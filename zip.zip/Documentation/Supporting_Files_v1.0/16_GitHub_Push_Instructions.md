# تعليمات رفع ودفع حزمة التوثيق إلى مستودع GitHub (MADAR-ERP)

**تنبيه أمانة حتمي**: بيئة التحقيق المعزولة تمتلك صلاحية **قراءة فقط (Read-Only)** لمستودع `https://github.com/AhmedElhassi/MADAR-ERP` ولا تملك مفاتيح أو توكن دفع (Push Credentials)، كما تم الحفاظ على ملفات التطبيق الأساسية كما هي تماماً.

لإتمام رفع مجلد `Documentation/` إلى المستودع بنفس البنية والمسارات:

```bash
# 1. استنساخ المستودع أو التوجه إلى نسختك المحلية المحدثة
git clone https://github.com/AhmedElhassi/MADAR-ERP.git
cd MADAR-ERP
git checkout main
git pull origin main

# 2. نسخ مجلد Documentation بالكامل إلى جذر المستودع
# (مثال من مسار بيئة AI Studio):
cp -r /path/to/exported/Documentation ./Documentation

# 3. التحقق من عدم المساس بملفات SQL أو الوثائق الأصلية
git status

# 4. إضافة مجلد التوثيق وإثباته بالرسالة المعتمدة
git add Documentation/
git commit -m "Add comprehensive MADAR ERP investigation and institutional design"

# 5. الدفع إلى فرع main (أو إنشاء فرع مراجعة مخصص مثل docs/investigation-v1.0)
git push origin main
```

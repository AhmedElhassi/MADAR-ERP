USE [MADARERPDataBase]
GO
/* توحيد التقارير المالية على DayMState = 7 (مؤرشف) */

/* ---- Acc_Select_Trial_Balance (2 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =====================================================================
   ميزان المراجعة
   ---------------------------------------------------------------------
   القواعد المحاسبية:
   - القيود المرحّلة فقط (DayMState = 7)، وتخص الشركة @Cmp.
   - رصيد أول المدة = كل الحركات قبل @FromDate من كل السنوات.
   - حركة الفترة = من @FromDate حتى @ToDate.
   - القيود تُسجَّل على الحسابات التحليلية (التي لا أبناء لها) فقط، وتُجمَّع
     أرصدتها نحو الآباء عبر شجرة الحسابات.
   - الصفوف والإجماليات تُحسب من الحسابات التحليلية فقط؛ أي حركة على حساب أب
     لا تدخل في الأرقام وتظهر فقط في ChkNonLeafAccounts.
   - إجماليات الميزان تُحسب لكل حساب تحليلي على حدة (مدين/دائن) دون مقاصة بين
     الحسابات، وتتجاهل فلاتر العرض.
   - شجرة الحسابات تُعالَج كاملة دون إسقاط أي مستوى. أي حلقة (حساب أبوه نفسه، أو
     دورة بين حسابين أو أكثر) تُوقف التقرير بخطأ صريح 50010.

   الأداء:
   - مسح واحد لجداول القيود، ومنه تُشتق الصفوف والإجماليات والفحوص.
   - لا CURSOR ولا قيود مسمّاة على الجداول المؤقتة (آمن للتشغيل المتزامن).

   فهارس مقترحة (إن لم تكن موجودة):
     CREATE INDEX IX_DayMaster_Cmp_State_Date
         ON dbo.Acc_DayMaster (DayMCompany, DayMState, DayMDate) INCLUDE (DayMNo);
     CREATE INDEX IX_DayDetails_Master
         ON dbo.Acc_DayDetails (DayDMID) INCLUDE (DayDAccID, DayDDeb, DayDCrd);
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_Select_Trial_Balance]
    @FromDate  DATE     = NULL,
    @ToDate    DATE     = NULL,
    @Cmp       INT      = 1,
    @Year      INT      = 0,
    @AllAcc    BIT      = 0,    -- 1 = الحسابات التحليلية فقط
    @MoveAcc   BIT      = 0,    -- 1 = الحسابات التي لها حركة خلال الفترة فقط
    @BalnceAcc BIT      = 0,    -- 1 = الحسابات التي رصيد نهاية مدتها <> 0 فقط
    @LevelAcc  TINYINT  = 0     -- 0 = كل المستويات ؛ AccLevel المطلق (+ التحليلي الأقل مستوى)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DROP TABLE IF EXISTS #Acc;
DROP TABLE IF EXISTS #Kid;
DROP TABLE IF EXISTS #Cl;
DROP TABLE IF EXISTS #Amount;
DROP TABLE IF EXISTS #LeafAmt;
DROP TABLE IF EXISTS #Roll;
    /* ---------- 1. التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);
    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    /* ---------- 2. شجرة حسابات الشركة ---------- */
    SELECT a.AccID,
           a.AccParentID,
           a.AccLevel,
           CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
           ISNULL(a.AccCode, N'') AS AccCode,
           ISNULL(a.AccName, N'') AS AccName
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc ON #Acc (AccID);
    CREATE NONCLUSTERED INDEX IX_Acc_Parent ON #Acc (AccParentID);

    /* ---------- 3. سلامة الشجرة: لا حلقات ولا حساب أبوه نفسه ----------
       نمشي من الجذور إلى الأسفل. كل حساب داخل حلقة (أو أبوه نفسه) لا يمكن
       الوصول إليه من أي جذر، فإذا اختلف عدد المُوصَل إليهم عن العدد الكلي
       فالشجرة فيها حلقة. لا يوجد حد عمق يُسقط مستويات: أقصى تكرار 1000 مجرد
       شبكة أمان تفشل بخطأ صريح إن تجاوزها، وهذا لا يحدث في شجرة حقيقية. */
    DECLARE @Total INT = (SELECT COUNT(*) FROM #Acc), @Reached INT;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0
           OR NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        JOIN #Acc  AS c ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT(*) FROM Reach
    OPTION (MAXRECURSION 1000);   -- شبكة أمان: تجاوزها يوقف التقرير بخطأ صريح (530) ولا يُسقط شيئًا بصمت

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300) =
            CONCAT(N'شجرة الحسابات فيها حلقة أو حساب أبوه نفسه (عدد الحسابات المتأثرة: ',
                   @Total - @Reached, N'). راجع الحسابات الأب والابن.');
        THROW 50010, @CycleMsg, 1;
    END;

    -- الآباء وعدد أبناء كل منهم (الحساب بلا أبناء = تحليلي)
    SELECT c.AccParentID AS AccID, COUNT(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid ON #Kid (AccID);

    /* ---------- 4. (الحساب ← كل أحفاده بما فيهم نفسه) ---------- */
    ;WITH Cl AS
    (
        SELECT a.AccID AS NodeID, a.AccID AS DescID
        FROM #Acc AS a

        UNION ALL

        SELECT t.NodeID, c.AccID
        FROM Cl AS t
        JOIN #Acc AS c ON c.AccParentID = t.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 1000);   -- شبكة أمان كما في الخطوة 3؛ عمق الشجرة الفعلي أقل منها بكثير

    CREATE UNIQUE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- 5. مسح واحد للقيود (أول المدة + حركة الفترة) ---------- */
    SELECT d.DayDAccID AS AccID,
           CAST(SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(18,3)) AS OpenNet,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END) AS DECIMAL(18,3))              AS PerDeb,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END) AS DECIMAL(18,3))              AS PerCrd,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END) AS BIGINT)                             AS PerCnt
    INTO #Amount
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate   <= @ToDate
    GROUP BY d.DayDAccID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount ON #Amount (AccID);

    /* ---------- 6. فحوص سلامة البيانات (النتيجة المتوقعة: أصفار) ---------- */
    DECLARE @ChkNonLeaf INT, @ChkOrphan INT, @ChkCrossCo INT, @ChkForeign INT, @ChkChid INT;

    -- حسابات عليها حركة وهي أب (الحركة لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT(*)
    FROM #Amount AS am
    JOIN #Kid    AS k ON k.AccID = am.AccID;

    -- حسابات أبوها غير موجود في أي شركة (يتيمة فعلًا)
    SELECT @ChkOrphan = COUNT(*)
    FROM #Acc AS a
    WHERE a.AccParentID > 0
      AND NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS x WHERE x.AccID = a.AccParentID);

    -- حسابات أبوها موجود لكنه يتبع شركة أخرى (ربط خاطئ بين الشركات)
    SELECT @ChkCrossCo = COUNT(*)
    FROM #Acc AS a
    WHERE a.AccParentID > 0
      AND NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)
      AND EXISTS     (SELECT 1 FROM dbo.Acc_Account AS x WHERE x.AccID = a.AccParentID);

    -- حركة على حساب لا يتبع هذه الشركة
    SELECT @ChkForeign = COUNT(*)
    FROM #Amount AS am
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS a WHERE a.AccID = am.AccID);

    -- AccChid المخزَّن لا يطابق وجود الأبناء الفعلي في الشجرة
    SELECT @ChkChid = COUNT(*)
    FROM #Acc AS a
    LEFT JOIN #Kid AS k ON k.AccID = a.AccID
    WHERE (CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
       <> (CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);

    /* ---------- 7. حركات الحسابات التحليلية فقط (أساس الصفوف والإجماليات) ---------- */
    SELECT am.AccID, am.OpenNet, am.PerDeb, am.PerCrd, am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    JOIN #Acc    AS a ON a.AccID = am.AccID
    WHERE NOT EXISTS (SELECT 1 FROM #Kid AS k WHERE k.AccID = am.AccID);

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt ON #LeafAmt (AccID);

    /* ---------- 8. إجماليات الميزان (لكل حساب تحليلي على حدة) ---------- */
    DECLARE
        @SumBlcOldDebit  DECIMAL(18,3), @SumBlcOldCredit  DECIMAL(18,3),
        @SumTotDebit     DECIMAL(18,3), @SumTotCredit     DECIMAL(18,3),
        @SumBlcDebit     DECIMAL(18,3), @SumBlcCredit     DECIMAL(18,3),
        @SumTotBlcDebit  DECIMAL(18,3), @SumTotBlcCredit  DECIMAL(18,3);

    SELECT
        @SumBlcOldDebit  = ISNULL(SUM(CASE WHEN y.OpenNet  > 0 THEN  y.OpenNet  ELSE 0 END), 0),
        @SumBlcOldCredit = ISNULL(SUM(CASE WHEN y.OpenNet  < 0 THEN -y.OpenNet  ELSE 0 END), 0),
        @SumTotDebit     = ISNULL(SUM(y.PerDeb), 0),
        @SumTotCredit    = ISNULL(SUM(y.PerCrd), 0),
        @SumBlcDebit     = ISNULL(SUM(CASE WHEN y.PerNet   > 0 THEN  y.PerNet   ELSE 0 END), 0),
        @SumBlcCredit    = ISNULL(SUM(CASE WHEN y.PerNet   < 0 THEN -y.PerNet   ELSE 0 END), 0),
        @SumTotBlcDebit  = ISNULL(SUM(CASE WHEN y.CloseNet > 0 THEN  y.CloseNet ELSE 0 END), 0),
        @SumTotBlcCredit = ISNULL(SUM(CASE WHEN y.CloseNet < 0 THEN -y.CloseNet ELSE 0 END), 0)
    FROM
    (
        SELECT l.OpenNet, l.PerDeb, l.PerCrd,
               l.PerDeb - l.PerCrd                AS PerNet,
               l.OpenNet + l.PerDeb - l.PerCrd    AS CloseNet
        FROM #LeafAmt AS l
    ) AS y;

    /* ---------- 9. تجميع كل حساب مع أحفاده ---------- */
    SELECT a.AccID, a.AccCode, a.AccName, a.AccParentID, a.AccLevel, a.AccChid,
           CAST(ISNULL(SUM(l.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(l.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(l.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(l.PerCnt ), 0) AS BIGINT)        AS PerCnt
    INTO #Roll
    FROM #Acc AS a
    JOIN #Cl  AS c ON c.NodeID = a.AccID
    LEFT JOIN #LeafAmt AS l ON l.AccID = c.DescID
    GROUP BY a.AccID, a.AccCode, a.AccName, a.AccParentID, a.AccLevel, a.AccChid;

    CREATE UNIQUE CLUSTERED INDEX IX_Roll ON #Roll (AccID);

    /* ---------- 10. النتيجة النهائية ---------- */
    SELECT
        x.AccID,
        x.AccCode,
        x.AccName                          AS AccARName,
        x.AccLevel,
        x.AccParentID                      AS AccParint,
        p.AccName                          AS AccParintName,
        x.AccChid                          AS AccCountChid,

        -- رصيد أول المدة
        CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
        CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
        -- الحركة بالمجاميع
        x.PerDeb                                            AS NewDebit,
        x.PerCrd                                            AS NewCredit,
        -- الحركة بالأرصدة
        CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END    AS BalanceDebit,
        CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END    AS BalanceCredit,
        -- رصيد نهاية الفترة
        CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotBlcDebit,
        CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,

        -- إجماليات الميزان (تتكرر على كل صف)
        @SumBlcOldDebit  AS SumBlcOldDebit,
        @SumBlcOldCredit AS SumBlcOldCredit,
        @SumTotDebit     AS SumTotDebit,
        @SumTotCredit    AS SumTotCredit,
        @SumBlcDebit     AS SumBlcDebit,
        @SumBlcCredit    AS SumBlcCredit,
        @SumTotBlcDebit  AS SumTotBlcDebit,
        @SumTotBlcCredit AS SumTotBlcCredit,

        -- فحوص ذاتية في آخر النتيجة: يجب أن تكون كلها صفرًا
        @SumBlcOldDebit - @SumBlcOldCredit AS ChkOpenDiff,
        @SumTotDebit    - @SumTotCredit    AS ChkPeriodDiff,
        @SumTotBlcDebit - @SumTotBlcCredit AS ChkCloseDiff,
        @ChkNonLeaf                        AS ChkNonLeafAccounts,
        @ChkOrphan                         AS ChkOrphanAccounts,
        @ChkCrossCo                        AS ChkCrossCompanyParents,
        @ChkForeign                        AS ChkForeignAccounts,
        @ChkChid                           AS ChkChidMismatch

    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #Roll AS r
    ) AS x
    LEFT JOIN #Acc AS p ON p.AccID = x.AccParentID
    LEFT JOIN #Kid AS k ON k.AccID = x.AccID
    WHERE (@AllAcc    = 0 OR k.AccID IS NULL)
      AND (@LevelAcc  = 0 OR x.AccLevel = @LevelAcc OR (x.AccLevel < @LevelAcc AND k.AccID IS NULL))
      AND (@MoveAcc   = 0 OR x.PerCnt   > 0)
      AND (@BalnceAcc = 0 OR x.CloseNet <> 0)
    ORDER BY x.AccCode, x.AccID
    OPTION (RECOMPILE);
END;

GO

/* ---- Acc_SelectAccBalanceSheet (2 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =====================================================================
   الميزانية العمومية
   ---------------------------------------------------------------------
   القواعد المحاسبية:
   - القيود المرحّلة فقط (DayMState = 7) للشركة @Cmp، حتى @ToDate.
   - الرصيد السابق = كل الحركات قبل @FromDate من كل السنوات.
   - القيد يُسجَّل على الحسابات التحليلية فقط؛ تُجمَّع نحو الآباء تصاعديًّا.
   - الأصول (AccType=0) = الرصيد المدين، الخصوم (1) وحقوق الملكية (2) = الرصيد الدائن.
   - السنة المالية لا تُقفل، فحسابات قائمة الدخل (AccEnd=2) تتراكم، وتُضاف
     إلى حقوق الملكية بصفّين مستقلين:
       * نتائج السنوات السابقة   (كل ما قبل 1 يناير من @Year)
       * نتيجة السنة الحالية     (من 1 يناير حتى @ToDate)
     وبذلك يكون: الأصول = الخصوم + حقوق الملكية + نتائج، والفرق
     BalanceDifference يساوي فرق دفتر الأستاذ فقط (صفر إن كانت القيود متوازنة).
   - مؤشرات سلامة البيانات في آخر النتيجة (يجب أن تكون أصفارًا).
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccBalanceSheet]
    @FromDate   DATE     = NULL,
    @ToDate     DATE     = NULL,
    @Cmp        INT      = 1,
    @Year       INT      = 0,
    @AllAcc     BIT      = 0,
    @MoveAcc    BIT      = 0,
    @BalnceAcc  BIT      = 0,
    @LevelAcc   TINYINT  = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Out;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #LeafIS;
    DROP TABLE IF EXISTS #LeafAmt;
    DROP TABLE IF EXISTS #Amount;
    DROP TABLE IF EXISTS #AccIS;
    DROP TABLE IF EXISTS #AccBS;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Acc;

    /* 1. التحقق من المدخلات */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year
       OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);


    /* 2. تحميل شجرة حسابات الشركة */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);


    /* 3. التحقق من الحسابات اليتيمة */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS x
              WHERE x.AccID = a.AccParentID
          )
    )
        THROW 50011, N'شجرة الحسابات تحتوي على حسابات يتيمة؛ الحساب الأب غير موجود.', 1;


    /* 4. التحقق من الربط بين الشركات */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #Acc AS p
              WHERE p.AccID = a.AccParentID
          )
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS x
              WHERE x.AccID = a.AccParentID
          )
    )
        THROW 50012, N'شجرة الحسابات تحتوي على ربط بين حسابات شركتين مختلفتين.', 1;


    /* 5. التحقق من الحلقات والحسابات غير القابلة للوصول */

    DECLARE
        @Total   BIGINT,
        @Reached BIGINT;

    SELECT @Total = COUNT_BIG(*)
    FROM #Acc;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        INNER JOIN #Acc AS c
            ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT_BIG(*)
    FROM Reach
    OPTION (MAXRECURSION 32767);

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300);

        SET @CycleMsg =
            CONCAT(
                N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول من الجذور. عدد الحسابات المتأثرة: ',
                @Total - @Reached
            );

        THROW 50010, @CycleMsg, 1;
    END;


    /* 6. تحديد عدد الأبناء الفعلي */

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);


    /* 7. حسابات الميزانية العمومية، وحسابات قائمة الدخل (لنتيجة السنة) */

    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        AccEnd,
        AccType
    INTO #AccBS
    FROM #Acc
    WHERE AccEnd = 1
      AND AccType IN (0, 1, 2);

    CREATE UNIQUE CLUSTERED INDEX IX_AccBS
        ON #AccBS (AccID);

    SELECT AccID
    INTO #AccIS
    FROM #Acc
    WHERE AccEnd = 2
      AND AccType IN (0, 1);

    CREATE UNIQUE CLUSTERED INDEX IX_AccIS
        ON #AccIS (AccID);


    /* 8. التحقق من تجانس تصنيف حسابات الميزانية مع آبائها */

    IF EXISTS
    (
        SELECT 1
        FROM #AccBS AS c
        INNER JOIN #AccBS AS p
            ON p.AccID = c.AccParentID
        WHERE c.AccType <> p.AccType
    )
        THROW 50013, N'يوجد اختلاف في تصنيف الحساب عن تصنيف الحساب الأب في الميزانية.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #AccBS AS c
        INNER JOIN #Acc AS p
            ON p.AccID = c.AccParentID
        WHERE p.AccEnd <> 1
    )
        THROW 50014, N'يوجد حساب ميزانية تابع لحساب لا ينتمي إلى الميزانية العمومية.', 1;


    /* 9. مسح واحد للحركات حتى @ToDate (كل الحسابات) */

    SELECT
        d.DayDAccID AS AccID,

        -- كل ما قبل @FromDate
        CAST(SUM(CASE WHEN m.DayMDate < @FromDate
                      THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS OpenNet,

        -- كل ما قبل 1 يناير من السنة (لنتائج السنوات السابقة)
        CAST(SUM(CASE WHEN m.DayMDate < @YearStart
                      THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS PriorNet,

        CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END) AS DECIMAL(28,3)) AS PerDeb,
        CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS PerCrd,

        SUM(CONVERT(BIGINT, CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)) AS PerCnt

    INTO #Amount

    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID

    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @ToDate

    GROUP BY d.DayDAccID

    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount
        ON #Amount (AccID);


    /* 10. مؤشرات سلامة البيانات */

    DECLARE
        @ChkNonLeaf BIGINT = 0,
        @ChkForeign BIGINT = 0,
        @ChkChid    BIGINT = 0;

    -- حركة مسجلة على حساب أب (لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT_BIG(*)
    FROM #Amount AS am
    INNER JOIN #Kid AS k
        ON k.AccID = am.AccID;

    -- حركة على حساب لا يتبع الشركة
    SELECT @ChkForeign = COUNT_BIG(*)
    FROM #Amount AS am
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS a WHERE a.AccID = am.AccID);

    -- عدم تطابق AccChid مع الأبناء الفعليين
    SELECT @ChkChid = COUNT_BIG(*)
    FROM #Acc AS a
    LEFT JOIN #Kid AS k
        ON k.AccID = a.AccID
    WHERE (CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
        <> (CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);


    /* 11. حركات الحسابات التحليلية */

    -- الميزانية
    SELECT
        am.AccID,
        am.OpenNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    INNER JOIN #AccBS AS a
        ON a.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
        ON #LeafAmt (AccID);

    -- قائمة الدخل (لنتائج السنوات السابقة والسنة الحالية)
    SELECT
        am.AccID,
        am.OpenNet,
        am.PriorNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafIS
    FROM #Amount AS am
    INNER JOIN #AccIS AS i
        ON i.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );


    /* 12. إجماليات الأصول والخصوم وحقوق الملكية + نتائج السنوات */

    DECLARE
        @TotalAssets      DECIMAL(38,3),
        @TotalLiabilities DECIMAL(38,3),
        @TotalEquityAcc   DECIMAL(38,3),   -- حسابات حقوق الملكية فقط
        @PriorNet         DECIMAL(38,3),   -- صافي مدين قائمة الدخل قبل بداية السنة
        @CurOpenNet       DECIMAL(38,3),   -- من بداية السنة حتى قبل @FromDate
        @CurPerDeb        DECIMAL(38,3),
        @CurPerCrd        DECIMAL(38,3),
        @CurPerCnt        BIGINT,
        @PriorResult      DECIMAL(38,3),   -- نتائج السنوات السابقة (الدائن موجب)
        @CurResult        DECIMAL(38,3),   -- نتيجة السنة الحالية (الدائن موجب)
        @TotalEquity      DECIMAL(38,3);

    SELECT
        @TotalAssets =
            ISNULL(SUM(CASE WHEN a.AccType = 0 THEN  (l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalLiabilities =
            ISNULL(SUM(CASE WHEN a.AccType = 1 THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalEquityAcc =
            ISNULL(SUM(CASE WHEN a.AccType = 2 THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0)
    FROM #LeafAmt AS l
    INNER JOIN #AccBS AS a
        ON a.AccID = l.AccID;

    SELECT
        @PriorNet   = ISNULL(SUM(i.PriorNet), 0),
        @CurOpenNet = ISNULL(SUM(i.OpenNet - i.PriorNet), 0),
        @CurPerDeb  = ISNULL(SUM(i.PerDeb), 0),
        @CurPerCrd  = ISNULL(SUM(i.PerCrd), 0),
        @CurPerCnt  = ISNULL(SUM(i.PerCnt), 0)
    FROM #LeafIS AS i;

    SET @PriorResult = -@PriorNet;
    SET @CurResult   = -(@CurOpenNet + @CurPerDeb - @CurPerCrd);
    SET @TotalEquity = @TotalEquityAcc + @PriorResult + @CurResult;


    /* 13. التجميع التصاعدي من الحسابات التحليلية إلى الآباء */

    ;WITH RollUp AS
    (
        SELECT
            l.AccID AS NodeID,
            l.OpenNet,
            l.PerDeb,
            l.PerCrd,
            l.PerCnt
        FROM #LeafAmt AS l

        UNION ALL

        SELECT
            p.AccID AS NodeID,
            r.OpenNet,
            r.PerDeb,
            r.PerCrd,
            r.PerCnt
        FROM RollUp AS r
        INNER JOIN #AccBS AS c
            ON c.AccID = r.NodeID
        INNER JOIN #AccBS AS p
            ON p.AccID = c.AccParentID
           AND c.AccParentID > 0
    ),
    RollTotals AS
    (
        SELECT
            NodeID AS AccID,
            SUM(OpenNet) AS OpenNet,
            SUM(PerDeb) AS PerDeb,
            SUM(PerCrd) AS PerCrd,
            SUM(PerCnt) AS PerCnt
        FROM RollUp
        GROUP BY NodeID
    )
    SELECT
        a.AccID,
        a.AccCode,
        a.AccName,
        a.AccParentID,
        a.AccLevel,
        a.AccChid,
        a.AccType,

        CAST(ISNULL(t.OpenNet, 0) AS DECIMAL(28,3)) AS OpenNet,
        CAST(ISNULL(t.PerDeb, 0) AS DECIMAL(28,3)) AS PerDeb,
        CAST(ISNULL(t.PerCrd, 0) AS DECIMAL(28,3)) AS PerCrd,

        ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt

    INTO #Roll

    FROM #AccBS AS a
    LEFT JOIN RollTotals AS t
        ON t.AccID = a.AccID

    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_Roll
        ON #Roll (AccID);


    /* 14. صفوف الميزانية + صفّا نتائج السنوات (Kind: 0 حساب، 1 سنوات سابقة، 2 السنة الحالية) */

    SELECT
        x.AccID,
        x.AccCode,
        x.AccName,
        x.AccLevel,
        x.AccParentID,
        p.AccName AS AccParentName,
        x.AccChid,
        x.AccType,
        CAST(CASE WHEN k.AccID IS NULL THEN 1 ELSE 0 END AS BIT) AS IsLeaf,
        x.OpenNet,
        x.PerDeb,
        x.PerCrd,
        x.PerCnt,
        CAST(0 AS TINYINT) AS Kind
    INTO #Out
    FROM #Roll AS x
    LEFT JOIN #AccBS AS p
        ON p.AccID = x.AccParentID
    LEFT JOIN #Kid AS k
        ON k.AccID = x.AccID;

    INSERT INTO #Out
    (
        AccID, AccCode, AccName, AccLevel, AccParentID, AccParentName,
        AccChid, AccType, IsLeaf, OpenNet, PerDeb, PerCrd, PerCnt, Kind
    )
    VALUES
    (
        -1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', 1, NULL, NULL,
        0, 2, 1, @PriorNet, 0, 0, 0, 1
    ),
    (
        -2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', 1, NULL, NULL,
        0, 2, 1, @CurOpenNet, @CurPerDeb, @CurPerCrd, @CurPerCnt, 2
    );


    /* 15. النتيجة النهائية */

    SELECT
        x.AccID,
        x.AccCode,
        x.AccName AS AccARName,
        x.AccLevel,
        x.AccParentID AS AccParint,
        x.AccParentName AS AccParintName,
        x.AccChid AS AccCountChid,
        x.AccType,

        CASE
            WHEN x.AccType = 0 THEN N'الأصول'
            WHEN x.AccType = 1 THEN N'الخصوم'
            WHEN x.AccType = 2 THEN N'حقوق الملكية'
        END AS AccountCategory,

        -- الرصيد السابق
        CASE WHEN x.OpenNet > 0 THEN x.OpenNet ELSE 0 END AS OldDebit,
        CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,

        -- حركة الفترة
        x.PerDeb AS NewDebit,
        x.PerCrd AS NewCredit,

        -- صافي حركة الفترة
        CASE WHEN x.PerNet > 0 THEN x.PerNet ELSE 0 END AS BalanceDebit,
        CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,

        -- الرصيد الختامي
        CASE WHEN x.CloseNet > 0 THEN x.CloseNet ELSE 0 END AS TotBlcDebit,
        CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,

        x.CloseNet AS NetBalance,
        x.PerCnt AS MovementCount,

        CAST(CASE WHEN x.Kind = 2 THEN 1 ELSE 0 END AS BIT) AS IsCurrentYearResult,

        @TotalAssets AS TotalAssets,
        @TotalLiabilities AS TotalLiabilities,
        @TotalEquity AS TotalEquity,

        @TotalAssets - (@TotalLiabilities + @TotalEquity)
            AS BalanceDifference,

        CAST(CASE WHEN x.Kind = 1 THEN 1 ELSE 0 END AS BIT) AS IsPriorYearsResult,
        @PriorResult AS PriorYearsResult,
        @CurResult   AS CurrentYearResult,

        -- مؤشرات سلامة البيانات
        @ChkNonLeaf AS ChkNonLeafAccounts,
        @ChkForeign AS ChkForeignAccounts,
        @ChkChid    AS ChkChidMismatch

    FROM
    (
        SELECT
            o.*,

            CAST(o.PerDeb - o.PerCrd AS DECIMAL(28,3)) AS PerNet,

            CAST(o.OpenNet + o.PerDeb - o.PerCrd AS DECIMAL(28,3)) AS CloseNet

        FROM #Out AS o
    ) AS x

    WHERE
        -- صفّا النتائج يظهران دائمًا (ولا يخضعان لفلاتر العرض إلا الحركة والرصيد)
        (
            x.Kind > 0
            OR
            (
                (@AllAcc = 0 OR x.IsLeaf = 1)

                AND
                (
                    @LevelAcc = 0
                    OR x.AccLevel = @LevelAcc
                    OR (x.AccLevel < @LevelAcc AND x.IsLeaf = 1)
                )
            )
        )

        AND (@MoveAcc = 0 OR x.PerCnt > 0)

        AND (@BalnceAcc = 0 OR x.CloseNet <> 0)

    ORDER BY
        x.Kind,
        x.AccCode,
        x.AccID

    OPTION (RECOMPILE);

END;

GO

/* ---- Acc_SelectAccChangesInEquity (4 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccChangesInEquity]
    @FromDate DATE,
    @ToDate   DATE,
    @Cmp      INT = 1
AS
BEGIN
    /* =====================================================================
       اسم التقرير : قائمة التغيّرات في حقوق الملكية
                     (Statement of Changes in Equity)
       الإجراء     : dbo.Acc_SelectAccChangesInEquity
       المدخلات    : @FromDate و@ToDate ضمن سنة مالية واحدة، و@Cmp = الشركة.

       مكوّنات حقوق الملكية (بلا أرقام ثابتة):
         - الجذر: حساب الشركة الذي AccEnd = 1 و AccType = 2 و AccParentID = NULL
           (يجب أن يكون واحدًا فقط).
         - المكوّنات: أبناؤه المباشرون (رأس المال، الأرباح والخسائر، أي احتياطي
           يُضاف لاحقًا...). إن لم يكن له أبناء فالجذر نفسه هو المكوّن.
         أي مكوّن جديد يُضاف تحت الجذر يظهر في القائمة تلقائيًا.

       لكل مكوّن: الرصيد الافتتاحي، حركة الفترة (مدين/دائن)، صافي التغيّر،
       الرصيد الختامي، ثم صف إجمالي حقوق الملكية.

       نتائج النشاط: السنة المالية لا تُقفل، فنتيجة النشاط تبقى في حسابات قائمة
                     الدخل. لذلك يضيف التقرير صفّين لتطابق الإجمالي مع الميزانية:
                       AccID = -1 نتائج السنوات السابقة (كل ما قبل 1 يناير)
                       AccID = -2 نتيجة السنة الحالية (من 1 يناير حتى @ToDate،
                                  وافتتاحيها ما كان من 1 يناير حتى قبل @FromDate)

       القواعد     : القيود المرحّلة فقط (DayMState = 7)؛ الافتتاحي = كل ما قبل
                     @FromDate من كل السنوات؛ القيد على الحساب التحليلي فقط
                     (حركة على حساب أب ضمن الشجرة أو على الجذر = خطأ 50006).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #EquityTree;
    DROP TABLE IF EXISTS #EquityKid;
    DROP TABLE IF EXISTS #Comp;
    DROP TABLE IF EXISTS #Result;
    DROP TABLE IF EXISTS #Output;

    /* 1. التحقق من المدخلات */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50001, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50002, N'الشركة المحددة غير صحيحة.', 1;

    IF YEAR(@FromDate) <> YEAR(@ToDate)
        THROW 50003, N'يجب أن تقع الفترة ضمن السنة المالية نفسها.', 1;


    /* 2. تحديد جذر حقوق الملكية ومكوّناته */

    DECLARE
        @RootCnt INT,
        @EqRoot  BIGINT;

    SELECT
        @RootCnt = COUNT(*),
        @EqRoot  = MAX(AccID)
    FROM dbo.Acc_Account
    WHERE AccCompany = @Cmp
      AND AccEnd = 1
      AND AccType = 2
      AND AccParentID IS NULL;

    IF @RootCnt = 0
        THROW 50004, N'لا يوجد حساب جذر لحقوق الملكية (AccEnd = 1 و AccType = 2).', 1;

    IF @RootCnt > 1
        THROW 50005, N'يوجد أكثر من جذر لحقوق الملكية؛ يجب أن يكون واحدًا.', 1;

    SELECT A.AccID
    INTO #Comp
    FROM dbo.Acc_Account AS A
    WHERE A.AccCompany = @Cmp
      AND A.AccParentID = @EqRoot;

    IF NOT EXISTS (SELECT 1 FROM #Comp)
        INSERT INTO #Comp (AccID) VALUES (@EqRoot);

    IF EXISTS
    (
        SELECT 1
        FROM #Comp AS C
        INNER JOIN dbo.Acc_Account AS A
            ON A.AccID = C.AccID
        WHERE A.AccEnd <> 1
           OR A.AccType <> 2
    )
        THROW 50009, N'يوجد مكوّن تحت جذر حقوق الملكية تصنيفه ليس من حقوق الملكية.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Comp
        ON #Comp (AccID);


    /* 3. تحميل شجرة حقوق الملكية */

    ;WITH EquityTree AS
    (
        SELECT
            A.AccID,
            A.AccParentID,
            A.AccLevel,
            A.AccChid,
            A.AccCode,
            A.AccName,
            A.AccID AS EquityRoot,
            CAST(
                '/' + CAST(A.AccID AS VARCHAR(20)) + '/'
                AS VARCHAR(MAX)
            ) AS AccountPath
        FROM dbo.Acc_Account A
        INNER JOIN #Comp K
            ON K.AccID = A.AccID
        WHERE A.AccCompany = @Cmp

        UNION ALL

        SELECT
            C.AccID,
            C.AccParentID,
            C.AccLevel,
            C.AccChid,
            C.AccCode,
            C.AccName,
            P.EquityRoot,
            CAST(
                P.AccountPath + CAST(C.AccID AS VARCHAR(20)) + '/'
                AS VARCHAR(MAX)
            )
        FROM dbo.Acc_Account C
        INNER JOIN EquityTree P
            ON C.AccParentID = P.AccID
        WHERE C.AccCompany = @Cmp
          AND P.AccountPath NOT LIKE
              '%/' + CAST(C.AccID AS VARCHAR(20)) + '/%'
    )
    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        EquityRoot
    INTO #EquityTree
    FROM EquityTree
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_EquityTree
        ON #EquityTree (AccID);


    /* 4. تحديد الحسابات الأب (تشمل الجذر نفسه إن كانت المكوّنات أبناءه) */

    SELECT DISTINCT
        AccParentID AS AccID
    INTO #EquityKid
    FROM #EquityTree
    WHERE AccParentID IS NOT NULL;

    CREATE UNIQUE CLUSTERED INDEX IX_EquityKid
        ON #EquityKid (AccID);


    /* 5. منع الحركات المباشرة على الحسابات الأب */

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Acc_DayMaster M
        INNER JOIN dbo.Acc_DayDetails D
            ON D.DayDMID = M.DayMID
        INNER JOIN #EquityKid K
            ON K.AccID = D.DayDAccID
        WHERE M.DayMCompany = @Cmp
          AND M.DayMState = 7
          AND M.DayMDate <= @ToDate
    )
        THROW 50006, N'توجد حركات مباشرة على حساب أب ضمن شجرة حقوق الملكية. يجب مراجعة توزيع الحركات على الحسابات التحليلية.', 1;


    /* 6. استخراج الأرصدة والحركات من الحسابات التحليلية */

    ;WITH LeafAmounts AS
    (
        SELECT
            T.EquityRoot,

            SUM
            (
                CASE
                    WHEN M.DayMDate < @FromDate
                    THEN ISNULL(D.DayDDeb, 0) - ISNULL(D.DayDCrd, 0)
                    ELSE 0
                END
            ) AS OpeningNet,

            SUM
            (
                CASE
                    WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                    THEN ISNULL(D.DayDDeb, 0)
                    ELSE 0
                END
            ) AS PeriodDebit,

            SUM
            (
                CASE
                    WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                    THEN ISNULL(D.DayDCrd, 0)
                    ELSE 0
                END
            ) AS PeriodCredit

        FROM #EquityTree T
        INNER JOIN dbo.Acc_DayDetails D
            ON D.DayDAccID = T.AccID
        INNER JOIN dbo.Acc_DayMaster M
            ON M.DayMID = D.DayDMID
        WHERE M.DayMCompany = @Cmp
          AND M.DayMState = 7
          AND M.DayMDate <= @ToDate
          AND NOT EXISTS
          (
              SELECT 1
              FROM #EquityKid K
              WHERE K.AccID = T.AccID
          )
        GROUP BY T.EquityRoot
    )
    SELECT
        T.AccID,
        T.AccCode,
        T.AccName,

        CAST(ISNULL(L.OpeningNet, 0) AS DECIMAL(28,3)) AS OpeningNet,
        CAST(ISNULL(L.PeriodDebit, 0) AS DECIMAL(28,3)) AS PeriodDebit,
        CAST(ISNULL(L.PeriodCredit, 0) AS DECIMAL(28,3)) AS PeriodCredit

    INTO #Result
    FROM #EquityTree T
    INNER JOIN #Comp K
        ON K.AccID = T.AccID
    LEFT JOIN LeafAmounts L
        ON L.EquityRoot = T.AccID;

    CREATE UNIQUE CLUSTERED INDEX IX_Result
        ON #Result (AccID);

    ALTER TABLE #Result ALTER COLUMN AccCode NVARCHAR(100) NULL;
    ALTER TABLE #Result ALTER COLUMN AccName NVARCHAR(200) NULL;


    /* 6.1 نتائج السنوات من حسابات قائمة الدخل التحليلية (السنة لا تُقفل) */

    DECLARE @YearStart DATE = DATEFROMPARTS(YEAR(@FromDate), 1, 1);

    DECLARE
        @PriorNet  DECIMAL(28,3),
        @CurOpen   DECIMAL(28,3),
        @CurDebit  DECIMAL(28,3),
        @CurCredit DECIMAL(28,3);

    SELECT
        @PriorNet  = ISNULL(SUM(CASE WHEN M.DayMDate < @YearStart
                                     THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @CurOpen   = ISNULL(SUM(CASE WHEN M.DayMDate >= @YearStart AND M.DayMDate < @FromDate
                                     THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @CurDebit  = ISNULL(SUM(CASE WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                                     THEN D.DayDDeb ELSE 0 END), 0),
        @CurCredit = ISNULL(SUM(CASE WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                                     THEN D.DayDCrd ELSE 0 END), 0)
    FROM dbo.Acc_DayMaster M
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = M.DayMID
    INNER JOIN dbo.Acc_Account A
        ON A.AccID = D.DayDAccID
       AND A.AccCompany = @Cmp
       AND A.AccEnd = 2
       AND A.AccType IN (0, 1)
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate <= @ToDate
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Acc_Account C
          WHERE C.AccParentID = A.AccID
      );

    INSERT INTO #Result (AccID, AccCode, AccName, OpeningNet, PeriodDebit, PeriodCredit)
    VALUES
        (-1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', @PriorNet, 0, 0),
        (-2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', @CurOpen, @CurDebit, @CurCredit);


    /* 7. تجهيز التقرير */

    CREATE TABLE #Output
    (
        SortOrder       INT NOT NULL,
        AccID           BIGINT NOT NULL,
        AccCode         NVARCHAR(100) NOT NULL,
        EquityComponent NVARCHAR(200) NOT NULL,

        OpeningDebit    DECIMAL(28,3) NOT NULL,
        OpeningCredit   DECIMAL(28,3) NOT NULL,

        PeriodDebit     DECIMAL(28,3) NOT NULL,
        PeriodCredit    DECIMAL(28,3) NOT NULL,

        NetChange       DECIMAL(28,3) NOT NULL,

        ClosingDebit    DECIMAL(28,3) NOT NULL,
        ClosingCredit   DECIMAL(28,3) NOT NULL
    );


    /* 8. تفاصيل مكونات حقوق الملكية + صفّا النتائج */

    INSERT INTO #Output
    (
        SortOrder,
        AccID,
        AccCode,
        EquityComponent,
        OpeningDebit,
        OpeningCredit,
        PeriodDebit,
        PeriodCredit,
        NetChange,
        ClosingDebit,
        ClosingCredit
    )
    SELECT
        ROW_NUMBER() OVER
        (
            ORDER BY
                CASE WHEN R.AccID < 0 THEN 1 ELSE 0 END,
                R.AccCode,
                R.AccID
        ),

        R.AccID,
        ISNULL(R.AccCode, N''),
        ISNULL(R.AccName, N''),

        CASE
            WHEN R.OpeningNet > 0 THEN R.OpeningNet
            ELSE 0
        END,

        CASE
            WHEN R.OpeningNet < 0 THEN -R.OpeningNet
            ELSE 0
        END,

        R.PeriodDebit,
        R.PeriodCredit,

        R.PeriodCredit - R.PeriodDebit,

        CASE
            WHEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit > 0
            THEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit
            ELSE 0
        END,

        CASE
            WHEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit < 0
            THEN -(R.OpeningNet + R.PeriodDebit - R.PeriodCredit)
            ELSE 0
        END

    FROM #Result R;


    /* 9. إجمالي حقوق الملكية */

    DECLARE
        @OpeningTotal DECIMAL(28,3),
        @DebitTotal   DECIMAL(28,3),
        @CreditTotal  DECIMAL(28,3),
        @ClosingTotal DECIMAL(28,3);

    SELECT
        @OpeningTotal = ISNULL(SUM(OpeningNet), 0),
        @DebitTotal   = ISNULL(SUM(PeriodDebit), 0),
        @CreditTotal  = ISNULL(SUM(PeriodCredit), 0)
    FROM #Result;

    SET @ClosingTotal =
        @OpeningTotal + @DebitTotal - @CreditTotal;

    INSERT INTO #Output
    (
        SortOrder,
        AccID,
        AccCode,
        EquityComponent,
        OpeningDebit,
        OpeningCredit,
        PeriodDebit,
        PeriodCredit,
        NetChange,
        ClosingDebit,
        ClosingCredit
    )
    VALUES
    (
        2147483647,
        0,
        N'',
        N'إجمالي حقوق الملكية',

        CASE WHEN @OpeningTotal > 0
             THEN @OpeningTotal ELSE 0 END,

        CASE WHEN @OpeningTotal < 0
             THEN -@OpeningTotal ELSE 0 END,

        @DebitTotal,
        @CreditTotal,
        @CreditTotal - @DebitTotal,

        CASE WHEN @ClosingTotal > 0
             THEN @ClosingTotal ELSE 0 END,

        CASE WHEN @ClosingTotal < 0
             THEN -@ClosingTotal ELSE 0 END
    );


    /* 10. إخراج التقرير */

    SELECT
        AccID,
        AccCode,
        EquityComponent,

        OpeningDebit,
        OpeningCredit,

        PeriodDebit,
        PeriodCredit,

        NetChange,

        ClosingDebit,
        ClosingCredit,

        @FromDate AS FromDate,
        @ToDate AS ToDate

    FROM #Output
    ORDER BY SortOrder;

END;

GO

/* ---- Acc_SelectAccFinancialNotes (2 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccFinancialNotes]
    @FromDate   DATE     = NULL,
    @ToDate     DATE     = NULL,
    @Cmp        INT      = 1,
    @Year       INT      = 0,
    @AllAcc     BIT      = 0,
    @MoveAcc    BIT      = 0,
    @BalnceAcc  BIT      = 0,
    @LevelAcc   TINYINT  = 0
AS
BEGIN
    /* =====================================================================
       اسم التقرير : الإيضاحات المتممة للقوائم المالية
                     (Notes to the Financial Statements)
       الإجراء     : dbo.Acc_SelectAccFinancialNotes
       المدخلات    : @FromDate و@ToDate ضمن @Year، و@Cmp = الشركة،
                     @AllAcc (1 = التحليلية فقط)، @MoveAcc، @BalnceAcc، @LevelAcc.
       المحتوى     : خمسة إيضاحات:
                       1 الأصول   2 الالتزامات   3 حقوق الملكية
                       4 الإيرادات   5 المصروفات
       الأرصدة     :
         - إيضاحات الميزانية (1-3): الافتتاحي = كل ما قبل @FromDate من كل السنوات.
         - إيضاحات قائمة الدخل (4-5): الافتتاحي = من 1 يناير حتى قبل @FromDate
           (السنة الحالية فقط)، والختامي = من 1 يناير حتى @ToDate.
           ما قبل 1 يناير يظهر ضمن صف «نتائج السنوات السابقة» في إيضاح 3.
       القواعد     : القيود المرحّلة فقط (DayMState = 7)؛ القيد على الحساب
                     التحليلي فقط ويُجمَّع نحو الآباء؛ السنة لا تُقفل.
       حقوق الملكية: إيضاح 3 يضم حسابات حقوق الملكية + صفّين:
                       AccID = -1 نتائج السنوات السابقة
                       AccID = -2 نتيجة السنة الحالية
                     (يظهران مهما كانت @AllAcc و@LevelAcc، ويخضعان لـ @MoveAcc و@BalnceAcc).
                     وبذلك: الأصول = الخصوم + حقوق الملكية، ويكون
                     BalanceDifference صفرًا إذا كانت القيود متوازنة، وإجمالي
                     إيضاح 4 - إيضاح 5 = نتيجة السنة الحالية.
       الفحوص      : ChkNonLeafAccounts = حسابات أب عليها حركة (لا تدخل في الأرقام)
                     ChkOtherAccounts   = حركة على حسابات غير تابعة للشركة أو غير مصنفة
                     يجب أن تكون صفرًا.
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Notes;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #RollTotals;
    DROP TABLE IF EXISTS #LeafAmt;
    DROP TABLE IF EXISTS #Amount;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #AccNote;
    DROP TABLE IF EXISTS #Acc;

    /* =========================================================
       1. التحقق من المدخلات
       ========================================================= */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year
       OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);


    /* =========================================================
       2. تحميل شجرة حسابات الشركة
       ========================================================= */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);


    /* =========================================================
       3. التحقق من سلامة ارتباط الحسابات بالآباء
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID IS NOT NULL
          AND a.AccParentID <> 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #Acc AS p
              WHERE p.AccID = a.AccParentID
          )
    )
        THROW 50011, N'شجرة الحسابات تحتوي على حساب أب غير موجود ضمن حسابات الشركة.', 1;


    /* =========================================================
       4. التحقق من الحلقات والحسابات غير القابلة للوصول
       ========================================================= */

    DECLARE
        @Total   BIGINT,
        @Reached BIGINT;

    SELECT @Total = COUNT_BIG(*)
    FROM #Acc;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        INNER JOIN #Acc AS c
            ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT_BIG(*)
    FROM Reach
    OPTION (MAXRECURSION 32767);

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300);

        SET @CycleMsg =
            CONCAT(
                N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول. عدد الحسابات المتأثرة: ',
                @Total - @Reached
            );

        THROW 50010, @CycleMsg, 1;
    END;


    /* =========================================================
       5. حسابات القوائم المالية
          الميزانية    : AccEnd = 1 ، AccType 0 أصول / 1 خصوم / 2 حقوق ملكية
          قائمة الدخل : AccEnd = 2 ، AccType 0 إيرادات / 1 مصروفات
          DebitNature = 1 للحسابات ذات الطبيعة المدينة (أصول، مصروفات)
       ========================================================= */

    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        AccEnd,
        AccType,
        CAST
        (
            CASE
                WHEN (AccEnd = 1 AND AccType = 0)
                  OR (AccEnd = 2 AND AccType = 1)
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS DebitNature
    INTO #AccNote
    FROM #Acc
    WHERE (AccEnd = 1 AND AccType IN (0, 1, 2))
       OR (AccEnd = 2 AND AccType IN (0, 1));

    IF NOT EXISTS (SELECT 1 FROM #AccNote)
        THROW 50015, N'لا توجد حسابات مصنفة ضمن القوائم المالية للشركة المحددة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_AccNote
        ON #AccNote (AccID);

    CREATE NONCLUSTERED INDEX IX_AccNote_Parent
        ON #AccNote (AccParentID);


    /* =========================================================
       6. التحقق من تصنيف الحسابات وعلاقة الأب بالابن
       ========================================================= */

    -- أب الحساب المصنف يجب أن يكون ضمن الحسابات المصنفة.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS c
        WHERE c.AccParentID IS NOT NULL
          AND c.AccParentID <> 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #AccNote AS p
              WHERE p.AccID = c.AccParentID
          )
    )
        THROW 50014, N'يوجد حساب تابع لحساب لا ينتمي إلى تصنيف القوائم المالية.', 1;

    -- يجب أن يتطابق التصنيف (القائمة والنوع) مع تصنيف الأب.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS c
        INNER JOIN #AccNote AS p
            ON p.AccID = c.AccParentID
        WHERE c.AccEnd <> p.AccEnd
           OR c.AccType <> p.AccType
    )
        THROW 50013, N'يوجد اختلاف في تصنيف الحساب عن تصنيف الحساب الأب.', 1;

    -- لا يجوز أن يكون لحساب مصنف ابن غير مصنف.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS p
        INNER JOIN #Acc AS c
            ON c.AccParentID = p.AccID
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM #AccNote AS n
            WHERE n.AccID = c.AccID
        )
    )
        THROW 50016, N'يوجد حساب ابن غير مصنف ضمن شجرة حسابات القوائم المالية.', 1;


    /* =========================================================
       7. تحديد الأبناء الفعليين من كامل شجرة الشركة
       ========================================================= */

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
      AND c.AccParentID > 0
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);


    /* =========================================================
       8. تجميع الحركات المحاسبية (القيود المرحّلة فقط) في مسح واحد
          OpenNet  : كل ما قبل @FromDate
          PriorNet : كل ما قبل 1 يناير من السنة (للسنوات السابقة)
       ========================================================= */

    SELECT
        d.DayDAccID AS AccID,

        SUM
        (
            CASE
                WHEN m.DayMDate < @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb) - CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS OpenNet,

        SUM
        (
            CASE
                WHEN m.DayMDate < @YearStart
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb) - CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PriorNet,

        SUM
        (
            CASE
                WHEN m.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PerDeb,

        SUM
        (
            CASE
                WHEN m.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PerCrd,

        SUM
        (
            CONVERT
            (
                BIGINT,
                CASE
                    WHEN m.DayMDate >= @FromDate THEN 1
                    ELSE 0
                END
            )
        ) AS PerCnt

    INTO #Amount

    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID

    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @ToDate

    GROUP BY d.DayDAccID

    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount
        ON #Amount (AccID);


    /* =========================================================
       9. مؤشرات سلامة البيانات + الحسابات التحليلية فقط
       ========================================================= */

    DECLARE
        @ChkNonLeaf BIGINT = 0,
        @ChkOther   BIGINT = 0;

    -- حركة على حساب أب (لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT_BIG(*)
    FROM #Amount AS am
    INNER JOIN #Kid AS k
        ON k.AccID = am.AccID;

    -- حركة على حساب لا يتبع الشركة أو غير مصنف في القوائم
    SELECT @ChkOther = COUNT_BIG(*)
    FROM #Amount AS am
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #AccNote AS n
        WHERE n.AccID = am.AccID
    );

    SELECT
        am.AccID,
        n.AccEnd,
        n.AccType,
        am.OpenNet,
        am.PriorNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    INNER JOIN #AccNote AS n
        ON n.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
        ON #LeafAmt (AccID);


    /* =========================================================
       10. تجميع الأرصدة والحركات من الحسابات التحليلية إلى الآباء
       ========================================================= */

    ;WITH RollUp AS
    (
        SELECT
            l.AccID AS NodeID,
            l.OpenNet,
            l.PriorNet,
            l.PerDeb,
            l.PerCrd,
            l.PerCnt
        FROM #LeafAmt AS l

        UNION ALL

        SELECT
            p.AccID AS NodeID,
            r.OpenNet,
            r.PriorNet,
            r.PerDeb,
            r.PerCrd,
            r.PerCnt
        FROM RollUp AS r
        INNER JOIN #AccNote AS c
            ON c.AccID = r.NodeID
        INNER JOIN #AccNote AS p
            ON p.AccID = c.AccParentID
           AND c.AccParentID > 0
    )
    SELECT
        NodeID AS AccID,
        SUM(OpenNet)  AS OpenNet,
        SUM(PriorNet) AS PriorNet,
        SUM(PerDeb)   AS PerDeb,
        SUM(PerCrd)   AS PerCrd,
        SUM(PerCnt)   AS PerCnt
    INTO #RollTotals
    FROM RollUp
    GROUP BY NodeID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_RollTotals
        ON #RollTotals (AccID);


    /* =========================================================
       11. تجهيز أرصدة جميع حسابات القوائم المالية
       ========================================================= */

    SELECT
        a.AccID,
        a.AccCode,
        a.AccName,
        a.AccParentID,
        a.AccLevel,
        a.AccChid,
        a.AccEnd,
        a.AccType,
        a.DebitNature,

        CAST(ISNULL(t.OpenNet, 0)  AS DECIMAL(28,3)) AS OpenNet,
        CAST(ISNULL(t.PriorNet, 0) AS DECIMAL(28,3)) AS PriorNet,
        CAST(ISNULL(t.PerDeb, 0)   AS DECIMAL(28,3)) AS PerDeb,
        CAST(ISNULL(t.PerCrd, 0)   AS DECIMAL(28,3)) AS PerCrd,

        ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt

    INTO #Roll

    FROM #AccNote AS a
    LEFT JOIN #RollTotals AS t
        ON t.AccID = a.AccID;

    CREATE UNIQUE CLUSTERED INDEX IX_Roll
        ON #Roll (AccID);


    /* =========================================================
       12. الإجماليات ونتائج السنوات
           نتائج السنوات السابقة = - صافي قائمة الدخل قبل 1 يناير
           نتيجة السنة الحالية   = - صافي قائمة الدخل من 1 يناير حتى @ToDate
       ========================================================= */

    DECLARE
        @TotalAssets      DECIMAL(38,3),
        @TotalLiabilities DECIMAL(38,3),
        @TotalEquityAcc   DECIMAL(38,3),
        @TotalRevenue     DECIMAL(38,3),
        @TotalExpenses    DECIMAL(38,3),
        @PriorNet         DECIMAL(38,3),
        @CurOpenNet       DECIMAL(38,3),
        @CurPerDeb        DECIMAL(38,3),
        @CurPerCrd        DECIMAL(38,3),
        @CurPerCnt        BIGINT,
        @PriorResult      DECIMAL(38,3),
        @CurResult        DECIMAL(38,3),
        @TotalEquity      DECIMAL(38,3),
        @BalanceDiff      DECIMAL(38,3);

    SELECT
        @TotalAssets =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 0
                            THEN  (l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalLiabilities =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 1
                            THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalEquityAcc =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 2
                            THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalRevenue =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 AND l.AccType = 0
                            THEN -(l.OpenNet - l.PriorNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalExpenses =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 AND l.AccType = 1
                            THEN  (l.OpenNet - l.PriorNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @PriorNet =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PriorNet ELSE 0 END), 0),

        @CurOpenNet =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.OpenNet - l.PriorNet ELSE 0 END), 0),

        @CurPerDeb =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerDeb ELSE 0 END), 0),

        @CurPerCrd =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerCrd ELSE 0 END), 0),

        @CurPerCnt =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerCnt ELSE CONVERT(BIGINT, 0) END), 0)

    FROM #LeafAmt AS l;

    SET @PriorResult = -@PriorNet;
    SET @CurResult   = -(@CurOpenNet + @CurPerDeb - @CurPerCrd);
    SET @TotalEquity = @TotalEquityAcc + @PriorResult + @CurResult;
    SET @BalanceDiff = @TotalAssets - (@TotalLiabilities + @TotalEquity);


    /* =========================================================
       13. صفوف الإيضاحات
       ========================================================= */

    SELECT
        CAST
        (
            CASE
                WHEN r.AccEnd = 1 THEN r.AccType + 1
                ELSE r.AccType + 4
            END
            AS INT
        ) AS NoteNo,

        CASE
            WHEN r.AccEnd = 1 AND r.AccType = 0 THEN N'إيضاح رقم 1 - الأصول'
            WHEN r.AccEnd = 1 AND r.AccType = 1 THEN N'إيضاح رقم 2 - الالتزامات'
            WHEN r.AccEnd = 1 AND r.AccType = 2 THEN N'إيضاح رقم 3 - حقوق الملكية'
            WHEN r.AccEnd = 2 AND r.AccType = 0 THEN N'إيضاح رقم 4 - الإيرادات'
            WHEN r.AccEnd = 2 AND r.AccType = 1 THEN N'إيضاح رقم 5 - المصروفات'
        END AS NoteTitle,

        CASE
            WHEN r.AccEnd = 1 AND r.AccType = 0 THEN N'الأصول'
            WHEN r.AccEnd = 1 AND r.AccType = 1 THEN N'الخصوم'
            WHEN r.AccEnd = 1 AND r.AccType = 2 THEN N'حقوق الملكية'
            WHEN r.AccEnd = 2 AND r.AccType = 0 THEN N'الإيرادات'
            WHEN r.AccEnd = 2 AND r.AccType = 1 THEN N'المصروفات'
        END AS AccountCategory,

        r.AccID,
        r.AccCode,
        r.AccName AS AccARName,
        r.AccParentID,
        p.AccName AS AccParentName,
        r.AccLevel,
        r.AccType,

        CAST
        (
            CASE
                WHEN k.AccID IS NULL THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsAnalyticalAccount,

        -- الافتتاحي: الميزانية = كل السنوات السابقة، قائمة الدخل = السنة الحالية فقط
        CAST(x.Sgn * x.OpenAdj AS DECIMAL(28,3)) AS OpeningBalance,

        r.PerDeb AS PeriodDebit,
        r.PerCrd AS PeriodCredit,

        CAST(x.Sgn * (x.OpenAdj + r.PerDeb - r.PerCrd) AS DECIMAL(28,3)) AS ClosingBalance,

        r.PerCnt AS MovementCount,

        @FromDate AS FromDate,
        @ToDate AS ToDate,
        @Year AS FinancialYear,
        @Cmp AS CompanyID,

        @TotalAssets AS TotalAssets,
        @TotalLiabilities AS TotalLiabilities,
        @TotalEquity AS TotalEquity,
        @BalanceDiff AS BalanceDifference,

        CAST(0 AS BIT) AS IsResultRow,
        @TotalRevenue AS TotalRevenue,
        @TotalExpenses AS TotalExpenses,
        @CurResult AS NetIncome,
        @PriorResult AS PriorYearsResult,
        @CurResult AS CurrentYearResult,

        @ChkNonLeaf AS ChkNonLeafAccounts,
        @ChkOther AS ChkOtherAccounts

    INTO #Notes

    FROM #Roll AS r
    CROSS APPLY
    (
        SELECT
            CASE WHEN r.DebitNature = 1 THEN CAST(1 AS INT) ELSE CAST(-1 AS INT) END AS Sgn,
            r.OpenNet - CASE WHEN r.AccEnd = 2 THEN r.PriorNet ELSE CAST(0 AS DECIMAL(28,3)) END AS OpenAdj
    ) AS x
    LEFT JOIN #AccNote AS p
        ON p.AccID = r.AccParentID
    LEFT JOIN #Kid AS k
        ON k.AccID = r.AccID;

    ALTER TABLE #Notes ALTER COLUMN AccCode   NVARCHAR(200) NULL;
    ALTER TABLE #Notes ALTER COLUMN AccARName NVARCHAR(400) NULL;


    /* =========================================================
       14. صفّا نتائج السنوات ضمن إيضاح حقوق الملكية (إيضاح 3)
           قيم الحقول بطبيعة دائنة (الدائن موجب)
       ========================================================= */

    INSERT INTO #Notes
    (
        NoteNo, NoteTitle, AccountCategory,
        AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccType, IsAnalyticalAccount,
        OpeningBalance, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
        FromDate, ToDate, FinancialYear, CompanyID,
        TotalAssets, TotalLiabilities, TotalEquity, BalanceDifference,
        IsResultRow, TotalRevenue, TotalExpenses, NetIncome, PriorYearsResult, CurrentYearResult,
        ChkNonLeafAccounts, ChkOtherAccounts
    )
    VALUES
    (
        3, N'إيضاح رقم 3 - حقوق الملكية', N'حقوق الملكية',
        -1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', NULL, NULL, 1, 2, 1,
        @PriorResult, 0, 0, @PriorResult, 0,
        @FromDate, @ToDate, @Year, @Cmp,
        @TotalAssets, @TotalLiabilities, @TotalEquity, @BalanceDiff,
        1, @TotalRevenue, @TotalExpenses, @CurResult, @PriorResult, @CurResult,
        @ChkNonLeaf, @ChkOther
    ),
    (
        3, N'إيضاح رقم 3 - حقوق الملكية', N'حقوق الملكية',
        -2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', NULL, NULL, 1, 2, 1,
        -@CurOpenNet, @CurPerDeb, @CurPerCrd, @CurResult, @CurPerCnt,
        @FromDate, @ToDate, @Year, @Cmp,
        @TotalAssets, @TotalLiabilities, @TotalEquity, @BalanceDiff,
        1, @TotalRevenue, @TotalExpenses, @CurResult, @PriorResult, @CurResult,
        @ChkNonLeaf, @ChkOther
    );


    /* =========================================================
       15. إخراج الإيضاحات
       ========================================================= */

    SELECT
        NoteNo,
        NoteTitle,
        AccountCategory,

        AccID,
        AccCode,
        AccARName,
        AccParentID,
        AccParentName,
        AccLevel,
        AccType,
        IsAnalyticalAccount,

        OpeningBalance,
        PeriodDebit,
        PeriodCredit,
        ClosingBalance,
        MovementCount,

        FromDate,
        ToDate,
        FinancialYear,
        CompanyID,

        TotalAssets,
        TotalLiabilities,
        TotalEquity,
        BalanceDifference,

        IsResultRow,
        TotalRevenue,
        TotalExpenses,
        NetIncome,
        PriorYearsResult,
        CurrentYearResult,

        ChkNonLeafAccounts,
        ChkOtherAccounts

    FROM #Notes

    WHERE
        (
            IsResultRow = 1
            OR
            (
                (@AllAcc = 0 OR IsAnalyticalAccount = 1)

                AND
                (
                    @LevelAcc = 0
                    OR AccLevel = @LevelAcc
                    OR (AccLevel < @LevelAcc AND IsAnalyticalAccount = 1)
                )
            )
        )

        AND
        (
            @MoveAcc = 0
            OR MovementCount > 0
        )

        AND
        (
            @BalnceAcc = 0
            OR ClosingBalance <> 0
        )

    ORDER BY
        NoteNo,
        IsResultRow,
        AccCode,
        AccID;

END;

GO

/* ---- Acc_SelectAccIncomeStatement (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccIncomeStatement]
@FromDate  DATE
= NULL,
@ToDate
DATE
= NULL,
@Cmp
INT
= 1,
@Year
INT
= 0,
@AllAcc
BIT
= 0,
@MoveAcc   BIT
= 0,
@LevelAcc  TINYINT  = 0  AS  BEGIN
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #RollTotals;
DROP TABLE IF EXISTS #LeafAmount;
DROP TABLE IF EXISTS #Amount;
DROP TABLE IF EXISTS #Kid;
DROP TABLE IF EXISTS #CompanyKid;
DROP TABLE IF EXISTS #Account;
DROP TABLE IF EXISTS #CompanyAcc;
/* =====================================================
1. التحقق من المدخلات والفترة
===================================================== */
IF @FromDate IS NULL
OR @ToDate IS NULL
OR @FromDate > @ToDate
THROW 52001, N'فترة قائمة الدخل غير صحيحة.', 1;
IF @Cmp IS NULL OR @Cmp <= 0
THROW 52002, N'الشركة المحددة غير صحيحة.', 1;
IF NOT EXISTS
(
SELECT 1
FROM dbo.Mng_Company
WHERE CmpID = @Cmp
)
THROW 52003, N'الشركة المحددة غير موجودة.', 1;
SET @Year = ISNULL(@Year, 0);
IF @Year = 0
SET @Year = YEAR(@FromDate);
IF YEAR(@FromDate) <> @Year
OR YEAR(@ToDate) <> @Year
THROW 52004, N'يجب أن يقع تاريخا التقرير ضمن السنة المالية نفسها.', 1;
SET @AllAcc   = ISNULL(@AllAcc, 0);
SET @MoveAcc  = ISNULL(@MoveAcc, 0);
SET @LevelAcc = ISNULL(@LevelAcc, 0);
/* =====================================================
2. تحميل جميع حسابات الشركة
نحتاج الشجرة الكاملة لتحديد الأبناء الفعليين،
وعدم اعتبار الحساب تحليليًا لمجرد عدم وجود أبنائه
ضمن تصنيف قائمة الدخل فقط.
===================================================== */
SELECT
a.AccID,
a.AccEnd,
a.AccType,
a.AccParentID,
a.AccLevel,
CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
ISNULL(a.AccCode, N'') AS AccCode,
ISNULL(a.AccName, N'') AS AccName
INTO #CompanyAcc
FROM dbo.Acc_Account AS a
WHERE a.AccCompany = @Cmp;
IF NOT EXISTS (SELECT 1 FROM #CompanyAcc)
THROW 52005, N'لا توجد حسابات لهذه الشركة.', 1;
CREATE UNIQUE CLUSTERED INDEX IX_CompanyAcc
ON #CompanyAcc (AccID);
CREATE NONCLUSTERED INDEX IX_CompanyAcc_Parent
ON #CompanyAcc (AccParentID);
/* =====================================================
3. تحميل حسابات قائمة الدخل
AccEnd = 2
AccType = 0 الإيرادات
AccType = 1 المصروفات
===================================================== */
SELECT
a.AccID,
a.AccEnd,
a.AccType,
a.AccParentID,
a.AccCode,
a.AccName,
a.AccLevel,
a.AccChid
INTO #Account
FROM #CompanyAcc AS a
WHERE a.AccEnd = 2
AND a.AccType IN (0, 1);
IF NOT EXISTS (SELECT 1 FROM #Account)
THROW 52006, N'لا توجد حسابات قائمة دخل للشركة المحددة.', 1;
CREATE UNIQUE CLUSTERED INDEX IX_IncomeAccount
ON #Account (AccID);
CREATE NONCLUSTERED INDEX IX_IncomeAccount_Parent
ON #Account (AccParentID)
INCLUDE (AccType, AccLevel, AccChid);
/* =====================================================
4. فحوص سلامة شجرة الحسابات
===================================================== */
/* الحسابات اليتيمة */
IF EXISTS
(
SELECT 1
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
)
)
THROW 52007, N'شجرة الحسابات تحتوي على حسابات يتيمة؛ الحساب الأب غير موجود.', 1;
/* الربط بين حسابات شركتين مختلفتين */
IF EXISTS
(
SELECT 1
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS p
WHERE p.AccID = a.AccParentID
)
AND EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
)
)
THROW 52008, N'شجرة الحسابات تحتوي على ربط بين حسابات شركتين مختلفتين.', 1;
/* يجب أن يكون الأب والابن من التصنيف نفسه في قائمة الدخل */
IF EXISTS
(
SELECT 1
FROM #CompanyAcc AS child
INNER JOIN #CompanyAcc AS parent
ON parent.AccID = child.AccParentID
WHERE parent.AccEnd = 2
AND
(
child.AccEnd <> 2
OR child.AccType <> parent.AccType
)
)
THROW 52009, N'يوجد اختلاف في تصنيف حساب أب وأحد حساباته الفرعية ضمن قائمة الدخل.', 1;
/* التحقق من الوصول إلى جذور الشجرة */
DECLARE
@ReachCount BIGINT,
@AccountCount BIGINT;
SELECT @AccountCount = COUNT_BIG(*)
FROM #CompanyAcc;
;WITH AccountReach AS
(
SELECT a.AccID
FROM #CompanyAcc AS a
WHERE a.AccParentID IS NULL
OR a.AccParentID = 0
UNION ALL
SELECT child.AccID
FROM #CompanyAcc AS child
INNER JOIN AccountReach AS parent
ON child.AccParentID = parent.AccID
)
SELECT @ReachCount = COUNT_BIG(*)
FROM AccountReach
OPTION (MAXRECURSION 32767);
IF ISNULL(@ReachCount, 0) <> @AccountCount
THROW 52010, N'توجد دورة أو حسابات غير مرتبطة بجذر شجرة الحسابات.', 1;
/* =====================================================
5. تحديد الأبناء الفعليين على مستوى الشركة
===================================================== */
SELECT
c.AccParentID AS AccID,
COUNT_BIG(*) AS ChildCount
INTO #CompanyKid
FROM #CompanyAcc AS c
WHERE c.AccParentID IS NOT NULL
AND c.AccParentID <> 0
GROUP BY c.AccParentID;
CREATE UNIQUE CLUSTERED INDEX IX_CompanyKid
ON #CompanyKid (AccID);
/* الأبناء الفعليون لحسابات قائمة الدخل */
SELECT
k.AccID,
k.ChildCount
INTO #Kid
FROM #CompanyKid AS k
INNER JOIN #Account AS a
ON a.AccID = k.AccID;
CREATE UNIQUE CLUSTERED INDEX IX_IncomeKid
ON #Kid (AccID);
/* =====================================================
6. تجميع الحركات المؤرشفة خلال الفترة
الإيرادات = الدائن - المدين
المصروفات = المدين - الدائن
لا يتم احتساب أرصدة سابقة في قائمة الدخل.
===================================================== */
SELECT
d.DayDAccID AS AccID,
SUM(d.DayDDeb) AS PeriodDebit,
SUM(d.DayDCrd) AS PeriodCredit,
COUNT_BIG(*) AS MovementCount
INTO #Amount
FROM dbo.Acc_DayMaster AS m
INNER JOIN dbo.Acc_DayDetails AS d
ON d.DayDMID = m.DayMID
WHERE m.DayMCompany = @Cmp
AND m.DayMState = 7
AND m.DayMDate >= @FromDate
AND m.DayMDate <= @ToDate
GROUP BY
d.DayDAccID
OPTION (RECOMPILE);
CREATE UNIQUE CLUSTERED INDEX IX_IncomeAmount
ON #Amount (AccID);
/* =====================================================
7. مؤشرات سلامة البيانات
===================================================== */
DECLARE
@ChkNonLeaf BIGINT = 0,
@ChkOrphan  BIGINT = 0,
@ChkCrossCo BIGINT = 0,
@ChkForeign BIGINT = 0,
@ChkChid
BIGINT = 0;
/* حركات مسجلة على حسابات رئيسية في قائمة الدخل */
SELECT
@ChkNonLeaf = COUNT_BIG(*)
FROM #Amount AS am
INNER JOIN #Account AS a
ON a.AccID = am.AccID
INNER JOIN #Kid AS k
ON k.AccID = am.AccID;
/* الحسابات اليتيمة */
SELECT
@ChkOrphan = COUNT_BIG(*)
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS p
WHERE p.AccID = a.AccParentID
)
AND NOT EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
);
/* الآباء التابعون لشركات أخرى */
SELECT
@ChkCrossCo = COUNT_BIG(*)
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS p
WHERE p.AccID = a.AccParentID
)
AND EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
);
/* حركات على حسابات خارج حسابات الشركة */
SELECT
@ChkForeign = COUNT_BIG(*)
FROM #Amount AS am
WHERE NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS a
WHERE a.AccID = am.AccID
);
/* عدم تطابق AccChid مع الأبناء الفعليين */
SELECT
@ChkChid = COUNT_BIG(*)
FROM #CompanyAcc AS a
LEFT JOIN #CompanyKid AS k
ON k.AccID = a.AccID
WHERE
(CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
<>
(CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);
/* =====================================================
8. حركات الحسابات التحليلية فقط
الحساب التحليلي يحدد من عدم وجود أبناء فعليين،
وليس من قيمة AccChid وحدها.
===================================================== */
SELECT
a.AccID,
a.AccType,
CAST
(
CASE
WHEN a.AccType = 0
THEN ISNULL(am.PeriodCredit, 0)
- ISNULL(am.PeriodDebit, 0)
ELSE 0
END
AS DECIMAL(38,3)
) AS RevenueAmount,
CAST
(
CASE
WHEN a.AccType = 1
THEN ISNULL(am.PeriodDebit, 0)
- ISNULL(am.PeriodCredit, 0)
ELSE 0
END
AS DECIMAL(38,3)
) AS ExpenseAmount,
ISNULL(am.PeriodDebit, 0) AS PeriodDebit,
ISNULL(am.PeriodCredit, 0) AS PeriodCredit,
ISNULL(am.MovementCount, CONVERT(BIGINT, 0)) AS MovementCount
INTO #LeafAmount
FROM #Account AS a
LEFT JOIN #Kid AS k
ON k.AccID = a.AccID
LEFT JOIN #Amount AS am
ON am.AccID = a.AccID
WHERE k.AccID IS NULL;
CREATE UNIQUE CLUSTERED INDEX IX_IncomeLeafAmount
ON #LeafAmount (AccID);
/* =====================================================
9. التجميع التصاعدي من الحسابات التحليلية إلى الآباء
===================================================== */
;WITH RollUp AS
(
/* الحسابات التحليلية */
SELECT
l.AccID AS NodeID,
l.RevenueAmount,
l.ExpenseAmount,
l.PeriodDebit,
l.PeriodCredit,
l.MovementCount
FROM #LeafAmount AS l
UNION ALL
/* نقل الحركة إلى الأب ثم الأجداد */
SELECT
parent.AccID AS NodeID,
r.RevenueAmount,
r.ExpenseAmount,
r.PeriodDebit,
r.PeriodCredit,
r.MovementCount
FROM RollUp AS r
INNER JOIN #Account AS currentNode
ON currentNode.AccID = r.NodeID
INNER JOIN #Account AS parent
ON parent.AccID = currentNode.AccParentID
)
SELECT
r.NodeID,
SUM(r.RevenueAmount) AS RevenueAmount,
SUM(r.ExpenseAmount) AS ExpenseAmount,
SUM(r.PeriodDebit) AS PeriodDebit,
SUM(r.PeriodCredit) AS PeriodCredit,
SUM(r.MovementCount) AS MovementCount
INTO #RollTotals
FROM RollUp AS r
GROUP BY
r.NodeID
OPTION (MAXRECURSION 32767, RECOMPILE);
CREATE UNIQUE CLUSTERED INDEX IX_IncomeRollTotals
ON #RollTotals (NodeID);
/* =====================================================
10. إجماليات قائمة الدخل
تحسب من الحسابات التحليلية فقط.
===================================================== */
DECLARE
@TotalRevenue  DECIMAL(38,3),
@TotalExpenses DECIMAL(38,3),
@NetProfitLoss DECIMAL(38,3);
SELECT
@TotalRevenue =
COALESCE
(
SUM(l.RevenueAmount),
CONVERT(DECIMAL(38,3), 0)
),
@TotalExpenses =
COALESCE
(
SUM(l.ExpenseAmount),
CONVERT(DECIMAL(38,3), 0)
)
FROM #LeafAmount AS l;
SET @NetProfitLoss = @TotalRevenue - @TotalExpenses;
/* =====================================================
11. النتيجة النهائية
===================================================== */
SELECT
a.AccID,
a.AccCode,
a.AccName AS AccARName,
a.AccEnd,
a.AccType,
CASE
WHEN a.AccType = 0 THEN N'إيرادات'
WHEN a.AccType = 1 THEN N'مصروفات'
END AS AccountCategory,
a.AccLevel,
a.AccParentID AS AccParint,
p.AccName AS AccParintName,
a.AccChid AS AccCountChid,
CASE
WHEN a.AccType = 0
THEN ISNULL(r.RevenueAmount, 0)
ELSE CONVERT(DECIMAL(38,3), 0)
END AS RevenueAmount,
CASE
WHEN a.AccType = 1
THEN ISNULL(r.ExpenseAmount, 0)
ELSE CONVERT(DECIMAL(38,3), 0)
END AS ExpenseAmount,
CASE
WHEN a.AccType = 0
THEN ISNULL(r.RevenueAmount, 0)
ELSE ISNULL(r.ExpenseAmount, 0)
END AS PeriodAmount,
ISNULL(r.PeriodDebit, 0) AS PeriodDebit,
ISNULL(r.PeriodCredit, 0) AS PeriodCredit,
ISNULL(r.MovementCount, 0) AS MovementCount,
@TotalRevenue AS TotalRevenue,
@TotalExpenses AS TotalExpenses,
@NetProfitLoss AS NetProfitLoss,
CASE
WHEN @NetProfitLoss > 0 THEN N'صافي ربح'
WHEN @NetProfitLoss < 0 THEN N'صافي خسارة'
ELSE N'تعادل'
END AS ProfitLossStatus,
/* مؤشرات سلامة البيانات */
@ChkNonLeaf AS ChkNonLeafAccounts,
@ChkOrphan AS ChkOrphanAccounts,
@ChkCrossCo AS ChkCrossCompanyParents,
@ChkForeign AS ChkForeignAccounts,
@ChkChid AS ChkChidMismatch
FROM #Account AS a
LEFT JOIN #Account AS p
ON p.AccID = a.AccParentID
LEFT JOIN #Kid AS k
ON k.AccID = a.AccID
LEFT JOIN #RollTotals AS r
ON r.NodeID = a.AccID
WHERE
/* عرض جميع الحسابات أو التحليلية فقط */
(
@AllAcc = 0
OR k.AccID IS NULL
)
/* الحسابات التي لها حركة فعلية خلال الفترة */
AND
(
@MoveAcc = 0
OR ISNULL(r.MovementCount, 0) > 0
)
/* المستوى المطلوب مع إظهار الحساب التحليلي النهائي */
AND
(
@LevelAcc = 0
OR a.AccLevel = @LevelAcc
OR
(
a.AccLevel < @LevelAcc
AND k.AccID IS NULL
)
)
ORDER BY
a.AccCode,
a.AccID
OPTION (RECOMPILE);
END;

GO

/* ---- Acc_SelectAccountAnalysis (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ---------- Acc_SelectAccountAnalysis ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountAnalysis]
    @Cmp       INT,
    @UserID    INT      = 0,   -- لا يؤثر على النتيجة (للترويسة فقط)
    @Year      INT,
    @AccId     BIGINT   = 0,   -- الحساب الأب (0 = من الجذور)
    @FromDate  DATE,
    @ToDate    DATE,
    @AllAcc    BIT      = 0,   -- 1 = الحسابات التحليلية فقط ، 0 = الكل (آباء وتحليلية)
    @AllLevel  BIT      = 0,   -- 1 = كل المستويات (أبناء وأحفاد) ، 0 = الأبناء المباشرون فقط
    @MoveAcc   BIT      = 0,   -- 1 = الحسابات التي لها حركة خلال الفترة فقط
    @BalnceAcc BIT      = 1,   -- 1 = الحسابات التي رصيد نهاية مدتها <> 0 أو لها حركة خلال الفترة
    @LevelAcc  TINYINT  = 0,   -- 0 = بلا فلتر ؛ المستوى المطلق AccLevel (+ التحليلي الأقل مستوى)
    @Debit     BIT      = 0,   -- 1 = رصيد نهاية المدة مدين فقط
    @Credit    BIT      = 0,   -- 1 = رصيد نهاية المدة دائن فقط
    @CsCID     BIGINT   = 0    -- مركز التكلفة (أب/جد/ابن) ؛ 0 = بلا فلتر
AS
BEGIN
    SET NOCOUNT ON;
    DROP TABLE IF EXISTS #Node;
    DROP TABLE IF EXISTS #Cl;
    DROP TABLE IF EXISTS #Amt;
    DROP TABLE IF EXISTS #R;

    /* ---------- التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @AccId = ISNULL(@AccId, 0);
    SET @CsCID = ISNULL(@CsCID, 0);

    IF @AccId > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccId AND AccCompany = @Cmp)
        THROW 50005, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

    /* ---------- مركز التكلفة وفروعه ---------- */
    DECLARE @CC TABLE (CsCID BIGINT NOT NULL PRIMARY KEY);

    IF @CsCID > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
            THROW 50007, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

        ;WITH CcTree AS
        (
            SELECT CsCID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_CostCenter
            WHERE CsCID = @CsCID AND CsCCompany = @Cmp

            UNION ALL

            SELECT c.CsCID, p.Lvl + 1
            FROM dbo.Acc_CostCenter AS c
            JOIN CcTree AS p ON c.CsCParentID = p.CsCID
            WHERE c.CsCCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @CC (CsCID) SELECT CsCID FROM CcTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- شجرة الحسابات تحت الحساب المطلوب (Depth 1 = الأبناء المباشرون) ---------- */
    ;WITH AccTree AS
    (
        SELECT a.AccID, a.AccParentID, a.AccLevel, a.AccCode, a.AccName, CAST(1 AS INT) AS Depth
        FROM dbo.Acc_Account AS a
        WHERE a.AccCompany = @Cmp
          AND a.AccID <> ISNULL(a.AccParentID, 0)
          AND (   (@AccId > 0 AND a.AccParentID = @AccId)
               OR (@AccId = 0 AND (a.AccParentID IS NULL OR a.AccParentID = 0)))

        UNION ALL

        SELECT a.AccID, a.AccParentID, a.AccLevel, a.AccCode, a.AccName, p.Depth + 1
        FROM dbo.Acc_Account AS a
        JOIN AccTree AS p ON a.AccParentID = p.AccID
        WHERE a.AccCompany = @Cmp AND p.Depth < 30
    )
    SELECT AccID, AccParentID, AccLevel, AccCode, AccName, Depth
    INTO #Node
    FROM AccTree
    OPTION (MAXRECURSION 100);
    CREATE UNIQUE CLUSTERED INDEX IX_Node ON #Node (AccID);

    /* ---------- (الحساب ← كل أحفاده بما فيهم نفسه) لتجميع الأرصدة نحو الآباء ---------- */
    ;WITH Cl AS
    (
        SELECT n.AccID AS NodeID, n.AccID AS DescID
        FROM #Node AS n

        UNION ALL

        SELECT c.NodeID, k.AccID
        FROM Cl AS c
        JOIN #Node AS k ON k.AccParentID = c.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 100);

    CREATE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- حركة كل حساب: مرة واحدة على الجداول الكبيرة ---------- */
    SELECT d.DayDAccID AS AccID,
           SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)                      AS PerCnt
    INTO #Amt
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    JOIN #Node              AS n ON n.AccID  = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate   <= @ToDate
      AND (@CsCID = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
    GROUP BY d.DayDAccID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amt ON #Amt (AccID);

    /* ---------- ملخص الترويسة: رصيد الحساب المطلوب نفسه (يتجاهل فلاتر العرض) ---------- */
    DECLARE @HOpen DECIMAL(18,3), @HPerDeb DECIMAL(18,3), @HPerCrd DECIMAL(18,3);

    SELECT @HOpen   = CAST(ISNULL(SUM(OpenNet), 0) AS DECIMAL(18,3)),
           @HPerDeb = CAST(ISNULL(SUM(PerDeb ), 0) AS DECIMAL(18,3)),
           @HPerCrd = CAST(ISNULL(SUM(PerCrd ), 0) AS DECIMAL(18,3))
    FROM #Amt;

    DECLARE @HPerNet DECIMAL(18,3) = @HPerDeb - @HPerCrd;
    DECLARE @HClose  DECIMAL(18,3) = @HOpen + @HPerNet;

    /* ---------- تجميع كل حساب مع أحفاده ---------- */
    SELECT n.AccID, n.AccParentID, n.AccLevel, n.AccCode, n.AccName, n.Depth,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM #Node AS k WHERE k.AccParentID = n.AccID) THEN 0 ELSE 1 END AS BIT) AS IsLeaf,
           CAST(ISNULL(SUM(a.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(a.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(a.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(a.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #R
    FROM #Node AS n
    JOIN #Cl   AS c ON c.NodeID = n.AccID
    LEFT JOIN #Amt AS a ON a.AccID = c.DescID
    GROUP BY n.AccID, n.AccParentID, n.AccLevel, n.AccCode, n.AccName, n.Depth;

    /* ---------- للاستخدام برأس التقرير بالطباعة ---------- */
    DECLARE @AccCode NVARCHAR(60), @AccName NVARCHAR(500);

    SELECT @AccName = AccName, @AccCode = AccCode FROM dbo.Acc_Account WHERE AccID = @AccId;

    DECLARE @ReportTital NVARCHAR(500) =
          ISNULL(@AccName, N'') + N' ' + ISNULL(@AccCode, N'')
        + N' من تاريخ ' + CONVERT(NVARCHAR(10), @FromDate, 105)
        + N' إلى تاريخ ' + CONVERT(NVARCHAR(10), @ToDate, 105);

    IF (@Debit  = 1) SET @ReportTital = @ReportTital + N' الأرصدة المدينة فقط';
    IF (@Credit = 1) SET @ReportTital = @ReportTital + N' الأرصدة الدائنة فقط';
    IF (@CsCID  > 0) SET @ReportTital = @ReportTital
        + ISNULL((SELECT N' لمركز التكلفة ' + CsCName FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID), N'');

    /* ---------- النتيجة ---------- */
    SELECT x.AccID, x.AccCode, x.AccName, x.AccLevel, x.AccParentID,
           pa.AccName AS AccParentName,
           x.IsLeaf,

           -- رصيد أول المدة
           CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
           CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
           -- الحركة بالمجاميع
           x.PerDeb AS NewDebit,
           x.PerCrd AS NewCredit,
           -- الحركة بالأرصدة
           CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END AS BalanceDebit,
           CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
           -- رصيد آخر المدة
           CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotDebit,
           CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotCredit,

           -- ملخص الترويسة (يتكرر على كل صف)
           CASE WHEN @HOpen   > 0 THEN  @HOpen   ELSE 0 END AS SumBlcOldDebit,
           CASE WHEN @HOpen   < 0 THEN -@HOpen   ELSE 0 END AS SumBlcOldCredit,
           @HPerDeb AS SumTotDebit,
           @HPerCrd AS SumTotCredit,
           CASE WHEN @HPerNet > 0 THEN  @HPerNet ELSE 0 END AS SumBlcDebit,
           CASE WHEN @HPerNet < 0 THEN -@HPerNet ELSE 0 END AS SumBlcCredit,
           CASE WHEN @HClose  > 0 THEN  @HClose  ELSE 0 END AS SumTotBlcDebit,
           CASE WHEN @HClose  < 0 THEN -@HClose  ELSE 0 END AS SumTotBlcCredit,
           @ReportTital AS ReportTital
    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #R AS r
    ) AS x
    LEFT JOIN dbo.Acc_Account AS pa ON pa.AccID = x.AccParentID
    WHERE
          /* الحسابات التحليلية فقط (أو الحسابات التي في المستوى المطلوب) */
          (@AllAcc = 0 OR x.IsLeaf = 1
              OR (@LevelAcc > 0 AND x.AccLevel = @LevelAcc))

      AND (@AllLevel = 1 OR @LevelAcc > 0 OR x.Depth = 1)

      /* ====== التصحيح 1: المقارنة بالمستوى المطلق AccLevel بدل Depth ====== */
      AND (@LevelAcc = 0
           OR x.AccLevel = @LevelAcc
           OR (x.AccLevel < @LevelAcc AND x.IsLeaf = 1))
      /* ==================================================================== */

      AND (@MoveAcc   = 0 OR x.PerCnt   > 0)

      /* ====== التصحيح 2: لا نُخفي الحساب الذي له حركة بالفترة ولو رصيده صفر ====== */
      AND (@BalnceAcc = 0 OR x.CloseNet <> 0 OR x.PerCnt > 0)
      /* ======================================================================== */

      AND (@Debit     = 0 OR x.CloseNet > 0)
      AND (@Credit    = 0 OR x.CloseNet < 0)
    ORDER BY x.AccCode, x.AccLevel;
END;
GO

/* ---- Acc_SelectCashFlow (3 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =====================================================================
   قائمة التدفقات النقدية (الطريقة المباشرة) — IAS 7
   ---------------------------------------------------------------------
   Acc_CashFlowAccounts.CashFlowType:
       1 = النقدية وما يعادلها
       2 = أنشطة تشغيلية   3 = أنشطة استثمارية   4 = أنشطة تمويلية
   يُورَّث التصنيف من أقرب حساب أعلى مصنَّف (الأقرب يغلب).

   المبدأ:
   - لكل قيد مرحّل (DayMState = 7) يمس حسابات النقدية في الفترة، صافي حركة
     النقدية = صافي بنوده المقابلة (إن كان القيد متوازنًا).
   - داخل القيد الواحد تُجمَّع البنود المقابلة حسب نوع النشاط (2/3/4)،
     فيصبح لكل نشاط صافٍ واحد: موجب = متحصلات، سالب = مدفوعات.
     بهذا لا يُستثنى قيد صحيح لمجرد أن بنوده المقابلة باتجاهين.
   - الاستثناء فقط لخلل حقيقي: لا بنود مقابلة، أو حساب مقابل غير مصنف،
     أو صافي البنود لا يطابق صافي النقدية (قيد غير متوازن).
   - التسوية مضمونة: الافتتاحي + (تشغيلي + استثماري + تمويلي) + المستثنى = الختامي،
     وفرق التسوية يجب أن يكون صفرًا دائمًا.
   - حركة النقدية بين حسابات نقدية (صافيها صفر) لا تُعد تدفقًا.
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCashFlow]
(
    @CompanyID INT,
    @DateFrom  DATE,
    @DateTo    DATE
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CompanyID IS NULL OR @CompanyID <= 0
        THROW 50001, N'يجب تحديد الشركة بصورة صحيحة.', 1;

    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo
        THROW 50002, N'نطاق التاريخ غير صحيح.', 1;

    DROP TABLE IF EXISTS #EntryFlow;
    DROP TABLE IF EXISTS #Exceptions;
    DROP TABLE IF EXISTS #JournalCheck;
    DROP TABLE IF EXISTS #CounterLines;
    DROP TABLE IF EXISTS #CashJournal;
    DROP TABLE IF EXISTS #AccountClass;

    /*==============================================================
      1. تصنيف الحسابات وتوريث أقرب تصنيف من الحسابات الأعلى
    ==============================================================*/

    ;WITH AccountAncestors AS
    (
        SELECT
            A.AccID AS LeafAccID,
            A.AccID AS AncestorAccID,
            CAST(0 AS INT) AS Distance,
            CAST('/' + CONVERT(VARCHAR(30), A.AccID) + '/' AS VARCHAR(MAX)) AS VisitedPath
        FROM dbo.Acc_Account A
        WHERE A.AccCompany = @CompanyID

        UNION ALL

        SELECT
            H.LeafAccID,
            P.AccParentID,
            H.Distance + 1,
            CAST(H.VisitedPath + CONVERT(VARCHAR(30), P.AccParentID) + '/' AS VARCHAR(MAX))
        FROM AccountAncestors H
        INNER JOIN dbo.Acc_Account P
            ON P.AccID = H.AncestorAccID
           AND P.AccCompany = @CompanyID
        WHERE P.AccParentID IS NOT NULL
          AND CHARINDEX('/' + CONVERT(VARCHAR(30), P.AccParentID) + '/', H.VisitedPath) = 0
    ),
    RankedClassification AS
    (
        SELECT
            H.LeafAccID,
            C.CashFlowType,
            ROW_NUMBER() OVER (PARTITION BY H.LeafAccID ORDER BY H.Distance ASC) AS RN
        FROM AccountAncestors H
        INNER JOIN dbo.Acc_CashFlowAccounts C
            ON C.AccID = H.AncestorAccID
    )
    SELECT
        A.AccID,
        R.CashFlowType
    INTO #AccountClass
    FROM dbo.Acc_Account A
    LEFT JOIN RankedClassification R
        ON R.LeafAccID = A.AccID
       AND R.RN = 1
    WHERE A.AccCompany = @CompanyID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_AccountClass
        ON #AccountClass (AccID);

    -- حسابات النقدية يجب أن تكون حسابات ميزانية من نوع أصول
    IF EXISTS
    (
        SELECT 1
        FROM #AccountClass C
        INNER JOIN dbo.Acc_Account A
            ON A.AccID = C.AccID
        WHERE C.CashFlowType = 1
          AND (A.AccEnd <> 1 OR A.AccType <> 0)
    )
        THROW 50020, N'تصنيف النقدية (1) مطبق على حساب ليس من أصول الميزانية العمومية.', 1;


    /*==============================================================
      2. قيود الفترة التي تمس النقدية وصافي حركة النقدية لكل قيد
         (القيود التي صافي نقديتها صفر، كالتحويل بين الصناديق، لا تُعد تدفقًا)
    ==============================================================*/

    SELECT
        D.DayDMID,
        CAST(SUM(D.DayDDeb) AS DECIMAL(19,3)) AS CashDebit,
        CAST(SUM(D.DayDCrd) AS DECIMAL(19,3)) AS CashCredit,
        CAST(SUM(D.DayDDeb - D.DayDCrd) AS DECIMAL(19,3)) AS CashNet
    INTO #CashJournal
    FROM dbo.Acc_DayMaster M
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = M.DayMID
    INNER JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
       AND A.CashFlowType = 1
    WHERE M.DayMCompany = @CompanyID
      AND M.DayMState = 7
      AND M.DayMDate >= @DateFrom
      AND M.DayMDate <= @DateTo
    GROUP BY D.DayDMID
    HAVING SUM(D.DayDDeb - D.DayDCrd) <> 0;

    CREATE UNIQUE CLUSTERED INDEX IX_CashJournal
        ON #CashJournal (DayDMID);


    /*==============================================================
      3. البنود المقابلة (غير النقدية) في هذه القيود فقط
         FlowAmount: موجب = تدفق داخل، سالب = تدفق خارج
         CashFlowType = NULL يعني حسابًا غير مصنف
    ==============================================================*/

    SELECT
        D.DayDMID,
        D.DayDID,
        A.CashFlowType,
        CAST(D.DayDCrd - D.DayDDeb AS DECIMAL(19,3)) AS FlowAmount
    INTO #CounterLines
    FROM #CashJournal CJ
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = CJ.DayDMID
    LEFT JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
    WHERE ISNULL(A.CashFlowType, 0) <> 1;

    CREATE INDEX IX_CounterLines_Journal
        ON #CounterLines (DayDMID);


    /*==============================================================
      4. فحص كل قيد
    ==============================================================*/

    SELECT
        CJ.DayDMID,
        CJ.CashNet,
        COUNT(CL.DayDID) AS CounterLineCount,
        SUM(CASE WHEN CL.DayDID IS NOT NULL AND CL.CashFlowType IS NULL THEN 1 ELSE 0 END) AS UnclassifiedCount,
        CAST(ISNULL(SUM(CASE WHEN CL.CashFlowType BETWEEN 2 AND 4 THEN CL.FlowAmount END), 0)
             AS DECIMAL(19,3)) AS ClassifiedNet
    INTO #JournalCheck
    FROM #CashJournal CJ
    LEFT JOIN #CounterLines CL
        ON CL.DayDMID = CJ.DayDMID
    GROUP BY CJ.DayDMID, CJ.CashNet;

    CREATE UNIQUE CLUSTERED INDEX IX_JournalCheck
        ON #JournalCheck (DayDMID);


    /*==============================================================
      5. القيود المستثناة وأسبابها
    ==============================================================*/

    SELECT
        X.DayDMID,
        X.ExceptionReason
    INTO #Exceptions
    FROM
    (
        SELECT
            JC.DayDMID,
            CASE
                WHEN JC.CounterLineCount = 0
                    THEN N'لا توجد بنود مقابلة لحركة النقدية'
                WHEN JC.UnclassifiedCount > 0
                    THEN N'يوجد حساب مقابل غير مصنف في قائمة التدفقات'
                WHEN ABS(JC.ClassifiedNet - JC.CashNet) > 0.001
                    THEN N'صافي البنود المقابلة لا يطابق صافي حركة النقدية (قيد غير متوازن)'
                ELSE NULL
            END AS ExceptionReason
        FROM #JournalCheck JC
    ) X
    WHERE X.ExceptionReason IS NOT NULL;

    CREATE UNIQUE CLUSTERED INDEX IX_Exceptions
        ON #Exceptions (DayDMID);


    /*==============================================================
      6. صافي كل نشاط داخل كل قيد سليم
         (موجب = متحصلات، سالب = مدفوعات)
    ==============================================================*/

    SELECT
        CL.DayDMID,
        CL.CashFlowType,
        CAST(SUM(CL.FlowAmount) AS DECIMAL(19,3)) AS NetFlow
    INTO #EntryFlow
    FROM #CounterLines CL
    WHERE CL.CashFlowType BETWEEN 2 AND 4
      AND NOT EXISTS (SELECT 1 FROM #Exceptions E WHERE E.DayDMID = CL.DayDMID)
    GROUP BY CL.DayDMID, CL.CashFlowType
    HAVING SUM(CL.FlowAmount) <> 0;


    /*==============================================================
      7. أرصدة النقدية وأرقام التسوية
    ==============================================================*/

    DECLARE
        @Opening       DECIMAL(19,3),
        @Period        DECIMAL(19,3),
        @NetClassified DECIMAL(19,3),
        @ExceptionsNet DECIMAL(19,3),
        @ExceptionCnt  INT;

    SELECT
        @Opening = ISNULL(SUM(CASE WHEN M.DayMDate <  @DateFrom THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @Period  = ISNULL(SUM(CASE WHEN M.DayMDate >= @DateFrom THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0)
    FROM dbo.Acc_DayDetails D
    INNER JOIN dbo.Acc_DayMaster M
        ON M.DayMID = D.DayDMID
    INNER JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
       AND A.CashFlowType = 1
    WHERE M.DayMCompany = @CompanyID
      AND M.DayMState = 7
      AND M.DayMDate <= @DateTo;

    SELECT @NetClassified = ISNULL(SUM(NetFlow), 0)
    FROM #EntryFlow;

    SELECT
        @ExceptionsNet = ISNULL(SUM(CJ.CashNet), 0),
        @ExceptionCnt  = COUNT(*)
    FROM #Exceptions E
    INNER JOIN #CashJournal CJ
        ON CJ.DayDMID = E.DayDMID;


    /*==============================================================
      RESULT SET 1: التدفقات حسب النشاط
    ==============================================================*/

    SELECT
        V.CashFlowType,
        V.FlowName,
        CAST(ISNULL(F.CashInflows, 0)  AS DECIMAL(19,3)) AS CashInflows,
        CAST(ISNULL(F.CashOutflows, 0) AS DECIMAL(19,3)) AS CashOutflows,
        CAST(ISNULL(F.NetFlow, 0)      AS DECIMAL(19,3)) AS NetFlow
    FROM
    (
        VALUES
            (2, N'التدفقات النقدية من الأنشطة التشغيلية'),
            (3, N'التدفقات النقدية من الأنشطة الاستثمارية'),
            (4, N'التدفقات النقدية من الأنشطة التمويلية')
    ) V(CashFlowType, FlowName)
    LEFT JOIN
    (
        SELECT
            EF.CashFlowType,
            SUM(EF.NetFlow) AS NetFlow,
            SUM(CASE WHEN EF.NetFlow > 0 THEN  EF.NetFlow ELSE 0 END) AS CashInflows,
            SUM(CASE WHEN EF.NetFlow < 0 THEN -EF.NetFlow ELSE 0 END) AS CashOutflows
        FROM #EntryFlow EF
        GROUP BY EF.CashFlowType
    ) F
        ON F.CashFlowType = V.CashFlowType
    ORDER BY V.CashFlowType;


    /*==============================================================
      RESULT SET 2: أرصدة النقدية والتسوية
         ReconciliationDifference يجب أن يكون صفرًا دائمًا
    ==============================================================*/

    SELECT
        @Opening                 AS OpeningCashBalance,
        @Period                  AS PeriodCashMovement,
        @Opening + @Period       AS ClosingCashBalance,
        @NetClassified           AS NetClassifiedFlow,
        @ExceptionsNet           AS ExceptionsNet,
        @ExceptionCnt            AS ExceptionCount,
        @Period - @NetClassified - @ExceptionsNet AS ReconciliationDifference;


    /*==============================================================
      RESULT SET 3: القيود المستثناة للمراجعة
    ==============================================================*/

    SELECT
        M.DayMID,
        M.DayMNo,
        M.DayMDate,
        M.DayMDescription,
        M.DayMState,
        E.ExceptionReason,
        CJ.CashDebit,
        CJ.CashCredit,
        CJ.CashNet
    FROM #Exceptions E
    INNER JOIN dbo.Acc_DayMaster M
        ON M.DayMID = E.DayDMID
    INNER JOIN #CashJournal CJ
        ON CJ.DayDMID = E.DayDMID
    ORDER BY
        M.DayMDate,
        M.DayMNo,
        M.DayMID;

END;

GO

/* ---- Acc_SelectFinancialStatements (5 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectFinancialStatements]
    @FromDate  DATE = NULL,
    @ToDate    DATE,
    @Cmp       INT = 1,
    @Year      INT = 0,
    @AllAcc    BIT = 0,
    @MoveAcc   BIT = 0,
    @BalnceAcc BIT = 0,
    @LevelAcc  TINYINT = 0
AS
BEGIN
    /* =====================================================================
       اسم التقرير : القوائم المالية (Financial Statements)
       الإجراء     : dbo.Acc_SelectFinancialStatements
       المدخلات    : @ToDate و@Cmp و@Year؛ الفترة دائمًا من 1 يناير حتى @ToDate
                     (يُتجاهل @FromDate).
       النتائج     : 1 قائمة الدخل
                     2 قائمة المركز المالي (الميزانية العمومية)
                     3 حركة حقوق الملكية
                     4 ملخص القوائم المالية
                     5 فحوص سلامة البيانات
                     6-8 قائمة التدفقات النقدية (Acc_SelectCashFlow)
                     9 ميزان المراجعة
       القواعد     : القيود المرحّلة فقط (DayMState = 7)؛ القيد على الحساب
                     التحليلي فقط؛ السنة لا تُقفل.
                     حقوق الملكية = حساباتها + نتائج السنوات السابقة
                     + نتيجة السنة الحالية، وفرق الميزانية (BalanceSheetDifference)
                     يجب أن يكون صفرًا إذا كانت القيود متوازنة.
       ملاحظة     : معنى @AllAcc هنا: 0 = التحليلية فقط، 1 = كل الحسابات
                     (عكس بقية إجراءات التقارير).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DROP TABLE IF EXISTS #Acc;
DROP TABLE IF EXISTS #Kid;
DROP TABLE IF EXISTS #Leaf;
DROP TABLE IF EXISTS #Roll;
DROP TABLE IF EXISTS #JournalBalance;
DROP TABLE IF EXISTS #BsOut;
DROP TABLE IF EXISTS #EqOut;
    /* =========================================================
       1. التحقق من المدخلات وتحديد السنة المالية
       ========================================================= */

    IF @ToDate IS NULL
        THROW 50201, N'تاريخ نهاية التقرير مطلوب.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50202, N'رقم الشركة غير صحيح.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_Company
        WHERE CmpID = @Cmp
    )
        THROW 50203, N'الشركة المحددة غير موجودة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@ToDate);

    IF @Year < 1900 OR @Year > 9999
        THROW 50204, N'السنة المالية غير صحيحة.', 1;

    IF YEAR(@ToDate) <> @Year
        THROW 50205, N'تاريخ نهاية التقرير لا يتوافق مع السنة المالية.', 1;

    SET @FromDate = DATEFROMPARTS(@Year, 1, 1);

    IF @ToDate < @FromDate
        THROW 50206, N'تاريخ نهاية التقرير يسبق بداية السنة المالية.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @ToDateExclusive DATE = DATEADD(DAY, 1, @ToDate);

    IF OBJECT_ID(N'dbo.Acc_SelectCashFlow', N'P') IS NULL
        THROW 50208, N'إجراء التدفقات النقدية غير موجود.', 1;


    /* =========================================================
       2. تحميل شجرة حسابات الشركة
       ========================================================= */

    DROP TABLE IF EXISTS #Acc;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Leaf;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #JournalBalance;
    DROP TABLE IF EXISTS #BsOut;
    DROP TABLE IF EXISTS #EqOut;

    SELECT
        A.AccID,
        A.AccParentID,
        A.AccLevel,
        CAST(ISNULL(A.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(A.AccCode, N'') AS AccCode,
        ISNULL(A.AccName, N'') AS AccName,
        A.AccEnd,
        A.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS A
    WHERE A.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50209, N'لا توجد حسابات مسجلة للشركة المحددة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_FS_AccParent
        ON #Acc (AccParentID);


    /* =========================================================
       3. التحقق من سلامة الشجرة
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        WHERE C.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS P
              WHERE P.AccID = C.AccParentID
          )
    )
        THROW 50210, N'توجد حسابات يتيمة؛ الحساب الأب غير موجود.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        INNER JOIN dbo.Acc_Account AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccParentID > 0
          AND P.AccCompany <> @Cmp
    )
        THROW 50211, N'توجد علاقة أب وابن بين حسابات شركتين مختلفتين.', 1;

    DECLARE
        @AccountCount BIGINT,
        @ReachCount BIGINT;

    SELECT @AccountCount = COUNT_BIG(*)
    FROM #Acc;

    ;WITH AccountReach AS
    (
        SELECT AccID
        FROM #Acc
        WHERE AccParentID IS NULL
           OR AccParentID = 0

        UNION ALL

        SELECT C.AccID
        FROM #Acc AS C
        INNER JOIN AccountReach AS P
            ON C.AccParentID = P.AccID
    )
    SELECT @ReachCount = COUNT_BIG(*)
    FROM AccountReach
    OPTION (MAXRECURSION 32767);

    IF ISNULL(@ReachCount, 0) <> @AccountCount
        THROW 50212, N'توجد دورة أو حسابات غير مرتبطة بجذر شجرة الحسابات.', 1;


    /* =========================================================
       4. التحقق من التصنيف المالي

       الميزانية:
       AccEnd = 1
       AccType = 0 أصول
       AccType = 1 خصوم
       AccType = 2 حقوق ملكية

       قائمة الدخل:
       AccEnd = 2
       AccType = 0 إيرادات
       AccType = 1 مصروفات
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc
        WHERE AccEnd IS NULL
           OR AccType IS NULL
           OR NOT
           (
               (AccEnd = 1 AND AccType IN (0,1,2))
               OR
               (AccEnd = 2 AND AccType IN (0,1))
           )
    )
        THROW 50213, N'توجد حسابات بتصنيف مالي غير صحيح.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        INNER JOIN #Acc AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccEnd <> P.AccEnd
           OR C.AccType <> P.AccType
    )
        THROW 50214, N'يوجد اختلاف في التصنيف المالي بين حساب أب وأحد أبنائه.', 1;


    /* =========================================================
       5. تحديد الأبناء الفعليين
       ========================================================= */

    SELECT
        AccParentID AS AccID,
        COUNT_BIG(*) AS ChildCount
    INTO #Kid
    FROM #Acc
    WHERE AccParentID IS NOT NULL
      AND AccParentID > 0
    GROUP BY AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Kid
        ON #Kid (AccID);


    /* =========================================================
       6. فحص القيود المؤرشفة غير المتوازنة
       ========================================================= */

    SELECT
        M.DayMID,
        SUM(CONVERT(DECIMAL(38,3), D.DayDDeb)) AS TotalDebit,
        SUM(CONVERT(DECIMAL(38,3), D.DayDCrd)) AS TotalCredit
    INTO #JournalBalance
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive
    GROUP BY M.DayMID;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_JournalBalance
        ON #JournalBalance (DayMID);

    DECLARE
        @UnbalancedJournalCount BIGINT = 0,
        @ForeignAccountCount BIGINT = 0,
        @OrphanAccountCount BIGINT = 0,
        @CrossCompanyParentCount BIGINT = 0,
        @InvalidClassCount BIGINT = 0,
        @NonLeafPostingCount BIGINT = 0;

    SELECT @UnbalancedJournalCount = COUNT_BIG(*)
    FROM #JournalBalance
    WHERE ABS(TotalDebit - TotalCredit) >= 0.001;


    /* =========================================================
       7. تجميع حركات الحسابات التحليلية
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccParentID,
        A.AccLevel,
        A.AccChid,
        A.AccEnd,
        A.AccType,

        SUM
        (
            CASE
                WHEN M.DayMDate < @FromDate
                THEN
                    CONVERT(DECIMAL(38,3), D.DayDDeb)
                    - CONVERT(DECIMAL(38,3), D.DayDCrd)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS OpeningNet,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(38,3), D.DayDDeb)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS PeriodDebit,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(38,3), D.DayDCrd)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS PeriodCredit,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(BIGINT, 1)
                ELSE CONVERT(BIGINT, 0)
            END
        ) AS MovementCount

    INTO #Leaf
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    INNER JOIN #Acc AS A
        ON A.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Kid AS K
          WHERE K.AccID = A.AccID
      )
    GROUP BY
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccParentID,
        A.AccLevel,
        A.AccChid,
        A.AccEnd,
        A.AccType;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Leaf
        ON #Leaf (AccID);


    /* =========================================================
       8. تجميع الحسابات التحليلية إلى الحسابات الأب
       ========================================================= */

    ;WITH AccountRollup AS
    (
        SELECT
            L.AccID AS NodeID,
            L.OpeningNet,
            L.PeriodDebit,
            L.PeriodCredit,
            L.MovementCount
        FROM #Leaf AS L

        UNION ALL

        SELECT
            P.AccID AS NodeID,
            R.OpeningNet,
            R.PeriodDebit,
            R.PeriodCredit,
            R.MovementCount
        FROM AccountRollup AS R
        INNER JOIN #Acc AS C
            ON C.AccID = R.NodeID
        INNER JOIN #Acc AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccParentID > 0
    )
    SELECT
        NodeID AS AccID,
        SUM(OpeningNet) AS OpeningNet,
        SUM(PeriodDebit) AS PeriodDebit,
        SUM(PeriodCredit) AS PeriodCredit,
        SUM(MovementCount) AS MovementCount
    INTO #Roll
    FROM AccountRollup
    GROUP BY NodeID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Roll
        ON #Roll (AccID);


    /* =========================================================
       9. فحوص الحركات والتصنيفات
       ========================================================= */

    SELECT
        @ForeignAccountCount = COUNT_BIG(*)
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    LEFT JOIN #Acc AS A
        ON A.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive
      AND A.AccID IS NULL;

    -- حركات مسجلة على حسابات أب (لا تدخل في الأرقام لأن القيد يُسجل على الحساب التحليلي فقط)
    SELECT
        @NonLeafPostingCount = COUNT_BIG(*)
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    INNER JOIN #Kid AS K
        ON K.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive;

    SELECT
        @OrphanAccountCount = COUNT_BIG(*)
    FROM #Acc AS C
    WHERE C.AccParentID > 0
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Acc AS P
          WHERE P.AccID = C.AccParentID
      );

    SELECT
        @CrossCompanyParentCount = COUNT_BIG(*)
    FROM #Acc AS C
    INNER JOIN dbo.Acc_Account AS P
        ON P.AccID = C.AccParentID
    WHERE P.AccCompany <> @Cmp;

    SELECT
        @InvalidClassCount = COUNT_BIG(*)
    FROM #Acc
    WHERE AccEnd IS NULL
       OR AccType IS NULL
       OR NOT
       (
           (AccEnd = 1 AND AccType IN (0,1,2))
           OR
           (AccEnd = 2 AND AccType IN (0,1))
       );


    /* =========================================================
       10. إجماليات قائمة الدخل
       ========================================================= */

    DECLARE
        @Revenue DECIMAL(38,3) = 0,
        @Expenses DECIMAL(38,3) = 0,
        @NetIncome DECIMAL(38,3) = 0;

    SELECT
        @Revenue =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN AccType = 0
                        THEN PeriodCredit - PeriodDebit
                        ELSE 0
                    END
                ),
                0
            ),
        @Expenses =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN AccType = 1
                        THEN PeriodDebit - PeriodCredit
                        ELSE 0
                    END
                ),
                0
            )
    FROM #Leaf
    WHERE AccEnd = 2;

    SET @NetIncome = @Revenue - @Expenses;

    /* السنة المالية لا تُقفل، فحسابات قائمة الدخل تتراكم:
       نتائج السنوات السابقة = كل ما قبل بداية السنة (الدائن موجب)،
       وصافي حركة حسابات قائمة الدخل خلال السنة = نتيجة السنة الحالية. */
    DECLARE
        @PriorResult DECIMAL(38,3) = 0,
        @IsDebit     DECIMAL(38,3) = 0,
        @IsCredit    DECIMAL(38,3) = 0,
        @IsCount     BIGINT = 0;

    SELECT
        @PriorResult = -ISNULL(SUM(OpeningNet), 0),
        @IsDebit     = ISNULL(SUM(PeriodDebit), 0),
        @IsCredit    = ISNULL(SUM(PeriodCredit), 0),
        @IsCount     = ISNULL(SUM(MovementCount), 0)
    FROM #Leaf
    WHERE AccEnd = 2;


    /* =========================================================
       11. إجماليات المركز المالي
       ========================================================= */

    DECLARE
        @Assets DECIMAL(38,3) = 0,
        @Liabilities DECIMAL(38,3) = 0,
        @EquityAcc DECIMAL(38,3) = 0;

    SELECT
        @Assets =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 0
                        THEN ISNULL(R.OpeningNet,0)
                           + ISNULL(R.PeriodDebit,0)
                           - ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            ),

        @Liabilities =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 1
                        THEN -ISNULL(R.OpeningNet,0)
                             - ISNULL(R.PeriodDebit,0)
                             + ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            ),

        @EquityAcc =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 2
                        THEN -ISNULL(R.OpeningNet,0)
                             - ISNULL(R.PeriodDebit,0)
                             + ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            )
    FROM #Acc AS A
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND
      (
          A.AccParentID IS NULL
          OR A.AccParentID = 0
      );


    /* =========================================================
       12. فروقات المطابقة
       ========================================================= */

    DECLARE
        @BalanceDifference DECIMAL(38,3),
        @Equity DECIMAL(38,3);

    /* حقوق الملكية = حساباتها + نتائج السنوات السابقة + نتيجة السنة الحالية */
    SET @Equity = @EquityAcc + @PriorResult + @NetIncome;

    SET @BalanceDifference =
        @Assets - @Liabilities - @Equity;



    /* =========================================================
       RESULT SET 1: قائمة الدخل
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        P.AccName AS AccParentName,
        A.AccLevel,
        A.AccChid,
        A.AccType,

        CASE
            WHEN A.AccType = 0 THEN N'إيرادات'
            WHEN A.AccType = 1 THEN N'مصروفات'
        END AS AccountCategory,

        ISNULL(R.PeriodDebit,0) AS PeriodDebit,
        ISNULL(R.PeriodCredit,0) AS PeriodCredit,

        CAST
        (
            CASE
                WHEN A.AccType = 0
                    THEN ISNULL(R.PeriodCredit,0)
                       - ISNULL(R.PeriodDebit,0)
                WHEN A.AccType = 1
                    THEN ISNULL(R.PeriodDebit,0)
                       - ISNULL(R.PeriodCredit,0)
                ELSE 0
            END
            AS DECIMAL(38,3)
        ) AS PeriodAmount,

        ISNULL(R.MovementCount,0) AS MovementCount,

        @Revenue AS TotalRevenue,
        @Expenses AS TotalExpenses,
        @NetIncome AS NetIncome

    FROM #Acc AS A
    LEFT JOIN #Acc AS P
        ON P.AccID = A.AccParentID
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 2
      AND A.AccType IN (0,1)
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ORDER BY A.AccCode, A.AccID;


    /* =========================================================
       RESULT SET 2: قائمة المركز المالي
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        P.AccName AS AccParentName,
        A.AccLevel,
        A.AccChid,
        A.AccType,

        CASE
            WHEN A.AccType = 0 THEN N'الأصول'
            WHEN A.AccType = 1 THEN N'الخصوم'
            WHEN A.AccType = 2 THEN N'حقوق الملكية'
        END AS AccountCategory,

        ISNULL(R.OpeningNet,0) AS OpeningNet,
        ISNULL(R.PeriodDebit,0) AS PeriodDebit,
        ISNULL(R.PeriodCredit,0) AS PeriodCredit,

        CAST
        (
            CASE
                WHEN A.AccType = 0
                    THEN ISNULL(R.OpeningNet,0)
                       + ISNULL(R.PeriodDebit,0)
                       - ISNULL(R.PeriodCredit,0)
                WHEN A.AccType IN (1,2)
                    THEN -ISNULL(R.OpeningNet,0)
                       - ISNULL(R.PeriodDebit,0)
                       + ISNULL(R.PeriodCredit,0)
                ELSE 0
            END
            AS DECIMAL(38,3)
        ) AS ClosingBalance,

        ISNULL(R.MovementCount,0) AS MovementCount,

        @Assets AS TotalAssets,
        @Liabilities AS TotalLiabilities,
        @Equity AS TotalEquity,
        CAST(0 AS TINYINT) AS RowKind
    INTO #BsOut

    FROM #Acc AS A
    LEFT JOIN #Acc AS P
        ON P.AccID = A.AccParentID
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND A.AccType IN (0,1,2)
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @BalnceAcc = 0
          OR
          (
              CASE
                  WHEN A.AccType = 0
                      THEN ISNULL(R.OpeningNet,0)
                         + ISNULL(R.PeriodDebit,0)
                         - ISNULL(R.PeriodCredit,0)
                  ELSE -ISNULL(R.OpeningNet,0)
                       - ISNULL(R.PeriodDebit,0)
                       + ISNULL(R.PeriodCredit,0)
              END
          ) <> 0
      )
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ALTER TABLE #BsOut ALTER COLUMN AccCode NVARCHAR(200) NULL;
    ALTER TABLE #BsOut ALTER COLUMN AccARName NVARCHAR(400) NULL;

    -- صفّا نتائج السنوات ضمن حقوق الملكية (يظهران حتى مع @AllAcc و@LevelAcc)
    IF @MoveAcc = 0 AND (@BalnceAcc = 0 OR @PriorResult <> 0)
        INSERT INTO #BsOut
        (
            AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccChid, AccType,
            AccountCategory, OpeningNet, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
            TotalAssets, TotalLiabilities, TotalEquity, RowKind
        )
        VALUES
        (
            -1, N'~1', N'نتائج السنوات السابقة', NULL, NULL, 1, 0, 2,
            N'حقوق الملكية', -@PriorResult, 0, 0, @PriorResult, 0,
            @Assets, @Liabilities, @Equity, 1
        );

    IF (@MoveAcc = 0 OR @IsCount > 0) AND (@BalnceAcc = 0 OR @NetIncome <> 0)
        INSERT INTO #BsOut
        (
            AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccChid, AccType,
            AccountCategory, OpeningNet, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
            TotalAssets, TotalLiabilities, TotalEquity, RowKind
        )
        VALUES
        (
            -2, N'~2', N'نتيجة السنة الحالية', NULL, NULL, 1, 0, 2,
            N'حقوق الملكية', 0, @IsDebit, @IsCredit, @NetIncome, @IsCount,
            @Assets, @Liabilities, @Equity, 2
        );

    SELECT *
    FROM #BsOut
    ORDER BY AccType, RowKind, AccCode, AccID;


    /* =========================================================
       RESULT SET 3: حركة حقوق الملكية
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        A.AccLevel,

        CAST
        (
            -ISNULL(R.OpeningNet,0)
            AS DECIMAL(38,3)
        ) AS OpeningEquity,

        CAST
        (
            ISNULL(R.PeriodCredit,0)
            - ISNULL(R.PeriodDebit,0)
            AS DECIMAL(38,3)
        ) AS PeriodMovement,

        CAST
        (
            -ISNULL(R.OpeningNet,0)
            - ISNULL(R.PeriodDebit,0)
            + ISNULL(R.PeriodCredit,0)
            AS DECIMAL(38,3)
        ) AS ClosingEquity,

        ISNULL(R.MovementCount,0) AS MovementCount,
        CAST(0 AS TINYINT) AS RowKind
    INTO #EqOut

    FROM #Acc AS A
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND A.AccType = 2
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ALTER TABLE #EqOut ALTER COLUMN AccCode NVARCHAR(200) NULL;
    ALTER TABLE #EqOut ALTER COLUMN AccARName NVARCHAR(400) NULL;

    IF @MoveAcc = 0
        INSERT INTO #EqOut
        (AccID, AccCode, AccARName, AccParentID, AccLevel, OpeningEquity, PeriodMovement, ClosingEquity, MovementCount, RowKind)
        VALUES
        (-1, N'~1', N'نتائج السنوات السابقة', NULL, 1, @PriorResult, 0, @PriorResult, 0, 1);

    IF @MoveAcc = 0 OR @IsCount > 0
        INSERT INTO #EqOut
        (AccID, AccCode, AccARName, AccParentID, AccLevel, OpeningEquity, PeriodMovement, ClosingEquity, MovementCount, RowKind)
        VALUES
        (-2, N'~2', N'نتيجة السنة الحالية', NULL, 1, 0, @NetIncome, @NetIncome, @IsCount, 2);

    SELECT *
    FROM #EqOut
    ORDER BY RowKind, AccCode, AccID;


    /* =========================================================
       RESULT SET 4: ملخص القوائم المالية
       ========================================================= */

    SELECT
        @Cmp AS CompanyID,
        @Year AS FinancialYear,
        @FromDate AS FromDate,
        @ToDate AS ToDate,

        @Revenue AS TotalRevenue,
        @Expenses AS TotalExpenses,
        @NetIncome AS NetIncome,
        @PriorResult AS PriorYearsResult,
        @EquityAcc AS EquityAccountsTotal,

        @Assets AS TotalAssets,
        @Liabilities AS TotalLiabilities,
        @Equity AS TotalEquity,

        @BalanceDifference AS BalanceSheetDifference,

        CASE
            WHEN ABS(@BalanceDifference) < 0.001
                THEN N'متوازن'
            ELSE N'توجد فروقات'
        END AS BalanceSheetStatus;


    /* =========================================================
       RESULT SET 5: فحوص سلامة البيانات
       ========================================================= */

    SELECT
        @ForeignAccountCount AS ForeignAccountMovementCount,
        @OrphanAccountCount AS OrphanAccountCount,
        @CrossCompanyParentCount AS CrossCompanyParentCount,
        @InvalidClassCount AS InvalidAccountClassificationCount,
        @UnbalancedJournalCount AS UnbalancedJournalCount,
        @NonLeafPostingCount AS NonLeafPostingCount,

        CASE
            WHEN @ForeignAccountCount = 0
             AND @OrphanAccountCount = 0
             AND @CrossCompanyParentCount = 0
             AND @InvalidClassCount = 0
             AND @UnbalancedJournalCount = 0
             AND @NonLeafPostingCount = 0
                THEN N'اجتازت البيانات فحوص السلامة المحددة'
            ELSE N'توجد ملاحظات تتطلب المراجعة'
        END AS DataIntegrityStatus;


    /* =========================================================
       RESULT SETS 6-8: التدفقات النقدية
       ========================================================= */

    EXEC dbo.Acc_SelectCashFlow
        @CompanyID = @Cmp,
        @DateFrom  = @FromDate,
        @DateTo    = @ToDate;


    /* =========================================================
       RESULT SET 9: ميزان المراجعة

       ملاحظة:
       OpenNet = صافي الرصيد الافتتاحي مديناً ناقص دائناً.
       PerDeb  = إجمالي مدين الفترة.
       PerCrd  = إجمالي دائن الفترة.
       PerCnt  = عدد تفاصيل الحركات خلال الفترة.
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccLevel,
        A.AccParentID,
        A.AccChid,

        CAST(ISNULL(R.OpeningNet,0) AS DECIMAL(38,3))
            AS OpenNet,

        CAST(ISNULL(R.PeriodDebit,0) AS DECIMAL(38,3))
            AS PerDeb,

        CAST(ISNULL(R.PeriodCredit,0) AS DECIMAL(38,3))
            AS PerCrd,

        CAST(ISNULL(R.MovementCount,0) AS BIGINT)
            AS PerCnt,

        CAST
        (
            ISNULL(R.OpeningNet,0)
            + ISNULL(R.PeriodDebit,0)
            - ISNULL(R.PeriodCredit,0)
            AS DECIMAL(38,3)
        ) AS ClosingNet

    FROM #Acc AS A
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID

    WHERE
        (@AllAcc = 1 OR K.AccID IS NULL)
        AND
        (
            @MoveAcc = 0
            OR ISNULL(R.MovementCount,0) > 0
        )
        AND
        (
            @BalnceAcc = 0
            OR
            (
                ISNULL(R.OpeningNet,0)
                + ISNULL(R.PeriodDebit,0)
                - ISNULL(R.PeriodCredit,0)
            ) <> 0
        )
        AND
        (
            @LevelAcc = 0
            OR A.AccLevel = @LevelAcc
            OR
            (
                A.AccLevel < @LevelAcc
                AND K.AccID IS NULL
            )
        )

    ORDER BY A.AccCode, A.AccID;

END;

GO

/* ---- Acc_SelectCostCenterAnalysis (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ---------- Acc_SelectCostCenterAnalysis ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenterAnalysis]
    @Cmp       INT,
    @UserID    INT      = 0,   -- لا يؤثر على النتيجة (للترويسة فقط)
    @Year      INT,
    @CsCID     BIGINT   = 0,   -- مركز التكلفة الأب (0 = من الجذور)
    @FromDate  DATE,
    @ToDate    DATE,
    @AllCsC    BIT      = 0,   -- 1 = مراكز التكلفة التحليلية فقط ، 0 = الكل (آباء وتحليلية)
    @AllLevel  BIT      = 0,   -- 1 = كل المستويات (أبناء وأحفاد) ، 0 = الأبناء المباشرون فقط
    @MoveCsC   BIT      = 0,   -- 1 = المراكز التي لها حركة خلال الفترة فقط
    @BalnceCsC BIT      = 1,   -- 1 = المراكز التي رصيد نهاية مدتها <> 0 فقط
    @LevelCsC  TINYINT  = 0,   -- 0 = بلا فلتر ؛ المستوى المطلق CsCLevel (+ التحليلي الأقل مستوى)
    @Debit     BIT      = 0,   -- 1 = رصيد نهاية المدة مدين فقط
    @Credit    BIT      = 0,   -- 1 = رصيد نهاية المدة دائن فقط
    @AccId     BIGINT   = 0    -- الحساب (أب/جد/ابن) ؛ 0 = بلا فلتر
AS
BEGIN
    SET NOCOUNT ON;
    DROP TABLE IF EXISTS #R;
DROP TABLE IF EXISTS #Amt;
DROP TABLE IF EXISTS #Cl;
DROP TABLE IF EXISTS #Node;
    /* ---------- التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @CsCID = ISNULL(@CsCID, 0);
    SET @AccId = ISNULL(@AccId, 0);

    IF @CsCID > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
        THROW 50005, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

    /* ---------- الحساب وفروعه (إن وُجد فلتر) ---------- */
    DECLARE @Acc TABLE (AccID BIGINT NOT NULL PRIMARY KEY);

    IF @AccId > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccId AND AccCompany = @Cmp)
            THROW 50007, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

        ;WITH AccTree AS
        (
            SELECT a.AccID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_Account AS a
            WHERE a.AccID = @AccId AND a.AccCompany = @Cmp

            UNION ALL

            SELECT a.AccID, p.Lvl + 1
            FROM dbo.Acc_Account AS a
            JOIN AccTree AS p ON a.AccParentID = p.AccID
            WHERE a.AccCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @Acc (AccID) SELECT AccID FROM AccTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- شجرة مراكز التكلفة تحت المركز المطلوب (Depth 1 = الأبناء المباشرون) ---------- */
    ;WITH CcTree AS
    (
        SELECT c.CsCID, c.CsCParentID, c.CsCLevel, c.CsCCode, c.CsCName, CAST(1 AS INT) AS Depth
        FROM dbo.Acc_CostCenter AS c
        WHERE c.CsCCompany = @Cmp
          AND c.CsCID <> ISNULL(c.CsCParentID, 0)
          AND (   (@CsCID > 0 AND c.CsCParentID = @CsCID)
               OR (@CsCID = 0 AND (c.CsCParentID IS NULL OR c.CsCParentID = 0)))

        UNION ALL

        SELECT c.CsCID, c.CsCParentID, c.CsCLevel, c.CsCCode, c.CsCName, p.Depth + 1
        FROM dbo.Acc_CostCenter AS c
        JOIN CcTree AS p ON c.CsCParentID = p.CsCID
        WHERE c.CsCCompany = @Cmp AND p.Depth < 30
    )
    SELECT CsCID, CsCParentID, CsCLevel, CsCCode, CsCName, Depth
    INTO #Node
    FROM CcTree
    OPTION (MAXRECURSION 100);

    CREATE UNIQUE CLUSTERED INDEX IX_Node ON #Node (CsCID);

    /* ---------- (المركز ← كل أحفاده بما فيهم نفسه) لتجميع الأرصدة نحو الآباء ---------- */
    ;WITH Cl AS
    (
        SELECT n.CsCID AS NodeID, n.CsCID AS DescID
        FROM #Node AS n

        UNION ALL

        SELECT c.NodeID, k.CsCID
        FROM Cl AS c
        JOIN #Node AS k ON k.CsCParentID = c.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 100);

    CREATE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- حركة كل مركز: مرة واحدة على الجداول الكبيرة ---------- */
    SELECT d.DayDCsCID AS CsCID,
           SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)                      AS PerCnt
    INTO #Amt
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    JOIN #Node              AS n ON n.CsCID  = d.DayDCsCID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate   <= @ToDate
      AND (@AccId = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
    GROUP BY d.DayDCsCID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amt ON #Amt (CsCID);

    /* ---------- ملخص الترويسة: رصيد المركز المطلوب نفسه (يتجاهل فلاتر العرض) ---------- */
    DECLARE @HOpen DECIMAL(18,3), @HPerDeb DECIMAL(18,3), @HPerCrd DECIMAL(18,3);

    SELECT @HOpen   = CAST(ISNULL(SUM(OpenNet), 0) AS DECIMAL(18,3)),
           @HPerDeb = CAST(ISNULL(SUM(PerDeb ), 0) AS DECIMAL(18,3)),
           @HPerCrd = CAST(ISNULL(SUM(PerCrd ), 0) AS DECIMAL(18,3))
    FROM #Amt;

    DECLARE @HPerNet DECIMAL(18,3) = @HPerDeb - @HPerCrd;
    DECLARE @HClose  DECIMAL(18,3) = @HOpen + @HPerNet;

    /* ---------- تجميع كل مركز مع أحفاده ---------- */
    SELECT n.CsCID, n.CsCParentID, n.CsCLevel, n.CsCCode, n.CsCName, n.Depth,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM #Node AS k WHERE k.CsCParentID = n.CsCID) THEN 0 ELSE 1 END AS BIT) AS IsLeaf,
           CAST(ISNULL(SUM(a.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(a.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(a.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(a.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #R
    FROM #Node AS n
    JOIN #Cl   AS c ON c.NodeID = n.CsCID
    LEFT JOIN #Amt AS a ON a.CsCID = c.DescID
    GROUP BY n.CsCID, n.CsCParentID, n.CsCLevel, n.CsCCode, n.CsCName, n.Depth;

    /* ---------- النتيجة ---------- */
    SELECT x.CsCID, x.CsCCode, x.CsCName, x.CsCLevel, x.CsCParentID,
           pc.CsCName AS CsCParentName,
           x.IsLeaf,

           -- رصيد أول المدة
           CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
           CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
           -- الحركة بالمجاميع
           x.PerDeb AS NewDebit,
           x.PerCrd AS NewCredit,
           -- الحركة بالأرصدة
           CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END AS BalanceDebit,
           CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
           -- رصيد آخر المدة
           CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotDebit,
           CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotCredit,

           -- ملخص الترويسة (يتكرر على كل صف)
           CASE WHEN @HOpen   > 0 THEN  @HOpen   ELSE 0 END AS SumBlcOldDebit,
           CASE WHEN @HOpen   < 0 THEN -@HOpen   ELSE 0 END AS SumBlcOldCredit,
           @HPerDeb AS SumTotDebit,
           @HPerCrd AS SumTotCredit,
           CASE WHEN @HPerNet > 0 THEN  @HPerNet ELSE 0 END AS SumBlcDebit,
           CASE WHEN @HPerNet < 0 THEN -@HPerNet ELSE 0 END AS SumBlcCredit,
           CASE WHEN @HClose  > 0 THEN  @HClose  ELSE 0 END AS SumTotBlcDebit,
           CASE WHEN @HClose  < 0 THEN -@HClose  ELSE 0 END AS SumTotBlcCredit
    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #R AS r
    ) AS x
    LEFT JOIN dbo.Acc_CostCenter AS pc ON pc.CsCID = x.CsCParentID
    WHERE (@AllCsC   = 0 OR x.IsLeaf = 1)
      AND (@AllLevel = 1 OR x.Depth  = 1)
      AND (@LevelCsC = 0 OR x.CsCLevel = @LevelCsC OR (x.CsCLevel < @LevelCsC AND x.IsLeaf = 1))
      AND (@MoveCsC   = 0 OR x.PerCnt   > 0)
      AND (@BalnceCsC = 0 OR x.CloseNet <> 0)
      AND (@Debit     = 0 OR x.CloseNet > 0)
      AND (@Credit    = 0 OR x.CloseNet < 0)
    ORDER BY x.CsCCode, x.CsCLevel;
END;

GO

/* ---- Acc_SelectCostCenterStatement (2 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ---------- Acc_SelectCostCenterStatement ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenterStatement]
    @Cmp      INT,
    @UserID   INT = 0,         -- لا يؤثر على النتيجة (للاستخدام في ترويسة التقرير فقط)
    @Year     INT,
    @CsCId    BIGINT = 0,      -- مركز التكلفة (تحليلي فقط)
    @FromDate DATE,
    @ToDate   DATE,
    @Debit    BIT = 0,         -- 1 = الحركات المدينة فقط
    @Credit   BIT = 0,         -- 1 = الحركات الدائنة فقط
    @AccID    BIGINT = 0       -- 0 = بلا فلتر الحسابات (يقبل أب/جد/ابن)
AS
BEGIN
    SET NOCOUNT ON;
    DROP TABLE IF EXISTS #Mov;
    /* ---------- التحقق من المدخلات ---------- */
    IF ISNULL(@CsCId, 0) <= 0
        THROW 50001, N'يجب تحديد مركز التكلفة.', 1;
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @AccID = ISNULL(@AccID, 0);

    DECLARE @CsCCode NVARCHAR(60), @CsCName NVARCHAR(500);

    SELECT @CsCCode = c.CsCCode, @CsCName = c.CsCName
    FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCID = @CsCId AND c.CsCCompany = @Cmp;

    IF @CsCCode IS NULL
        THROW 50005, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS k WHERE k.CsCParentID = @CsCId)
        THROW 50006, N'كشف مركز التكلفة متاح لمراكز التكلفة التحليلية فقط.', 1;

    /* ---------- الحساب وفروعه (إن وُجد فلتر) ---------- */
    DECLARE @Acc TABLE (AccID BIGINT NOT NULL PRIMARY KEY);

    IF @AccID > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID AND AccCompany = @Cmp)
            THROW 50007, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

        ;WITH AccTree AS
        (
            SELECT a.AccID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_Account AS a
            WHERE a.AccID = @AccID AND a.AccCompany = @Cmp

            UNION ALL

            SELECT a.AccID, p.Lvl + 1
            FROM dbo.Acc_Account AS a
            JOIN AccTree AS p ON a.AccParentID = p.AccID
            WHERE a.AccCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @Acc (AccID) SELECT AccID FROM AccTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- رصيد بداية المدة: كل الحركات قبل @FromDate من كل السنوات ---------- */
    DECLARE @Opening DECIMAL(18,3);

    SELECT @Opening = ISNULL(SUM(d.DayDDeb), 0) - ISNULL(SUM(d.DayDCrd), 0)
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE d.DayDCsCID = @CsCId
      AND m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate < @FromDate
      AND (@AccID = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
    OPTION (RECOMPILE);

    /* ---------- حركات الفترة (الترتيب: الشهر ثم DayMNo ثم البند) ---------- */
    SELECT
        CAST(ROW_NUMBER() OVER (ORDER BY MONTH(m.DayMDate), m.DayMNo, d.DayDID) AS INT) AS Seq,
        m.DayMID, m.DayMNo, m.DayMDate,
        m.DayMDescription, d.DayDDescription, d.DayDNum,
        d.DayDAccID, a.AccCode, a.AccName,
        d.DayDDeb, d.DayDCrd
    INTO #Mov
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    LEFT JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
    WHERE d.DayDCsCID = @CsCId
      AND m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate >= @FromDate AND m.DayMDate <= @ToDate
      AND (@AccID = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
      AND (@Debit  = 0 OR d.DayDDeb > 0)
      AND (@Credit = 0 OR d.DayDCrd > 0)
    OPTION (RECOMPILE);

    DECLARE @PerDeb DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDDeb), 0) FROM #Mov),
            @PerCrd DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDCrd), 0) FROM #Mov);
    DECLARE @Closing DECIMAL(18,3) = @Opening + @PerDeb - @PerCrd;

    /* ---------- النتيجة: جدول واحد ---------- */
    SELECT R.RowType, R.Seq, R.RowLabel,
           R.DayMID, R.DayMNo,
           CASE WHEN R.RowType = 1
                THEN CONCAT(CAST(R.DayMNo AS NVARCHAR(10)), N'/', RIGHT(CONCAT(N'0', MONTH(R.DayMDate)), 2))
           END AS EntryNo,
           R.DayMDate, R.EntryDescription, R.ItemDescription, R.DayDNum,
           R.AccountID AS AccID, R.AccountCode AS AccCode, R.AccountName AS AccName,
           R.Debit, R.Credit, R.Balance,
           CASE WHEN R.Balance > 0 THEN N'مدين' WHEN R.Balance < 0 THEN N'دائن' ELSE N'' END AS BalanceSide,
           @CsCId AS CsCID, @CsCCode AS CsCCode, @CsCName AS CsCName
    FROM
    (
        -- رصيد بداية المدة
        SELECT CAST(0 AS TINYINT) AS RowType, 0 AS Seq, N'رصيد بداية المدة' AS RowLabel,
               CAST(NULL AS BIGINT) AS DayMID, CAST(NULL AS INT) AS DayMNo, CAST(NULL AS DATE) AS DayMDate,
               CAST(NULL AS NVARCHAR(MAX)) AS EntryDescription, CAST(NULL AS NVARCHAR(MAX)) AS ItemDescription,
               CAST(NULL AS NVARCHAR(50)) AS DayDNum,
               CAST(NULL AS BIGINT) AS AccountID, CAST(NULL AS NVARCHAR(60)) AS AccountCode, CAST(NULL AS NVARCHAR(500)) AS AccountName,
               CAST(NULL AS DECIMAL(18,3)) AS Debit, CAST(NULL AS DECIMAL(18,3)) AS Credit,
               @Opening AS Balance

        UNION ALL
        -- الحركات مع الرصيد الجاري على الصفوف الظاهرة
        SELECT CAST(1 AS TINYINT), Seq, CAST(NULL AS NVARCHAR(50)),
               DayMID, DayMNo, DayMDate,
               DayMDescription, DayDDescription, DayDNum,
               DayDAccID, AccCode, AccName,
               DayDDeb, DayDCrd,
               @Opening + SUM(DayDDeb - DayDCrd) OVER (ORDER BY Seq ROWS UNBOUNDED PRECEDING)
        FROM #Mov

        UNION ALL
        -- رصيد خلال الفترة
        SELECT CAST(2 AS TINYINT), 0, N'رصيد خلال الفترة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               @PerDeb, @PerCrd, @PerDeb - @PerCrd

        UNION ALL
        -- رصيد نهاية المدة
        SELECT CAST(3 AS TINYINT), 0, N'رصيد نهاية المدة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               NULL, NULL, @Closing
    ) AS R
    ORDER BY R.RowType, R.Seq;
END;

GO

/* ---- Acc_SelectCostCentersWithBalnce (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCentersWithBalnce]
    @Cmp  INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50001, N'رقم الشركة غير صحيح.', 1;

    IF @Year IS NULL OR @Year < 1900 OR @Year > 9998
        THROW 50002, N'السنة المالية غير صحيحة.', 1;

    DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
            @To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);

    ;WITH Tree AS
    (
        -- المراكز الرئيسية
        SELECT
            a.CsCID,
            CAST(N'' AS NVARCHAR(4000)) AS CsCParintName,
            0 AS Lvl
        FROM dbo.Acc_CostCenter AS a
        WHERE a.CsCCompany = @Cmp
          AND a.CsCParentID IS NULL

        UNION ALL

        -- المراكز الفرعية
        SELECT
            c.CsCID,
            CAST(
                CASE
                    WHEN t.CsCParintName = N''
                        THEN p.CsCName
                    ELSE t.CsCParintName + N' / ' + p.CsCName
                END AS NVARCHAR(4000)
            ) AS CsCParintName,
            t.Lvl + 1
        FROM dbo.Acc_CostCenter AS c
        INNER JOIN Tree AS t
            ON c.CsCParentID = t.CsCID
        INNER JOIN dbo.Acc_CostCenter AS p
            ON p.CsCID = t.CsCID
           AND p.CsCCompany = @Cmp
        WHERE c.CsCCompany = @Cmp
          AND t.Lvl < 30
    ),
    Mov AS
    (
        -- حركة مراكز التكلفة خلال السنة
        SELECT
            d.DayDCsCID AS CsCID,
            SUM(d.DayDDeb) AS Deb,
            SUM(d.DayDCrd) AS Crd
        FROM dbo.Acc_DayMaster AS m
        INNER JOIN dbo.Acc_DayDetails AS d
            ON d.DayDMID = m.DayMID
        WHERE m.DayMState = 7
          AND m.DayMDate >= @From
          AND m.DayMDate < @To
          AND d.DayDCsCID IS NOT NULL
        GROUP BY d.DayDCsCID
    )
    SELECT
        a.CsCID,
        a.CsCCode,
        a.CsCName,
        a.CsCState,
        t.CsCParintName,
        CASE
            WHEN t.CsCParintName = N''
                THEN a.CsCName
            ELSE t.CsCParintName + N' / ' + a.CsCName
        END AS Parents,
        CASE
            WHEN ISNULL(x.Deb, 0) > ISNULL(x.Crd, 0)
                THEN x.Deb - x.Crd
            ELSE 0
        END AS CsCDebet,
        CASE
            WHEN ISNULL(x.Crd, 0) > ISNULL(x.Deb, 0)
                THEN x.Crd - x.Deb
            ELSE 0
        END AS CsCCridit,
        a.CsCCompany
    FROM dbo.Acc_CostCenter AS a
    INNER JOIN Tree AS t
        ON t.CsCID = a.CsCID
    LEFT JOIN Mov AS x
        ON x.CsCID = a.CsCID
    WHERE a.CsCState = 0
      AND a.CsCChid = 0
      AND a.CsCCompany = @Cmp
    ORDER BY a.CsCCode
    OPTION (MAXRECURSION 32);
END;

GO

/* ---- Acc_SelectDashboardExecutive (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =====================================================================
   لوحة المحاسبة التنفيذية — إجراءات قراءة فقط (لا تغيّر أي منطق ولا بيانات)
   القيود المحتسبة: DayMState من 1 إلى 7 (كل ما عدا المؤقت).
   الفترة: من 1/1/@Year حتى @AsOf، حيث
        @AsOf = اليوم إن وقع داخل السنة، وإلا نهاية السنة (أو بدايتها لسنة مستقبلية).
   المقارنة: نفس الفترة من السنة السابقة (من 1/1 حتى نفس اليوم والشهر).
   المعاملة @Part: 0 = كل المجموعات، أو رقم المجموعة المطلوبة وحدها
        (تسمح بالاختبار INSERT-EXEC وبتحميل جزء واحد في الصفحة).

   Acc_SelectDashboardExecutive  — المجموعات:
     1 KPI        صف واحد (الفترة، الإيراد، المصروف، النقدية، الأصول، الخصوم...)
     2 Monthly    12 صفًا (إيراد/مصروف/نقدية داخلة وخارجة + السنة السابقة)
     3 RevenueSrc أعلى 8 حسابات إيراد + «أخرى»
     4 ExpenseSrc أعلى 8 حسابات مصروف + «أخرى»
     5 CashAcc    أرصدة حسابات النقدية والبنوك (حتى 8)
     6 Health     مؤشرات الرقابة (صف واحد)
     7 Abnormal   أعلى 8 حسابات بأرصدة شاذة

   Acc_SelectDashboardProject    — المجموعات:
     1 Summary    ملخص المشروع المختار (أو كل المشاريع)
     2 Monthly    12 صفًا (الصرف الشهري + السنة السابقة + إجمالي الشركة)
     3 TopAcc     أعلى 8 حسابات صرفًا على المشروع
     4 Ranking    أعلى 12 مشروعًا بحسب الصرف المباشر على المشروع نفسه
     5 Children   المشاريع الفرعية المباشرة للمختار (أو الجذور)
     6 List       قائمة كل المشاريع للقائمة المنسدلة (إن @IncludeList = 1)
   ===================================================================== */

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectDashboardExecutive]
    @Cmp  INT,
    @Year INT,
    @Part TINYINT = 0
AS
BEGIN
    SET NOCOUNT ON;
    DROP TABLE IF EXISTS #Src;
DROP TABLE IF EXISTS #CV;
DROP TABLE IF EXISTS #CashLeaf;
DROP TABLE IF EXISTS #Leaf;
DROP TABLE IF EXISTS #Acc;
DROP TABLE IF EXISTS #M;
    IF @Cmp IS NULL OR @Cmp <= 0 THROW 53101, N'الشركة المحددة غير صحيحة.', 1;
    IF @Year IS NULL OR @Year < 1900 OR @Year > 2200 THROW 53102, N'السنة المالية غير صحيحة.', 1;

    DECLARE @Today  DATE = CAST(GETDATE() AS DATE);
    DECLARE @YStart DATE = DATEFROMPARTS(@Year, 1, 1);
    DECLARE @YEnd   DATE = DATEFROMPARTS(@Year, 12, 31);
    DECLARE @AsOf   DATE = CASE WHEN @Today > @YEnd THEN @YEnd
                                WHEN @Today < @YStart THEN @YStart
                                ELSE @Today END;
    DECLARE @PStart DATE = DATEADD(YEAR, -1, @YStart);
    DECLARE @PAsOf  DATE = DATEADD(YEAR, -1, @AsOf);
    DECLARE @PYEnd  DATE = DATEADD(YEAR, -1, @YEnd);
    DECLARE @MoAsOf INT  = MONTH(@AsOf);

    /* حركات الشركة (غير المؤقتة) حتى @AsOf، مع تصنيف الحساب */
    SELECT m.DayMID, m.DayMDate, d.DayDAccID AS AccID,
           d.DayDDeb AS Deb, d.DayDCrd AS Crd, a.AccEnd, a.AccType
    INTO #M
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    JOIN dbo.Acc_Account    AS a ON a.AccID = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @AsOf;

    CREATE CLUSTERED INDEX IX_M ON #M (AccID, DayMDate);

    /* شجرة الحسابات + الأوراق */
    SELECT AccID, AccParentID, AccCode, AccName INTO #Acc
    FROM dbo.Acc_Account WHERE AccCompany = @Cmp;
    CREATE UNIQUE CLUSTERED INDEX IX_Acc ON #Acc (AccID);

    SELECT a.AccID INTO #Leaf
    FROM #Acc AS a
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS c WHERE c.AccParentID = a.AccID);
    CREATE UNIQUE CLUSTERED INDEX IX_Leaf ON #Leaf (AccID);

    /* حسابات النقدية: الأوراق تحت تصنيف CashFlowType = 1 (يرث من الآباء) */
    ;WITH Up AS
    (
        SELECT a.AccID AS LeafID, a.AccID AS NodeID, a.AccParentID AS ParentID
        FROM #Acc AS a
        UNION ALL
        SELECT u.LeafID, p.AccID, p.AccParentID
        FROM Up AS u JOIN #Acc AS p ON p.AccID = u.ParentID
        WHERE u.ParentID > 0
    )
    SELECT DISTINCT u.LeafID AS AccID
    INTO #CashLeaf
    FROM Up AS u
    JOIN dbo.Acc_CashFlowAccounts AS c ON c.AccID = u.NodeID AND c.CashFlowType = 1
    WHERE EXISTS (SELECT 1 FROM #Leaf AS l WHERE l.AccID = u.LeafID)
    OPTION (MAXRECURSION 200);
    CREATE UNIQUE CLUSTERED INDEX IX_CashLeaf ON #CashLeaf (AccID);

    /* حركة القيد على النقدية: الداخل = زيادة صافية، الخارج = نقص صافٍ.
       التحويل بين حسابي نقدية داخل القيد نفسه لا يُحتسب داخلًا ولا خارجًا. */
    SELECT m.DayMID, m.DayMDate,
           SUM(m.Deb) AS CDeb, SUM(m.Crd) AS CCrd
    INTO #CV
    FROM #M AS m
    JOIN #CashLeaf AS c ON c.AccID = m.AccID
    GROUP BY m.DayMID, m.DayMDate;

    /* --------------------------- 1) KPI --------------------------- */
    IF @Part IN (0, 1)
    BEGIN
        DECLARE @Rev  DECIMAL(28,3), @Exp  DECIMAL(28,3), @PRev DECIMAL(28,3), @PExp DECIMAL(28,3);

        SELECT
            @Rev  = ISNULL(SUM(CASE WHEN AccType = 0 AND DayMDate >= @YStart THEN Crd - Deb END), 0),
            @Exp  = ISNULL(SUM(CASE WHEN AccType = 1 AND DayMDate >= @YStart THEN Deb - Crd END), 0),
            @PRev = ISNULL(SUM(CASE WHEN AccType = 0 AND DayMDate BETWEEN @PStart AND @PAsOf THEN Crd - Deb END), 0),
            @PExp = ISNULL(SUM(CASE WHEN AccType = 1 AND DayMDate BETWEEN @PStart AND @PAsOf THEN Deb - Crd END), 0)
        FROM #M WHERE AccEnd = 2;

        SELECT
            @AsOf   AS AsOf,
            @PAsOf  AS PAsOf,
            @YStart AS YStart,
            @Rev    AS Revenue,
            @Exp    AS Expenses,
            @Rev - @Exp   AS NetResult,
            @PRev   AS PRevenue,
            @PExp   AS PExpenses,
            @PRev - @PExp AS PNetResult,
            -- النقدية
            ISNULL((SELECT SUM(m.Deb - m.Crd) FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID), 0) AS CashBalance,
            ISNULL((SELECT SUM(m.Deb - m.Crd) FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
                     WHERE m.DayMDate < @YStart), 0) AS CashOpening,
            ISNULL((SELECT SUM(m.Deb - m.Crd) FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
                     WHERE m.DayMDate <= @PAsOf), 0) AS PCashBalance,
            ISNULL((SELECT SUM(CASE WHEN CDeb > CCrd THEN CDeb - CCrd ELSE 0 END) FROM #CV WHERE DayMDate >= @YStart), 0) AS CashIn,
            ISNULL((SELECT SUM(CASE WHEN CCrd > CDeb THEN CCrd - CDeb ELSE 0 END) FROM #CV WHERE DayMDate >= @YStart), 0) AS CashOut,
            ISNULL((SELECT SUM(CASE WHEN CDeb > CCrd THEN CDeb - CCrd ELSE 0 END) FROM #CV WHERE DayMDate BETWEEN @PStart AND @PAsOf), 0) AS PCashIn,
            ISNULL((SELECT SUM(CASE WHEN CCrd > CDeb THEN CCrd - CDeb ELSE 0 END) FROM #CV WHERE DayMDate BETWEEN @PStart AND @PAsOf), 0) AS PCashOut,
            -- المركز المالي (تراكمي كل السنوات حتى @AsOf)
            ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 1 AND AccType = 0), 0) AS Assets,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType = 1), 0) AS Liabilities,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType = 2), 0) AS Equity,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2), 0) AS CumResult,
            ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 1 AND AccType = 0), 0)
              - ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType IN (1, 2)), 0)
              - ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2), 0) AS BalanceDiff,
            ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 1 AND AccType = 0 AND DayMDate <= @PAsOf), 0) AS PAssets,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType = 1 AND DayMDate <= @PAsOf), 0) AS PLiabilities;
    END;

    /* --------------------------- 2) الشهري --------------------------- */
    IF @Part IN (0, 2)
    BEGIN
        ;WITH Mo AS (SELECT 1 AS N UNION ALL SELECT N + 1 FROM Mo WHERE N < 12)
        SELECT
            Mo.N AS Mo,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2 AND AccType = 0
                               AND DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS Revenue,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 2 AND AccType = 1
                               AND DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS Expenses,
            CAST(ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2 AND AccType = 0
                           AND DayMDate BETWEEN @PStart AND @PYEnd AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) AS PRevenue,
            CAST(ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 2 AND AccType = 1
                           AND DayMDate BETWEEN @PStart AND @PYEnd AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) AS PExpenses,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(CASE WHEN CDeb > CCrd THEN CDeb - CCrd ELSE 0 END) FROM #CV
                               WHERE DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS CashIn,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(CASE WHEN CCrd > CDeb THEN CCrd - CDeb ELSE 0 END) FROM #CV
                               WHERE DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS CashOut
        FROM Mo
        ORDER BY Mo.N;
    END;

    /* ------------------- 3) مصادر الإيراد / 4) أوجه المصروف ------------------- */
    IF @Part IN (0, 3, 4)
    BEGIN
        SELECT m.AccID, m.AccType,
               SUM(CASE WHEN m.DayMDate >= @YStart THEN
                        CASE WHEN m.AccType = 0 THEN m.Crd - m.Deb ELSE m.Deb - m.Crd END END) AS Cur,
               SUM(CASE WHEN m.DayMDate BETWEEN @PStart AND @PAsOf THEN
                        CASE WHEN m.AccType = 0 THEN m.Crd - m.Deb ELSE m.Deb - m.Crd END END) AS Prev
        INTO #Src
        FROM #M AS m
        WHERE m.AccEnd = 2 AND m.AccType IN (0, 1)
          AND m.DayMDate >= @PStart
        GROUP BY m.AccID, m.AccType;

        UPDATE #Src SET Cur = ISNULL(Cur, 0), Prev = ISNULL(Prev, 0);
        DELETE FROM #Src WHERE Cur = 0 AND Prev = 0;

        IF @Part IN (0, 3)
        BEGIN
            ;WITH R AS
            (
                SELECT s.AccID, a.AccCode, a.AccName, s.Cur, s.Prev,
                       ROW_NUMBER() OVER (ORDER BY s.Cur DESC, s.Prev DESC, s.AccID) AS Rk
                FROM #Src AS s JOIN #Acc AS a ON a.AccID = s.AccID
                WHERE s.AccType = 0
            )
            SELECT Rk AS [Rank], AccCode, AccName, CAST(Cur AS DECIMAL(28,3)) AS Cur, CAST(Prev AS DECIMAL(28,3)) AS Prev
            FROM R WHERE Rk <= 8
            UNION ALL
            SELECT 99, N'', N'أخرى', CAST(SUM(Cur) AS DECIMAL(28,3)), CAST(SUM(Prev) AS DECIMAL(28,3))
            FROM R WHERE Rk > 8 HAVING COUNT(*) > 0
            ORDER BY [Rank];
        END;

        IF @Part IN (0, 4)
        BEGIN
            ;WITH R AS
            (
                SELECT s.AccID, a.AccCode, a.AccName, s.Cur, s.Prev,
                       ROW_NUMBER() OVER (ORDER BY s.Cur DESC, s.Prev DESC, s.AccID) AS Rk
                FROM #Src AS s JOIN #Acc AS a ON a.AccID = s.AccID
                WHERE s.AccType = 1
            )
            SELECT Rk AS [Rank], AccCode, AccName, CAST(Cur AS DECIMAL(28,3)) AS Cur, CAST(Prev AS DECIMAL(28,3)) AS Prev
            FROM R WHERE Rk <= 8
            UNION ALL
            SELECT 99, N'', N'أخرى', CAST(SUM(Cur) AS DECIMAL(28,3)), CAST(SUM(Prev) AS DECIMAL(28,3))
            FROM R WHERE Rk > 8 HAVING COUNT(*) > 0
            ORDER BY [Rank];
        END;
    END;

    /* --------------------------- 5) حسابات النقدية --------------------------- */
    IF @Part IN (0, 5)
    BEGIN
        SELECT TOP (8) a.AccCode, a.AccName, CAST(b.Bal AS DECIMAL(28,3)) AS Balance
        FROM (SELECT m.AccID, SUM(m.Deb - m.Crd) AS Bal
              FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
              GROUP BY m.AccID) AS b
        JOIN #Acc AS a ON a.AccID = b.AccID
        WHERE b.Bal <> 0
        ORDER BY ABS(b.Bal) DESC;
    END;

    /* --------------------------- 6) الرقابة --------------------------- */
    IF @Part IN (0, 6)
    BEGIN
        SELECT
            (SELECT COUNT(*) FROM
                (SELECT DayMID FROM #M WHERE DayMDate >= @YStart
                 GROUP BY DayMID HAVING SUM(Deb) <> SUM(Crd)) AS x) AS UnbalancedPosted,
            (SELECT COUNT(*) FROM dbo.Acc_DayMaster
              WHERE DayMCompany = @Cmp AND DayMState = 0
                AND DayMDate BETWEEN @YStart AND @YEnd
                AND DayMDateTime < DATEADD(DAY, -7, SYSUTCDATETIME())) AS StaleDrafts,
            (SELECT COUNT(*) FROM dbo.Acc_DayMaster
              WHERE DayMCompany = @Cmp AND DayMState IN (2, 4, 6)
                AND DayMDate BETWEEN @YStart AND @YEnd) AS ReturnedVouchers,
            (SELECT COUNT(*) FROM
                (SELECT m.AccID FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
                 GROUP BY m.AccID HAVING SUM(m.Deb - m.Crd) < 0) AS x) AS NegativeCashAccounts,
            (SELECT COUNT(*) FROM
                (SELECT m.AccID FROM #M AS m JOIN #Leaf AS l ON l.AccID = m.AccID
                 WHERE m.AccEnd = 1
                 GROUP BY m.AccID, m.AccType
                 HAVING (m.AccType = 0 AND SUM(m.Deb - m.Crd) < 0)
                     OR (m.AccType IN (1, 2) AND SUM(m.Crd - m.Deb) < 0)) AS x) AS AbnormalBalances;
    END;

    /* --------------------------- 7) أرصدة شاذة --------------------------- */
    IF @Part IN (0, 7)
    BEGIN
        SELECT TOP (8) a.AccCode, a.AccName,
               CASE WHEN x.AccType = 0 THEN N'أصل برصيد دائن' ELSE N'خصم/ملكية برصيد مدين' END AS Kind,
               CAST(x.Amt AS DECIMAL(28,3)) AS Amount
        FROM
        (
            SELECT m.AccID, m.AccType,
                   CASE WHEN m.AccType = 0 THEN SUM(m.Deb - m.Crd) ELSE SUM(m.Crd - m.Deb) END AS Amt
            FROM #M AS m JOIN #Leaf AS l ON l.AccID = m.AccID
            WHERE m.AccEnd = 1
            GROUP BY m.AccID, m.AccType
        ) AS x
        JOIN #Acc AS a ON a.AccID = x.AccID
        WHERE x.Amt < 0
        ORDER BY x.Amt ASC;
    END;
END;

GO

/* ---- Acc_SelectDashboardProject (2 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =====================================================================
   تحليل المشاريع (مراكز التكلفة): المصروفات فقط.
   الإيراد غير مقيّد على مراكز التكلفة في بياناتك (سطر واحد فقط)، لذلك لا يُحسب
   إيراد المشروع؛ يُعاد عدد أسطر الإيراد المقيّدة ليقرر العرض.
   @CsCID: NULL أو 0 = كل المشاريع.  المشروع الأب يشمل مشاريعه الفرعية.
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectDashboardProject]
    @Cmp         INT,
    @Year        INT,
    @CsCID       BIGINT  = NULL,
    @IncludeList BIT     = 0,
    @Part        TINYINT = 0
AS
BEGIN
    SET NOCOUNT ON;
    DROP TABLE IF EXISTS #EP;
DROP TABLE IF EXISTS #E;
DROP TABLE IF EXISTS #Anc;
DROP TABLE IF EXISTS #CC;
    IF @Cmp IS NULL OR @Cmp <= 0 THROW 53111, N'الشركة المحددة غير صحيحة.', 1;
    IF @Year IS NULL OR @Year < 1900 OR @Year > 2200 THROW 53112, N'السنة المالية غير صحيحة.', 1;

    SET @CsCID = NULLIF(@CsCID, 0);

    IF @CsCID IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
        THROW 53113, N'المشروع المحدد غير موجود أو لا يتبع الشركة.', 1;

    DECLARE @Today  DATE = CAST(GETDATE() AS DATE);
    DECLARE @YStart DATE = DATEFROMPARTS(@Year, 1, 1);
    DECLARE @YEnd   DATE = DATEFROMPARTS(@Year, 12, 31);
    DECLARE @AsOf   DATE = CASE WHEN @Today > @YEnd THEN @YEnd
                                WHEN @Today < @YStart THEN @YStart
                                ELSE @Today END;
    DECLARE @PStart DATE = DATEADD(YEAR, -1, @YStart);
    DECLARE @PAsOf  DATE = DATEADD(YEAR, -1, @AsOf);
    DECLARE @PYEnd  DATE = DATEADD(YEAR, -1, @YEnd);
    DECLARE @MoAsOf INT  = MONTH(@AsOf);

    /* مراكز التكلفة + علاقة الأب بالأحفاد (Desc → Anc) */
    SELECT CsCID, CsCParentID, CsCCode, CsCName, CsCLevel, CsCState INTO #CC
    FROM dbo.Acc_CostCenter WHERE CsCCompany = @Cmp;
    CREATE UNIQUE CLUSTERED INDEX IX_CC ON #CC (CsCID);

    ;WITH Up AS
    (
        SELECT c.CsCID AS D, c.CsCID AS A, c.CsCParentID AS P FROM #CC AS c
        UNION ALL
        SELECT u.D, p.CsCID, p.CsCParentID
        FROM Up AS u JOIN #CC AS p ON p.CsCID = u.P
        WHERE u.P > 0
    )
    SELECT D, A INTO #Anc FROM Up OPTION (MAXRECURSION 200);
    CREATE CLUSTERED INDEX IX_Anc ON #Anc (A, D);

    /* أسطر المصروفات للفترتين (الحالية والسابقة) */
    SELECT m.DayMID, m.DayMDate, d.DayDAccID AS AccID, d.DayDCsCID AS CsC,
           d.DayDDeb - d.DayDCrd AS Amt,
           CASE WHEN m.DayMDate >= @YStart THEN 1 ELSE 0 END AS IsCur
    INTO #E
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    JOIN dbo.Acc_Account    AS a ON a.AccID = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND a.AccEnd = 2 AND a.AccType = 1
      AND ((m.DayMDate >= @YStart AND m.DayMDate <= @AsOf)
        OR (m.DayMDate >= @PStart AND m.DayMDate <= @PAsOf));
    CREATE CLUSTERED INDEX IX_E ON #E (CsC);

    /* أسطر المشروع المختار (الأب يشمل أحفاده) أو كل المقيّد على مراكز تكلفة */
    SELECT e.* INTO #EP
    FROM #E AS e
    WHERE e.CsC IS NOT NULL
      AND (@CsCID IS NULL
           OR EXISTS (SELECT 1 FROM #Anc AS n WHERE n.D = e.CsC AND n.A = @CsCID));

    /* ------------------------ 1) الملخص ------------------------ */
    IF @Part IN (0, 1)
    BEGIN
        DECLARE @Cur DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 1), 0);
        DECLARE @Prv DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 0), 0);
        DECLARE @All DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1), 0);
        DECLARE @Tag DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1 AND CsC IS NOT NULL), 0);
        DECLARE @MaxMo INT, @MaxAmt DECIMAL(28,3);

        SELECT TOP (1) @MaxMo = Mo, @MaxAmt = S
        FROM (SELECT MONTH(DayMDate) AS Mo, SUM(Amt) AS S FROM #EP WHERE IsCur = 1 GROUP BY MONTH(DayMDate)) AS z
        ORDER BY S DESC;

        SELECT
            @CsCID AS CsCID,
            ISNULL((SELECT CsCCode FROM #CC WHERE CsCID = @CsCID), N'') AS CsCCode,
            ISNULL((SELECT CsCName FROM #CC WHERE CsCID = @CsCID), N'كل المشاريع') AS CsCName,
            @AsOf  AS AsOf,
            @PAsOf AS PAsOf,
            @Cur   AS ProjExp,
            @Prv   AS ProjExpPrev,
            @All   AS CompanyExp,
            @Tag   AS TaggedExp,
            @All - @Tag AS UnallocatedExp,
            CASE WHEN @All = 0 THEN NULL ELSE CAST(@Cur * 100.0 / @All AS DECIMAL(9,2)) END AS SharePct,
            (SELECT COUNT(DISTINCT MONTH(DayMDate)) FROM #EP WHERE IsCur = 1 AND Amt <> 0) AS ActiveMonths,
            @MoAsOf AS MonthsElapsed,
            CAST(@Cur / NULLIF(@MoAsOf, 0) AS DECIMAL(28,3)) AS AvgMonthly,
            @MaxMo  AS MaxMonth,
            @MaxAmt AS MaxMonthAmount,
            (SELECT COUNT(*)
               FROM dbo.Acc_DayMaster AS m
               JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
               JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
              WHERE m.DayMCompany = @Cmp AND m.DayMState = 7
                AND m.DayMDate BETWEEN @YStart AND @AsOf
                AND a.AccEnd = 2 AND a.AccType = 0
                AND d.DayDCsCID IS NOT NULL) AS RevenueTaggedLines;
    END;

    /* ------------------------ 2) الشهري ------------------------ */
    IF @Part IN (0, 2)
    BEGIN
        ;WITH Mo AS (SELECT 1 AS N UNION ALL SELECT N + 1 FROM Mo WHERE N < 12)
        SELECT
            Mo.N AS Mo,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 1 AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS ProjExp,
            CAST(ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 0 AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) AS ProjExpPrev,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1 AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS CompanyExp
        FROM Mo
        ORDER BY Mo.N;
    END;

    /* ------------------------ 3) أعلى الحسابات ------------------------ */
    IF @Part IN (0, 3)
    BEGIN
        SELECT TOP (8) a.AccCode, a.AccName,
               CAST(SUM(CASE WHEN p.IsCur = 1 THEN p.Amt ELSE 0 END) AS DECIMAL(28,3)) AS Cur,
               CAST(SUM(CASE WHEN p.IsCur = 0 THEN p.Amt ELSE 0 END) AS DECIMAL(28,3)) AS Prev
        FROM #EP AS p
        JOIN dbo.Acc_Account AS a ON a.AccID = p.AccID
        GROUP BY a.AccID, a.AccCode, a.AccName
        HAVING SUM(CASE WHEN p.IsCur = 1 THEN p.Amt ELSE 0 END) <> 0
        ORDER BY SUM(CASE WHEN p.IsCur = 1 THEN p.Amt ELSE 0 END) DESC;
    END;

    /* ------------------------ 4) ترتيب المشاريع (الصرف المباشر على كل مشروع) ------------------------ */
    IF @Part IN (0, 4)
    BEGIN
        DECLARE @TagAll DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1 AND CsC IS NOT NULL), 0);

        SELECT TOP (12)
               c.CsCID, c.CsCCode, c.CsCName,
               CAST(SUM(e.Amt) AS DECIMAL(28,3)) AS Amount,
               CASE WHEN @TagAll = 0 THEN NULL ELSE CAST(SUM(e.Amt) * 100.0 / @TagAll AS DECIMAL(9,2)) END AS SharePct,
               CAST(CASE WHEN @CsCID IS NULL THEN 0
                         WHEN EXISTS (SELECT 1 FROM #Anc AS n WHERE n.D = c.CsCID AND n.A = @CsCID) THEN 1
                         ELSE 0 END AS BIT) AS IsSelected
        FROM #E AS e
        JOIN #CC AS c ON c.CsCID = e.CsC
        WHERE e.IsCur = 1
        GROUP BY c.CsCID, c.CsCCode, c.CsCName
        HAVING SUM(e.Amt) <> 0
        ORDER BY SUM(e.Amt) DESC;
    END;

    /* ------------------------ 5) المشاريع الفرعية المباشرة ------------------------ */
    IF @Part IN (0, 5)
    BEGIN
        SELECT TOP (20)
               c.CsCID, c.CsCCode, c.CsCName,
               CAST(ISNULL(SUM(CASE WHEN e.IsCur = 1 THEN e.Amt END), 0) AS DECIMAL(28,3)) AS Cur,
               CAST(ISNULL(SUM(CASE WHEN e.IsCur = 0 THEN e.Amt END), 0) AS DECIMAL(28,3)) AS Prev
        FROM #CC AS c
        LEFT JOIN #Anc AS n ON n.A = c.CsCID
        LEFT JOIN #E   AS e ON e.CsC = n.D
        WHERE (@CsCID IS NULL AND (c.CsCParentID IS NULL OR c.CsCParentID = 0))
           OR (@CsCID IS NOT NULL AND c.CsCParentID = @CsCID)
        GROUP BY c.CsCID, c.CsCCode, c.CsCName
        HAVING ISNULL(SUM(CASE WHEN e.IsCur = 1 THEN e.Amt END), 0) <> 0
            OR ISNULL(SUM(CASE WHEN e.IsCur = 0 THEN e.Amt END), 0) <> 0
        ORDER BY ISNULL(SUM(CASE WHEN e.IsCur = 1 THEN e.Amt END), 0) DESC;
    END;

    /* ------------------------ 6) قائمة المشاريع ------------------------ */
    IF @Part IN (0, 6)
    BEGIN
        SELECT c.CsCID, c.CsCCode, c.CsCName, c.CsCLevel, c.CsCParentID,
               CAST(CASE WHEN EXISTS (SELECT 1 FROM #CC AS k WHERE k.CsCParentID = c.CsCID) THEN 1 ELSE 0 END AS BIT) AS HasChildren
        FROM #CC AS c
        WHERE @IncludeList = 1 AND c.CsCState = 0
        ORDER BY c.CsCCode;
    END;
END;

GO

/* ---- Acc_SelectAccountingTree (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountingTree]
@Cmp  INT,
@Year INT  AS  BEGIN
SET NOCOUNT ON;
DECLARE
@From DATE = DATEFROMPARTS(@Year, 1, 1),
@To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);
;WITH Accounts AS
(
SELECT
A.AccID,
A.AccCode,
A.AccName,
A.AccParentID,
A.AccLevel,
A.AccOrder,
/* هل سبق استخدام الحساب في أي تفصيل قيد؟ */
CAST(
CASE
WHEN EXISTS
(
SELECT 1
FROM dbo.Acc_DayDetails AS D
WHERE D.DayDAccID = A.AccID
)
THEN 1
ELSE 0
END
AS BIT) AS AccUsed
FROM dbo.Acc_Account AS A
WHERE A.AccCompany = @Cmp
),
Hierarchy AS
(
/* كل حساب يبدأ باعتباره أصلًا لنفسه */
SELECT
A.AccID AS DescendantID,
A.AccID AS AncestorID,
A.AccParentID AS ParentID,
0 AS Lvl
FROM Accounts AS A
UNION ALL
/* الصعود من الحساب إلى آبائه */
SELECT
H.DescendantID,
P.AccID,
P.AccParentID,
H.Lvl + 1
FROM Hierarchy AS H
INNER JOIN Accounts AS P
ON P.AccID = H.ParentID
WHERE H.ParentID IS NOT NULL
AND H.ParentID <> 0
AND H.Lvl < 30
),
Mov AS
(
/* الحركات المؤرشفة خلال السنة المالية */
SELECT
D.DayDAccID AS AccID,
SUM(D.DayDDeb) AS Deb,
SUM(D.DayDCrd) AS Crd
FROM dbo.Acc_DayMaster AS M
INNER JOIN dbo.Acc_DayDetails AS D
ON D.DayDMID = M.DayMID
INNER JOIN Accounts AS A
ON A.AccID = D.DayDAccID
WHERE M.DayMState = 7
AND M.DayMDate >= @From
AND M.DayMDate < @To
GROUP BY D.DayDAccID
),
Rollup AS
(
/* تجميع حركات كل حساب مع جميع حساباته التابعة */
SELECT
H.AncestorID AS AccID,
SUM(ISNULL(M.Deb, 0)) AS Deb,
SUM(ISNULL(M.Crd, 0)) AS Crd
FROM Hierarchy AS H
LEFT JOIN Mov AS M
ON M.AccID = H.DescendantID
GROUP BY H.AncestorID
)
SELECT
A.AccID,
A.AccCode,
A.AccName,
CAST(ISNULL(R.Deb, 0) AS DECIMAL(15,3)) AS AccDebet,
CAST(ISNULL(R.Crd, 0) AS DECIMAL(15,3)) AS AccCridit,
A.AccUsed,
A.AccParentID,
A.AccLevel,
A.AccOrder
FROM Accounts AS A
LEFT JOIN Rollup AS R
ON R.AccID = A.AccID
ORDER BY A.AccCode
OPTION (MAXRECURSION 100);
END;

GO

/* ---- Acc_SelectAccountWithBalnce (1 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ---------------------------------------------------------------------
   8) قائمة الحسابات المسموح اختيارها في القيد اليدوي (للقوائم)
      يخفي حسابات النظام التي ShowInVoucherLookup = 0.
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountWithBalnce]
    @Cmp  INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
            @To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);

    ;WITH Tree AS
    (
        SELECT a.AccID,
               CAST(N'' AS NVARCHAR(4000)) AS AccParintName,
               0 AS Lvl
        FROM dbo.Acc_Account AS a
        WHERE a.AccCompany = @Cmp
          AND a.AccParentID IS NULL

        UNION ALL

        SELECT c.AccID,
               CAST(CASE WHEN t.AccParintName = N'' THEN p.AccName
                         ELSE t.AccParintName + N' / ' + p.AccName END AS NVARCHAR(4000)),
               t.Lvl + 1
        FROM dbo.Acc_Account AS c
        JOIN Tree AS t ON c.AccParentID = t.AccID
        JOIN dbo.Acc_Account AS p ON p.AccID = t.AccID
        WHERE c.AccCompany = @Cmp AND p.AccCompany = @Cmp
          AND t.Lvl < 30
    ),
    Mov AS
    (
        SELECT d.DayDAccID AS AccID,
               SUM(d.DayDDeb) AS Deb,
               SUM(d.DayDCrd) AS Crd
        FROM dbo.Acc_DayMaster AS m
        JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
        WHERE m.DayMState = 7
          AND m.DayMDate >= @From
          AND m.DayMDate < @To
        GROUP BY d.DayDAccID
    )
    SELECT a.AccID,
           a.AccCode,
           a.AccName,
           a.AccState,
           t.AccParintName,
           CASE WHEN t.AccParintName = N'' THEN a.AccName
                ELSE t.AccParintName + N' / ' + a.AccName END AS Parents,
           CASE WHEN ISNULL(x.Deb, 0) > ISNULL(x.Crd, 0)
                THEN x.Deb - x.Crd ELSE 0 END AS AccDebet,
           CASE WHEN ISNULL(x.Crd, 0) > ISNULL(x.Deb, 0)
                THEN x.Crd - x.Deb ELSE 0 END AS AccCridit,
           a.AccCompany
    FROM dbo.Acc_Account AS a
    JOIN Tree AS t ON t.AccID = a.AccID
    LEFT JOIN Mov AS x ON x.AccID = a.AccID
    WHERE a.AccState = 0
      AND a.AccChid = 0
      AND a.AccCompany = @Cmp
      AND NOT EXISTS (SELECT 1
                      FROM dbo.Acc_PostingRule  AS r
                      JOIN dbo.Acc_PostingState AS s ON s.StateID = r.StateID
                      WHERE r.AccID = a.AccID
                        AND s.ShowInVoucherLookup = 0)
    ORDER BY a.AccCode;
END;

GO

/* ---- Acc_SelectDashboard (3 تعديل) ---- */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =====================================================================
   Acc_SelectDashboard — بيانات لوحة المحاسبة (قراءة فقط)
   المدخلات: @Cmp, @Year
   القيود المحتسبة: DayMState من 1 إلى 7 (كل ما عدا المؤقت)
   المخرجات (7 مجموعات بالترتيب):
     1) KPI      : صف واحد بالمؤشرات
     2) Monthly  : 12 صفًا (الإيراد والمصروف لكل شهر)
     3) States   : 8 صفوف (عدد القيود لكل حالة 0..7 في السنة)
     4) Latest   : آخر 8 قيود
     5) TopExp   : أعلى 5 حسابات مصروفات
     6) Cash     : أرصدة حسابات النقدية (حتى 6 حسابات)
     7) Health   : مؤشرات سلامة (قيود مُرحّلة غير متوازنة، قيود مؤقتة قديمة)
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectDashboard]
    @Cmp  INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;
    DROP TABLE IF EXISTS #CashBal;
DROP TABLE IF EXISTS #CashLeaf;
DROP TABLE IF EXISTS #Acc;
DROP TABLE IF EXISTS #Y;
    IF @Cmp IS NULL OR @Cmp <= 0 THROW 53001, N'الشركة المحددة غير صحيحة.', 1;
    IF @Year IS NULL OR @Year < 1900 OR @Year > 2200 THROW 53002, N'السنة المالية غير صحيحة.', 1;

    DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
            @To   DATE = DATEFROMPARTS(@Year, 12, 31);

    /* حركات السنة (غير المؤقتة) مع تصنيف الحساب */
    SELECT m.DayMID, m.DayMDate, d.DayDAccID, d.DayDDeb, d.DayDCrd,
           a.AccEnd, a.AccType
    INTO #Y
    FROM dbo.Acc_DayMaster AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    JOIN dbo.Acc_Account   AS a ON a.AccID = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate >= @From AND m.DayMDate <= @To;

    /* ---------- النقدية: الحسابات التحليلية تحت تصنيف CashFlowType = 1 ---------- */
    SELECT AccID, AccParentID INTO #Acc FROM dbo.Acc_Account WHERE AccCompany = @Cmp;

    ;WITH Up AS
    (
        SELECT a.AccID AS LeafID, a.AccID AS NodeID, a.AccParentID AS ParentID, 0 AS Dist
        FROM #Acc AS a
        UNION ALL
        SELECT u.LeafID, p.AccID, p.AccParentID, u.Dist + 1
        FROM Up AS u JOIN #Acc AS p ON p.AccID = u.ParentID
        WHERE u.ParentID > 0
    )
    SELECT DISTINCT u.LeafID AS AccID
    INTO #CashLeaf
    FROM Up AS u
    JOIN dbo.Acc_CashFlowAccounts AS c ON c.AccID = u.NodeID AND c.CashFlowType = 1
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS k WHERE k.AccParentID = u.LeafID)
    OPTION (MAXRECURSION 200);

    SELECT l.AccID,
           CAST(SUM(d.DayDDeb - d.DayDCrd) AS DECIMAL(28,3)) AS Bal
    INTO #CashBal
    FROM #CashLeaf AS l
    JOIN dbo.Acc_DayDetails AS d ON d.DayDAccID = l.AccID
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE m.DayMCompany = @Cmp AND m.DayMState = 7 AND m.DayMDate <= @To
    GROUP BY l.AccID;

    /* ---------- 1) KPI ---------- */
    DECLARE @Rev DECIMAL(28,3) =
        (SELECT ISNULL(SUM(DayDCrd - DayDDeb), 0) FROM #Y WHERE AccEnd = 2 AND AccType = 0);
    DECLARE @Exp DECIMAL(28,3) =
        (SELECT ISNULL(SUM(DayDDeb - DayDCrd), 0) FROM #Y WHERE AccEnd = 2 AND AccType = 1);

    SELECT
        @Rev AS Revenue,
        @Exp AS Expenses,
        @Rev - @Exp AS NetProfit,
        (SELECT ISNULL(SUM(Bal), 0) FROM #CashBal) AS CashBalance,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState BETWEEN 1 AND 7
            AND DayMDate BETWEEN @From AND @To) AS PostedCount,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState = 0
            AND DayMDate BETWEEN @From AND @To) AS DraftCount,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState IN (2, 4, 6)
            AND DayMDate BETWEEN @From AND @To) AS ReturnedCount,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState = 1
            AND DayMDate BETWEEN @From AND @To) AS AwaitingReviewCount;

    /* ---------- 2) الشهري ---------- */
    ;WITH M AS (SELECT 1 AS Mo UNION ALL SELECT Mo + 1 FROM M WHERE Mo < 12)
    SELECT M.Mo,
           CAST(ISNULL(SUM(CASE WHEN y.AccEnd = 2 AND y.AccType = 0 THEN y.DayDCrd - y.DayDDeb END), 0) AS DECIMAL(28,3)) AS Revenue,
           CAST(ISNULL(SUM(CASE WHEN y.AccEnd = 2 AND y.AccType = 1 THEN y.DayDDeb - y.DayDCrd END), 0) AS DECIMAL(28,3)) AS Expenses
    FROM M
    LEFT JOIN #Y AS y ON MONTH(y.DayMDate) = M.Mo
    GROUP BY M.Mo
    ORDER BY M.Mo;

    /* ---------- 3) الحالات ---------- */
    ;WITH S AS (SELECT CAST(0 AS TINYINT) AS St UNION ALL SELECT CAST(St + 1 AS TINYINT) FROM S WHERE St < 7)
    SELECT S.St AS DayMState,
           CASE S.St
                WHEN 0 THEN N'مؤقت'
                WHEN 1 THEN N'مُرحّل'
                WHEN 2 THEN N'مُعاد للمحاسب'
                WHEN 3 THEN N'اعتُمد من المراجعة'
                WHEN 4 THEN N'مُعاد للمراجعة'
                WHEN 5 THEN N'اعتمده المدير المالي'
                WHEN 6 THEN N'مُعاد للمدير المالي'
                WHEN 7 THEN N'مُؤرشف'
           END AS StateName,
           (SELECT COUNT(*) FROM dbo.Acc_DayMaster AS m
             WHERE m.DayMCompany = @Cmp AND m.DayMState = S.St
               AND m.DayMDate BETWEEN @From AND @To) AS Cnt
    FROM S
    ORDER BY S.St;

    /* ---------- 4) آخر القيود ---------- */
    SELECT TOP (8)
           m.DayMID,
           CASE WHEN m.DayMNo > 0
                THEN CONCAT(m.DayMNo, N'/', RIGHT(CONCAT(N'0', MONTH(m.DayMDate)), 2))
                ELSE N'—' END AS VoucherNo,
           m.DayMDate,
           m.DayMDescription,
           m.DayMState,
           CAST(ISNULL(t.TotDeb, 0) AS DECIMAL(28,3)) AS Amount
    FROM dbo.Acc_DayMaster AS m
    OUTER APPLY (SELECT SUM(d.DayDDeb) AS TotDeb FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS t
    WHERE m.DayMCompany = @Cmp AND m.DayMDate BETWEEN @From AND @To
    ORDER BY m.DayMID DESC;

    /* ---------- 5) أعلى المصروفات ---------- */
    SELECT TOP (5)
           a.AccCode, a.AccName,
           CAST(SUM(y.DayDDeb - y.DayDCrd) AS DECIMAL(28,3)) AS Amount
    FROM #Y AS y
    JOIN dbo.Acc_Account AS a ON a.AccID = y.DayDAccID
    WHERE y.AccEnd = 2 AND y.AccType = 1
    GROUP BY a.AccID, a.AccCode, a.AccName
    HAVING SUM(y.DayDDeb - y.DayDCrd) <> 0
    ORDER BY SUM(y.DayDDeb - y.DayDCrd) DESC;

    /* ---------- 6) النقدية ---------- */
    SELECT TOP (6) a.AccCode, a.AccName, b.Bal AS Balance
    FROM #CashBal AS b
    JOIN dbo.Acc_Account AS a ON a.AccID = b.AccID
    WHERE b.Bal <> 0
    ORDER BY ABS(b.Bal) DESC;

    /* ---------- 7) السلامة ---------- */
    SELECT
        (SELECT COUNT(*) FROM
            (SELECT d.DayDMID
               FROM dbo.Acc_DayMaster AS m
               JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
              WHERE m.DayMCompany = @Cmp AND m.DayMState = 7
                AND m.DayMDate BETWEEN @From AND @To
              GROUP BY d.DayDMID
             HAVING SUM(d.DayDDeb) <> SUM(d.DayDCrd)) AS x) AS UnbalancedPosted,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState = 0
            AND DayMDate BETWEEN @From AND @To
            AND DayMDateTime < DATEADD(DAY, -7, SYSUTCDATETIME())) AS StaleDrafts;
END;

GO

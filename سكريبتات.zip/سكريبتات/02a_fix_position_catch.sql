﻿USE [MADARERPDataBase]
GO
/* إصلاح CATCH: إعادة THROW وعدم ابتلاع الأخطاء */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[sp_Save_Emp_Position]
    @Emp_PosID      BIGINT = NULL OUTPUT,
    @Emp_PosName    NVARCHAR(255),
    @Emp_PosCmp     INT,
    @EmpOrgStrID    BIGINT,
    @EmpJobID       BIGINT,
    @Emp_SpyID      BIGINT = NULL,
    @Emp_EduQualID  BIGINT = NULL,
    @Emp_SchTypeID  BIGINT,
    @Emp_PosState   TINYINT = 0,
    @Emp_PosUser    BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF; -- النمط السليم لدعم المعاملات المتداخلة وتجنب الخطأ 3931

    -- 1. التحقق من المدخلات الأساسية
    IF ISNULL(@Emp_PosCmp, 0) <= 0
        THROW 50020, N'يجب تحديد الشركة بشكل صحيح.', 1;

    IF LTRIM(RTRIM(ISNULL(@Emp_PosName, N''))) = N''
        THROW 50021, N'يجب إدخال اسم المنصب.', 1;

    IF ISNULL(@Emp_PosUser, 0) <= 0
        THROW 50022, N'يجب تحديد مستخدم النظام.', 1;

    IF @Emp_PosState IS NULL OR @Emp_PosState NOT IN (0, 1)
        THROW 50023, N'حالة المنصب غير صالحة.', 1;

    -- 2. التحقق من وجود الشركة والمستخدم في النظام
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @Emp_PosCmp)
        THROW 50024, N'الشركة غير موجودة.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @Emp_PosUser)
        THROW 50025, N'مستخدم النظام غير موجود.', 1;

    -- 3. التحقق من تطابق تبعية السجلات لنفس الشركة (عزل الشركات التام)
    IF NOT EXISTS (SELECT 1 FROM dbo.Emp_OrganigramStructure WHERE EmpOrgStrCompany = @Emp_PosCmp AND EmpOrgStrID = @EmpOrgStrID)
        THROW 50026, N'الوحدة التنظيمية غير موجودة أو لا تتبع لهذه الشركة.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Emp_JobTitles WHERE EmpJobCompany = @Emp_PosCmp AND EmpJobID = @EmpJobID)
        THROW 50027, N'المسمى الوظيفي غير موجود أو لا يتبع لهذه الشركة.', 1;

    IF @Emp_SpyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Emp_Specialty WHERE Emp_SpyCmp = @Emp_PosCmp AND Emp_SpyID = @Emp_SpyID)
        THROW 50028, N'التخصص المطلوب غير موجود أو لا يتبع لهذه الشركة.', 1;

    IF @Emp_EduQualID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Emp_EducationalQualifications WHERE Emp_EduQualCmp = @Emp_PosCmp AND Emp_EduQualID = @Emp_EduQualID)
        THROW 50029, N'المؤهل العلمي غير موجود أو لا يتبع لهذه الشركة.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Emp_WorkScheduleTypes WHERE Emp_SchTypeCmp = @Emp_PosCmp AND Emp_SchTypeID = @Emp_SchTypeID)
        THROW 50030, N'نوع جدول العمل غير موجود أو لا يتبع لهذه الشركة.', 1;

    -- 4. إدارة المعاملات الآمنة مع دعم المعاملات الخارجية (Nested Transactions Support)
    DECLARE @TranStarted INT = 0;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
        BEGIN
            SAVE TRANSACTION SavePoint_Emp_Position;
        END

        IF ISNULL(@Emp_PosID, 0) <= 0
        BEGIN
            -- عملية الإدراج (INSERT)
            INSERT INTO dbo.Emp_Position
            (
                Emp_PosName,
                Emp_PosCmp,
                EmpOrgStrID,
                EmpJobID,
                Emp_SpyID,
                Emp_EduQualID,
                Emp_SchTypeID,
                Emp_PosState,
                Emp_PosDate,
                Emp_PosUser
            )
            VALUES
            (
                LTRIM(RTRIM(@Emp_PosName)),
                @Emp_PosCmp,
                @EmpOrgStrID,
                @EmpJobID,
                @Emp_SpyID,
                @Emp_EduQualID,
                @Emp_SchTypeID,
                @Emp_PosState,
                SYSDATETIME(),
                @Emp_PosUser
            );

            SET @Emp_PosID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            -- عملية التحديث (UPDATE)
            IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Position WHERE Emp_PosID = @Emp_PosID AND Emp_PosCmp = @Emp_PosCmp)
                THROW 50031, N'المنصب المراد تعديله غير موجود أو لا يتبع لهذه الشركة.', 1;

            UPDATE dbo.Emp_Position
            SET Emp_PosName   = LTRIM(RTRIM(@Emp_PosName)),
                EmpOrgStrID   = @EmpOrgStrID,
                EmpJobID      = @EmpJobID,
                Emp_SpyID     = @Emp_SpyID,
                Emp_EduQualID = @Emp_EduQualID,
                Emp_SchTypeID = @Emp_SchTypeID,
                Emp_PosState  = @Emp_PosState,
                Emp_PosDate   = SYSDATETIME(),
                Emp_PosUser   = @Emp_PosUser
            WHERE Emp_PosID = @Emp_PosID
              AND Emp_PosCmp = @Emp_PosCmp;
        END

        IF @TranStarted = 1 AND @@TRANCOUNT > 0
            COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_Emp_Position;

        THROW;
    END CATCH
END;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[sp_UpdateState_Emp_Position]
    @Emp_PosID      BIGINT,
    @Emp_PosCmp     INT,
    @Emp_PosState   TINYINT, -- 0: نشط (Active), 1: معطل (Inactive)
    @Emp_PosUser    BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF; -- دعم المعاملات المتداخلة وتجنب الخطأ 3931

    -- 1. التحقق من صحة المدخلات الأساسية
    IF ISNULL(@Emp_PosID, 0) <= 0
        THROW 50032, N'معرّف المنصب غير صحيح.', 1;

    IF ISNULL(@Emp_PosCmp, 0) <= 0
        THROW 50020, N'يجب تحديد الشركة بشكل صحيح.', 1;

    IF ISNULL(@Emp_PosUser, 0) <= 0
        THROW 50022, N'يجب تحديد مستخدم النظام.', 1;

    IF @Emp_PosState IS NULL OR @Emp_PosState NOT IN (0, 1)
        THROW 50023, N'حالة المنصب غير صالحة.', 1;

    -- 2. التحقق من وجود الشركة والمستخدم في النظام
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @Emp_PosCmp)
        THROW 50024, N'الشركة غير موجودة.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @Emp_PosUser)
        THROW 50025, N'مستخدم النظام غير موجود.', 1;

    -- 3. التحقق من وجود المنصب وأنه يتبع حصراً لهذه الشركة (عزل الشركات)
    IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Position WHERE Emp_PosID = @Emp_PosID AND Emp_PosCmp = @Emp_PosCmp)
        THROW 50031, N'المنصب غير موجود أو لا يتبع لهذه الشركة.', 1;

    -- (ملاحظة معمارية مستقبلية عند بناء جدول الموظفين:
    --  يمكن هنا إضافة التحقق من عدم وجود موظفين نشطين معينين على هذا المنصب في حال كان المطلوب هو التعطيل @Emp_PosState = 1)

    -- 4. إدارة المعاملات الآمنة مع دعم المعاملات الخارجية (Nested Transactions)
    DECLARE @TranStarted INT = 0;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
        BEGIN
            SAVE TRANSACTION SavePoint_UpdateState_Pos;
        END

        -- تحديث حالة المنصب فقط مع تسجيل بيانات التدقيق
        UPDATE dbo.Emp_Position
        SET Emp_PosState = @Emp_PosState,
            Emp_PosDate  = SYSDATETIME(),
            Emp_PosUser  = @Emp_PosUser
        WHERE Emp_PosID = @Emp_PosID
          AND Emp_PosCmp = @Emp_PosCmp;

        IF @TranStarted = 1 AND @@TRANCOUNT > 0
            COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_UpdateState_Pos;

        THROW;
    END CATCH
END;
GO

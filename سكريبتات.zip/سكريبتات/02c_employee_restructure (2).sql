USE [MADARERPDataBase]
GO
/* =====================================================================
   02c: إعادة هيكلة بيانات الموظف (بأسلوب ALTER الآمن)
   ---------------------------------------------------------------------
   Emp_Employee        : الجدول النحيف (الهوية الإدارية)
   Emp_ContractSalary  : العقود والرواتب والتاريخ (سجل لكل فترة)
   Emp_PersonalDetails : البيانات الشخصية (1:1)

   قبل التشغيل تأكد أن:  SELECT COUNT(*) FROM dbo.Emp_Employee WHERE EmpCompany IS NULL  = 0
   إن ظهر أي خطأ في دفعة، أوقف التنفيذ ولا تكمل (GO لا يوقف الدفعات التالية).

   افتراضات تحتاج تأكيدك (موضحة بعلامة [افتراض]):
   [افتراض 1] EmpGender: 1 ذكر، 2 أنثى.
   [افتراض 2] EmpSocial = الحالة الاجتماعية: 1 أعزب، 2 متزوج، 3 مطلق، 4 أرمل.
   [افتراض 3] EmpQualification = المؤهل العلمي (Emp_EducationalQualifications).
   [افتراض 4] EmpWorkSite بلا مفتاح أجنبي حتى يتحدد جدول مواقع العمل.
   [افتراض 5] EmpState: 0 فعال، 1 غير فعال. (لا تعطيل تلقائي لحساب المستخدم)
   [افتراض 6] EmpAddress بطول 500 حرف بدل MAX.
   ===================================================================== */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------------
-- 1. Emp_Employee: شركة إلزامية + قيد فريد مرجعي + أعمدة المنصب والصورة
--------------------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM sys.columns
           WHERE object_id = OBJECT_ID('dbo.Emp_Employee')
             AND name = 'EmpCompany' AND is_nullable = 1)
    ALTER TABLE [dbo].[Emp_Employee] ALTER COLUMN [EmpCompany] INT NOT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.key_constraints
               WHERE name = 'UQ_Emp_Employee_Cmp_ID'
                 AND parent_object_id = OBJECT_ID('dbo.Emp_Employee'))
    ALTER TABLE [dbo].[Emp_Employee]
        ADD CONSTRAINT [UQ_Emp_Employee_Cmp_ID] UNIQUE NONCLUSTERED ([EmpCompany], [EmpID]);
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.Emp_Employee') AND name = 'Emp_PosID')
    ALTER TABLE [dbo].[Emp_Employee] ADD [Emp_PosID] BIGINT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.Emp_Employee') AND name = 'EmpPicPath')
    ALTER TABLE [dbo].[Emp_Employee] ADD [EmpPicPath] NVARCHAR(500) NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Emp_Employee_Company'
               AND parent_object_id = OBJECT_ID('dbo.Emp_Employee'))
    ALTER TABLE [dbo].[Emp_Employee] WITH CHECK ADD CONSTRAINT [FK_Emp_Employee_Company]
        FOREIGN KEY ([EmpCompany]) REFERENCES [dbo].[Mng_Company] ([CmpID]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Emp_Employee_Position'
               AND parent_object_id = OBJECT_ID('dbo.Emp_Employee'))
    ALTER TABLE [dbo].[Emp_Employee] WITH CHECK ADD CONSTRAINT [FK_Emp_Employee_Position]
        FOREIGN KEY ([EmpCompany], [Emp_PosID]) REFERENCES [dbo].[Emp_Position] ([Emp_PosCmp], [Emp_PosID]);
GO

--------------------------------------------------------------------------------
-- 2. قيود فريدة (الشركة + المعرف) على الجداول المرجعية لتصلح للربط المركب
--------------------------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints
               WHERE name = 'UQ_Emp_Nationality_Cmp_ID'
                 AND parent_object_id = OBJECT_ID('dbo.Emp_Nationality'))
    ALTER TABLE [dbo].[Emp_Nationality]
        ADD CONSTRAINT [UQ_Emp_Nationality_Cmp_ID] UNIQUE NONCLUSTERED ([Emp_NatCmp], [Emp_NatID]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints
               WHERE name = 'UQ_Emp_EmploymentTypes_Cmp_ID'
                 AND parent_object_id = OBJECT_ID('dbo.Emp_EmploymentTypes'))
    ALTER TABLE [dbo].[Emp_EmploymentTypes]
        ADD CONSTRAINT [UQ_Emp_EmploymentTypes_Cmp_ID] UNIQUE NONCLUSTERED ([Emp_EmpTypeCmp], [Emp_EmpTypeID]);
GO

--------------------------------------------------------------------------------
-- 3. Emp_ContractSalary: سجل تاريخي للعقد والراتب وموقع العمل
--------------------------------------------------------------------------------
IF OBJECT_ID(N'[dbo].[Emp_ContractSalary]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Emp_ContractSalary](
        [ContractID]        BIGINT IDENTITY(1,1) NOT NULL,
        [EmpCompany]        INT NOT NULL,
        [EmpID]             BIGINT NOT NULL,
        [EmpContractType]   BIGINT NOT NULL,
        [EmpDirectDate]     DATE NOT NULL,          -- بداية سريان العقد/الراتب (شاملة)
        [EmpEndDate]        DATE NULL,              -- نهاية السريان (شاملة)، NULL = ساري حالياً
        [EmpSalary]         DECIMAL(15,3) NOT NULL,
        [EmpWorkSite]       BIGINT NULL,            -- [افتراض 4] بلا FK حالياً
        [EmpUser]           BIGINT NOT NULL,
        [EmpDateTime]       DATETIME NOT NULL CONSTRAINT [DF_Emp_ContractSalary_DateTime] DEFAULT (GETDATE()),

        CONSTRAINT [PK_Emp_ContractSalary] PRIMARY KEY CLUSTERED ([ContractID] ASC),
        CONSTRAINT [CK_Emp_ContractSalary_Salary] CHECK ([EmpSalary] >= 0),
        CONSTRAINT [CK_Emp_ContractSalary_Dates] CHECK ([EmpEndDate] IS NULL OR [EmpEndDate] >= [EmpDirectDate]),
        CONSTRAINT [FK_Emp_ContractSalary_Employee] FOREIGN KEY ([EmpCompany], [EmpID])
            REFERENCES [dbo].[Emp_Employee] ([EmpCompany], [EmpID]),
        CONSTRAINT [FK_Emp_ContractSalary_ContractType] FOREIGN KEY ([EmpCompany], [EmpContractType])
            REFERENCES [dbo].[Emp_EmploymentTypes] ([Emp_EmpTypeCmp], [Emp_EmpTypeID]),
        CONSTRAINT [FK_Emp_ContractSalary_User] FOREIGN KEY ([EmpUser])
            REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];

    -- عقد ساري واحد فقط لكل موظف
    CREATE UNIQUE NONCLUSTERED INDEX [UX_Emp_ContractSalary_Active]
        ON [dbo].[Emp_ContractSalary] ([EmpCompany] ASC, [EmpID] ASC)
        WHERE [EmpEndDate] IS NULL;

    CREATE NONCLUSTERED INDEX [IX_Emp_ContractSalary_Employee]
        ON [dbo].[Emp_ContractSalary] ([EmpCompany] ASC, [EmpID] ASC, [EmpDirectDate] ASC);
END
GO

--------------------------------------------------------------------------------
-- 4. Emp_PersonalDetails: البيانات الشخصية (1:1)
--------------------------------------------------------------------------------
IF OBJECT_ID(N'[dbo].[Emp_PersonalDetails]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Emp_PersonalDetails](
        [EmpCompany]        INT NOT NULL,
        [EmpID]             BIGINT NOT NULL,
        [EmpGender]         TINYINT NULL,           -- [افتراض 1]
        [EmpNat]            BIGINT NULL,
        [EmpBDate]          DATE NULL,
        [EmpBPlace]         NVARCHAR(50) NULL,
        [EmpSocial]         TINYINT NULL,           -- [افتراض 2]
        [EmpCardNum]        NVARCHAR(25) NULL,
        [EmpQualification]  BIGINT NULL,            -- [افتراض 3]
        [EmpPhone]          NVARCHAR(15) NULL,
        [EmpAddress]        NVARCHAR(500) NULL,     -- [افتراض 6]
        [EmpNots]           NVARCHAR(MAX) NULL,
        [EmpUser]           BIGINT NOT NULL,
        [EmpDateTime]       DATETIME NOT NULL CONSTRAINT [DF_Emp_PersonalDetails_DateTime] DEFAULT (GETDATE()),

        CONSTRAINT [PK_Emp_PersonalDetails] PRIMARY KEY CLUSTERED ([EmpCompany] ASC, [EmpID] ASC),
        CONSTRAINT [CK_Emp_PersonalDetails_Gender] CHECK ([EmpGender] IN (1, 2)),
        CONSTRAINT [CK_Emp_PersonalDetails_Social] CHECK ([EmpSocial] BETWEEN 1 AND 4),
        CONSTRAINT [FK_Emp_PersonalDetails_Employee] FOREIGN KEY ([EmpCompany], [EmpID])
            REFERENCES [dbo].[Emp_Employee] ([EmpCompany], [EmpID]),
        CONSTRAINT [FK_Emp_PersonalDetails_Nationality] FOREIGN KEY ([EmpCompany], [EmpNat])
            REFERENCES [dbo].[Emp_Nationality] ([Emp_NatCmp], [Emp_NatID]),
        CONSTRAINT [FK_Emp_PersonalDetails_Qualification] FOREIGN KEY ([EmpCompany], [EmpQualification])
            REFERENCES [dbo].[Emp_EducationalQualifications] ([Emp_EduQualCmp], [Emp_EduQualID]),
        CONSTRAINT [FK_Emp_PersonalDetails_User] FOREIGN KEY ([EmpUser])
            REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];

    -- عدم تكرار رقم الهوية داخل الشركة
    CREATE UNIQUE NONCLUSTERED INDEX [UX_Emp_PersonalDetails_CardNum]
        ON [dbo].[Emp_PersonalDetails] ([EmpCompany] ASC, [EmpCardNum] ASC)
        WHERE [EmpCardNum] IS NOT NULL;
END
GO

--------------------------------------------------------------------------------
-- 5. Emp_SaveEmployee: حفظ الموظف + بياناته الشخصية
--    - الحقول الشخصية: حفظ كامل (NULL يمسح القيمة)
--    - EmpPicPath: NULL يعني إبقاء المسار الحالي
--    - الراتب والعقد من اختصاص Emp_InsertContractSalary فقط
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[Emp_SaveEmployee]
    @EmpID              BIGINT = NULL OUTPUT,
    @EmpCompany         INT,
    @EmpNum             NVARCHAR(10) = NULL,
    @EmpName            NVARCHAR(50),
    @Emp_PosID          BIGINT = NULL,
    @EmpPicPath         NVARCHAR(500) = NULL,
    @EmpState           TINYINT = 0,
    @EmpUser            BIGINT,
    @EmpGender          TINYINT = NULL,
    @EmpNat             BIGINT = NULL,
    @EmpBDate           DATE = NULL,
    @EmpBPlace          NVARCHAR(50) = NULL,
    @EmpSocial          TINYINT = NULL,
    @EmpCardNum         NVARCHAR(25) = NULL,
    @EmpQualification   BIGINT = NULL,
    @EmpPhone           NVARCHAR(15) = NULL,
    @EmpAddress         NVARCHAR(500) = NULL,
    @EmpNots            NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50069, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    -- تنقية المدخلات
    SET @EmpNum        = NULLIF(LTRIM(RTRIM(@EmpNum)), N'');
    SET @EmpName       = NULLIF(LTRIM(RTRIM(@EmpName)), N'');
    SET @EmpPicPath    = NULLIF(LTRIM(RTRIM(@EmpPicPath)), N'');
    SET @EmpBPlace     = NULLIF(LTRIM(RTRIM(@EmpBPlace)), N'');
    SET @EmpCardNum    = NULLIF(LTRIM(RTRIM(@EmpCardNum)), N'');
    SET @EmpPhone      = NULLIF(LTRIM(RTRIM(@EmpPhone)), N'');
    SET @EmpAddress    = NULLIF(LTRIM(RTRIM(@EmpAddress)), N'');
    SET @EmpNots       = NULLIF(LTRIM(RTRIM(@EmpNots)), N'');

    -- التحقق الشكلي
    IF @EmpID IS NOT NULL AND @EmpID < 0
        THROW 50068, N'معرف الموظف غير صالح.', 1;
    IF @EmpCompany IS NULL OR @EmpCompany <= 0
        THROW 50060, N'معرف الشركة غير صالح أو غير مدخل.', 1;
    IF @EmpName IS NULL
        THROW 50061, N'اسم الموظف إلزامي.', 1;
    IF @EmpUser IS NULL OR @EmpUser <= 0
        THROW 50062, N'معرف المستخدم غير صالح أو مفقود.', 1;
    IF @EmpState IS NULL OR @EmpState NOT IN (0, 1)
        THROW 50070, N'حالة الموظف غير صالحة.', 1;
    IF @EmpGender IS NOT NULL AND @EmpGender NOT IN (1, 2)
        THROW 50071, N'قيمة الجنس غير صالحة.', 1;
    IF @EmpSocial IS NOT NULL AND @EmpSocial NOT BETWEEN 1 AND 4
        THROW 50072, N'قيمة الحالة الاجتماعية غير صالحة.', 1;
    IF @EmpBDate IS NOT NULL AND (@EmpBDate < '19000101' OR @EmpBDate > CAST(GETDATE() AS DATE))
        THROW 50073, N'تاريخ الميلاد غير منطقي.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @OldPos BIGINT = NULL, @OldNat BIGINT = NULL, @OldQual BIGINT = NULL;
    DECLARE @HasPersonal BIT = 0;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_SaveEmployee;

        -- الشركة والمستخدم
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @EmpCompany)
            THROW 50066, N'الشركة غير مسجلة.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WITH (UPDLOCK, HOLDLOCK) WHERE UsrID = @EmpUser)
            THROW 50067, N'مستخدم النظام غير مسجل.', 1;

        -- القيم الحالية عند التعديل
        IF @EmpID IS NOT NULL AND @EmpID > 0
        BEGIN
            SELECT @OldPos = Emp_PosID
            FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
            WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany;

            IF @@ROWCOUNT = 0
                THROW 50065, N'الموظف غير موجود في نطاق هذه الشركة.', 1;

            SELECT @OldNat = EmpNat, @OldQual = EmpQualification, @HasPersonal = 1
            FROM dbo.Emp_PersonalDetails WITH (UPDLOCK, HOLDLOCK)
            WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany;
        END

        -- المنصب: تابع للشركة وفعال (أو بلا تغيير)
        IF @Emp_PosID IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM dbo.Emp_Position WITH (UPDLOCK, HOLDLOCK)
            WHERE Emp_PosID = @Emp_PosID AND Emp_PosCmp = @EmpCompany
              AND (Emp_PosState = 0 OR Emp_PosID = @OldPos))
            THROW 50063, N'المنصب غير موجود أو لا يتبع لهذه الشركة أو معطّل.', 1;

        -- الجنسية
        IF @EmpNat IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM dbo.Emp_Nationality WITH (UPDLOCK, HOLDLOCK)
            WHERE Emp_NatID = @EmpNat AND Emp_NatCmp = @EmpCompany
              AND (Emp_NatState = 0 OR Emp_NatID = @OldNat))
            THROW 50074, N'الجنسية غير موجودة أو لا تتبع لهذه الشركة أو معطّلة.', 1;

        -- المؤهل العلمي
        IF @EmpQualification IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM dbo.Emp_EducationalQualifications WITH (UPDLOCK, HOLDLOCK)
            WHERE Emp_EduQualID = @EmpQualification AND Emp_EduQualCmp = @EmpCompany
              AND (Emp_EduQualState = 0 OR Emp_EduQualID = @OldQual))
            THROW 50075, N'المؤهل العلمي غير موجود أو لا يتبع لهذه الشركة أو معطّل.', 1;

        -- تكرار الكود الوظيفي داخل الشركة
        IF @EmpNum IS NOT NULL AND EXISTS (
            SELECT 1 FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
            WHERE EmpCompany = @EmpCompany AND EmpNum = @EmpNum
              AND (@EmpID IS NULL OR @EmpID = 0 OR EmpID <> @EmpID))
            THROW 50064, N'رقم الموظف مستخدم لموظف آخر في هذه الشركة.', 1;

        -- تكرار رقم الهوية داخل الشركة
        IF @EmpCardNum IS NOT NULL AND EXISTS (
            SELECT 1 FROM dbo.Emp_PersonalDetails WITH (UPDLOCK, HOLDLOCK)
            WHERE EmpCompany = @EmpCompany AND EmpCardNum = @EmpCardNum
              AND (@EmpID IS NULL OR @EmpID = 0 OR EmpID <> @EmpID))
            THROW 50076, N'رقم الهوية مستخدم لموظف آخر في هذه الشركة.', 1;

        -- الموظف: تعديل أو إدراج
        IF @EmpID IS NOT NULL AND @EmpID > 0
        BEGIN
            UPDATE dbo.Emp_Employee
            SET EmpNum      = @EmpNum,
                EmpName     = @EmpName,
                Emp_PosID   = @Emp_PosID,
                EmpPicPath  = COALESCE(@EmpPicPath, EmpPicPath),
                EmpState    = @EmpState,
                EmpUser     = @EmpUser,
                EmpDateTime = GETDATE()
            WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany;
        END
        ELSE
        BEGIN
            INSERT dbo.Emp_Employee
                (EmpCompany, EmpNum, EmpName, Emp_PosID, EmpPicPath, EmpState, EmpUser, EmpDateTime)
            VALUES
                (@EmpCompany, @EmpNum, @EmpName, @Emp_PosID, @EmpPicPath, @EmpState, @EmpUser, GETDATE());

            SET @EmpID = SCOPE_IDENTITY();
        END

        -- البيانات الشخصية
        IF @HasPersonal = 1
        BEGIN
            UPDATE dbo.Emp_PersonalDetails
            SET EmpGender = @EmpGender, EmpNat = @EmpNat, EmpBDate = @EmpBDate,
                EmpBPlace = @EmpBPlace, EmpSocial = @EmpSocial, EmpCardNum = @EmpCardNum,
                EmpQualification = @EmpQualification, EmpPhone = @EmpPhone,
                EmpAddress = @EmpAddress, EmpNots = @EmpNots,
                EmpUser = @EmpUser, EmpDateTime = GETDATE()
            WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany;
        END
        ELSE IF COALESCE(@EmpGender, @EmpSocial) IS NOT NULL
             OR COALESCE(@EmpNat, @EmpQualification) IS NOT NULL
             OR @EmpBDate IS NOT NULL
             OR COALESCE(@EmpBPlace, @EmpCardNum, @EmpPhone, @EmpAddress, @EmpNots) IS NOT NULL
        BEGIN
            INSERT dbo.Emp_PersonalDetails
                (EmpCompany, EmpID, EmpGender, EmpNat, EmpBDate, EmpBPlace, EmpSocial,
                 EmpCardNum, EmpQualification, EmpPhone, EmpAddress, EmpNots, EmpUser, EmpDateTime)
            VALUES
                (@EmpCompany, @EmpID, @EmpGender, @EmpNat, @EmpBDate, @EmpBPlace, @EmpSocial,
                 @EmpCardNum, @EmpQualification, @EmpPhone, @EmpAddress, @EmpNots, @EmpUser, GETDATE());
        END

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_SaveEmployee;

        THROW;
    END CATCH
END
GO

--------------------------------------------------------------------------------
-- 6. Emp_InsertContractSalary: إضافة فترة عقد/راتب جديدة (لا تعديل على التاريخ)
--    - تغلق العقد الساري بتاريخ (بداية الجديد - يوم)
--    - لا يُعدَّل سجل قائم؛ التصحيح يتم بإضافة فترة جديدة
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[Emp_InsertContractSalary]
    @ContractID         BIGINT = NULL OUTPUT,
    @EmpCompany         INT,
    @EmpID              BIGINT,
    @EmpContractType    BIGINT,
    @EmpDirectDate      DATE,
    @EmpSalary          DECIMAL(15,3),
    @EmpWorkSite        BIGINT = NULL,
    @EmpUser            BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50089, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    IF @EmpCompany IS NULL OR @EmpCompany <= 0
        THROW 50080, N'معرف الشركة غير صالح.', 1;
    IF @EmpID IS NULL OR @EmpID <= 0
        THROW 50081, N'معرف الموظف غير صالح.', 1;
    IF @EmpContractType IS NULL OR @EmpContractType <= 0
        THROW 50082, N'نوع العقد إلزامي.', 1;
    IF @EmpDirectDate IS NULL
        THROW 50083, N'تاريخ بداية العقد إلزامي.', 1;
    IF @EmpSalary IS NULL OR @EmpSalary < 0
        THROW 50084, N'الراتب غير صالح.', 1;
    IF @EmpUser IS NULL OR @EmpUser <= 0
        THROW 50085, N'معرف المستخدم غير صالح.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @LastStart DATE, @LastEnd DATE;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_AddContract;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
                       WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany)
            THROW 50086, N'الموظف غير موجود في نطاق هذه الشركة.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @EmpUser)
            THROW 50087, N'مستخدم النظام غير مسجل.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_EmploymentTypes WITH (UPDLOCK, HOLDLOCK)
                       WHERE Emp_EmpTypeID = @EmpContractType AND Emp_EmpTypeCmp = @EmpCompany
                         AND Emp_EmpTypeState = 0)
            THROW 50088, N'نوع العقد غير موجود أو لا يتبع لهذه الشركة أو معطّل.', 1;

        -- بداية الفترة الجديدة يجب أن تكون بعد كل الفترات السابقة
        SELECT @LastStart = MAX(EmpDirectDate), @LastEnd = MAX(EmpEndDate)
        FROM dbo.Emp_ContractSalary WITH (UPDLOCK, HOLDLOCK)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID;

        IF @LastStart IS NOT NULL AND @EmpDirectDate <= @LastStart
            THROW 50090, N'تاريخ بداية العقد يجب أن يكون بعد بداية آخر عقد مسجل.', 1;
        IF @LastEnd IS NOT NULL AND @EmpDirectDate <= @LastEnd
            THROW 50091, N'تاريخ بداية العقد يتداخل مع فترة عقد سابق.', 1;

        -- إغلاق العقد الساري إن وجد
        UPDATE dbo.Emp_ContractSalary
        SET EmpEndDate = DATEADD(DAY, -1, @EmpDirectDate)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID AND EmpEndDate IS NULL;

        INSERT dbo.Emp_ContractSalary
            (EmpCompany, EmpID, EmpContractType, EmpDirectDate, EmpEndDate,
             EmpSalary, EmpWorkSite, EmpUser, EmpDateTime)
        VALUES
            (@EmpCompany, @EmpID, @EmpContractType, @EmpDirectDate, NULL,
             @EmpSalary, @EmpWorkSite, @EmpUser, GETDATE());

        SET @ContractID = SCOPE_IDENTITY();

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_AddContract;

        THROW;
    END CATCH
END
GO

﻿USE [MADARERPDataBase]
GO
/* =====================================================================
   02d: العملات وأسعار الصرف + ربط عملة الراتب
   يُشغَّل بعد 02c (يتطلب وجود Emp_ContractSalary).
   ---------------------------------------------------------------------
   Acc_Currency      : عملات كل شركة، وعملة أساسية واحدة فقط لكل شركة
   Acc_ExchangeRate  : أسعار الصرف بتاريخ (سعر الوحدة الأجنبية بالعملة الأساسية)
   Emp_ContractSalary.EmpCurrencyID : عملة الراتب

   افتراضات تحتاج تأكيدك:
   [افتراض A1] العملات مستقلة لكل شركة (عزل الشركات).
   [افتراض A2] سعر الصرف = كم وحدة من العملة الأساسية تساوي وحدة واحدة أجنبية.
   [افتراض A3] عدد الخانات العشرية الافتراضي 3.
   [افتراض A4] لا ربط بالقيود المحاسبية الآن؛ هذا الملف لا يلمس Acc_DayMaster/Acc_DayDetails.
   [افتراض A5] العملة الأساسية لا يتغير وضعها بعد إنشائها، ويجب إنشاؤها يدوياً أولاً
               (لا يوجد تعبئة تلقائية) قبل أي عملة أخرى أو عقد.
   [افتراض A6] تعديل سعر صرف مسجل مسموح حالياً؛ يجب إقفاله عند بدء استعمال الأسعار في القيود.
   ===================================================================== */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------------
-- 1. Acc_Currency
--------------------------------------------------------------------------------
IF OBJECT_ID(N'[dbo].[Acc_Currency]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Acc_Currency](
        [CurID]         BIGINT IDENTITY(1,1) NOT NULL,
        [CurCmp]        INT NOT NULL,
        [CurCode]       NVARCHAR(3) NOT NULL,           -- رمز ISO مثل USD
        [CurName]       NVARCHAR(100) NOT NULL,
        [CurSymbol]     NVARCHAR(10) NULL,
        [CurDecimals]   TINYINT NOT NULL CONSTRAINT [DF_Acc_Currency_Decimals] DEFAULT (3),
        [CurIsBase]     BIT NOT NULL CONSTRAINT [DF_Acc_Currency_IsBase] DEFAULT (0),
        [CurState]      TINYINT NOT NULL CONSTRAINT [DF_Acc_Currency_State] DEFAULT (0),
        [CurDate]       DATETIME2(0) NOT NULL CONSTRAINT [DF_Acc_Currency_Date] DEFAULT (SYSDATETIME()),
        [CurUser]       BIGINT NOT NULL,

        CONSTRAINT [PK_Acc_Currency] PRIMARY KEY CLUSTERED ([CurID] ASC),
        CONSTRAINT [UQ_Acc_Currency_Cmp_ID] UNIQUE NONCLUSTERED ([CurCmp], [CurID]),
        CONSTRAINT [UQ_Acc_Currency_Cmp_Code] UNIQUE NONCLUSTERED ([CurCmp], [CurCode]),
        CONSTRAINT [CK_Acc_Currency_State] CHECK ([CurState] IN (0, 1)),
        CONSTRAINT [CK_Acc_Currency_Decimals] CHECK ([CurDecimals] BETWEEN 0 AND 6),
        CONSTRAINT [CK_Acc_Currency_BaseActive] CHECK ([CurIsBase] = 0 OR [CurState] = 0),
        CONSTRAINT [FK_Acc_Currency_Company] FOREIGN KEY ([CurCmp]) REFERENCES [dbo].[Mng_Company] ([CmpID]),
        CONSTRAINT [FK_Acc_Currency_User] FOREIGN KEY ([CurUser]) REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];

    -- عملة أساسية واحدة فقط لكل شركة
    CREATE UNIQUE NONCLUSTERED INDEX [UX_Acc_Currency_Base]
        ON [dbo].[Acc_Currency] ([CurCmp] ASC)
        WHERE [CurIsBase] = 1;
END
GO

--------------------------------------------------------------------------------
-- 2. Acc_ExchangeRate
--------------------------------------------------------------------------------
IF OBJECT_ID(N'[dbo].[Acc_ExchangeRate]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Acc_ExchangeRate](
        [RateID]        BIGINT IDENTITY(1,1) NOT NULL,
        [RateCmp]       INT NOT NULL,
        [RateCurID]     BIGINT NOT NULL,
        [RateDate]      DATE NOT NULL,
        [RateValue]     DECIMAL(18,8) NOT NULL,         -- [افتراض A2]
        [RateUser]      BIGINT NOT NULL,
        [RateDateTime]  DATETIME2(0) NOT NULL CONSTRAINT [DF_Acc_ExchangeRate_DateTime] DEFAULT (SYSDATETIME()),

        CONSTRAINT [PK_Acc_ExchangeRate] PRIMARY KEY CLUSTERED ([RateID] ASC),
        CONSTRAINT [UQ_Acc_ExchangeRate_Cmp_Cur_Date] UNIQUE NONCLUSTERED ([RateCmp], [RateCurID], [RateDate]),
        CONSTRAINT [CK_Acc_ExchangeRate_Value] CHECK ([RateValue] > 0),
        CONSTRAINT [FK_Acc_ExchangeRate_Currency] FOREIGN KEY ([RateCmp], [RateCurID])
            REFERENCES [dbo].[Acc_Currency] ([CurCmp], [CurID]),
        CONSTRAINT [FK_Acc_ExchangeRate_User] FOREIGN KEY ([RateUser]) REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];
END
GO

--------------------------------------------------------------------------------
-- 3. ربط عملة الراتب (يتطلب أن يكون Emp_ContractSalary فارغاً عند الإضافة الأولى)
--------------------------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.Emp_ContractSalary') AND name = 'EmpCurrencyID')
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Emp_ContractSalary)
        THROW 50100, N'توجد عقود مسجلة بلا عملة. حدّد عملتها يدوياً قبل إضافة العمود.', 1;

    ALTER TABLE [dbo].[Emp_ContractSalary] ADD [EmpCurrencyID] BIGINT NOT NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Emp_ContractSalary_Currency'
               AND parent_object_id = OBJECT_ID('dbo.Emp_ContractSalary'))
    ALTER TABLE [dbo].[Emp_ContractSalary] WITH CHECK ADD CONSTRAINT [FK_Emp_ContractSalary_Currency]
        FOREIGN KEY ([EmpCompany], [EmpCurrencyID])
        REFERENCES [dbo].[Acc_Currency] ([CurCmp], [CurID]);
GO

--------------------------------------------------------------------------------
-- 4. دالة سعر الصرف في تاريخ: آخر سعر حتى التاريخ (العملة الأساسية = 1، لا سعر = NULL)
--------------------------------------------------------------------------------
CREATE OR ALTER FUNCTION [dbo].[fn_Acc_GetExchangeRate]
(
    @Cmp    INT,
    @CurID  BIGINT,
    @Date   DATE
)
RETURNS DECIMAL(18,8)
AS
BEGIN
    DECLARE @Rate DECIMAL(18,8);

    IF EXISTS (SELECT 1 FROM dbo.Acc_Currency WHERE CurCmp = @Cmp AND CurID = @CurID AND CurIsBase = 1)
        RETURN CAST(1 AS DECIMAL(18,8));

    SELECT TOP (1) @Rate = RateValue
    FROM dbo.Acc_ExchangeRate
    WHERE RateCmp = @Cmp AND RateCurID = @CurID AND RateDate <= @Date
    ORDER BY RateDate DESC;

    RETURN @Rate;
END
GO

--------------------------------------------------------------------------------
-- 5. sp_Save_Acc_Currency
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[sp_Save_Acc_Currency]
    @CurID          BIGINT = NULL OUTPUT,
    @CurCmp         INT,
    @CurCode        NVARCHAR(3),
    @CurName        NVARCHAR(100),
    @CurSymbol      NVARCHAR(10) = NULL,
    @CurDecimals    TINYINT = 3,
    @CurIsBase      BIT = 0,
    @CurState       TINYINT = 0,
    @CurUser        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50119, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    SET @CurCode   = UPPER(NULLIF(LTRIM(RTRIM(@CurCode)), N''));
    SET @CurName   = NULLIF(LTRIM(RTRIM(@CurName)), N'');
    SET @CurSymbol = NULLIF(LTRIM(RTRIM(@CurSymbol)), N'');

    IF @CurID IS NOT NULL AND @CurID < 0
        THROW 50101, N'معرف العملة غير صالح.', 1;
    IF @CurCmp IS NULL OR @CurCmp <= 0
        THROW 50102, N'معرف الشركة غير صالح.', 1;
    IF @CurCode IS NULL OR LEN(@CurCode) <> 3 OR @CurCode LIKE N'%[^A-Z]%' COLLATE Latin1_General_BIN
        THROW 50103, N'رمز العملة يجب أن يكون ثلاثة أحرف إنجليزية (مثل USD).', 1;
    IF @CurName IS NULL
        THROW 50104, N'اسم العملة إلزامي.', 1;
    IF @CurDecimals IS NULL OR @CurDecimals > 6
        THROW 50105, N'عدد الخانات العشرية يجب أن يكون بين 0 و6.', 1;
    IF @CurState IS NULL OR @CurState NOT IN (0, 1)
        THROW 50106, N'حالة العملة غير صالحة.', 1;
    IF @CurIsBase IS NULL
        SET @CurIsBase = 0;
    IF @CurUser IS NULL OR @CurUser <= 0
        THROW 50107, N'معرف المستخدم غير صالح.', 1;
    IF @CurIsBase = 1 AND @CurState = 1
        THROW 50108, N'لا يمكن تعطيل العملة الأساسية.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @OldCode NVARCHAR(3), @OldBase BIT;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_SaveCurrency;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @CurCmp)
            THROW 50109, N'الشركة غير مسجلة.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @CurUser)
            THROW 50110, N'مستخدم النظام غير مسجل.', 1;

        -- رمز العملة غير مكرر داخل الشركة
        IF EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                   WHERE CurCmp = @CurCmp AND CurCode = @CurCode
                     AND (@CurID IS NULL OR @CurID = 0 OR CurID <> @CurID))
            THROW 50111, N'رمز العملة مستخدم لعملة أخرى في هذه الشركة.', 1;

        IF @CurID IS NOT NULL AND @CurID > 0
        BEGIN
            -- تعديل
            SELECT @OldCode = CurCode, @OldBase = CurIsBase
            FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
            WHERE CurID = @CurID AND CurCmp = @CurCmp;

            IF @@ROWCOUNT = 0
                THROW 50112, N'العملة غير موجودة في نطاق هذه الشركة.', 1;

            IF @OldBase <> @CurIsBase
                THROW 50113, N'لا يمكن تغيير وضع العملة الأساسية بعد إنشائها.', 1;

            IF @OldCode <> @CurCode
               AND (EXISTS (SELECT 1 FROM dbo.Emp_ContractSalary WHERE EmpCompany = @CurCmp AND EmpCurrencyID = @CurID)
                 OR EXISTS (SELECT 1 FROM dbo.Acc_ExchangeRate WHERE RateCmp = @CurCmp AND RateCurID = @CurID))
                THROW 50114, N'لا يمكن تغيير رمز عملة مستخدمة في عقود أو أسعار صرف.', 1;

            -- لا تعطيل لعملة مستخدمة في عقد ساري
            IF @CurState = 1
               AND EXISTS (SELECT 1 FROM dbo.Emp_ContractSalary
                           WHERE EmpCompany = @CurCmp AND EmpCurrencyID = @CurID AND EmpEndDate IS NULL)
                THROW 50115, N'لا يمكن تعطيل عملة مستخدمة في عقد ساري.', 1;

            UPDATE dbo.Acc_Currency
            SET CurCode = @CurCode, CurName = @CurName, CurSymbol = @CurSymbol,
                CurDecimals = @CurDecimals, CurState = @CurState,
                CurDate = SYSDATETIME(), CurUser = @CurUser
            WHERE CurID = @CurID AND CurCmp = @CurCmp;
        END
        ELSE
        BEGIN
            -- إدراج: العملة الأساسية أولاً
            IF @CurIsBase = 1 AND EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                                          WHERE CurCmp = @CurCmp AND CurIsBase = 1)
                THROW 50116, N'للشركة عملة أساسية بالفعل.', 1;

            IF @CurIsBase = 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                                              WHERE CurCmp = @CurCmp AND CurIsBase = 1)
                THROW 50117, N'أنشئ العملة الأساسية للشركة أولاً.', 1;

            INSERT dbo.Acc_Currency
                (CurCmp, CurCode, CurName, CurSymbol, CurDecimals, CurIsBase, CurState, CurDate, CurUser)
            VALUES
                (@CurCmp, @CurCode, @CurName, @CurSymbol, @CurDecimals, @CurIsBase, @CurState, SYSDATETIME(), @CurUser);

            SET @CurID = SCOPE_IDENTITY();
        END

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_SaveCurrency;

        THROW;
    END CATCH
END
GO

--------------------------------------------------------------------------------
-- 6. sp_Get_Acc_Currency
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[sp_Get_Acc_Currency]
    @CurCmp     INT,
    @CurID      BIGINT = NULL,
    @CurState   TINYINT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@CurCmp, 0) <= 0
        THROW 50102, N'معرف الشركة غير صالح.', 1;

    SELECT C.CurID, C.CurCmp, C.CurCode, C.CurName, C.CurSymbol, C.CurDecimals,
           C.CurIsBase, C.CurState, C.CurDate, C.CurUser, U.UsrLogIn AS CurUserName
    FROM dbo.Acc_Currency AS C
    LEFT JOIN dbo.Mng_User AS U ON U.UsrID = C.CurUser
    WHERE C.CurCmp = @CurCmp
      AND (@CurID IS NULL OR C.CurID = @CurID)
      AND (@CurState IS NULL OR C.CurState = @CurState)
    ORDER BY C.CurIsBase DESC, C.CurCode;
END
GO

--------------------------------------------------------------------------------
-- 7. sp_Save_Acc_ExchangeRate (إدراج أو تحديث سعر يوم لعملة)
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[sp_Save_Acc_ExchangeRate]
    @RateID     BIGINT = NULL OUTPUT,
    @RateCmp    INT,
    @RateCurID  BIGINT,
    @RateDate   DATE,
    @RateValue  DECIMAL(18,8),
    @RateUser   BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50139, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    IF @RateCmp IS NULL OR @RateCmp <= 0
        THROW 50120, N'معرف الشركة غير صالح.', 1;
    IF @RateCurID IS NULL OR @RateCurID <= 0
        THROW 50121, N'العملة إلزامية.', 1;
    IF @RateDate IS NULL
        THROW 50122, N'تاريخ السعر إلزامي.', 1;
    IF @RateValue IS NULL OR @RateValue <= 0
        THROW 50123, N'سعر الصرف يجب أن يكون أكبر من صفر.', 1;
    IF @RateUser IS NULL OR @RateUser <= 0
        THROW 50124, N'معرف المستخدم غير صالح.', 1;

    DECLARE @TranStarted INT = 0;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_SaveRate;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @RateUser)
            THROW 50125, N'مستخدم النظام غير مسجل.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                       WHERE CurID = @RateCurID AND CurCmp = @RateCmp AND CurState = 0)
            THROW 50126, N'العملة غير موجودة في هذه الشركة أو معطّلة.', 1;

        IF EXISTS (SELECT 1 FROM dbo.Acc_Currency WHERE CurID = @RateCurID AND CurCmp = @RateCmp AND CurIsBase = 1)
            THROW 50127, N'لا يُسجَّل سعر صرف للعملة الأساسية (سعرها 1 دائماً).', 1;

        SELECT @RateID = RateID
        FROM dbo.Acc_ExchangeRate WITH (UPDLOCK, HOLDLOCK)
        WHERE RateCmp = @RateCmp AND RateCurID = @RateCurID AND RateDate = @RateDate;

        IF @RateID IS NOT NULL
            UPDATE dbo.Acc_ExchangeRate
            SET RateValue = @RateValue, RateUser = @RateUser, RateDateTime = SYSDATETIME()
            WHERE RateID = @RateID;
        ELSE
        BEGIN
            INSERT dbo.Acc_ExchangeRate (RateCmp, RateCurID, RateDate, RateValue, RateUser, RateDateTime)
            VALUES (@RateCmp, @RateCurID, @RateDate, @RateValue, @RateUser, SYSDATETIME());

            SET @RateID = SCOPE_IDENTITY();
        END

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_SaveRate;

        THROW;
    END CATCH
END
GO

--------------------------------------------------------------------------------
-- 8. sp_Get_Acc_ExchangeRate
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[sp_Get_Acc_ExchangeRate]
    @RateCmp    INT,
    @RateCurID  BIGINT = NULL,
    @FromDate   DATE = NULL,
    @ToDate     DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@RateCmp, 0) <= 0
        THROW 50120, N'معرف الشركة غير صالح.', 1;

    SELECT R.RateID, R.RateCmp, R.RateCurID, C.CurCode, C.CurName,
           R.RateDate, R.RateValue, R.RateUser, U.UsrLogIn AS RateUserName, R.RateDateTime
    FROM dbo.Acc_ExchangeRate AS R
    INNER JOIN dbo.Acc_Currency AS C ON C.CurCmp = R.RateCmp AND C.CurID = R.RateCurID
    LEFT JOIN dbo.Mng_User AS U ON U.UsrID = R.RateUser
    WHERE R.RateCmp = @RateCmp
      AND (@RateCurID IS NULL OR R.RateCurID = @RateCurID)
      AND (@FromDate IS NULL OR R.RateDate >= @FromDate)
      AND (@ToDate IS NULL OR R.RateDate <= @ToDate)
    ORDER BY C.CurCode, R.RateDate DESC;
END
GO

--------------------------------------------------------------------------------
-- 9. sp_Add_Emp_ContractSalary بعد إضافة العملة (يستبدل نسخة 02c)
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[sp_Add_Emp_ContractSalary]
    @ContractID         BIGINT = NULL OUTPUT,
    @EmpCompany         INT,
    @EmpID              BIGINT,
    @EmpContractType    BIGINT,
    @EmpDirectDate      DATE,
    @EmpSalary          DECIMAL(15,3),
    @EmpCurrencyID      BIGINT,
    @EmpWorkSite        BIGINT = NULL,
    @EmpUser            BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50089, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    IF @EmpCompany IS NULL OR @EmpCompany <= 0
        THROW 50080, N'معرف الشركة غير صالح.', 1;
    IF @EmpID IS NULL OR @EmpID <= 0
        THROW 50081, N'معرف الموظف غير صالح.', 1;
    IF @EmpContractType IS NULL OR @EmpContractType <= 0
        THROW 50082, N'نوع العقد إلزامي.', 1;
    IF @EmpDirectDate IS NULL
        THROW 50083, N'تاريخ بداية العقد إلزامي.', 1;
    IF @EmpSalary IS NULL OR @EmpSalary < 0
        THROW 50084, N'الراتب غير صالح.', 1;
    IF @EmpCurrencyID IS NULL OR @EmpCurrencyID <= 0
        THROW 50092, N'عملة الراتب إلزامية.', 1;
    IF @EmpUser IS NULL OR @EmpUser <= 0
        THROW 50085, N'معرف المستخدم غير صالح.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @LastStart DATE, @LastEnd DATE;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_AddContract;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
                       WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany)
            THROW 50086, N'الموظف غير موجود في نطاق هذه الشركة.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @EmpUser)
            THROW 50087, N'مستخدم النظام غير مسجل.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_EmploymentTypes WITH (UPDLOCK, HOLDLOCK)
                       WHERE Emp_EmpTypeID = @EmpContractType AND Emp_EmpTypeCmp = @EmpCompany
                         AND Emp_EmpTypeState = 0)
            THROW 50088, N'نوع العقد غير موجود أو لا يتبع لهذه الشركة أو معطّل.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                       WHERE CurID = @EmpCurrencyID AND CurCmp = @EmpCompany AND CurState = 0)
            THROW 50093, N'عملة الراتب غير موجودة في هذه الشركة أو معطّلة.', 1;

        -- بداية الفترة الجديدة يجب أن تكون بعد كل الفترات السابقة
        SELECT @LastStart = MAX(EmpDirectDate), @LastEnd = MAX(EmpEndDate)
        FROM dbo.Emp_ContractSalary WITH (UPDLOCK, HOLDLOCK)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID;

        IF @LastStart IS NOT NULL AND @EmpDirectDate <= @LastStart
            THROW 50090, N'تاريخ بداية العقد يجب أن يكون بعد بداية آخر عقد مسجل.', 1;
        IF @LastEnd IS NOT NULL AND @EmpDirectDate <= @LastEnd
            THROW 50091, N'تاريخ بداية العقد يتداخل مع فترة عقد سابق.', 1;

        -- إغلاق العقد الساري إن وجد
        UPDATE dbo.Emp_ContractSalary
        SET EmpEndDate = DATEADD(DAY, -1, @EmpDirectDate)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID AND EmpEndDate IS NULL;

        INSERT dbo.Emp_ContractSalary
            (EmpCompany, EmpID, EmpContractType, EmpDirectDate, EmpEndDate,
             EmpSalary, EmpCurrencyID, EmpWorkSite, EmpUser, EmpDateTime)
        VALUES
            (@EmpCompany, @EmpID, @EmpContractType, @EmpDirectDate, NULL,
             @EmpSalary, @EmpCurrencyID, @EmpWorkSite, @EmpUser, GETDATE());

        SET @ContractID = SCOPE_IDENTITY();

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_AddContract;

        THROW;
    END CATCH
END
GO

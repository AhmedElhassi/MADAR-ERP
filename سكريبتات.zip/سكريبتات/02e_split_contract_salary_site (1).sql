﻿USE [MADARERPDataBase]
GO
/* =====================================================================
   02e: فصل العقد والراتب وموقع العمل في ثلاثة سجلات تاريخية
   ---------------------------------------------------------------------
   Emp_Contract            : نوع العقد وفترته
   Emp_Salary              : المبلغ والعملة وفترته (مستقل عن العقد)
   Emp_WorkSiteAssignment  : موقع العمل وفترته
   كل جدول: فترة بداية/نهاية (النهاية NULL = ساري) + سجل ساري واحد للموظف.

   يتطلب 02c و02d. ويحل محل Emp_ContractSalary و Emp_InsertContractSalary.
   لا تُعد تشغيل مقاطع Emp_ContractSalary من 02c/02d بعد هذا الملف.

   افتراضات تحتاج تأكيدك:
   [افتراض E1] الراتب مستقل عن العقد (بلا مفتاح أجنبي بينهما).
   [افتراض E2] موقع العمل بتاريخ (جدول تعيين)، وبلا FK حتى يتحدد جدول المواقع.
   [افتراض E3] ترحيل بيانات Emp_ContractSalary إن وُجدت: كل سجل قديم يصبح سجلاً
               في كل جدول (والموقع فقط إن لم يكن NULL). ثم يُعاد تسمية الجدول القديم
               إلى Emp_ContractSalary_Legacy ولا يُحذف.
   [افتراض E4] لا يُشترط وجود سعر صرف عند تسجيل الراتب؛ القراءة تعيد المبلغ بالأساسي
               إن وُجد السعر وإلا NULL.
   [افتراض E5] يُحذف الإجراء Emp_InsertContractSalary لأنه يكتب في الجدول القديم.
   ===================================================================== */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------------
-- 1. الجداول
--------------------------------------------------------------------------------
IF OBJECT_ID(N'[dbo].[Emp_Contract]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Emp_Contract](
        [ConID]         BIGINT IDENTITY(1,1) NOT NULL,
        [EmpCompany]    INT NOT NULL,
        [EmpID]         BIGINT NOT NULL,
        [ConType]       BIGINT NOT NULL,
        [ConStartDate]  DATE NOT NULL,
        [ConEndDate]    DATE NULL,
        [ConUser]       BIGINT NOT NULL,
        [ConDateTime]   DATETIME NOT NULL CONSTRAINT [DF_Emp_Contract_DateTime] DEFAULT (GETDATE()),
        CONSTRAINT [PK_Emp_Contract] PRIMARY KEY CLUSTERED ([ConID] ASC),
        CONSTRAINT [CK_Emp_Contract_Dates] CHECK ([ConEndDate] IS NULL OR [ConEndDate] >= [ConStartDate]),
        CONSTRAINT [FK_Emp_Contract_Employee] FOREIGN KEY ([EmpCompany], [EmpID])
            REFERENCES [dbo].[Emp_Employee] ([EmpCompany], [EmpID]),
        CONSTRAINT [FK_Emp_Contract_Type] FOREIGN KEY ([EmpCompany], [ConType])
            REFERENCES [dbo].[Emp_EmploymentTypes] ([Emp_EmpTypeCmp], [Emp_EmpTypeID]),
        CONSTRAINT [FK_Emp_Contract_User] FOREIGN KEY ([ConUser]) REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];

    CREATE UNIQUE NONCLUSTERED INDEX [UX_Emp_Contract_Active]
        ON [dbo].[Emp_Contract] ([EmpCompany], [EmpID]) WHERE [ConEndDate] IS NULL;
    CREATE NONCLUSTERED INDEX [IX_Emp_Contract_Employee]
        ON [dbo].[Emp_Contract] ([EmpCompany], [EmpID], [ConStartDate]);
END
GO

IF OBJECT_ID(N'[dbo].[Emp_Salary]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Emp_Salary](
        [SalID]         BIGINT IDENTITY(1,1) NOT NULL,
        [EmpCompany]    INT NOT NULL,
        [EmpID]         BIGINT NOT NULL,
        [SalAmount]     DECIMAL(15,3) NOT NULL,
        [SalCurrencyID] BIGINT NOT NULL,
        [SalStartDate]  DATE NOT NULL,
        [SalEndDate]    DATE NULL,
        [SalUser]       BIGINT NOT NULL,
        [SalDateTime]   DATETIME NOT NULL CONSTRAINT [DF_Emp_Salary_DateTime] DEFAULT (GETDATE()),
        CONSTRAINT [PK_Emp_Salary] PRIMARY KEY CLUSTERED ([SalID] ASC),
        CONSTRAINT [CK_Emp_Salary_Amount] CHECK ([SalAmount] >= 0),
        CONSTRAINT [CK_Emp_Salary_Dates] CHECK ([SalEndDate] IS NULL OR [SalEndDate] >= [SalStartDate]),
        CONSTRAINT [FK_Emp_Salary_Employee] FOREIGN KEY ([EmpCompany], [EmpID])
            REFERENCES [dbo].[Emp_Employee] ([EmpCompany], [EmpID]),
        CONSTRAINT [FK_Emp_Salary_Currency] FOREIGN KEY ([EmpCompany], [SalCurrencyID])
            REFERENCES [dbo].[Acc_Currency] ([CurCmp], [CurID]),
        CONSTRAINT [FK_Emp_Salary_User] FOREIGN KEY ([SalUser]) REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];

    CREATE UNIQUE NONCLUSTERED INDEX [UX_Emp_Salary_Active]
        ON [dbo].[Emp_Salary] ([EmpCompany], [EmpID]) WHERE [SalEndDate] IS NULL;
    CREATE NONCLUSTERED INDEX [IX_Emp_Salary_Employee]
        ON [dbo].[Emp_Salary] ([EmpCompany], [EmpID], [SalStartDate]);
END
GO

IF OBJECT_ID(N'[dbo].[Emp_WorkSiteAssignment]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[Emp_WorkSiteAssignment](
        [WsaID]         BIGINT IDENTITY(1,1) NOT NULL,
        [EmpCompany]    INT NOT NULL,
        [EmpID]         BIGINT NOT NULL,
        [WsaSiteID]     BIGINT NOT NULL,                -- [افتراض E2] بلا FK حالياً
        [WsaStartDate]  DATE NOT NULL,
        [WsaEndDate]    DATE NULL,
        [WsaUser]       BIGINT NOT NULL,
        [WsaDateTime]   DATETIME NOT NULL CONSTRAINT [DF_Emp_WorkSiteAssignment_DateTime] DEFAULT (GETDATE()),
        CONSTRAINT [PK_Emp_WorkSiteAssignment] PRIMARY KEY CLUSTERED ([WsaID] ASC),
        CONSTRAINT [CK_Emp_WorkSiteAssignment_Dates] CHECK ([WsaEndDate] IS NULL OR [WsaEndDate] >= [WsaStartDate]),
        CONSTRAINT [FK_Emp_WorkSiteAssignment_Employee] FOREIGN KEY ([EmpCompany], [EmpID])
            REFERENCES [dbo].[Emp_Employee] ([EmpCompany], [EmpID]),
        CONSTRAINT [FK_Emp_WorkSiteAssignment_User] FOREIGN KEY ([WsaUser]) REFERENCES [dbo].[Mng_User] ([UsrID])
    ) ON [PRIMARY];

    CREATE UNIQUE NONCLUSTERED INDEX [UX_Emp_WorkSiteAssignment_Active]
        ON [dbo].[Emp_WorkSiteAssignment] ([EmpCompany], [EmpID]) WHERE [WsaEndDate] IS NULL;
    CREATE NONCLUSTERED INDEX [IX_Emp_WorkSiteAssignment_Employee]
        ON [dbo].[Emp_WorkSiteAssignment] ([EmpCompany], [EmpID], [WsaStartDate]);
END
GO

--------------------------------------------------------------------------------
-- 2. ترحيل بيانات Emp_ContractSalary القديمة (إن وُجدت) ثم إعادة تسمية الجدول
--------------------------------------------------------------------------------
IF OBJECT_ID(N'[dbo].[Emp_ContractSalary]', N'U') IS NOT NULL
   AND OBJECT_ID(N'[dbo].[Emp_ContractSalary_Legacy]', N'U') IS NULL
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Emp_Contract)
       OR EXISTS (SELECT 1 FROM dbo.Emp_Salary)
       OR EXISTS (SELECT 1 FROM dbo.Emp_WorkSiteAssignment)
        THROW 50200, N'الجداول الجديدة تحتوي بيانات مسبقاً؛ لا يُنفَّذ الترحيل تلقائياً. راجع الوضع يدوياً.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT dbo.Emp_Contract (EmpCompany, EmpID, ConType, ConStartDate, ConEndDate, ConUser, ConDateTime)
        SELECT EmpCompany, EmpID, EmpContractType, EmpDirectDate, EmpEndDate, EmpUser, EmpDateTime
        FROM dbo.Emp_ContractSalary;

        INSERT dbo.Emp_Salary (EmpCompany, EmpID, SalAmount, SalCurrencyID, SalStartDate, SalEndDate, SalUser, SalDateTime)
        SELECT EmpCompany, EmpID, EmpSalary, EmpCurrencyID, EmpDirectDate, EmpEndDate, EmpUser, EmpDateTime
        FROM dbo.Emp_ContractSalary;

        INSERT dbo.Emp_WorkSiteAssignment (EmpCompany, EmpID, WsaSiteID, WsaStartDate, WsaEndDate, WsaUser, WsaDateTime)
        SELECT EmpCompany, EmpID, EmpWorkSite, EmpDirectDate, EmpEndDate, EmpUser, EmpDateTime
        FROM dbo.Emp_ContractSalary
        WHERE EmpWorkSite IS NOT NULL;

        IF (SELECT COUNT(*) FROM dbo.Emp_ContractSalary) <> (SELECT COUNT(*) FROM dbo.Emp_Contract)
           OR (SELECT COUNT(*) FROM dbo.Emp_ContractSalary) <> (SELECT COUNT(*) FROM dbo.Emp_Salary)
           OR (SELECT COUNT(*) FROM dbo.Emp_ContractSalary WHERE EmpWorkSite IS NOT NULL)
              <> (SELECT COUNT(*) FROM dbo.Emp_WorkSiteAssignment)
            THROW 50201, N'عدد السجلات بعد الترحيل لا يطابق الأصل؛ تم التراجع.', 1;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH

    EXEC sys.sp_rename N'dbo.Emp_ContractSalary', N'Emp_ContractSalary_Legacy';
END
GO

-- [افتراض E5]
IF OBJECT_ID(N'[dbo].[Emp_InsertContractSalary]', N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Emp_InsertContractSalary];
GO

--------------------------------------------------------------------------------
-- Emp_InsertContract: إضافة فترة جديدة (تغلق الفترة السارية بتاريخ بداية الجديدة - يوم)
-- لا يُعدَّل سجل قائم؛ التصحيح بإضافة فترة جديدة.
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[Emp_InsertContract]
    @ConID           BIGINT = NULL OUTPUT,
    @EmpCompany     INT,
    @EmpID          BIGINT,
    @ConType        BIGINT,
    @ConStartDate   DATE,
    @ConUser        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50219, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    IF @EmpCompany IS NULL OR @EmpCompany <= 0
        THROW 50210, N'معرف الشركة غير صالح.', 1;
    IF @EmpID IS NULL OR @EmpID <= 0
        THROW 50211, N'معرف الموظف غير صالح.', 1;
    IF @ConType IS NULL OR @ConType <= 0
        THROW 50212, N'نوع العقد إلزامي.', 1;
    IF @ConStartDate IS NULL
        THROW 50213, N'تاريخ البداية إلزامي.', 1;
    IF @ConUser IS NULL OR @ConUser <= 0
        THROW 50214, N'معرف المستخدم غير صالح.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @LastStart DATE, @LastEnd DATE;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_Emp_InsertContract;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
                       WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany)
            THROW 50215, N'الموظف غير موجود في نطاق هذه الشركة.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ConUser)
            THROW 50216, N'مستخدم النظام غير مسجل.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_EmploymentTypes WITH (UPDLOCK, HOLDLOCK)
                       WHERE Emp_EmpTypeID = @ConType AND Emp_EmpTypeCmp = @EmpCompany AND Emp_EmpTypeState = 0)
            THROW 50220, N'نوع العقد غير موجود أو لا يتبع لهذه الشركة أو معطّل.', 1;

        SELECT @LastStart = MAX(ConStartDate), @LastEnd = MAX(ConEndDate)
        FROM dbo.Emp_Contract WITH (UPDLOCK, HOLDLOCK)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID;

        IF @LastStart IS NOT NULL AND @ConStartDate <= @LastStart
            THROW 50217, N'تاريخ البداية يجب أن يكون بعد بداية آخر فترة مسجلة.', 1;
        IF @LastEnd IS NOT NULL AND @ConStartDate <= @LastEnd
            THROW 50218, N'تاريخ البداية يتداخل مع فترة سابقة.', 1;

        UPDATE dbo.Emp_Contract
        SET ConEndDate = DATEADD(DAY, -1, @ConStartDate)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID AND ConEndDate IS NULL;

        INSERT dbo.Emp_Contract
            (EmpCompany, EmpID, ConType, ConStartDate, ConEndDate, ConUser, ConDateTime)
        VALUES
            (@EmpCompany, @EmpID, @ConType, @ConStartDate, NULL, @ConUser, GETDATE());

        SET @ConID = SCOPE_IDENTITY();

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_Emp_InsertContract;

        THROW;
    END CATCH
END
GO

--------------------------------------------------------------------------------
-- Emp_InsertSalary: إضافة فترة جديدة (تغلق الفترة السارية بتاريخ بداية الجديدة - يوم)
-- لا يُعدَّل سجل قائم؛ التصحيح بإضافة فترة جديدة.
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[Emp_InsertSalary]
    @SalID           BIGINT = NULL OUTPUT,
    @EmpCompany     INT,
    @EmpID          BIGINT,
    @SalAmount      DECIMAL(15,3),
    @SalCurrencyID  BIGINT,
    @SalStartDate   DATE,
    @SalUser        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50239, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    IF @EmpCompany IS NULL OR @EmpCompany <= 0
        THROW 50230, N'معرف الشركة غير صالح.', 1;
    IF @EmpID IS NULL OR @EmpID <= 0
        THROW 50231, N'معرف الموظف غير صالح.', 1;
    IF @SalAmount IS NULL OR @SalAmount < 0
        THROW 50232, N'مبلغ الراتب غير صالح.', 1;
    IF @SalCurrencyID IS NULL OR @SalCurrencyID <= 0
        THROW 50240, N'عملة الراتب إلزامية.', 1;
    IF @SalStartDate IS NULL
        THROW 50233, N'تاريخ البداية إلزامي.', 1;
    IF @SalUser IS NULL OR @SalUser <= 0
        THROW 50234, N'معرف المستخدم غير صالح.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @LastStart DATE, @LastEnd DATE;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_Emp_InsertSalary;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
                       WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany)
            THROW 50235, N'الموظف غير موجود في نطاق هذه الشركة.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @SalUser)
            THROW 50236, N'مستخدم النظام غير مسجل.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                       WHERE CurID = @SalCurrencyID AND CurCmp = @EmpCompany AND CurState = 0)
            THROW 50241, N'عملة الراتب غير موجودة في هذه الشركة أو معطّلة.', 1;

        SELECT @LastStart = MAX(SalStartDate), @LastEnd = MAX(SalEndDate)
        FROM dbo.Emp_Salary WITH (UPDLOCK, HOLDLOCK)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID;

        IF @LastStart IS NOT NULL AND @SalStartDate <= @LastStart
            THROW 50237, N'تاريخ البداية يجب أن يكون بعد بداية آخر فترة مسجلة.', 1;
        IF @LastEnd IS NOT NULL AND @SalStartDate <= @LastEnd
            THROW 50238, N'تاريخ البداية يتداخل مع فترة سابقة.', 1;

        UPDATE dbo.Emp_Salary
        SET SalEndDate = DATEADD(DAY, -1, @SalStartDate)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID AND SalEndDate IS NULL;

        INSERT dbo.Emp_Salary
            (EmpCompany, EmpID, SalAmount, SalCurrencyID, SalStartDate, SalEndDate, SalUser, SalDateTime)
        VALUES
            (@EmpCompany, @EmpID, @SalAmount, @SalCurrencyID, @SalStartDate, NULL, @SalUser, GETDATE());

        SET @SalID = SCOPE_IDENTITY();

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_Emp_InsertSalary;

        THROW;
    END CATCH
END
GO

--------------------------------------------------------------------------------
-- Emp_InsertWorkSiteAssignment: إضافة فترة جديدة (تغلق الفترة السارية بتاريخ بداية الجديدة - يوم)
-- لا يُعدَّل سجل قائم؛ التصحيح بإضافة فترة جديدة.
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[Emp_InsertWorkSiteAssignment]
    @WsaID           BIGINT = NULL OUTPUT,
    @EmpCompany     INT,
    @EmpID          BIGINT,
    @WsaSiteID      BIGINT,
    @WsaStartDate   DATE,
    @WsaUser        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50259, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    IF @EmpCompany IS NULL OR @EmpCompany <= 0
        THROW 50250, N'معرف الشركة غير صالح.', 1;
    IF @EmpID IS NULL OR @EmpID <= 0
        THROW 50251, N'معرف الموظف غير صالح.', 1;
    IF @WsaSiteID IS NULL OR @WsaSiteID <= 0
        THROW 50252, N'موقع العمل إلزامي.', 1;
    IF @WsaStartDate IS NULL
        THROW 50253, N'تاريخ البداية إلزامي.', 1;
    IF @WsaUser IS NULL OR @WsaUser <= 0
        THROW 50254, N'معرف المستخدم غير صالح.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @LastStart DATE, @LastEnd DATE;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_Emp_InsertWorkSite;

        IF NOT EXISTS (SELECT 1 FROM dbo.Emp_Employee WITH (UPDLOCK, HOLDLOCK)
                       WHERE EmpID = @EmpID AND EmpCompany = @EmpCompany)
            THROW 50255, N'الموظف غير موجود في نطاق هذه الشركة.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @WsaUser)
            THROW 50256, N'مستخدم النظام غير مسجل.', 1;

        SELECT @LastStart = MAX(WsaStartDate), @LastEnd = MAX(WsaEndDate)
        FROM dbo.Emp_WorkSiteAssignment WITH (UPDLOCK, HOLDLOCK)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID;

        IF @LastStart IS NOT NULL AND @WsaStartDate <= @LastStart
            THROW 50257, N'تاريخ البداية يجب أن يكون بعد بداية آخر فترة مسجلة.', 1;
        IF @LastEnd IS NOT NULL AND @WsaStartDate <= @LastEnd
            THROW 50258, N'تاريخ البداية يتداخل مع فترة سابقة.', 1;

        UPDATE dbo.Emp_WorkSiteAssignment
        SET WsaEndDate = DATEADD(DAY, -1, @WsaStartDate)
        WHERE EmpCompany = @EmpCompany AND EmpID = @EmpID AND WsaEndDate IS NULL;

        INSERT dbo.Emp_WorkSiteAssignment
            (EmpCompany, EmpID, WsaSiteID, WsaStartDate, WsaEndDate, WsaUser, WsaDateTime)
        VALUES
            (@EmpCompany, @EmpID, @WsaSiteID, @WsaStartDate, NULL, @WsaUser, GETDATE());

        SET @WsaID = SCOPE_IDENTITY();

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_Emp_InsertWorkSite;

        THROW;
    END CATCH
END
GO

--------------------------------------------------------------------------------
-- قراءة السجلات
--------------------------------------------------------------------------------
CREATE OR ALTER PROCEDURE [dbo].[Emp_SelectContract]
    @EmpCompany INT,
    @EmpID      BIGINT,
    @OnlyActive BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@EmpCompany, 0) <= 0 THROW 50260, N'معرف الشركة غير صالح.', 1;
    IF ISNULL(@EmpID, 0) <= 0      THROW 50261, N'معرف الموظف غير صالح.', 1;

    SELECT C.ConID, C.EmpCompany, C.EmpID, C.ConType, T.Emp_EmpTypeName AS ConTypeName,
           C.ConStartDate, C.ConEndDate,
           CAST(CASE WHEN C.ConEndDate IS NULL THEN 1 ELSE 0 END AS BIT) AS IsActive,
           C.ConUser, U.UsrLogIn AS ConUserName, C.ConDateTime
    FROM dbo.Emp_Contract AS C
    INNER JOIN dbo.Emp_EmploymentTypes AS T ON T.Emp_EmpTypeCmp = C.EmpCompany AND T.Emp_EmpTypeID = C.ConType
    LEFT JOIN dbo.Mng_User AS U ON U.UsrID = C.ConUser
    WHERE C.EmpCompany = @EmpCompany AND C.EmpID = @EmpID
      AND (@OnlyActive = 0 OR C.ConEndDate IS NULL)
    ORDER BY C.ConStartDate DESC;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[Emp_SelectSalary]
    @EmpCompany INT,
    @EmpID      BIGINT,
    @OnlyActive BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@EmpCompany, 0) <= 0 THROW 50260, N'معرف الشركة غير صالح.', 1;
    IF ISNULL(@EmpID, 0) <= 0      THROW 50261, N'معرف الموظف غير صالح.', 1;

    SELECT S.SalID, S.EmpCompany, S.EmpID, S.SalAmount, S.SalCurrencyID,
           CU.CurCode, CU.CurName,
           dbo.fn_Acc_GetExchangeRate(S.EmpCompany, S.SalCurrencyID, S.SalStartDate) AS RateAtStart,
           S.SalAmount * dbo.fn_Acc_GetExchangeRate(S.EmpCompany, S.SalCurrencyID, S.SalStartDate) AS SalAmountBase,
           S.SalStartDate, S.SalEndDate,
           CAST(CASE WHEN S.SalEndDate IS NULL THEN 1 ELSE 0 END AS BIT) AS IsActive,
           S.SalUser, U.UsrLogIn AS SalUserName, S.SalDateTime
    FROM dbo.Emp_Salary AS S
    INNER JOIN dbo.Acc_Currency AS CU ON CU.CurCmp = S.EmpCompany AND CU.CurID = S.SalCurrencyID
    LEFT JOIN dbo.Mng_User AS U ON U.UsrID = S.SalUser
    WHERE S.EmpCompany = @EmpCompany AND S.EmpID = @EmpID
      AND (@OnlyActive = 0 OR S.SalEndDate IS NULL)
    ORDER BY S.SalStartDate DESC;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[Emp_SelectWorkSiteAssignment]
    @EmpCompany INT,
    @EmpID      BIGINT,
    @OnlyActive BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@EmpCompany, 0) <= 0 THROW 50260, N'معرف الشركة غير صالح.', 1;
    IF ISNULL(@EmpID, 0) <= 0      THROW 50261, N'معرف الموظف غير صالح.', 1;

    SELECT W.WsaID, W.EmpCompany, W.EmpID, W.WsaSiteID, W.WsaStartDate, W.WsaEndDate,
           CAST(CASE WHEN W.WsaEndDate IS NULL THEN 1 ELSE 0 END AS BIT) AS IsActive,
           W.WsaUser, U.UsrLogIn AS WsaUserName, W.WsaDateTime
    FROM dbo.Emp_WorkSiteAssignment AS W
    LEFT JOIN dbo.Mng_User AS U ON U.UsrID = W.WsaUser
    WHERE W.EmpCompany = @EmpCompany AND W.EmpID = @EmpID
      AND (@OnlyActive = 0 OR W.WsaEndDate IS NULL)
    ORDER BY W.WsaStartDate DESC;
END
GO

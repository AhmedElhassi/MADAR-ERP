USE [MADARERPDataBase]
GO
/* =====================================================================
   03: مزامنة نص تعريف الإجراءات مع أسمائها الحالية بعد sp_rename
   ---------------------------------------------------------------------
   المشكلة: sp_rename يغيّر اسم الكائن فقط، ويبقى نص التعريف يحمل الاسم القديم،
            فإن عُدِّل الإجراء من SSMS رجع الاسم القديم.
   الحل   : يقرأ التعريف الفعلي من القاعدة، ويستبدل الاسم في سطر CREATE فقط،
            ثم يعيد إنشاءه CREATE OR ALTER. لا يمس جسم الإجراء ولا صلاحياته.

   طريقة الاستعمال:
     1) شغّله كما هو (@Apply = 0): يعرض فقط الإجراءات التي سيُصلحها، ولا يغيّر شيئاً.
     2) راجع القائمة، ثم غيّر @Apply إلى 1 وشغّله ثانية.
   ===================================================================== */
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;

DECLARE @Apply BIT = 0;   -- 0 = عرض فقط، 1 = تنفيذ

DECLARE @Fix TABLE
(
    ObjID   INT PRIMARY KEY,
    Name    SYSNAME NOT NULL,
    OldName NVARCHAR(400) NOT NULL,
    NewDef  NVARCHAR(MAX) NOT NULL
);

DECLARE @ObjID INT, @Name SYSNAME, @Def NVARCHAR(MAX);
DECLARE @c INT, @p INT, @s INT, @e INT, @n INT;
DECLARE @HeaderName NVARCHAR(400), @Bare NVARCHAR(400), @NewDef NVARCHAR(MAX);
DECLARE @ws NVARCHAR(10) = N' ' + NCHAR(9) + NCHAR(10) + NCHAR(13);

DECLARE ProcCursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT o.object_id, o.name, m.definition
    FROM sys.objects AS o
    INNER JOIN sys.sql_modules AS m ON m.object_id = o.object_id
    WHERE o.type = 'P'
      AND o.is_ms_shipped = 0
      AND o.schema_id = SCHEMA_ID(N'dbo');

OPEN ProcCursor;
FETCH NEXT FROM ProcCursor INTO @ObjID, @Name, @Def;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @n = LEN(@Def);

    -- موضع كلمة CREATE الأولى ثم كلمة PROC/PROCEDURE بعدها
    SET @c = PATINDEX(N'%[Cc][Rr][Ee][Aa][Tt][Ee]%', @Def);
    SET @p = 0;
    IF @c > 0
    BEGIN
        SET @p = PATINDEX(N'%[Pp][Rr][Oo][Cc]%', SUBSTRING(@Def, @c, 4000));
        IF @p > 0 SET @p = @p + @c - 1;
    END

    IF @c > 0 AND @p > 0
    BEGIN
        SET @s = @p + 4;
        IF UPPER(SUBSTRING(@Def, @s, 5)) = N'EDURE' SET @s = @s + 5;

        WHILE @s <= @n AND CHARINDEX(SUBSTRING(@Def, @s, 1), @ws) > 0
            SET @s = @s + 1;

        SET @e = @s;
        WHILE @e <= @n
              AND CHARINDEX(SUBSTRING(@Def, @e, 1), @ws + N'(@') = 0
            SET @e = @e + 1;

        SET @HeaderName = SUBSTRING(@Def, @s, @e - @s);
        SET @Bare = REPLACE(REPLACE(REPLACE(@HeaderName, N'[', N''), N']', N''), N'dbo.', N'');

        IF @Bare COLLATE Latin1_General_BIN <> @Name COLLATE Latin1_General_BIN
           AND CHARINDEX(N'.', @Bare) = 0
        BEGIN
            SET @NewDef = STUFF(@Def, @s, @e - @s, N'[dbo].' + QUOTENAME(@Name));

            -- إن لم يكن التعريف أصلاً CREATE OR ALTER نحوّله إليه
            IF PATINDEX(N'%[Oo][Rr]%[Aa][Ll][Tt][Ee][Rr]%', SUBSTRING(@Def, @c + 6, @p - @c - 6)) = 0
                SET @NewDef = STUFF(@NewDef, @c, 6, N'CREATE OR ALTER');

            INSERT @Fix (ObjID, Name, OldName, NewDef) VALUES (@ObjID, @Name, @Bare, @NewDef);
        END
    END

    FETCH NEXT FROM ProcCursor INTO @ObjID, @Name, @Def;
END

CLOSE ProcCursor;
DEALLOCATE ProcCursor;

-- قائمة ما سيُصلَح
SELECT Name AS [الاسم الحالي], OldName AS [الاسم داخل النص], LEN(NewDef) AS [طول التعريف]
FROM @Fix
ORDER BY Name;

IF @Apply = 1
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @FixName SYSNAME, @FixDef NVARCHAR(MAX);

        DECLARE FixCursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT Name, NewDef FROM @Fix ORDER BY Name;

        OPEN FixCursor;
        FETCH NEXT FROM FixCursor INTO @FixName, @FixDef;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC sys.sp_executesql @FixDef;
            PRINT N'تمت المزامنة: ' + @FixName;
            FETCH NEXT FROM FixCursor INTO @FixName, @FixDef;
        END

        CLOSE FixCursor;
        DEALLOCATE FixCursor;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'FixCursor') >= 0 CLOSE FixCursor;
        IF CURSOR_STATUS('local', 'FixCursor') > -3 DEALLOCATE FixCursor;
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
ELSE
    PRINT N'وضع العرض فقط. لتنفيذ الإصلاح غيّر @Apply إلى 1.';
GO

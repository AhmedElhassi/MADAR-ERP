USE [MADARERPDataBase]
GO
/* =====================================================================
   04: تهيئة الشركة الجديدة — الدليل الحسابي القياسي + مركز تكلفة «الإدارة العامة»
   ---------------------------------------------------------------------
   مسودة للمراجعة — لا تُنفَّذ قبل الموافقة.

   القواعد (كما اتفقنا):
     - الجذور الخمسة ثابتة: الأصول، الخصوم، حقوق الملكية، الإيرادات، المصروفات.
     - الأصول/الخصوم تنقسم إلى متداولة وغير متداولة (ثابتة).
     - الإيرادات لا تُقسَّم.
     - المصروفات ← مصروفات التشغيل ← الإدارة والعمومية.
     - البنود المرتبطة بمنظومة تُنشأ فقط إن اختارتها الشركة (Mng_Company.CmpSystems).
     - كل حساب مرتبط بعملية (Acc_Operation) تُسجَّل له قاعدة Acc_PostingRule وقت الإنشاء:
       حالة 3 للأب الآلي (خزائن، مصارف، عهد، مخازن، موردون...)، وحالة 1 للحساب الآلي المفرد (مرتبات، إتلاف...).
     - مركز تكلفة «الإدارة العامة» جذر (أب NULL) يُنشأ مع الشركة.

   قبل التشغيل املأ معرّفات المنظومات في أعلى الإجراء؛ الصفر يمنع التنفيذ عمداً
   حتى لا يُنشأ دليل ناقص بصمت. أرقام العمليات وحالاتها مكتوبة في جدول التعريف.

   أكواد الحسابات: يبنيها Acc_UpdateAccountCode من الترتيب والأب (كبقية النظام).
   ===================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_InitializeCompany]
    @Cmp  INT,
    @User BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    /* ===================== ثوابت تُملأ مرة واحدة ===================== */
    -- معرّفات المنظومات من Mng_System (SysID). 0 = لم تُحدَّد.
    DECLARE @SysTreasury   TINYINT = 4;   -- الخزينة
    DECLARE @SysWarehouse  TINYINT = 12;   -- المخازن
    DECLARE @SysCustody    TINYINT = 7;   -- العهد المالية
    DECLARE @SysPurchases  TINYINT = 11;   -- المشتريات
    DECLARE @SysContracts  TINYINT = 16;   -- العقود والمستخلصات
    DECLARE @SysProjects   TINYINT = 15;   -- إدارة المشاريع
    DECLARE @SysPayroll    TINYINT = 22;   -- المرتبات
    DECLARE @SysHR         TINYINT = 21;   -- الموارد البشرية
    DECLARE @SysFixed      TINYINT = 6;   -- الأصول الثابتة

    /* ================================================================ */

    DECLARE @TranStarted BIT = 0;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SP_Acc_InitCompany;

        IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
            THROW 52300, N'المستخدم غير صحيح.', 1;

        DECLARE @Systems NVARCHAR(500);
        SELECT @Systems = CmpSystems FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @Cmp;
        IF @@ROWCOUNT = 0
            THROW 52301, N'الشركة غير موجودة.', 1;

        IF EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccCompany = @Cmp)
            THROW 52302, N'للشركة دليل حسابي مسبق؛ التهيئة تُنفَّذ مرة واحدة عند الإنشاء فقط.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCCompany = @Cmp)
            THROW 52303, N'للشركة مراكز تكلفة مسبقة؛ التهيئة تُنفَّذ مرة واحدة عند الإنشاء فقط.', 1;

        IF @SysTreasury = 0 OR @SysWarehouse = 0 OR @SysCustody = 0 OR @SysPurchases = 0
           OR @SysContracts = 0 OR @SysProjects = 0 OR @SysPayroll = 0 OR @SysHR = 0 OR @SysFixed = 0
            THROW 52304, N'عيّن معرّفات المنظومات في أعلى الإجراء قبل الاستخدام.', 1;

        /* ---------- المنظومات المختارة ---------- */
        DECLARE @Chosen TABLE (SysID INT PRIMARY KEY);
        INSERT @Chosen (SysID)
        SELECT DISTINCT TRY_CONVERT(INT, LTRIM(RTRIM(value)))
        FROM STRING_SPLIT(ISNULL(@Systems, N''), N',')
        WHERE TRY_CONVERT(INT, LTRIM(RTRIM(value))) IS NOT NULL;

        DECLARE @Flags TABLE (Code CHAR(3) PRIMARY KEY, Has BIT NOT NULL);
        INSERT @Flags (Code, Has) VALUES
            ('TRE', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysTreasury),  1, 0)),
            ('WRH', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysWarehouse), 1, 0)),
            ('CUS', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysCustody),   1, 0)),
            ('PUR', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysPurchases), 1, 0)),
            ('CON', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysContracts), 1, 0)),
            ('PRJ', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysProjects),  1, 0)),
            ('PAY', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysPayroll),   1, 0)),
            ('HR ', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysHR),        1, 0)),
            ('FIX', IIF(EXISTS (SELECT 1 FROM @Chosen WHERE SysID = @SysFixed),     1, 0));

        /* ---------- تعريف الدليل ----------
           K = مفتاح، P = مفتاح الأب، E = AccEnd (1 ميزانية، 2 دخل)،
           T = AccType (ميزانية: 0 أصول 1 خصوم 2 حقوق ملكية | دخل: 0 إيرادات 1 مصروفات)،
           A,B = منظومة مطلوبة (أي واحدة منهما تكفي؛ NULL = دائم)،
           Op/St = العملية وحالة الحساب في Acc_PostingRule (NULL = حساب هيكلي بلا قاعدة):
             1 حساب نظام (ابن) لا يُمس | 2 حساب نظام مقفل | 3 أب آلي | 4 أب يسمح بأبناء يدويين */
        DECLARE @Def TABLE
        (
            Seq INT PRIMARY KEY, K VARCHAR(20) NOT NULL, P VARCHAR(20) NULL,
            Nm NVARCHAR(500) NOT NULL, E TINYINT NOT NULL, T TINYINT NOT NULL,
            A CHAR(3) NULL, B CHAR(3) NULL, Op SMALLINT NULL, St TINYINT NULL
        );
        INSERT @Def (Seq, K, P, Nm, E, T, A, B, Op, St) VALUES
        -- الأصول
        (10 ,'AST'     ,NULL      ,N'الأصول'                          ,1,0,NULL,NULL,NULL,NULL),
        (11 ,'AST_C'   ,'AST'     ,N'الأصول المتداولة'                 ,1,0,NULL,NULL,NULL,NULL),
        (12 ,'CASH'    ,'AST_C'   ,N'النقدية وما في حكمها'             ,1,0,'TRE',NULL,NULL,NULL),
        (13 ,'CASH_T'  ,'CASH'    ,N'الخزائن'                          ,1,0,'TRE',NULL,101 ,3),
        (14 ,'CASH_B'  ,'CASH'    ,N'المصارف'                          ,1,0,'TRE',NULL,102 ,3),
        (15 ,'CASH_R'  ,'CASH'    ,N'تحويلات نقدية بالطريق'            ,1,0,'TRE',NULL,104 ,1),
        (16 ,'INV'     ,'AST_C'   ,N'المخزون'                          ,1,0,'WRH',NULL,202 ,3),
        (17 ,'CUS'     ,'AST_C'   ,N'العهد المالية'                    ,1,0,'CUS',NULL,103 ,3),
        (18 ,'OWN'     ,'AST_C'   ,N'أصحاب الأعمال'                    ,1,0,'CON',NULL,301 ,3),
        (19 ,'ADVSUP'  ,'AST_C'   ,N'دفعات مقدمة'                      ,1,0,'PUR','CON',NULL,NULL),
        (20 ,'LOAN'    ,'AST_C'   ,N'سلف العاملين'                     ,1,0,'PAY',NULL,405 ,1),
        (21 ,'EMPDEBT' ,'AST_C'   ,N'مدينون - موظفو الشركة'            ,1,0,'PAY',NULL,406 ,1),
        (22 ,'PREPAID' ,'AST_C'   ,N'المصروفات المقدمة'                ,1,0,'PAY',NULL,NULL,NULL),
        (23 ,'PRE_SAL' ,'PREPAID' ,N'مرتبات مقدمة'                     ,1,0,'PAY',NULL,402 ,1),
        (24 ,'PRE_DED' ,'PREPAID' ,N'خصومات من الموظفين لصالح الغير'   ,1,0,'PAY',NULL,407 ,1),
        (25 ,'AST_N'   ,'AST'     ,N'الأصول غير المتداولة'             ,1,0,NULL,NULL,NULL,NULL),
        (26 ,'FIXED'   ,'AST_N'   ,N'الأصول الثابتة'                   ,1,0,'FIX',NULL,105 ,3),
        -- الخصوم
        (30 ,'LIA'     ,NULL      ,N'الخصوم'                          ,1,1,NULL,NULL,NULL,NULL),
        (31 ,'LIA_C'   ,'LIA'     ,N'الخصوم المتداولة'                 ,1,1,NULL,NULL,NULL,NULL),
        (32 ,'SUP'     ,'LIA_C'   ,N'الموردون'                         ,1,1,'PUR',NULL,201 ,3),
        (33 ,'EXE'     ,'LIA_C'   ,N'منفذو الأعمال'                    ,1,1,'CON',NULL,302 ,3),
        (34 ,'ACCR'    ,'LIA_C'   ,N'المصروفات المستحقة'               ,1,1,'PAY',NULL,404 ,1),
        (35 ,'SUNDRY'  ,'LIA_C'   ,N'الدائنون المتنوعون'               ,1,1,'PAY',NULL,408 ,3),
        (36 ,'LIA_N'   ,'LIA'     ,N'الخصوم غير المتداولة'             ,1,1,NULL,NULL,NULL,NULL),
        -- حقوق الملكية
        (40 ,'EQT'     ,NULL      ,N'حقوق الملكية'                    ,1,2,NULL,NULL,NULL,NULL),
        -- الإيرادات
        (50 ,'REV'     ,NULL      ,N'الإيرادات'                       ,2,0,NULL,NULL,NULL,NULL),
        -- المصروفات
        (60 ,'EXP'     ,NULL      ,N'المصروفات'                       ,2,1,NULL,NULL,NULL,NULL),
        (61 ,'OPX'     ,'EXP'     ,N'مصروفات التشغيل'                 ,2,1,NULL,NULL,NULL,NULL),
        (62 ,'OPX_MAT' ,'OPX'     ,N'مواد التشغيل'                    ,2,1,'WRH',NULL,203 ,3),
        (63 ,'OPX_WRK' ,'OPX'     ,N'أعمال التشغيل'                   ,2,1,'CON','PRJ',303 ,3),
        (64 ,'GNA'     ,'OPX'     ,N'الإدارة والعمومية'               ,2,1,NULL,NULL,NULL,NULL),
        (65 ,'GNA_PAY' ,'GNA'     ,N'أجور ومرتبات'                    ,2,1,'PAY',NULL,401 ,1),
        (66 ,'GNA_BON' ,'GNA'     ,N'مكافآت'                          ,2,1,'PAY',NULL,403 ,1),
        (67 ,'GNA_LIV' ,'GNA'     ,N'مصاريف إعاشة'                    ,2,1,'PAY',NULL,409 ,1),
        (68 ,'GNA_DMG' ,'GNA'     ,N'تلف المخزون'                     ,2,1,'WRH',NULL,204 ,1),
        (69 ,'GNA_MED' ,'GNA'     ,N'مصاريف علاجية وطبية'             ,2,1,'HR ',NULL,NULL,NULL),
        (70 ,'GNA_STA' ,'GNA'     ,N'قرطاسية عامة'                    ,2,1,NULL,NULL,NULL,NULL),
        (71 ,'GNA_RNT' ,'GNA'     ,N'إيجارات'                         ,2,1,NULL,NULL,NULL,NULL),
        (72 ,'GNA_UTL' ,'GNA'     ,N'كهرباء ومياه واتصالات'           ,2,1,NULL,NULL,NULL,NULL),
        (73 ,'GNA_MNT' ,'GNA'     ,N'صيانة وإصلاح'                    ,2,1,NULL,NULL,NULL,NULL),
        (74 ,'GNA_FEE' ,'GNA'     ,N'رسوم ومصاريف بنكية وحكومية'      ,2,1,NULL,NULL,NULL,NULL),
        (75 ,'GNA_HSP' ,'GNA'     ,N'ضيافة ونظافة'                    ,2,1,NULL,NULL,NULL,NULL),
        (76 ,'GNA_OTH' ,'GNA'     ,N'مصروفات متنوعة'                  ,2,1,NULL,NULL,NULL,NULL);

        /* ---------- إدراج العقد المطلوبة ---------- */
        DECLARE @Map TABLE (K VARCHAR(20) PRIMARY KEY, AccID BIGINT NOT NULL, Lvl SMALLINT NOT NULL, Chid SMALLINT NOT NULL);

        DECLARE @K VARCHAR(20), @P VARCHAR(20), @Nm NVARCHAR(500), @E TINYINT, @T TINYINT, @Op SMALLINT, @St TINYINT;
        DECLARE @PID BIGINT, @PLvl SMALLINT, @PChid SMALLINT, @Ord INT, @NewID BIGINT;

        DECLARE c CURSOR LOCAL FAST_FORWARD FOR
            SELECT d.K, d.P, d.Nm, d.E, d.T, d.Op, d.St
            FROM @Def AS d
            WHERE d.A IS NULL
               OR EXISTS (SELECT 1 FROM @Flags f WHERE f.Has = 1 AND f.Code IN (d.A, d.B))
            ORDER BY d.Seq;
        OPEN c;
        FETCH NEXT FROM c INTO @K, @P, @Nm, @E, @T, @Op, @St;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @P IS NULL
            BEGIN
                SELECT @Ord = ISNULL(MAX(AccOrder), 0) + 1
                FROM dbo.Acc_Account WHERE AccCompany = @Cmp AND AccParentID IS NULL;
                SET @PID = NULL; SET @PLvl = 0;
            END
            ELSE
            BEGIN
                SELECT @PID = AccID, @PLvl = Lvl, @PChid = Chid FROM @Map WHERE K = @P;
                IF @PID IS NULL
                    THROW 52305, N'خلل في تعريف الدليل: الأب غير موجود قبل الابن.', 1;
                SET @Ord = @PChid + 1;
            END

            INSERT dbo.Acc_Account
                (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccState, AccDateTime, AccUser, AccCompany)
            VALUES
                (@E, @T, @PID, @Ord, @PLvl + 1, 0,
                 IIF(@PID IS NULL, CONVERT(NVARCHAR(60), @Ord), N'~' + CONVERT(NVARCHAR(40), NEWID())),   -- رمز مؤقت فريد؛ يُعاد بناء رموز الفروع لاحقاً
                 @Nm, 0, SYSDATETIME(), @User, @Cmp);
            SET @NewID = CONVERT(BIGINT, SCOPE_IDENTITY());

            IF @PID IS NOT NULL
            BEGIN
                UPDATE dbo.Acc_Account SET AccChid = AccChid + 1 WHERE AccID = @PID;
                UPDATE @Map SET Chid = Chid + 1 WHERE K = @P;
            END

            INSERT @Map (K, AccID, Lvl, Chid) VALUES (@K, @NewID, @PLvl + 1, 0);

            -- قاعدة الترحيل للحساب المرتبط بعملية
            IF @Op IS NOT NULL
                INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (@Op, @NewID, @St);

            FETCH NEXT FROM c INTO @K, @P, @Nm, @E, @T, @Op, @St;
        END
        CLOSE c; DEALLOCATE c;

        -- رموز الفروع بنفس دالة النظام
        EXEC dbo.Acc_UpdateAccountCode @AccCompany = @Cmp;

        -- سجل التاريخ
        INSERT dbo.Acc_AccountHistory
            (AccHOpration, AccHAccID, AccHEnd, AccHType, AccHParentID, AccHOrder, AccHLevel, AccHChid,
             AccHCode, AccHName, AccHState, AccHDateTime, AccHUser, AccHCompany)
        SELECT 1, AccID, AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid,
               AccCode, AccName, AccState, AccDateTime, AccUser, AccCompany
        FROM dbo.Acc_Account
        WHERE AccCompany = @Cmp;

        /* ---------- مركز تكلفة «الإدارة العامة» ---------- */
        DECLARE @CsCID BIGINT;
        INSERT dbo.Acc_CostCenter
            (CsCParentID, CsCOrder, CsCLevel, CsCChid, CsCCode, CsCName, CsCState, CsCDateTime, CsCUser, CsCCompany)
        VALUES (NULL, 1, 1, 0, N'1', N'الإدارة العامة', 0, SYSDATETIME(), @User, @Cmp);
        SET @CsCID = CONVERT(BIGINT, SCOPE_IDENTITY());

        INSERT dbo.Acc_CostCenterHistory
            (CsCHOpration, CsCHCsCID, CsCHParentID, CsCHOrder, CsCHLevel, CsCHChid, CsCHCode, CsCHName,
             CsCHState, CsCHDateTime, CsCHUser, CsCHCompany)
        SELECT 1, CsCID, CsCParentID, CsCOrder, CsCLevel, CsCChid, CsCCode, CsCName,
               CsCState, CsCDateTime, CsCUser, CsCCompany
        FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID;

        IF @TranStarted = 1 COMMIT TRANSACTION;

        SELECT @Cmp AS CmpID, COUNT(*) AS AccountsCreated FROM dbo.Acc_Account WHERE AccCompany = @Cmp;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'c') >= 0 CLOSE c;
        IF CURSOR_STATUS('local', 'c') > -3 DEALLOCATE c;

        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SP_Acc_InitCompany;
        THROW;
    END CATCH
END
GO

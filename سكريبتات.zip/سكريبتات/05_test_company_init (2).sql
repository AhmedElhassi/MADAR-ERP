USE [MADARERPDataBase]
GO
/* =====================================================================
   05: اختبار عملي لتهيئة شركة جديدة — لا يترك أي أثر (ينتهي بـ ROLLBACK)
   ---------------------------------------------------------------------
   قبل التشغيل: شغّل 04_company_initialization.sql لإنشاء/تحديث الإجراء.
   يُنشئ شركة مؤقتة بالمنظومات الأساسية الست فقط (1,4,11,12,21,22)،
   فيُفترض ألا تُنشأ حسابات العهد والعقود والمشاريع والأصول الثابتة.

   المتوقع:
     حسابات = 40 | قواعد ترحيل = 16 | مراكز تكلفة = 1 | سنة مالية = 1
     عملات = 1 | تصنيف تدفقات = 8 | صلاحيات للمستخدم = 2 (المنظومتان 1 و 4)
   ===================================================================== */
SET NOCOUNT ON;

DECLARE @Cmp INT;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC dbo.Mng_InsertCompany
         @CmpName    = N'شركة اختبار مؤقتة',
         @CmpEName   = N'Temp Test Company',
         @CmpCode    = N'ZZZ',
         @CmpState   = 0,
         @CmpUser    = 1,
         @CmpSystems = N'1,4,11,12,21,22';

    SELECT @Cmp = CmpID FROM dbo.Mng_Company WHERE CmpCode = N'ZZZ';

    -- التهيئة تتم الآن داخل Mng_InsertCompany نفسه (06)

    /* ---------- ملخص النتائج ---------- */
    SELECT
        @Cmp AS CmpID,
        (SELECT COUNT(*) FROM dbo.Acc_Account    WHERE AccCompany = @Cmp) AS Accounts,
        (SELECT COUNT(*) FROM dbo.Acc_PostingRule r JOIN dbo.Acc_Account a ON a.AccID = r.AccID
                          WHERE a.AccCompany = @Cmp)                       AS PostingRules,
        (SELECT COUNT(*) FROM dbo.Acc_CostCenter WHERE CsCCompany = @Cmp) AS CostCenters,
        (SELECT COUNT(*) FROM dbo.Acc_FiscalYear WHERE AccFCmpID = @Cmp)  AS FiscalYears,
        (SELECT COUNT(*) FROM dbo.Acc_Currency   WHERE CurCmp = @Cmp)     AS Currencies,
        (SELECT COUNT(*) FROM dbo.Acc_CashFlowAccounts c JOIN dbo.Acc_Account a ON a.AccID = c.AccID
                          WHERE a.AccCompany = @Cmp)                       AS CashFlowRows,
        (SELECT COUNT(*) FROM dbo.Mng_UserParmations
                          WHERE USPCompanyID = @Cmp AND USPUserID = 1)     AS UserPerms;

    /* ---------- الدليل المُنشأ ---------- */
    SELECT AccCode, AccName, AccLevel, AccEnd, AccType
    FROM dbo.Acc_Account WHERE AccCompany = @Cmp ORDER BY AccCode;

    /* ---------- قواعد الترحيل ---------- */
    SELECT a.AccCode, a.AccName, r.OpID, r.StateID
    FROM dbo.Acc_PostingRule r JOIN dbo.Acc_Account a ON a.AccID = r.AccID
    WHERE a.AccCompany = @Cmp ORDER BY a.AccCode;

    ROLLBACK TRANSACTION;   -- لا أثر دائم
    PRINT N'تم الاختبار وتراجع كل شيء (ROLLBACK).';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    SELECT ERROR_NUMBER() AS ErrNo, ERROR_MESSAGE() AS ErrMsg, ERROR_LINE() AS ErrLine,
           ERROR_PROCEDURE() AS ErrProc;
END CATCH
GO

USE [MADARERPDataBase]
GO
/* =====================================================================
   06: ربط التهيئة بإنشاء الشركة (Mng_InsertCompany)
   ---------------------------------------------------------------------
   التغييرات على الإجراء القائم (وما عداها كما هو):
     1) @CmpUser إلزامي ويجب أن يكون مستخدماً موجوداً (سجلات التهيئة تُنسب إليه).
     2) المنظومات الأساسية الست تُضاف تلقائياً لكل شركة: 1 و4 و11 و12 و21 و22.
     3) بعد إنشاء السنة المالية يُستدعى Acc_InitializeCompany داخل المعاملة نفسها:
        فإن فشلت التهيئة تتراجع الشركة كلها.
   شغّل 04_company_initialization.sql أولاً.
   ===================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[Mng_InsertCompany]
    @CmpName NVARCHAR(255) = NULL,
    @CmpEName NVARCHAR(255) = NULL,
    @CmpCode NVARCHAR(3) = NULL,
    @CmpLogo VARBINARY(MAX) = NULL,
    @CmpState TINYINT = NULL,
    @CmpDateTime DATETIME = NULL,
    @CmpUser BIGINT = NULL,
    @CmpSystems NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @CmpSystems = NULLIF(LTRIM(RTRIM(@CmpSystems)), N'');
    SET @CmpCode = NULLIF(UPPER(LTRIM(RTRIM(@CmpCode))), N'');

    DECLARE @Now DATETIME = GETDATE();
    DECLARE @FiscalYear INT = YEAR(@Now);
    DECLARE @NewID BIGINT;
    DECLARE @CmpID INT;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- حجز جدول الشركات لمنع تعارض الإدخال المتزامن
        SELECT @NewID = ISNULL(MAX(CONVERT(BIGINT, CmpID)), 0) + 1
        FROM dbo.Mng_Company WITH (TABLOCKX, HOLDLOCK);

        -- منشئ الشركة إلزامي (يُنسب إليه الدليل والتهيئة)
        IF ISNULL(@CmpUser, 0) <= 0
           OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @CmpUser)
            THROW 51104, N'منشئ الشركة إلزامي ويجب أن يكون مستخدماً موجوداً.', 1;

        -- التحقق من رمز الشركة
        IF @CmpCode IS NOT NULL
        BEGIN
            IF LEN(@CmpCode) <> 3
               OR @CmpCode COLLATE Latin1_General_100_BIN2
                  LIKE N'%[^A-Z]%'
            BEGIN
                THROW 51100,
                    N'رمز الشركة يجب أن يتكون من ثلاثة أحرف إنجليزية كبيرة فقط.',
                    1;
            END;

            IF EXISTS
            (
                SELECT 1
                FROM dbo.Mng_Company
                WHERE CmpCode = @CmpCode
            )
            BEGIN
                THROW 51101,
                    N'رمز الشركة مستخدم مسبقاً، يرجى اختيار رمز آخر.',
                    1;
            END;
        END;

        -- التحقق من صحة المنظومات المدخلة
        IF @CmpSystems IS NOT NULL
           AND EXISTS
           (
               SELECT 1
               FROM STRING_SPLIT(@CmpSystems, N',') ss
               CROSS APPLY
               (
                   SELECT TRY_CONVERT(INT, LTRIM(RTRIM(ss.value))) AS ID
               ) x
               WHERE x.ID IS NULL
                  OR x.ID NOT BETWEEN 1 AND 255
                  OR NOT EXISTS
                  (
                      SELECT 1
                      FROM dbo.Mng_System s
                      WHERE s.SysID = x.ID
                  )
           )
        BEGIN
            THROW 51102,
                N'قائمة المنظومات تحتوي على معرّف غير صحيح أو منظومة غير موجودة.',
                1;
        END;

        -- المنظومات الأساسية لكل شركة + ما اختاره المستخدم (بلا تكرار)
        SELECT @CmpSystems = STRING_AGG(CONVERT(NVARCHAR(10), u.ID), N',') WITHIN GROUP (ORDER BY u.ID)
        FROM
        (
            SELECT TRY_CONVERT(INT, LTRIM(RTRIM(ss.value))) AS ID
            FROM STRING_SPLIT(ISNULL(@CmpSystems, N''), N',') ss
            WHERE TRY_CONVERT(INT, LTRIM(RTRIM(ss.value))) IS NOT NULL
            UNION
            SELECT ID FROM (VALUES (1), (4), (11), (12), (21), (22)) AS b(ID)
        ) AS u;

        -- التحقق من الحد الأعلى لمعرف الشركة
        IF @NewID > 2147483647
        BEGIN
            THROW 51103,
                N'تم بلوغ الحد الأعلى لمعرّف الشركة.',
                1;
        END;

        SET @CmpID = CONVERT(INT, @NewID);

        -- إضافة الشركة
        INSERT INTO dbo.Mng_Company
        (
            CmpID, CmpName, CmpEName, CmpCode, CmpLogo,
            CmpState, CmpDateTime, CmpUser, CmpSystems
        )
        VALUES
        (
            @CmpID, @CmpName, @CmpEName, @CmpCode, @CmpLogo,
            COALESCE(@CmpState, 0), COALESCE(@CmpDateTime, @Now), @CmpUser, @CmpSystems
        );

        -- إنشاء السنة المالية للشركة الجديدة
        INSERT INTO dbo.Acc_FiscalYear
        (
            AccFYear, AccFName, AccFState, AccFDateTime, AccFUser, AccFCmpID
        )
        VALUES
        (
            @FiscalYear,
            N'السنة المالية ' + CONVERT(NVARCHAR(4), @FiscalYear),
            0, @Now, @CmpUser, @CmpID
        );

        -- تهيئة الشركة: الدليل الحسابي، مركز تكلفة الإدارة العامة، العملة، صلاحيات المنشئ
        EXEC dbo.Acc_InitializeCompany @Cmp = @CmpID, @User = @CmpUser, @Quiet = 1;

        COMMIT TRANSACTION;

        SELECT @CmpID AS CmpID;

    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

USE [MADARERPDataBase]
GO
/* =====================================================================
   07: تحديث شركة هُيّئت بالنسخة القديمة من التهيئة (افتراضياً الشركة 1)
   ---------------------------------------------------------------------
   يضيف ما نقص فقط، ويمكن تشغيله أكثر من مرة دون ازدواج:
     1) اسم الحساب الآلي (عملية 407) = «مدفوعات عن الموظفين لصالح الغير».
     2) حسابا «رأس المال» و«الاحتياطيات» تحت جذر حقوق الملكية.
     3) تصنيف التدفقات النقدية للحسابات الهيكلية.
   ===================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Cmp INT = 1;      -- الشركة المراد تحديثها
DECLARE @User BIGINT = 1;  -- منفّذ التحديث

BEGIN TRY
    BEGIN TRANSACTION;

    -- 1) الاسم
    UPDATE a SET AccName = N'مدفوعات عن الموظفين لصالح الغير'
    FROM dbo.Acc_Account a
    JOIN dbo.Acc_PostingRule r ON r.AccID = a.AccID AND r.OpID = 407
    WHERE a.AccCompany = @Cmp AND a.AccName <> N'مدفوعات عن الموظفين لصالح الغير';

    -- 2) حقوق الملكية
    DECLARE @Eq BIGINT = (SELECT AccID FROM dbo.Acc_Account
                          WHERE AccCompany = @Cmp AND AccEnd = 1 AND AccType = 2 AND AccParentID IS NULL);
    IF @Eq IS NULL THROW 52320, N'جذر حقوق الملكية غير موجود.', 1;

    DECLARE @Names TABLE (Seq INT, Nm NVARCHAR(500));
    INSERT @Names VALUES (1, N'رأس المال'), (2, N'الاحتياطيات');

    DECLARE @Seq INT, @Nm NVARCHAR(500), @Ord INT, @Lvl SMALLINT, @NewID BIGINT;
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT Seq, Nm FROM @Names ORDER BY Seq;
    OPEN c; FETCH NEXT FROM c INTO @Seq, @Nm;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccCompany = @Cmp AND AccParentID = @Eq AND AccName = @Nm)
        BEGIN
            SELECT @Ord = ISNULL(MAX(AccOrder), 0) + 1 FROM dbo.Acc_Account WHERE AccCompany = @Cmp AND AccParentID = @Eq;
            SELECT @Lvl = AccLevel + 1 FROM dbo.Acc_Account WHERE AccID = @Eq;

            INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName,
                                    AccState, AccDateTime, AccUser, AccCompany)
            VALUES (1, 2, @Eq, @Ord, @Lvl, 0, N'~' + CONVERT(NVARCHAR(40), NEWID()), @Nm, 0, SYSDATETIME(), @User, @Cmp);
            SET @NewID = CONVERT(BIGINT, SCOPE_IDENTITY());

            UPDATE dbo.Acc_Account SET AccChid = AccChid + 1 WHERE AccID = @Eq;
        END
        FETCH NEXT FROM c INTO @Seq, @Nm;
    END
    CLOSE c; DEALLOCATE c;

    EXEC dbo.Acc_UpdateAccountCode @AccCompany = @Cmp;

    -- سجل التاريخ للحسابين الجديدين فقط
    INSERT dbo.Acc_AccountHistory
        (AccHOpration, AccHAccID, AccHEnd, AccHType, AccHParentID, AccHOrder, AccHLevel, AccHChid,
         AccHCode, AccHName, AccHState, AccHDateTime, AccHUser, AccHCompany)
    SELECT 1, a.AccID, a.AccEnd, a.AccType, a.AccParentID, a.AccOrder, a.AccLevel, a.AccChid,
           a.AccCode, a.AccName, a.AccState, a.AccDateTime, a.AccUser, a.AccCompany
    FROM dbo.Acc_Account a
    WHERE a.AccCompany = @Cmp AND a.AccParentID = @Eq
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_AccountHistory h WHERE h.AccHAccID = a.AccID);

    -- 3) تصنيف التدفقات النقدية (بالاسم والموضع تحت الجذور)
    INSERT dbo.Acc_CashFlowAccounts (AccID, CashFlowType)
    SELECT a.AccID, v.CfType
    FROM (VALUES (N'النقدية وما في حكمها', 1), (N'الأصول المتداولة', 2), (N'الأصول غير المتداولة', 3),
                 (N'الخصوم المتداولة', 2), (N'الخصوم غير المتداولة', 4)) AS v(Nm, CfType)
    JOIN dbo.Acc_Account a ON a.AccCompany = @Cmp AND a.AccName = v.Nm AND a.AccEnd = 1
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_CashFlowAccounts c WHERE c.AccID = a.AccID);

    INSERT dbo.Acc_CashFlowAccounts (AccID, CashFlowType)
    SELECT a.AccID, v.CfType
    FROM (VALUES (1, 2, 4), (2, 0, 2), (2, 1, 2)) AS v(AccEnd, AccType, CfType)   -- حقوق الملكية والإيرادات والمصروفات: AccEnd,AccType,النوع
    JOIN dbo.Acc_Account a ON a.AccCompany = @Cmp AND a.AccParentID IS NULL
                          AND a.AccEnd = v.AccEnd AND a.AccType = v.AccType
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_CashFlowAccounts c WHERE c.AccID = a.AccID);

    COMMIT TRANSACTION;

    SELECT a.AccCode, a.AccName, c.CashFlowType
    FROM dbo.Acc_Account a
    LEFT JOIN dbo.Acc_CashFlowAccounts c ON c.AccID = a.AccID
    WHERE a.AccCompany = @Cmp AND (a.AccLevel <= 2 OR c.AccID IS NOT NULL)
    ORDER BY a.AccCode;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS('local', 'c') >= 0 CLOSE c;
    IF CURSOR_STATUS('local', 'c') > -3 DEALLOCATE c;
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH
GO

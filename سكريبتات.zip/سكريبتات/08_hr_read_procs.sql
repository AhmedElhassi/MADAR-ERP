USE [MADARERPDataBase]
GO
/* =====================================================================
   08: إجراءات قراءة الموارد البشرية الناقصة
   ---------------------------------------------------------------------
   1) Emp_SelectEmployee: قراءة موظف/موظفين مع الشركة (عزل كامل) وبكل التفاصيل:
      الأساسي + المسمى + البيانات الشخصية + العقد/الراتب/موقع العمل الفعّال.
      يحل محل Emp_GetEmployeeByID و Emp_SearchEmployee اللذين لا يعرفان
      الشركة ولا الحقول الجديدة.
   2) Emp_SelectOrganigramStructure: قراءة الهيكل التنظيمي (لم يكن له إجراء قراءة).
   الصورة: يُرجَع HasPic فقط؛ الصورة المخزّنة EmpPic لا تُنقل مع القوائم.
   ===================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[Emp_SelectEmployee]
    @Cmp    INT,
    @EmpID  BIGINT       = NULL,
    @Search NVARCHAR(50) = NULL,   -- رقم أو اسم (جزء منه)
    @State  TINYINT      = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50300, N'الشركة غير صحيحة.', 1;

    SET @Search = NULLIF(LTRIM(RTRIM(@Search)), N'');

    SELECT
        e.EmpID, e.EmpNum, e.EmpName, e.EmpState, e.EmpPicPath,
        CAST(CASE WHEN e.EmpPic IS NOT NULL THEN 1 ELSE 0 END AS BIT) AS HasPic,
        e.Emp_PosID, p.Emp_PosName,
        d.EmpGender, d.EmpNat, n.Emp_NatName AS EmpNatName,
        d.EmpBDate, d.EmpBPlace, d.EmpSocial, d.EmpCardNum,
        d.EmpQualification, q.Emp_EduQualName AS EmpQualificationName,
        d.EmpPhone, d.EmpAddress, d.EmpNots,
        c.ConID,  c.ConType, t.Emp_EmpTypeName AS ConTypeName, c.ConStartDate, c.ConEndDate,
        s.SalID,  s.SalAmount, s.SalCurrencyID, cu.CurCode AS SalCurrencyCode, s.SalStartDate,
        w.WsaID,  w.WsaSiteID, w.WsaStartDate
    FROM dbo.Emp_Employee AS e
    LEFT JOIN dbo.Emp_Position            AS p  ON p.Emp_PosCmp = e.EmpCompany AND p.Emp_PosID = e.Emp_PosID
    LEFT JOIN dbo.Emp_PersonalDetails     AS d  ON d.EmpCompany = e.EmpCompany AND d.EmpID = e.EmpID
    LEFT JOIN dbo.Emp_Nationality         AS n  ON n.Emp_NatCmp = e.EmpCompany AND n.Emp_NatID = d.EmpNat
    LEFT JOIN dbo.Emp_EducationalQualifications AS q
                                              ON q.Emp_EduQualCmp = e.EmpCompany AND q.Emp_EduQualID = d.EmpQualification
    OUTER APPLY (SELECT TOP (1) * FROM dbo.Emp_Contract AS x
                 WHERE x.EmpCompany = e.EmpCompany AND x.EmpID = e.EmpID AND x.ConEndDate IS NULL
                 ORDER BY x.ConStartDate DESC) AS c
    LEFT JOIN dbo.Emp_EmploymentTypes     AS t  ON t.Emp_EmpTypeCmp = e.EmpCompany AND t.Emp_EmpTypeID = c.ConType
    OUTER APPLY (SELECT TOP (1) * FROM dbo.Emp_Salary AS x
                 WHERE x.EmpCompany = e.EmpCompany AND x.EmpID = e.EmpID AND x.SalEndDate IS NULL
                 ORDER BY x.SalStartDate DESC) AS s
    LEFT JOIN dbo.Acc_Currency            AS cu ON cu.CurCmp = e.EmpCompany AND cu.CurID = s.SalCurrencyID
    OUTER APPLY (SELECT TOP (1) * FROM dbo.Emp_WorkSiteAssignment AS x
                 WHERE x.EmpCompany = e.EmpCompany AND x.EmpID = e.EmpID AND x.WsaEndDate IS NULL
                 ORDER BY x.WsaStartDate DESC) AS w
    WHERE e.EmpCompany = @Cmp
      AND (@EmpID  IS NULL OR e.EmpID = @EmpID)
      AND (@State  IS NULL OR e.EmpState = @State)
      AND (@Search IS NULL OR e.EmpNum LIKE N'%' + @Search + N'%' OR e.EmpName LIKE N'%' + @Search + N'%')
    ORDER BY e.EmpID;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[Emp_SelectOrganigramStructure]
    @EmpOrgStrCompany INT,
    @EmpOrgStrState   TINYINT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @EmpOrgStrCompany IS NULL OR @EmpOrgStrCompany <= 0
        THROW 50301, N'الشركة غير صحيحة.', 1;

    SELECT EmpOrgStrID, EmpOrgStrParentID, EmpOrgStrName, EmpOrgStrState
    FROM dbo.Emp_OrganigramStructure
    WHERE EmpOrgStrCompany = @EmpOrgStrCompany
      AND (@EmpOrgStrState IS NULL OR EmpOrgStrState = @EmpOrgStrState)
    ORDER BY ISNULL(EmpOrgStrParentID, 0), EmpOrgStrName;
END
GO

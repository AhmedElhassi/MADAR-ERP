/* =====================================================================
   اختبار الميزانية العمومية (Acc_SelectAccBalanceSheet) — يعمل على قاعدة فيها بيانات
   ---------------------------------------------------------------------
   1) يحفظ نتيجة الإجراء الحالية (قبل أي قيد تجريبي).
   2) يُدخل قيودًا تجريبية معروفة داخل معاملة.
   3) يتحقق أن الفرق = أثر القيود التجريبية فقط (للحسابات والآباء وصفّي النتائج والإجماليات).
   4) يتحقق من الخاصية الأساسية: BalanceDifference = فرق دفتر الأستاذ حتى @ToDate.
   5) ROLLBACK دائمًا: لا يبقى أي قيد تجريبي في قاعدتك.
   غيّر @UserId (مستخدم موجود في Mng_User) ثم نفّذ الملف كله.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Cmp    INT    = 10;
DECLARE @UserId BIGINT = 1;      -- رقم مستخدم موجود في Mng_User
DECLARE @Year   INT    = 2026;
DECLARE @From   DATE   = '2026-04-01';
DECLARE @To     DATE   = '2026-06-30';
DECLARE @Fail   INT    = 0;

BEGIN TRY
    BEGIN TRAN;

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);

    /* ---------- 1) اختيار الحسابات التحليلية ---------- */
    DECLARE @Aa BIGINT, @L1 BIGINT, @E1 BIGINT, @R1 BIGINT, @X1 BIGINT, @X2 BIGINT;

    SELECT TOP (1) @Aa = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 1 AND a.AccType = 0
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @L1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 1 AND a.AccType = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @E1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 1 AND a.AccType = 2
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @R1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 0
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @X1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @X2 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
      AND a.AccID <> @X1
    ORDER BY a.AccCode DESC;

    IF @Aa IS NULL OR @L1 IS NULL OR @E1 IS NULL OR @R1 IS NULL OR @X1 IS NULL OR @X2 IS NULL
        THROW 51001, N'تعذّر اختيار حسابات تحليلية للأصول والخصوم وحقوق الملكية والإيراد والمصروف.', 1;

    /* ---------- 2) جدول النتائج والحالة قبل القيود ---------- */
    CREATE TABLE #BS
    (
        AccID BIGINT, AccCode NVARCHAR(60), AccARName NVARCHAR(500), AccLevel INT,
        AccParint BIGINT NULL, AccParintName NVARCHAR(500) NULL, AccCountChid INT,
        AccType INT, AccountCategory NVARCHAR(30),
        OldDebit DECIMAL(38,3), OldCredit DECIMAL(38,3),
        NewDebit DECIMAL(38,3), NewCredit DECIMAL(38,3),
        BalanceDebit DECIMAL(38,3), BalanceCredit DECIMAL(38,3),
        TotBlcDebit DECIMAL(38,3), TotBlcCredit DECIMAL(38,3),
        NetBalance DECIMAL(38,3), MovementCount BIGINT, IsCurrentYearResult BIT,
        TotalAssets DECIMAL(38,3), TotalLiabilities DECIMAL(38,3), TotalEquity DECIMAL(38,3),
        BalanceDifference DECIMAL(38,3),
        IsPriorYearsResult BIT, PriorYearsResult DECIMAL(38,3), CurrentYearResult DECIMAL(38,3),
        ChkNonLeafAccounts INT, ChkForeignAccounts INT, ChkChidMismatch INT
    );

    INSERT #BS
    EXEC dbo.Acc_SelectAccBalanceSheet @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year;

    SELECT AccID,
           OldDebit - OldCredit AS OpenNet, NewDebit AS Deb, NewCredit AS Crd, MovementCount AS Cnt
    INTO #Base
    FROM #BS;

    SELECT TOP (1)
           TotalAssets AS Assets, TotalLiabilities AS Liab, TotalEquity AS Equity,
           BalanceDifference AS BalDiff, PriorYearsResult AS PriorRes, CurrentYearResult AS CurRes,
           ChkNonLeafAccounts AS C1, ChkForeignAccounts AS C2, ChkChidMismatch AS C3
    INTO #BaseTot
    FROM #BS;

    DECLARE @BaseRows INT = (SELECT COUNT(*) FROM #BS);

    /* ---------- 3) القيود التجريبية (كلها متوازنة) ---------- */
    CREATE TABLE #Line (EntryNo INT, EntryDate DATE, State TINYINT, AccID BIGINT, Deb DECIMAL(18,3), Crd DECIMAL(18,3));

    INSERT #Line VALUES
      -- 1: قبل بداية الفترة داخل السنة: أصل مقابل إيراد
      (1, '2026-03-05', 7, @Aa, 1000, 0), (1, '2026-03-05', 7, @R1, 0, 1000),
      -- 2: داخل الفترة: مصروف مقابل التزام
      (2, '2026-05-10', 7, @X1, 400, 0), (2, '2026-05-10', 7, @L1, 0, 400),
      -- 3: السنة السابقة: أصل ومصروف مقابل حقوق ملكية والتزام
      (3, '2025-12-20', 7, @Aa, 600, 0), (3, '2025-12-20', 7, @X2, 200, 0),
      (3, '2025-12-20', 7, @E1, 0, 600), (3, '2025-12-20', 7, @L1, 0, 200),
      -- 4: مسودة: يجب ألا تظهر
      (4, '2026-04-15', 0, @Aa, 9999, 0), (4, '2026-04-15', 0, @L1, 0, 9999),
      -- 5: بعد @ToDate: يجب ألا تظهر
      (5, '2026-09-01', 7, @Aa, 50, 0), (5, '2026-09-01', 7, @R1, 0, 50);

    DECLARE @no INT = (SELECT MIN(EntryNo) FROM #Line), @m BIGINT;
    WHILE @no IS NOT NULL
    BEGIN
        INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
        SELECT TOP (1) EntryDate, N'TEST ميزانية', 92000 + @no, State, @UserId, @Cmp
        FROM #Line WHERE EntryNo = @no;

        SET @m = SCOPE_IDENTITY();

        INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
        SELECT @m, AccID, Deb, Crd, N'TEST' FROM #Line WHERE EntryNo = @no;

        SET @no = (SELECT MIN(EntryNo) FROM #Line WHERE EntryNo > @no);
    END;

    /* ---------- 4) المتوقع: أثر القيود على حسابات الميزانية وعلى صفّي النتائج ---------- */
    -- حسابات الميزانية التحليلية
    SELECT v.AccID,
           CAST(ISNULL(SUM(CASE WHEN l.EntryDate <  @From THEN l.Deb - l.Crd END), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN l.Deb END), 0) AS DECIMAL(18,3))        AS Deb,
           CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN l.Crd END), 0) AS DECIMAL(18,3))        AS Crd,
           CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN 1 END), 0) AS INT)                        AS Cnt
    INTO #ExpLeaf
    FROM (VALUES (@Aa), (@L1), (@E1)) AS v(AccID)
    LEFT JOIN #Line AS l
           ON l.AccID = v.AccID AND l.State = 7 AND l.EntryDate <= @To
    GROUP BY v.AccID;

    -- (الحساب ← أحفاده) لكل دليل الشركة
    ;WITH Cl AS
    (
        SELECT a.AccID AS NodeID, a.AccID AS DescID
        FROM dbo.Acc_Account AS a WHERE a.AccCompany = @Cmp
        UNION ALL
        SELECT c.NodeID, k.AccID
        FROM Cl AS c
        JOIN dbo.Acc_Account AS k ON k.AccParentID = c.DescID AND k.AccCompany = @Cmp
    )
    SELECT NodeID, DescID INTO #XCl FROM Cl OPTION (MAXRECURSION 1000);

    SELECT c.NodeID AS AccID,
           CAST(ISNULL(SUM(e.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(e.Deb), 0) AS DECIMAL(18,3))     AS Deb,
           CAST(ISNULL(SUM(e.Crd), 0) AS DECIMAL(18,3))     AS Crd,
           CAST(ISNULL(SUM(e.Cnt), 0) AS INT)               AS Cnt
    INTO #ExpNode
    FROM #XCl AS c
    LEFT JOIN #ExpLeaf AS e ON e.AccID = c.DescID
    GROUP BY c.NodeID;

    -- صفّا النتائج من حسابات قائمة الدخل
    DECLARE @ExpPriorNet DECIMAL(18,3), @ExpCurOpen DECIMAL(18,3), @ExpCurDeb DECIMAL(18,3),
            @ExpCurCrd DECIMAL(18,3), @ExpCurCnt INT;

    SELECT @ExpPriorNet = CAST(ISNULL(SUM(CASE WHEN l.EntryDate < @YearStart THEN l.Deb - l.Crd END), 0) AS DECIMAL(18,3)),
           @ExpCurOpen  = CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @YearStart AND l.EntryDate < @From THEN l.Deb - l.Crd END), 0) AS DECIMAL(18,3)),
           @ExpCurDeb   = CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN l.Deb END), 0) AS DECIMAL(18,3)),
           @ExpCurCrd   = CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN l.Crd END), 0) AS DECIMAL(18,3)),
           @ExpCurCnt   = CAST(ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN 1 END), 0) AS INT)
    FROM #Line AS l
    WHERE l.State = 7 AND l.EntryDate <= @To AND l.AccID IN (@R1, @X1, @X2);

    -- الإجماليات المتوقعة (التغيّر)
    DECLARE @ExpAssets DECIMAL(18,3), @ExpLiab DECIMAL(18,3), @ExpEqAcc DECIMAL(18,3);
    SELECT @ExpAssets = ISNULL(SUM(CASE WHEN AccID = @Aa THEN  (OpenNet + Deb - Crd) END), 0),
           @ExpLiab   = ISNULL(SUM(CASE WHEN AccID = @L1 THEN -(OpenNet + Deb - Crd) END), 0),
           @ExpEqAcc  = ISNULL(SUM(CASE WHEN AccID = @E1 THEN -(OpenNet + Deb - Crd) END), 0)
    FROM #ExpLeaf;

    DECLARE @ExpPriorRes DECIMAL(18,3) = -@ExpPriorNet;
    DECLARE @ExpCurRes   DECIMAL(18,3) = -(@ExpCurOpen + @ExpCurDeb - @ExpCurCrd);
    DECLARE @ExpEquity   DECIMAL(18,3) = @ExpEqAcc + @ExpPriorRes + @ExpCurRes;

    /* ---------- 5) تشغيل الإجراء بعد القيود والمقارنة ---------- */
    DELETE #BS;
    INSERT #BS
    EXEC dbo.Acc_SelectAccBalanceSheet @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year;

    -- A) عدد الصفوف لم يتغير (الحسابات نفسها + صفّا النتائج)
    DECLARE @Rows INT = (SELECT COUNT(*) FROM #BS);
    IF @Rows = @BaseRows PRINT N'PASS A: عدد الصفوف ثابت (حسابات الميزانية + صفّا النتائج)';
    ELSE BEGIN PRINT N'FAIL A: تغيّر عدد الصفوف'; SET @Fail += 1; END;

    -- B) أثر القيود على كل حساب (تحليلي وأب)
    SELECT r.AccCode, r.AccARName,
           e.OpenNet AS ExpOpenΔ, (r.OldDebit - r.OldCredit) - b.OpenNet AS ActOpenΔ,
           e.Deb AS ExpDebΔ, r.NewDebit - b.Deb AS ActDebΔ,
           e.Crd AS ExpCrdΔ, r.NewCredit - b.Crd AS ActCrdΔ,
           e.Cnt AS ExpCntΔ, r.MovementCount - b.Cnt AS ActCntΔ
    INTO #Bad
    FROM #BS AS r
    JOIN #Base AS b ON b.AccID = r.AccID
    JOIN #ExpNode AS e ON e.AccID = r.AccID
    WHERE r.AccID > 0
      AND ( (r.OldDebit - r.OldCredit) - b.OpenNet <> e.OpenNet
         OR r.NewDebit  - b.Deb <> e.Deb
         OR r.NewCredit - b.Crd <> e.Crd
         OR r.MovementCount - b.Cnt <> e.Cnt );
    IF NOT EXISTS (SELECT 1 FROM #Bad) PRINT N'PASS B: أثر القيود على كل حسابات الميزانية (تحليلية وآباء) مطابق للمتوقع';
    ELSE BEGIN PRINT N'FAIL B: اختلافات في أرقام الحسابات'; SELECT TOP 30 * FROM #Bad; SET @Fail += 1; END;

    -- C) صفّا النتائج: -1 سنوات سابقة، -2 السنة الحالية
    SELECT r.AccID,
           (r.OldDebit - r.OldCredit) - b.OpenNet AS ActOpenΔ, r.NewDebit - b.Deb AS ActDebΔ,
           r.NewCredit - b.Crd AS ActCrdΔ, r.MovementCount - b.Cnt AS ActCntΔ
    INTO #ResRows
    FROM #BS AS r JOIN #Base AS b ON b.AccID = r.AccID
    WHERE r.AccID IN (-1, -2);

    IF  (SELECT COUNT(*) FROM #ResRows) = 2
    AND EXISTS (SELECT 1 FROM #ResRows WHERE AccID = -1 AND ActOpenΔ = @ExpPriorNet AND ActDebΔ = 0 AND ActCrdΔ = 0 AND ActCntΔ = 0)
    AND EXISTS (SELECT 1 FROM #ResRows WHERE AccID = -2 AND ActOpenΔ = @ExpCurOpen AND ActDebΔ = @ExpCurDeb AND ActCrdΔ = @ExpCurCrd AND ActCntΔ = @ExpCurCnt)
        PRINT CONCAT(N'PASS C: صفّا النتائج: سنوات سابقة ', @ExpPriorRes, N' | السنة الحالية ', @ExpCurRes);
    ELSE BEGIN PRINT N'FAIL C: صفّا النتائج لا يطابقان'; SELECT * FROM #ResRows; SET @Fail += 1; END;

    -- D) تغيّر الإجماليات
    IF EXISTS (SELECT 1
               FROM (SELECT TOP (1) * FROM #BS) AS t
               CROSS JOIN #BaseTot AS b
               WHERE t.TotalAssets      - b.Assets = @ExpAssets
                 AND t.TotalLiabilities - b.Liab   = @ExpLiab
                 AND t.TotalEquity      - b.Equity = @ExpEquity
                 AND t.PriorYearsResult  - b.PriorRes = @ExpPriorRes
                 AND t.CurrentYearResult - b.CurRes   = @ExpCurRes
                 AND t.BalanceDifference - b.BalDiff  = 0)
        PRINT CONCAT(N'PASS D: الإجماليات: أصول +', @ExpAssets, N' | خصوم +', @ExpLiab, N' | حقوق ملكية +', @ExpEquity, N' | الفرق لم يتغير');
    ELSE BEGIN PRINT N'FAIL D: تغيّر الإجماليات لا يطابق'; SELECT TOP 1 * FROM (SELECT TOP (1) TotalAssets, TotalLiabilities, TotalEquity, BalanceDifference FROM #BS) x;
               SELECT * FROM #BaseTot; SET @Fail += 1; END;

    -- E) الخاصية الأساسية: BalanceDifference = فرق دفتر الأستاذ حتى @ToDate (عند سلامة المؤشرات)
    DECLARE @LedgerNet DECIMAL(38,3) =
        (SELECT ISNULL(SUM(d.DayDDeb - d.DayDCrd), 0)
         FROM dbo.Acc_DayMaster AS m
         JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
         WHERE m.DayMCompany = @Cmp AND m.DayMState = 7 AND m.DayMDate <= @To);

    IF EXISTS (SELECT 1 FROM (SELECT TOP (1) * FROM #BS) AS t
               WHERE t.ChkNonLeafAccounts = 0 AND t.ChkForeignAccounts = 0 AND t.BalanceDifference = @LedgerNet)
        PRINT CONCAT(N'PASS E: BalanceDifference = فرق دفتر الأستاذ حتى ', CONVERT(NVARCHAR(10), @To, 23), N' = ', @LedgerNet);
    ELSE BEGIN
        PRINT N'FAIL E: BalanceDifference لا يساوي فرق دفتر الأستاذ';
        SELECT TOP (1) BalanceDifference, @LedgerNet AS LedgerNet, ChkNonLeafAccounts, ChkForeignAccounts FROM #BS;
        SET @Fail += 1;
    END;

    -- F) مؤشرات سلامة البيانات لم تتغير بالقيود التجريبية
    IF EXISTS (SELECT 1 FROM (SELECT TOP (1) * FROM #BS) AS t CROSS JOIN #BaseTot AS b
               WHERE t.ChkNonLeafAccounts <> b.C1 OR t.ChkForeignAccounts <> b.C2 OR t.ChkChidMismatch <> b.C3)
    BEGIN PRINT N'FAIL F: مؤشرات سلامة البيانات تغيّرت'; SET @Fail += 1; END
    ELSE PRINT N'PASS F: مؤشرات سلامة البيانات لم تتغير';

    -- G) @AllAcc = 1 : الحسابات التحليلية + صفّا النتائج
    DELETE #BS;
    INSERT #BS EXEC dbo.Acc_SelectAccBalanceSheet @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year, @AllAcc = 1;
    DECLARE @LeafBS INT = (SELECT COUNT(*) FROM dbo.Acc_Account AS a
                           WHERE a.AccCompany = @Cmp AND a.AccEnd = 1 AND a.AccType IN (0, 1, 2)
                             AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID));
    IF (SELECT COUNT(*) FROM #BS) = @LeafBS + 2 PRINT N'PASS G: @AllAcc = 1 يعرض التحليلية فقط + صفّي النتائج';
    ELSE BEGIN PRINT N'FAIL G: @AllAcc = 1 عدد الصفوف لا يطابق'; SET @Fail += 1; END;

    -- H) @BalnceAcc = 1 : لا صف برصيد صفر
    DELETE #BS;
    INSERT #BS EXEC dbo.Acc_SelectAccBalanceSheet @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year, @BalnceAcc = 1;
    IF EXISTS (SELECT 1 FROM #BS WHERE NetBalance = 0)
    BEGIN PRINT N'FAIL H: ظهر حساب رصيده صفر مع @BalnceAcc = 1'; SET @Fail += 1; END
    ELSE PRINT N'PASS H: @BalnceAcc = 1 يخفي الأرصدة الصفرية';

    IF @Fail = 0 PRINT N'==== كل الاختبارات نجحت ====';
    ELSE PRINT N'==== توجد اختبارات فاشلة (انظر FAIL أعلاه) ====';

    ROLLBACK TRAN;
    PRINT N'تم التراجع عن كل القيود التجريبية (ROLLBACK).';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    PRINT N'خطأ أثناء الاختبار (تم التراجع عن كل شيء): ' + ERROR_MESSAGE();
END CATCH;

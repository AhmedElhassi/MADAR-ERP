/* =====================================================================
   تعبئة جدول تصنيف التدفقات النقدية  dbo.Acc_CashFlowAccounts
   الشركة 10
   ---------------------------------------------------------------------
   CashFlowType: 1 النقدية وما يعادلها | 2 تشغيلية | 3 استثمارية | 4 تمويلية
   يُورَّث التصنيف إلى كل الأبناء، والأقرب يغلب. لذلك صُنّفت العقد العليا
   وأُخرجت منها الاستثناءات (مثل النقدية تحت الأصول المتداولة).

   الاستخدام:
     1) نفّذ السكربت كما هو (@Apply = 0): يعرض المعاينة ثم يتراجع.
     2) راجع التصنيف، وعدّل جدول القيم إن أردت.
     3) غيّر @Apply إلى 1 ونفّذ لتثبيته.
   لا يعدّل الصفوف الموجودة أصلًا في الجدول (يضيف الناقص فقط).
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Cmp   INT = 10;
DECLARE @Apply BIT = 0;      -- 0 = معاينة ثم تراجع، 1 = تثبيت

BEGIN TRAN;

-- التصنيف على العقد العليا (AccID كما في دليل الشركة 10)
CREATE TABLE #Map (AccID BIGINT NOT NULL PRIMARY KEY, CashFlowType TINYINT NOT NULL, Why NVARCHAR(200) NOT NULL);

INSERT INTO #Map (AccID, CashFlowType, Why)
VALUES
    -- الأصول
    (15,    1, N'النقدية وما يعادلها (1608)'),
    (13356, 3, N'أصول غير ملموسة (11)'),
    (13103, 3, N'أصول أخرى: معدات ووسائل نقل وأثاث (12)'),
    (13186, 3, N'أصول تحت التجهيز (13)'),
    (12909, 3, N'استثمارات القابضة (14)'),
    (5,     3, N'الأصول الثابتة (15)'),
    (6,     2, N'الأصول المتداولة (16): مدينون ومخازن وعهد ومصروفات مقدمة'),

    -- الخصوم
    (26,    2, N'الخصوم المتداولة (21): دائنون وموردون ومنفذو أعمال ومستحقات'),
    (12335, 4, N'جاري النماء القابضة (219): تمويل من الشركة الأم'),
    (13137, 3, N'مجمع إهلاك الأصول الثابتة (217): مرتبط بالأصول الثابتة'),

    -- حقوق الملكية
    (12997, 4, N'حقوق الملكية (3): رأس المال والأرباح والخسائر');

-- جذور قائمة الدخل (الإيرادات والمصروفات) = تشغيلية
INSERT INTO #Map (AccID, CashFlowType, Why)
SELECT a.AccID, 2, N'جذر قائمة الدخل: ' + a.AccName
FROM dbo.Acc_Account AS a
WHERE a.AccCompany = @Cmp
  AND a.AccEnd = 2
  AND a.AccParentID IS NULL
  AND NOT EXISTS (SELECT 1 FROM #Map AS m WHERE m.AccID = a.AccID);

-- التأكد أن كل حساب ينتمي للشركة
IF EXISTS
(
    SELECT 1
    FROM #Map AS m
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Acc_Account AS a
        WHERE a.AccID = m.AccID
          AND a.AccCompany = @Cmp
    )
)
BEGIN
    SELECT m.AccID AS MissingOrForeignAccID, m.Why
    FROM #Map AS m
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Acc_Account AS a
        WHERE a.AccID = m.AccID
          AND a.AccCompany = @Cmp
    );

    ROLLBACK TRAN;
    THROW 51101, N'يوجد AccID في الجدول لا يتبع الشركة أو غير موجود. راجع النتيجة أعلاه.', 1;
END;

-- إضافة الناقص فقط
INSERT INTO dbo.Acc_CashFlowAccounts (AccID, CashFlowType)
SELECT m.AccID, m.CashFlowType
FROM #Map AS m
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Acc_CashFlowAccounts AS c
    WHERE c.AccID = m.AccID
);

-- معاينة التصنيف الحالي كاملًا
SELECT
    c.AccID,
    a.AccCode,
    a.AccName,
    a.AccLevel,
    c.CashFlowType,
    CASE c.CashFlowType
        WHEN 1 THEN N'نقدية وما يعادلها'
        WHEN 2 THEN N'تشغيلية'
        WHEN 3 THEN N'استثمارية'
        WHEN 4 THEN N'تمويلية'
    END AS FlowName,
    m.Why
FROM dbo.Acc_CashFlowAccounts AS c
INNER JOIN dbo.Acc_Account AS a
    ON a.AccID = c.AccID
LEFT JOIN #Map AS m
    ON m.AccID = c.AccID
WHERE a.AccCompany = @Cmp
ORDER BY a.AccEnd, a.AccCode;

-- حسابات الميزانية والدخل غير المصنفة بعد التوريث (يجب ألا يبقى شيء)
;WITH Anc AS
(
    SELECT a.AccID AS LeafAccID, a.AccID AS AncID, a.AccParentID
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp

    UNION ALL

    SELECT x.LeafAccID, p.AccID, p.AccParentID
    FROM Anc AS x
    INNER JOIN dbo.Acc_Account AS p
        ON p.AccID = x.AccParentID
)
SELECT TOP (50)
    a.AccID, a.AccCode, a.AccName, a.AccLevel
FROM dbo.Acc_Account AS a
WHERE a.AccCompany = @Cmp
  AND NOT EXISTS
  (
      SELECT 1
      FROM Anc AS x
      INNER JOIN dbo.Acc_CashFlowAccounts AS c
          ON c.AccID = x.AncID
      WHERE x.LeafAccID = a.AccID
  )
ORDER BY a.AccCode
OPTION (MAXRECURSION 32767);

DROP TABLE #Map;

IF @Apply = 1
BEGIN
    COMMIT TRAN;
    PRINT N'تم تثبيت التصنيف.';
END
ELSE
BEGIN
    ROLLBACK TRAN;
    PRINT N'معاينة فقط: تم التراجع. غيّر @Apply إلى 1 للتثبيت.';
END;

﻿/* =====================================================================
   مسار حالات القيد: مراجعة ← اعتماد ← أرشفة (إجراء واحد للقبول والرفض)
   ---------------------------------------------------------------------
   المراحل (تُفعَّل بإعدادات الشركة Acc_CompanySettings):
     1 المراجعة   AccSReview   : قبول ← 3   ورفض ← يعود لما قبلها
     2 الاعتماد   AccSApproval : قبول ← 5
     3 الأرشفة    AccSArchive  : قبول ← 7

   الحالات ومن ينتظرها:
     1 (مرحّل) و 4 (مُعاد للمراجع)  ← ينتظران المراجعة
     3 (راجعه المراجع) و 6 (مُعاد للمدير المالي) ← ينتظران الاعتماد
     5 (اعتمده المدير المالي)       ← ينتظر الأرشفة
     0 و 2 و 7                      ← لا إجراء (2 يعدّله المحاسب ويعيده إلى 1)

   القفز: المرحلة المعطّلة تُتجاوز. الحالة تنتظر أول مرحلة مفعّلة من مرحلتها فصاعدًا.
   الرفض يعود إلى أقرب مرحلة مفعّلة قبل الرافضة:
        المراجع ← 4   المدير المالي ← 6   وإن لم توجد (المحاسب) ← 2
   إن لم توجد مرحلة مفعّلة تنتظرها الحالة فلا إجراء (الحالة نهائية).

   فصل المهام: العمود الجديد AccSSeparateDuties (افتراضي 1) يمنع من أنشأ القيد
   (DayMUser) من مراجعته أو اعتماده أو أرشفته.

   الأخطاء: 50301 قيد غير موجود/ليس للشركة   50302 تغيّرت حالته (@FromState)
            50303 لا إجراء متاح في هذه الحالة 50304 فصل المهام
            50305 معاملات غير صحيحة (@Accept فارغ أو مستخدم غير موجود)
            50306 المستخدم لا يملك صلاحية المرحلة (قائمتها ليست في Mng_UserParmations)
            50307 لم تُعرَّف قائمة المرحلة في Acc_StageMenu
   الصلاحيات: Acc_StageMenu تربط كل مرحلة (1 مراجعة، 2 اعتماد، 3 أرشفة) برقم قائمة؛
   والمستخدم يملك المرحلة إن كان رقم قائمتها ضمن USPParmations لصفه الفعّال (USPState = 0)
   في Mng_UserParmations لنفس الشركة والمنظومة. المرحلة غير المعرّفة تُرفض (الأمان أولًا).
   مثال ملء الربط (استبدل الأرقام بأرقام قوائمكم):
        INSERT dbo.Acc_StageMenu (StageNo, MenuID) VALUES (1, 101), (2, 102), (3, 103);
   نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF COL_LENGTH(N'dbo.Acc_CompanySettings', N'AccSSeparateDuties') IS NULL
    ALTER TABLE dbo.Acc_CompanySettings
        ADD AccSSeparateDuties BIT NOT NULL
            CONSTRAINT DF_Acc_CompanySettings_SeparateDuties DEFAULT (1);
GO

IF OBJECT_ID(N'dbo.Acc_StageMenu', N'U') IS NULL
    CREATE TABLE dbo.Acc_StageMenu
    (
        StageNo  TINYINT NOT NULL CONSTRAINT PK_Acc_StageMenu PRIMARY KEY,
        SystemID TINYINT NOT NULL CONSTRAINT DF_Acc_StageMenu_System DEFAULT (1),   -- منظومة المحاسبة
        MenuID   INT     NOT NULL,
        CONSTRAINT CK_Acc_StageMenu_Stage CHECK (StageNo BETWEEN 1 AND 3)
    );
GO

/* هل يملك المستخدم صلاحية المرحلة؟ (تُستعمل في الإجراء وفي استعلام الشبكة لإظهار الأزرار)
     Mapped = 0: لم تُعرَّف قائمة المرحلة   Allowed = 1: يملكها */
CREATE OR ALTER FUNCTION dbo.Acc_UserCanAct (@Cmp INT, @User BIGINT, @Stage TINYINT)
RETURNS TABLE
AS
RETURN
(
    SELECT CAST(CASE WHEN m.MenuID IS NULL THEN 0 ELSE 1 END AS BIT) AS Mapped,
           CAST(CASE WHEN m.MenuID IS NOT NULL AND EXISTS
                (SELECT 1
                 FROM dbo.Mng_UserParmations AS p
                 WHERE p.USPUserID = @User AND p.USPCompanyID = @Cmp
                   AND p.USPSystemID = m.SystemID AND p.USPState = 0
                   AND N',' + REPLACE(REPLACE(REPLACE(REPLACE(p.USPParmations, N' ', N''), NCHAR(9), N''), NCHAR(13), N''), NCHAR(10), N'') + N','
                       LIKE N'%,' + CONVERT(NVARCHAR(10), m.MenuID) + N',%')
                THEN 1 ELSE 0 END AS BIT) AS Allowed
    FROM (SELECT @Stage AS StageNo) AS x
    LEFT JOIN dbo.Acc_StageMenu AS m ON m.StageNo = x.StageNo
);
GO

/* دالة المسار: صف واحد إن كان للحالة مرحلة تنتظرها، وإلا لا صفوف.
   تُستعمل في الإجراء وفي استعلام الشبكة لإظهار الأزرار:
     SELECT m.*, f.AcceptState, f.RejectState
     FROM dbo.Acc_DayMaster m OUTER APPLY dbo.Acc_VoucherFlow(m.DayMCompany, m.DayMState) f */
CREATE OR ALTER FUNCTION dbo.Acc_VoucherFlow (@Cmp INT, @State TINYINT)
RETURNS TABLE
AS
RETURN
(
    WITH S AS
    (
        SELECT ISNULL(MAX(CASE WHEN AccSReview   = 1 THEN 1 END), 0) AS Rv,
               ISNULL(MAX(CASE WHEN AccSApproval = 1 THEN 1 END), 0) AS Ap,
               ISNULL(MAX(CASE WHEN AccSArchive  = 1 THEN 1 END), 0) AS Ar
        FROM dbo.Acc_CompanySettings
        WHERE AccSCmpID = @Cmp
    ),
    P AS
    (
        SELECT CASE WHEN @State IN (1, 4) THEN 1
                    WHEN @State IN (3, 6) THEN 2
                    WHEN @State = 5       THEN 3 END AS Pend
    ),
    A AS
    (
        SELECT S.Rv, S.Ap, S.Ar,
               CASE WHEN P.Pend <= 1 AND S.Rv = 1 THEN 1
                    WHEN P.Pend <= 2 AND S.Ap = 1 THEN 2
                    WHEN P.Pend <= 3 AND S.Ar = 1 THEN 3 END AS Act
        FROM S CROSS JOIN P
        WHERE P.Pend IS NOT NULL
    )
    SELECT CAST(A.Act AS TINYINT) AS ActStage,
           CAST(CASE A.Act WHEN 1 THEN 3 WHEN 2 THEN 5 WHEN 3 THEN 7 END AS TINYINT) AS AcceptState,
           CAST(CASE WHEN A.Act IS NULL THEN NULL
                     WHEN A.Act = 3 AND A.Ap = 1 THEN 6
                     WHEN A.Act >= 2 AND A.Rv = 1 THEN 4
                     ELSE 2 END AS TINYINT) AS RejectState
    FROM A
    WHERE A.Act IS NOT NULL
);
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ChangeDayVoucherState
    @Cmp       INT,
    @User      BIGINT,
    @DayMID    BIGINT,
    @Accept    BIT,                 -- 1 قبول (تمرير)   0 رفض (إرجاع)
    @FromState TINYINT = NULL       -- حالة القيد كما في الشبكة؛ تمنع القبول المزدوج من شاشة قديمة
AS
BEGIN
    SET NOCOUNT ON;

    IF @Accept IS NULL OR ISNULL(@User, 0) <= 0
       OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 50305, N'معاملات غير صحيحة: تحقق من المستخدم ونوع الإجراء.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_ChangeDayVoucherState;

    BEGIN TRY
        DECLARE @Old TINYINT, @Owner BIGINT;

        SELECT @Old = m.DayMState, @Owner = m.DayMUser
        FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
        WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

        IF @Old IS NULL
            THROW 50301, N'القيد غير موجود أو لا يتبع الشركة.', 1;

        IF @FromState IS NOT NULL AND @FromState <> @Old
            THROW 50302, N'تغيّرت حالة القيد منذ عرضه؛ حدّث الصفحة وأعد المحاولة.', 1;

        DECLARE @Act TINYINT, @Acc TINYINT, @Rej TINYINT;
        SELECT @Act = f.ActStage, @Acc = f.AcceptState, @Rej = f.RejectState
        FROM dbo.Acc_VoucherFlow(@Cmp, @Old) AS f;

        IF @Act IS NULL
            THROW 50303, N'لا يوجد إجراء متاح للقيد في حالته الحالية أو وفق إعدادات الشركة.', 1;

        DECLARE @Mapped BIT, @Allowed BIT;
        SELECT @Mapped = u.Mapped, @Allowed = u.Allowed FROM dbo.Acc_UserCanAct(@Cmp, @User, @Act) AS u;
        IF @Mapped = 0
            THROW 50307, N'لم تُعرَّف قائمة هذه المرحلة في جدول Acc_StageMenu.', 1;
        IF @Allowed = 0
            THROW 50306, N'لا تملك صلاحية هذه المرحلة.', 1;

        IF @Owner = @User
           AND ISNULL((SELECT MAX(CAST(AccSSeparateDuties AS INT)) FROM dbo.Acc_CompanySettings WHERE AccSCmpID = @Cmp), 1) = 1
            THROW 50304, N'لا يجوز لمن أنشأ القيد أن يراجعه أو يعتمده أو يؤرشفه (فصل المهام).', 1;

        DECLARE @New TINYINT = CASE WHEN @Accept = 1 THEN @Acc ELSE @Rej END;

        UPDATE dbo.Acc_DayMaster
        SET DayMState = @New
        WHERE DayMID = @DayMID AND DayMCompany = @Cmp;

        IF @Started = 1 COMMIT;

        SELECT @DayMID AS DayMID, @Old AS OldState, @New AS NewState, @Act AS ActStage;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_ChangeDayVoucherState;
        THROW;
    END CATCH
END;
GO

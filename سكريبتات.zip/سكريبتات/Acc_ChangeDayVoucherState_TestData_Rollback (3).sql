﻿/* اختبار مسار الحالات — يتراجع عن كل شيء في النهاية (ROLLBACK).
   يغيّر إعدادات شركة الاختبار مؤقتًا ثم يتراجع. الناتج: أسطر PASS/FAIL في Messages. */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
DECLARE @Cmp INT = 10, @U1 BIGINT = 1, @U2 BIGINT;
SELECT TOP (1) @U2 = UsrID FROM dbo.Mng_User WHERE UsrID <> @U1 ORDER BY UsrID;

DECLARE @R TABLE (Name NVARCHAR(300), Ok BIT);
DECLARE @Err INT, @Ign INT;

BEGIN TRAN;

IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE AccSCmpID = @Cmp)
    INSERT dbo.Acc_CompanySettings (AccSCmpID) VALUES (@Cmp);

/* ---------- 1) مصفوفة الدالة مقابل تنفيذ مستقل ---------- */
DECLARE @mask INT = 0, @st INT, @bad INT = 0, @cnt INT = 0;
WHILE @mask < 8
BEGIN
    UPDATE dbo.Acc_CompanySettings
    SET AccSReview = @mask & 1, AccSApproval = (@mask / 2) & 1, AccSArchive = (@mask / 4) & 1
    WHERE AccSCmpID = @Cmp;

    SET @st = 0;
    WHILE @st <= 7
    BEGIN
        /* التوقع بطريقة مختلفة: مصفوفة المراحل المفعّلة تُمشى بالترتيب */
        DECLARE @pend INT = CASE WHEN @st IN (1,4) THEN 1 WHEN @st IN (3,6) THEN 2 WHEN @st = 5 THEN 3 END;
        DECLARE @act INT = NULL, @k INT = 1, @expAcc INT, @expRej INT, @j INT;
        IF @pend IS NOT NULL
            WHILE @k <= 3 AND @act IS NULL
            BEGIN
                IF @k >= @pend AND ((@k = 1 AND @mask & 1 = 1) OR (@k = 2 AND @mask & 2 = 2) OR (@k = 3 AND @mask & 4 = 4))
                    SET @act = @k;
                SET @k += 1;
            END;
        SET @expAcc = CASE @act WHEN 1 THEN 3 WHEN 2 THEN 5 WHEN 3 THEN 7 END;
        SET @expRej = NULL;
        IF @act IS NOT NULL
        BEGIN
            SET @expRej = 2; SET @j = @act - 1;
            WHILE @j >= 1
            BEGIN
                IF (@j = 1 AND @mask & 1 = 1) BEGIN SET @expRej = 4; BREAK; END;
                IF (@j = 2 AND @mask & 2 = 2) BEGIN SET @expRej = 6; BREAK; END;
                SET @j -= 1;
            END;
        END;

        DECLARE @gAct INT, @gAcc INT, @gRej INT;
        SELECT @gAct = NULL, @gAcc = NULL, @gRej = NULL;
        SELECT @gAct = ActStage, @gAcc = AcceptState, @gRej = RejectState FROM dbo.Acc_VoucherFlow(@Cmp, @st);
        SET @cnt += 1;
        IF ISNULL(@gAct, -1) <> ISNULL(@act, -1) OR ISNULL(@gAcc, -1) <> ISNULL(@expAcc, -1) OR ISNULL(@gRej, -1) <> ISNULL(@expRej, -1)
            SET @bad += 1;
        SET @st += 1;
    END;
    SET @mask += 1;
END;
INSERT @R VALUES (N'F1 مصفوفة الدالة: 64 حالة (8 تركيبات × 8 حالات) مطابقة (' + CONVERT(NVARCHAR(10), @cnt) + N' فحص)', CASE WHEN @bad = 0 THEN 1 ELSE 0 END);

/* مراسي صريحة */
UPDATE dbo.Acc_CompanySettings SET AccSReview = 1, AccSApproval = 1, AccSArchive = 1 WHERE AccSCmpID = @Cmp;
INSERT @R SELECT N'F2 الكل مفعّل: 1→(3,2) 3→(5,4) 4→(3,2) 5→(7,6) 6→(5,4)',
  CASE WHEN (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 1)) = '3,2'
        AND (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 3)) = '5,4'
        AND (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 4)) = '3,2'
        AND (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 5)) = '7,6'
        AND (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 6)) = '5,4'
        AND NOT EXISTS (SELECT 1 FROM dbo.Acc_VoucherFlow(@Cmp, 0)) AND NOT EXISTS (SELECT 1 FROM dbo.Acc_VoucherFlow(@Cmp, 2))
        AND NOT EXISTS (SELECT 1 FROM dbo.Acc_VoucherFlow(@Cmp, 7)) THEN 1 ELSE 0 END;

UPDATE dbo.Acc_CompanySettings SET AccSReview = 0, AccSApproval = 1, AccSArchive = 1 WHERE AccSCmpID = @Cmp;
INSERT @R SELECT N'F3 بلا مراجعة: 1→(5,2) والرفض من الأرشيف يعود للمدير المالي (7,6)',
  CASE WHEN (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 1)) = '5,2'
        AND (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 5)) = '7,6' THEN 1 ELSE 0 END;

UPDATE dbo.Acc_CompanySettings SET AccSReview = 1, AccSApproval = 0, AccSArchive = 1 WHERE AccSCmpID = @Cmp;
INSERT @R SELECT N'F4 بلا اعتماد: 3→(7,4) أي قفز الاعتماد والرفض يعود للمراجع',
  CASE WHEN (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 3)) = '7,4' THEN 1 ELSE 0 END;

UPDATE dbo.Acc_CompanySettings SET AccSReview = 1, AccSApproval = 0, AccSArchive = 0 WHERE AccSCmpID = @Cmp;
INSERT @R SELECT N'F5 مراجعة فقط: 1→(3,2) و 3 نهائية',
  CASE WHEN (SELECT CONCAT(AcceptState, ',', RejectState) FROM dbo.Acc_VoucherFlow(@Cmp, 1)) = '3,2'
        AND NOT EXISTS (SELECT 1 FROM dbo.Acc_VoucherFlow(@Cmp, 3)) THEN 1 ELSE 0 END;

/* ---------- 2) الإجراء ---------- */
UPDATE dbo.Acc_CompanySettings
SET AccSReview = 1, AccSApproval = 1, AccSArchive = 1, AccSSeparateDuties = 1 WHERE AccSCmpID = @Cmp;

DECLARE @V TABLE (Tag NVARCHAR(10), ID BIGINT);
DECLARE @n INT = 0, @tag NVARCHAR(10);
DECLARE @tags TABLE (Tag NVARCHAR(10), St TINYINT);
INSERT @tags VALUES (N's0',0),(N's1',1),(N's2',2),(N's3',3),(N's4',4),(N's5',5),(N's6',6),(N's7',7),
                    (N'a1',1),(N'a3',3),(N'a5',5),(N'r1',1),(N'r3',3),(N'r5',5),(N'b4',4),(N'b6',6),(N'c4',4),(N'x1',1),(N'y1',1),(N'z1',1),(N'w1',1);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT Tag, St FROM @tags;
DECLARE @st2 TINYINT;
OPEN c; FETCH NEXT FROM c INTO @tag, @st2;
WHILE @@FETCH_STATUS = 0
BEGIN
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2026-01-15', N'اختبار مسار ' + @tag, 990000 + @n, @st2, @U1, @Cmp);
    INSERT @V VALUES (@tag, SCOPE_IDENTITY());
    SET @n += 1;
    FETCH NEXT FROM c INTO @tag, @st2;
END;
CLOSE c; DEALLOCATE c;

DECLARE @id BIGINT, @a BIGINT, @o INT, @nw INT;
DECLARE @res TABLE (DayMID BIGINT, OldState TINYINT, NewState TINYINT, ActStage TINYINT);

/* مساعد: تنفيذ ومحاولة التقاط الخطأ */
DECLARE @tests TABLE (Seq INT IDENTITY, Name NVARCHAR(200), Tag NVARCHAR(10), Usr BIGINT, Acc BIT, FromSt TINYINT, ExpNew INT, ExpErr INT);
INSERT @tests (Name, Tag, Usr, Acc, FromSt, ExpNew, ExpErr) VALUES
 (N'P1 قبول 1→3',            N'a1', @U2, 1, NULL, 3, NULL),
 (N'P2 قبول 3→5',            N'a3', @U2, 1, NULL, 5, NULL),
 (N'P3 قبول 5→7',            N'a5', @U2, 1, NULL, 7, NULL),
 (N'P4 رفض 1→2',             N'r1', @U2, 0, NULL, 2, NULL),
 (N'P5 رفض 3→4',             N'r3', @U2, 0, NULL, 4, NULL),
 (N'P6 رفض 5→6',             N'r5', @U2, 0, NULL, 6, NULL),
 (N'P7 قبول 4→3 (المعاد للمراجع)', N'b4', @U2, 1, NULL, 3, NULL),
 (N'P8 قبول 6→5 (المعاد للمدير المالي)', N'b6', @U2, 1, NULL, 5, NULL),
 (N'P9 رفض 4→2',             N'c4', @U2, 0, NULL, 2, NULL),
 (N'P10 المؤرشف لا إجراء 50303', N's7', @U2, 1, NULL, NULL, 50303),
 (N'P11 المؤقت لا إجراء 50303',   N's0', @U2, 1, NULL, NULL, 50303),
 (N'P12 المُعاد للمحاسب (2) لا إجراء 50303', N's2', @U2, 1, NULL, NULL, 50303),
 (N'P13 حالة قديمة @FromState 50302', N'x1', @U2, 1, 3, NULL, 50302),
 (N'P14 @Accept فارغ 50305',  N'y1', @U2, NULL, NULL, NULL, 50305),
 (N'P15 فصل المهام 50304 (المنشئ نفسه)', N'z1', @U1, 1, NULL, NULL, 50304);

DECLARE @seq INT = 1, @max INT = (SELECT MAX(Seq) FROM @tests);
DECLARE @tn NVARCHAR(200), @tg NVARCHAR(10), @uu BIGINT, @ac BIT, @fs TINYINT, @en INT, @ee INT;
WHILE @seq <= @max
BEGIN
    SELECT @tn = Name, @tg = Tag, @uu = Usr, @ac = Acc, @fs = FromSt, @en = ExpNew, @ee = ExpErr FROM @tests WHERE Seq = @seq;
    SELECT @id = ID FROM @V WHERE Tag = @tg;
    SET @Err = 0; SET @nw = NULL;
    IF @uu IS NULL SET @uu = @U1;   -- لا مستخدم ثانٍ في القاعدة: يُختبر فصل المهام فقط
    BEGIN TRY
        IF @ee IS NULL
            INSERT @res EXEC dbo.Acc_ChangeDayVoucherState @Cmp = @Cmp, @User = @uu, @DayMID = @id, @Accept = @ac, @FromState = @fs;
        ELSE
            EXEC dbo.Acc_ChangeDayVoucherState @Cmp = @Cmp, @User = @uu, @DayMID = @id, @Accept = @ac, @FromState = @fs;
    END TRY
    BEGIN CATCH
        SET @Err = ERROR_NUMBER();
    END CATCH;
    SELECT @nw = DayMState FROM dbo.Acc_DayMaster WHERE DayMID = @id;
    INSERT @R VALUES (@tn,
        CASE WHEN @ee IS NULL THEN CASE WHEN @Err = 0 AND @nw = @en THEN 1 ELSE 0 END
             ELSE CASE WHEN @Err = @ee AND @nw = (SELECT St FROM @tags WHERE Tag = @tg) THEN 1 ELSE 0 END END);
    SET @seq += 1;
END;

/* قيد غير موجود / شركة أخرى */
SET @Err = 0;
BEGIN TRY
    EXEC dbo.Acc_ChangeDayVoucherState @Cmp = @Cmp, @User = @U2, @DayMID = -1, @Accept = 1;
END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'P16 قيد غير موجود 50301', CASE WHEN @Err = 50301 THEN 1 ELSE 0 END);

SET @Err = 0; SELECT @id = ID FROM @V WHERE Tag = N'w1';
BEGIN TRY
    EXEC dbo.Acc_ChangeDayVoucherState @Cmp = 999999, @User = @U2, @DayMID = @id, @Accept = 1;
END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'P17 شركة أخرى لا تصل للقيد 50301', CASE WHEN @Err = 50301 THEN 1 ELSE 0 END);

/* فصل المهام معطّل: المنشئ يمرّر */
UPDATE dbo.Acc_CompanySettings SET AccSSeparateDuties = 0 WHERE AccSCmpID = @Cmp;
SET @Err = 0;
BEGIN TRY
    DELETE @res; INSERT @res EXEC dbo.Acc_ChangeDayVoucherState @Cmp = @Cmp, @User = @U1, @DayMID = @id, @Accept = 1, @FromState = 1;
END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'P18 فصل المهام معطّل: المنشئ يستطيع (1→3)',
    CASE WHEN @Err = 0 AND (SELECT DayMState FROM dbo.Acc_DayMaster WHERE DayMID = @id) = 3 THEN 1 ELSE 0 END);
UPDATE dbo.Acc_CompanySettings SET AccSSeparateDuties = 1 WHERE AccSCmpID = @Cmp;

/* القفز في الإجراء: بلا مراجعة، 1→5 */
UPDATE dbo.Acc_CompanySettings SET AccSReview = 0 WHERE AccSCmpID = @Cmp;
SELECT @id = ID FROM @V WHERE Tag = N'y1';
SET @Err = 0;
BEGIN TRY
    DELETE @res; INSERT @res EXEC dbo.Acc_ChangeDayVoucherState @Cmp = @Cmp, @User = @U2, @DayMID = @id, @Accept = 1;
END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'P19 بلا مراجعة: قبول 1→5 (قفز)', CASE WHEN @Err = 0 AND (SELECT DayMState FROM dbo.Acc_DayMaster WHERE DayMID = @id) = 5 THEN 1 ELSE 0 END);

/* كل المراحل معطّلة: القيد 1 نهائي */
UPDATE dbo.Acc_CompanySettings SET AccSApproval = 0, AccSArchive = 0 WHERE AccSCmpID = @Cmp;
SELECT @id = ID FROM @V WHERE Tag = N'x1';
SET @Err = 0;
BEGIN TRY
    EXEC dbo.Acc_ChangeDayVoucherState @Cmp = @Cmp, @User = @U2, @DayMID = @id, @Accept = 1;
END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'P20 كل المراحل معطّلة: لا إجراء 50303', CASE WHEN @Err = 50303 THEN 1 ELSE 0 END);

/* لا تغيير في بقية بيانات القيد */
INSERT @R SELECT N'P21 التاريخ والوصف لم يتغيرا بعد التمرير',
   CASE WHEN EXISTS (SELECT 1 FROM dbo.Acc_DayMaster m JOIN @V v ON v.ID = m.DayMID
                     WHERE v.Tag = N'a1' AND m.DayMDate = '2026-01-15' AND m.DayMDescription = N'اختبار مسار a1') THEN 1 ELSE 0 END;

ROLLBACK;

/* ---------- الطباعة ---------- */
DECLARE @p INT = 0, @f INT = 0, @nm NVARCHAR(300), @ok BIT;
DECLARE r CURSOR LOCAL FAST_FORWARD FOR SELECT Name, Ok FROM @R;
OPEN r; FETCH NEXT FROM r INTO @nm, @ok;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF @ok = 1 BEGIN SET @p += 1; PRINT N'PASS - ' + @nm; END ELSE BEGIN SET @f += 1; PRINT N'FAIL - ' + @nm; END;
    FETCH NEXT FROM r INTO @nm, @ok;
END;
CLOSE r; DEALLOCATE r;
IF @U2 IS NULL PRINT N'تنبيه: لا يوجد مستخدم ثانٍ في Mng_User؛ اختُبر المسار بمستخدم واحد وقد تفشل اختبارات P1–P9 بسبب فصل المهام.';
PRINT N'الإجمالي: ' + CONVERT(NVARCHAR(10), @p + @f) + N' اختبار | نجح: ' + CONVERT(NVARCHAR(10), @p) + N' | فشل: ' + CONVERT(NVARCHAR(10), @f);
IF @@TRANCOUNT > 0 ROLLBACK;
GO

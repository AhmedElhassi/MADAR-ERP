USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_CheckFinancialStatements]
    @FromDate   DATE = NULL,
    @ToDate     DATE = NULL,
    @Cmp        INT  = 1,
    @Year       INT  = 0,
    @MaxDetails INT  = 200
AS
BEGIN
    /* =====================================================================
       اسم التقرير : فحص سلامة القوائم المالية وربطها ومطابقتها
                     (Financial Statements Integrity & Reconciliation Check)
       الإجراء     : dbo.Acc_CheckFinancialStatements
       المدخلات    : @FromDate (الافتراضي 1 يناير)، @ToDate، @Cmp، @Year،
                     @MaxDetails = أقصى عدد صفوف تفصيل لكل فحص (الافتراضي 200).
       لا يغيّر أي بيانات: قراءة فقط.

       النتائج:
         1 جدول الفحوص: رقم الفحص، المجموعة، العنوان، الخطورة، الحالة،
                        عدد الملاحظات، المتوقع، الفعلي، الفرق.
         2 تفاصيل الملاحظات (حتى @MaxDetails لكل فحص): الحساب أو القيد المعني.
         3 الخلاصة: عدد الأخطاء والتحذيرات والحالة العامة.

       مجموعات الفحوص:
         A بنية دليل الحسابات       (1-7)   أب مفقود، شركة أخرى، حلقة، تصنيف، AccChid، تكرار رمز
         B سلامة القيود المرحّلة      (8-14)  توازن القيد، قيد بلا بنود، قاعدة الطرف الواحد،
                                              حركة على أب / حساب غريب / غير مصنف، تكرار رقم القيد
         C المطابقة                 (15-21) توازن دفتر الأستاذ (افتتاحي/حركة/ختامي)، معادلة
                                              الميزانية، جذور الشجرة = الأوراق، نتيجة السنة
         D الربط بقائمة حقوق الملكية (22-23) الحسابات الثابتة وتغطية حقوق الملكية
         E ربط التدفقات النقدية      (24-28) تصنيف النقدية والحسابات المقابلة والاستثناءات

       الخطورة: خطأ = يمنع الاعتماد على الأرقام، تحذير = يحتاج مراجعة، لا يمنع.
       القواعد: القيود المرحّلة فقط (DayMState = 7) حتى @ToDate؛ القيد على
                الحساب التحليلي فقط؛ السنة لا تُقفل (نتائج السنوات تتراكم).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Det;
    DROP TABLE IF EXISTS #Chk;
    DROP TABLE IF EXISTS #CashChk;
    DROP TABLE IF EXISTS #Counter;
    DROP TABLE IF EXISTS #CashEntry;
    DROP TABLE IF EXISTS #CF;
    DROP TABLE IF EXISTS #EqCovered;
    DROP TABLE IF EXISTS #LeafNet;
    DROP TABLE IF EXISTS #Journal;
    DROP TABLE IF EXISTS #Line;
    DROP TABLE IF EXISTS #Reach;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Acc;

    /* =========================================================
       1. التحقق من المدخلات
       ========================================================= */

    IF @ToDate IS NULL
        THROW 50301, N'تاريخ نهاية الفحص مطلوب.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50302, N'رقم الشركة غير صحيح.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @Cmp)
        THROW 50303, N'الشركة المحددة غير موجودة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@ToDate);

    IF @Year < 1900 OR @Year > 9999
        THROW 50304, N'السنة المالية غير صحيحة.', 1;

    IF @FromDate IS NULL
        SET @FromDate = DATEFROMPARTS(@Year, 1, 1);

    IF @FromDate > @ToDate
        THROW 50305, N'فترة الفحص غير صحيحة.', 1;

    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50306, N'يجب أن تقع فترة الفحص داخل السنة المالية المحددة.', 1;

    SET @MaxDetails = ISNULL(@MaxDetails, 200);

    IF @MaxDetails < 1
        SET @MaxDetails = 200;

    DECLARE
        @YearStart DATE = DATEFROMPARTS(@Year, 1, 1),
        @YearEnd   DATE = DATEFROMPARTS(@Year, 12, 31);


    /* =========================================================
       2. تحميل دليل حسابات الشركة
       ========================================================= */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType,
        CAST
        (
            CASE
                WHEN (a.AccEnd = 1 AND a.AccType IN (0, 1, 2))
                  OR (a.AccEnd = 2 AND a.AccType IN (0, 1))
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS ValidClass
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50307, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);

    -- الحسابات القابلة للوصول من جذور الشجرة (الجذر: AccParentID = NULL)
    ;WITH R AS
    (
        SELECT AccID
        FROM #Acc
        WHERE AccParentID IS NULL

        UNION ALL

        SELECT c.AccID
        FROM R
        INNER JOIN #Acc AS c
            ON c.AccParentID = R.AccID
    )
    SELECT AccID
    INTO #Reach
    FROM R
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_Reach
        ON #Reach (AccID);


    /* =========================================================
       3. جداول الفحوص والتفاصيل
       ========================================================= */

    CREATE TABLE #Chk
    (
        CheckNo       INT NOT NULL PRIMARY KEY,
        Grp           NVARCHAR(100) NOT NULL,
        Title         NVARCHAR(300) NOT NULL,
        Severity      TINYINT NOT NULL,          -- 1 خطأ، 2 تحذير
        IssueCount    BIGINT NOT NULL,
        ExpectedValue DECIMAL(38,3) NULL,
        ActualValue   DECIMAL(38,3) NULL,
        Difference    DECIMAL(38,3) NULL
    );

    CREATE TABLE #Det
    (
        Seq        INT IDENTITY(1,1) NOT NULL,
        CheckNo    INT NOT NULL,
        ObjectType NVARCHAR(30)  NULL,
        ObjectID   BIGINT        NULL,
        ObjectCode NVARCHAR(200) NULL,
        ObjectName NVARCHAR(MAX) NULL,
        Amount1    DECIMAL(38,3) NULL,
        Amount2    DECIMAL(38,3) NULL,
        Note       NVARCHAR(MAX) NULL
    );

    INSERT INTO #Chk (CheckNo, Grp, Title, Severity, IssueCount)
    VALUES
    (1,  N'A - بنية دليل الحسابات', N'حسابات أبوها غير موجود (يتيمة)، أو الأب = 0 بدل NULL', 1, 0),
    (2,  N'A - بنية دليل الحسابات', N'حسابات أبوها يتبع شركة أخرى', 1, 0),
    (3,  N'A - بنية دليل الحسابات', N'حسابات غير قابلة للوصول من جذر الشجرة (حلقة أو أب مفقود)', 1, 0),
    (4,  N'A - بنية دليل الحسابات', N'حسابات بتصنيف مالي غير صحيح (AccEnd / AccType)', 1, 0),
    (5,  N'A - بنية دليل الحسابات', N'اختلاف التصنيف المالي بين الحساب وأبيه', 1, 0),
    (6,  N'A - بنية دليل الحسابات', N'عدم تطابق AccChid مع الأبناء الفعليين', 2, 0),
    (7,  N'A - بنية دليل الحسابات', N'تكرار رمز الحساب (AccCode)', 2, 0),

    (8,  N'B - سلامة القيود المرحّلة', N'قيود مرحّلة غير متوازنة (مجموع المدين ≠ مجموع الدائن)', 1, 0),
    (9,  N'B - سلامة القيود المرحّلة', N'قيود مرحّلة بلا بنود', 1, 0),
    (10, N'B - سلامة القيود المرحّلة', N'بنود مخالفة لقاعدة الطرف الواحد (مدين ودائن معًا، أو صفر، أو سالب)', 1, 0),
    (11, N'B - سلامة القيود المرحّلة', N'حركة مسجلة مباشرة على حساب أب (لا تدخل في الأرقام)', 1, 0),
    (12, N'B - سلامة القيود المرحّلة', N'حركة على حساب لا يتبع الشركة', 1, 0),
    (13, N'B - سلامة القيود المرحّلة', N'حركة على حساب بتصنيف مالي غير صحيح', 1, 0),
    (14, N'B - سلامة القيود المرحّلة', N'تكرار رقم القيد (DayMNo) داخل الشهر نفسه (الترقيم يبدأ من 1 كل شهر)', 2, 0),

    (15, N'C - المطابقة', N'الافتتاحي: مجموع المدين = مجموع الدائن قبل بداية الفترة', 1, 0),
    (16, N'C - المطابقة', N'حركة الفترة: إجمالي المدين = إجمالي الدائن', 1, 0),
    (17, N'C - المطابقة', N'الختامي: صافي دفتر الأستاذ حتى نهاية الفترة = صفر', 1, 0),
    (18, N'C - المطابقة', N'معادلة الميزانية: الأصول = الخصوم + حقوق الملكية + نتائج السنوات', 1, 0),
    (19, N'C - المطابقة', N'مجموع جذور الميزانية = مجموع حساباتها التحليلية', 1, 0),
    (20, N'C - المطابقة', N'مجموع جذور قائمة الدخل = مجموع حساباتها التحليلية', 1, 0),
    (21, N'C - المطابقة', N'نتيجة السنة الحالية: إيرادات - مصروفات = نتيجة السنة في حقوق الملكية', 1, 0),

    (22, N'D - الربط بقائمة حقوق الملكية', N'حسابات حقوق الملكية الثابتة (12997 و13012 و13906) موجودة ومرتبطة', 2, 0),
    (23, N'D - الربط بقائمة حقوق الملكية', N'إجمالي حقوق الملكية في قائمة التغيّرات = إجماليها في الميزانية', 2, 0),

    (24, N'E - ربط التدفقات النقدية', N'يوجد حساب مصنف نقدية (1) في جدول Acc_CashFlowAccounts', 2, 0),
    (25, N'E - ربط التدفقات النقدية', N'تصنيف النقدية مطبق على حساب ليس من أصول الميزانية', 1, 0),
    (26, N'E - ربط التدفقات النقدية', N'حسابات مقابلة غير مصنفة في قيود النقدية خلال الفترة', 2, 0),
    (27, N'E - ربط التدفقات النقدية', N'قيود نقدية ستُستثنى من قائمة التدفقات (بلا مقابل / غير مصنف / غير متوازن)', 2, 0),
    (28, N'E - ربط التدفقات النقدية', N'حسابات نقدية رصيدها الختامي سالب', 2, 0);


    /* =========================================================
       4. A - بنية دليل الحسابات
       ========================================================= */

    -- 1: أب غير موجود أو الأب = 0
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        1, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'الأب = ', a.AccParentID)
    FROM #Acc AS a
    WHERE a.AccParentID IS NOT NULL
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Acc_Account AS x
          WHERE x.AccID = a.AccParentID
      );

    -- 2: أب من شركة أخرى
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        2, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'الأب ', a.AccParentID, N' يتبع الشركة ', p.AccCompany)
    FROM #Acc AS a
    INNER JOIN dbo.Acc_Account AS p
        ON p.AccID = a.AccParentID
    WHERE p.AccCompany <> @Cmp;

    -- 3: غير قابل للوصول من جذر
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        3, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'الأب = ', a.AccParentID)
    FROM #Acc AS a
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Reach AS r
        WHERE r.AccID = a.AccID
    );

    -- 4: تصنيف غير صحيح
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        4, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'AccEnd = ', a.AccEnd, N'، AccType = ', a.AccType)
    FROM #Acc AS a
    WHERE a.ValidClass = 0;

    -- 5: اختلاف التصنيف مع الأب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        5, N'حساب', c.AccID, c.AccCode, c.AccName,
        CONCAT(N'الحساب (', c.AccEnd, N'/', c.AccType, N') والأب ', p.AccCode, N' (', p.AccEnd, N'/', p.AccType, N')')
    FROM #Acc AS c
    INNER JOIN #Acc AS p
        ON p.AccID = c.AccParentID
    WHERE COALESCE(c.AccEnd, -1) <> COALESCE(p.AccEnd, -1)
       OR COALESCE(c.AccType, -1) <> COALESCE(p.AccType, -1);

    -- 6: AccChid مقابل الأبناء الفعليين
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        6, N'حساب', a.AccID, a.AccCode, a.AccName,
        a.AccChid, ISNULL(k.Cnt, 0),
        N'الكمية الأولى = AccChid المخزّن، الثانية = عدد الأبناء الفعلي'
    FROM #Acc AS a
    LEFT JOIN #Kid AS k
        ON k.AccID = a.AccID
    WHERE (a.AccChid > 0 AND k.AccID IS NULL)
       OR (a.AccChid = 0 AND k.AccID IS NOT NULL);

    -- 7: تكرار رمز الحساب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        7, N'حساب', a.AccID, a.AccCode, a.AccName, N'رمز مكرر'
    FROM #Acc AS a
    INNER JOIN
    (
        SELECT AccCode
        FROM #Acc
        WHERE AccCode <> N''
        GROUP BY AccCode
        HAVING COUNT(*) > 1
    ) AS d
        ON d.AccCode = a.AccCode;


    /* =========================================================
       5. جمع بنود القيود المرحّلة مرة واحدة
       ========================================================= */

    SELECT
        d.DayDID,
        d.DayDMID AS MID,
        d.DayDAccID AS AccID,
        m.DayMDate AS EntDate,
        CAST(d.DayDDeb AS DECIMAL(28,3)) AS Deb,
        CAST(d.DayDCrd AS DECIMAL(28,3)) AS Crd
    INTO #Line
    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @ToDate;

    CREATE CLUSTERED INDEX IX_Line_MID
        ON #Line (MID);

    CREATE NONCLUSTERED INDEX IX_Line_Acc
        ON #Line (AccID);

    SELECT
        m.DayMID,
        m.DayMNo,
        m.DayMDate,
        m.DayMDescription,
        CAST(ISNULL(SUM(l.Deb), 0) AS DECIMAL(38,3)) AS TotDeb,
        CAST(ISNULL(SUM(l.Crd), 0) AS DECIMAL(38,3)) AS TotCrd,
        COUNT_BIG(l.DayDID) AS LineCnt
    INTO #Journal
    FROM dbo.Acc_DayMaster AS m
    LEFT JOIN #Line AS l
        ON l.MID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @ToDate
    GROUP BY
        m.DayMID,
        m.DayMNo,
        m.DayMDate,
        m.DayMDescription;

    CREATE UNIQUE CLUSTERED INDEX IX_Journal
        ON #Journal (DayMID);


    /* =========================================================
       6. B - سلامة القيود المرحّلة
       ========================================================= */

    -- 8: قيد غير متوازن
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        8, N'قيد', j.DayMID, CAST(j.DayMNo AS NVARCHAR(50)), j.DayMDescription,
        j.TotDeb - j.TotCrd, j.TotDeb,
        CONCAT(N'بتاريخ ', CONVERT(NVARCHAR(10), j.DayMDate, 23), N'؛ الكمية الأولى = الفرق، الثانية = إجمالي المدين')
    FROM #Journal AS j
    WHERE j.LineCnt > 0
      AND ABS(j.TotDeb - j.TotCrd) >= 0.001;

    -- 9: قيد بلا بنود
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        9, N'قيد', j.DayMID, CAST(j.DayMNo AS NVARCHAR(50)), j.DayMDescription,
        CONCAT(N'بتاريخ ', CONVERT(NVARCHAR(10), j.DayMDate, 23))
    FROM #Journal AS j
    WHERE j.LineCnt = 0;

    -- 10: مخالفة قاعدة الطرف الواحد
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        10, N'بند', l.DayDID, CAST(l.MID AS NVARCHAR(50)), NULL,
        l.Deb, l.Crd,
        CONCAT(N'قيد رقم (المعرّف) ', l.MID, N' بتاريخ ', CONVERT(NVARCHAR(10), l.EntDate, 23))
    FROM #Line AS l
    WHERE (l.Deb > 0 AND l.Crd > 0)
       OR (l.Deb = 0 AND l.Crd = 0)
       OR l.Deb < 0
       OR l.Crd < 0;

    -- 11: حركة على حساب أب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        11, N'حساب', a.AccID, a.AccCode, a.AccName,
        SUM(l.Deb - l.Crd), COUNT_BIG(*),
        N'الكمية الأولى = صافي الحركة (مدين - دائن)، الثانية = عدد البنود'
    FROM #Line AS l
    INNER JOIN #Kid AS k
        ON k.AccID = l.AccID
    INNER JOIN #Acc AS a
        ON a.AccID = l.AccID
    GROUP BY a.AccID, a.AccCode, a.AccName;

    -- 12: حركة على حساب لا يتبع الشركة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        12, N'حساب', l.AccID, x.AccCode, x.AccName,
        SUM(l.Deb - l.Crd), COUNT_BIG(*),
        CONCAT(N'شركة الحساب = ', x.AccCompany)
    FROM #Line AS l
    LEFT JOIN dbo.Acc_Account AS x
        ON x.AccID = l.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccID = l.AccID
    )
    GROUP BY l.AccID, x.AccCode, x.AccName, x.AccCompany;

    -- 13: حركة على حساب بتصنيف غير صحيح
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        13, N'حساب', a.AccID, a.AccCode, a.AccName,
        SUM(l.Deb - l.Crd), COUNT_BIG(*),
        CONCAT(N'AccEnd = ', a.AccEnd, N'، AccType = ', a.AccType)
    FROM #Line AS l
    INNER JOIN #Acc AS a
        ON a.AccID = l.AccID
    WHERE a.ValidClass = 0
    GROUP BY a.AccID, a.AccCode, a.AccName, a.AccEnd, a.AccType;

    -- 14: تكرار رقم القيد داخل السنة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        14, N'قيد', m.DayMID, CAST(m.DayMNo AS NVARCHAR(50)), m.DayMDescription,
        CONCAT(N'رقم مكرر داخل الشهر، بتاريخ ', CONVERT(NVARCHAR(10), m.DayMDate, 23))
    FROM dbo.Acc_DayMaster AS m
    INNER JOIN
    (
        SELECT MONTH(DayMDate) AS Mn, DayMNo
        FROM dbo.Acc_DayMaster
        WHERE DayMCompany = @Cmp
          AND DayMState = 7
          AND DayMDate >= @YearStart
          AND DayMDate <= @YearEnd
          AND DayMNo IS NOT NULL
        GROUP BY MONTH(DayMDate), DayMNo
        HAVING COUNT(*) > 1
    ) AS d
        ON d.DayMNo = m.DayMNo
       AND d.Mn = MONTH(m.DayMDate)
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate >= @YearStart
      AND m.DayMDate <= @YearEnd;


    /* =========================================================
       7. أرصدة الحسابات التحليلية السليمة التصنيف
       ========================================================= */

    SELECT
        l.AccID,
        a.AccEnd,
        a.AccType,

        CAST(SUM(CASE WHEN l.EntDate < @FromDate  THEN l.Deb - l.Crd ELSE 0 END) AS DECIMAL(38,3)) AS OpenNet,
        CAST(SUM(CASE WHEN l.EntDate < @YearStart THEN l.Deb - l.Crd ELSE 0 END) AS DECIMAL(38,3)) AS PriorNet,
        CAST(SUM(CASE WHEN l.EntDate >= @FromDate THEN l.Deb ELSE 0 END) AS DECIMAL(38,3)) AS PerDeb,
        CAST(SUM(CASE WHEN l.EntDate >= @FromDate THEN l.Crd ELSE 0 END) AS DECIMAL(38,3)) AS PerCrd

    INTO #LeafNet
    FROM #Line AS l
    INNER JOIN #Acc AS a
        ON a.AccID = l.AccID
    WHERE a.ValidClass = 1
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Kid AS k
          WHERE k.AccID = l.AccID
      )
    GROUP BY l.AccID, a.AccEnd, a.AccType;

    CREATE UNIQUE CLUSTERED INDEX IX_LeafNet
        ON #LeafNet (AccID);


    /* =========================================================
       8. C - المطابقة
       ========================================================= */

    DECLARE
        @OpenNet  DECIMAL(38,3),
        @PerDeb   DECIMAL(38,3),
        @PerCrd   DECIMAL(38,3),
        @CloseNet DECIMAL(38,3);

    SELECT
        @OpenNet = ISNULL(SUM(CASE WHEN EntDate <  @FromDate THEN Deb - Crd ELSE 0 END), 0),
        @PerDeb  = ISNULL(SUM(CASE WHEN EntDate >= @FromDate THEN Deb ELSE 0 END), 0),
        @PerCrd  = ISNULL(SUM(CASE WHEN EntDate >= @FromDate THEN Crd ELSE 0 END), 0)
    FROM #Line;

    SET @CloseNet = @OpenNet + @PerDeb - @PerCrd;

    -- 15: الافتتاحي
    UPDATE #Chk
    SET ExpectedValue = 0,
        ActualValue   = @OpenNet,
        Difference    = @OpenNet,
        IssueCount    = CASE WHEN ABS(@OpenNet) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 15;

    -- 16: حركة الفترة (المتوقع = المدين، الفعلي = الدائن)
    UPDATE #Chk
    SET ExpectedValue = @PerDeb,
        ActualValue   = @PerCrd,
        Difference    = @PerDeb - @PerCrd,
        IssueCount    = CASE WHEN ABS(@PerDeb - @PerCrd) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 16;

    -- 17: الختامي
    UPDATE #Chk
    SET ExpectedValue = 0,
        ActualValue   = @CloseNet,
        Difference    = @CloseNet,
        IssueCount    = CASE WHEN ABS(@CloseNet) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 17;

    -- 18: معادلة الميزانية من الحسابات التحليلية السليمة
    DECLARE
        @Assets      DECIMAL(38,3),
        @Liabilities DECIMAL(38,3),
        @EquityAcc   DECIMAL(38,3),
        @PriorNetIS  DECIMAL(38,3),
        @CurNetIS    DECIMAL(38,3),
        @Revenue     DECIMAL(38,3),
        @Expenses    DECIMAL(38,3),
        @PriorResult DECIMAL(38,3),
        @CurResult   DECIMAL(38,3),
        @BsDiff      DECIMAL(38,3);

    SELECT
        @Assets =
            ISNULL(SUM(CASE WHEN AccEnd = 1 AND AccType = 0 THEN  (OpenNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @Liabilities =
            ISNULL(SUM(CASE WHEN AccEnd = 1 AND AccType = 1 THEN -(OpenNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @EquityAcc =
            ISNULL(SUM(CASE WHEN AccEnd = 1 AND AccType = 2 THEN -(OpenNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @PriorNetIS =
            ISNULL(SUM(CASE WHEN AccEnd = 2 THEN PriorNet ELSE 0 END), 0),
        @CurNetIS =
            ISNULL(SUM(CASE WHEN AccEnd = 2 THEN OpenNet - PriorNet + PerDeb - PerCrd ELSE 0 END), 0),
        @Revenue =
            ISNULL(SUM(CASE WHEN AccEnd = 2 AND AccType = 0 THEN -(OpenNet - PriorNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @Expenses =
            ISNULL(SUM(CASE WHEN AccEnd = 2 AND AccType = 1 THEN  (OpenNet - PriorNet + PerDeb - PerCrd) ELSE 0 END), 0)
    FROM #LeafNet;

    SET @PriorResult = -@PriorNetIS;
    SET @CurResult   = -@CurNetIS;
    SET @BsDiff      = @Assets - (@Liabilities + @EquityAcc + @PriorResult + @CurResult);

    UPDATE #Chk
    SET ExpectedValue = @Liabilities + @EquityAcc + @PriorResult + @CurResult,
        ActualValue   = @Assets,
        Difference    = @BsDiff,
        IssueCount    = CASE WHEN ABS(@BsDiff) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 18;

    -- 19 و20: مجموع جذور الشجرة مقابل مجموع الأوراق (يكشف الحركة على فروع غير قابلة للوصول)
    DECLARE
        @RootBS DECIMAL(38,3),
        @RootIS DECIMAL(38,3),
        @LeafBS DECIMAL(38,3),
        @LeafIS DECIMAL(38,3);

    ;WITH RU AS
    (
        SELECT
            n.AccID AS NodeID,
            n.AccEnd,
            CAST(n.OpenNet + n.PerDeb - n.PerCrd AS DECIMAL(38,3)) AS Net
        FROM #LeafNet AS n
        INNER JOIN #Reach AS r
            ON r.AccID = n.AccID

        UNION ALL

        SELECT
            p.AccID,
            u.AccEnd,
            u.Net
        FROM RU AS u
        INNER JOIN #Acc AS c
            ON c.AccID = u.NodeID
        INNER JOIN #Acc AS p
            ON p.AccID = c.AccParentID
    )
    SELECT
        @RootBS = ISNULL(SUM(CASE WHEN u.AccEnd = 1 THEN u.Net ELSE 0 END), 0),
        @RootIS = ISNULL(SUM(CASE WHEN u.AccEnd = 2 THEN u.Net ELSE 0 END), 0)
    FROM RU AS u
    INNER JOIN #Acc AS a
        ON a.AccID = u.NodeID
    WHERE a.AccParentID IS NULL
    OPTION (MAXRECURSION 32767);

    SELECT
        @LeafBS = ISNULL(SUM(CASE WHEN AccEnd = 1 THEN OpenNet + PerDeb - PerCrd ELSE 0 END), 0),
        @LeafIS = ISNULL(SUM(CASE WHEN AccEnd = 2 THEN OpenNet + PerDeb - PerCrd ELSE 0 END), 0)
    FROM #LeafNet;

    UPDATE #Chk
    SET ExpectedValue = @LeafBS,
        ActualValue   = @RootBS,
        Difference    = @LeafBS - @RootBS,
        IssueCount    = CASE WHEN ABS(@LeafBS - @RootBS) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 19;

    UPDATE #Chk
    SET ExpectedValue = @LeafIS,
        ActualValue   = @RootIS,
        Difference    = @LeafIS - @RootIS,
        IssueCount    = CASE WHEN ABS(@LeafIS - @RootIS) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 20;

    -- 21: نتيجة السنة الحالية
    UPDATE #Chk
    SET ExpectedValue = @Revenue - @Expenses,
        ActualValue   = @CurResult,
        Difference    = (@Revenue - @Expenses) - @CurResult,
        IssueCount    = CASE WHEN ABS((@Revenue - @Expenses) - @CurResult) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 21;


    /* =========================================================
       9. D - الربط بقائمة التغيّرات في حقوق الملكية
          (Acc_SelectAccChangesInEquity تعتمد حسابات ثابتة)
       ========================================================= */

    -- 22: الحسابات الثابتة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        22, N'حساب', v.AccID, a.AccCode, a.AccName,
        CASE
            WHEN a.AccID IS NULL
                THEN N'غير موجود في دليل حسابات الشركة'
            WHEN v.ExpParent IS NOT NULL AND ISNULL(a.AccParentID, -1) <> v.ExpParent
                THEN N'غير مرتبط بالحساب 12997'
            ELSE N'تصنيفه ليس من حقوق الملكية في الميزانية'
        END
    FROM (VALUES (12997, CAST(NULL AS BIGINT)), (13012, CAST(12997 AS BIGINT)), (13906, CAST(12997 AS BIGINT)))
         AS v (AccID, ExpParent)
    LEFT JOIN #Acc AS a
        ON a.AccID = v.AccID
    WHERE a.AccID IS NULL
       OR (v.ExpParent IS NOT NULL AND ISNULL(a.AccParentID, -1) <> v.ExpParent)
       OR COALESCE(a.AccEnd, -1) <> 1
       OR COALESCE(a.AccType, -1) <> 2;

    -- 23: تغطية حسابات حقوق الملكية في القائمة
    ;WITH Eq AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        INNER JOIN #Reach AS r
            ON r.AccID = a.AccID
        WHERE a.AccID IN (13012, 13906)
          AND a.AccParentID = 12997

        UNION ALL

        SELECT c.AccID
        FROM Eq AS e
        INNER JOIN #Acc AS c
            ON c.AccParentID = e.AccID
    )
    SELECT AccID
    INTO #EqCovered
    FROM Eq
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_EqCovered
        ON #EqCovered (AccID);

    DECLARE
        @EqCoveredAcc DECIMAL(38,3),
        @EqBsTotal    DECIMAL(38,3),
        @EqStmtTotal  DECIMAL(38,3);

    SELECT
        @EqCoveredAcc =
            ISNULL(SUM(CASE WHEN n.AccEnd = 1 AND n.AccType = 2 AND e.AccID IS NOT NULL
                            THEN -(n.OpenNet + n.PerDeb - n.PerCrd) ELSE 0 END), 0)
    FROM #LeafNet AS n
    LEFT JOIN #EqCovered AS e
        ON e.AccID = n.AccID;

    SET @EqBsTotal   = @EquityAcc + @PriorResult + @CurResult;
    SET @EqStmtTotal = @EqCoveredAcc + @PriorResult + @CurResult;

    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Note)
    SELECT
        23, N'حساب', a.AccID, a.AccCode, a.AccName,
        -(n.OpenNet + n.PerDeb - n.PerCrd),
        N'رصيد حقوق ملكية (دائن موجب) لا يظهر في قائمة التغيّرات في حقوق الملكية'
    FROM #LeafNet AS n
    INNER JOIN #Acc AS a
        ON a.AccID = n.AccID
    WHERE n.AccEnd = 1
      AND n.AccType = 2
      AND NOT EXISTS (SELECT 1 FROM #EqCovered AS e WHERE e.AccID = n.AccID)
      AND (n.OpenNet + n.PerDeb - n.PerCrd) <> 0;

    UPDATE #Chk
    SET ExpectedValue = @EqBsTotal,
        ActualValue   = @EqStmtTotal,
        Difference    = @EqBsTotal - @EqStmtTotal,
        IssueCount    = CASE WHEN ABS(@EqBsTotal - @EqStmtTotal) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 23;


    /* =========================================================
       10. E - ربط التدفقات النقدية
           التصنيف الفعّال: أقرب حساب مصنف في Acc_CashFlowAccounts
       ========================================================= */

    ;WITH AccountAncestors AS
    (
        SELECT
            a.AccID AS LeafAccID,
            a.AccID AS AncestorAccID,
            CAST(0 AS INT) AS Distance,
            CAST('/' + CONVERT(VARCHAR(30), a.AccID) + '/' AS VARCHAR(MAX)) AS VisitedPath
        FROM #Acc AS a

        UNION ALL

        SELECT
            h.LeafAccID,
            p.AccParentID,
            h.Distance + 1,
            CAST(h.VisitedPath + CONVERT(VARCHAR(30), p.AccParentID) + '/' AS VARCHAR(MAX))
        FROM AccountAncestors AS h
        INNER JOIN #Acc AS p
            ON p.AccID = h.AncestorAccID
        WHERE p.AccParentID IS NOT NULL
          AND CHARINDEX('/' + CONVERT(VARCHAR(30), p.AccParentID) + '/', h.VisitedPath) = 0
    ),
    Ranked AS
    (
        SELECT
            h.LeafAccID,
            c.CashFlowType,
            ROW_NUMBER() OVER (PARTITION BY h.LeafAccID ORDER BY h.Distance ASC) AS RN
        FROM AccountAncestors AS h
        INNER JOIN dbo.Acc_CashFlowAccounts AS c
            ON c.AccID = h.AncestorAccID
    )
    SELECT
        a.AccID,
        r.CashFlowType
    INTO #CF
    FROM #Acc AS a
    LEFT JOIN Ranked AS r
        ON r.LeafAccID = a.AccID
       AND r.RN = 1
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_CF
        ON #CF (AccID);

    -- 24: لا يوجد حساب نقدية
    INSERT INTO #Det (CheckNo, ObjectType, Note)
    SELECT
        24, N'إعداد',
        N'لا يوجد أي حساب مصنف (1) نقدية؛ ستكون قائمة التدفقات النقدية صفرية'
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #CF
        WHERE CashFlowType = 1
    );

    -- 25: النقدية على حساب ليس أصلًا من الميزانية
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        25, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'AccEnd = ', a.AccEnd, N'، AccType = ', a.AccType, N' (المطلوب 1 / 0)')
    FROM #CF AS cf
    INNER JOIN #Acc AS a
        ON a.AccID = cf.AccID
    WHERE cf.CashFlowType = 1
      AND (COALESCE(a.AccEnd, -1) <> 1 OR COALESCE(a.AccType, -1) <> 0);

    -- قيود الفترة التي تمس النقدية (صافي النقدية <> 0)
    SELECT
        l.MID,
        CAST(SUM(l.Deb - l.Crd) AS DECIMAL(38,3)) AS CashNet
    INTO #CashEntry
    FROM #Line AS l
    INNER JOIN #CF AS cf
        ON cf.AccID = l.AccID
       AND cf.CashFlowType = 1
    WHERE l.EntDate >= @FromDate
    GROUP BY l.MID
    HAVING SUM(l.Deb - l.Crd) <> 0;

    CREATE UNIQUE CLUSTERED INDEX IX_CashEntry
        ON #CashEntry (MID);

    -- البنود المقابلة (غير النقدية) في تلك القيود
    SELECT
        l.MID,
        l.DayDID,
        l.AccID,
        cf.CashFlowType,
        CAST(l.Crd - l.Deb AS DECIMAL(38,3)) AS Flow
    INTO #Counter
    FROM #CashEntry AS ce
    INNER JOIN #Line AS l
        ON l.MID = ce.MID
    LEFT JOIN #CF AS cf
        ON cf.AccID = l.AccID
    WHERE ISNULL(cf.CashFlowType, 0) <> 1;

    CREATE CLUSTERED INDEX IX_Counter
        ON #Counter (MID);

    -- 26: حسابات مقابلة غير مصنفة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        26, N'حساب', c.AccID, x.AccCode, x.AccName,
        SUM(c.Flow), COUNT(DISTINCT c.MID),
        N'الكمية الأولى = صافي التدفق (داخل موجب)، الثانية = عدد القيود؛ صنّفه أو صنّف أحد آبائه في Acc_CashFlowAccounts'
    FROM #Counter AS c
    LEFT JOIN dbo.Acc_Account AS x
        ON x.AccID = c.AccID
    WHERE c.CashFlowType IS NULL
    GROUP BY c.AccID, x.AccCode, x.AccName;

    -- 27: قيود نقدية ستُستثنى
    SELECT
        ce.MID,
        ce.CashNet,
        COUNT_BIG(c.DayDID) AS CounterCnt,
        SUM(CASE WHEN c.DayDID IS NOT NULL AND c.CashFlowType IS NULL THEN 1 ELSE 0 END) AS UnclassCnt,
        CAST(ISNULL(SUM(CASE WHEN c.CashFlowType BETWEEN 2 AND 4 THEN c.Flow END), 0) AS DECIMAL(38,3)) AS ClassifiedNet
    INTO #CashChk
    FROM #CashEntry AS ce
    LEFT JOIN #Counter AS c
        ON c.MID = ce.MID
    GROUP BY ce.MID, ce.CashNet;

    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        27, N'قيد', j.DayMID, CAST(j.DayMNo AS NVARCHAR(50)), j.DayMDescription,
        k.CashNet, k.ClassifiedNet,
        CONCAT
        (
            CONVERT(NVARCHAR(10), j.DayMDate, 23), N'؛ ',
            CASE
                WHEN k.CounterCnt = 0 THEN N'لا توجد بنود مقابلة لحركة النقدية'
                WHEN k.UnclassCnt > 0 THEN N'يوجد حساب مقابل غير مصنف'
                ELSE N'صافي البنود المقابلة لا يطابق صافي النقدية (قيد غير متوازن)'
            END,
            N'؛ الكمية الأولى = صافي النقدية، الثانية = صافي البنود المصنفة'
        )
    FROM #CashChk AS k
    INNER JOIN #Journal AS j
        ON j.DayMID = k.MID
    WHERE k.CounterCnt = 0
       OR k.UnclassCnt > 0
       OR ABS(k.ClassifiedNet - k.CashNet) > 0.001;

    -- 28: رصيد نقدية سالب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Note)
    SELECT
        28, N'حساب', a.AccID, a.AccCode, a.AccName,
        n.OpenNet + n.PerDeb - n.PerCrd,
        N'رصيد ختامي مدين سالب (أي دائن) في حساب نقدية'
    FROM #LeafNet AS n
    INNER JOIN #CF AS cf
        ON cf.AccID = n.AccID
       AND cf.CashFlowType = 1
    INNER JOIN #Acc AS a
        ON a.AccID = n.AccID
    WHERE n.OpenNet + n.PerDeb - n.PerCrd < 0;


    /* =========================================================
       11. عدد الملاحظات للفحوص القائمة على التفاصيل
           (الفحوص 15-21 و23 قيمية: عدّادها محسوب أعلاه)
       ========================================================= */

    UPDATE c
    SET c.IssueCount = d.Cnt
    FROM #Chk AS c
    INNER JOIN
    (
        SELECT CheckNo, COUNT_BIG(*) AS Cnt
        FROM #Det
        GROUP BY CheckNo
    ) AS d
        ON d.CheckNo = c.CheckNo
    WHERE c.CheckNo NOT BETWEEN 15 AND 21
      AND c.CheckNo <> 23;


    /* =========================================================
       RESULT SET 1: جدول الفحوص
       ========================================================= */

    SELECT
        c.CheckNo,
        c.Grp AS CheckGroup,
        c.Title AS CheckTitle,

        CASE c.Severity
            WHEN 1 THEN N'خطأ'
            ELSE N'تحذير'
        END AS Severity,

        CASE
            WHEN c.IssueCount = 0 THEN N'سليم'
            WHEN c.Severity = 1   THEN N'فشل'
            ELSE N'تنبيه'
        END AS CheckStatus,

        c.IssueCount,
        c.ExpectedValue,
        c.ActualValue,
        c.Difference

    FROM #Chk AS c
    ORDER BY c.CheckNo;


    /* =========================================================
       RESULT SET 2: تفاصيل الملاحظات (حتى @MaxDetails لكل فحص)
       ========================================================= */

    SELECT
        x.CheckNo,
        c.Title AS CheckTitle,
        c.IssueCount AS TotalIssuesInCheck,
        x.ObjectType,
        x.ObjectID,
        x.ObjectCode,
        x.ObjectName,
        x.Amount1,
        x.Amount2,
        x.Note
    FROM
    (
        SELECT
            d.*,
            ROW_NUMBER() OVER (PARTITION BY d.CheckNo ORDER BY d.Seq) AS RN
        FROM #Det AS d
    ) AS x
    INNER JOIN #Chk AS c
        ON c.CheckNo = x.CheckNo
    WHERE x.RN <= @MaxDetails
    ORDER BY x.CheckNo, x.Seq;


    /* =========================================================
       RESULT SET 3: الخلاصة
       ========================================================= */

    SELECT
        @Cmp AS CompanyID,
        @Year AS FinancialYear,
        @FromDate AS FromDate,
        @ToDate AS ToDate,

        COUNT(*) AS TotalChecks,
        SUM(CASE WHEN IssueCount > 0 AND Severity = 1 THEN 1 ELSE 0 END) AS FailedErrorChecks,
        SUM(CASE WHEN IssueCount > 0 AND Severity = 2 THEN 1 ELSE 0 END) AS WarningChecks,

        CASE
            WHEN SUM(CASE WHEN IssueCount > 0 AND Severity = 1 THEN 1 ELSE 0 END) > 0
                THEN N'توجد أخطاء تمنع الاعتماد على القوائم المالية'
            WHEN SUM(CASE WHEN IssueCount > 0 AND Severity = 2 THEN 1 ELSE 0 END) > 0
                THEN N'سليمة مع ملاحظات تحتاج مراجعة'
            ELSE N'سليمة: اجتازت كل الفحوص'
        END AS OverallStatus
    FROM #Chk;

END;
GO

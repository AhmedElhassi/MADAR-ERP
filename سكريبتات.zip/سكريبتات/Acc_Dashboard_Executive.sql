﻿USE MADARERPDataBase;
GO
/* =====================================================================
   لوحة المحاسبة التنفيذية — إجراءات قراءة فقط (لا تغيّر أي منطق ولا بيانات)
   القيود المحتسبة: DayMState من 1 إلى 7 (كل ما عدا المؤقت).
   الفترة: من 1/1/@Year حتى @AsOf، حيث
        @AsOf = اليوم إن وقع داخل السنة، وإلا نهاية السنة (أو بدايتها لسنة مستقبلية).
   المقارنة: نفس الفترة من السنة السابقة (من 1/1 حتى نفس اليوم والشهر).
   المعاملة @Part: 0 = كل المجموعات، أو رقم المجموعة المطلوبة وحدها
        (تسمح بالاختبار INSERT-EXEC وبتحميل جزء واحد في الصفحة).

   Acc_SelectDashboardExecutive  — المجموعات:
     1 KPI        صف واحد (الفترة، الإيراد، المصروف، النقدية، الأصول، الخصوم...)
     2 Monthly    12 صفًا (إيراد/مصروف/نقدية داخلة وخارجة + السنة السابقة)
     3 RevenueSrc أعلى 8 حسابات إيراد + «أخرى»
     4 ExpenseSrc أعلى 8 حسابات مصروف + «أخرى»
     5 CashAcc    أرصدة حسابات النقدية والبنوك (حتى 8)
     6 Health     مؤشرات الرقابة (صف واحد)
     7 Abnormal   أعلى 8 حسابات بأرصدة شاذة

   Acc_SelectDashboardProject    — المجموعات:
     1 Summary    ملخص المشروع المختار (أو كل المشاريع)
     2 Monthly    12 صفًا (الصرف الشهري + السنة السابقة + إجمالي الشركة)
     3 TopAcc     أعلى 8 حسابات صرفًا على المشروع
     4 Ranking    أعلى 12 مشروعًا بحسب الصرف المباشر على المشروع نفسه
     5 Children   المشاريع الفرعية المباشرة للمختار (أو الجذور)
     6 List       قائمة كل المشاريع للقائمة المنسدلة (إن @IncludeList = 1)
   ===================================================================== */

CREATE OR ALTER PROCEDURE dbo.Acc_SelectDashboardExecutive
    @Cmp  INT,
    @Year INT,
    @Part TINYINT = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF @Cmp IS NULL OR @Cmp <= 0 THROW 53101, N'الشركة المحددة غير صحيحة.', 1;
    IF @Year IS NULL OR @Year < 1900 OR @Year > 2200 THROW 53102, N'السنة المالية غير صحيحة.', 1;

    DECLARE @Today  DATE = CAST(GETDATE() AS DATE);
    DECLARE @YStart DATE = DATEFROMPARTS(@Year, 1, 1);
    DECLARE @YEnd   DATE = DATEFROMPARTS(@Year, 12, 31);
    DECLARE @AsOf   DATE = CASE WHEN @Today > @YEnd THEN @YEnd
                                WHEN @Today < @YStart THEN @YStart
                                ELSE @Today END;
    DECLARE @PStart DATE = DATEADD(YEAR, -1, @YStart);
    DECLARE @PAsOf  DATE = DATEADD(YEAR, -1, @AsOf);
    DECLARE @PYEnd  DATE = DATEADD(YEAR, -1, @YEnd);
    DECLARE @MoAsOf INT  = MONTH(@AsOf);

    /* حركات الشركة (غير المؤقتة) حتى @AsOf، مع تصنيف الحساب */
    SELECT m.DayMID, m.DayMDate, d.DayDAccID AS AccID,
           d.DayDDeb AS Deb, d.DayDCrd AS Crd, a.AccEnd, a.AccType
    INTO #M
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    JOIN dbo.Acc_Account    AS a ON a.AccID = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate <= @AsOf;

    CREATE CLUSTERED INDEX IX_M ON #M (AccID, DayMDate);

    /* شجرة الحسابات + الأوراق */
    SELECT AccID, AccParentID, AccCode, AccName INTO #Acc
    FROM dbo.Acc_Account WHERE AccCompany = @Cmp;
    CREATE UNIQUE CLUSTERED INDEX IX_Acc ON #Acc (AccID);

    SELECT a.AccID INTO #Leaf
    FROM #Acc AS a
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS c WHERE c.AccParentID = a.AccID);
    CREATE UNIQUE CLUSTERED INDEX IX_Leaf ON #Leaf (AccID);

    /* حسابات النقدية: الأوراق تحت تصنيف CashFlowType = 1 (يرث من الآباء) */
    ;WITH Up AS
    (
        SELECT a.AccID AS LeafID, a.AccID AS NodeID, a.AccParentID AS ParentID
        FROM #Acc AS a
        UNION ALL
        SELECT u.LeafID, p.AccID, p.AccParentID
        FROM Up AS u JOIN #Acc AS p ON p.AccID = u.ParentID
        WHERE u.ParentID > 0
    )
    SELECT DISTINCT u.LeafID AS AccID
    INTO #CashLeaf
    FROM Up AS u
    JOIN dbo.Acc_CashFlowAccounts AS c ON c.AccID = u.NodeID AND c.CashFlowType = 1
    WHERE EXISTS (SELECT 1 FROM #Leaf AS l WHERE l.AccID = u.LeafID)
    OPTION (MAXRECURSION 200);
    CREATE UNIQUE CLUSTERED INDEX IX_CashLeaf ON #CashLeaf (AccID);

    /* حركة القيد على النقدية: الداخل = زيادة صافية، الخارج = نقص صافٍ.
       التحويل بين حسابي نقدية داخل القيد نفسه لا يُحتسب داخلًا ولا خارجًا. */
    SELECT m.DayMID, m.DayMDate,
           SUM(m.Deb) AS CDeb, SUM(m.Crd) AS CCrd
    INTO #CV
    FROM #M AS m
    JOIN #CashLeaf AS c ON c.AccID = m.AccID
    GROUP BY m.DayMID, m.DayMDate;

    /* --------------------------- 1) KPI --------------------------- */
    IF @Part IN (0, 1)
    BEGIN
        DECLARE @Rev  DECIMAL(28,3), @Exp  DECIMAL(28,3), @PRev DECIMAL(28,3), @PExp DECIMAL(28,3);

        SELECT
            @Rev  = ISNULL(SUM(CASE WHEN AccType = 0 AND DayMDate >= @YStart THEN Crd - Deb END), 0),
            @Exp  = ISNULL(SUM(CASE WHEN AccType = 1 AND DayMDate >= @YStart THEN Deb - Crd END), 0),
            @PRev = ISNULL(SUM(CASE WHEN AccType = 0 AND DayMDate BETWEEN @PStart AND @PAsOf THEN Crd - Deb END), 0),
            @PExp = ISNULL(SUM(CASE WHEN AccType = 1 AND DayMDate BETWEEN @PStart AND @PAsOf THEN Deb - Crd END), 0)
        FROM #M WHERE AccEnd = 2;

        SELECT
            @AsOf   AS AsOf,
            @PAsOf  AS PAsOf,
            @YStart AS YStart,
            @Rev    AS Revenue,
            @Exp    AS Expenses,
            @Rev - @Exp   AS NetResult,
            @PRev   AS PRevenue,
            @PExp   AS PExpenses,
            @PRev - @PExp AS PNetResult,
            -- النقدية
            ISNULL((SELECT SUM(m.Deb - m.Crd) FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID), 0) AS CashBalance,
            ISNULL((SELECT SUM(m.Deb - m.Crd) FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
                     WHERE m.DayMDate < @YStart), 0) AS CashOpening,
            ISNULL((SELECT SUM(m.Deb - m.Crd) FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
                     WHERE m.DayMDate <= @PAsOf), 0) AS PCashBalance,
            ISNULL((SELECT SUM(CASE WHEN CDeb > CCrd THEN CDeb - CCrd ELSE 0 END) FROM #CV WHERE DayMDate >= @YStart), 0) AS CashIn,
            ISNULL((SELECT SUM(CASE WHEN CCrd > CDeb THEN CCrd - CDeb ELSE 0 END) FROM #CV WHERE DayMDate >= @YStart), 0) AS CashOut,
            ISNULL((SELECT SUM(CASE WHEN CDeb > CCrd THEN CDeb - CCrd ELSE 0 END) FROM #CV WHERE DayMDate BETWEEN @PStart AND @PAsOf), 0) AS PCashIn,
            ISNULL((SELECT SUM(CASE WHEN CCrd > CDeb THEN CCrd - CDeb ELSE 0 END) FROM #CV WHERE DayMDate BETWEEN @PStart AND @PAsOf), 0) AS PCashOut,
            -- المركز المالي (تراكمي كل السنوات حتى @AsOf)
            ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 1 AND AccType = 0), 0) AS Assets,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType = 1), 0) AS Liabilities,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType = 2), 0) AS Equity,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2), 0) AS CumResult,
            ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 1 AND AccType = 0), 0)
              - ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType IN (1, 2)), 0)
              - ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2), 0) AS BalanceDiff,
            ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 1 AND AccType = 0 AND DayMDate <= @PAsOf), 0) AS PAssets,
            ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 1 AND AccType = 1 AND DayMDate <= @PAsOf), 0) AS PLiabilities;
    END;

    /* --------------------------- 2) الشهري --------------------------- */
    IF @Part IN (0, 2)
    BEGIN
        ;WITH Mo AS (SELECT 1 AS N UNION ALL SELECT N + 1 FROM Mo WHERE N < 12)
        SELECT
            Mo.N AS Mo,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2 AND AccType = 0
                               AND DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS Revenue,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 2 AND AccType = 1
                               AND DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS Expenses,
            CAST(ISNULL((SELECT SUM(Crd - Deb) FROM #M WHERE AccEnd = 2 AND AccType = 0
                           AND DayMDate BETWEEN @PStart AND @PYEnd AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) AS PRevenue,
            CAST(ISNULL((SELECT SUM(Deb - Crd) FROM #M WHERE AccEnd = 2 AND AccType = 1
                           AND DayMDate BETWEEN @PStart AND @PYEnd AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) AS PExpenses,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(CASE WHEN CDeb > CCrd THEN CDeb - CCrd ELSE 0 END) FROM #CV
                               WHERE DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS CashIn,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(CASE WHEN CCrd > CDeb THEN CCrd - CDeb ELSE 0 END) FROM #CV
                               WHERE DayMDate >= @YStart AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS CashOut
        FROM Mo
        ORDER BY Mo.N;
    END;

    /* ------------------- 3) مصادر الإيراد / 4) أوجه المصروف ------------------- */
    IF @Part IN (0, 3, 4)
    BEGIN
        SELECT m.AccID, m.AccType,
               SUM(CASE WHEN m.DayMDate >= @YStart THEN
                        CASE WHEN m.AccType = 0 THEN m.Crd - m.Deb ELSE m.Deb - m.Crd END END) AS Cur,
               SUM(CASE WHEN m.DayMDate BETWEEN @PStart AND @PAsOf THEN
                        CASE WHEN m.AccType = 0 THEN m.Crd - m.Deb ELSE m.Deb - m.Crd END END) AS Prev
        INTO #Src
        FROM #M AS m
        WHERE m.AccEnd = 2 AND m.AccType IN (0, 1)
          AND m.DayMDate >= @PStart
        GROUP BY m.AccID, m.AccType;

        UPDATE #Src SET Cur = ISNULL(Cur, 0), Prev = ISNULL(Prev, 0);
        DELETE FROM #Src WHERE Cur = 0 AND Prev = 0;

        IF @Part IN (0, 3)
        BEGIN
            ;WITH R AS
            (
                SELECT s.AccID, a.AccCode, a.AccName, s.Cur, s.Prev,
                       ROW_NUMBER() OVER (ORDER BY s.Cur DESC, s.Prev DESC, s.AccID) AS Rk
                FROM #Src AS s JOIN #Acc AS a ON a.AccID = s.AccID
                WHERE s.AccType = 0
            )
            SELECT Rk AS [Rank], AccCode, AccName, CAST(Cur AS DECIMAL(28,3)) AS Cur, CAST(Prev AS DECIMAL(28,3)) AS Prev
            FROM R WHERE Rk <= 8
            UNION ALL
            SELECT 99, N'', N'أخرى', CAST(SUM(Cur) AS DECIMAL(28,3)), CAST(SUM(Prev) AS DECIMAL(28,3))
            FROM R WHERE Rk > 8 HAVING COUNT(*) > 0
            ORDER BY [Rank];
        END;

        IF @Part IN (0, 4)
        BEGIN
            ;WITH R AS
            (
                SELECT s.AccID, a.AccCode, a.AccName, s.Cur, s.Prev,
                       ROW_NUMBER() OVER (ORDER BY s.Cur DESC, s.Prev DESC, s.AccID) AS Rk
                FROM #Src AS s JOIN #Acc AS a ON a.AccID = s.AccID
                WHERE s.AccType = 1
            )
            SELECT Rk AS [Rank], AccCode, AccName, CAST(Cur AS DECIMAL(28,3)) AS Cur, CAST(Prev AS DECIMAL(28,3)) AS Prev
            FROM R WHERE Rk <= 8
            UNION ALL
            SELECT 99, N'', N'أخرى', CAST(SUM(Cur) AS DECIMAL(28,3)), CAST(SUM(Prev) AS DECIMAL(28,3))
            FROM R WHERE Rk > 8 HAVING COUNT(*) > 0
            ORDER BY [Rank];
        END;
    END;

    /* --------------------------- 5) حسابات النقدية --------------------------- */
    IF @Part IN (0, 5)
    BEGIN
        SELECT TOP (8) a.AccCode, a.AccName, CAST(b.Bal AS DECIMAL(28,3)) AS Balance
        FROM (SELECT m.AccID, SUM(m.Deb - m.Crd) AS Bal
              FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
              GROUP BY m.AccID) AS b
        JOIN #Acc AS a ON a.AccID = b.AccID
        WHERE b.Bal <> 0
        ORDER BY ABS(b.Bal) DESC;
    END;

    /* --------------------------- 6) الرقابة --------------------------- */
    IF @Part IN (0, 6)
    BEGIN
        SELECT
            (SELECT COUNT(*) FROM
                (SELECT DayMID FROM #M WHERE DayMDate >= @YStart
                 GROUP BY DayMID HAVING SUM(Deb) <> SUM(Crd)) AS x) AS UnbalancedPosted,
            (SELECT COUNT(*) FROM dbo.Acc_DayMaster
              WHERE DayMCompany = @Cmp AND DayMState = 0
                AND DayMDate BETWEEN @YStart AND @YEnd
                AND DayMDateTime < DATEADD(DAY, -7, SYSUTCDATETIME())) AS StaleDrafts,
            (SELECT COUNT(*) FROM dbo.Acc_DayMaster
              WHERE DayMCompany = @Cmp AND DayMState IN (2, 4, 6)
                AND DayMDate BETWEEN @YStart AND @YEnd) AS ReturnedVouchers,
            (SELECT COUNT(*) FROM
                (SELECT m.AccID FROM #M AS m JOIN #CashLeaf AS c ON c.AccID = m.AccID
                 GROUP BY m.AccID HAVING SUM(m.Deb - m.Crd) < 0) AS x) AS NegativeCashAccounts,
            (SELECT COUNT(*) FROM
                (SELECT m.AccID FROM #M AS m JOIN #Leaf AS l ON l.AccID = m.AccID
                 WHERE m.AccEnd = 1
                 GROUP BY m.AccID, m.AccType
                 HAVING (m.AccType = 0 AND SUM(m.Deb - m.Crd) < 0)
                     OR (m.AccType IN (1, 2) AND SUM(m.Crd - m.Deb) < 0)) AS x) AS AbnormalBalances;
    END;

    /* --------------------------- 7) أرصدة شاذة --------------------------- */
    IF @Part IN (0, 7)
    BEGIN
        SELECT TOP (8) a.AccCode, a.AccName,
               CASE WHEN x.AccType = 0 THEN N'أصل برصيد دائن' ELSE N'خصم/ملكية برصيد مدين' END AS Kind,
               CAST(x.Amt AS DECIMAL(28,3)) AS Amount
        FROM
        (
            SELECT m.AccID, m.AccType,
                   CASE WHEN m.AccType = 0 THEN SUM(m.Deb - m.Crd) ELSE SUM(m.Crd - m.Deb) END AS Amt
            FROM #M AS m JOIN #Leaf AS l ON l.AccID = m.AccID
            WHERE m.AccEnd = 1
            GROUP BY m.AccID, m.AccType
        ) AS x
        JOIN #Acc AS a ON a.AccID = x.AccID
        WHERE x.Amt < 0
        ORDER BY x.Amt ASC;
    END;
END;
GO

/* =====================================================================
   تحليل المشاريع (مراكز التكلفة): المصروفات فقط.
   الإيراد غير مقيّد على مراكز التكلفة في بياناتك (سطر واحد فقط)، لذلك لا يُحسب
   إيراد المشروع؛ يُعاد عدد أسطر الإيراد المقيّدة ليقرر العرض.
   @CsCID: NULL أو 0 = كل المشاريع.  المشروع الأب يشمل مشاريعه الفرعية.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_SelectDashboardProject
    @Cmp         INT,
    @Year        INT,
    @CsCID       BIGINT  = NULL,
    @IncludeList BIT     = 0,
    @Part        TINYINT = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF @Cmp IS NULL OR @Cmp <= 0 THROW 53111, N'الشركة المحددة غير صحيحة.', 1;
    IF @Year IS NULL OR @Year < 1900 OR @Year > 2200 THROW 53112, N'السنة المالية غير صحيحة.', 1;

    SET @CsCID = NULLIF(@CsCID, 0);

    IF @CsCID IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
        THROW 53113, N'المشروع المحدد غير موجود أو لا يتبع الشركة.', 1;

    DECLARE @Today  DATE = CAST(GETDATE() AS DATE);
    DECLARE @YStart DATE = DATEFROMPARTS(@Year, 1, 1);
    DECLARE @YEnd   DATE = DATEFROMPARTS(@Year, 12, 31);
    DECLARE @AsOf   DATE = CASE WHEN @Today > @YEnd THEN @YEnd
                                WHEN @Today < @YStart THEN @YStart
                                ELSE @Today END;
    DECLARE @PStart DATE = DATEADD(YEAR, -1, @YStart);
    DECLARE @PAsOf  DATE = DATEADD(YEAR, -1, @AsOf);
    DECLARE @PYEnd  DATE = DATEADD(YEAR, -1, @YEnd);
    DECLARE @MoAsOf INT  = MONTH(@AsOf);

    /* مراكز التكلفة + علاقة الأب بالأحفاد (Desc → Anc) */
    SELECT CsCID, CsCParentID, CsCCode, CsCName, CsCLevel, CsCState INTO #CC
    FROM dbo.Acc_CostCenter WHERE CsCCompany = @Cmp;
    CREATE UNIQUE CLUSTERED INDEX IX_CC ON #CC (CsCID);

    ;WITH Up AS
    (
        SELECT c.CsCID AS D, c.CsCID AS A, c.CsCParentID AS P FROM #CC AS c
        UNION ALL
        SELECT u.D, p.CsCID, p.CsCParentID
        FROM Up AS u JOIN #CC AS p ON p.CsCID = u.P
        WHERE u.P > 0
    )
    SELECT D, A INTO #Anc FROM Up OPTION (MAXRECURSION 200);
    CREATE CLUSTERED INDEX IX_Anc ON #Anc (A, D);

    /* أسطر المصروفات للفترتين (الحالية والسابقة) */
    SELECT m.DayMID, m.DayMDate, d.DayDAccID AS AccID, d.DayDCsCID AS CsC,
           d.DayDDeb - d.DayDCrd AS Amt,
           CASE WHEN m.DayMDate >= @YStart THEN 1 ELSE 0 END AS IsCur
    INTO #E
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    JOIN dbo.Acc_Account    AS a ON a.AccID = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND a.AccEnd = 2 AND a.AccType = 1
      AND ((m.DayMDate >= @YStart AND m.DayMDate <= @AsOf)
        OR (m.DayMDate >= @PStart AND m.DayMDate <= @PAsOf));
    CREATE CLUSTERED INDEX IX_E ON #E (CsC);

    /* أسطر المشروع المختار (الأب يشمل أحفاده) أو كل المقيّد على مراكز تكلفة */
    SELECT e.* INTO #EP
    FROM #E AS e
    WHERE e.CsC IS NOT NULL
      AND (@CsCID IS NULL
           OR EXISTS (SELECT 1 FROM #Anc AS n WHERE n.D = e.CsC AND n.A = @CsCID));

    /* ------------------------ 1) الملخص ------------------------ */
    IF @Part IN (0, 1)
    BEGIN
        DECLARE @Cur DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 1), 0);
        DECLARE @Prv DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 0), 0);
        DECLARE @All DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1), 0);
        DECLARE @Tag DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1 AND CsC IS NOT NULL), 0);
        DECLARE @MaxMo INT, @MaxAmt DECIMAL(28,3);

        SELECT TOP (1) @MaxMo = Mo, @MaxAmt = S
        FROM (SELECT MONTH(DayMDate) AS Mo, SUM(Amt) AS S FROM #EP WHERE IsCur = 1 GROUP BY MONTH(DayMDate)) AS z
        ORDER BY S DESC;

        SELECT
            @CsCID AS CsCID,
            ISNULL((SELECT CsCCode FROM #CC WHERE CsCID = @CsCID), N'') AS CsCCode,
            ISNULL((SELECT CsCName FROM #CC WHERE CsCID = @CsCID), N'كل المشاريع') AS CsCName,
            @AsOf  AS AsOf,
            @PAsOf AS PAsOf,
            @Cur   AS ProjExp,
            @Prv   AS ProjExpPrev,
            @All   AS CompanyExp,
            @Tag   AS TaggedExp,
            @All - @Tag AS UnallocatedExp,
            CASE WHEN @All = 0 THEN NULL ELSE CAST(@Cur * 100.0 / @All AS DECIMAL(9,2)) END AS SharePct,
            (SELECT COUNT(DISTINCT MONTH(DayMDate)) FROM #EP WHERE IsCur = 1 AND Amt <> 0) AS ActiveMonths,
            @MoAsOf AS MonthsElapsed,
            CAST(@Cur / NULLIF(@MoAsOf, 0) AS DECIMAL(28,3)) AS AvgMonthly,
            @MaxMo  AS MaxMonth,
            @MaxAmt AS MaxMonthAmount,
            (SELECT COUNT(*)
               FROM dbo.Acc_DayMaster AS m
               JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
               JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
              WHERE m.DayMCompany = @Cmp AND m.DayMState BETWEEN 1 AND 7
                AND m.DayMDate BETWEEN @YStart AND @AsOf
                AND a.AccEnd = 2 AND a.AccType = 0
                AND d.DayDCsCID IS NOT NULL) AS RevenueTaggedLines;
    END;

    /* ------------------------ 2) الشهري ------------------------ */
    IF @Part IN (0, 2)
    BEGIN
        ;WITH Mo AS (SELECT 1 AS N UNION ALL SELECT N + 1 FROM Mo WHERE N < 12)
        SELECT
            Mo.N AS Mo,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 1 AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS ProjExp,
            CAST(ISNULL((SELECT SUM(Amt) FROM #EP WHERE IsCur = 0 AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) AS ProjExpPrev,
            CASE WHEN DATEFROMPARTS(@Year, Mo.N, 1) > @AsOf THEN NULL ELSE
                CAST(ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1 AND MONTH(DayMDate) = Mo.N), 0) AS DECIMAL(28,3)) END AS CompanyExp
        FROM Mo
        ORDER BY Mo.N;
    END;

    /* ------------------------ 3) أعلى الحسابات ------------------------ */
    IF @Part IN (0, 3)
    BEGIN
        SELECT TOP (8) a.AccCode, a.AccName,
               CAST(SUM(CASE WHEN p.IsCur = 1 THEN p.Amt ELSE 0 END) AS DECIMAL(28,3)) AS Cur,
               CAST(SUM(CASE WHEN p.IsCur = 0 THEN p.Amt ELSE 0 END) AS DECIMAL(28,3)) AS Prev
        FROM #EP AS p
        JOIN dbo.Acc_Account AS a ON a.AccID = p.AccID
        GROUP BY a.AccID, a.AccCode, a.AccName
        HAVING SUM(CASE WHEN p.IsCur = 1 THEN p.Amt ELSE 0 END) <> 0
        ORDER BY SUM(CASE WHEN p.IsCur = 1 THEN p.Amt ELSE 0 END) DESC;
    END;

    /* ------------------------ 4) ترتيب المشاريع (الصرف المباشر على كل مشروع) ------------------------ */
    IF @Part IN (0, 4)
    BEGIN
        DECLARE @TagAll DECIMAL(28,3) = ISNULL((SELECT SUM(Amt) FROM #E WHERE IsCur = 1 AND CsC IS NOT NULL), 0);

        SELECT TOP (12)
               c.CsCID, c.CsCCode, c.CsCName,
               CAST(SUM(e.Amt) AS DECIMAL(28,3)) AS Amount,
               CASE WHEN @TagAll = 0 THEN NULL ELSE CAST(SUM(e.Amt) * 100.0 / @TagAll AS DECIMAL(9,2)) END AS SharePct,
               CAST(CASE WHEN @CsCID IS NULL THEN 0
                         WHEN EXISTS (SELECT 1 FROM #Anc AS n WHERE n.D = c.CsCID AND n.A = @CsCID) THEN 1
                         ELSE 0 END AS BIT) AS IsSelected
        FROM #E AS e
        JOIN #CC AS c ON c.CsCID = e.CsC
        WHERE e.IsCur = 1
        GROUP BY c.CsCID, c.CsCCode, c.CsCName
        HAVING SUM(e.Amt) <> 0
        ORDER BY SUM(e.Amt) DESC;
    END;

    /* ------------------------ 5) المشاريع الفرعية المباشرة ------------------------ */
    IF @Part IN (0, 5)
    BEGIN
        SELECT TOP (20)
               c.CsCID, c.CsCCode, c.CsCName,
               CAST(ISNULL(SUM(CASE WHEN e.IsCur = 1 THEN e.Amt END), 0) AS DECIMAL(28,3)) AS Cur,
               CAST(ISNULL(SUM(CASE WHEN e.IsCur = 0 THEN e.Amt END), 0) AS DECIMAL(28,3)) AS Prev
        FROM #CC AS c
        LEFT JOIN #Anc AS n ON n.A = c.CsCID
        LEFT JOIN #E   AS e ON e.CsC = n.D
        WHERE (@CsCID IS NULL AND (c.CsCParentID IS NULL OR c.CsCParentID = 0))
           OR (@CsCID IS NOT NULL AND c.CsCParentID = @CsCID)
        GROUP BY c.CsCID, c.CsCCode, c.CsCName
        HAVING ISNULL(SUM(CASE WHEN e.IsCur = 1 THEN e.Amt END), 0) <> 0
            OR ISNULL(SUM(CASE WHEN e.IsCur = 0 THEN e.Amt END), 0) <> 0
        ORDER BY ISNULL(SUM(CASE WHEN e.IsCur = 1 THEN e.Amt END), 0) DESC;
    END;

    /* ------------------------ 6) قائمة المشاريع ------------------------ */
    IF @Part IN (0, 6)
    BEGIN
        SELECT c.CsCID, c.CsCCode, c.CsCName, c.CsCLevel, c.CsCParentID,
               CAST(CASE WHEN EXISTS (SELECT 1 FROM #CC AS k WHERE k.CsCParentID = c.CsCID) THEN 1 ELSE 0 END AS BIT) AS HasChildren
        FROM #CC AS c
        WHERE @IncludeList = 1 AND c.CsCState = 0
        ORDER BY c.CsCCode;
    END;
END;
GO

﻿/* =====================================================================
   مطابقة أرقام اللوحة التنفيذية مع التقارير الحالية (قراءة فقط، لا يغيّر شيئًا)
   قبل التشغيل: نفّذ Acc_Dashboard_Executive.sql و Acc_FixState_RemainingProcs.sql
   (قائمة الدخل يجب أن تحتسب الحالات 1–7 كاللوحة).
   النتيجة: أسطر PASS / FAIL / INFO في تبويب Messages.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;

DECLARE @Cmp  INT = 10;
DECLARE @Year INT = 2026;

/* ---------- التقاط مجموعات اللوحة ---------- */
CREATE TABLE #K (AsOf DATE, PAsOf DATE, YStart DATE,
    Revenue DECIMAL(28,3), Expenses DECIMAL(28,3), NetResult DECIMAL(28,3),
    PRevenue DECIMAL(28,3), PExpenses DECIMAL(28,3), PNetResult DECIMAL(28,3),
    CashBalance DECIMAL(28,3), CashOpening DECIMAL(28,3), PCashBalance DECIMAL(28,3),
    CashIn DECIMAL(28,3), CashOut DECIMAL(28,3), PCashIn DECIMAL(28,3), PCashOut DECIMAL(28,3),
    Assets DECIMAL(28,3), Liabilities DECIMAL(28,3), Equity DECIMAL(28,3), CumResult DECIMAL(28,3),
    BalanceDiff DECIMAL(28,3), PAssets DECIMAL(28,3), PLiabilities DECIMAL(28,3));
CREATE TABLE #Mo (Mo INT, Revenue DECIMAL(28,3), Expenses DECIMAL(28,3), PRevenue DECIMAL(28,3),
    PExpenses DECIMAL(28,3), CashIn DECIMAL(28,3), CashOut DECIMAL(28,3));
CREATE TABLE #RS (Rk BIGINT, AccCode NVARCHAR(60), AccName NVARCHAR(500), Cur DECIMAL(28,3), Prev DECIMAL(28,3));
CREATE TABLE #ES (Rk BIGINT, AccCode NVARCHAR(60), AccName NVARCHAR(500), Cur DECIMAL(28,3), Prev DECIMAL(28,3));
CREATE TABLE #IS (
    AccID BIGINT, AccCode NVARCHAR(60), AccARName NVARCHAR(500),
    AccEnd INT, AccType INT, AccountCategory NVARCHAR(30),
    AccLevel INT, AccParint BIGINT NULL, AccParintName NVARCHAR(500) NULL, AccCountChid INT,
    RevenueAmount DECIMAL(38,3), ExpenseAmount DECIMAL(38,3), PeriodAmount DECIMAL(38,3),
    PeriodDebit DECIMAL(38,3), PeriodCredit DECIMAL(38,3), MovementCount BIGINT,
    TotalRevenue DECIMAL(38,3), TotalExpenses DECIMAL(38,3), NetProfitLoss DECIMAL(38,3),
    ProfitLossStatus NVARCHAR(30),
    ChkNonLeafAccounts INT, ChkOrphanAccounts INT, ChkCrossCompanyParents INT,
    ChkForeignAccounts INT, ChkChidMismatch INT);

INSERT #K  EXEC dbo.Acc_SelectDashboardExecutive @Cmp = @Cmp, @Year = @Year, @Part = 1;
INSERT #Mo EXEC dbo.Acc_SelectDashboardExecutive @Cmp = @Cmp, @Year = @Year, @Part = 2;
INSERT #RS EXEC dbo.Acc_SelectDashboardExecutive @Cmp = @Cmp, @Year = @Year, @Part = 3;
INSERT #ES EXEC dbo.Acc_SelectDashboardExecutive @Cmp = @Cmp, @Year = @Year, @Part = 4;

DECLARE @AsOf DATE, @YStart DATE, @PAsOf DATE;
SELECT @AsOf = AsOf, @YStart = YStart, @PAsOf = PAsOf FROM #K;

INSERT #IS EXEC dbo.Acc_SelectAccIncomeStatement @FromDate = @YStart, @ToDate = @AsOf, @Cmp = @Cmp, @Year = @Year;

DECLARE @Pass INT = 0, @Fail INT = 0;
DECLARE @tol DECIMAL(9,3) = 0.001;

DECLARE @T TABLE (Name NVARCHAR(300), Ok BIT);

/* ---------- الشركة كلها ---------- */
INSERT @T
SELECT N'V1 الإيراد = إجمالي الإيراد في قائمة الدخل (' + CONVERT(NVARCHAR(30), k.Revenue) + N')',
       CASE WHEN ABS(k.Revenue - i.TotalRevenue) <= @tol THEN 1 ELSE 0 END
FROM #K k CROSS APPLY (SELECT TOP (1) TotalRevenue, TotalExpenses, NetProfitLoss FROM #IS) i;

INSERT @T
SELECT N'V2 المصروف = إجمالي المصروف في قائمة الدخل (' + CONVERT(NVARCHAR(30), k.Expenses) + N')',
       CASE WHEN ABS(k.Expenses - i.TotalExpenses) <= @tol THEN 1 ELSE 0 END
FROM #K k CROSS APPLY (SELECT TOP (1) TotalRevenue, TotalExpenses, NetProfitLoss FROM #IS) i;

INSERT @T
SELECT N'V3 صافي النتيجة = صافي الربح/الخسارة في قائمة الدخل',
       CASE WHEN ABS(k.NetResult - i.NetProfitLoss) <= @tol THEN 1 ELSE 0 END
FROM #K k CROSS APPLY (SELECT TOP (1) NetProfitLoss FROM #IS) i;

INSERT @T
SELECT N'V4 مجموع الأشهر (إيراد) = إيراد السنة حتى اليوم',
       CASE WHEN ABS(ISNULL((SELECT SUM(Revenue) FROM #Mo), 0) - k.Revenue) <= @tol THEN 1 ELSE 0 END FROM #K k;

INSERT @T
SELECT N'V5 مجموع الأشهر (مصروف) = مصروف السنة حتى اليوم',
       CASE WHEN ABS(ISNULL((SELECT SUM(Expenses) FROM #Mo), 0) - k.Expenses) <= @tol THEN 1 ELSE 0 END FROM #K k;

INSERT @T
SELECT N'V6 رصيد النقدية = الافتتاحي + الداخل − الخارج',
       CASE WHEN ABS(k.CashBalance - (k.CashOpening + k.CashIn - k.CashOut)) <= @tol THEN 1 ELSE 0 END FROM #K k;

INSERT @T
SELECT N'V7 مجموع الداخل والخارج الشهريين = إجماليهما في المؤشرات',
       CASE WHEN ABS(ISNULL((SELECT SUM(CashIn) FROM #Mo), 0) - k.CashIn) <= @tol
             AND ABS(ISNULL((SELECT SUM(CashOut) FROM #Mo), 0) - k.CashOut) <= @tol THEN 1 ELSE 0 END FROM #K k;

INSERT @T
SELECT N'V8 مجموع مصادر الإيراد (مع «أخرى») = الإيراد، والسابق = إيراد السنة السابقة',
       CASE WHEN ABS(ISNULL((SELECT SUM(Cur) FROM #RS), 0) - k.Revenue) <= @tol
             AND ABS(ISNULL((SELECT SUM(Prev) FROM #RS), 0) - k.PRevenue) <= @tol THEN 1 ELSE 0 END FROM #K k;

INSERT @T
SELECT N'V9 مجموع أوجه المصروف (مع «أخرى») = المصروف، والسابق = مصروف السنة السابقة',
       CASE WHEN ABS(ISNULL((SELECT SUM(Cur) FROM #ES), 0) - k.Expenses) <= @tol
             AND ABS(ISNULL((SELECT SUM(Prev) FROM #ES), 0) - k.PExpenses) <= @tol THEN 1 ELSE 0 END FROM #K k;

/* ---------- المشاريع ---------- */
CREATE TABLE #PS (CsCID BIGINT, CsCCode NVARCHAR(60), CsCName NVARCHAR(500), AsOf DATE, PAsOf DATE,
    ProjExp DECIMAL(28,3), ProjExpPrev DECIMAL(28,3), CompanyExp DECIMAL(28,3), TaggedExp DECIMAL(28,3),
    UnallocatedExp DECIMAL(28,3), SharePct DECIMAL(9,2), ActiveMonths INT, MonthsElapsed INT,
    AvgMonthly DECIMAL(28,3), MaxMonth INT, MaxMonthAmount DECIMAL(28,3), RevenueTaggedLines INT);
CREATE TABLE #PM (Mo INT, ProjExp DECIMAL(28,3), ProjExpPrev DECIMAL(28,3), CompanyExp DECIMAL(28,3));
CREATE TABLE #PK (CsCID BIGINT, CsCCode NVARCHAR(60), CsCName NVARCHAR(500), Amount DECIMAL(28,3),
    SharePct DECIMAL(9,2), IsSelected BIT);
CREATE TABLE #PC (CsCID BIGINT, CsCCode NVARCHAR(60), CsCName NVARCHAR(500), Cur DECIMAL(28,3), Prev DECIMAL(28,3));

INSERT #PS EXEC dbo.Acc_SelectDashboardProject @Cmp = @Cmp, @Year = @Year, @CsCID = NULL, @Part = 1;
INSERT #PM EXEC dbo.Acc_SelectDashboardProject @Cmp = @Cmp, @Year = @Year, @CsCID = NULL, @Part = 2;
INSERT #PK EXEC dbo.Acc_SelectDashboardProject @Cmp = @Cmp, @Year = @Year, @CsCID = NULL, @Part = 4;
INSERT #PC EXEC dbo.Acc_SelectDashboardProject @Cmp = @Cmp, @Year = @Year, @CsCID = NULL, @Part = 5;

INSERT @T
SELECT N'P1 كل المشاريع: المقيّد + غير الموزع = مصروف الشركة = مصروف اللوحة',
       CASE WHEN ABS(p.TaggedExp + p.UnallocatedExp - p.CompanyExp) <= @tol
             AND ABS(p.CompanyExp - k.Expenses) <= @tol THEN 1 ELSE 0 END
FROM #PS p CROSS JOIN #K k;

INSERT @T
SELECT N'P2 كل المشاريع: مجموع الأشهر = مصروف المشاريع، ومجموع الشركة الشهري = مصروف الشركة',
       CASE WHEN ABS(ISNULL((SELECT SUM(ProjExp) FROM #PM), 0) - p.ProjExp) <= @tol
             AND ABS(ISNULL((SELECT SUM(CompanyExp) FROM #PM), 0) - p.CompanyExp) <= @tol THEN 1 ELSE 0 END
FROM #PS p;

INSERT @T
SELECT N'P3 كل المشاريع: مجموع الجذور (الفرعية المباشرة) = مصروف المشاريع المقيّد',
       CASE WHEN ABS(ISNULL((SELECT SUM(Cur) FROM #PC), 0) - p.ProjExp) <= @tol THEN 1 ELSE 0 END
FROM #PS p;

/* مطابقة مستقلة (طريقة مختلفة: تكرار نزولي) لثلاثة مشاريع: أكبر جذر، أكبر ورقة، وسطي */
DECLARE @Pick TABLE (Tag NVARCHAR(30), CsCID BIGINT);
INSERT @Pick SELECT TOP (1) N'أكبر جذر', CsCID FROM #PC ORDER BY Cur DESC;
INSERT @Pick SELECT TOP (1) N'أكبر مشروع مباشر', CsCID FROM #PK ORDER BY Amount DESC;
INSERT @Pick
SELECT TOP (1) N'مشروع أب وسطي', c.CsCID
FROM dbo.Acc_CostCenter AS c
WHERE c.CsCCompany = @Cmp AND c.CsCLevel = 3
  AND EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS k WHERE k.CsCParentID = c.CsCID)
ORDER BY c.CsCCode;

DECLARE @Tag NVARCHAR(30), @Id BIGINT, @Exp DECIMAL(28,3), @Got DECIMAL(28,3), @GotPrev DECIMAL(28,3), @ExpPrev DECIMAL(28,3);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT Tag, CsCID FROM @Pick;
OPEN c; FETCH NEXT FROM c INTO @Tag, @Id;
WHILE @@FETCH_STATUS = 0
BEGIN
    ;WITH Down AS
    (
        SELECT CsCID FROM dbo.Acc_CostCenter WHERE CsCID = @Id
        UNION ALL
        SELECT k.CsCID FROM dbo.Acc_CostCenter AS k JOIN Down AS d ON k.CsCParentID = d.CsCID
    )
    SELECT
        @Exp = ISNULL(SUM(CASE WHEN m.DayMDate BETWEEN @YStart AND @AsOf THEN dd.DayDDeb - dd.DayDCrd END), 0),
        @ExpPrev = ISNULL(SUM(CASE WHEN m.DayMDate BETWEEN DATEADD(YEAR, -1, @YStart) AND @PAsOf THEN dd.DayDDeb - dd.DayDCrd END), 0)
    FROM dbo.Acc_DayMaster AS m
    JOIN dbo.Acc_DayDetails AS dd ON dd.DayDMID = m.DayMID
    JOIN dbo.Acc_Account AS a ON a.AccID = dd.DayDAccID
    WHERE m.DayMCompany = @Cmp AND m.DayMState BETWEEN 1 AND 7
      AND a.AccEnd = 2 AND a.AccType = 1
      AND dd.DayDCsCID IN (SELECT CsCID FROM Down)
    OPTION (MAXRECURSION 200);

    TRUNCATE TABLE #PS;
    INSERT #PS EXEC dbo.Acc_SelectDashboardProject @Cmp = @Cmp, @Year = @Year, @CsCID = @Id, @Part = 1;
    SELECT @Got = ProjExp, @GotPrev = ProjExpPrev FROM #PS;

    INSERT @T VALUES (N'P4 مطابقة مستقلة (' + @Tag + N' رقم ' + CONVERT(NVARCHAR(20), @Id) + N'): '
                      + CONVERT(NVARCHAR(30), @Got) + N' / السابق ' + CONVERT(NVARCHAR(30), @GotPrev),
                      CASE WHEN ABS(@Got - @Exp) <= @tol AND ABS(@GotPrev - @ExpPrev) <= @tol THEN 1 ELSE 0 END);
    FETCH NEXT FROM c INTO @Tag, @Id;
END;
CLOSE c; DEALLOCATE c;

/* ---------- الطباعة ---------- */
DECLARE @N NVARCHAR(300), @O BIT;
DECLARE r CURSOR LOCAL FAST_FORWARD FOR SELECT Name, Ok FROM @T;
OPEN r; FETCH NEXT FROM r INTO @N, @O;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF @O = 1 BEGIN SET @Pass += 1; PRINT N'PASS - ' + @N; END
    ELSE      BEGIN SET @Fail += 1; PRINT N'FAIL - ' + @N; END;
    FETCH NEXT FROM r INTO @N, @O;
END;
CLOSE r; DEALLOCATE r;

PRINT N'الإجمالي: ' + CONVERT(NVARCHAR(10), @Pass + @Fail) + N' فحص | نجح: ' + CONVERT(NVARCHAR(10), @Pass)
      + N' | فشل: ' + CONVERT(NVARCHAR(10), @Fail);

/* معلومات للمراجعة (ليست اختبارات) */
SELECT AsOf, PAsOf, Revenue, Expenses, NetResult, PRevenue, PExpenses,
       CashBalance, CashIn, CashOut, Assets, Liabilities, Equity, CumResult,
       BalanceDiff AS [فرق معادلة الميزانية (يُتوقع قيمة الفقد المعروفة من الترحيل)]
FROM #K;

DROP TABLE #K, #Mo, #RS, #ES, #IS, #PS, #PM, #PK, #PC;
GO

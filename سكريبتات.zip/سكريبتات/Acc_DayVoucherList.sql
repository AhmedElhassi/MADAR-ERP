﻿/* =====================================================================
   قوائم القيود حسب الحالة (صفحة واحدة Acc_DayReviewList.aspx?State=n)
   ---------------------------------------------------------------------
   يتطلب تنفيذ Acc_ChangeDayVoucherState.sql أولًا (Acc_StateMenu و Acc_UserCanAct و Acc_VoucherFlow).

   Acc_SelectDayVouchersByState(@Cmp, @Year, @User, @State, ...)
     - الحالة لا تُصدَّق من الرابط: يتحقق الإجراء أن المستخدم يملك قائمة هذه الحالة.
     - المسودات (0) لا يراها إلا صاحبها. القيود التي لسنة @Year فقط.
     - الأعلام: CanAccept / CanReject (يوجد مسار للحالة، ومن أنشأ القيد ممنوع عليه
       إن كان فصل المهام مفعّلًا)، CanEdit (الحالتان 0 و2)، CanPrint.
     - الترقيم: @PageSize = 0 يعيد الكل؛ وإلا الصفحة @PageNo، و TotalRows الإجمالي.
   Acc_SelectDayVoucherLines(@Cmp, @User, @DayMID)   بنود قيد واحد لصف التفاصيل.

   الأخطاء: 50401 حالة غير صحيحة   50402 لا يملك قائمة الحالة   50403 قائمة الحالة غير معرّفة
            50301 القيد غير موجود/ليس للشركة (أو مسودة غيره)
   نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SelectDayVouchersByState
    @Cmp      INT,
    @Year     INT,
    @User     BIGINT,
    @State    TINYINT,
    @FromDate DATE          = NULL,
    @ToDate   DATE          = NULL,
    @Search   NVARCHAR(100) = NULL,
    @PageNo   INT           = 1,
    @PageSize INT           = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF @State > 7
        THROW 50401, N'حالة القيد غير صحيحة.', 1;

    DECLARE @Mapped BIT, @Allowed BIT;
    SELECT @Mapped = u.Mapped, @Allowed = u.Allowed FROM dbo.Acc_UserCanAct(@Cmp, @User, @State) AS u;
    IF ISNULL(@Mapped, 0) = 0
        THROW 50403, N'لم تُعرَّف قائمة هذه الحالة في جدول Acc_StateMenu.', 1;
    IF ISNULL(@Allowed, 0) = 0
        THROW 50402, N'لا تملك صلاحية عرض القيود في هذه الحالة.', 1;

    IF ISNULL(@PageNo, 1) < 1 SET @PageNo = 1;
    IF ISNULL(@PageSize, 0) < 0 SET @PageSize = 0;

    DECLARE @Sep BIT = CAST(ISNULL((SELECT MAX(CAST(AccSSeparateDuties AS INT))
                                    FROM dbo.Acc_CompanySettings WHERE AccSCmpID = @Cmp), 1) AS BIT);
    DECLARE @YS DATE = DATEFROMPARTS(@Year, 1, 1), @YE DATE = DATEFROMPARTS(@Year + 1, 1, 1);

    DECLARE @Off INT = CASE WHEN @PageSize = 0 THEN 0 ELSE (@PageNo - 1) * @PageSize END;
    DECLARE @Fetch INT = CASE WHEN @PageSize = 0 THEN 2147483647 ELSE @PageSize END;

    DECLARE @S NVARCHAR(100) = NULLIF(LTRIM(RTRIM(@Search)), N'');
    DECLARE @Pat NVARCHAR(220) = CASE WHEN @S IS NULL THEN NULL
        ELSE N'%' + REPLACE(REPLACE(REPLACE(REPLACE(@S, N'\', N'\\'), N'%', N'\%'), N'_', N'\_'), N'[', N'\[') + N'%' END;

    SELECT m.DayMID,
           m.DayMNo,
           CASE WHEN m.DayMNo > 0
                THEN CONCAT(m.DayMNo, N'/', RIGHT(CONCAT(N'0', MONTH(m.DayMDate)), 2))
                ELSE N'' END                                   AS VoucherNo,
           m.DayMDate,
           m.DayMDescription,
           m.DayMState,
           CASE m.DayMState
                WHEN 0 THEN N'مؤقت'
                WHEN 1 THEN N'مُرحّل'
                WHEN 2 THEN N'مُعاد من المراجعة للمحاسب'
                WHEN 3 THEN N'تم اعتماد المراجعة'
                WHEN 4 THEN N'مُعاد من المدير المالي للمراجعة'
                WHEN 5 THEN N'مُعتمد من المدير المالي'
                WHEN 6 THEN N'مُعاد من الأرشيف للمدير المالي'
                WHEN 7 THEN N'مُؤرشف'
           END                                                 AS StateName,
           CAST(ISNULL(t.Deb, 0) AS DECIMAL(38,3))             AS TotalDebit,
           CAST(ISNULL(t.Crd, 0) AS DECIMAL(38,3))             AS TotalCredit,
           CAST(ISNULL(t.Cnt, 0) AS INT)                       AS LinesCount,
           CAST(CASE WHEN ISNULL(t.Cnt, 0) >= 2 AND ISNULL(t.Deb, 0) = ISNULL(t.Crd, 0) AND ISNULL(t.Deb, 0) > 0
                     THEN 1 ELSE 0 END AS BIT)                 AS IsBalanced,
           m.DayMUser,
           m.DayMDateTime,
           f.AcceptState,
           f.RejectState,
           CAST(CASE WHEN f.ActStage IS NOT NULL AND (@Sep = 0 OR m.DayMUser <> @User) THEN 1 ELSE 0 END AS BIT) AS CanAccept,
           CAST(CASE WHEN f.ActStage IS NOT NULL AND (@Sep = 0 OR m.DayMUser <> @User) THEN 1 ELSE 0 END AS BIT) AS CanReject,
           CAST(CASE WHEN m.DayMState IN (0, 2) THEN 1 ELSE 0 END AS BIT) AS CanEdit,
           CAST(1 AS BIT)                                       AS CanPrint,
           CAST(COUNT(*) OVER () AS INT)                        AS TotalRows
    FROM dbo.Acc_DayMaster AS m
    OUTER APPLY (SELECT SUM(d.DayDDeb) AS Deb, SUM(d.DayDCrd) AS Crd, COUNT(*) AS Cnt
                 FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS t
    OUTER APPLY dbo.Acc_VoucherFlow(m.DayMCompany, m.DayMState) AS f
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState   = @State
      AND m.DayMDate >= @YS AND m.DayMDate < @YE
      AND (@FromDate IS NULL OR m.DayMDate >= @FromDate)
      AND (@ToDate   IS NULL OR m.DayMDate <= @ToDate)
      AND (@State <> 0 OR m.DayMUser = @User)
      AND (@Pat IS NULL
           OR m.DayMDescription LIKE @Pat ESCAPE N'\'
           OR CONVERT(NVARCHAR(20), m.DayMNo) LIKE @Pat ESCAPE N'\')
    ORDER BY m.DayMDate DESC, m.DayMNo DESC, m.DayMID DESC
    OFFSET @Off ROWS FETCH NEXT @Fetch ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SelectDayVoucherLines
    @Cmp    INT,
    @User   BIGINT,
    @DayMID BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @St TINYINT, @Owner BIGINT;
    SELECT @St = m.DayMState, @Owner = m.DayMUser
    FROM dbo.Acc_DayMaster AS m
    WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

    IF @St IS NULL OR (@St = 0 AND @Owner <> @User)
        THROW 50301, N'القيد غير موجود أو لا يتبع الشركة.', 1;

    DECLARE @Mapped BIT, @Allowed BIT;
    SELECT @Mapped = u.Mapped, @Allowed = u.Allowed FROM dbo.Acc_UserCanAct(@Cmp, @User, @St) AS u;
    IF ISNULL(@Mapped, 0) = 0
        THROW 50403, N'لم تُعرَّف قائمة حالة هذا القيد في جدول Acc_StateMenu.', 1;
    IF ISNULL(@Allowed, 0) = 0
        THROW 50402, N'لا تملك صلاحية عرض القيود في هذه الحالة.', 1;

    SELECT d.DayDID, d.DayDAccID, a.AccCode, a.AccName,
           d.DayDDeb, d.DayDCrd,
           d.DayDCsCID, c.CsCCode, c.CsCName,
           d.DayDNum, d.DayDDescription
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
    LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DayDCsCID
    WHERE d.DayDMID = @DayMID
    ORDER BY d.DayDID;
END;
GO

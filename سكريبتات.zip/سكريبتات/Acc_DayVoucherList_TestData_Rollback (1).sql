﻿/* اختبار قوائم القيود حسب الحالة — يتراجع عن كل شيء في النهاية (ROLLBACK).
   النتيجة: أسطر PASS/FAIL في تبويب Messages. */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Acc_SelectDayVouchersByState') IS NULL OR OBJECT_ID(N'dbo.Acc_SelectDayVoucherLines') IS NULL
   OR OBJECT_ID(N'dbo.Acc_UserCanAct') IS NULL OR OBJECT_ID(N'dbo.Acc_StateMenu', N'U') IS NULL
    THROW 50900, N'نفّذ Acc_ChangeDayVoucherState.sql ثم Acc_DayVoucherList.sql أولًا.', 1;

DECLARE @Cmp INT = 10, @Year INT = 2026, @U1 BIGINT = 1, @U2 BIGINT;
SELECT TOP (1) @U2 = UsrID FROM dbo.Mng_User WHERE UsrID <> @U1 ORDER BY UsrID;
IF @U2 IS NULL THROW 50901, N'يلزم مستخدم ثانٍ في Mng_User لهذا الاختبار.', 1;

DECLARE @R TABLE (Name NVARCHAR(300), Ok BIT);
DECLARE @Err INT;

BEGIN TRAN;

/* ---------- الإعدادات والصلاحيات ---------- */
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE AccSCmpID = @Cmp) INSERT dbo.Acc_CompanySettings (AccSCmpID) VALUES (@Cmp);
UPDATE dbo.Acc_CompanySettings SET AccSReview = 1, AccSApproval = 1, AccSArchive = 1, AccSSeparateDuties = 1 WHERE AccSCmpID = @Cmp;

DELETE dbo.Acc_StateMenu;
INSERT dbo.Acc_StateMenu (State, SystemID, MenuID)
VALUES (0,1,100),(1,1,101),(2,1,102),(3,1,103),(4,1,104),(5,1,105),(6,1,106),(7,1,107);

DELETE dbo.Mng_UserParmations WHERE USPUserID IN (@U1, @U2) AND USPCompanyID = @Cmp AND USPSystemID = 1;
INSERT dbo.Mng_UserParmations (USPUserID, USPCompanyID, USPSystemID, USPParmations, USPState, USPUser)
VALUES (@U1, @Cmp, 1, N'100,101,102,103,104,105,106,107', 0, @U1),
       (@U2, @Cmp, 1, N'100, 101 ,103', 0, @U1);          -- الثاني: الحالات 0 و1 و3 فقط

/* ---------- حسابات للبنود ---------- */
DECLARE @A1 BIGINT, @A2 BIGINT;
SELECT TOP (1) @A1 = a.AccID FROM dbo.Acc_Account a
 WHERE a.AccCompany = @Cmp AND a.AccEnd = 1 AND a.AccType = 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account c WHERE c.AccParentID = a.AccID) ORDER BY a.AccCode;
SELECT TOP (1) @A2 = a.AccID FROM dbo.Acc_Account a
 WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 1 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account c WHERE c.AccParentID = a.AccID) ORDER BY a.AccCode;
IF @A1 IS NULL OR @A2 IS NULL THROW 50902, N'تعذّر اختيار حسابات للاختبار.', 1;

/* ---------- قيود الاختبار: واحد لكل حالة (لصاحبه U1) + قيد للمستخدم الثاني + قيد قديم ---------- */
DECLARE @V TABLE (Tag NVARCHAR(20), ID BIGINT);
DECLARE @tags TABLE (Tag NVARCHAR(20), St TINYINT, Usr BIGINT, Dt DATE);
INSERT @tags VALUES (N's0',0,@U1,'2026-03-01'),(N's0b',0,@U2,'2026-03-01'),(N's1',1,@U1,'2026-03-02'),(N's1b',1,@U2,'2026-03-03'),
  (N's2',2,@U1,'2026-03-04'),(N's3',3,@U1,'2026-03-05'),(N's4',4,@U1,'2026-03-06'),(N's5',5,@U1,'2026-03-07'),
  (N's6',6,@U1,'2026-03-08'),(N's7',7,@U1,'2026-03-09'),(N'old',1,@U1,'2025-05-01');
DECLARE @tg NVARCHAR(20), @st TINYINT, @us BIGINT, @dt DATE, @n INT = 0, @mid BIGINT;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT Tag, St, Usr, Dt FROM @tags;
OPEN c; FETCH NEXT FROM c INTO @tg, @st, @us, @dt;
WHILE @@FETCH_STATUS = 0
BEGIN
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES (@dt, N'LT-' + @tg, 995000 + @n, @st, @us, @Cmp);
    SET @mid = SCOPE_IDENTITY();
    INSERT @V VALUES (@tg, @mid);
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDNum, DayDDescription)
    VALUES (@mid, @A1, 500, 0, N'D1', N'بند مدين'), (@mid, @A2, 0, 500, N'D2', N'بند دائن');
    SET @n += 1;
    FETCH NEXT FROM c INTO @tg, @st, @us, @dt;
END;
CLOSE c; DEALLOCATE c;

CREATE TABLE #L (DayMID BIGINT, DayMNo INT, VoucherNo NVARCHAR(50), DayMDate DATE, DayMDescription NVARCHAR(MAX),
    DayMState TINYINT, StateName NVARCHAR(60), TotalDebit DECIMAL(38,3), TotalCredit DECIMAL(38,3), LinesCount INT, IsBalanced BIT,
    DayMUser BIGINT, DayMDateTime DATETIME2(0), AcceptState TINYINT, RejectState TINYINT,
    CanAccept BIT, CanReject BIT, CanEdit BIT, CanPrint BIT, TotalRows INT);

/* L1: كل حالة تعيد قيدها (U1 يملك كل القوائم) مع اسم الحالة */
DECLARE @bad INT = 0, @k INT = 0;
WHILE @k <= 7
BEGIN
    TRUNCATE TABLE #L;
    INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = @k, @Search = N'LT-';
    IF NOT EXISTS (SELECT 1 FROM #L l JOIN @V v ON v.ID = l.DayMID WHERE l.DayMState = @k AND l.StateName IS NOT NULL AND v.Tag = N's' + CONVERT(NVARCHAR(2), @k))
        SET @bad += 1;
    IF EXISTS (SELECT 1 FROM #L WHERE DayMState <> @k) SET @bad += 1;
    SET @k += 1;
END;
INSERT @R VALUES (N'L1 كل حالة 0–7 تعيد قيدها وحدها مع اسم الحالة', CASE WHEN @bad = 0 THEN 1 ELSE 0 END);

/* L2: المسودات خاصة بصاحبها */
TRUNCATE TABLE #L;
INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U2, @State = 0, @Search = N'LT-';
INSERT @R VALUES (N'L2 المستخدم الثاني يرى مسودته فقط (s0b) ولا يرى مسودة الأول',
   CASE WHEN (SELECT COUNT(*) FROM #L) = 1 AND EXISTS (SELECT 1 FROM #L l JOIN @V v ON v.ID = l.DayMID WHERE v.Tag = N's0b') THEN 1 ELSE 0 END);

/* L3: الأعلام للمستخدم الثاني على قيد الأول (الحالة 1): يقبل ويرفض، 1→(3,2) */
TRUNCATE TABLE #L;
INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U2, @State = 1, @Search = N'LT-';
INSERT @R VALUES (N'L3 قيد الغير في الحالة 1: CanAccept/CanReject=1 والمسار (3,2)',
   CASE WHEN EXISTS (SELECT 1 FROM #L l JOIN @V v ON v.ID = l.DayMID
                     WHERE v.Tag = N's1' AND l.CanAccept = 1 AND l.CanReject = 1 AND l.AcceptState = 3 AND l.RejectState = 2 AND l.CanEdit = 0 AND l.CanPrint = 1) THEN 1 ELSE 0 END);
INSERT @R VALUES (N'L4 قيده هو نفسه: CanAccept/CanReject=0 (فصل المهام)',
   CASE WHEN EXISTS (SELECT 1 FROM #L l JOIN @V v ON v.ID = l.DayMID WHERE v.Tag = N's1b' AND l.CanAccept = 0 AND l.CanReject = 0) THEN 1 ELSE 0 END);

/* L5: الإجماليات والتوازن */
INSERT @R VALUES (N'L5 إجمالي المدين والدائن 500 وعدد البنود 2 ومتوازن',
   CASE WHEN EXISTS (SELECT 1 FROM #L l JOIN @V v ON v.ID = l.DayMID
                     WHERE v.Tag = N's1' AND l.TotalDebit = 500 AND l.TotalCredit = 500 AND l.LinesCount = 2 AND l.IsBalanced = 1) THEN 1 ELSE 0 END);

/* L6: الحالة 7 لا إجراء، 5 → (7,6)، 2 و0 للتعديل */
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = 7, @Search = N'LT-';
DECLARE @ok7 BIT = CASE WHEN EXISTS (SELECT 1 FROM #L WHERE CanAccept = 0 AND CanReject = 0 AND AcceptState IS NULL) THEN 1 ELSE 0 END;
INSERT @R VALUES (N'L6 القيد المؤرشف (7): لا قبول ولا رفض', @ok7);

/* U1 مالك قيود الاختبار؛ نستعمل U2 مع قوائم إضافية داخل المعاملة لقراءة 5 و2 */
UPDATE dbo.Mng_UserParmations SET USPParmations = N'100,101,102,103,104,105,106,107' WHERE USPUserID = @U2 AND USPCompanyID = @Cmp AND USPSystemID = 1;
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U2, @State = 5, @Search = N'LT-';
INSERT @R VALUES (N'L7 الحالة 5 → (7,6) والقبول متاح لغير المنشئ',
   CASE WHEN EXISTS (SELECT 1 FROM #L WHERE AcceptState = 7 AND RejectState = 6 AND CanAccept = 1) THEN 1 ELSE 0 END);
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U2, @State = 2, @Search = N'LT-';
INSERT @R VALUES (N'L8 الحالة 2: CanEdit=1 ولا قبول ولا رفض',
   CASE WHEN EXISTS (SELECT 1 FROM #L WHERE CanEdit = 1 AND CanAccept = 0 AND CanReject = 0) THEN 1 ELSE 0 END);
UPDATE dbo.Mng_UserParmations SET USPParmations = N'100, 101 ,103' WHERE USPUserID = @U2 AND USPCompanyID = @Cmp AND USPSystemID = 1;

/* L9: السنة */
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = 1, @Search = N'LT-';
DECLARE @in2026 INT = (SELECT COUNT(*) FROM #L WHERE DayMDescription = N'LT-old');
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = 2025, @User = @U1, @State = 1, @Search = N'LT-';
INSERT @R VALUES (N'L9 القيد القديم (2025) لا يظهر في 2026 ويظهر في 2025',
   CASE WHEN @in2026 = 0 AND EXISTS (SELECT 1 FROM #L WHERE DayMDescription = N'LT-old') THEN 1 ELSE 0 END);

/* L10: الترقيم */
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = 1, @Search = N'LT-s1', @PageNo = 2, @PageSize = 1;
INSERT @R VALUES (N'L10 الترقيم: الصفحة 2 بحجم 1 تعيد صفًا واحدًا والإجمالي 2',
   CASE WHEN (SELECT COUNT(*) FROM #L) = 1 AND (SELECT MAX(TotalRows) FROM #L) = 2 THEN 1 ELSE 0 END);

/* L11: البحث بحروف خاصة لا يكسر ولا يطابق الكل */
TRUNCATE TABLE #L; INSERT #L EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = 1, @Search = N'LT-%';
INSERT @R VALUES (N'L11 البحث بالرمز % يُعامل حرفيًا (LT-% لا يطابق شيئًا)', CASE WHEN (SELECT COUNT(*) FROM #L) = 0 THEN 1 ELSE 0 END);

/* L12: الأخطاء */
SET @Err = 0; BEGIN TRY EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = 9; END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'L12 حالة 9: 50401', CASE WHEN @Err = 50401 THEN 1 ELSE 0 END);
SET @Err = 0; BEGIN TRY EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U2, @State = 5; END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'L13 مستخدم بلا قائمة الحالة 5: 50402', CASE WHEN @Err = 50402 THEN 1 ELSE 0 END);
DELETE dbo.Acc_StateMenu WHERE State = 6;
SET @Err = 0; BEGIN TRY EXEC dbo.Acc_SelectDayVouchersByState @Cmp = @Cmp, @Year = @Year, @User = @U1, @State = 6; END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'L14 حالة بلا قائمة معرّفة: 50403', CASE WHEN @Err = 50403 THEN 1 ELSE 0 END);
INSERT dbo.Acc_StateMenu (State, SystemID, MenuID) VALUES (6, 1, 106);

/* ---------- بنود القيد ---------- */
CREATE TABLE #D (DayDID BIGINT, DayDAccID BIGINT, AccCode NVARCHAR(60), AccName NVARCHAR(500), DayDDeb DECIMAL(15,3), DayDCrd DECIMAL(15,3),
                 DayDCsCID BIGINT, CsCCode NVARCHAR(60), CsCName NVARCHAR(500), DayDNum NVARCHAR(50), DayDDescription NVARCHAR(MAX));
DECLARE @id BIGINT;
SELECT @id = ID FROM @V WHERE Tag = N's1';
INSERT #D EXEC dbo.Acc_SelectDayVoucherLines @Cmp = @Cmp, @User = @U2, @DayMID = @id;
INSERT @R VALUES (N'D1 بنود القيد: بندان باسم الحساب ورمزه والمجموع 500', 
   CASE WHEN (SELECT COUNT(*) FROM #D) = 2 AND NOT EXISTS (SELECT 1 FROM #D WHERE AccName IS NULL OR AccCode IS NULL)
         AND (SELECT SUM(DayDDeb) FROM #D) = 500 AND (SELECT SUM(DayDCrd) FROM #D) = 500 THEN 1 ELSE 0 END);

SELECT @id = ID FROM @V WHERE Tag = N's5';
SET @Err = 0; BEGIN TRY EXEC dbo.Acc_SelectDayVoucherLines @Cmp = @Cmp, @User = @U2, @DayMID = @id; END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'D2 بنود قيد في حالة لا يملك قائمتها: 50402', CASE WHEN @Err = 50402 THEN 1 ELSE 0 END);

SELECT @id = ID FROM @V WHERE Tag = N's0';
SET @Err = 0; BEGIN TRY EXEC dbo.Acc_SelectDayVoucherLines @Cmp = @Cmp, @User = @U2, @DayMID = @id; END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'D3 بنود مسودة الغير: 50301', CASE WHEN @Err = 50301 THEN 1 ELSE 0 END);

SELECT @id = ID FROM @V WHERE Tag = N's1';
SET @Err = 0; BEGIN TRY EXEC dbo.Acc_SelectDayVoucherLines @Cmp = 99999, @User = @U2, @DayMID = @id; END TRY BEGIN CATCH SET @Err = ERROR_NUMBER(); END CATCH;
INSERT @R VALUES (N'D4 شركة أخرى لا تصل للبنود: 50301', CASE WHEN @Err = 50301 THEN 1 ELSE 0 END);

ROLLBACK;

DECLARE @p INT = 0, @f INT = 0, @nm NVARCHAR(300), @ok BIT;
DECLARE r CURSOR LOCAL FAST_FORWARD FOR SELECT Name, Ok FROM @R;
OPEN r; FETCH NEXT FROM r INTO @nm, @ok;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF @ok = 1 BEGIN SET @p += 1; PRINT N'PASS - ' + @nm; END ELSE BEGIN SET @f += 1; PRINT N'FAIL - ' + @nm; END;
    FETCH NEXT FROM r INTO @nm, @ok;
END;
CLOSE r; DEALLOCATE r;
PRINT N'الإجمالي: ' + CONVERT(NVARCHAR(10), @p + @f) + N' اختبار | نجح: ' + CONVERT(NVARCHAR(10), @p) + N' | فشل: ' + CONVERT(NVARCHAR(10), @f);
IF @@TRANCOUNT > 0 ROLLBACK;
GO

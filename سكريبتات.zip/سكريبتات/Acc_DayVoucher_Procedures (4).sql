﻿/* =====================================================================
   قيد اليومية: إجراءات الحفظ المؤقت والنهائي وفتح القيد والحذف والنسخ
   ---------------------------------------------------------------------
   حالات DayMState:
     0 مؤقت (بلا رقم قيد)      1 مُرحّل (الحفظ النهائي)   2 مُعاد من المراجعة للمحاسب
     3 اعتُمدت المراجعة         4 مُعاد من المدير المالي    5 مُعتمد من المدير المالي
     6 مُعاد من الأرشيف         7 مُؤرشف
   قواعد هذه الإجراءات:
     - الحفظ يتم في معاملة واحدة: الرأس + كل البنود (استبدال كامل للبنود).
     - الحفظ المؤقت يقبل قيدًا غير متوازن، ولا يعطيه رقمًا (DayMNo = 0).
     - الحفظ النهائي يرفض القيد غير المتوازن أو الأقل من بندين، ثم يضعه في الحالة 1
       ويعطيه رقمًا = أكبر رقم في الشهر نفسه للشركة + 1 (الترقيم يبدأ من 1 كل شهر).
     - لا يُعدَّل القيد إلا في الحالتين 0 و2. ولا يُحذف إلا في الحالة 0.
     - القيد على الحسابات التحليلية فقط، التابعة للشركة، والمصنفة ماليًا تصنيفًا صحيحًا.
   نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF TYPE_ID(N'dbo.Acc_DayLineType') IS NULL
    CREATE TYPE dbo.Acc_DayLineType AS TABLE
    (
        SeqNo           INT            NOT NULL PRIMARY KEY,   -- ترتيب البند في الشاشة
        DayDAccID       BIGINT         NOT NULL,
        DayDDeb         DECIMAL(15,3)  NOT NULL,
        DayDCrd         DECIMAL(15,3)  NOT NULL,
        DayDCsCID       BIGINT         NULL,
        DayDNum         NVARCHAR(50)   NULL,
        DayDDescription NVARCHAR(MAX)  NULL
    );
GO

/* =====================================================================
   1) حفظ القيد (مؤقت أو نهائي)
      يعيد صفًا واحدًا: DayMID, DayMNo, DayMState, VoucherNo
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_SaveDayVoucher
    @Cmp    INT,
    @Year   INT,
    @User   BIGINT,
    @DayMID BIGINT = 0,              -- 0 = قيد جديد
    @Date   DATE,
    @Info   NVARCHAR(MAX),
    @Post   BIT = 0,                 -- 0 = حفظ مؤقت ، 1 = حفظ نهائي
    @Lines  dbo.Acc_DayLineType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;      -- نستخدم نقطة حفظ عند وجود معاملة خارجية

    DECLARE @Cnt INT, @Deb DECIMAL(18,3), @Crd DECIMAL(18,3), @Msg NVARCHAR(400);

    SELECT @Cnt = COUNT(*),
           @Deb = ISNULL(SUM(DayDDeb), 0),
           @Crd = ISNULL(SUM(DayDCrd), 0)
    FROM @Lines;

    /* ---------- التحقق (قبل أي كتابة) ---------- */
    IF @Date IS NULL OR @Year IS NULL OR YEAR(@Date) <> @Year
        THROW 50101, N'تاريخ القيد يجب أن يقع داخل السنة المالية المحددة.', 1;

    IF NULLIF(LTRIM(RTRIM(ISNULL(@Info, N''))), N'') IS NULL
        THROW 50102, N'شرح القيد مطلوب.', 1;

    IF @Cnt = 0
        THROW 50103, N'أضف بندًا واحدًا على الأقل قبل الحفظ.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 50112, N'المستخدم غير موجود.', 1;

    IF EXISTS (SELECT 1 FROM @Lines
               WHERE DayDDeb < 0 OR DayDCrd < 0
                  OR (DayDDeb = 0 AND DayDCrd = 0)
                  OR (DayDDeb > 0 AND DayDCrd > 0))
        THROW 50106, N'يوجد بند قيمته غير صحيحة: مدين أو دائن فقط، وأكبر من صفر.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS a
                                 WHERE a.AccID = l.DayDAccID AND a.AccCompany = @Cmp))
        THROW 50104, N'يوجد بند على حساب غير موجود أو لا يتبع الشركة.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = l.DayDAccID))
        THROW 50105, N'لا يجوز القيد على حساب أب، اختر حسابًا تحليليًا.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
               WHERE NOT (   (a.AccEnd = 1 AND a.AccType IN (0, 1, 2))
                          OR (a.AccEnd = 2 AND a.AccType IN (0, 1))))
        THROW 50108, N'يوجد بند على حساب تصنيفه المالي غير صحيح (AccEnd / AccType).', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE l.DayDCsCID IS NOT NULL
                 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS c
                                 WHERE c.CsCID = l.DayDCsCID AND c.CsCCompany = @Cmp))
        THROW 50109, N'يوجد بند على مركز تكلفة غير موجود أو لا يتبع الشركة.', 1;

    /* حسابات النظام (توجيهات حسابية): لا يجوز القيد اليدوي عليها إلا من إجراء النظام.
       علامة النظام: sp_set_session_context 'Acc.SystemOperation' = 1 */
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Acc.SystemOperation')), 0) <> 1
       AND EXISTS (SELECT 1
                   FROM @Lines AS l
                   JOIN dbo.Acc_PostingRule  AS r ON r.AccID = l.DayDAccID
                   JOIN dbo.Acc_PostingState AS s ON s.StateID = r.StateID
                   WHERE s.AllowManualPosting = 0)
        THROW 50114, N'يوجد بند على حساب نظام لا يقبل القيد اليدوي (مثل حسابات الموردين والزبائن). يُرحَّل عليه من العملية الخاصة به فقط.', 1;

    IF @Post = 1
    BEGIN
        IF @Cnt < 2
            THROW 50107, N'القيد النهائي يحتاج بندين على الأقل.', 1;

        IF @Deb <> @Crd
        BEGIN
            SET @Msg = CONCAT(N'لا يمكن الحفظ النهائي لقيد غير متوازن. الفرق: ',
                              CONVERT(NVARCHAR(40), @Deb - @Crd));
            THROW 50111, @Msg, 1;
        END;
    END;

    /* ---------- الكتابة ---------- */
    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_SaveDayVoucher;

    BEGIN TRY
        DECLARE @OldDate DATE, @OldState TINYINT, @OldNo INT, @No INT, @State TINYINT;

        IF @DayMID > 0
        BEGIN
            SELECT @OldDate = m.DayMDate, @OldState = m.DayMState, @OldNo = m.DayMNo
            FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
            WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

            IF @OldState IS NULL
                THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;

            IF @OldState NOT IN (0, 2)
                THROW 50121, N'لا يمكن تعديل القيد في حالته الحالية (يُعدَّل المؤقت والمُعاد من المراجعة فقط).', 1;
        END;

        DECLARE @MS DATE = DATEFROMPARTS(YEAR(@Date), MONTH(@Date), 1);
        DECLARE @ME DATE = DATEADD(MONTH, 1, @MS);

        SET @No = ISNULL(@OldNo, 0);
        SET @State = CASE WHEN @Post = 1 THEN CAST(1 AS TINYINT) ELSE ISNULL(@OldState, CAST(0 AS TINYINT)) END;

        DECLARE @MonthChanged BIT =
            CASE WHEN @OldDate IS NOT NULL
                  AND DATEFROMPARTS(YEAR(@OldDate), MONTH(@OldDate), 1) <> @MS THEN 1 ELSE 0 END;

        IF @Post = 1 AND (@No = 0 OR @MonthChanged = 1)
        BEGIN
            -- رقم القيد = أكبر رقم في الشهر نفسه للشركة + 1 (القفل يمنع تكرار الرقم عند الحفظ المتزامن)
            SELECT @No = ISNULL(MAX(m.DayMNo), 0) + 1
            FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
            WHERE m.DayMCompany = @Cmp AND m.DayMDate >= @MS AND m.DayMDate < @ME;
        END
        ELSE IF @Post = 0 AND @No > 0 AND @MonthChanged = 1
            SET @No = 0;     -- رقم الشهر القديم لا يصلح للشهر الجديد؛ يُعاد توليده عند الترحيل

        IF @DayMID = 0
        BEGIN
            INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
            VALUES (@Date, @Info, @No, @State, @User, @Cmp);

            SET @DayMID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE dbo.Acc_DayMaster
            SET DayMDate = @Date, DayMDescription = @Info, DayMNo = @No, DayMState = @State
            WHERE DayMID = @DayMID AND DayMCompany = @Cmp;

            DELETE dbo.Acc_DayDetails WHERE DayDMID = @DayMID;
        END;

        INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDCsCID, DayDNum, DayDDescription)
        SELECT @DayMID, l.DayDAccID, l.DayDDeb, l.DayDCrd, l.DayDCsCID, l.DayDNum, l.DayDDescription
        FROM @Lines AS l
        ORDER BY l.SeqNo;

        -- فحص أخير من الجدول نفسه: لا يُرحَّل قيد غير متوازن مهما حدث
        IF @Post = 1
        BEGIN
            IF (SELECT SUM(DayDDeb) - SUM(DayDCrd) FROM dbo.Acc_DayDetails WHERE DayDMID = @DayMID) <> 0
                THROW 50113, N'القيد غير متوازن بعد الحفظ؛ أُلغي الترحيل.', 1;
        END;

        IF @Started = 1 COMMIT;

        SELECT @DayMID AS DayMID,
               @No     AS DayMNo,
               @State  AS DayMState,
               CASE WHEN @No > 0
                    THEN CONCAT(@No, N'/', RIGHT(CONCAT(N'0', MONTH(@Date)), 2))
                    ELSE N'' END AS VoucherNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_SaveDayVoucher;

        THROW;
    END CATCH;
END;
GO

/* =====================================================================
   2) فتح قيد: نتيجتان
      الأولى: رأس القيد   الثانية: البنود (مع اسم الحساب ومركز التكلفة)
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_SelectDayEntry
    @Cmp    INT,
    @DayMID BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @DayMID AND DayMCompany = @Cmp)
        THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;

    SELECT m.DayMID,
           m.DayMNo,
           CASE WHEN m.DayMNo > 0
                THEN CONCAT(m.DayMNo, N'/', RIGHT(CONCAT(N'0', MONTH(m.DayMDate)), 2))
                ELSE N'' END AS VoucherNo,
           m.DayMDate,
           m.DayMDescription,
           m.DayMState,
           CASE m.DayMState
                WHEN 0 THEN N'مؤقت'
                WHEN 1 THEN N'مُرحّل'
                WHEN 2 THEN N'مُعاد من المراجعة للمحاسب'
                WHEN 3 THEN N'تم اعتماد المراجعة'
                WHEN 4 THEN N'مُعاد من المدير المالي للمراجعة'
                WHEN 5 THEN N'مُعتمد من المدير المالي'
                WHEN 6 THEN N'مُعاد من الأرشيف للمدير المالي'
                WHEN 7 THEN N'مُؤرشف'
           END AS StateName,
           CAST(CASE WHEN m.DayMState IN (0, 2) THEN 1 ELSE 0 END AS BIT) AS IsEditable,
           (SELECT ISNULL(SUM(d.DayDDeb), 0) FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS TotalDebit,
           (SELECT ISNULL(SUM(d.DayDCrd), 0) FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS TotalCredit,
           m.DayMUser,
           m.DayMDateTime
    FROM dbo.Acc_DayMaster AS m
    WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

    SELECT d.DayDID, d.DayDAccID, a.AccCode, a.AccName,
           d.DayDDeb, d.DayDCrd,
           d.DayDCsCID, c.CsCCode, c.CsCName,
           d.DayDNum, d.DayDDescription
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
    LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DayDCsCID
    WHERE d.DayDMID = @DayMID
    ORDER BY d.DayDID;
END;
GO

/* =====================================================================
   3) حذف قيد مؤقت فقط (الحالة 0)
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_DeleteDayVoucher
    @Cmp    INT,
    @DayMID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    DECLARE @State TINYINT;
    SELECT @State = DayMState FROM dbo.Acc_DayMaster WHERE DayMID = @DayMID AND DayMCompany = @Cmp;

    IF @State IS NULL
        THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;
    IF @State <> 0
        THROW 50122, N'لا يُحذف إلا القيد المؤقت.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_DeleteDayVoucher;

    BEGIN TRY
        DELETE dbo.Acc_DayDetails WHERE DayDMID = @DayMID;
        DELETE dbo.Acc_DayMaster  WHERE DayMID = @DayMID AND DayMCompany = @Cmp AND DayMState = 0;

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_DeleteDayVoucher;

        THROW;
    END CATCH;
END;
GO

/* =====================================================================
   4) نسخ قيد إلى تاريخ جديد: يُنشأ مؤقتًا بلا رقم. يعيد NewDayMID
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_CopyDayVoucher
    @Cmp     INT,
    @Year    INT,
    @User    BIGINT,
    @DayMID  BIGINT,
    @NewDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF @NewDate IS NULL OR YEAR(@NewDate) <> @Year
        THROW 50101, N'تاريخ القيد يجب أن يقع داخل السنة المالية المحددة.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @DayMID AND DayMCompany = @Cmp)
        THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 50112, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0, @New BIGINT;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_CopyDayVoucher;

    BEGIN TRY
        INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
        SELECT @NewDate, m.DayMDescription, 0, 0, @User, @Cmp
        FROM dbo.Acc_DayMaster AS m
        WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

        SET @New = SCOPE_IDENTITY();

        INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDCsCID, DayDNum, DayDDescription)
        SELECT @New, d.DayDAccID, d.DayDDeb, d.DayDCrd, d.DayDCsCID, d.DayDNum, d.DayDDescription
        FROM dbo.Acc_DayDetails AS d
        WHERE d.DayDMID = @DayMID
        ORDER BY d.DayDID;

        IF @Started = 1 COMMIT;

        SELECT @New AS NewDayMID;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_CopyDayVoucher;

        THROW;
    END CATCH;
END;
GO

﻿/* =====================================================================
   إصلاح إعادة ترقيم الرموز: AccChid / CsCChid هو عدد الأبناء، لا عرض الرمز.
   عرض جزء الرمز = عدد خانات هذا العدد.
   تحقق منه بالاستعلام: 3813 من 3813 رمز حسابات تطابق الصيغة الجديدة.
   الحسابات: Acc_UpdateAccountCode  (مُتحقَّق منه)
   مراكز التكلفة: ACC_UpdateCostCenterCode  — لا تنفّذ جزءها إلا بعد استعلام
   التحقق الخاص بها (في الرسالة)، وإلا اتركه معلقًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_UpdateAccountCode]
    @AccCompany INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- إعادة ترقيم الحسابات الفرعية والرئيسية داخل الشركة
        ;WITH AccountOrder AS
        (
            SELECT
                AccID,
                ROW_NUMBER() OVER
                (
                    PARTITION BY AccParentID
                    ORDER BY AccOrder, AccID
                ) AS NewOrder
            FROM dbo.Acc_Account
            WHERE AccCompany = @AccCompany
        )
        UPDATE A
        SET
            AccOrder = O.NewOrder
        FROM dbo.Acc_Account AS A
        INNER JOIN AccountOrder AS O
            ON O.AccID = A.AccID;

        -- إعادة بناء الرموز من الحسابات الرئيسية إلى الفروع
        DECLARE @Level SMALLINT = 2;
        DECLARE @MaxLevel SMALLINT;

        SELECT @MaxLevel = MAX(AccLevel)
        FROM dbo.Acc_Account
        WHERE AccCompany = @AccCompany;

        WHILE @Level <= ISNULL(@MaxLevel, 0)
        BEGIN
            UPDATE C
            SET
                C.AccCode =
                    P.AccCode +
                    RIGHT(
                        REPLICATE(N'0', LEN(CONVERT(NVARCHAR(10), P.AccChid))) +
                        CONVERT(NVARCHAR(10), C.AccOrder),
                        LEN(CONVERT(NVARCHAR(10), P.AccChid))
                    ),
                C.AccDateTime = SYSDATETIME()
            FROM dbo.Acc_Account AS C
            INNER JOIN dbo.Acc_Account AS P
                ON P.AccID = C.AccParentID
               AND P.AccCompany = C.AccCompany
            WHERE C.AccCompany = @AccCompany
              AND C.AccLevel = @Level;

            SET @Level += 1;
        END;

        COMMIT TRANSACTION;

        SELECT *
        FROM dbo.Acc_Account
        WHERE AccCompany = @AccCompany
        ORDER BY AccLevel, AccParentID, AccOrder, AccID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

/* --- مراكز التكلفة: نفّذ هذا الجزء بعد التحقق فقط --- */
CREATE OR ALTER PROCEDURE [dbo].[ACC_UpdateCostCenterCode]
    @CsCCompany INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- إعادة ترتيب مراكز التكلفة الرئيسية والفرعية داخل الشركة
        ;WITH CostCenterOrder AS
        (
            SELECT
                CsCID,
                ROW_NUMBER() OVER
                (
                    PARTITION BY CsCParentID
                    ORDER BY CsCOrder, CsCID
                ) AS NewOrder
            FROM dbo.Acc_CostCenter
            WHERE CsCCompany = @CsCCompany
        )
        UPDATE C
        SET CsCOrder = O.NewOrder
        FROM dbo.Acc_CostCenter AS C
        INNER JOIN CostCenterOrder AS O
            ON O.CsCID = C.CsCID;

        -- تحديد أعلى مستوى
        DECLARE @Level SMALLINT = 2;
        DECLARE @MaxLevel SMALLINT;

        SELECT @MaxLevel = MAX(CsCLevel)
        FROM dbo.Acc_CostCenter
        WHERE CsCCompany = @CsCCompany;

        -- إعادة بناء الأكواد من الأب إلى الابن
        WHILE @Level <= ISNULL(@MaxLevel, 0)
        BEGIN
            UPDATE C
            SET
                C.CsCCode =
                    P.CsCCode +
                    RIGHT
                    (
                        REPLICATE(N'0', LEN(CONVERT(NVARCHAR(10), P.CsCChid))) +
                        CONVERT(NVARCHAR(10), C.CsCOrder),
                        LEN(CONVERT(NVARCHAR(10), P.CsCChid))
                    ),
                C.CsCDateTime = SYSUTCDATETIME()
            FROM dbo.Acc_CostCenter AS C
            INNER JOIN dbo.Acc_CostCenter AS P
                ON P.CsCID = C.CsCParentID
               AND P.CsCCompany = C.CsCCompany
            WHERE C.CsCCompany = @CsCCompany
              AND C.CsCLevel = @Level;

            SET @Level += 1;
        END;

        COMMIT TRANSACTION;

        SELECT *
        FROM dbo.Acc_CostCenter
        WHERE CsCCompany = @CsCCompany
        ORDER BY CsCLevel, CsCParentID, CsCOrder, CsCID;

    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

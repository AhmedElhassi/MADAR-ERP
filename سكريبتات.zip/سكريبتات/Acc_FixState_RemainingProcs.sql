﻿USE MADARERPDataBase;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccTrialBalance]
@FromDate  DATE
= NULL,
@ToDate
DATE
= NULL,
@Cmp
INT
= 1,
@Year
INT
= 0,
@AllAcc
BIT
= 0,
@MoveAcc   BIT
= 0,
@BalnceAcc BIT
= 0,
@LevelAcc  TINYINT  = 0  AS  BEGIN
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #Roll;
DROP TABLE IF EXISTS #LeafAmt;
DROP TABLE IF EXISTS #Amount;
DROP TABLE IF EXISTS #Kid;
DROP TABLE IF EXISTS #Acc;
/* 1. التحقق من المدخلات */
IF @FromDate IS NULL
OR @ToDate IS NULL
OR @FromDate > @ToDate
THROW 50002, N'فترة التقرير غير صحيحة.', 1;
IF @Cmp IS NULL OR @Cmp <= 0
THROW 50008, N'الشركة المحددة غير صحيحة.', 1;
SET @Year = ISNULL(@Year, 0);
IF @Year = 0
SET @Year = YEAR(@FromDate);
IF YEAR(@FromDate) <> @Year
OR YEAR(@ToDate) <> @Year
THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;
SET @AllAcc
= ISNULL(@AllAcc, 0);
SET @MoveAcc   = ISNULL(@MoveAcc, 0);
SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
SET @LevelAcc  = ISNULL(@LevelAcc, 0);
/* 2. تحميل شجرة حسابات الشركة */
SELECT
a.AccID,
a.AccParentID,
a.AccLevel,
CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
ISNULL(a.AccCode, N'') AS AccCode,
ISNULL(a.AccName, N'') AS AccName
INTO #Acc
FROM dbo.Acc_Account AS a
WHERE a.AccCompany = @Cmp;
IF NOT EXISTS (SELECT 1 FROM #Acc)
THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;
CREATE UNIQUE CLUSTERED INDEX IX_Acc
ON #Acc (AccID);
CREATE NONCLUSTERED INDEX IX_Acc_Parent
ON #Acc (AccParentID);
/* 3. التحقق من الحسابات اليتيمة */
IF EXISTS
(
SELECT 1
FROM #Acc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS x
WHERE x.AccID = a.AccParentID
)
)
THROW 50011, N'شجرة الحسابات تحتوي على حسابات يتيمة؛ الحساب الأب غير موجود.', 1;
/* 4. التحقق من الربط بين الشركات */
IF EXISTS
(
SELECT 1
FROM #Acc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #Acc AS p
WHERE p.AccID = a.AccParentID
)
AND EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS x
WHERE x.AccID = a.AccParentID
)
)
THROW 50012, N'شجرة الحسابات تحتوي على ربط بين حسابات شركتين مختلفتين.', 1;
/* 5. التحقق من الحلقات والحسابات غير القابلة للوصول */
DECLARE
@Total   BIGINT,
@Reached BIGINT;
SELECT @Total = COUNT_BIG(*)
FROM #Acc;
;WITH Reach AS
(
SELECT a.AccID
FROM #Acc AS a
WHERE a.AccParentID IS NULL
OR a.AccParentID = 0
UNION ALL
SELECT c.AccID
FROM Reach AS r
INNER JOIN #Acc AS c
ON c.AccParentID = r.AccID
)
SELECT @Reached = COUNT_BIG(*)
FROM Reach
OPTION (MAXRECURSION 32767);
IF @Reached <> @Total
BEGIN
DECLARE @CycleMsg NVARCHAR(300);
SET @CycleMsg =
CONCAT(
N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول من الجذور. عدد الحسابات المتأثرة: ',
@Total - @Reached
);
THROW 50010, @CycleMsg, 1;
END;
/* 6. تحديد عدد الأبناء لكل حساب */
SELECT
c.AccParentID AS AccID,
COUNT_BIG(*) AS Cnt
INTO #Kid
FROM #Acc AS c
WHERE c.AccParentID IS NOT NULL
GROUP BY c.AccParentID;
CREATE UNIQUE CLUSTERED INDEX IX_Kid
ON #Kid (AccID);
/* 7. تجميع الحركات المحاسبية */
SELECT
d.DayDAccID AS AccID,
CAST
(
SUM
(
CASE
WHEN m.DayMDate < @FromDate
THEN d.DayDDeb - d.DayDCrd
ELSE 0
END
)
AS DECIMAL(28,3)
) AS OpenNet,
CAST
(
SUM
(
CASE
WHEN m.DayMDate >= @FromDate
THEN d.DayDDeb
ELSE 0
END
)
AS DECIMAL(28,3)
) AS PerDeb,
CAST
(
SUM
(
CASE
WHEN m.DayMDate >= @FromDate
THEN d.DayDCrd
ELSE 0
END
)
AS DECIMAL(28,3)
) AS PerCrd,
SUM
(
CONVERT
(
BIGINT,
CASE
WHEN m.DayMDate >= @FromDate THEN 1
ELSE 0
END
)
) AS PerCnt
INTO #Amount
FROM dbo.Acc_DayMaster AS m
INNER JOIN dbo.Acc_DayDetails AS d
ON d.DayDMID = m.DayMID
WHERE m.DayMCompany = @Cmp
AND m.DayMState BETWEEN 1 AND 7
AND m.DayMDate <= @ToDate
GROUP BY d.DayDAccID
OPTION (RECOMPILE);
CREATE UNIQUE CLUSTERED INDEX IX_Amount
ON #Amount (AccID);
/* 8. فحوص سلامة البيانات */
DECLARE
@ChkNonLeaf BIGINT = 0,
@ChkOrphan  BIGINT = 0,
@ChkCrossCo BIGINT = 0,
@ChkForeign BIGINT = 0,
@ChkChid
BIGINT = 0;
/* حركة على حساب أب */
SELECT @ChkNonLeaf = COUNT_BIG(*)
FROM #Amount AS am
INNER JOIN #Kid AS k
ON k.AccID = am.AccID;
/* الحسابات اليتيمة */
SELECT @ChkOrphan = COUNT_BIG(*)
FROM #Acc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #Acc AS p
WHERE p.AccID = a.AccParentID
)
AND NOT EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS x
WHERE x.AccID = a.AccParentID
);
/* الآباء التابعون لشركات أخرى */
SELECT @ChkCrossCo = COUNT_BIG(*)
FROM #Acc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #Acc AS p
WHERE p.AccID = a.AccParentID
)
AND EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS x
WHERE x.AccID = a.AccParentID
);
/* حركة على حساب خارج حسابات الشركة */
SELECT @ChkForeign = COUNT_BIG(*)
FROM #Amount AS am
WHERE NOT EXISTS
(
SELECT 1
FROM #Acc AS a
WHERE a.AccID = am.AccID
);
/* عدم تطابق AccChid مع وجود الأبناء الفعلي */
SELECT @ChkChid = COUNT_BIG(*)
FROM #Acc AS a
LEFT JOIN #Kid AS k
ON k.AccID = a.AccID
WHERE
(CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
<>
(CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);
/* 9. حركات الحسابات التحليلية فقط */
SELECT
am.AccID,
am.OpenNet,
am.PerDeb,
am.PerCrd,
am.PerCnt
INTO #LeafAmt
FROM #Amount AS am
INNER JOIN #Acc AS a
ON a.AccID = am.AccID
WHERE NOT EXISTS
(
SELECT 1
FROM #Kid AS k
WHERE k.AccID = am.AccID
);
CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
ON #LeafAmt (AccID);
/* 10. إجماليات الميزان من الحسابات التحليلية */
DECLARE
@SumBlcOldDebit  DECIMAL(38,3),
@SumBlcOldCredit DECIMAL(38,3),
@SumTotDebit
DECIMAL(38,3),
@SumTotCredit
DECIMAL(38,3),
@SumBlcDebit
DECIMAL(38,3),
@SumBlcCredit
DECIMAL(38,3),
@SumTotBlcDebit  DECIMAL(38,3),
@SumTotBlcCredit DECIMAL(38,3);
SELECT
@SumBlcOldDebit =
ISNULL(SUM(CASE WHEN y.OpenNet > 0 THEN y.OpenNet ELSE 0 END), 0),
@SumBlcOldCredit =
ISNULL(SUM(CASE WHEN y.OpenNet < 0 THEN -y.OpenNet ELSE 0 END), 0),
@SumTotDebit =
ISNULL(SUM(y.PerDeb), 0),
@SumTotCredit =
ISNULL(SUM(y.PerCrd), 0),
@SumBlcDebit =
ISNULL(SUM(CASE WHEN y.PerNet > 0 THEN y.PerNet ELSE 0 END), 0),
@SumBlcCredit =
ISNULL(SUM(CASE WHEN y.PerNet < 0 THEN -y.PerNet ELSE 0 END), 0),
@SumTotBlcDebit =
ISNULL(SUM(CASE WHEN y.CloseNet > 0 THEN y.CloseNet ELSE 0 END), 0),
@SumTotBlcCredit =
ISNULL(SUM(CASE WHEN y.CloseNet < 0 THEN -y.CloseNet ELSE 0 END), 0)
FROM
(
SELECT
l.OpenNet,
l.PerDeb,
l.PerCrd,
CAST(l.PerDeb - l.PerCrd AS DECIMAL(28,3)) AS PerNet,
CAST
(
l.OpenNet + l.PerDeb - l.PerCrd
AS DECIMAL(28,3)
) AS CloseNet
FROM #LeafAmt AS l
) AS y;
/* ================================================================
11. التجميع التصاعدي من الحسابات التحليلية إلى الآباء
بدل إنشاء #Cl الذي يحتوي على كل حساب وكل أحفاده،
ننقل حركات الحساب التحليلي إلى أبيه ثم إلى الجد الأعلى.
================================================================ */
;WITH RollUp AS
(
/* بداية التجميع: الحسابات التحليلية ذات الحركات */
SELECT
l.AccID AS NodeID,
l.OpenNet,
l.PerDeb,
l.PerCrd,
l.PerCnt
FROM #LeafAmt AS l
UNION ALL
/* نقل الحركة إلى الحساب الأب */
SELECT
p.AccID AS NodeID,
r.OpenNet,
r.PerDeb,
r.PerCrd,
r.PerCnt
FROM RollUp AS r
INNER JOIN #Acc AS c
ON c.AccID = r.NodeID
INNER JOIN #Acc AS p
ON p.AccID = c.AccParentID
AND c.AccParentID > 0
),
RollTotals AS
(
SELECT
NodeID AS AccID,
SUM(OpenNet) AS OpenNet,
SUM(PerDeb) AS PerDeb,
SUM(PerCrd) AS PerCrd,
SUM(PerCnt) AS PerCnt
FROM RollUp
GROUP BY NodeID
)
SELECT
a.AccID,
a.AccCode,
a.AccName,
a.AccParentID,
a.AccLevel,
a.AccChid,
CAST(ISNULL(t.OpenNet, 0) AS DECIMAL(28,3)) AS OpenNet,
CAST(ISNULL(t.PerDeb, 0) AS DECIMAL(28,3)) AS PerDeb,
CAST(ISNULL(t.PerCrd, 0) AS DECIMAL(28,3)) AS PerCrd,
ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt
INTO #Roll
FROM #Acc AS a
LEFT JOIN RollTotals AS t
ON t.AccID = a.AccID
OPTION (MAXRECURSION 32767);
CREATE UNIQUE CLUSTERED INDEX IX_Roll
ON #Roll (AccID);
/* 12. النتيجة النهائية */
SELECT
x.AccID,
x.AccCode,
x.AccName AS AccARName,
x.AccLevel,
x.AccParentID AS AccParint,
p.AccName AS AccParintName,
x.AccChid AS AccCountChid,
/* رصيد أول المدة */
CASE WHEN x.OpenNet > 0 THEN x.OpenNet ELSE 0 END AS OldDebit,
CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
/* حركة الفترة */
x.PerDeb AS NewDebit,
x.PerCrd AS NewCredit,
/* صافي حركة الفترة */
CASE WHEN x.PerNet > 0 THEN x.PerNet ELSE 0 END AS BalanceDebit,
CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
/* رصيد نهاية الفترة */
CASE WHEN x.CloseNet > 0 THEN x.CloseNet ELSE 0 END AS TotBlcDebit,
CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,
/* إجماليات الميزان */
@SumBlcOldDebit AS SumBlcOldDebit,
@SumBlcOldCredit AS SumBlcOldCredit,
@SumTotDebit AS SumTotDebit,
@SumTotCredit AS SumTotCredit,
@SumBlcDebit AS SumBlcDebit,
@SumBlcCredit AS SumBlcCredit,
@SumTotBlcDebit AS SumTotBlcDebit,
@SumTotBlcCredit AS SumTotBlcCredit,
/* فحوص التوازن */
@SumBlcOldDebit - @SumBlcOldCredit AS ChkOpenDiff,
@SumTotDebit - @SumTotCredit AS ChkPeriodDiff,
@SumTotBlcDebit - @SumTotBlcCredit AS ChkCloseDiff,
/* فحوص سلامة البيانات */
@ChkNonLeaf AS ChkNonLeafAccounts,
@ChkOrphan AS ChkOrphanAccounts,
@ChkCrossCo AS ChkCrossCompanyParents,
@ChkForeign AS ChkForeignAccounts,
@ChkChid AS ChkChidMismatch
FROM
(
SELECT
r.*,
CAST(r.PerDeb - r.PerCrd AS DECIMAL(28,3)) AS PerNet,
CAST
(
r.OpenNet + r.PerDeb - r.PerCrd
AS DECIMAL(28,3)
) AS CloseNet
FROM #Roll AS r
) AS x
LEFT JOIN #Acc AS p
ON p.AccID = x.AccParentID
LEFT JOIN #Kid AS k
ON k.AccID = x.AccID
WHERE
(@AllAcc = 0 OR k.AccID IS NULL)
AND
(
@LevelAcc = 0
OR x.AccLevel = @LevelAcc
OR (x.AccLevel < @LevelAcc AND k.AccID IS NULL)
)
AND (@MoveAcc = 0 OR x.PerCnt > 0)
AND (@BalnceAcc = 0 OR x.CloseNet <> 0)
ORDER BY
x.AccCode,
x.AccID
OPTION (RECOMPILE);
END;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccIncomeStatement]
@FromDate  DATE
= NULL,
@ToDate
DATE
= NULL,
@Cmp
INT
= 1,
@Year
INT
= 0,
@AllAcc
BIT
= 0,
@MoveAcc   BIT
= 0,
@LevelAcc  TINYINT  = 0  AS  BEGIN
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #RollTotals;
DROP TABLE IF EXISTS #LeafAmount;
DROP TABLE IF EXISTS #Amount;
DROP TABLE IF EXISTS #Kid;
DROP TABLE IF EXISTS #CompanyKid;
DROP TABLE IF EXISTS #Account;
DROP TABLE IF EXISTS #CompanyAcc;
/* =====================================================
1. التحقق من المدخلات والفترة
===================================================== */
IF @FromDate IS NULL
OR @ToDate IS NULL
OR @FromDate > @ToDate
THROW 52001, N'فترة قائمة الدخل غير صحيحة.', 1;
IF @Cmp IS NULL OR @Cmp <= 0
THROW 52002, N'الشركة المحددة غير صحيحة.', 1;
IF NOT EXISTS
(
SELECT 1
FROM dbo.Mng_Company
WHERE CmpID = @Cmp
)
THROW 52003, N'الشركة المحددة غير موجودة.', 1;
SET @Year = ISNULL(@Year, 0);
IF @Year = 0
SET @Year = YEAR(@FromDate);
IF YEAR(@FromDate) <> @Year
OR YEAR(@ToDate) <> @Year
THROW 52004, N'يجب أن يقع تاريخا التقرير ضمن السنة المالية نفسها.', 1;
SET @AllAcc   = ISNULL(@AllAcc, 0);
SET @MoveAcc  = ISNULL(@MoveAcc, 0);
SET @LevelAcc = ISNULL(@LevelAcc, 0);
/* =====================================================
2. تحميل جميع حسابات الشركة
نحتاج الشجرة الكاملة لتحديد الأبناء الفعليين،
وعدم اعتبار الحساب تحليليًا لمجرد عدم وجود أبنائه
ضمن تصنيف قائمة الدخل فقط.
===================================================== */
SELECT
a.AccID,
a.AccEnd,
a.AccType,
a.AccParentID,
a.AccLevel,
CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
ISNULL(a.AccCode, N'') AS AccCode,
ISNULL(a.AccName, N'') AS AccName
INTO #CompanyAcc
FROM dbo.Acc_Account AS a
WHERE a.AccCompany = @Cmp;
IF NOT EXISTS (SELECT 1 FROM #CompanyAcc)
THROW 52005, N'لا توجد حسابات لهذه الشركة.', 1;
CREATE UNIQUE CLUSTERED INDEX IX_CompanyAcc
ON #CompanyAcc (AccID);
CREATE NONCLUSTERED INDEX IX_CompanyAcc_Parent
ON #CompanyAcc (AccParentID);
/* =====================================================
3. تحميل حسابات قائمة الدخل
AccEnd = 2
AccType = 0 الإيرادات
AccType = 1 المصروفات
===================================================== */
SELECT
a.AccID,
a.AccEnd,
a.AccType,
a.AccParentID,
a.AccCode,
a.AccName,
a.AccLevel,
a.AccChid
INTO #Account
FROM #CompanyAcc AS a
WHERE a.AccEnd = 2
AND a.AccType IN (0, 1);
IF NOT EXISTS (SELECT 1 FROM #Account)
THROW 52006, N'لا توجد حسابات قائمة دخل للشركة المحددة.', 1;
CREATE UNIQUE CLUSTERED INDEX IX_IncomeAccount
ON #Account (AccID);
CREATE NONCLUSTERED INDEX IX_IncomeAccount_Parent
ON #Account (AccParentID)
INCLUDE (AccType, AccLevel, AccChid);
/* =====================================================
4. فحوص سلامة شجرة الحسابات
===================================================== */
/* الحسابات اليتيمة */
IF EXISTS
(
SELECT 1
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
)
)
THROW 52007, N'شجرة الحسابات تحتوي على حسابات يتيمة؛ الحساب الأب غير موجود.', 1;
/* الربط بين حسابات شركتين مختلفتين */
IF EXISTS
(
SELECT 1
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS p
WHERE p.AccID = a.AccParentID
)
AND EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
)
)
THROW 52008, N'شجرة الحسابات تحتوي على ربط بين حسابات شركتين مختلفتين.', 1;
/* يجب أن يكون الأب والابن من التصنيف نفسه في قائمة الدخل */
IF EXISTS
(
SELECT 1
FROM #CompanyAcc AS child
INNER JOIN #CompanyAcc AS parent
ON parent.AccID = child.AccParentID
WHERE parent.AccEnd = 2
AND
(
child.AccEnd <> 2
OR child.AccType <> parent.AccType
)
)
THROW 52009, N'يوجد اختلاف في تصنيف حساب أب وأحد حساباته الفرعية ضمن قائمة الدخل.', 1;
/* التحقق من الوصول إلى جذور الشجرة */
DECLARE
@ReachCount BIGINT,
@AccountCount BIGINT;
SELECT @AccountCount = COUNT_BIG(*)
FROM #CompanyAcc;
;WITH AccountReach AS
(
SELECT a.AccID
FROM #CompanyAcc AS a
WHERE a.AccParentID IS NULL
OR a.AccParentID = 0
UNION ALL
SELECT child.AccID
FROM #CompanyAcc AS child
INNER JOIN AccountReach AS parent
ON child.AccParentID = parent.AccID
)
SELECT @ReachCount = COUNT_BIG(*)
FROM AccountReach
OPTION (MAXRECURSION 32767);
IF ISNULL(@ReachCount, 0) <> @AccountCount
THROW 52010, N'توجد دورة أو حسابات غير مرتبطة بجذر شجرة الحسابات.', 1;
/* =====================================================
5. تحديد الأبناء الفعليين على مستوى الشركة
===================================================== */
SELECT
c.AccParentID AS AccID,
COUNT_BIG(*) AS ChildCount
INTO #CompanyKid
FROM #CompanyAcc AS c
WHERE c.AccParentID IS NOT NULL
AND c.AccParentID <> 0
GROUP BY c.AccParentID;
CREATE UNIQUE CLUSTERED INDEX IX_CompanyKid
ON #CompanyKid (AccID);
/* الأبناء الفعليون لحسابات قائمة الدخل */
SELECT
k.AccID,
k.ChildCount
INTO #Kid
FROM #CompanyKid AS k
INNER JOIN #Account AS a
ON a.AccID = k.AccID;
CREATE UNIQUE CLUSTERED INDEX IX_IncomeKid
ON #Kid (AccID);
/* =====================================================
6. تجميع الحركات المؤرشفة خلال الفترة
الإيرادات = الدائن - المدين
المصروفات = المدين - الدائن
لا يتم احتساب أرصدة سابقة في قائمة الدخل.
===================================================== */
SELECT
d.DayDAccID AS AccID,
SUM(d.DayDDeb) AS PeriodDebit,
SUM(d.DayDCrd) AS PeriodCredit,
COUNT_BIG(*) AS MovementCount
INTO #Amount
FROM dbo.Acc_DayMaster AS m
INNER JOIN dbo.Acc_DayDetails AS d
ON d.DayDMID = m.DayMID
WHERE m.DayMCompany = @Cmp
AND m.DayMState BETWEEN 1 AND 7
AND m.DayMDate >= @FromDate
AND m.DayMDate <= @ToDate
GROUP BY
d.DayDAccID
OPTION (RECOMPILE);
CREATE UNIQUE CLUSTERED INDEX IX_IncomeAmount
ON #Amount (AccID);
/* =====================================================
7. مؤشرات سلامة البيانات
===================================================== */
DECLARE
@ChkNonLeaf BIGINT = 0,
@ChkOrphan  BIGINT = 0,
@ChkCrossCo BIGINT = 0,
@ChkForeign BIGINT = 0,
@ChkChid
BIGINT = 0;
/* حركات مسجلة على حسابات رئيسية في قائمة الدخل */
SELECT
@ChkNonLeaf = COUNT_BIG(*)
FROM #Amount AS am
INNER JOIN #Account AS a
ON a.AccID = am.AccID
INNER JOIN #Kid AS k
ON k.AccID = am.AccID;
/* الحسابات اليتيمة */
SELECT
@ChkOrphan = COUNT_BIG(*)
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS p
WHERE p.AccID = a.AccParentID
)
AND NOT EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
);
/* الآباء التابعون لشركات أخرى */
SELECT
@ChkCrossCo = COUNT_BIG(*)
FROM #CompanyAcc AS a
WHERE a.AccParentID > 0
AND NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS p
WHERE p.AccID = a.AccParentID
)
AND EXISTS
(
SELECT 1
FROM dbo.Acc_Account AS p
WHERE p.AccID = a.AccParentID
);
/* حركات على حسابات خارج حسابات الشركة */
SELECT
@ChkForeign = COUNT_BIG(*)
FROM #Amount AS am
WHERE NOT EXISTS
(
SELECT 1
FROM #CompanyAcc AS a
WHERE a.AccID = am.AccID
);
/* عدم تطابق AccChid مع الأبناء الفعليين */
SELECT
@ChkChid = COUNT_BIG(*)
FROM #CompanyAcc AS a
LEFT JOIN #CompanyKid AS k
ON k.AccID = a.AccID
WHERE
(CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
<>
(CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);
/* =====================================================
8. حركات الحسابات التحليلية فقط
الحساب التحليلي يحدد من عدم وجود أبناء فعليين،
وليس من قيمة AccChid وحدها.
===================================================== */
SELECT
a.AccID,
a.AccType,
CAST
(
CASE
WHEN a.AccType = 0
THEN ISNULL(am.PeriodCredit, 0)
- ISNULL(am.PeriodDebit, 0)
ELSE 0
END
AS DECIMAL(38,3)
) AS RevenueAmount,
CAST
(
CASE
WHEN a.AccType = 1
THEN ISNULL(am.PeriodDebit, 0)
- ISNULL(am.PeriodCredit, 0)
ELSE 0
END
AS DECIMAL(38,3)
) AS ExpenseAmount,
ISNULL(am.PeriodDebit, 0) AS PeriodDebit,
ISNULL(am.PeriodCredit, 0) AS PeriodCredit,
ISNULL(am.MovementCount, CONVERT(BIGINT, 0)) AS MovementCount
INTO #LeafAmount
FROM #Account AS a
LEFT JOIN #Kid AS k
ON k.AccID = a.AccID
LEFT JOIN #Amount AS am
ON am.AccID = a.AccID
WHERE k.AccID IS NULL;
CREATE UNIQUE CLUSTERED INDEX IX_IncomeLeafAmount
ON #LeafAmount (AccID);
/* =====================================================
9. التجميع التصاعدي من الحسابات التحليلية إلى الآباء
===================================================== */
;WITH RollUp AS
(
/* الحسابات التحليلية */
SELECT
l.AccID AS NodeID,
l.RevenueAmount,
l.ExpenseAmount,
l.PeriodDebit,
l.PeriodCredit,
l.MovementCount
FROM #LeafAmount AS l
UNION ALL
/* نقل الحركة إلى الأب ثم الأجداد */
SELECT
parent.AccID AS NodeID,
r.RevenueAmount,
r.ExpenseAmount,
r.PeriodDebit,
r.PeriodCredit,
r.MovementCount
FROM RollUp AS r
INNER JOIN #Account AS currentNode
ON currentNode.AccID = r.NodeID
INNER JOIN #Account AS parent
ON parent.AccID = currentNode.AccParentID
)
SELECT
r.NodeID,
SUM(r.RevenueAmount) AS RevenueAmount,
SUM(r.ExpenseAmount) AS ExpenseAmount,
SUM(r.PeriodDebit) AS PeriodDebit,
SUM(r.PeriodCredit) AS PeriodCredit,
SUM(r.MovementCount) AS MovementCount
INTO #RollTotals
FROM RollUp AS r
GROUP BY
r.NodeID
OPTION (MAXRECURSION 32767, RECOMPILE);
CREATE UNIQUE CLUSTERED INDEX IX_IncomeRollTotals
ON #RollTotals (NodeID);
/* =====================================================
10. إجماليات قائمة الدخل
تحسب من الحسابات التحليلية فقط.
===================================================== */
DECLARE
@TotalRevenue  DECIMAL(38,3),
@TotalExpenses DECIMAL(38,3),
@NetProfitLoss DECIMAL(38,3);
SELECT
@TotalRevenue =
COALESCE
(
SUM(l.RevenueAmount),
CONVERT(DECIMAL(38,3), 0)
),
@TotalExpenses =
COALESCE
(
SUM(l.ExpenseAmount),
CONVERT(DECIMAL(38,3), 0)
)
FROM #LeafAmount AS l;
SET @NetProfitLoss = @TotalRevenue - @TotalExpenses;
/* =====================================================
11. النتيجة النهائية
===================================================== */
SELECT
a.AccID,
a.AccCode,
a.AccName AS AccARName,
a.AccEnd,
a.AccType,
CASE
WHEN a.AccType = 0 THEN N'إيرادات'
WHEN a.AccType = 1 THEN N'مصروفات'
END AS AccountCategory,
a.AccLevel,
a.AccParentID AS AccParint,
p.AccName AS AccParintName,
a.AccChid AS AccCountChid,
CASE
WHEN a.AccType = 0
THEN ISNULL(r.RevenueAmount, 0)
ELSE CONVERT(DECIMAL(38,3), 0)
END AS RevenueAmount,
CASE
WHEN a.AccType = 1
THEN ISNULL(r.ExpenseAmount, 0)
ELSE CONVERT(DECIMAL(38,3), 0)
END AS ExpenseAmount,
CASE
WHEN a.AccType = 0
THEN ISNULL(r.RevenueAmount, 0)
ELSE ISNULL(r.ExpenseAmount, 0)
END AS PeriodAmount,
ISNULL(r.PeriodDebit, 0) AS PeriodDebit,
ISNULL(r.PeriodCredit, 0) AS PeriodCredit,
ISNULL(r.MovementCount, 0) AS MovementCount,
@TotalRevenue AS TotalRevenue,
@TotalExpenses AS TotalExpenses,
@NetProfitLoss AS NetProfitLoss,
CASE
WHEN @NetProfitLoss > 0 THEN N'صافي ربح'
WHEN @NetProfitLoss < 0 THEN N'صافي خسارة'
ELSE N'تعادل'
END AS ProfitLossStatus,
/* مؤشرات سلامة البيانات */
@ChkNonLeaf AS ChkNonLeafAccounts,
@ChkOrphan AS ChkOrphanAccounts,
@ChkCrossCo AS ChkCrossCompanyParents,
@ChkForeign AS ChkForeignAccounts,
@ChkChid AS ChkChidMismatch
FROM #Account AS a
LEFT JOIN #Account AS p
ON p.AccID = a.AccParentID
LEFT JOIN #Kid AS k
ON k.AccID = a.AccID
LEFT JOIN #RollTotals AS r
ON r.NodeID = a.AccID
WHERE
/* عرض جميع الحسابات أو التحليلية فقط */
(
@AllAcc = 0
OR k.AccID IS NULL
)
/* الحسابات التي لها حركة فعلية خلال الفترة */
AND
(
@MoveAcc = 0
OR ISNULL(r.MovementCount, 0) > 0
)
/* المستوى المطلوب مع إظهار الحساب التحليلي النهائي */
AND
(
@LevelAcc = 0
OR a.AccLevel = @LevelAcc
OR
(
a.AccLevel < @LevelAcc
AND k.AccID IS NULL
)
)
ORDER BY
a.AccCode,
a.AccID
OPTION (RECOMPILE);
END;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountWithBalnce]
@Cmp  INT,
@Year INT  AS  BEGIN
SET NOCOUNT ON;
DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
@To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);
;WITH Tree AS
(
/* الجذور (حسابات بلا أب) */
SELECT a.AccID,
CAST(N'' AS NVARCHAR(4000)) AS AccParintName,
0 AS Lvl
FROM dbo.Acc_Account AS a
WHERE a.AccCompany = @Cmp
AND a.AccParentID IS NULL
UNION ALL
/* كل ابن يرث مسار أبيه + اسم أبيه */
SELECT c.AccID,
CAST(CASE WHEN t.AccParintName = N'' THEN p.AccName
ELSE t.AccParintName + N' / ' + p.AccName END AS NVARCHAR(4000)),
t.Lvl + 1
FROM dbo.Acc_Account AS c
JOIN Tree AS t ON c.AccParentID = t.AccID
JOIN dbo.Acc_Account AS p ON p.AccID = t.AccID
WHERE c.AccCompany = @Cmp
AND t.Lvl < 30
),
Mov AS
(
SELECT d.DayDAccID AS AccID,
SUM(d.DayDDeb) AS Deb,
SUM(d.DayDCrd) AS Crd
FROM dbo.Acc_DayMaster AS m
JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
WHERE m.DayMState BETWEEN 1 AND 7
AND m.DayMDate >= @From
AND m.DayMDate < @To
GROUP BY d.DayDAccID
)
SELECT a.AccID,
a.AccCode,
a.AccName,
a.AccState,
t.AccParintName,
CASE WHEN t.AccParintName = N'' THEN a.AccName
ELSE t.AccParintName + N' / ' + a.AccName END AS Parents,
CASE WHEN ISNULL(x.Deb, 0) > ISNULL(x.Crd, 0)
THEN x.Deb - x.Crd ELSE 0 END AS AccDebet,
CASE WHEN ISNULL(x.Crd, 0) > ISNULL(x.Deb, 0)
THEN x.Crd - x.Deb ELSE 0 END AS AccCridit,
a.AccCompany
FROM dbo.Acc_Account AS a
JOIN Tree AS t ON t.AccID = a.AccID
LEFT JOIN Mov AS x ON x.AccID = a.AccID
WHERE a.AccState = 0
AND a.AccChid = 0
AND a.AccCompany = @Cmp
ORDER BY a.AccCode;  END;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenters]
@Cmp  INT,
@Year INT  AS  BEGIN
SET NOCOUNT ON;
DECLARE
@From DATE = DATEFROMPARTS(@Year, 1, 1),
@To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);
;WITH CostCenters AS
(
SELECT
C.CsCID,
C.CsCCode,
C.CsCName,
C.CsCParentID,
C.CsCLevel,
C.CsCOrder,
C.CsCChid,
C.CsCState,
C.CsCCompany,
/* هل سبق استخدام مركز التكلفة في أي تفصيل قيد؟ */
CAST(
CASE
WHEN EXISTS
(
SELECT 1
FROM dbo.Acc_DayDetails AS D
WHERE D.DayDCsCID = C.CsCID
)
THEN 1
ELSE 0
END
AS BIT) AS CsCUsed
FROM dbo.Acc_CostCenter AS C
WHERE C.CsCCompany = @Cmp
),
Tree AS
(
SELECT
C.CsCID AS DescendantID,
C.CsCID AS AncestorID,
C.CsCParentID AS ParentID,
0 AS Lvl
FROM CostCenters AS C
UNION ALL
SELECT
T.DescendantID,
P.CsCID,
P.CsCParentID,
T.Lvl + 1
FROM Tree AS T
INNER JOIN CostCenters AS P
ON P.CsCID = T.ParentID
WHERE T.ParentID IS NOT NULL
AND T.ParentID <> 0
AND T.Lvl < 30
),
Hierarchy AS
(
/* الجذور ومسار الآباء */
SELECT
C.CsCID,
CAST(N'' AS NVARCHAR(4000)) AS CsCParintName,
0 AS Lvl
FROM CostCenters AS C
WHERE C.CsCParentID IS NULL
OR C.CsCParentID = 0
UNION ALL
/* بناء مسار الآباء لكل مركز */
SELECT
C.CsCID,
CAST(
CASE
WHEN H.CsCParintName = N''
THEN P.CsCName
ELSE H.CsCParintName + N' / ' + P.CsCName
END
AS NVARCHAR(4000)
),
H.Lvl + 1
FROM CostCenters AS C
INNER JOIN Hierarchy AS H
ON C.CsCParentID = H.CsCID
INNER JOIN CostCenters AS P
ON P.CsCID = H.CsCID
WHERE H.Lvl < 30
),
Mov AS
(
/* الحركات المالية خلال السنة للقيود المؤرشفة فقط */
SELECT
D.DayDCsCID AS CsCID,
SUM(D.DayDDeb) AS Deb,
SUM(D.DayDCrd) AS Crd
FROM dbo.Acc_DayMaster AS M
INNER JOIN dbo.Acc_DayDetails AS D
ON D.DayDMID = M.DayMID
INNER JOIN CostCenters AS C
ON C.CsCID = D.DayDCsCID
WHERE M.DayMState BETWEEN 1 AND 7
AND M.DayMDate >= @From
AND M.DayMDate < @To
AND D.DayDCsCID IS NOT NULL
GROUP BY D.DayDCsCID
),
Rollup AS
(
/* تجميع حركات الأبناء نحو الآباء */
SELECT
T.AncestorID AS CsCID,
SUM(ISNULL(M.Deb, 0)) AS Deb,
SUM(ISNULL(M.Crd, 0)) AS Crd
FROM Tree AS T
LEFT JOIN Mov AS M
ON M.CsCID = T.DescendantID
GROUP BY T.AncestorID
)
SELECT
C.CsCID,
C.CsCCode,
C.CsCName,
CAST(ISNULL(R.Deb, 0) AS DECIMAL(15,3)) AS CsCDebet,
CAST(ISNULL(R.Crd, 0) AS DECIMAL(15,3)) AS CsCCridit,
C.CsCUsed,
C.CsCParentID,
C.CsCLevel,
C.CsCOrder,
C.CsCState,
ISNULL(H.CsCParintName, N'') AS CsCParintName,
CASE
WHEN H.CsCParintName IS NULL
OR H.CsCParintName = N''
THEN C.CsCName
ELSE H.CsCParintName + N' / ' + C.CsCName
END AS Parents,
C.CsCCompany
FROM CostCenters AS C
LEFT JOIN Rollup AS R
ON R.CsCID = C.CsCID
LEFT JOIN Hierarchy AS H
ON H.CsCID = C.CsCID
WHERE C.CsCState = 0
AND C.CsCChid = 0
AND C.CsCCompany = @Cmp
ORDER BY C.CsCCode
OPTION (MAXRECURSION 100);
END;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountingTree]
@Cmp  INT,
@Year INT  AS  BEGIN
SET NOCOUNT ON;
DECLARE
@From DATE = DATEFROMPARTS(@Year, 1, 1),
@To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);
;WITH Accounts AS
(
SELECT
A.AccID,
A.AccCode,
A.AccName,
A.AccParentID,
A.AccLevel,
A.AccOrder,
/* هل سبق استخدام الحساب في أي تفصيل قيد؟ */
CAST(
CASE
WHEN EXISTS
(
SELECT 1
FROM dbo.Acc_DayDetails AS D
WHERE D.DayDAccID = A.AccID
)
THEN 1
ELSE 0
END
AS BIT) AS AccUsed
FROM dbo.Acc_Account AS A
WHERE A.AccCompany = @Cmp
),
Hierarchy AS
(
/* كل حساب يبدأ باعتباره أصلًا لنفسه */
SELECT
A.AccID AS DescendantID,
A.AccID AS AncestorID,
A.AccParentID AS ParentID,
0 AS Lvl
FROM Accounts AS A
UNION ALL
/* الصعود من الحساب إلى آبائه */
SELECT
H.DescendantID,
P.AccID,
P.AccParentID,
H.Lvl + 1
FROM Hierarchy AS H
INNER JOIN Accounts AS P
ON P.AccID = H.ParentID
WHERE H.ParentID IS NOT NULL
AND H.ParentID <> 0
AND H.Lvl < 30
),
Mov AS
(
/* الحركات المؤرشفة خلال السنة المالية */
SELECT
D.DayDAccID AS AccID,
SUM(D.DayDDeb) AS Deb,
SUM(D.DayDCrd) AS Crd
FROM dbo.Acc_DayMaster AS M
INNER JOIN dbo.Acc_DayDetails AS D
ON D.DayDMID = M.DayMID
INNER JOIN Accounts AS A
ON A.AccID = D.DayDAccID
WHERE M.DayMState BETWEEN 1 AND 7
AND M.DayMDate >= @From
AND M.DayMDate < @To
GROUP BY D.DayDAccID
),
Rollup AS
(
/* تجميع حركات كل حساب مع جميع حساباته التابعة */
SELECT
H.AncestorID AS AccID,
SUM(ISNULL(M.Deb, 0)) AS Deb,
SUM(ISNULL(M.Crd, 0)) AS Crd
FROM Hierarchy AS H
LEFT JOIN Mov AS M
ON M.AccID = H.DescendantID
GROUP BY H.AncestorID
)
SELECT
A.AccID,
A.AccCode,
A.AccName,
CAST(ISNULL(R.Deb, 0) AS DECIMAL(15,3)) AS AccDebet,
CAST(ISNULL(R.Crd, 0) AS DECIMAL(15,3)) AS AccCridit,
A.AccUsed,
A.AccParentID,
A.AccLevel,
A.AccOrder
FROM Accounts AS A
LEFT JOIN Rollup AS R
ON R.AccID = A.AccID
ORDER BY A.AccCode
OPTION (MAXRECURSION 100);
END;
GO

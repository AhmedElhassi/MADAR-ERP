/* =====================================================================
   اختبار قائمة الدخل (Acc_SelectAccIncomeStatement) — يعمل على قاعدة فيها بيانات
   ---------------------------------------------------------------------
   طريقة العمل (الفرق بين قبل وبعد):
     1) يشغّل الإجراء ويحفظ النتيجة الحالية (قبل أي قيد تجريبي).
     2) يُدخل قيودًا تجريبية معروفة داخل معاملة.
     3) يشغّل الإجراء مرة ثانية ويتحقق أن الفرق = أثر القيود التجريبية فقط.
     4) ROLLBACK دائمًا: لا يبقى أي قيد تجريبي في قاعدتك.
   فلا يتأثر بوجود قيود حقيقية.
   غيّر @UserId (مستخدم موجود في Mng_User) ثم نفّذ الملف كله.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Cmp    INT    = 10;
DECLARE @UserId BIGINT = 1;      -- رقم مستخدم موجود في Mng_User
DECLARE @Fail   INT    = 0;

BEGIN TRY
    BEGIN TRAN;

    /* ---------- 1) اختيار الحسابات ---------- */
    DECLARE @R1 BIGINT, @R2 BIGINT, @X1 BIGINT, @X2 BIGINT, @B BIGINT;

    SELECT TOP (1) @R1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 0
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @R2 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 0
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
      AND a.AccID <> @R1
    ORDER BY a.AccCode DESC;

    SELECT TOP (1) @X1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    SELECT TOP (1) @X2 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
      AND a.AccID <> @X1
    ORDER BY a.AccCode DESC;

    SELECT TOP (1) @B = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode ASC;

    IF @R1 IS NULL OR @R2 IS NULL OR @X1 IS NULL OR @X2 IS NULL OR @B IS NULL
        THROW 51001, N'تعذّر اختيار الحسابات التحليلية المطلوبة (إيرادان ومصروفان وحساب ميزانية).', 1;

    /* ---------- 2) الجداول المساعدة ---------- */
    CREATE TABLE #IS
    (
        AccID BIGINT, AccCode NVARCHAR(60), AccARName NVARCHAR(500),
        AccEnd INT, AccType INT, AccountCategory NVARCHAR(30),
        AccLevel INT, AccParint BIGINT NULL, AccParintName NVARCHAR(500) NULL, AccCountChid INT,
        RevenueAmount DECIMAL(38,3), ExpenseAmount DECIMAL(38,3), PeriodAmount DECIMAL(38,3),
        PeriodDebit DECIMAL(38,3), PeriodCredit DECIMAL(38,3), MovementCount BIGINT,
        TotalRevenue DECIMAL(38,3), TotalExpenses DECIMAL(38,3), NetProfitLoss DECIMAL(38,3),
        ProfitLossStatus NVARCHAR(30),
        ChkNonLeafAccounts INT, ChkOrphanAccounts INT, ChkCrossCompanyParents INT,
        ChkForeignAccounts INT, ChkChidMismatch INT
    );

    CREATE TABLE #Win (Id INT, D1 DATE, D2 DATE, ExpRev DECIMAL(18,3), ExpExp DECIMAL(18,3), ExpNet DECIMAL(18,3));
    INSERT #Win VALUES
        (1, '2026-01-01', '2026-06-30', 1300, 400, 900),    -- R1 1000 + R2 300 | X1 400
        (2, '2026-01-01', '2026-12-31', 1200, 650, 550);    -- R1 900 + R2 300 | X1 400 + X2 250

    CREATE TABLE #Base (W INT, AccID BIGINT, Rev DECIMAL(38,3), Exp DECIMAL(38,3),
                        Deb DECIMAL(38,3), Crd DECIMAL(38,3), Cnt BIGINT,
                        TotRev DECIMAL(38,3), TotExp DECIMAL(38,3));
    CREATE TABLE #BaseChk (W INT, C1 INT, C2 INT, C3 INT, C4 INT, C5 INT);

    DECLARE @w INT = 1, @D1 DATE, @D2 DATE, @ExpRev DECIMAL(18,3), @ExpExp DECIMAL(18,3), @ExpNet DECIMAL(18,3);

    /* ---------- 3) الحالة الحالية (قبل القيود التجريبية) ---------- */
    WHILE @w <= 2
    BEGIN
        SELECT @D1 = D1, @D2 = D2 FROM #Win WHERE Id = @w;

        DELETE #IS;
        INSERT #IS
        EXEC dbo.Acc_SelectAccIncomeStatement @FromDate = @D1, @ToDate = @D2, @Cmp = @Cmp, @Year = 2026;

        INSERT #Base
        SELECT @w, AccID, RevenueAmount, ExpenseAmount, PeriodDebit, PeriodCredit, MovementCount, TotalRevenue, TotalExpenses
        FROM #IS;

        INSERT #BaseChk
        SELECT TOP (1) @w, ChkNonLeafAccounts, ChkOrphanAccounts, ChkCrossCompanyParents, ChkForeignAccounts, ChkChidMismatch
        FROM #IS;

        SET @w += 1;
    END;

    /* ---------- 4) القيود التجريبية ---------- */
    CREATE TABLE #Line (EntryNo INT, EntryDate DATE, State TINYINT, AccID BIGINT, Deb DECIMAL(18,3), Crd DECIMAL(18,3));

    INSERT #Line VALUES
      (1, '2026-03-05', 7, @B , 1000, 0), (1, '2026-03-05', 7, @R1, 0, 1000),   -- إيراد R1
      (2, '2026-05-10', 7, @B , 300 , 0), (2, '2026-05-10', 7, @R2, 0, 300),    -- إيراد R2
      (3, '2026-06-01', 7, @X1, 400 , 0), (3, '2026-06-01', 7, @B , 0, 400),    -- مصروف X1
      (4, '2026-07-15', 7, @X2, 250 , 0), (4, '2026-07-15', 7, @B , 0, 250),    -- مصروف X2 (النصف الثاني)
      (5, '2026-04-01', 0, @B , 5000, 0), (5, '2026-04-01', 0, @R1, 0, 5000),   -- مسودة: يجب ألا تظهر
      (6, '2025-12-31', 7, @B , 900 , 0), (6, '2025-12-31', 7, @R1, 0, 900),    -- السنة السابقة: خارج الفترة
      (7, '2026-08-01', 7, @R1, 100 , 0), (7, '2026-08-01', 7, @B , 0, 100);    -- مردودات على إيراد R1

    DECLARE @no INT = (SELECT MIN(EntryNo) FROM #Line), @m BIGINT;
    WHILE @no IS NOT NULL
    BEGIN
        INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
        SELECT TOP (1) EntryDate, N'TEST قائمة دخل', 91000 + @no, State, @UserId, @Cmp
        FROM #Line WHERE EntryNo = @no;

        SET @m = SCOPE_IDENTITY();

        INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
        SELECT @m, AccID, Deb, Crd, N'TEST' FROM #Line WHERE EntryNo = @no;

        SET @no = (SELECT MIN(EntryNo) FROM #Line WHERE EntryNo > @no);
    END;

    /* ---------- 5) (الحساب ← أحفاده) لكل دليل الشركة ---------- */
    ;WITH Cl AS
    (
        SELECT a.AccID AS NodeID, a.AccID AS DescID
        FROM dbo.Acc_Account AS a WHERE a.AccCompany = @Cmp
        UNION ALL
        SELECT c.NodeID, k.AccID
        FROM Cl AS c
        JOIN dbo.Acc_Account AS k ON k.AccParentID = c.DescID AND k.AccCompany = @Cmp
    )
    SELECT NodeID, DescID INTO #XCl FROM Cl OPTION (MAXRECURSION 1000);

    DECLARE @IncomeCnt INT = (SELECT COUNT(*) FROM dbo.Acc_Account
                              WHERE AccCompany = @Cmp AND AccEnd = 2 AND AccType IN (0, 1));
    DECLARE @LeafIncomeCnt INT = (SELECT COUNT(*) FROM dbo.Acc_Account AS a
                                  WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType IN (0, 1)
                                    AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID));

    DECLARE @NBad INT, @NRows INT, @NMove INT, @ExpMove INT, @NLeaf INT;

    /* ---------- 6) التحقق: الفرق بعد القيود = أثر القيود التجريبية فقط ---------- */
    SET @w = 1;
    WHILE @w <= 2
    BEGIN
        SELECT @D1 = D1, @D2 = D2, @ExpRev = ExpRev, @ExpExp = ExpExp, @ExpNet = ExpNet FROM #Win WHERE Id = @w;
        PRINT CONCAT(N'---- النافذة ', @w, N': ', CONVERT(NVARCHAR(10), @D1, 23), N' → ', CONVERT(NVARCHAR(10), @D2, 23), N' ----');

        IF OBJECT_ID('tempdb..#ExpLeaf') IS NOT NULL DROP TABLE #ExpLeaf;
        IF OBJECT_ID('tempdb..#ExpNode') IS NOT NULL DROP TABLE #ExpNode;

        -- أثر القيود التجريبية على كل حساب تحليلي (من القيود الداخلة مباشرة)
        SELECT v.AccID,
               CAST(CASE WHEN v.AccID IN (@R1, @R2) THEN ISNULL(s.Crd, 0) - ISNULL(s.Deb, 0) ELSE 0 END AS DECIMAL(18,3)) AS Rev,
               CAST(CASE WHEN v.AccID IN (@X1, @X2) THEN ISNULL(s.Deb, 0) - ISNULL(s.Crd, 0) ELSE 0 END AS DECIMAL(18,3)) AS Exp,
               CAST(ISNULL(s.Deb, 0) AS DECIMAL(18,3)) AS Deb,
               CAST(ISNULL(s.Crd, 0) AS DECIMAL(18,3)) AS Crd,
               CAST(ISNULL(s.Cnt, 0) AS INT)           AS Cnt
        INTO #ExpLeaf
        FROM (VALUES (@R1), (@R2), (@X1), (@X2)) AS v(AccID)
        LEFT JOIN (SELECT AccID, SUM(Deb) AS Deb, SUM(Crd) AS Crd, COUNT(*) AS Cnt
                   FROM #Line
                   WHERE State = 7 AND EntryDate >= @D1 AND EntryDate <= @D2
                   GROUP BY AccID) AS s ON s.AccID = v.AccID;

        -- وأثرها على الآباء
        SELECT c.NodeID AS AccID,
               CAST(ISNULL(SUM(e.Rev), 0) AS DECIMAL(18,3)) AS Rev,
               CAST(ISNULL(SUM(e.Exp), 0) AS DECIMAL(18,3)) AS Exp,
               CAST(ISNULL(SUM(e.Deb), 0) AS DECIMAL(18,3)) AS Deb,
               CAST(ISNULL(SUM(e.Crd), 0) AS DECIMAL(18,3)) AS Crd,
               CAST(ISNULL(SUM(e.Cnt), 0) AS INT)           AS Cnt
        INTO #ExpNode
        FROM #XCl AS c
        LEFT JOIN #ExpLeaf AS e ON e.AccID = c.DescID
        GROUP BY c.NodeID;

        DELETE #IS;
        INSERT #IS
        EXEC dbo.Acc_SelectAccIncomeStatement @FromDate = @D1, @ToDate = @D2, @Cmp = @Cmp, @Year = 2026;

        -- A) عدد الصفوف
        SET @NRows = (SELECT COUNT(*) FROM #IS);
        IF @NRows = @IncomeCnt PRINT N'PASS A: عدد الصفوف = عدد حسابات قائمة الدخل';
        ELSE BEGIN PRINT N'FAIL A: عدد الصفوف لا يطابق حسابات قائمة الدخل'; SET @Fail += 1; END;

        -- B) الفرق على كل حساب (تحليلي وأب) = أثر القيود التجريبية
        IF OBJECT_ID('tempdb..#Bad') IS NOT NULL DROP TABLE #Bad;
        SELECT r.AccCode, r.AccARName,
               e.Rev AS ExpRevDelta, r.RevenueAmount - b.Rev AS ActRevDelta,
               e.Exp AS ExpExpDelta, r.ExpenseAmount - b.Exp AS ActExpDelta,
               e.Deb AS ExpDebDelta, r.PeriodDebit  - b.Deb AS ActDebDelta,
               e.Crd AS ExpCrdDelta, r.PeriodCredit - b.Crd AS ActCrdDelta,
               e.Cnt AS ExpCntDelta, r.MovementCount - b.Cnt AS ActCntDelta
        INTO #Bad
        FROM #IS AS r
        JOIN #ExpNode AS e ON e.AccID = r.AccID
        JOIN #Base    AS b ON b.W = @w AND b.AccID = r.AccID
        WHERE (r.RevenueAmount - b.Rev) <> e.Rev
           OR (r.ExpenseAmount - b.Exp) <> e.Exp
           OR (r.PeriodDebit   - b.Deb) <> e.Deb
           OR (r.PeriodCredit  - b.Crd) <> e.Crd
           OR (r.MovementCount - b.Cnt) <> e.Cnt;
        SET @NBad = (SELECT COUNT(*) FROM #Bad);
        IF @NBad = 0 PRINT N'PASS B: أثر القيود التجريبية على كل الحسابات (تحليلية وآباء) مطابق للمتوقع';
        ELSE BEGIN PRINT N'FAIL B: اختلافات في الأرقام'; SELECT TOP 30 * FROM #Bad; SET @Fail += 1; END;

        -- C) أثر القيود على الإجماليات
        IF EXISTS (SELECT 1
                   FROM (SELECT TOP (1) * FROM #IS) AS t
                   CROSS JOIN (SELECT TOP (1) TotRev, TotExp FROM #Base WHERE W = @w) AS b
                   WHERE t.TotalRevenue  - b.TotRev = @ExpRev
                     AND t.TotalExpenses - b.TotExp = @ExpExp
                     AND t.NetProfitLoss - (b.TotRev - b.TotExp) = @ExpNet)
            PRINT CONCAT(N'PASS C: الإجماليات تغيّرت بالمقدار المتوقع: إيرادات +', @ExpRev, N' | مصروفات +', @ExpExp, N' | صافي +', @ExpNet);
        ELSE BEGIN PRINT N'FAIL C: تغيّر الإجماليات لا يطابق'; SELECT TOP 1 TotalRevenue, TotalExpenses, NetProfitLoss FROM #IS;
                   SELECT TOP 1 TotRev, TotExp FROM #Base WHERE W = @w; SET @Fail += 1; END;

        -- D) مؤشرات سلامة البيانات لم تتغير بإدخال القيود التجريبية
        IF EXISTS (SELECT 1 FROM (SELECT TOP (1) * FROM #IS) AS t
                   JOIN #BaseChk AS c ON c.W = @w
                   WHERE t.ChkNonLeafAccounts <> c.C1 OR t.ChkOrphanAccounts <> c.C2
                      OR t.ChkCrossCompanyParents <> c.C3 OR t.ChkForeignAccounts <> c.C4
                      OR t.ChkChidMismatch <> c.C5)
        BEGIN PRINT N'FAIL D: مؤشرات سلامة البيانات تغيّرت بعد القيود التجريبية'; SET @Fail += 1; END
        ELSE PRINT N'PASS D: مؤشرات سلامة البيانات لم تتغير';

        -- E) @MoveAcc = 1
        DELETE #IS;
        INSERT #IS EXEC dbo.Acc_SelectAccIncomeStatement @FromDate = @D1, @ToDate = @D2, @Cmp = @Cmp, @Year = 2026, @MoveAcc = 1;
        SET @NMove = (SELECT COUNT(*) FROM #IS);
        SET @ExpMove = (SELECT COUNT(*) FROM #Base AS b
                        JOIN #ExpNode AS e ON e.AccID = b.AccID
                        WHERE b.W = @w AND b.Cnt + e.Cnt > 0);
        IF @NMove = @ExpMove PRINT N'PASS E: @MoveAcc = 1 يعرض الحسابات ذات الحركة فقط';
        ELSE BEGIN PRINT N'FAIL E: @MoveAcc = 1 عدد الصفوف لا يطابق'; SET @Fail += 1; END;

        -- F) @AllAcc = 1
        DELETE #IS;
        INSERT #IS EXEC dbo.Acc_SelectAccIncomeStatement @FromDate = @D1, @ToDate = @D2, @Cmp = @Cmp, @Year = 2026, @AllAcc = 1;
        SET @NLeaf = (SELECT COUNT(*) FROM #IS);
        IF @NLeaf = @LeafIncomeCnt PRINT N'PASS F: @AllAcc = 1 يعرض الحسابات التحليلية فقط';
        ELSE BEGIN PRINT N'FAIL F: @AllAcc = 1 عدد الصفوف لا يطابق'; SET @Fail += 1; END;

        SET @w += 1;
    END;

    IF @Fail = 0 PRINT N'==== كل الاختبارات نجحت ====';
    ELSE PRINT N'==== توجد اختبارات فاشلة (انظر FAIL أعلاه) ====';

    ROLLBACK TRAN;
    PRINT N'تم التراجع عن كل القيود التجريبية (ROLLBACK).';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    PRINT N'خطأ أثناء الاختبار (تم التراجع عن كل شيء): ' + ERROR_MESSAGE();
END CATCH;

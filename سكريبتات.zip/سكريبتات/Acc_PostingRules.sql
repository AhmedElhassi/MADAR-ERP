﻿/* =====================================================================
   التوجيهات الحسابية (Acc_PostingRule) وحماية حسابات النظام
   ---------------------------------------------------------------------
   الفكرة: أي حساب مذكور في Acc_PostingRule هو «حساب نظام». حالته (StateID)
   تحدد ما يُسمح به. القواعد العامة على كل حساب نظام (لا تتغير بالحالة):
       - لا يُحذف.          - لا يُنقل إلى أب آخر.
       - لا يتغير تصنيفه (AccEnd / AccType) ولا شركته ولا حالته (AccState).
       - المسموح: تعديل الاسم فقط (إعادة ترقيم الرموز AccCode/AccOrder مسموحة
         لأنها تنتج عن تعديل الاسم أو ترتيب الإخوة).
   وما يختلف بحسب الحالة (جدول Acc_PostingState):
       AllowManualChildren : هل يجوز إنشاء أبناء يدويًا تحته
       AllowAutoChildren   : هل يولّد النظام أبناء له آليًا
       AllowManualPosting  : هل يجوز القيد اليدوي عليه (Acc_SaveDayVoucher)
       ShowInVoucherLookup : هل يظهر في قائمة اختيار الحساب عند إنشاء القيد

   الاستثناء الوحيد: إجراءات النظام المعتمدة (إنشاء طرف وحسابه، الفاتورة...)
   تفتح العلامة:   EXEC dbo.Acc_SystemOperationBegin;   ... العمل ...
                   EXEC dbo.Acc_SystemOperationEnd;      (إلزاميًا، حتى عند الخطأ)

   ملاحظة: هذه العلامة حماية من الأخطاء ومن المسارات الخاطئة، وليست حماية من
   مستخدم قاعدة بيانات يملك صلاحية تنفيذ T-SQL مباشر.

   التنفيذ: مرة واحدة على MADARERPDataBase (آمن إعادة التنفيذ).
   بعده أعد تنفيذ Acc_DayVoucher_Procedures.sql (تعديل حفظ القيد يعتمد على الجداول).
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* ---------------------------------------------------------------------
   1) حالات التوجيه
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Acc_PostingState', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_PostingState
    (
        StateID             TINYINT       NOT NULL CONSTRAINT PK_Acc_PostingState PRIMARY KEY,
        StateName           NVARCHAR(150) NOT NULL,
        AllowManualChildren BIT           NOT NULL,
        AllowAutoChildren   BIT           NOT NULL,
        AllowManualPosting  BIT           NOT NULL,
        ShowInVoucherLookup BIT           NOT NULL,
        Notes               NVARCHAR(500) NULL
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingState WHERE StateID = 1)
    INSERT dbo.Acc_PostingState VALUES
    (1, N'حساب نظام (ابن) لا يُمس', 0, 0, 0, 0,
        N'مثل حساب مورد: يُنشأ آليًا، لا يُنشأ تحته شيء، ولا قيد يدوي عليه، ولا يظهر في بحث القيد.');
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingState WHERE StateID = 2)
    INSERT dbo.Acc_PostingState VALUES
    (2, N'حساب نظام مقفل', 0, 0, 1, 1,
        N'حساب عادي من حيث القيد والظهور، لكنه لا يُحذف ولا يُنقل ولا يُعدَّل إلا اسمه.');
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingState WHERE StateID = 3)
    INSERT dbo.Acc_PostingState VALUES
    (3, N'أب آلي: أبناؤه يولَّدون آليًا فقط', 0, 1, 0, 0,
        N'مثل «الموردون»: يولّد النظام تحته حساب كل طرف، ولا يُنشئ المحاسب تحته شيئًا.');
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingState WHERE StateID = 4)
    INSERT dbo.Acc_PostingState VALUES
    (4, N'أب: يسمح بإنشاء أبناء يدويًا أيضًا', 1, 1, 0, 0,
        N'كالحالة 3 لكن يُسمح للمحاسب بإضافة أبناء من واجهة الشجرة (يظهر زر الإضافة).');
GO

/* ---------------------------------------------------------------------
   2) العمليات (رقم + اسم). تُضاف الصفوف من جهتك.
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Acc_Operation', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_Operation
    (
        OpID   SMALLINT      NOT NULL CONSTRAINT PK_Acc_Operation PRIMARY KEY,
        OpName NVARCHAR(100) NOT NULL CONSTRAINT UQ_Acc_Operation_Name UNIQUE
    );
END;
GO

/* ---------------------------------------------------------------------
   3) التوجيهات: حساب واحد لا يرتبط إلا بتوجيه واحد.
      الشركة تُستنتج من الحساب (AccCompany).
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Acc_PostingRule', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_PostingRule
    (
        RuleID       INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_PostingRule PRIMARY KEY,
        OpID         SMALLINT     NOT NULL,
        AccID        BIGINT       NOT NULL,
        StateID      TINYINT      NOT NULL,
        RuleDateTime DATETIME2(0) NOT NULL
            CONSTRAINT DF_Acc_PostingRule_DateTime DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Acc_PostingRule_Acc UNIQUE (AccID)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id = OBJECT_ID(N'dbo.Acc_PostingRule') AND name = N'FK_Acc_PostingRule_Op')
    ALTER TABLE dbo.Acc_PostingRule WITH CHECK
    ADD CONSTRAINT FK_Acc_PostingRule_Op FOREIGN KEY (OpID) REFERENCES dbo.Acc_Operation (OpID);
GO
-- الحساب المرتبط لا يُحذف (NO ACTION)
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id = OBJECT_ID(N'dbo.Acc_PostingRule') AND name = N'FK_Acc_PostingRule_Acc')
    ALTER TABLE dbo.Acc_PostingRule WITH CHECK
    ADD CONSTRAINT FK_Acc_PostingRule_Acc FOREIGN KEY (AccID) REFERENCES dbo.Acc_Account (AccID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id = OBJECT_ID(N'dbo.Acc_PostingRule') AND name = N'FK_Acc_PostingRule_State')
    ALTER TABLE dbo.Acc_PostingRule WITH CHECK
    ADD CONSTRAINT FK_Acc_PostingRule_State FOREIGN KEY (StateID) REFERENCES dbo.Acc_PostingState (StateID);
GO

/* ---------------------------------------------------------------------
   4) علامة إجراءات النظام
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE dbo.Acc_SystemOperationBegin
AS
BEGIN
    SET NOCOUNT ON;
    EXEC sys.sp_set_session_context @key = N'Acc.SystemOperation', @value = 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SystemOperationEnd
AS
BEGIN
    SET NOCOUNT ON;
    EXEC sys.sp_set_session_context @key = N'Acc.SystemOperation', @value = NULL;
END;
GO

/* ---------------------------------------------------------------------
   5) تريجر حماية الحسابات
      SET XACT_ABORT ON: عند الرفض يتراجع التغيير نفسه (لا يبقى أثر).
   --------------------------------------------------------------------- */
CREATE OR ALTER TRIGGER dbo.trg_Acc_Account_Protect
ON dbo.Acc_Account
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Acc.SystemOperation')), 0) = 1
        RETURN;

    DECLARE @HasIns BIT = IIF(EXISTS (SELECT 1 FROM inserted), 1, 0);
    DECLARE @HasDel BIT = IIF(EXISTS (SELECT 1 FROM deleted), 1, 0);

    IF @HasIns = 0 AND @HasDel = 0 RETURN;

    /* حذف */
    IF @HasIns = 0 AND @HasDel = 1
    BEGIN
        IF EXISTS (SELECT 1 FROM deleted AS d
                   JOIN dbo.Acc_PostingRule AS r ON r.AccID = d.AccID)
            THROW 50201, N'لا يجوز حذف حساب نظام (مرتبط بتوجيه حسابي).', 1;
        RETURN;
    END;

    /* إدراج: ممنوع تحت أب نظام لا يسمح بالإنشاء اليدوي */
    IF @HasIns = 1 AND @HasDel = 0
    BEGIN
        IF EXISTS (SELECT 1
                   FROM inserted AS i
                   JOIN dbo.Acc_PostingRule  AS pr ON pr.AccID = i.AccParentID
                   JOIN dbo.Acc_PostingState AS s  ON s.StateID = pr.StateID
                   WHERE s.AllowManualChildren = 0)
            THROW 50202, N'لا يجوز إنشاء حساب تحت هذا الحساب يدويًا؛ حسابات النظام تُنشأ آليًا من واجهتها الخاصة.', 1;
        RETURN;
    END;

    /* تعديل */
    IF EXISTS (SELECT 1
               FROM inserted AS i
               JOIN deleted  AS d ON d.AccID = i.AccID
               JOIN dbo.Acc_PostingRule AS r ON r.AccID = i.AccID
               WHERE ISNULL(i.AccParentID, -1) <> ISNULL(d.AccParentID, -1)
                  OR i.AccEnd     <> d.AccEnd
                  OR i.AccType    <> d.AccType
                  OR i.AccLevel   <> d.AccLevel
                  OR i.AccCompany <> d.AccCompany
                  OR i.AccState   <> d.AccState)
        THROW 50203, N'حساب نظام: المسموح تعديل الاسم فقط، ولا يُنقل ولا يتغير تصنيفه.', 1;

    IF EXISTS (SELECT 1
               FROM inserted AS i
               JOIN deleted  AS d ON d.AccID = i.AccID
               JOIN dbo.Acc_PostingRule  AS pr ON pr.AccID = i.AccParentID
               JOIN dbo.Acc_PostingState AS s  ON s.StateID = pr.StateID
               WHERE ISNULL(i.AccParentID, -1) <> ISNULL(d.AccParentID, -1)
                 AND s.AllowManualChildren = 0)
        THROW 50204, N'لا يجوز نقل حساب إلى أب هو حساب نظام لا يسمح بالإنشاء اليدوي تحته.', 1;
END;
GO

/* ---------------------------------------------------------------------
   6) تريجر حماية جدول التوجيهات نفسه
   --------------------------------------------------------------------- */
CREATE OR ALTER TRIGGER dbo.trg_Acc_PostingRule_Guard
ON dbo.Acc_PostingRule
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Acc.SystemOperation')), 0) = 1
        RETURN;

    -- تعديل التوجيه أو حذفه يرفع الحماية عن الحساب، فلا يتم إلا بعلامة النظام
    IF EXISTS (SELECT 1 FROM deleted)
        THROW 50212, N'لا يُعدَّل التوجيه الحسابي ولا يُحذف إلا بإجراء النظام المعتمد.', 1;

    -- الحالة 1 (ابن لا يُمس) لا تقبل حسابًا له أبناء
    IF EXISTS (SELECT 1
               FROM inserted AS i
               WHERE i.StateID = 1
                 AND EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = i.AccID))
        THROW 50211, N'الحالة 1 (ابن لا يُمس) لا تُطبَّق على حساب له أبناء.', 1;
END;
GO

/* ---------------------------------------------------------------------
   7) فحص: ما يخالف القواعد (يُرجع صفوفًا؛ لا شيء = سليم)
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE dbo.Acc_CheckProtectedAccounts
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;

    -- 1) حساب بحالة 1 وله أبناء
    SELECT N'حالة 1 وله أبناء' AS Problem, a.AccID, a.AccCode, a.AccName
    FROM dbo.Acc_PostingRule AS r
    JOIN dbo.Acc_Account AS a ON a.AccID = r.AccID
    WHERE a.AccCompany = @Cmp AND r.StateID = 1
      AND EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    UNION ALL
    -- 2) ابن لحساب نظام لا يسمح بالإنشاء اليدوي وليس مسجلًا في التوجيهات (تجاوز)
    SELECT N'ابن غير مسجّل تحت حساب نظام مقفل', c.AccID, c.AccCode, c.AccName
    FROM dbo.Acc_Account AS c
    JOIN dbo.Acc_PostingRule  AS pr ON pr.AccID = c.AccParentID
    JOIN dbo.Acc_PostingState AS s  ON s.StateID = pr.StateID
    WHERE c.AccCompany = @Cmp AND s.AllowManualChildren = 0
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingRule AS x WHERE x.AccID = c.AccID)
    UNION ALL
    -- 3) أب آلي بلا عرض أبناء (AccChid = 0) لن يستطيع النظام توليد رموز أبنائه
    SELECT N'أب آلي بلا تحديد لخانات رمز الأبناء (AccChid = 0)', a.AccID, a.AccCode, a.AccName
    FROM dbo.Acc_PostingRule AS r
    JOIN dbo.Acc_PostingState AS s ON s.StateID = r.StateID
    JOIN dbo.Acc_Account AS a ON a.AccID = r.AccID
    WHERE a.AccCompany = @Cmp AND s.AllowAutoChildren = 1 AND a.AccChid = 0
    ORDER BY 1, 3;
END;
GO

/* ---------------------------------------------------------------------
   8) قائمة الحسابات المسموح اختيارها في القيد اليدوي (للقوائم)
      يخفي حسابات النظام التي ShowInVoucherLookup = 0.
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE dbo.Acc_SelectAccountWithBalnce
    @Cmp  INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
            @To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);

    ;WITH Tree AS
    (
        SELECT a.AccID,
               CAST(N'' AS NVARCHAR(4000)) AS AccParintName,
               0 AS Lvl
        FROM dbo.Acc_Account AS a
        WHERE a.AccCompany = @Cmp
          AND a.AccParentID IS NULL

        UNION ALL

        SELECT c.AccID,
               CAST(CASE WHEN t.AccParintName = N'' THEN p.AccName
                         ELSE t.AccParintName + N' / ' + p.AccName END AS NVARCHAR(4000)),
               t.Lvl + 1
        FROM dbo.Acc_Account AS c
        JOIN Tree AS t ON c.AccParentID = t.AccID
        JOIN dbo.Acc_Account AS p ON p.AccID = t.AccID
        WHERE c.AccCompany = @Cmp
          AND t.Lvl < 30
    ),
    Mov AS
    (
        SELECT d.DayDAccID AS AccID,
               SUM(d.DayDDeb) AS Deb,
               SUM(d.DayDCrd) AS Crd
        FROM dbo.Acc_DayMaster AS m
        JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
        WHERE m.DayMState BETWEEN 1 AND 7
          AND m.DayMDate >= @From
          AND m.DayMDate < @To
        GROUP BY d.DayDAccID
    )
    SELECT a.AccID,
           a.AccCode,
           a.AccName,
           a.AccState,
           t.AccParintName,
           CASE WHEN t.AccParintName = N'' THEN a.AccName
                ELSE t.AccParintName + N' / ' + a.AccName END AS Parents,
           CASE WHEN ISNULL(x.Deb, 0) > ISNULL(x.Crd, 0)
                THEN x.Deb - x.Crd ELSE 0 END AS AccDebet,
           CASE WHEN ISNULL(x.Crd, 0) > ISNULL(x.Deb, 0)
                THEN x.Crd - x.Deb ELSE 0 END AS AccCridit,
           a.AccCompany
    FROM dbo.Acc_Account AS a
    JOIN Tree AS t ON t.AccID = a.AccID
    LEFT JOIN Mov AS x ON x.AccID = a.AccID
    WHERE a.AccState = 0
      AND a.AccChid = 0
      AND a.AccCompany = @Cmp
      AND NOT EXISTS (SELECT 1
                      FROM dbo.Acc_PostingRule  AS r
                      JOIN dbo.Acc_PostingState AS s ON s.StateID = r.StateID
                      WHERE r.AccID = a.AccID
                        AND s.ShowInVoucherLookup = 0)
    ORDER BY a.AccCode;
END;
GO

PRINT N'تم إنشاء التوجيهات الحسابية وحماية حسابات النظام.';
GO

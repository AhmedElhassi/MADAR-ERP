﻿/* =====================================================================
   اختبار التوجيهات الحسابية وحماية حسابات النظام
   كل اختبار يعمل في معاملة مستقلة تنتهي بـ ROLLBACK: لا يبقى حساب تجريبي.
   (سبب الفصل: رفض التريجر يُلغي المعاملة الحالية، فلا يمكن جمع الاختبارات في معاملة واحدة.)
   قبل التشغيل نفّذ: Acc_PostingRules.sql ثم Acc_DayVoucher_Procedures.sql
   غيّر @UserId (مستخدم موجود في Mng_User) ثم نفّذ الملف كله.
   النتيجة: أسطر PASS / FAIL في تبويب Messages.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;

DECLARE @Cmp    INT    = 10;
DECLARE @UserId BIGINT = 1;       -- رقم مستخدم موجود في Mng_User
DECLARE @Year   INT    = 2026;

IF OBJECT_ID(N'dbo.Acc_PostingRule') IS NULL OR OBJECT_ID(N'dbo.Acc_CheckProtectedAccounts') IS NULL
   OR TYPE_ID(N'dbo.Acc_DayLineType') IS NULL
BEGIN
    RAISERROR(N'نفّذ أولًا Acc_PostingRules.sql ثم Acc_DayVoucher_Procedures.sql.', 16, 1);
    RETURN;
END;

IF @@TRANCOUNT > 0
BEGIN
    RAISERROR(N'يوجد معاملة مفتوحة في هذه الجلسة. أغلقها ثم أعد التشغيل.', 16, 1);
    RETURN;
END;

/* جداول مؤقتة تلتقط نتائج الإجراءات داخل الدفعات الديناميكية */
CREATE TABLE #R   (DayMID BIGINT, DayMNo INT, DayMState TINYINT, VoucherNo NVARCHAR(50));
CREATE TABLE #L   (AccID BIGINT, AccCode NVARCHAR(60), AccName NVARCHAR(500), AccState TINYINT,
                   AccParintName NVARCHAR(MAX), Parents NVARCHAR(MAX),
                   AccDebet DECIMAL(38,3), AccCridit DECIMAL(38,3), AccCompany INT);
CREATE TABLE #P   (Problem NVARCHAR(200), AccID BIGINT, AccCode NVARCHAR(60), AccName NVARCHAR(500));
-- نفس أعمدة Acc_Account لالتقاط SELECT * من Acc_UpdaeAccounting (دون خاصية IDENTITY)
SELECT TOP (0) AccID + CAST(0 AS BIGINT) AS AccID, AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid,
       AccCode, AccName, AccState, AccDateTime, AccUser, AccCompany
INTO #Acc0 FROM dbo.Acc_Account;

DECLARE @Setup NVARCHAR(MAX) = N'
DECLARE @Root BIGINT, @P BIGINT, @C1 BIGINT, @N BIGINT, @X BIGINT;
INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
VALUES (1, 1, NULL, 1, 1, 2, N''ZZT'', N''اختبار جذر'', @U, @Cmp);
SET @Root = CONVERT(BIGINT, SCOPE_IDENTITY());
INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
VALUES (1, 1, @Root, 1, 2, 2, N''ZZT01'', N''اختبار أب'', @U, @Cmp);
SET @P = CONVERT(BIGINT, SCOPE_IDENTITY());
INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
VALUES (1, 1, @P, 1, 3, 0, N''ZZT0101'', N''اختبار ابن'', @U, @Cmp);
SET @C1 = CONVERT(BIGINT, SCOPE_IDENTITY());
INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
VALUES (1, 1, @Root, 2, 2, 0, N''ZZT02'', N''اختبار عادي'', @U, @Cmp);
SET @N = CONVERT(BIGINT, SCOPE_IDENTITY());
INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
VALUES (1, 1, @Root, 3, 2, 0, N''ZZT03'', N''اختبار عادي 2'', @U, @Cmp);
SET @X = CONVERT(BIGINT, SCOPE_IDENTITY());
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Operation WHERE OpID = 32000)
    INSERT dbo.Acc_Operation (OpID, OpName) VALUES (32000, N''ZZ عملية اختبار'');
';

/* قائمة الاختبارات: الاسم، النص، الخطأ المتوقع (0 = ينجح)، خطأ بديل مقبول */
DECLARE @T TABLE (Id INT IDENTITY(1,1), Name NVARCHAR(300), Body NVARCHAR(MAX), E1 INT, E2 INT);

INSERT @T (Name, Body, E1, E2) VALUES
(N'T1 إنشاء ابن يدويًا تحت أب آلي (حالة 3) = خطأ 50202',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
   VALUES (1, 1, @P, 2, 3, 0, N''ZZT0102'', N''ابن يدوي'', @U, @Cmp);', 50202, 50202),

(N'T2 إنشاء ابن بعلامة النظام تحت أب آلي = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   EXEC dbo.Acc_SystemOperationBegin;
   INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
   VALUES (1, 1, @P, 2, 3, 0, N''ZZT0102'', N''ابن آلي'', @U, @Cmp);
   EXEC dbo.Acc_SystemOperationEnd;', 0, 0),

(N'T3 إنشاء ابن يدويًا تحت أب حالة 4 = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 4);
   INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
   VALUES (1, 1, @P, 2, 3, 0, N''ZZT0102'', N''ابن يدوي'', @U, @Cmp);', 0, 0),

(N'T4 تعديل اسم حساب نظام = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   UPDATE dbo.Acc_Account SET AccName = N''اسم جديد'' WHERE AccID = @C1;
   IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @C1 AND AccName = N''اسم جديد'') THROW 59999, N''لم يتغير الاسم'', 1;', 0, 0),

(N'T5 تغيير ترتيب ورمز حساب نظام (ناتج إعادة الترقيم) = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   UPDATE dbo.Acc_Account SET AccOrder = 5, AccCode = N''ZZT0105'' WHERE AccID = @C1;', 0, 0),

(N'T6 نقل حساب نظام إلى أب آخر = خطأ 50203',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   UPDATE dbo.Acc_Account SET AccParentID = @Root, AccLevel = 2 WHERE AccID = @C1;', 50203, 50203),

(N'T7 تغيير تصنيف حساب نظام = خطأ 50203',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   UPDATE dbo.Acc_Account SET AccType = 0 WHERE AccID = @C1;', 50203, 50203),

(N'T8 حذف حساب نظام = خطأ (547 أو 50201)',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   DELETE dbo.Acc_Account WHERE AccID = @C1;', 547, 50201),

(N'T9 نقل حساب عادي إلى أب آلي = خطأ 50204',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   UPDATE dbo.Acc_Account SET AccParentID = @P, AccLevel = 3 WHERE AccID = @X;', 50204, 50204),

(N'T10 تعديل توجيه قائم بلا علامة = خطأ 50212',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   UPDATE dbo.Acc_PostingRule SET StateID = 2 WHERE AccID = @P;', 50212, 50212),

(N'T11 حذف توجيه بلا علامة = خطأ 50212',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   DELETE dbo.Acc_PostingRule WHERE AccID = @P;', 50212, 50212),

(N'T12 حذف توجيه بعلامة النظام = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   EXEC dbo.Acc_SystemOperationBegin;
   DELETE dbo.Acc_PostingRule WHERE AccID = @P;
   EXEC dbo.Acc_SystemOperationEnd;', 0, 0),

(N'T13 الحالة 1 على حساب له أبناء = خطأ 50211',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 1);', 50211, 50211),

(N'T14 قيد يدوي على حساب نظام (حالة 1) = خطأ 50114',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   DECLARE @L dbo.Acc_DayLineType;
   INSERT @L VALUES (1, @C1, 100, 0, NULL, NULL, NULL), (2, @N, 0, 100, NULL, NULL, NULL);
   INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Yr, @User = @U, @DayMID = 0,
        @Date = ''2026-05-10'', @Info = N''TEST'', @Post = 0, @Lines = @L;', 50114, 50114),

(N'T15 قيد بعلامة النظام على حساب حالة 1 = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   DECLARE @L dbo.Acc_DayLineType;
   INSERT @L VALUES (1, @C1, 100, 0, NULL, NULL, NULL), (2, @N, 0, 100, NULL, NULL, NULL);
   EXEC dbo.Acc_SystemOperationBegin;
   INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Yr, @User = @U, @DayMID = 0,
        @Date = ''2026-05-10'', @Info = N''TEST'', @Post = 1, @Lines = @L;
   EXEC dbo.Acc_SystemOperationEnd;', 0, 0),

(N'T16 قيد يدوي على حساب نظام مقفل (حالة 2) = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 2);
   DECLARE @L dbo.Acc_DayLineType;
   INSERT @L VALUES (1, @C1, 100, 0, NULL, NULL, NULL), (2, @N, 0, 100, NULL, NULL, NULL);
   INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Yr, @User = @U, @DayMID = 0,
        @Date = ''2026-05-10'', @Info = N''TEST'', @Post = 0, @Lines = @L;', 0, 0),

(N'T17 بحث الحسابات: حالة 1 مخفي، حالة 2 والعادي ظاهران',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1), (32000, @N, 2);
   INSERT #L EXEC dbo.Acc_SelectAccountWithBalnce @Cmp = @Cmp, @Year = @Yr;
   IF EXISTS (SELECT 1 FROM #L WHERE AccID = @C1) THROW 59999, N''الحساب المحمي ظاهر'', 1;
   IF NOT EXISTS (SELECT 1 FROM #L WHERE AccID = @N) THROW 59999, N''حساب الحالة 2 غير ظاهر'', 1;
   IF NOT EXISTS (SELECT 1 FROM #L WHERE AccID = @X) THROW 59999, N''الحساب العادي غير ظاهر'', 1;', 0, 0),

(N'T18 تعديل الاسم عبر Acc_UpdaeAccounting (يعيد ترقيم الشركة كلها) على حساب نظام = ينجح',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @C1, 1);
   INSERT #Acc0 EXEC dbo.Acc_UpdaeAccounting @AccName = N''اسم بعد الترقيم'', @original_AccID = @C1, @AccUser = @U, @Cmp = @Cmp;
   IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @C1 AND AccName = N''اسم بعد الترقيم'' AND AccParentID = @P)
       THROW 59999, N''الاسم أو الأب تغيّر بشكل غير متوقع'', 1;', 0, 0),

(N'T19 فحص Acc_CheckProtectedAccounts يكشف ابنًا غير مسجّل تحت أب آلي',
 N'INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (32000, @P, 3);
   INSERT #P EXEC dbo.Acc_CheckProtectedAccounts @Cmp = @Cmp;
   IF NOT EXISTS (SELECT 1 FROM #P WHERE AccID = @C1 AND Problem LIKE N''ابن غير مسجّل%'') THROW 59999, N''لم يكشف المخالفة'', 1;', 0, 0);

DECLARE @Pass INT = 0, @Fail INT = 0;
DECLARE @Id INT, @Name NVARCHAR(300), @Body NVARCHAR(MAX), @E1 INT, @E2 INT, @Sql NVARCHAR(MAX), @en INT, @ok BIT;

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT Id, Name, Body, E1, E2 FROM @T ORDER BY Id;
OPEN cur;
FETCH NEXT FROM cur INTO @Id, @Name, @Body, @E1, @E2;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @en = NULL;
    TRUNCATE TABLE #R; TRUNCATE TABLE #L; TRUNCATE TABLE #P; TRUNCATE TABLE #Acc0;

    SET @Sql = N'SET XACT_ABORT OFF;
        BEGIN TRY
            BEGIN TRAN;' + @Setup + @Body + N'
            SET @e = 0;
        END TRY
        BEGIN CATCH
            SET @e = ERROR_NUMBER();
        END CATCH;
        IF @@TRANCOUNT > 0 ROLLBACK;';

    BEGIN TRY
        EXEC sys.sp_executesql @Sql, N'@U BIGINT, @Cmp INT, @Yr INT, @e INT OUTPUT',
             @U = @UserId, @Cmp = @Cmp, @Yr = @Year, @e = @en OUTPUT;
    END TRY
    BEGIN CATCH
        SET @en = -ERROR_NUMBER();       -- خطأ في الاختبار نفسه
        IF @@TRANCOUNT > 0 ROLLBACK;
    END CATCH;

    EXEC dbo.Acc_SystemOperationEnd;     -- لا تبقى علامة النظام مفتوحة بين الاختبارات

    SET @ok = CASE WHEN @en IN (@E1, @E2) THEN 1 ELSE 0 END;

    IF @ok = 1
    BEGIN
        SET @Pass += 1;
        PRINT N'PASS - ' + @Name;
    END
    ELSE
    BEGIN
        SET @Fail += 1;
        PRINT N'FAIL - ' + @Name + N'  | الخطأ الفعلي: ' + ISNULL(CONVERT(NVARCHAR(20), @en), N'لم يُنفَّذ')
              + N'  | المتوقع: ' + CONVERT(NVARCHAR(20), @E1)
              + CASE WHEN @E2 <> @E1 THEN N' أو ' + CONVERT(NVARCHAR(20), @E2) ELSE N'' END;
    END;

    FETCH NEXT FROM cur INTO @Id, @Name, @Body, @E1, @E2;
END;
CLOSE cur; DEALLOCATE cur;

PRINT N'الإجمالي: ' + CONVERT(NVARCHAR(10), @Pass + @Fail) + N' اختبار | نجح: ' + CONVERT(NVARCHAR(10), @Pass)
      + N' | فشل: ' + CONVERT(NVARCHAR(10), @Fail);
PRINT N'تم التراجع عن كل الحسابات والتوجيهات التجريبية (كل اختبار في معاملة مستقلة).';

DROP TABLE #R; DROP TABLE #L; DROP TABLE #P; DROP TABLE #Acc0;
GO

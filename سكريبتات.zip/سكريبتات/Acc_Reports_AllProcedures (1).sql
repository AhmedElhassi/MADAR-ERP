/* ====== كل إجراءات التقارير المالية بعد اعتماد الحالات 1 إلى 7 (كل ما عدا المؤقت) ======
   نفّذ الملف كاملًا مرة واحدة على MADARERPDataBase. كل إجراء CREATE OR ALTER. */
USE [MADARERPDataBase];
GO

/* ---------- Acc_SelectAccBalanceSheet ---------- */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   الميزانية العمومية
   ---------------------------------------------------------------------
   القواعد المحاسبية:
   - القيود المرحّلة فقط (DayMState BETWEEN 1 AND 7) للشركة @Cmp، حتى @ToDate.
   - الرصيد السابق = كل الحركات قبل @FromDate من كل السنوات.
   - القيد يُسجَّل على الحسابات التحليلية فقط؛ تُجمَّع نحو الآباء تصاعديًّا.
   - الأصول (AccType=0) = الرصيد المدين، الخصوم (1) وحقوق الملكية (2) = الرصيد الدائن.
   - السنة المالية لا تُقفل، فحسابات قائمة الدخل (AccEnd=2) تتراكم، وتُضاف
     إلى حقوق الملكية بصفّين مستقلين:
       * نتائج السنوات السابقة   (كل ما قبل 1 يناير من @Year)
       * نتيجة السنة الحالية     (من 1 يناير حتى @ToDate)
     وبذلك يكون: الأصول = الخصوم + حقوق الملكية + نتائج، والفرق
     BalanceDifference يساوي فرق دفتر الأستاذ فقط (صفر إن كانت القيود متوازنة).
   - مؤشرات سلامة البيانات في آخر النتيجة (يجب أن تكون أصفارًا).
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccBalanceSheet]
    @FromDate   DATE     = NULL,
    @ToDate     DATE     = NULL,
    @Cmp        INT      = 1,
    @Year       INT      = 0,
    @AllAcc     BIT      = 0,
    @MoveAcc    BIT      = 0,
    @BalnceAcc  BIT      = 0,
    @LevelAcc   TINYINT  = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Out;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #LeafIS;
    DROP TABLE IF EXISTS #LeafAmt;
    DROP TABLE IF EXISTS #Amount;
    DROP TABLE IF EXISTS #AccIS;
    DROP TABLE IF EXISTS #AccBS;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Acc;

    /* 1. التحقق من المدخلات */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year
       OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);


    /* 2. تحميل شجرة حسابات الشركة */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);


    /* 3. التحقق من الحسابات اليتيمة */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS x
              WHERE x.AccID = a.AccParentID
          )
    )
        THROW 50011, N'شجرة الحسابات تحتوي على حسابات يتيمة؛ الحساب الأب غير موجود.', 1;


    /* 4. التحقق من الربط بين الشركات */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #Acc AS p
              WHERE p.AccID = a.AccParentID
          )
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS x
              WHERE x.AccID = a.AccParentID
          )
    )
        THROW 50012, N'شجرة الحسابات تحتوي على ربط بين حسابات شركتين مختلفتين.', 1;


    /* 5. التحقق من الحلقات والحسابات غير القابلة للوصول */

    DECLARE
        @Total   BIGINT,
        @Reached BIGINT;

    SELECT @Total = COUNT_BIG(*)
    FROM #Acc;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        INNER JOIN #Acc AS c
            ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT_BIG(*)
    FROM Reach
    OPTION (MAXRECURSION 32767);

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300);

        SET @CycleMsg =
            CONCAT(
                N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول من الجذور. عدد الحسابات المتأثرة: ',
                @Total - @Reached
            );

        THROW 50010, @CycleMsg, 1;
    END;


    /* 6. تحديد عدد الأبناء الفعلي */

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);


    /* 7. حسابات الميزانية العمومية، وحسابات قائمة الدخل (لنتيجة السنة) */

    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        AccEnd,
        AccType
    INTO #AccBS
    FROM #Acc
    WHERE AccEnd = 1
      AND AccType IN (0, 1, 2);

    CREATE UNIQUE CLUSTERED INDEX IX_AccBS
        ON #AccBS (AccID);

    SELECT AccID
    INTO #AccIS
    FROM #Acc
    WHERE AccEnd = 2
      AND AccType IN (0, 1);

    CREATE UNIQUE CLUSTERED INDEX IX_AccIS
        ON #AccIS (AccID);


    /* 8. التحقق من تجانس تصنيف حسابات الميزانية مع آبائها */

    IF EXISTS
    (
        SELECT 1
        FROM #AccBS AS c
        INNER JOIN #AccBS AS p
            ON p.AccID = c.AccParentID
        WHERE c.AccType <> p.AccType
    )
        THROW 50013, N'يوجد اختلاف في تصنيف الحساب عن تصنيف الحساب الأب في الميزانية.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #AccBS AS c
        INNER JOIN #Acc AS p
            ON p.AccID = c.AccParentID
        WHERE p.AccEnd <> 1
    )
        THROW 50014, N'يوجد حساب ميزانية تابع لحساب لا ينتمي إلى الميزانية العمومية.', 1;


    /* 9. مسح واحد للحركات حتى @ToDate (كل الحسابات) */

    SELECT
        d.DayDAccID AS AccID,

        -- كل ما قبل @FromDate
        CAST(SUM(CASE WHEN m.DayMDate < @FromDate
                      THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS OpenNet,

        -- كل ما قبل 1 يناير من السنة (لنتائج السنوات السابقة)
        CAST(SUM(CASE WHEN m.DayMDate < @YearStart
                      THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS PriorNet,

        CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END) AS DECIMAL(28,3)) AS PerDeb,
        CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS PerCrd,

        SUM(CONVERT(BIGINT, CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)) AS PerCnt

    INTO #Amount

    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID

    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate <= @ToDate

    GROUP BY d.DayDAccID

    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount
        ON #Amount (AccID);


    /* 10. مؤشرات سلامة البيانات */

    DECLARE
        @ChkNonLeaf BIGINT = 0,
        @ChkForeign BIGINT = 0,
        @ChkChid    BIGINT = 0;

    -- حركة مسجلة على حساب أب (لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT_BIG(*)
    FROM #Amount AS am
    INNER JOIN #Kid AS k
        ON k.AccID = am.AccID;

    -- حركة على حساب لا يتبع الشركة
    SELECT @ChkForeign = COUNT_BIG(*)
    FROM #Amount AS am
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS a WHERE a.AccID = am.AccID);

    -- عدم تطابق AccChid مع الأبناء الفعليين
    SELECT @ChkChid = COUNT_BIG(*)
    FROM #Acc AS a
    LEFT JOIN #Kid AS k
        ON k.AccID = a.AccID
    WHERE (CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
        <> (CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);


    /* 11. حركات الحسابات التحليلية */

    -- الميزانية
    SELECT
        am.AccID,
        am.OpenNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    INNER JOIN #AccBS AS a
        ON a.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
        ON #LeafAmt (AccID);

    -- قائمة الدخل (لنتائج السنوات السابقة والسنة الحالية)
    SELECT
        am.AccID,
        am.OpenNet,
        am.PriorNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafIS
    FROM #Amount AS am
    INNER JOIN #AccIS AS i
        ON i.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );


    /* 12. إجماليات الأصول والخصوم وحقوق الملكية + نتائج السنوات */

    DECLARE
        @TotalAssets      DECIMAL(38,3),
        @TotalLiabilities DECIMAL(38,3),
        @TotalEquityAcc   DECIMAL(38,3),   -- حسابات حقوق الملكية فقط
        @PriorNet         DECIMAL(38,3),   -- صافي مدين قائمة الدخل قبل بداية السنة
        @CurOpenNet       DECIMAL(38,3),   -- من بداية السنة حتى قبل @FromDate
        @CurPerDeb        DECIMAL(38,3),
        @CurPerCrd        DECIMAL(38,3),
        @CurPerCnt        BIGINT,
        @PriorResult      DECIMAL(38,3),   -- نتائج السنوات السابقة (الدائن موجب)
        @CurResult        DECIMAL(38,3),   -- نتيجة السنة الحالية (الدائن موجب)
        @TotalEquity      DECIMAL(38,3);

    SELECT
        @TotalAssets =
            ISNULL(SUM(CASE WHEN a.AccType = 0 THEN  (l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalLiabilities =
            ISNULL(SUM(CASE WHEN a.AccType = 1 THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalEquityAcc =
            ISNULL(SUM(CASE WHEN a.AccType = 2 THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0)
    FROM #LeafAmt AS l
    INNER JOIN #AccBS AS a
        ON a.AccID = l.AccID;

    SELECT
        @PriorNet   = ISNULL(SUM(i.PriorNet), 0),
        @CurOpenNet = ISNULL(SUM(i.OpenNet - i.PriorNet), 0),
        @CurPerDeb  = ISNULL(SUM(i.PerDeb), 0),
        @CurPerCrd  = ISNULL(SUM(i.PerCrd), 0),
        @CurPerCnt  = ISNULL(SUM(i.PerCnt), 0)
    FROM #LeafIS AS i;

    SET @PriorResult = -@PriorNet;
    SET @CurResult   = -(@CurOpenNet + @CurPerDeb - @CurPerCrd);
    SET @TotalEquity = @TotalEquityAcc + @PriorResult + @CurResult;


    /* 13. التجميع التصاعدي من الحسابات التحليلية إلى الآباء */

    ;WITH RollUp AS
    (
        SELECT
            l.AccID AS NodeID,
            l.OpenNet,
            l.PerDeb,
            l.PerCrd,
            l.PerCnt
        FROM #LeafAmt AS l

        UNION ALL

        SELECT
            p.AccID AS NodeID,
            r.OpenNet,
            r.PerDeb,
            r.PerCrd,
            r.PerCnt
        FROM RollUp AS r
        INNER JOIN #AccBS AS c
            ON c.AccID = r.NodeID
        INNER JOIN #AccBS AS p
            ON p.AccID = c.AccParentID
           AND c.AccParentID > 0
    ),
    RollTotals AS
    (
        SELECT
            NodeID AS AccID,
            SUM(OpenNet) AS OpenNet,
            SUM(PerDeb) AS PerDeb,
            SUM(PerCrd) AS PerCrd,
            SUM(PerCnt) AS PerCnt
        FROM RollUp
        GROUP BY NodeID
    )
    SELECT
        a.AccID,
        a.AccCode,
        a.AccName,
        a.AccParentID,
        a.AccLevel,
        a.AccChid,
        a.AccType,

        CAST(ISNULL(t.OpenNet, 0) AS DECIMAL(28,3)) AS OpenNet,
        CAST(ISNULL(t.PerDeb, 0) AS DECIMAL(28,3)) AS PerDeb,
        CAST(ISNULL(t.PerCrd, 0) AS DECIMAL(28,3)) AS PerCrd,

        ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt

    INTO #Roll

    FROM #AccBS AS a
    LEFT JOIN RollTotals AS t
        ON t.AccID = a.AccID

    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_Roll
        ON #Roll (AccID);


    /* 14. صفوف الميزانية + صفّا نتائج السنوات (Kind: 0 حساب، 1 سنوات سابقة، 2 السنة الحالية) */

    SELECT
        x.AccID,
        x.AccCode,
        x.AccName,
        x.AccLevel,
        x.AccParentID,
        p.AccName AS AccParentName,
        x.AccChid,
        x.AccType,
        CAST(CASE WHEN k.AccID IS NULL THEN 1 ELSE 0 END AS BIT) AS IsLeaf,
        x.OpenNet,
        x.PerDeb,
        x.PerCrd,
        x.PerCnt,
        CAST(0 AS TINYINT) AS Kind
    INTO #Out
    FROM #Roll AS x
    LEFT JOIN #AccBS AS p
        ON p.AccID = x.AccParentID
    LEFT JOIN #Kid AS k
        ON k.AccID = x.AccID;

    INSERT INTO #Out
    (
        AccID, AccCode, AccName, AccLevel, AccParentID, AccParentName,
        AccChid, AccType, IsLeaf, OpenNet, PerDeb, PerCrd, PerCnt, Kind
    )
    VALUES
    (
        -1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', 1, NULL, NULL,
        0, 2, 1, @PriorNet, 0, 0, 0, 1
    ),
    (
        -2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', 1, NULL, NULL,
        0, 2, 1, @CurOpenNet, @CurPerDeb, @CurPerCrd, @CurPerCnt, 2
    );


    /* 15. النتيجة النهائية */

    SELECT
        x.AccID,
        x.AccCode,
        x.AccName AS AccARName,
        x.AccLevel,
        x.AccParentID AS AccParint,
        x.AccParentName AS AccParintName,
        x.AccChid AS AccCountChid,
        x.AccType,

        CASE
            WHEN x.AccType = 0 THEN N'الأصول'
            WHEN x.AccType = 1 THEN N'الخصوم'
            WHEN x.AccType = 2 THEN N'حقوق الملكية'
        END AS AccountCategory,

        -- الرصيد السابق
        CASE WHEN x.OpenNet > 0 THEN x.OpenNet ELSE 0 END AS OldDebit,
        CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,

        -- حركة الفترة
        x.PerDeb AS NewDebit,
        x.PerCrd AS NewCredit,

        -- صافي حركة الفترة
        CASE WHEN x.PerNet > 0 THEN x.PerNet ELSE 0 END AS BalanceDebit,
        CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,

        -- الرصيد الختامي
        CASE WHEN x.CloseNet > 0 THEN x.CloseNet ELSE 0 END AS TotBlcDebit,
        CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,

        x.CloseNet AS NetBalance,
        x.PerCnt AS MovementCount,

        CAST(CASE WHEN x.Kind = 2 THEN 1 ELSE 0 END AS BIT) AS IsCurrentYearResult,

        @TotalAssets AS TotalAssets,
        @TotalLiabilities AS TotalLiabilities,
        @TotalEquity AS TotalEquity,

        @TotalAssets - (@TotalLiabilities + @TotalEquity)
            AS BalanceDifference,

        CAST(CASE WHEN x.Kind = 1 THEN 1 ELSE 0 END AS BIT) AS IsPriorYearsResult,
        @PriorResult AS PriorYearsResult,
        @CurResult   AS CurrentYearResult,

        -- مؤشرات سلامة البيانات
        @ChkNonLeaf AS ChkNonLeafAccounts,
        @ChkForeign AS ChkForeignAccounts,
        @ChkChid    AS ChkChidMismatch

    FROM
    (
        SELECT
            o.*,

            CAST(o.PerDeb - o.PerCrd AS DECIMAL(28,3)) AS PerNet,

            CAST(o.OpenNet + o.PerDeb - o.PerCrd AS DECIMAL(28,3)) AS CloseNet

        FROM #Out AS o
    ) AS x

    WHERE
        -- صفّا النتائج يظهران دائمًا (ولا يخضعان لفلاتر العرض إلا الحركة والرصيد)
        (
            x.Kind > 0
            OR
            (
                (@AllAcc = 0 OR x.IsLeaf = 1)

                AND
                (
                    @LevelAcc = 0
                    OR x.AccLevel = @LevelAcc
                    OR (x.AccLevel < @LevelAcc AND x.IsLeaf = 1)
                )
            )
        )

        AND (@MoveAcc = 0 OR x.PerCnt > 0)

        AND (@BalnceAcc = 0 OR x.CloseNet <> 0)

    ORDER BY
        x.Kind,
        x.AccCode,
        x.AccID

    OPTION (RECOMPILE);

END;
GO
GO

/* ---------- Acc_SelectFinancialStatements ---------- */
USE [MADARERPDataBase]
GO
/****** Object:  StoredProcedure [dbo].[Acc_SelectFinancialStatements]    Script Date: 2026-10-31 3:55:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectFinancialStatements]
    @FromDate  DATE = NULL,
    @ToDate    DATE,
    @Cmp       INT = 1,
    @Year      INT = 0,
    @AllAcc    BIT = 0,
    @MoveAcc   BIT = 0,
    @BalnceAcc BIT = 0,
    @LevelAcc  TINYINT = 0
AS
BEGIN
    /* =====================================================================
       اسم التقرير : القوائم المالية (Financial Statements)
       الإجراء     : dbo.Acc_SelectFinancialStatements
       المدخلات    : @ToDate و@Cmp و@Year؛ الفترة دائمًا من 1 يناير حتى @ToDate
                     (يُتجاهل @FromDate).
       النتائج     : 1 قائمة الدخل
                     2 قائمة المركز المالي (الميزانية العمومية)
                     3 حركة حقوق الملكية
                     4 ملخص القوائم المالية
                     5 فحوص سلامة البيانات
                     6-8 قائمة التدفقات النقدية (Acc_SelectCashFlow)
                     9 ميزان المراجعة
       القواعد     : القيود المرحّلة فقط (DayMState BETWEEN 1 AND 7)؛ القيد على الحساب
                     التحليلي فقط؛ السنة لا تُقفل.
                     حقوق الملكية = حساباتها + نتائج السنوات السابقة
                     + نتيجة السنة الحالية، وفرق الميزانية (BalanceSheetDifference)
                     يجب أن يكون صفرًا إذا كانت القيود متوازنة.
       ملاحظة     : معنى @AllAcc هنا: 0 = التحليلية فقط، 1 = كل الحسابات
                     (عكس بقية إجراءات التقارير).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    /* =========================================================
       1. التحقق من المدخلات وتحديد السنة المالية
       ========================================================= */

    IF @ToDate IS NULL
        THROW 50201, N'تاريخ نهاية التقرير مطلوب.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50202, N'رقم الشركة غير صحيح.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_Company
        WHERE CmpID = @Cmp
    )
        THROW 50203, N'الشركة المحددة غير موجودة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@ToDate);

    IF @Year < 1900 OR @Year > 9999
        THROW 50204, N'السنة المالية غير صحيحة.', 1;

    IF YEAR(@ToDate) <> @Year
        THROW 50205, N'تاريخ نهاية التقرير لا يتوافق مع السنة المالية.', 1;

    SET @FromDate = DATEFROMPARTS(@Year, 1, 1);

    IF @ToDate < @FromDate
        THROW 50206, N'تاريخ نهاية التقرير يسبق بداية السنة المالية.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @ToDateExclusive DATE = DATEADD(DAY, 1, @ToDate);

    IF OBJECT_ID(N'dbo.Acc_SelectCashFlow', N'P') IS NULL
        THROW 50208, N'إجراء التدفقات النقدية غير موجود.', 1;


    /* =========================================================
       2. تحميل شجرة حسابات الشركة
       ========================================================= */

    DROP TABLE IF EXISTS #Acc;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Leaf;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #JournalBalance;
    DROP TABLE IF EXISTS #BsOut;
    DROP TABLE IF EXISTS #EqOut;

    SELECT
        A.AccID,
        A.AccParentID,
        A.AccLevel,
        CAST(ISNULL(A.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(A.AccCode, N'') AS AccCode,
        ISNULL(A.AccName, N'') AS AccName,
        A.AccEnd,
        A.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS A
    WHERE A.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50209, N'لا توجد حسابات مسجلة للشركة المحددة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_FS_AccParent
        ON #Acc (AccParentID);


    /* =========================================================
       3. التحقق من سلامة الشجرة
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        WHERE C.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS P
              WHERE P.AccID = C.AccParentID
          )
    )
        THROW 50210, N'توجد حسابات يتيمة؛ الحساب الأب غير موجود.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        INNER JOIN dbo.Acc_Account AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccParentID > 0
          AND P.AccCompany <> @Cmp
    )
        THROW 50211, N'توجد علاقة أب وابن بين حسابات شركتين مختلفتين.', 1;

    DECLARE
        @AccountCount BIGINT,
        @ReachCount BIGINT;

    SELECT @AccountCount = COUNT_BIG(*)
    FROM #Acc;

    ;WITH AccountReach AS
    (
        SELECT AccID
        FROM #Acc
        WHERE AccParentID IS NULL
           OR AccParentID = 0

        UNION ALL

        SELECT C.AccID
        FROM #Acc AS C
        INNER JOIN AccountReach AS P
            ON C.AccParentID = P.AccID
    )
    SELECT @ReachCount = COUNT_BIG(*)
    FROM AccountReach
    OPTION (MAXRECURSION 32767);

    IF ISNULL(@ReachCount, 0) <> @AccountCount
        THROW 50212, N'توجد دورة أو حسابات غير مرتبطة بجذر شجرة الحسابات.', 1;


    /* =========================================================
       4. التحقق من التصنيف المالي

       الميزانية:
       AccEnd = 1
       AccType = 0 أصول
       AccType = 1 خصوم
       AccType = 2 حقوق ملكية

       قائمة الدخل:
       AccEnd = 2
       AccType = 0 إيرادات
       AccType = 1 مصروفات
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc
        WHERE AccEnd IS NULL
           OR AccType IS NULL
           OR NOT
           (
               (AccEnd = 1 AND AccType IN (0,1,2))
               OR
               (AccEnd = 2 AND AccType IN (0,1))
           )
    )
        THROW 50213, N'توجد حسابات بتصنيف مالي غير صحيح.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        INNER JOIN #Acc AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccEnd <> P.AccEnd
           OR C.AccType <> P.AccType
    )
        THROW 50214, N'يوجد اختلاف في التصنيف المالي بين حساب أب وأحد أبنائه.', 1;


    /* =========================================================
       5. تحديد الأبناء الفعليين
       ========================================================= */

    SELECT
        AccParentID AS AccID,
        COUNT_BIG(*) AS ChildCount
    INTO #Kid
    FROM #Acc
    WHERE AccParentID IS NOT NULL
      AND AccParentID > 0
    GROUP BY AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Kid
        ON #Kid (AccID);


    /* =========================================================
       6. فحص القيود المؤرشفة غير المتوازنة
       ========================================================= */

    SELECT
        M.DayMID,
        SUM(CONVERT(DECIMAL(38,3), D.DayDDeb)) AS TotalDebit,
        SUM(CONVERT(DECIMAL(38,3), D.DayDCrd)) AS TotalCredit
    INTO #JournalBalance
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate < @ToDateExclusive
    GROUP BY M.DayMID;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_JournalBalance
        ON #JournalBalance (DayMID);

    DECLARE
        @UnbalancedJournalCount BIGINT = 0,
        @ForeignAccountCount BIGINT = 0,
        @OrphanAccountCount BIGINT = 0,
        @CrossCompanyParentCount BIGINT = 0,
        @InvalidClassCount BIGINT = 0,
        @NonLeafPostingCount BIGINT = 0;

    SELECT @UnbalancedJournalCount = COUNT_BIG(*)
    FROM #JournalBalance
    WHERE ABS(TotalDebit - TotalCredit) >= 0.001;


    /* =========================================================
       7. تجميع حركات الحسابات التحليلية
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccParentID,
        A.AccLevel,
        A.AccChid,
        A.AccEnd,
        A.AccType,

        SUM
        (
            CASE
                WHEN M.DayMDate < @FromDate
                THEN
                    CONVERT(DECIMAL(38,3), D.DayDDeb)
                    - CONVERT(DECIMAL(38,3), D.DayDCrd)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS OpeningNet,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(38,3), D.DayDDeb)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS PeriodDebit,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(38,3), D.DayDCrd)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS PeriodCredit,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(BIGINT, 1)
                ELSE CONVERT(BIGINT, 0)
            END
        ) AS MovementCount

    INTO #Leaf
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    INNER JOIN #Acc AS A
        ON A.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate < @ToDateExclusive
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Kid AS K
          WHERE K.AccID = A.AccID
      )
    GROUP BY
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccParentID,
        A.AccLevel,
        A.AccChid,
        A.AccEnd,
        A.AccType;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Leaf
        ON #Leaf (AccID);


    /* =========================================================
       8. تجميع الحسابات التحليلية إلى الحسابات الأب
       ========================================================= */

    ;WITH AccountRollup AS
    (
        SELECT
            L.AccID AS NodeID,
            L.OpeningNet,
            L.PeriodDebit,
            L.PeriodCredit,
            L.MovementCount
        FROM #Leaf AS L

        UNION ALL

        SELECT
            P.AccID AS NodeID,
            R.OpeningNet,
            R.PeriodDebit,
            R.PeriodCredit,
            R.MovementCount
        FROM AccountRollup AS R
        INNER JOIN #Acc AS C
            ON C.AccID = R.NodeID
        INNER JOIN #Acc AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccParentID > 0
    )
    SELECT
        NodeID AS AccID,
        SUM(OpeningNet) AS OpeningNet,
        SUM(PeriodDebit) AS PeriodDebit,
        SUM(PeriodCredit) AS PeriodCredit,
        SUM(MovementCount) AS MovementCount
    INTO #Roll
    FROM AccountRollup
    GROUP BY NodeID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Roll
        ON #Roll (AccID);


    /* =========================================================
       9. فحوص الحركات والتصنيفات
       ========================================================= */

    SELECT
        @ForeignAccountCount = COUNT_BIG(*)
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    LEFT JOIN #Acc AS A
        ON A.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate < @ToDateExclusive
      AND A.AccID IS NULL;

    -- حركات مسجلة على حسابات أب (لا تدخل في الأرقام لأن القيد يُسجل على الحساب التحليلي فقط)
    SELECT
        @NonLeafPostingCount = COUNT_BIG(*)
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    INNER JOIN #Kid AS K
        ON K.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate < @ToDateExclusive;

    SELECT
        @OrphanAccountCount = COUNT_BIG(*)
    FROM #Acc AS C
    WHERE C.AccParentID > 0
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Acc AS P
          WHERE P.AccID = C.AccParentID
      );

    SELECT
        @CrossCompanyParentCount = COUNT_BIG(*)
    FROM #Acc AS C
    INNER JOIN dbo.Acc_Account AS P
        ON P.AccID = C.AccParentID
    WHERE P.AccCompany <> @Cmp;

    SELECT
        @InvalidClassCount = COUNT_BIG(*)
    FROM #Acc
    WHERE AccEnd IS NULL
       OR AccType IS NULL
       OR NOT
       (
           (AccEnd = 1 AND AccType IN (0,1,2))
           OR
           (AccEnd = 2 AND AccType IN (0,1))
       );


    /* =========================================================
       10. إجماليات قائمة الدخل
       ========================================================= */

    DECLARE
        @Revenue DECIMAL(38,3) = 0,
        @Expenses DECIMAL(38,3) = 0,
        @NetIncome DECIMAL(38,3) = 0;

    SELECT
        @Revenue =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN AccType = 0
                        THEN PeriodCredit - PeriodDebit
                        ELSE 0
                    END
                ),
                0
            ),
        @Expenses =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN AccType = 1
                        THEN PeriodDebit - PeriodCredit
                        ELSE 0
                    END
                ),
                0
            )
    FROM #Leaf
    WHERE AccEnd = 2;

    SET @NetIncome = @Revenue - @Expenses;

    /* السنة المالية لا تُقفل، فحسابات قائمة الدخل تتراكم:
       نتائج السنوات السابقة = كل ما قبل بداية السنة (الدائن موجب)،
       وصافي حركة حسابات قائمة الدخل خلال السنة = نتيجة السنة الحالية. */
    DECLARE
        @PriorResult DECIMAL(38,3) = 0,
        @IsDebit     DECIMAL(38,3) = 0,
        @IsCredit    DECIMAL(38,3) = 0,
        @IsCount     BIGINT = 0;

    SELECT
        @PriorResult = -ISNULL(SUM(OpeningNet), 0),
        @IsDebit     = ISNULL(SUM(PeriodDebit), 0),
        @IsCredit    = ISNULL(SUM(PeriodCredit), 0),
        @IsCount     = ISNULL(SUM(MovementCount), 0)
    FROM #Leaf
    WHERE AccEnd = 2;


    /* =========================================================
       11. إجماليات المركز المالي
       ========================================================= */

    DECLARE
        @Assets DECIMAL(38,3) = 0,
        @Liabilities DECIMAL(38,3) = 0,
        @EquityAcc DECIMAL(38,3) = 0;

    SELECT
        @Assets =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 0
                        THEN ISNULL(R.OpeningNet,0)
                           + ISNULL(R.PeriodDebit,0)
                           - ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            ),

        @Liabilities =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 1
                        THEN -ISNULL(R.OpeningNet,0)
                             - ISNULL(R.PeriodDebit,0)
                             + ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            ),

        @EquityAcc =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 2
                        THEN -ISNULL(R.OpeningNet,0)
                             - ISNULL(R.PeriodDebit,0)
                             + ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            )
    FROM #Acc AS A
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND
      (
          A.AccParentID IS NULL
          OR A.AccParentID = 0
      );


    /* =========================================================
       12. فروقات المطابقة
       ========================================================= */

    DECLARE
        @BalanceDifference DECIMAL(38,3),
        @Equity DECIMAL(38,3);

    /* حقوق الملكية = حساباتها + نتائج السنوات السابقة + نتيجة السنة الحالية */
    SET @Equity = @EquityAcc + @PriorResult + @NetIncome;

    SET @BalanceDifference =
        @Assets - @Liabilities - @Equity;



    /* =========================================================
       RESULT SET 1: قائمة الدخل
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        P.AccName AS AccParentName,
        A.AccLevel,
        A.AccChid,
        A.AccType,

        CASE
            WHEN A.AccType = 0 THEN N'إيرادات'
            WHEN A.AccType = 1 THEN N'مصروفات'
        END AS AccountCategory,

        ISNULL(R.PeriodDebit,0) AS PeriodDebit,
        ISNULL(R.PeriodCredit,0) AS PeriodCredit,

        CAST
        (
            CASE
                WHEN A.AccType = 0
                    THEN ISNULL(R.PeriodCredit,0)
                       - ISNULL(R.PeriodDebit,0)
                WHEN A.AccType = 1
                    THEN ISNULL(R.PeriodDebit,0)
                       - ISNULL(R.PeriodCredit,0)
                ELSE 0
            END
            AS DECIMAL(38,3)
        ) AS PeriodAmount,

        ISNULL(R.MovementCount,0) AS MovementCount,

        @Revenue AS TotalRevenue,
        @Expenses AS TotalExpenses,
        @NetIncome AS NetIncome

    FROM #Acc AS A
    LEFT JOIN #Acc AS P
        ON P.AccID = A.AccParentID
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 2
      AND A.AccType IN (0,1)
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ORDER BY A.AccCode, A.AccID;


    /* =========================================================
       RESULT SET 2: قائمة المركز المالي
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        P.AccName AS AccParentName,
        A.AccLevel,
        A.AccChid,
        A.AccType,

        CASE
            WHEN A.AccType = 0 THEN N'الأصول'
            WHEN A.AccType = 1 THEN N'الخصوم'
            WHEN A.AccType = 2 THEN N'حقوق الملكية'
        END AS AccountCategory,

        ISNULL(R.OpeningNet,0) AS OpeningNet,
        ISNULL(R.PeriodDebit,0) AS PeriodDebit,
        ISNULL(R.PeriodCredit,0) AS PeriodCredit,

        CAST
        (
            CASE
                WHEN A.AccType = 0
                    THEN ISNULL(R.OpeningNet,0)
                       + ISNULL(R.PeriodDebit,0)
                       - ISNULL(R.PeriodCredit,0)
                WHEN A.AccType IN (1,2)
                    THEN -ISNULL(R.OpeningNet,0)
                       - ISNULL(R.PeriodDebit,0)
                       + ISNULL(R.PeriodCredit,0)
                ELSE 0
            END
            AS DECIMAL(38,3)
        ) AS ClosingBalance,

        ISNULL(R.MovementCount,0) AS MovementCount,

        @Assets AS TotalAssets,
        @Liabilities AS TotalLiabilities,
        @Equity AS TotalEquity,
        CAST(0 AS TINYINT) AS RowKind
    INTO #BsOut

    FROM #Acc AS A
    LEFT JOIN #Acc AS P
        ON P.AccID = A.AccParentID
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND A.AccType IN (0,1,2)
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @BalnceAcc = 0
          OR
          (
              CASE
                  WHEN A.AccType = 0
                      THEN ISNULL(R.OpeningNet,0)
                         + ISNULL(R.PeriodDebit,0)
                         - ISNULL(R.PeriodCredit,0)
                  ELSE -ISNULL(R.OpeningNet,0)
                       - ISNULL(R.PeriodDebit,0)
                       + ISNULL(R.PeriodCredit,0)
              END
          ) <> 0
      )
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ALTER TABLE #BsOut ALTER COLUMN AccCode NVARCHAR(200) NULL;
    ALTER TABLE #BsOut ALTER COLUMN AccARName NVARCHAR(400) NULL;

    -- صفّا نتائج السنوات ضمن حقوق الملكية (يظهران حتى مع @AllAcc و@LevelAcc)
    IF @MoveAcc = 0 AND (@BalnceAcc = 0 OR @PriorResult <> 0)
        INSERT INTO #BsOut
        (
            AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccChid, AccType,
            AccountCategory, OpeningNet, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
            TotalAssets, TotalLiabilities, TotalEquity, RowKind
        )
        VALUES
        (
            -1, N'~1', N'نتائج السنوات السابقة', NULL, NULL, 1, 0, 2,
            N'حقوق الملكية', -@PriorResult, 0, 0, @PriorResult, 0,
            @Assets, @Liabilities, @Equity, 1
        );

    IF (@MoveAcc = 0 OR @IsCount > 0) AND (@BalnceAcc = 0 OR @NetIncome <> 0)
        INSERT INTO #BsOut
        (
            AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccChid, AccType,
            AccountCategory, OpeningNet, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
            TotalAssets, TotalLiabilities, TotalEquity, RowKind
        )
        VALUES
        (
            -2, N'~2', N'نتيجة السنة الحالية', NULL, NULL, 1, 0, 2,
            N'حقوق الملكية', 0, @IsDebit, @IsCredit, @NetIncome, @IsCount,
            @Assets, @Liabilities, @Equity, 2
        );

    SELECT *
    FROM #BsOut
    ORDER BY AccType, RowKind, AccCode, AccID;


    /* =========================================================
       RESULT SET 3: حركة حقوق الملكية
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        A.AccLevel,

        CAST
        (
            -ISNULL(R.OpeningNet,0)
            AS DECIMAL(38,3)
        ) AS OpeningEquity,

        CAST
        (
            ISNULL(R.PeriodCredit,0)
            - ISNULL(R.PeriodDebit,0)
            AS DECIMAL(38,3)
        ) AS PeriodMovement,

        CAST
        (
            -ISNULL(R.OpeningNet,0)
            - ISNULL(R.PeriodDebit,0)
            + ISNULL(R.PeriodCredit,0)
            AS DECIMAL(38,3)
        ) AS ClosingEquity,

        ISNULL(R.MovementCount,0) AS MovementCount,
        CAST(0 AS TINYINT) AS RowKind
    INTO #EqOut

    FROM #Acc AS A
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND A.AccType = 2
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ALTER TABLE #EqOut ALTER COLUMN AccCode NVARCHAR(200) NULL;
    ALTER TABLE #EqOut ALTER COLUMN AccARName NVARCHAR(400) NULL;

    IF @MoveAcc = 0
        INSERT INTO #EqOut
        (AccID, AccCode, AccARName, AccParentID, AccLevel, OpeningEquity, PeriodMovement, ClosingEquity, MovementCount, RowKind)
        VALUES
        (-1, N'~1', N'نتائج السنوات السابقة', NULL, 1, @PriorResult, 0, @PriorResult, 0, 1);

    IF @MoveAcc = 0 OR @IsCount > 0
        INSERT INTO #EqOut
        (AccID, AccCode, AccARName, AccParentID, AccLevel, OpeningEquity, PeriodMovement, ClosingEquity, MovementCount, RowKind)
        VALUES
        (-2, N'~2', N'نتيجة السنة الحالية', NULL, 1, 0, @NetIncome, @NetIncome, @IsCount, 2);

    SELECT *
    FROM #EqOut
    ORDER BY RowKind, AccCode, AccID;


    /* =========================================================
       RESULT SET 4: ملخص القوائم المالية
       ========================================================= */

    SELECT
        @Cmp AS CompanyID,
        @Year AS FinancialYear,
        @FromDate AS FromDate,
        @ToDate AS ToDate,

        @Revenue AS TotalRevenue,
        @Expenses AS TotalExpenses,
        @NetIncome AS NetIncome,
        @PriorResult AS PriorYearsResult,
        @EquityAcc AS EquityAccountsTotal,

        @Assets AS TotalAssets,
        @Liabilities AS TotalLiabilities,
        @Equity AS TotalEquity,

        @BalanceDifference AS BalanceSheetDifference,

        CASE
            WHEN ABS(@BalanceDifference) < 0.001
                THEN N'متوازن'
            ELSE N'توجد فروقات'
        END AS BalanceSheetStatus;


    /* =========================================================
       RESULT SET 5: فحوص سلامة البيانات
       ========================================================= */

    SELECT
        @ForeignAccountCount AS ForeignAccountMovementCount,
        @OrphanAccountCount AS OrphanAccountCount,
        @CrossCompanyParentCount AS CrossCompanyParentCount,
        @InvalidClassCount AS InvalidAccountClassificationCount,
        @UnbalancedJournalCount AS UnbalancedJournalCount,
        @NonLeafPostingCount AS NonLeafPostingCount,

        CASE
            WHEN @ForeignAccountCount = 0
             AND @OrphanAccountCount = 0
             AND @CrossCompanyParentCount = 0
             AND @InvalidClassCount = 0
             AND @UnbalancedJournalCount = 0
             AND @NonLeafPostingCount = 0
                THEN N'اجتازت البيانات فحوص السلامة المحددة'
            ELSE N'توجد ملاحظات تتطلب المراجعة'
        END AS DataIntegrityStatus;


    /* =========================================================
       RESULT SETS 6-8: التدفقات النقدية
       ========================================================= */

    EXEC dbo.Acc_SelectCashFlow
        @CompanyID = @Cmp,
        @DateFrom  = @FromDate,
        @DateTo    = @ToDate;


    /* =========================================================
       RESULT SET 9: ميزان المراجعة

       ملاحظة:
       OpenNet = صافي الرصيد الافتتاحي مديناً ناقص دائناً.
       PerDeb  = إجمالي مدين الفترة.
       PerCrd  = إجمالي دائن الفترة.
       PerCnt  = عدد تفاصيل الحركات خلال الفترة.
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccLevel,
        A.AccParentID,
        A.AccChid,

        CAST(ISNULL(R.OpeningNet,0) AS DECIMAL(38,3))
            AS OpenNet,

        CAST(ISNULL(R.PeriodDebit,0) AS DECIMAL(38,3))
            AS PerDeb,

        CAST(ISNULL(R.PeriodCredit,0) AS DECIMAL(38,3))
            AS PerCrd,

        CAST(ISNULL(R.MovementCount,0) AS BIGINT)
            AS PerCnt,

        CAST
        (
            ISNULL(R.OpeningNet,0)
            + ISNULL(R.PeriodDebit,0)
            - ISNULL(R.PeriodCredit,0)
            AS DECIMAL(38,3)
        ) AS ClosingNet

    FROM #Acc AS A
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID

    WHERE
        (@AllAcc = 1 OR K.AccID IS NULL)
        AND
        (
            @MoveAcc = 0
            OR ISNULL(R.MovementCount,0) > 0
        )
        AND
        (
            @BalnceAcc = 0
            OR
            (
                ISNULL(R.OpeningNet,0)
                + ISNULL(R.PeriodDebit,0)
                - ISNULL(R.PeriodCredit,0)
            ) <> 0
        )
        AND
        (
            @LevelAcc = 0
            OR A.AccLevel = @LevelAcc
            OR
            (
                A.AccLevel < @LevelAcc
                AND K.AccID IS NULL
            )
        )

    ORDER BY A.AccCode, A.AccID;

END;
GO

/* ---------- Acc_SelectAccFinancialNotes ---------- */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccFinancialNotes]
    @FromDate   DATE     = NULL,
    @ToDate     DATE     = NULL,
    @Cmp        INT      = 1,
    @Year       INT      = 0,
    @AllAcc     BIT      = 0,
    @MoveAcc    BIT      = 0,
    @BalnceAcc  BIT      = 0,
    @LevelAcc   TINYINT  = 0
AS
BEGIN
    /* =====================================================================
       اسم التقرير : الإيضاحات المتممة للقوائم المالية
                     (Notes to the Financial Statements)
       الإجراء     : dbo.Acc_SelectAccFinancialNotes
       المدخلات    : @FromDate و@ToDate ضمن @Year، و@Cmp = الشركة،
                     @AllAcc (1 = التحليلية فقط)، @MoveAcc، @BalnceAcc، @LevelAcc.
       المحتوى     : خمسة إيضاحات:
                       1 الأصول   2 الالتزامات   3 حقوق الملكية
                       4 الإيرادات   5 المصروفات
       الأرصدة     :
         - إيضاحات الميزانية (1-3): الافتتاحي = كل ما قبل @FromDate من كل السنوات.
         - إيضاحات قائمة الدخل (4-5): الافتتاحي = من 1 يناير حتى قبل @FromDate
           (السنة الحالية فقط)، والختامي = من 1 يناير حتى @ToDate.
           ما قبل 1 يناير يظهر ضمن صف «نتائج السنوات السابقة» في إيضاح 3.
       القواعد     : القيود المرحّلة فقط (DayMState BETWEEN 1 AND 7)؛ القيد على الحساب
                     التحليلي فقط ويُجمَّع نحو الآباء؛ السنة لا تُقفل.
       حقوق الملكية: إيضاح 3 يضم حسابات حقوق الملكية + صفّين:
                       AccID = -1 نتائج السنوات السابقة
                       AccID = -2 نتيجة السنة الحالية
                     (يظهران مهما كانت @AllAcc و@LevelAcc، ويخضعان لـ @MoveAcc و@BalnceAcc).
                     وبذلك: الأصول = الخصوم + حقوق الملكية، ويكون
                     BalanceDifference صفرًا إذا كانت القيود متوازنة، وإجمالي
                     إيضاح 4 - إيضاح 5 = نتيجة السنة الحالية.
       الفحوص      : ChkNonLeafAccounts = حسابات أب عليها حركة (لا تدخل في الأرقام)
                     ChkOtherAccounts   = حركة على حسابات غير تابعة للشركة أو غير مصنفة
                     يجب أن تكون صفرًا.
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Notes;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #RollTotals;
    DROP TABLE IF EXISTS #LeafAmt;
    DROP TABLE IF EXISTS #Amount;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #AccNote;
    DROP TABLE IF EXISTS #Acc;

    /* =========================================================
       1. التحقق من المدخلات
       ========================================================= */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year
       OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);


    /* =========================================================
       2. تحميل شجرة حسابات الشركة
       ========================================================= */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);


    /* =========================================================
       3. التحقق من سلامة ارتباط الحسابات بالآباء
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID IS NOT NULL
          AND a.AccParentID <> 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #Acc AS p
              WHERE p.AccID = a.AccParentID
          )
    )
        THROW 50011, N'شجرة الحسابات تحتوي على حساب أب غير موجود ضمن حسابات الشركة.', 1;


    /* =========================================================
       4. التحقق من الحلقات والحسابات غير القابلة للوصول
       ========================================================= */

    DECLARE
        @Total   BIGINT,
        @Reached BIGINT;

    SELECT @Total = COUNT_BIG(*)
    FROM #Acc;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        INNER JOIN #Acc AS c
            ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT_BIG(*)
    FROM Reach
    OPTION (MAXRECURSION 32767);

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300);

        SET @CycleMsg =
            CONCAT(
                N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول. عدد الحسابات المتأثرة: ',
                @Total - @Reached
            );

        THROW 50010, @CycleMsg, 1;
    END;


    /* =========================================================
       5. حسابات القوائم المالية
          الميزانية    : AccEnd = 1 ، AccType 0 أصول / 1 خصوم / 2 حقوق ملكية
          قائمة الدخل : AccEnd = 2 ، AccType 0 إيرادات / 1 مصروفات
          DebitNature = 1 للحسابات ذات الطبيعة المدينة (أصول، مصروفات)
       ========================================================= */

    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        AccEnd,
        AccType,
        CAST
        (
            CASE
                WHEN (AccEnd = 1 AND AccType = 0)
                  OR (AccEnd = 2 AND AccType = 1)
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS DebitNature
    INTO #AccNote
    FROM #Acc
    WHERE (AccEnd = 1 AND AccType IN (0, 1, 2))
       OR (AccEnd = 2 AND AccType IN (0, 1));

    IF NOT EXISTS (SELECT 1 FROM #AccNote)
        THROW 50015, N'لا توجد حسابات مصنفة ضمن القوائم المالية للشركة المحددة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_AccNote
        ON #AccNote (AccID);

    CREATE NONCLUSTERED INDEX IX_AccNote_Parent
        ON #AccNote (AccParentID);


    /* =========================================================
       6. التحقق من تصنيف الحسابات وعلاقة الأب بالابن
       ========================================================= */

    -- أب الحساب المصنف يجب أن يكون ضمن الحسابات المصنفة.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS c
        WHERE c.AccParentID IS NOT NULL
          AND c.AccParentID <> 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #AccNote AS p
              WHERE p.AccID = c.AccParentID
          )
    )
        THROW 50014, N'يوجد حساب تابع لحساب لا ينتمي إلى تصنيف القوائم المالية.', 1;

    -- يجب أن يتطابق التصنيف (القائمة والنوع) مع تصنيف الأب.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS c
        INNER JOIN #AccNote AS p
            ON p.AccID = c.AccParentID
        WHERE c.AccEnd <> p.AccEnd
           OR c.AccType <> p.AccType
    )
        THROW 50013, N'يوجد اختلاف في تصنيف الحساب عن تصنيف الحساب الأب.', 1;

    -- لا يجوز أن يكون لحساب مصنف ابن غير مصنف.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS p
        INNER JOIN #Acc AS c
            ON c.AccParentID = p.AccID
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM #AccNote AS n
            WHERE n.AccID = c.AccID
        )
    )
        THROW 50016, N'يوجد حساب ابن غير مصنف ضمن شجرة حسابات القوائم المالية.', 1;


    /* =========================================================
       7. تحديد الأبناء الفعليين من كامل شجرة الشركة
       ========================================================= */

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
      AND c.AccParentID > 0
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);


    /* =========================================================
       8. تجميع الحركات المحاسبية (القيود المرحّلة فقط) في مسح واحد
          OpenNet  : كل ما قبل @FromDate
          PriorNet : كل ما قبل 1 يناير من السنة (للسنوات السابقة)
       ========================================================= */

    SELECT
        d.DayDAccID AS AccID,

        SUM
        (
            CASE
                WHEN m.DayMDate < @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb) - CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS OpenNet,

        SUM
        (
            CASE
                WHEN m.DayMDate < @YearStart
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb) - CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PriorNet,

        SUM
        (
            CASE
                WHEN m.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PerDeb,

        SUM
        (
            CASE
                WHEN m.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PerCrd,

        SUM
        (
            CONVERT
            (
                BIGINT,
                CASE
                    WHEN m.DayMDate >= @FromDate THEN 1
                    ELSE 0
                END
            )
        ) AS PerCnt

    INTO #Amount

    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID

    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate <= @ToDate

    GROUP BY d.DayDAccID

    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount
        ON #Amount (AccID);


    /* =========================================================
       9. مؤشرات سلامة البيانات + الحسابات التحليلية فقط
       ========================================================= */

    DECLARE
        @ChkNonLeaf BIGINT = 0,
        @ChkOther   BIGINT = 0;

    -- حركة على حساب أب (لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT_BIG(*)
    FROM #Amount AS am
    INNER JOIN #Kid AS k
        ON k.AccID = am.AccID;

    -- حركة على حساب لا يتبع الشركة أو غير مصنف في القوائم
    SELECT @ChkOther = COUNT_BIG(*)
    FROM #Amount AS am
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #AccNote AS n
        WHERE n.AccID = am.AccID
    );

    SELECT
        am.AccID,
        n.AccEnd,
        n.AccType,
        am.OpenNet,
        am.PriorNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    INNER JOIN #AccNote AS n
        ON n.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
        ON #LeafAmt (AccID);


    /* =========================================================
       10. تجميع الأرصدة والحركات من الحسابات التحليلية إلى الآباء
       ========================================================= */

    ;WITH RollUp AS
    (
        SELECT
            l.AccID AS NodeID,
            l.OpenNet,
            l.PriorNet,
            l.PerDeb,
            l.PerCrd,
            l.PerCnt
        FROM #LeafAmt AS l

        UNION ALL

        SELECT
            p.AccID AS NodeID,
            r.OpenNet,
            r.PriorNet,
            r.PerDeb,
            r.PerCrd,
            r.PerCnt
        FROM RollUp AS r
        INNER JOIN #AccNote AS c
            ON c.AccID = r.NodeID
        INNER JOIN #AccNote AS p
            ON p.AccID = c.AccParentID
           AND c.AccParentID > 0
    )
    SELECT
        NodeID AS AccID,
        SUM(OpenNet)  AS OpenNet,
        SUM(PriorNet) AS PriorNet,
        SUM(PerDeb)   AS PerDeb,
        SUM(PerCrd)   AS PerCrd,
        SUM(PerCnt)   AS PerCnt
    INTO #RollTotals
    FROM RollUp
    GROUP BY NodeID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_RollTotals
        ON #RollTotals (AccID);


    /* =========================================================
       11. تجهيز أرصدة جميع حسابات القوائم المالية
       ========================================================= */

    SELECT
        a.AccID,
        a.AccCode,
        a.AccName,
        a.AccParentID,
        a.AccLevel,
        a.AccChid,
        a.AccEnd,
        a.AccType,
        a.DebitNature,

        CAST(ISNULL(t.OpenNet, 0)  AS DECIMAL(28,3)) AS OpenNet,
        CAST(ISNULL(t.PriorNet, 0) AS DECIMAL(28,3)) AS PriorNet,
        CAST(ISNULL(t.PerDeb, 0)   AS DECIMAL(28,3)) AS PerDeb,
        CAST(ISNULL(t.PerCrd, 0)   AS DECIMAL(28,3)) AS PerCrd,

        ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt

    INTO #Roll

    FROM #AccNote AS a
    LEFT JOIN #RollTotals AS t
        ON t.AccID = a.AccID;

    CREATE UNIQUE CLUSTERED INDEX IX_Roll
        ON #Roll (AccID);


    /* =========================================================
       12. الإجماليات ونتائج السنوات
           نتائج السنوات السابقة = - صافي قائمة الدخل قبل 1 يناير
           نتيجة السنة الحالية   = - صافي قائمة الدخل من 1 يناير حتى @ToDate
       ========================================================= */

    DECLARE
        @TotalAssets      DECIMAL(38,3),
        @TotalLiabilities DECIMAL(38,3),
        @TotalEquityAcc   DECIMAL(38,3),
        @TotalRevenue     DECIMAL(38,3),
        @TotalExpenses    DECIMAL(38,3),
        @PriorNet         DECIMAL(38,3),
        @CurOpenNet       DECIMAL(38,3),
        @CurPerDeb        DECIMAL(38,3),
        @CurPerCrd        DECIMAL(38,3),
        @CurPerCnt        BIGINT,
        @PriorResult      DECIMAL(38,3),
        @CurResult        DECIMAL(38,3),
        @TotalEquity      DECIMAL(38,3),
        @BalanceDiff      DECIMAL(38,3);

    SELECT
        @TotalAssets =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 0
                            THEN  (l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalLiabilities =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 1
                            THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalEquityAcc =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 2
                            THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalRevenue =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 AND l.AccType = 0
                            THEN -(l.OpenNet - l.PriorNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalExpenses =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 AND l.AccType = 1
                            THEN  (l.OpenNet - l.PriorNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @PriorNet =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PriorNet ELSE 0 END), 0),

        @CurOpenNet =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.OpenNet - l.PriorNet ELSE 0 END), 0),

        @CurPerDeb =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerDeb ELSE 0 END), 0),

        @CurPerCrd =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerCrd ELSE 0 END), 0),

        @CurPerCnt =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerCnt ELSE CONVERT(BIGINT, 0) END), 0)

    FROM #LeafAmt AS l;

    SET @PriorResult = -@PriorNet;
    SET @CurResult   = -(@CurOpenNet + @CurPerDeb - @CurPerCrd);
    SET @TotalEquity = @TotalEquityAcc + @PriorResult + @CurResult;
    SET @BalanceDiff = @TotalAssets - (@TotalLiabilities + @TotalEquity);


    /* =========================================================
       13. صفوف الإيضاحات
       ========================================================= */

    SELECT
        CAST
        (
            CASE
                WHEN r.AccEnd = 1 THEN r.AccType + 1
                ELSE r.AccType + 4
            END
            AS INT
        ) AS NoteNo,

        CASE
            WHEN r.AccEnd = 1 AND r.AccType = 0 THEN N'إيضاح رقم 1 - الأصول'
            WHEN r.AccEnd = 1 AND r.AccType = 1 THEN N'إيضاح رقم 2 - الالتزامات'
            WHEN r.AccEnd = 1 AND r.AccType = 2 THEN N'إيضاح رقم 3 - حقوق الملكية'
            WHEN r.AccEnd = 2 AND r.AccType = 0 THEN N'إيضاح رقم 4 - الإيرادات'
            WHEN r.AccEnd = 2 AND r.AccType = 1 THEN N'إيضاح رقم 5 - المصروفات'
        END AS NoteTitle,

        CASE
            WHEN r.AccEnd = 1 AND r.AccType = 0 THEN N'الأصول'
            WHEN r.AccEnd = 1 AND r.AccType = 1 THEN N'الخصوم'
            WHEN r.AccEnd = 1 AND r.AccType = 2 THEN N'حقوق الملكية'
            WHEN r.AccEnd = 2 AND r.AccType = 0 THEN N'الإيرادات'
            WHEN r.AccEnd = 2 AND r.AccType = 1 THEN N'المصروفات'
        END AS AccountCategory,

        r.AccID,
        r.AccCode,
        r.AccName AS AccARName,
        r.AccParentID,
        p.AccName AS AccParentName,
        r.AccLevel,
        r.AccType,

        CAST
        (
            CASE
                WHEN k.AccID IS NULL THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsAnalyticalAccount,

        -- الافتتاحي: الميزانية = كل السنوات السابقة، قائمة الدخل = السنة الحالية فقط
        CAST(x.Sgn * x.OpenAdj AS DECIMAL(28,3)) AS OpeningBalance,

        r.PerDeb AS PeriodDebit,
        r.PerCrd AS PeriodCredit,

        CAST(x.Sgn * (x.OpenAdj + r.PerDeb - r.PerCrd) AS DECIMAL(28,3)) AS ClosingBalance,

        r.PerCnt AS MovementCount,

        @FromDate AS FromDate,
        @ToDate AS ToDate,
        @Year AS FinancialYear,
        @Cmp AS CompanyID,

        @TotalAssets AS TotalAssets,
        @TotalLiabilities AS TotalLiabilities,
        @TotalEquity AS TotalEquity,
        @BalanceDiff AS BalanceDifference,

        CAST(0 AS BIT) AS IsResultRow,
        @TotalRevenue AS TotalRevenue,
        @TotalExpenses AS TotalExpenses,
        @CurResult AS NetIncome,
        @PriorResult AS PriorYearsResult,
        @CurResult AS CurrentYearResult,

        @ChkNonLeaf AS ChkNonLeafAccounts,
        @ChkOther AS ChkOtherAccounts

    INTO #Notes

    FROM #Roll AS r
    CROSS APPLY
    (
        SELECT
            CASE WHEN r.DebitNature = 1 THEN CAST(1 AS INT) ELSE CAST(-1 AS INT) END AS Sgn,
            r.OpenNet - CASE WHEN r.AccEnd = 2 THEN r.PriorNet ELSE CAST(0 AS DECIMAL(28,3)) END AS OpenAdj
    ) AS x
    LEFT JOIN #AccNote AS p
        ON p.AccID = r.AccParentID
    LEFT JOIN #Kid AS k
        ON k.AccID = r.AccID;

    ALTER TABLE #Notes ALTER COLUMN AccCode   NVARCHAR(200) NULL;
    ALTER TABLE #Notes ALTER COLUMN AccARName NVARCHAR(400) NULL;


    /* =========================================================
       14. صفّا نتائج السنوات ضمن إيضاح حقوق الملكية (إيضاح 3)
           قيم الحقول بطبيعة دائنة (الدائن موجب)
       ========================================================= */

    INSERT INTO #Notes
    (
        NoteNo, NoteTitle, AccountCategory,
        AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccType, IsAnalyticalAccount,
        OpeningBalance, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
        FromDate, ToDate, FinancialYear, CompanyID,
        TotalAssets, TotalLiabilities, TotalEquity, BalanceDifference,
        IsResultRow, TotalRevenue, TotalExpenses, NetIncome, PriorYearsResult, CurrentYearResult,
        ChkNonLeafAccounts, ChkOtherAccounts
    )
    VALUES
    (
        3, N'إيضاح رقم 3 - حقوق الملكية', N'حقوق الملكية',
        -1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', NULL, NULL, 1, 2, 1,
        @PriorResult, 0, 0, @PriorResult, 0,
        @FromDate, @ToDate, @Year, @Cmp,
        @TotalAssets, @TotalLiabilities, @TotalEquity, @BalanceDiff,
        1, @TotalRevenue, @TotalExpenses, @CurResult, @PriorResult, @CurResult,
        @ChkNonLeaf, @ChkOther
    ),
    (
        3, N'إيضاح رقم 3 - حقوق الملكية', N'حقوق الملكية',
        -2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', NULL, NULL, 1, 2, 1,
        -@CurOpenNet, @CurPerDeb, @CurPerCrd, @CurResult, @CurPerCnt,
        @FromDate, @ToDate, @Year, @Cmp,
        @TotalAssets, @TotalLiabilities, @TotalEquity, @BalanceDiff,
        1, @TotalRevenue, @TotalExpenses, @CurResult, @PriorResult, @CurResult,
        @ChkNonLeaf, @ChkOther
    );


    /* =========================================================
       15. إخراج الإيضاحات
       ========================================================= */

    SELECT
        NoteNo,
        NoteTitle,
        AccountCategory,

        AccID,
        AccCode,
        AccARName,
        AccParentID,
        AccParentName,
        AccLevel,
        AccType,
        IsAnalyticalAccount,

        OpeningBalance,
        PeriodDebit,
        PeriodCredit,
        ClosingBalance,
        MovementCount,

        FromDate,
        ToDate,
        FinancialYear,
        CompanyID,

        TotalAssets,
        TotalLiabilities,
        TotalEquity,
        BalanceDifference,

        IsResultRow,
        TotalRevenue,
        TotalExpenses,
        NetIncome,
        PriorYearsResult,
        CurrentYearResult,

        ChkNonLeafAccounts,
        ChkOtherAccounts

    FROM #Notes

    WHERE
        (
            IsResultRow = 1
            OR
            (
                (@AllAcc = 0 OR IsAnalyticalAccount = 1)

                AND
                (
                    @LevelAcc = 0
                    OR AccLevel = @LevelAcc
                    OR (AccLevel < @LevelAcc AND IsAnalyticalAccount = 1)
                )
            )
        )

        AND
        (
            @MoveAcc = 0
            OR MovementCount > 0
        )

        AND
        (
            @BalnceAcc = 0
            OR ClosingBalance <> 0
        )

    ORDER BY
        NoteNo,
        IsResultRow,
        AccCode,
        AccID;

END;
GO
GO

/* ---------- Acc_SelectAccChangesInEquity ---------- */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccChangesInEquity]
    @FromDate DATE,
    @ToDate   DATE,
    @Cmp      INT = 1
AS
BEGIN
    /* =====================================================================
       اسم التقرير : قائمة التغيّرات في حقوق الملكية
                     (Statement of Changes in Equity)
       الإجراء     : dbo.Acc_SelectAccChangesInEquity
       المدخلات    : @FromDate و@ToDate ضمن سنة مالية واحدة، و@Cmp = الشركة.

       مكوّنات حقوق الملكية (بلا أرقام ثابتة):
         - الجذر: حساب الشركة الذي AccEnd = 1 و AccType = 2 و AccParentID = NULL
           (يجب أن يكون واحدًا فقط).
         - المكوّنات: أبناؤه المباشرون (رأس المال، الأرباح والخسائر، أي احتياطي
           يُضاف لاحقًا...). إن لم يكن له أبناء فالجذر نفسه هو المكوّن.
         أي مكوّن جديد يُضاف تحت الجذر يظهر في القائمة تلقائيًا.

       لكل مكوّن: الرصيد الافتتاحي، حركة الفترة (مدين/دائن)، صافي التغيّر،
       الرصيد الختامي، ثم صف إجمالي حقوق الملكية.

       نتائج النشاط: السنة المالية لا تُقفل، فنتيجة النشاط تبقى في حسابات قائمة
                     الدخل. لذلك يضيف التقرير صفّين لتطابق الإجمالي مع الميزانية:
                       AccID = -1 نتائج السنوات السابقة (كل ما قبل 1 يناير)
                       AccID = -2 نتيجة السنة الحالية (من 1 يناير حتى @ToDate،
                                  وافتتاحيها ما كان من 1 يناير حتى قبل @FromDate)

       القواعد     : القيود المرحّلة فقط (DayMState BETWEEN 1 AND 7)؛ الافتتاحي = كل ما قبل
                     @FromDate من كل السنوات؛ القيد على الحساب التحليلي فقط
                     (حركة على حساب أب ضمن الشجرة أو على الجذر = خطأ 50006).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #EquityTree;
    DROP TABLE IF EXISTS #EquityKid;
    DROP TABLE IF EXISTS #Comp;
    DROP TABLE IF EXISTS #Result;
    DROP TABLE IF EXISTS #Output;

    /* 1. التحقق من المدخلات */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50001, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50002, N'الشركة المحددة غير صحيحة.', 1;

    IF YEAR(@FromDate) <> YEAR(@ToDate)
        THROW 50003, N'يجب أن تقع الفترة ضمن السنة المالية نفسها.', 1;


    /* 2. تحديد جذر حقوق الملكية ومكوّناته */

    DECLARE
        @RootCnt INT,
        @EqRoot  BIGINT;

    SELECT
        @RootCnt = COUNT(*),
        @EqRoot  = MAX(AccID)
    FROM dbo.Acc_Account
    WHERE AccCompany = @Cmp
      AND AccEnd = 1
      AND AccType = 2
      AND AccParentID IS NULL;

    IF @RootCnt = 0
        THROW 50004, N'لا يوجد حساب جذر لحقوق الملكية (AccEnd = 1 و AccType = 2).', 1;

    IF @RootCnt > 1
        THROW 50005, N'يوجد أكثر من جذر لحقوق الملكية؛ يجب أن يكون واحدًا.', 1;

    SELECT A.AccID
    INTO #Comp
    FROM dbo.Acc_Account AS A
    WHERE A.AccCompany = @Cmp
      AND A.AccParentID = @EqRoot;

    IF NOT EXISTS (SELECT 1 FROM #Comp)
        INSERT INTO #Comp (AccID) VALUES (@EqRoot);

    IF EXISTS
    (
        SELECT 1
        FROM #Comp AS C
        INNER JOIN dbo.Acc_Account AS A
            ON A.AccID = C.AccID
        WHERE A.AccEnd <> 1
           OR A.AccType <> 2
    )
        THROW 50009, N'يوجد مكوّن تحت جذر حقوق الملكية تصنيفه ليس من حقوق الملكية.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Comp
        ON #Comp (AccID);


    /* 3. تحميل شجرة حقوق الملكية */

    ;WITH EquityTree AS
    (
        SELECT
            A.AccID,
            A.AccParentID,
            A.AccLevel,
            A.AccChid,
            A.AccCode,
            A.AccName,
            A.AccID AS EquityRoot,
            CAST(
                '/' + CAST(A.AccID AS VARCHAR(20)) + '/'
                AS VARCHAR(MAX)
            ) AS AccountPath
        FROM dbo.Acc_Account A
        INNER JOIN #Comp K
            ON K.AccID = A.AccID
        WHERE A.AccCompany = @Cmp

        UNION ALL

        SELECT
            C.AccID,
            C.AccParentID,
            C.AccLevel,
            C.AccChid,
            C.AccCode,
            C.AccName,
            P.EquityRoot,
            CAST(
                P.AccountPath + CAST(C.AccID AS VARCHAR(20)) + '/'
                AS VARCHAR(MAX)
            )
        FROM dbo.Acc_Account C
        INNER JOIN EquityTree P
            ON C.AccParentID = P.AccID
        WHERE C.AccCompany = @Cmp
          AND P.AccountPath NOT LIKE
              '%/' + CAST(C.AccID AS VARCHAR(20)) + '/%'
    )
    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        EquityRoot
    INTO #EquityTree
    FROM EquityTree
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_EquityTree
        ON #EquityTree (AccID);


    /* 4. تحديد الحسابات الأب (تشمل الجذر نفسه إن كانت المكوّنات أبناءه) */

    SELECT DISTINCT
        AccParentID AS AccID
    INTO #EquityKid
    FROM #EquityTree
    WHERE AccParentID IS NOT NULL;

    CREATE UNIQUE CLUSTERED INDEX IX_EquityKid
        ON #EquityKid (AccID);


    /* 5. منع الحركات المباشرة على الحسابات الأب */

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Acc_DayMaster M
        INNER JOIN dbo.Acc_DayDetails D
            ON D.DayDMID = M.DayMID
        INNER JOIN #EquityKid K
            ON K.AccID = D.DayDAccID
        WHERE M.DayMCompany = @Cmp
          AND M.DayMState BETWEEN 1 AND 7
          AND M.DayMDate <= @ToDate
    )
        THROW 50006, N'توجد حركات مباشرة على حساب أب ضمن شجرة حقوق الملكية. يجب مراجعة توزيع الحركات على الحسابات التحليلية.', 1;


    /* 6. استخراج الأرصدة والحركات من الحسابات التحليلية */

    ;WITH LeafAmounts AS
    (
        SELECT
            T.EquityRoot,

            SUM
            (
                CASE
                    WHEN M.DayMDate < @FromDate
                    THEN ISNULL(D.DayDDeb, 0) - ISNULL(D.DayDCrd, 0)
                    ELSE 0
                END
            ) AS OpeningNet,

            SUM
            (
                CASE
                    WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                    THEN ISNULL(D.DayDDeb, 0)
                    ELSE 0
                END
            ) AS PeriodDebit,

            SUM
            (
                CASE
                    WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                    THEN ISNULL(D.DayDCrd, 0)
                    ELSE 0
                END
            ) AS PeriodCredit

        FROM #EquityTree T
        INNER JOIN dbo.Acc_DayDetails D
            ON D.DayDAccID = T.AccID
        INNER JOIN dbo.Acc_DayMaster M
            ON M.DayMID = D.DayDMID
        WHERE M.DayMCompany = @Cmp
          AND M.DayMState BETWEEN 1 AND 7
          AND M.DayMDate <= @ToDate
          AND NOT EXISTS
          (
              SELECT 1
              FROM #EquityKid K
              WHERE K.AccID = T.AccID
          )
        GROUP BY T.EquityRoot
    )
    SELECT
        T.AccID,
        T.AccCode,
        T.AccName,

        CAST(ISNULL(L.OpeningNet, 0) AS DECIMAL(28,3)) AS OpeningNet,
        CAST(ISNULL(L.PeriodDebit, 0) AS DECIMAL(28,3)) AS PeriodDebit,
        CAST(ISNULL(L.PeriodCredit, 0) AS DECIMAL(28,3)) AS PeriodCredit

    INTO #Result
    FROM #EquityTree T
    INNER JOIN #Comp K
        ON K.AccID = T.AccID
    LEFT JOIN LeafAmounts L
        ON L.EquityRoot = T.AccID;

    CREATE UNIQUE CLUSTERED INDEX IX_Result
        ON #Result (AccID);

    ALTER TABLE #Result ALTER COLUMN AccCode NVARCHAR(100) NULL;
    ALTER TABLE #Result ALTER COLUMN AccName NVARCHAR(200) NULL;


    /* 6.1 نتائج السنوات من حسابات قائمة الدخل التحليلية (السنة لا تُقفل) */

    DECLARE @YearStart DATE = DATEFROMPARTS(YEAR(@FromDate), 1, 1);

    DECLARE
        @PriorNet  DECIMAL(28,3),
        @CurOpen   DECIMAL(28,3),
        @CurDebit  DECIMAL(28,3),
        @CurCredit DECIMAL(28,3);

    SELECT
        @PriorNet  = ISNULL(SUM(CASE WHEN M.DayMDate < @YearStart
                                     THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @CurOpen   = ISNULL(SUM(CASE WHEN M.DayMDate >= @YearStart AND M.DayMDate < @FromDate
                                     THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @CurDebit  = ISNULL(SUM(CASE WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                                     THEN D.DayDDeb ELSE 0 END), 0),
        @CurCredit = ISNULL(SUM(CASE WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                                     THEN D.DayDCrd ELSE 0 END), 0)
    FROM dbo.Acc_DayMaster M
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = M.DayMID
    INNER JOIN dbo.Acc_Account A
        ON A.AccID = D.DayDAccID
       AND A.AccCompany = @Cmp
       AND A.AccEnd = 2
       AND A.AccType IN (0, 1)
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate <= @ToDate
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Acc_Account C
          WHERE C.AccParentID = A.AccID
      );

    INSERT INTO #Result (AccID, AccCode, AccName, OpeningNet, PeriodDebit, PeriodCredit)
    VALUES
        (-1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', @PriorNet, 0, 0),
        (-2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', @CurOpen, @CurDebit, @CurCredit);


    /* 7. تجهيز التقرير */

    CREATE TABLE #Output
    (
        SortOrder       INT NOT NULL,
        AccID           BIGINT NOT NULL,
        AccCode         NVARCHAR(100) NOT NULL,
        EquityComponent NVARCHAR(200) NOT NULL,

        OpeningDebit    DECIMAL(28,3) NOT NULL,
        OpeningCredit   DECIMAL(28,3) NOT NULL,

        PeriodDebit     DECIMAL(28,3) NOT NULL,
        PeriodCredit    DECIMAL(28,3) NOT NULL,

        NetChange       DECIMAL(28,3) NOT NULL,

        ClosingDebit    DECIMAL(28,3) NOT NULL,
        ClosingCredit   DECIMAL(28,3) NOT NULL
    );


    /* 8. تفاصيل مكونات حقوق الملكية + صفّا النتائج */

    INSERT INTO #Output
    (
        SortOrder,
        AccID,
        AccCode,
        EquityComponent,
        OpeningDebit,
        OpeningCredit,
        PeriodDebit,
        PeriodCredit,
        NetChange,
        ClosingDebit,
        ClosingCredit
    )
    SELECT
        ROW_NUMBER() OVER
        (
            ORDER BY
                CASE WHEN R.AccID < 0 THEN 1 ELSE 0 END,
                R.AccCode,
                R.AccID
        ),

        R.AccID,
        ISNULL(R.AccCode, N''),
        ISNULL(R.AccName, N''),

        CASE
            WHEN R.OpeningNet > 0 THEN R.OpeningNet
            ELSE 0
        END,

        CASE
            WHEN R.OpeningNet < 0 THEN -R.OpeningNet
            ELSE 0
        END,

        R.PeriodDebit,
        R.PeriodCredit,

        R.PeriodCredit - R.PeriodDebit,

        CASE
            WHEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit > 0
            THEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit
            ELSE 0
        END,

        CASE
            WHEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit < 0
            THEN -(R.OpeningNet + R.PeriodDebit - R.PeriodCredit)
            ELSE 0
        END

    FROM #Result R;


    /* 9. إجمالي حقوق الملكية */

    DECLARE
        @OpeningTotal DECIMAL(28,3),
        @DebitTotal   DECIMAL(28,3),
        @CreditTotal  DECIMAL(28,3),
        @ClosingTotal DECIMAL(28,3);

    SELECT
        @OpeningTotal = ISNULL(SUM(OpeningNet), 0),
        @DebitTotal   = ISNULL(SUM(PeriodDebit), 0),
        @CreditTotal  = ISNULL(SUM(PeriodCredit), 0)
    FROM #Result;

    SET @ClosingTotal =
        @OpeningTotal + @DebitTotal - @CreditTotal;

    INSERT INTO #Output
    (
        SortOrder,
        AccID,
        AccCode,
        EquityComponent,
        OpeningDebit,
        OpeningCredit,
        PeriodDebit,
        PeriodCredit,
        NetChange,
        ClosingDebit,
        ClosingCredit
    )
    VALUES
    (
        2147483647,
        0,
        N'',
        N'إجمالي حقوق الملكية',

        CASE WHEN @OpeningTotal > 0
             THEN @OpeningTotal ELSE 0 END,

        CASE WHEN @OpeningTotal < 0
             THEN -@OpeningTotal ELSE 0 END,

        @DebitTotal,
        @CreditTotal,
        @CreditTotal - @DebitTotal,

        CASE WHEN @ClosingTotal > 0
             THEN @ClosingTotal ELSE 0 END,

        CASE WHEN @ClosingTotal < 0
             THEN -@ClosingTotal ELSE 0 END
    );


    /* 10. إخراج التقرير */

    SELECT
        AccID,
        AccCode,
        EquityComponent,

        OpeningDebit,
        OpeningCredit,

        PeriodDebit,
        PeriodCredit,

        NetChange,

        ClosingDebit,
        ClosingCredit,

        @FromDate AS FromDate,
        @ToDate AS ToDate

    FROM #Output
    ORDER BY SortOrder;

END;
GO
GO

/* ---------- Acc_SelectCashFlow ---------- */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   قائمة التدفقات النقدية (الطريقة المباشرة) — IAS 7
   ---------------------------------------------------------------------
   Acc_CashFlowAccounts.CashFlowType:
       1 = النقدية وما يعادلها
       2 = أنشطة تشغيلية   3 = أنشطة استثمارية   4 = أنشطة تمويلية
   يُورَّث التصنيف من أقرب حساب أعلى مصنَّف (الأقرب يغلب).

   المبدأ:
   - لكل قيد مرحّل (DayMState BETWEEN 1 AND 7) يمس حسابات النقدية في الفترة، صافي حركة
     النقدية = صافي بنوده المقابلة (إن كان القيد متوازنًا).
   - داخل القيد الواحد تُجمَّع البنود المقابلة حسب نوع النشاط (2/3/4)،
     فيصبح لكل نشاط صافٍ واحد: موجب = متحصلات، سالب = مدفوعات.
     بهذا لا يُستثنى قيد صحيح لمجرد أن بنوده المقابلة باتجاهين.
   - الاستثناء فقط لخلل حقيقي: لا بنود مقابلة، أو حساب مقابل غير مصنف،
     أو صافي البنود لا يطابق صافي النقدية (قيد غير متوازن).
   - التسوية مضمونة: الافتتاحي + (تشغيلي + استثماري + تمويلي) + المستثنى = الختامي،
     وفرق التسوية يجب أن يكون صفرًا دائمًا.
   - حركة النقدية بين حسابات نقدية (صافيها صفر) لا تُعد تدفقًا.
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCashFlow]
(
    @CompanyID INT,
    @DateFrom  DATE,
    @DateTo    DATE
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CompanyID IS NULL OR @CompanyID <= 0
        THROW 50001, N'يجب تحديد الشركة بصورة صحيحة.', 1;

    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo
        THROW 50002, N'نطاق التاريخ غير صحيح.', 1;

    DROP TABLE IF EXISTS #EntryFlow;
    DROP TABLE IF EXISTS #Exceptions;
    DROP TABLE IF EXISTS #JournalCheck;
    DROP TABLE IF EXISTS #CounterLines;
    DROP TABLE IF EXISTS #CashJournal;
    DROP TABLE IF EXISTS #AccountClass;

    /*==============================================================
      1. تصنيف الحسابات وتوريث أقرب تصنيف من الحسابات الأعلى
    ==============================================================*/

    ;WITH AccountAncestors AS
    (
        SELECT
            A.AccID AS LeafAccID,
            A.AccID AS AncestorAccID,
            CAST(0 AS INT) AS Distance,
            CAST('/' + CONVERT(VARCHAR(30), A.AccID) + '/' AS VARCHAR(MAX)) AS VisitedPath
        FROM dbo.Acc_Account A
        WHERE A.AccCompany = @CompanyID

        UNION ALL

        SELECT
            H.LeafAccID,
            P.AccParentID,
            H.Distance + 1,
            CAST(H.VisitedPath + CONVERT(VARCHAR(30), P.AccParentID) + '/' AS VARCHAR(MAX))
        FROM AccountAncestors H
        INNER JOIN dbo.Acc_Account P
            ON P.AccID = H.AncestorAccID
           AND P.AccCompany = @CompanyID
        WHERE P.AccParentID IS NOT NULL
          AND CHARINDEX('/' + CONVERT(VARCHAR(30), P.AccParentID) + '/', H.VisitedPath) = 0
    ),
    RankedClassification AS
    (
        SELECT
            H.LeafAccID,
            C.CashFlowType,
            ROW_NUMBER() OVER (PARTITION BY H.LeafAccID ORDER BY H.Distance ASC) AS RN
        FROM AccountAncestors H
        INNER JOIN dbo.Acc_CashFlowAccounts C
            ON C.AccID = H.AncestorAccID
    )
    SELECT
        A.AccID,
        R.CashFlowType
    INTO #AccountClass
    FROM dbo.Acc_Account A
    LEFT JOIN RankedClassification R
        ON R.LeafAccID = A.AccID
       AND R.RN = 1
    WHERE A.AccCompany = @CompanyID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_AccountClass
        ON #AccountClass (AccID);

    -- حسابات النقدية يجب أن تكون حسابات ميزانية من نوع أصول
    IF EXISTS
    (
        SELECT 1
        FROM #AccountClass C
        INNER JOIN dbo.Acc_Account A
            ON A.AccID = C.AccID
        WHERE C.CashFlowType = 1
          AND (A.AccEnd <> 1 OR A.AccType <> 0)
    )
        THROW 50020, N'تصنيف النقدية (1) مطبق على حساب ليس من أصول الميزانية العمومية.', 1;


    /*==============================================================
      2. قيود الفترة التي تمس النقدية وصافي حركة النقدية لكل قيد
         (القيود التي صافي نقديتها صفر، كالتحويل بين الصناديق، لا تُعد تدفقًا)
    ==============================================================*/

    SELECT
        D.DayDMID,
        CAST(SUM(D.DayDDeb) AS DECIMAL(19,3)) AS CashDebit,
        CAST(SUM(D.DayDCrd) AS DECIMAL(19,3)) AS CashCredit,
        CAST(SUM(D.DayDDeb - D.DayDCrd) AS DECIMAL(19,3)) AS CashNet
    INTO #CashJournal
    FROM dbo.Acc_DayMaster M
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = M.DayMID
    INNER JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
       AND A.CashFlowType = 1
    WHERE M.DayMCompany = @CompanyID
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate >= @DateFrom
      AND M.DayMDate <= @DateTo
    GROUP BY D.DayDMID
    HAVING SUM(D.DayDDeb - D.DayDCrd) <> 0;

    CREATE UNIQUE CLUSTERED INDEX IX_CashJournal
        ON #CashJournal (DayDMID);


    /*==============================================================
      3. البنود المقابلة (غير النقدية) في هذه القيود فقط
         FlowAmount: موجب = تدفق داخل، سالب = تدفق خارج
         CashFlowType = NULL يعني حسابًا غير مصنف
    ==============================================================*/

    SELECT
        D.DayDMID,
        D.DayDID,
        A.CashFlowType,
        CAST(D.DayDCrd - D.DayDDeb AS DECIMAL(19,3)) AS FlowAmount
    INTO #CounterLines
    FROM #CashJournal CJ
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = CJ.DayDMID
    LEFT JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
    WHERE ISNULL(A.CashFlowType, 0) <> 1;

    CREATE INDEX IX_CounterLines_Journal
        ON #CounterLines (DayDMID);


    /*==============================================================
      4. فحص كل قيد
    ==============================================================*/

    SELECT
        CJ.DayDMID,
        CJ.CashNet,
        COUNT(CL.DayDID) AS CounterLineCount,
        SUM(CASE WHEN CL.DayDID IS NOT NULL AND CL.CashFlowType IS NULL THEN 1 ELSE 0 END) AS UnclassifiedCount,
        CAST(ISNULL(SUM(CASE WHEN CL.CashFlowType BETWEEN 2 AND 4 THEN CL.FlowAmount END), 0)
             AS DECIMAL(19,3)) AS ClassifiedNet
    INTO #JournalCheck
    FROM #CashJournal CJ
    LEFT JOIN #CounterLines CL
        ON CL.DayDMID = CJ.DayDMID
    GROUP BY CJ.DayDMID, CJ.CashNet;

    CREATE UNIQUE CLUSTERED INDEX IX_JournalCheck
        ON #JournalCheck (DayDMID);


    /*==============================================================
      5. القيود المستثناة وأسبابها
    ==============================================================*/

    SELECT
        X.DayDMID,
        X.ExceptionReason
    INTO #Exceptions
    FROM
    (
        SELECT
            JC.DayDMID,
            CASE
                WHEN JC.CounterLineCount = 0
                    THEN N'لا توجد بنود مقابلة لحركة النقدية'
                WHEN JC.UnclassifiedCount > 0
                    THEN N'يوجد حساب مقابل غير مصنف في قائمة التدفقات'
                WHEN ABS(JC.ClassifiedNet - JC.CashNet) > 0.001
                    THEN N'صافي البنود المقابلة لا يطابق صافي حركة النقدية (قيد غير متوازن)'
                ELSE NULL
            END AS ExceptionReason
        FROM #JournalCheck JC
    ) X
    WHERE X.ExceptionReason IS NOT NULL;

    CREATE UNIQUE CLUSTERED INDEX IX_Exceptions
        ON #Exceptions (DayDMID);


    /*==============================================================
      6. صافي كل نشاط داخل كل قيد سليم
         (موجب = متحصلات، سالب = مدفوعات)
    ==============================================================*/

    SELECT
        CL.DayDMID,
        CL.CashFlowType,
        CAST(SUM(CL.FlowAmount) AS DECIMAL(19,3)) AS NetFlow
    INTO #EntryFlow
    FROM #CounterLines CL
    WHERE CL.CashFlowType BETWEEN 2 AND 4
      AND NOT EXISTS (SELECT 1 FROM #Exceptions E WHERE E.DayDMID = CL.DayDMID)
    GROUP BY CL.DayDMID, CL.CashFlowType
    HAVING SUM(CL.FlowAmount) <> 0;


    /*==============================================================
      7. أرصدة النقدية وأرقام التسوية
    ==============================================================*/

    DECLARE
        @Opening       DECIMAL(19,3),
        @Period        DECIMAL(19,3),
        @NetClassified DECIMAL(19,3),
        @ExceptionsNet DECIMAL(19,3),
        @ExceptionCnt  INT;

    SELECT
        @Opening = ISNULL(SUM(CASE WHEN M.DayMDate <  @DateFrom THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @Period  = ISNULL(SUM(CASE WHEN M.DayMDate >= @DateFrom THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0)
    FROM dbo.Acc_DayDetails D
    INNER JOIN dbo.Acc_DayMaster M
        ON M.DayMID = D.DayDMID
    INNER JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
       AND A.CashFlowType = 1
    WHERE M.DayMCompany = @CompanyID
      AND M.DayMState BETWEEN 1 AND 7
      AND M.DayMDate <= @DateTo;

    SELECT @NetClassified = ISNULL(SUM(NetFlow), 0)
    FROM #EntryFlow;

    SELECT
        @ExceptionsNet = ISNULL(SUM(CJ.CashNet), 0),
        @ExceptionCnt  = COUNT(*)
    FROM #Exceptions E
    INNER JOIN #CashJournal CJ
        ON CJ.DayDMID = E.DayDMID;


    /*==============================================================
      RESULT SET 1: التدفقات حسب النشاط
    ==============================================================*/

    SELECT
        V.CashFlowType,
        V.FlowName,
        CAST(ISNULL(F.CashInflows, 0)  AS DECIMAL(19,3)) AS CashInflows,
        CAST(ISNULL(F.CashOutflows, 0) AS DECIMAL(19,3)) AS CashOutflows,
        CAST(ISNULL(F.NetFlow, 0)      AS DECIMAL(19,3)) AS NetFlow
    FROM
    (
        VALUES
            (2, N'التدفقات النقدية من الأنشطة التشغيلية'),
            (3, N'التدفقات النقدية من الأنشطة الاستثمارية'),
            (4, N'التدفقات النقدية من الأنشطة التمويلية')
    ) V(CashFlowType, FlowName)
    LEFT JOIN
    (
        SELECT
            EF.CashFlowType,
            SUM(EF.NetFlow) AS NetFlow,
            SUM(CASE WHEN EF.NetFlow > 0 THEN  EF.NetFlow ELSE 0 END) AS CashInflows,
            SUM(CASE WHEN EF.NetFlow < 0 THEN -EF.NetFlow ELSE 0 END) AS CashOutflows
        FROM #EntryFlow EF
        GROUP BY EF.CashFlowType
    ) F
        ON F.CashFlowType = V.CashFlowType
    ORDER BY V.CashFlowType;


    /*==============================================================
      RESULT SET 2: أرصدة النقدية والتسوية
         ReconciliationDifference يجب أن يكون صفرًا دائمًا
    ==============================================================*/

    SELECT
        @Opening                 AS OpeningCashBalance,
        @Period                  AS PeriodCashMovement,
        @Opening + @Period       AS ClosingCashBalance,
        @NetClassified           AS NetClassifiedFlow,
        @ExceptionsNet           AS ExceptionsNet,
        @ExceptionCnt            AS ExceptionCount,
        @Period - @NetClassified - @ExceptionsNet AS ReconciliationDifference;


    /*==============================================================
      RESULT SET 3: القيود المستثناة للمراجعة
    ==============================================================*/

    SELECT
        M.DayMID,
        M.DayMNo,
        M.DayMDate,
        M.DayMDescription,
        M.DayMState,
        E.ExceptionReason,
        CJ.CashDebit,
        CJ.CashCredit,
        CJ.CashNet
    FROM #Exceptions E
    INNER JOIN dbo.Acc_DayMaster M
        ON M.DayMID = E.DayDMID
    INNER JOIN #CashJournal CJ
        ON CJ.DayDMID = E.DayDMID
    ORDER BY
        M.DayMDate,
        M.DayMNo,
        M.DayMID;

END;
GO
GO

/* ---------- Acc_CheckFinancialStatements ---------- */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_CheckFinancialStatements]
    @FromDate   DATE = NULL,
    @ToDate     DATE = NULL,
    @Cmp        INT  = 1,
    @Year       INT  = 0,
    @MaxDetails INT  = 200
AS
BEGIN
    /* =====================================================================
       اسم التقرير : فحص سلامة القوائم المالية وربطها ومطابقتها
                     (Financial Statements Integrity & Reconciliation Check)
       الإجراء     : dbo.Acc_CheckFinancialStatements
       المدخلات    : @FromDate (الافتراضي 1 يناير)، @ToDate، @Cmp، @Year،
                     @MaxDetails = أقصى عدد صفوف تفصيل لكل فحص (الافتراضي 200).
       لا يغيّر أي بيانات: قراءة فقط.

       النتائج:
         1 جدول الفحوص: رقم الفحص، المجموعة، العنوان، الخطورة، الحالة،
                        عدد الملاحظات، المتوقع، الفعلي، الفرق.
         2 تفاصيل الملاحظات (حتى @MaxDetails لكل فحص): الحساب أو القيد المعني.
         3 الخلاصة: عدد الأخطاء والتحذيرات والحالة العامة.

       مجموعات الفحوص:
         A بنية دليل الحسابات       (1-7)   أب مفقود، شركة أخرى، حلقة، تصنيف، AccChid، تكرار رمز
         B سلامة القيود المرحّلة      (8-14)  توازن القيد، قيد بلا بنود، قاعدة الطرف الواحد،
                                              حركة على أب / حساب غريب / غير مصنف، تكرار رقم القيد
         C المطابقة                 (15-21) توازن دفتر الأستاذ (افتتاحي/حركة/ختامي)، معادلة
                                              الميزانية، جذور الشجرة = الأوراق، نتيجة السنة
         D الربط بقائمة حقوق الملكية (22-23) وجود جذر واحد لحقوق الملكية وتغطية كل حساباتها
         E ربط التدفقات النقدية      (24-28) تصنيف النقدية والحسابات المقابلة والاستثناءات

       الخطورة: خطأ = يمنع الاعتماد على الأرقام، تحذير = يحتاج مراجعة، لا يمنع.
       القواعد: القيود المرحّلة فقط (DayMState BETWEEN 1 AND 7) حتى @ToDate؛ القيد على
                الحساب التحليلي فقط؛ السنة لا تُقفل (نتائج السنوات تتراكم).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Det;
    DROP TABLE IF EXISTS #Chk;
    DROP TABLE IF EXISTS #CashChk;
    DROP TABLE IF EXISTS #Counter;
    DROP TABLE IF EXISTS #CashEntry;
    DROP TABLE IF EXISTS #CF;
    DROP TABLE IF EXISTS #EqCovered;
    DROP TABLE IF EXISTS #LeafNet;
    DROP TABLE IF EXISTS #Journal;
    DROP TABLE IF EXISTS #Line;
    DROP TABLE IF EXISTS #Reach;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Acc;

    /* =========================================================
       1. التحقق من المدخلات
       ========================================================= */

    IF @ToDate IS NULL
        THROW 50301, N'تاريخ نهاية الفحص مطلوب.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50302, N'رقم الشركة غير صحيح.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @Cmp)
        THROW 50303, N'الشركة المحددة غير موجودة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@ToDate);

    IF @Year < 1900 OR @Year > 9999
        THROW 50304, N'السنة المالية غير صحيحة.', 1;

    IF @FromDate IS NULL
        SET @FromDate = DATEFROMPARTS(@Year, 1, 1);

    IF @FromDate > @ToDate
        THROW 50305, N'فترة الفحص غير صحيحة.', 1;

    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50306, N'يجب أن تقع فترة الفحص داخل السنة المالية المحددة.', 1;

    SET @MaxDetails = ISNULL(@MaxDetails, 200);

    IF @MaxDetails < 1
        SET @MaxDetails = 200;

    DECLARE
        @YearStart DATE = DATEFROMPARTS(@Year, 1, 1),
        @YearEnd   DATE = DATEFROMPARTS(@Year, 12, 31);


    /* =========================================================
       2. تحميل دليل حسابات الشركة
       ========================================================= */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType,
        CAST
        (
            CASE
                WHEN (a.AccEnd = 1 AND a.AccType IN (0, 1, 2))
                  OR (a.AccEnd = 2 AND a.AccType IN (0, 1))
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS ValidClass
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50307, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);

    -- الحسابات القابلة للوصول من جذور الشجرة (الجذر: AccParentID = NULL)
    ;WITH R AS
    (
        SELECT AccID
        FROM #Acc
        WHERE AccParentID IS NULL

        UNION ALL

        SELECT c.AccID
        FROM R
        INNER JOIN #Acc AS c
            ON c.AccParentID = R.AccID
    )
    SELECT AccID
    INTO #Reach
    FROM R
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_Reach
        ON #Reach (AccID);


    /* =========================================================
       3. جداول الفحوص والتفاصيل
       ========================================================= */

    CREATE TABLE #Chk
    (
        CheckNo       INT NOT NULL PRIMARY KEY,
        Grp           NVARCHAR(100) NOT NULL,
        Title         NVARCHAR(300) NOT NULL,
        Severity      TINYINT NOT NULL,          -- 1 خطأ، 2 تحذير
        IssueCount    BIGINT NOT NULL,
        ExpectedValue DECIMAL(38,3) NULL,
        ActualValue   DECIMAL(38,3) NULL,
        Difference    DECIMAL(38,3) NULL
    );

    CREATE TABLE #Det
    (
        Seq        INT IDENTITY(1,1) NOT NULL,
        CheckNo    INT NOT NULL,
        ObjectType NVARCHAR(30)  NULL,
        ObjectID   BIGINT        NULL,
        ObjectCode NVARCHAR(200) NULL,
        ObjectName NVARCHAR(MAX) NULL,
        Amount1    DECIMAL(38,3) NULL,
        Amount2    DECIMAL(38,3) NULL,
        Note       NVARCHAR(MAX) NULL
    );

    INSERT INTO #Chk (CheckNo, Grp, Title, Severity, IssueCount)
    VALUES
    (1,  N'A - بنية دليل الحسابات', N'حسابات أبوها غير موجود (يتيمة)، أو الأب = 0 بدل NULL', 1, 0),
    (2,  N'A - بنية دليل الحسابات', N'حسابات أبوها يتبع شركة أخرى', 1, 0),
    (3,  N'A - بنية دليل الحسابات', N'حسابات غير قابلة للوصول من جذر الشجرة (حلقة أو أب مفقود)', 1, 0),
    (4,  N'A - بنية دليل الحسابات', N'حسابات بتصنيف مالي غير صحيح (AccEnd / AccType)', 1, 0),
    (5,  N'A - بنية دليل الحسابات', N'اختلاف التصنيف المالي بين الحساب وأبيه', 1, 0),
    (6,  N'A - بنية دليل الحسابات', N'عدم تطابق AccChid مع الأبناء الفعليين', 2, 0),
    (7,  N'A - بنية دليل الحسابات', N'تكرار رمز الحساب (AccCode)', 2, 0),

    (8,  N'B - سلامة القيود المرحّلة', N'قيود مرحّلة غير متوازنة (مجموع المدين ≠ مجموع الدائن)', 1, 0),
    (9,  N'B - سلامة القيود المرحّلة', N'قيود مرحّلة بلا بنود', 1, 0),
    (10, N'B - سلامة القيود المرحّلة', N'بنود مخالفة لقاعدة الطرف الواحد (مدين ودائن معًا، أو صفر، أو سالب)', 1, 0),
    (11, N'B - سلامة القيود المرحّلة', N'حركة مسجلة مباشرة على حساب أب (لا تدخل في الأرقام)', 1, 0),
    (12, N'B - سلامة القيود المرحّلة', N'حركة على حساب لا يتبع الشركة', 1, 0),
    (13, N'B - سلامة القيود المرحّلة', N'حركة على حساب بتصنيف مالي غير صحيح', 1, 0),
    (14, N'B - سلامة القيود المرحّلة', N'تكرار رقم القيد (DayMNo) داخل الشهر نفسه (الترقيم يبدأ من 1 كل شهر)', 2, 0),

    (15, N'C - المطابقة', N'الافتتاحي: مجموع المدين = مجموع الدائن قبل بداية الفترة', 1, 0),
    (16, N'C - المطابقة', N'حركة الفترة: إجمالي المدين = إجمالي الدائن', 1, 0),
    (17, N'C - المطابقة', N'الختامي: صافي دفتر الأستاذ حتى نهاية الفترة = صفر', 1, 0),
    (18, N'C - المطابقة', N'معادلة الميزانية: الأصول = الخصوم + حقوق الملكية + نتائج السنوات', 1, 0),
    (19, N'C - المطابقة', N'مجموع جذور الميزانية = مجموع حساباتها التحليلية', 1, 0),
    (20, N'C - المطابقة', N'مجموع جذور قائمة الدخل = مجموع حساباتها التحليلية', 1, 0),
    (21, N'C - المطابقة', N'نتيجة السنة الحالية: إيرادات - مصروفات = نتيجة السنة في حقوق الملكية', 1, 0),

    (22, N'D - الربط بقائمة حقوق الملكية', N'جذر حقوق الملكية موجود وواحد (AccEnd = 1 و AccType = 2 و AccParentID = NULL)', 2, 0),
    (23, N'D - الربط بقائمة حقوق الملكية', N'إجمالي حقوق الملكية في قائمة التغيّرات = إجماليها في الميزانية (كل حسابات الملكية تحت الجذر)', 2, 0),

    (24, N'E - ربط التدفقات النقدية', N'يوجد حساب مصنف نقدية (1) في جدول Acc_CashFlowAccounts', 2, 0),
    (25, N'E - ربط التدفقات النقدية', N'تصنيف النقدية مطبق على حساب ليس من أصول الميزانية', 1, 0),
    (26, N'E - ربط التدفقات النقدية', N'حسابات مقابلة غير مصنفة في قيود النقدية خلال الفترة', 2, 0),
    (27, N'E - ربط التدفقات النقدية', N'قيود نقدية ستُستثنى من قائمة التدفقات (بلا مقابل / غير مصنف / غير متوازن)', 2, 0),
    (28, N'E - ربط التدفقات النقدية', N'حسابات نقدية رصيدها الختامي سالب', 2, 0);


    /* =========================================================
       4. A - بنية دليل الحسابات
       ========================================================= */

    -- 1: أب غير موجود أو الأب = 0
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        1, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'الأب = ', a.AccParentID)
    FROM #Acc AS a
    WHERE a.AccParentID IS NOT NULL
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Acc_Account AS x
          WHERE x.AccID = a.AccParentID
      );

    -- 2: أب من شركة أخرى
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        2, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'الأب ', a.AccParentID, N' يتبع الشركة ', p.AccCompany)
    FROM #Acc AS a
    INNER JOIN dbo.Acc_Account AS p
        ON p.AccID = a.AccParentID
    WHERE p.AccCompany <> @Cmp;

    -- 3: غير قابل للوصول من جذر
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        3, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'الأب = ', a.AccParentID)
    FROM #Acc AS a
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Reach AS r
        WHERE r.AccID = a.AccID
    );

    -- 4: تصنيف غير صحيح
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        4, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'AccEnd = ', a.AccEnd, N'، AccType = ', a.AccType)
    FROM #Acc AS a
    WHERE a.ValidClass = 0;

    -- 5: اختلاف التصنيف مع الأب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        5, N'حساب', c.AccID, c.AccCode, c.AccName,
        CONCAT(N'الحساب (', c.AccEnd, N'/', c.AccType, N') والأب ', p.AccCode, N' (', p.AccEnd, N'/', p.AccType, N')')
    FROM #Acc AS c
    INNER JOIN #Acc AS p
        ON p.AccID = c.AccParentID
    WHERE COALESCE(c.AccEnd, -1) <> COALESCE(p.AccEnd, -1)
       OR COALESCE(c.AccType, -1) <> COALESCE(p.AccType, -1);

    -- 6: AccChid مقابل الأبناء الفعليين
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        6, N'حساب', a.AccID, a.AccCode, a.AccName,
        a.AccChid, ISNULL(k.Cnt, 0),
        N'الكمية الأولى = AccChid المخزّن، الثانية = عدد الأبناء الفعلي'
    FROM #Acc AS a
    LEFT JOIN #Kid AS k
        ON k.AccID = a.AccID
    WHERE (a.AccChid > 0 AND k.AccID IS NULL)
       OR (a.AccChid = 0 AND k.AccID IS NOT NULL);

    -- 7: تكرار رمز الحساب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        7, N'حساب', a.AccID, a.AccCode, a.AccName, N'رمز مكرر'
    FROM #Acc AS a
    INNER JOIN
    (
        SELECT AccCode
        FROM #Acc
        WHERE AccCode <> N''
        GROUP BY AccCode
        HAVING COUNT(*) > 1
    ) AS d
        ON d.AccCode = a.AccCode;


    /* =========================================================
       5. جمع بنود القيود المرحّلة مرة واحدة
       ========================================================= */

    SELECT
        d.DayDID,
        d.DayDMID AS MID,
        d.DayDAccID AS AccID,
        m.DayMDate AS EntDate,
        CAST(d.DayDDeb AS DECIMAL(28,3)) AS Deb,
        CAST(d.DayDCrd AS DECIMAL(28,3)) AS Crd
    INTO #Line
    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate <= @ToDate;

    CREATE CLUSTERED INDEX IX_Line_MID
        ON #Line (MID);

    CREATE NONCLUSTERED INDEX IX_Line_Acc
        ON #Line (AccID);

    SELECT
        m.DayMID,
        m.DayMNo,
        m.DayMDate,
        m.DayMDescription,
        CAST(ISNULL(SUM(l.Deb), 0) AS DECIMAL(38,3)) AS TotDeb,
        CAST(ISNULL(SUM(l.Crd), 0) AS DECIMAL(38,3)) AS TotCrd,
        COUNT_BIG(l.DayDID) AS LineCnt
    INTO #Journal
    FROM dbo.Acc_DayMaster AS m
    LEFT JOIN #Line AS l
        ON l.MID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate <= @ToDate
    GROUP BY
        m.DayMID,
        m.DayMNo,
        m.DayMDate,
        m.DayMDescription;

    CREATE UNIQUE CLUSTERED INDEX IX_Journal
        ON #Journal (DayMID);


    /* =========================================================
       6. B - سلامة القيود المرحّلة
       ========================================================= */

    -- 8: قيد غير متوازن
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        8, N'قيد', j.DayMID, CAST(j.DayMNo AS NVARCHAR(50)), j.DayMDescription,
        j.TotDeb - j.TotCrd, j.TotDeb,
        CONCAT(N'بتاريخ ', CONVERT(NVARCHAR(10), j.DayMDate, 23), N'؛ الكمية الأولى = الفرق، الثانية = إجمالي المدين')
    FROM #Journal AS j
    WHERE j.LineCnt > 0
      AND ABS(j.TotDeb - j.TotCrd) >= 0.001;

    -- 9: قيد بلا بنود
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        9, N'قيد', j.DayMID, CAST(j.DayMNo AS NVARCHAR(50)), j.DayMDescription,
        CONCAT(N'بتاريخ ', CONVERT(NVARCHAR(10), j.DayMDate, 23))
    FROM #Journal AS j
    WHERE j.LineCnt = 0;

    -- 10: مخالفة قاعدة الطرف الواحد
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        10, N'بند', l.DayDID, CAST(l.MID AS NVARCHAR(50)), NULL,
        l.Deb, l.Crd,
        CONCAT(N'قيد رقم (المعرّف) ', l.MID, N' بتاريخ ', CONVERT(NVARCHAR(10), l.EntDate, 23))
    FROM #Line AS l
    WHERE (l.Deb > 0 AND l.Crd > 0)
       OR (l.Deb = 0 AND l.Crd = 0)
       OR l.Deb < 0
       OR l.Crd < 0;

    -- 11: حركة على حساب أب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        11, N'حساب', a.AccID, a.AccCode, a.AccName,
        SUM(l.Deb - l.Crd), COUNT_BIG(*),
        N'الكمية الأولى = صافي الحركة (مدين - دائن)، الثانية = عدد البنود'
    FROM #Line AS l
    INNER JOIN #Kid AS k
        ON k.AccID = l.AccID
    INNER JOIN #Acc AS a
        ON a.AccID = l.AccID
    GROUP BY a.AccID, a.AccCode, a.AccName;

    -- 12: حركة على حساب لا يتبع الشركة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        12, N'حساب', l.AccID, x.AccCode, x.AccName,
        SUM(l.Deb - l.Crd), COUNT_BIG(*),
        CONCAT(N'شركة الحساب = ', x.AccCompany)
    FROM #Line AS l
    LEFT JOIN dbo.Acc_Account AS x
        ON x.AccID = l.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccID = l.AccID
    )
    GROUP BY l.AccID, x.AccCode, x.AccName, x.AccCompany;

    -- 13: حركة على حساب بتصنيف غير صحيح
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        13, N'حساب', a.AccID, a.AccCode, a.AccName,
        SUM(l.Deb - l.Crd), COUNT_BIG(*),
        CONCAT(N'AccEnd = ', a.AccEnd, N'، AccType = ', a.AccType)
    FROM #Line AS l
    INNER JOIN #Acc AS a
        ON a.AccID = l.AccID
    WHERE a.ValidClass = 0
    GROUP BY a.AccID, a.AccCode, a.AccName, a.AccEnd, a.AccType;

    -- 14: تكرار رقم القيد داخل السنة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        14, N'قيد', m.DayMID, CAST(m.DayMNo AS NVARCHAR(50)), m.DayMDescription,
        CONCAT(N'رقم مكرر داخل الشهر، بتاريخ ', CONVERT(NVARCHAR(10), m.DayMDate, 23))
    FROM dbo.Acc_DayMaster AS m
    INNER JOIN
    (
        SELECT MONTH(DayMDate) AS Mn, DayMNo
        FROM dbo.Acc_DayMaster
        WHERE DayMCompany = @Cmp
          AND DayMState BETWEEN 1 AND 7
          AND DayMDate >= @YearStart
          AND DayMDate <= @YearEnd
          AND DayMNo IS NOT NULL
        GROUP BY MONTH(DayMDate), DayMNo
        HAVING COUNT(*) > 1
    ) AS d
        ON d.DayMNo = m.DayMNo
       AND d.Mn = MONTH(m.DayMDate)
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate >= @YearStart
      AND m.DayMDate <= @YearEnd;


    /* =========================================================
       7. أرصدة الحسابات التحليلية السليمة التصنيف
       ========================================================= */

    SELECT
        l.AccID,
        a.AccEnd,
        a.AccType,

        CAST(SUM(CASE WHEN l.EntDate < @FromDate  THEN l.Deb - l.Crd ELSE 0 END) AS DECIMAL(38,3)) AS OpenNet,
        CAST(SUM(CASE WHEN l.EntDate < @YearStart THEN l.Deb - l.Crd ELSE 0 END) AS DECIMAL(38,3)) AS PriorNet,
        CAST(SUM(CASE WHEN l.EntDate >= @FromDate THEN l.Deb ELSE 0 END) AS DECIMAL(38,3)) AS PerDeb,
        CAST(SUM(CASE WHEN l.EntDate >= @FromDate THEN l.Crd ELSE 0 END) AS DECIMAL(38,3)) AS PerCrd

    INTO #LeafNet
    FROM #Line AS l
    INNER JOIN #Acc AS a
        ON a.AccID = l.AccID
    WHERE a.ValidClass = 1
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Kid AS k
          WHERE k.AccID = l.AccID
      )
    GROUP BY l.AccID, a.AccEnd, a.AccType;

    CREATE UNIQUE CLUSTERED INDEX IX_LeafNet
        ON #LeafNet (AccID);


    /* =========================================================
       8. C - المطابقة
       ========================================================= */

    DECLARE
        @OpenNet  DECIMAL(38,3),
        @PerDeb   DECIMAL(38,3),
        @PerCrd   DECIMAL(38,3),
        @CloseNet DECIMAL(38,3);

    SELECT
        @OpenNet = ISNULL(SUM(CASE WHEN EntDate <  @FromDate THEN Deb - Crd ELSE 0 END), 0),
        @PerDeb  = ISNULL(SUM(CASE WHEN EntDate >= @FromDate THEN Deb ELSE 0 END), 0),
        @PerCrd  = ISNULL(SUM(CASE WHEN EntDate >= @FromDate THEN Crd ELSE 0 END), 0)
    FROM #Line;

    SET @CloseNet = @OpenNet + @PerDeb - @PerCrd;

    -- 15: الافتتاحي
    UPDATE #Chk
    SET ExpectedValue = 0,
        ActualValue   = @OpenNet,
        Difference    = @OpenNet,
        IssueCount    = CASE WHEN ABS(@OpenNet) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 15;

    -- 16: حركة الفترة (المتوقع = المدين، الفعلي = الدائن)
    UPDATE #Chk
    SET ExpectedValue = @PerDeb,
        ActualValue   = @PerCrd,
        Difference    = @PerDeb - @PerCrd,
        IssueCount    = CASE WHEN ABS(@PerDeb - @PerCrd) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 16;

    -- 17: الختامي
    UPDATE #Chk
    SET ExpectedValue = 0,
        ActualValue   = @CloseNet,
        Difference    = @CloseNet,
        IssueCount    = CASE WHEN ABS(@CloseNet) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 17;

    -- 18: معادلة الميزانية من الحسابات التحليلية السليمة
    DECLARE
        @Assets      DECIMAL(38,3),
        @Liabilities DECIMAL(38,3),
        @EquityAcc   DECIMAL(38,3),
        @PriorNetIS  DECIMAL(38,3),
        @CurNetIS    DECIMAL(38,3),
        @Revenue     DECIMAL(38,3),
        @Expenses    DECIMAL(38,3),
        @PriorResult DECIMAL(38,3),
        @CurResult   DECIMAL(38,3),
        @BsDiff      DECIMAL(38,3);

    SELECT
        @Assets =
            ISNULL(SUM(CASE WHEN AccEnd = 1 AND AccType = 0 THEN  (OpenNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @Liabilities =
            ISNULL(SUM(CASE WHEN AccEnd = 1 AND AccType = 1 THEN -(OpenNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @EquityAcc =
            ISNULL(SUM(CASE WHEN AccEnd = 1 AND AccType = 2 THEN -(OpenNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @PriorNetIS =
            ISNULL(SUM(CASE WHEN AccEnd = 2 THEN PriorNet ELSE 0 END), 0),
        @CurNetIS =
            ISNULL(SUM(CASE WHEN AccEnd = 2 THEN OpenNet - PriorNet + PerDeb - PerCrd ELSE 0 END), 0),
        @Revenue =
            ISNULL(SUM(CASE WHEN AccEnd = 2 AND AccType = 0 THEN -(OpenNet - PriorNet + PerDeb - PerCrd) ELSE 0 END), 0),
        @Expenses =
            ISNULL(SUM(CASE WHEN AccEnd = 2 AND AccType = 1 THEN  (OpenNet - PriorNet + PerDeb - PerCrd) ELSE 0 END), 0)
    FROM #LeafNet;

    SET @PriorResult = -@PriorNetIS;
    SET @CurResult   = -@CurNetIS;
    SET @BsDiff      = @Assets - (@Liabilities + @EquityAcc + @PriorResult + @CurResult);

    UPDATE #Chk
    SET ExpectedValue = @Liabilities + @EquityAcc + @PriorResult + @CurResult,
        ActualValue   = @Assets,
        Difference    = @BsDiff,
        IssueCount    = CASE WHEN ABS(@BsDiff) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 18;

    -- 19 و20: مجموع جذور الشجرة مقابل مجموع الأوراق (يكشف الحركة على فروع غير قابلة للوصول)
    DECLARE
        @RootBS DECIMAL(38,3),
        @RootIS DECIMAL(38,3),
        @LeafBS DECIMAL(38,3),
        @LeafIS DECIMAL(38,3);

    ;WITH RU AS
    (
        SELECT
            n.AccID AS NodeID,
            n.AccEnd,
            CAST(n.OpenNet + n.PerDeb - n.PerCrd AS DECIMAL(38,3)) AS Net
        FROM #LeafNet AS n
        INNER JOIN #Reach AS r
            ON r.AccID = n.AccID

        UNION ALL

        SELECT
            p.AccID,
            u.AccEnd,
            u.Net
        FROM RU AS u
        INNER JOIN #Acc AS c
            ON c.AccID = u.NodeID
        INNER JOIN #Acc AS p
            ON p.AccID = c.AccParentID
    )
    SELECT
        @RootBS = ISNULL(SUM(CASE WHEN u.AccEnd = 1 THEN u.Net ELSE 0 END), 0),
        @RootIS = ISNULL(SUM(CASE WHEN u.AccEnd = 2 THEN u.Net ELSE 0 END), 0)
    FROM RU AS u
    INNER JOIN #Acc AS a
        ON a.AccID = u.NodeID
    WHERE a.AccParentID IS NULL
    OPTION (MAXRECURSION 32767);

    SELECT
        @LeafBS = ISNULL(SUM(CASE WHEN AccEnd = 1 THEN OpenNet + PerDeb - PerCrd ELSE 0 END), 0),
        @LeafIS = ISNULL(SUM(CASE WHEN AccEnd = 2 THEN OpenNet + PerDeb - PerCrd ELSE 0 END), 0)
    FROM #LeafNet;

    UPDATE #Chk
    SET ExpectedValue = @LeafBS,
        ActualValue   = @RootBS,
        Difference    = @LeafBS - @RootBS,
        IssueCount    = CASE WHEN ABS(@LeafBS - @RootBS) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 19;

    UPDATE #Chk
    SET ExpectedValue = @LeafIS,
        ActualValue   = @RootIS,
        Difference    = @LeafIS - @RootIS,
        IssueCount    = CASE WHEN ABS(@LeafIS - @RootIS) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 20;

    -- 21: نتيجة السنة الحالية
    UPDATE #Chk
    SET ExpectedValue = @Revenue - @Expenses,
        ActualValue   = @CurResult,
        Difference    = (@Revenue - @Expenses) - @CurResult,
        IssueCount    = CASE WHEN ABS((@Revenue - @Expenses) - @CurResult) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 21;


    /* =========================================================
       9. D - الربط بقائمة التغيّرات في حقوق الملكية
          (Acc_SelectAccChangesInEquity تبني مكوّناتها من أبناء جذر حقوق الملكية)
       ========================================================= */

    -- 22: جذر حقوق الملكية (قائمة التغيّرات تبني مكوّناتها من أبنائه المباشرين)
    INSERT INTO #Det (CheckNo, ObjectType, Note)
    SELECT
        22, N'إعداد',
        CASE
            WHEN x.Cnt = 0 THEN N'لا يوجد جذر لحقوق الملكية (AccEnd = 1 و AccType = 2 و AccParentID = NULL)'
            ELSE CONCAT(N'يوجد ', x.Cnt, N' جذور لحقوق الملكية؛ يجب أن يكون واحدًا')
        END
    FROM
    (
        SELECT COUNT(*) AS Cnt
        FROM #Acc
        WHERE AccEnd = 1
          AND AccType = 2
          AND AccParentID IS NULL
    ) AS x
    WHERE x.Cnt <> 1;

    -- 23: تغطية حسابات حقوق الملكية في القائمة
    ;WITH Eq AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        INNER JOIN #Reach AS r
            ON r.AccID = a.AccID
        WHERE a.AccEnd = 1
          AND a.AccType = 2
          AND a.AccParentID IS NULL

        UNION ALL

        SELECT c.AccID
        FROM Eq AS e
        INNER JOIN #Acc AS c
            ON c.AccParentID = e.AccID
    )
    SELECT AccID
    INTO #EqCovered
    FROM Eq
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_EqCovered
        ON #EqCovered (AccID);

    DECLARE
        @EqCoveredAcc DECIMAL(38,3),
        @EqBsTotal    DECIMAL(38,3),
        @EqStmtTotal  DECIMAL(38,3);

    SELECT
        @EqCoveredAcc =
            ISNULL(SUM(CASE WHEN n.AccEnd = 1 AND n.AccType = 2 AND e.AccID IS NOT NULL
                            THEN -(n.OpenNet + n.PerDeb - n.PerCrd) ELSE 0 END), 0)
    FROM #LeafNet AS n
    LEFT JOIN #EqCovered AS e
        ON e.AccID = n.AccID;

    SET @EqBsTotal   = @EquityAcc + @PriorResult + @CurResult;
    SET @EqStmtTotal = @EqCoveredAcc + @PriorResult + @CurResult;

    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Note)
    SELECT
        23, N'حساب', a.AccID, a.AccCode, a.AccName,
        -(n.OpenNet + n.PerDeb - n.PerCrd),
        N'رصيد حقوق ملكية (دائن موجب) لا يظهر في قائمة التغيّرات في حقوق الملكية'
    FROM #LeafNet AS n
    INNER JOIN #Acc AS a
        ON a.AccID = n.AccID
    WHERE n.AccEnd = 1
      AND n.AccType = 2
      AND NOT EXISTS (SELECT 1 FROM #EqCovered AS e WHERE e.AccID = n.AccID)
      AND (n.OpenNet + n.PerDeb - n.PerCrd) <> 0;

    UPDATE #Chk
    SET ExpectedValue = @EqBsTotal,
        ActualValue   = @EqStmtTotal,
        Difference    = @EqBsTotal - @EqStmtTotal,
        IssueCount    = CASE WHEN ABS(@EqBsTotal - @EqStmtTotal) >= 0.001 THEN 1 ELSE 0 END
    WHERE CheckNo = 23;


    /* =========================================================
       10. E - ربط التدفقات النقدية
           التصنيف الفعّال: أقرب حساب مصنف في Acc_CashFlowAccounts
       ========================================================= */

    ;WITH AccountAncestors AS
    (
        SELECT
            a.AccID AS LeafAccID,
            a.AccID AS AncestorAccID,
            CAST(0 AS INT) AS Distance,
            CAST('/' + CONVERT(VARCHAR(30), a.AccID) + '/' AS VARCHAR(MAX)) AS VisitedPath
        FROM #Acc AS a

        UNION ALL

        SELECT
            h.LeafAccID,
            p.AccParentID,
            h.Distance + 1,
            CAST(h.VisitedPath + CONVERT(VARCHAR(30), p.AccParentID) + '/' AS VARCHAR(MAX))
        FROM AccountAncestors AS h
        INNER JOIN #Acc AS p
            ON p.AccID = h.AncestorAccID
        WHERE p.AccParentID IS NOT NULL
          AND CHARINDEX('/' + CONVERT(VARCHAR(30), p.AccParentID) + '/', h.VisitedPath) = 0
    ),
    Ranked AS
    (
        SELECT
            h.LeafAccID,
            c.CashFlowType,
            ROW_NUMBER() OVER (PARTITION BY h.LeafAccID ORDER BY h.Distance ASC) AS RN
        FROM AccountAncestors AS h
        INNER JOIN dbo.Acc_CashFlowAccounts AS c
            ON c.AccID = h.AncestorAccID
    )
    SELECT
        a.AccID,
        r.CashFlowType
    INTO #CF
    FROM #Acc AS a
    LEFT JOIN Ranked AS r
        ON r.LeafAccID = a.AccID
       AND r.RN = 1
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_CF
        ON #CF (AccID);

    -- 24: لا يوجد حساب نقدية
    INSERT INTO #Det (CheckNo, ObjectType, Note)
    SELECT
        24, N'إعداد',
        N'لا يوجد أي حساب مصنف (1) نقدية؛ ستكون قائمة التدفقات النقدية صفرية'
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #CF
        WHERE CashFlowType = 1
    );

    -- 25: النقدية على حساب ليس أصلًا من الميزانية
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Note)
    SELECT
        25, N'حساب', a.AccID, a.AccCode, a.AccName,
        CONCAT(N'AccEnd = ', a.AccEnd, N'، AccType = ', a.AccType, N' (المطلوب 1 / 0)')
    FROM #CF AS cf
    INNER JOIN #Acc AS a
        ON a.AccID = cf.AccID
    WHERE cf.CashFlowType = 1
      AND (COALESCE(a.AccEnd, -1) <> 1 OR COALESCE(a.AccType, -1) <> 0);

    -- قيود الفترة التي تمس النقدية (صافي النقدية <> 0)
    SELECT
        l.MID,
        CAST(SUM(l.Deb - l.Crd) AS DECIMAL(38,3)) AS CashNet
    INTO #CashEntry
    FROM #Line AS l
    INNER JOIN #CF AS cf
        ON cf.AccID = l.AccID
       AND cf.CashFlowType = 1
    WHERE l.EntDate >= @FromDate
    GROUP BY l.MID
    HAVING SUM(l.Deb - l.Crd) <> 0;

    CREATE UNIQUE CLUSTERED INDEX IX_CashEntry
        ON #CashEntry (MID);

    -- البنود المقابلة (غير النقدية) في تلك القيود
    SELECT
        l.MID,
        l.DayDID,
        l.AccID,
        cf.CashFlowType,
        CAST(l.Crd - l.Deb AS DECIMAL(38,3)) AS Flow
    INTO #Counter
    FROM #CashEntry AS ce
    INNER JOIN #Line AS l
        ON l.MID = ce.MID
    LEFT JOIN #CF AS cf
        ON cf.AccID = l.AccID
    WHERE ISNULL(cf.CashFlowType, 0) <> 1;

    CREATE CLUSTERED INDEX IX_Counter
        ON #Counter (MID);

    -- 26: حسابات مقابلة غير مصنفة
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        26, N'حساب', c.AccID, x.AccCode, x.AccName,
        SUM(c.Flow), COUNT(DISTINCT c.MID),
        N'الكمية الأولى = صافي التدفق (داخل موجب)، الثانية = عدد القيود؛ صنّفه أو صنّف أحد آبائه في Acc_CashFlowAccounts'
    FROM #Counter AS c
    LEFT JOIN dbo.Acc_Account AS x
        ON x.AccID = c.AccID
    WHERE c.CashFlowType IS NULL
    GROUP BY c.AccID, x.AccCode, x.AccName;

    -- 27: قيود نقدية ستُستثنى
    SELECT
        ce.MID,
        ce.CashNet,
        COUNT_BIG(c.DayDID) AS CounterCnt,
        SUM(CASE WHEN c.DayDID IS NOT NULL AND c.CashFlowType IS NULL THEN 1 ELSE 0 END) AS UnclassCnt,
        CAST(ISNULL(SUM(CASE WHEN c.CashFlowType BETWEEN 2 AND 4 THEN c.Flow END), 0) AS DECIMAL(38,3)) AS ClassifiedNet
    INTO #CashChk
    FROM #CashEntry AS ce
    LEFT JOIN #Counter AS c
        ON c.MID = ce.MID
    GROUP BY ce.MID, ce.CashNet;

    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Amount2, Note)
    SELECT
        27, N'قيد', j.DayMID, CAST(j.DayMNo AS NVARCHAR(50)), j.DayMDescription,
        k.CashNet, k.ClassifiedNet,
        CONCAT
        (
            CONVERT(NVARCHAR(10), j.DayMDate, 23), N'؛ ',
            CASE
                WHEN k.CounterCnt = 0 THEN N'لا توجد بنود مقابلة لحركة النقدية'
                WHEN k.UnclassCnt > 0 THEN N'يوجد حساب مقابل غير مصنف'
                ELSE N'صافي البنود المقابلة لا يطابق صافي النقدية (قيد غير متوازن)'
            END,
            N'؛ الكمية الأولى = صافي النقدية، الثانية = صافي البنود المصنفة'
        )
    FROM #CashChk AS k
    INNER JOIN #Journal AS j
        ON j.DayMID = k.MID
    WHERE k.CounterCnt = 0
       OR k.UnclassCnt > 0
       OR ABS(k.ClassifiedNet - k.CashNet) > 0.001;

    -- 28: رصيد نقدية سالب
    INSERT INTO #Det (CheckNo, ObjectType, ObjectID, ObjectCode, ObjectName, Amount1, Note)
    SELECT
        28, N'حساب', a.AccID, a.AccCode, a.AccName,
        n.OpenNet + n.PerDeb - n.PerCrd,
        N'رصيد ختامي مدين سالب (أي دائن) في حساب نقدية'
    FROM #LeafNet AS n
    INNER JOIN #CF AS cf
        ON cf.AccID = n.AccID
       AND cf.CashFlowType = 1
    INNER JOIN #Acc AS a
        ON a.AccID = n.AccID
    WHERE n.OpenNet + n.PerDeb - n.PerCrd < 0;


    /* =========================================================
       11. عدد الملاحظات للفحوص القائمة على التفاصيل
           (الفحوص 15-21 و23 قيمية: عدّادها محسوب أعلاه)
       ========================================================= */

    UPDATE c
    SET c.IssueCount = d.Cnt
    FROM #Chk AS c
    INNER JOIN
    (
        SELECT CheckNo, COUNT_BIG(*) AS Cnt
        FROM #Det
        GROUP BY CheckNo
    ) AS d
        ON d.CheckNo = c.CheckNo
    WHERE c.CheckNo NOT BETWEEN 15 AND 21
      AND c.CheckNo <> 23;


    /* =========================================================
       RESULT SET 1: جدول الفحوص
       ========================================================= */

    SELECT
        c.CheckNo,
        c.Grp AS CheckGroup,
        c.Title AS CheckTitle,

        CASE c.Severity
            WHEN 1 THEN N'خطأ'
            ELSE N'تحذير'
        END AS Severity,

        CASE
            WHEN c.IssueCount = 0 THEN N'سليم'
            WHEN c.Severity = 1   THEN N'فشل'
            ELSE N'تنبيه'
        END AS CheckStatus,

        c.IssueCount,
        c.ExpectedValue,
        c.ActualValue,
        c.Difference

    FROM #Chk AS c
    ORDER BY c.CheckNo;


    /* =========================================================
       RESULT SET 2: تفاصيل الملاحظات (حتى @MaxDetails لكل فحص)
       ========================================================= */

    SELECT
        x.CheckNo,
        c.Title AS CheckTitle,
        c.IssueCount AS TotalIssuesInCheck,
        x.ObjectType,
        x.ObjectID,
        x.ObjectCode,
        x.ObjectName,
        x.Amount1,
        x.Amount2,
        x.Note
    FROM
    (
        SELECT
            d.*,
            ROW_NUMBER() OVER (PARTITION BY d.CheckNo ORDER BY d.Seq) AS RN
        FROM #Det AS d
    ) AS x
    INNER JOIN #Chk AS c
        ON c.CheckNo = x.CheckNo
    WHERE x.RN <= @MaxDetails
    ORDER BY x.CheckNo, x.Seq;


    /* =========================================================
       RESULT SET 3: الخلاصة
       ========================================================= */

    SELECT
        @Cmp AS CompanyID,
        @Year AS FinancialYear,
        @FromDate AS FromDate,
        @ToDate AS ToDate,

        COUNT(*) AS TotalChecks,
        SUM(CASE WHEN IssueCount > 0 AND Severity = 1 THEN 1 ELSE 0 END) AS FailedErrorChecks,
        SUM(CASE WHEN IssueCount > 0 AND Severity = 2 THEN 1 ELSE 0 END) AS WarningChecks,

        CASE
            WHEN SUM(CASE WHEN IssueCount > 0 AND Severity = 1 THEN 1 ELSE 0 END) > 0
                THEN N'توجد أخطاء تمنع الاعتماد على القوائم المالية'
            WHEN SUM(CASE WHEN IssueCount > 0 AND Severity = 2 THEN 1 ELSE 0 END) > 0
                THEN N'سليمة مع ملاحظات تحتاج مراجعة'
            ELSE N'سليمة: اجتازت كل الفحوص'
        END AS OverallStatus
    FROM #Chk;

END;
GO
GO

/* ---------- Acc_Select_Trial_Balance ---------- */
USE [MADARERPDataBase];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* =====================================================================
   ميزان المراجعة
   ---------------------------------------------------------------------
   القواعد المحاسبية:
   - القيود المرحّلة فقط (DayMState BETWEEN 1 AND 7)، وتخص الشركة @Cmp.
   - رصيد أول المدة = كل الحركات قبل @FromDate من كل السنوات.
   - حركة الفترة = من @FromDate حتى @ToDate.
   - القيود تُسجَّل على الحسابات التحليلية (التي لا أبناء لها) فقط، وتُجمَّع
     أرصدتها نحو الآباء عبر شجرة الحسابات.
   - الصفوف والإجماليات تُحسب من الحسابات التحليلية فقط؛ أي حركة على حساب أب
     لا تدخل في الأرقام وتظهر فقط في ChkNonLeafAccounts.
   - إجماليات الميزان تُحسب لكل حساب تحليلي على حدة (مدين/دائن) دون مقاصة بين
     الحسابات، وتتجاهل فلاتر العرض.
   - شجرة الحسابات تُعالَج كاملة دون إسقاط أي مستوى. أي حلقة (حساب أبوه نفسه، أو
     دورة بين حسابين أو أكثر) تُوقف التقرير بخطأ صريح 50010.

   الأداء:
   - مسح واحد لجداول القيود، ومنه تُشتق الصفوف والإجماليات والفحوص.
   - لا CURSOR ولا قيود مسمّاة على الجداول المؤقتة (آمن للتشغيل المتزامن).

   فهارس مقترحة (إن لم تكن موجودة):
     CREATE INDEX IX_DayMaster_Cmp_State_Date
         ON dbo.Acc_DayMaster (DayMCompany, DayMState, DayMDate) INCLUDE (DayMNo);
     CREATE INDEX IX_DayDetails_Master
         ON dbo.Acc_DayDetails (DayDMID) INCLUDE (DayDAccID, DayDDeb, DayDCrd);
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_Select_Trial_Balance
    @FromDate  DATE     = NULL,
    @ToDate    DATE     = NULL,
    @Cmp       INT      = 1,
    @Year      INT      = 0,
    @AllAcc    BIT      = 0,    -- 1 = الحسابات التحليلية فقط
    @MoveAcc   BIT      = 0,    -- 1 = الحسابات التي لها حركة خلال الفترة فقط
    @BalnceAcc BIT      = 0,    -- 1 = الحسابات التي رصيد نهاية مدتها <> 0 فقط
    @LevelAcc  TINYINT  = 0     -- 0 = كل المستويات ؛ AccLevel المطلق (+ التحليلي الأقل مستوى)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    /* ---------- 1. التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);
    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    /* ---------- 2. شجرة حسابات الشركة ---------- */
    SELECT a.AccID,
           a.AccParentID,
           a.AccLevel,
           CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
           ISNULL(a.AccCode, N'') AS AccCode,
           ISNULL(a.AccName, N'') AS AccName
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc ON #Acc (AccID);
    CREATE NONCLUSTERED INDEX IX_Acc_Parent ON #Acc (AccParentID);

    /* ---------- 3. سلامة الشجرة: لا حلقات ولا حساب أبوه نفسه ----------
       نمشي من الجذور إلى الأسفل. كل حساب داخل حلقة (أو أبوه نفسه) لا يمكن
       الوصول إليه من أي جذر، فإذا اختلف عدد المُوصَل إليهم عن العدد الكلي
       فالشجرة فيها حلقة. لا يوجد حد عمق يُسقط مستويات: أقصى تكرار 1000 مجرد
       شبكة أمان تفشل بخطأ صريح إن تجاوزها، وهذا لا يحدث في شجرة حقيقية. */
    DECLARE @Total INT = (SELECT COUNT(*) FROM #Acc), @Reached INT;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0
           OR NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        JOIN #Acc  AS c ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT(*) FROM Reach
    OPTION (MAXRECURSION 1000);   -- شبكة أمان: تجاوزها يوقف التقرير بخطأ صريح (530) ولا يُسقط شيئًا بصمت

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300) =
            CONCAT(N'شجرة الحسابات فيها حلقة أو حساب أبوه نفسه (عدد الحسابات المتأثرة: ',
                   @Total - @Reached, N'). راجع الحسابات الأب والابن.');
        THROW 50010, @CycleMsg, 1;
    END;

    -- الآباء وعدد أبناء كل منهم (الحساب بلا أبناء = تحليلي)
    SELECT c.AccParentID AS AccID, COUNT(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid ON #Kid (AccID);

    /* ---------- 4. (الحساب ← كل أحفاده بما فيهم نفسه) ---------- */
    ;WITH Cl AS
    (
        SELECT a.AccID AS NodeID, a.AccID AS DescID
        FROM #Acc AS a

        UNION ALL

        SELECT t.NodeID, c.AccID
        FROM Cl AS t
        JOIN #Acc AS c ON c.AccParentID = t.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 1000);   -- شبكة أمان كما في الخطوة 3؛ عمق الشجرة الفعلي أقل منها بكثير

    CREATE UNIQUE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- 5. مسح واحد للقيود (أول المدة + حركة الفترة) ---------- */
    SELECT d.DayDAccID AS AccID,
           CAST(SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(18,3)) AS OpenNet,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END) AS DECIMAL(18,3))              AS PerDeb,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END) AS DECIMAL(18,3))              AS PerCrd,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END) AS BIGINT)                             AS PerCnt
    INTO #Amount
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate   <= @ToDate
    GROUP BY d.DayDAccID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount ON #Amount (AccID);

    /* ---------- 6. فحوص سلامة البيانات (النتيجة المتوقعة: أصفار) ---------- */
    DECLARE @ChkNonLeaf INT, @ChkOrphan INT, @ChkCrossCo INT, @ChkForeign INT, @ChkChid INT;

    -- حسابات عليها حركة وهي أب (الحركة لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT(*)
    FROM #Amount AS am
    JOIN #Kid    AS k ON k.AccID = am.AccID;

    -- حسابات أبوها غير موجود في أي شركة (يتيمة فعلًا)
    SELECT @ChkOrphan = COUNT(*)
    FROM #Acc AS a
    WHERE a.AccParentID > 0
      AND NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS x WHERE x.AccID = a.AccParentID);

    -- حسابات أبوها موجود لكنه يتبع شركة أخرى (ربط خاطئ بين الشركات)
    SELECT @ChkCrossCo = COUNT(*)
    FROM #Acc AS a
    WHERE a.AccParentID > 0
      AND NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)
      AND EXISTS     (SELECT 1 FROM dbo.Acc_Account AS x WHERE x.AccID = a.AccParentID);

    -- حركة على حساب لا يتبع هذه الشركة
    SELECT @ChkForeign = COUNT(*)
    FROM #Amount AS am
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS a WHERE a.AccID = am.AccID);

    -- AccChid المخزَّن لا يطابق وجود الأبناء الفعلي في الشجرة
    SELECT @ChkChid = COUNT(*)
    FROM #Acc AS a
    LEFT JOIN #Kid AS k ON k.AccID = a.AccID
    WHERE (CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
       <> (CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);

    /* ---------- 7. حركات الحسابات التحليلية فقط (أساس الصفوف والإجماليات) ---------- */
    SELECT am.AccID, am.OpenNet, am.PerDeb, am.PerCrd, am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    JOIN #Acc    AS a ON a.AccID = am.AccID
    WHERE NOT EXISTS (SELECT 1 FROM #Kid AS k WHERE k.AccID = am.AccID);

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt ON #LeafAmt (AccID);

    /* ---------- 8. إجماليات الميزان (لكل حساب تحليلي على حدة) ---------- */
    DECLARE
        @SumBlcOldDebit  DECIMAL(18,3), @SumBlcOldCredit  DECIMAL(18,3),
        @SumTotDebit     DECIMAL(18,3), @SumTotCredit     DECIMAL(18,3),
        @SumBlcDebit     DECIMAL(18,3), @SumBlcCredit     DECIMAL(18,3),
        @SumTotBlcDebit  DECIMAL(18,3), @SumTotBlcCredit  DECIMAL(18,3);

    SELECT
        @SumBlcOldDebit  = ISNULL(SUM(CASE WHEN y.OpenNet  > 0 THEN  y.OpenNet  ELSE 0 END), 0),
        @SumBlcOldCredit = ISNULL(SUM(CASE WHEN y.OpenNet  < 0 THEN -y.OpenNet  ELSE 0 END), 0),
        @SumTotDebit     = ISNULL(SUM(y.PerDeb), 0),
        @SumTotCredit    = ISNULL(SUM(y.PerCrd), 0),
        @SumBlcDebit     = ISNULL(SUM(CASE WHEN y.PerNet   > 0 THEN  y.PerNet   ELSE 0 END), 0),
        @SumBlcCredit    = ISNULL(SUM(CASE WHEN y.PerNet   < 0 THEN -y.PerNet   ELSE 0 END), 0),
        @SumTotBlcDebit  = ISNULL(SUM(CASE WHEN y.CloseNet > 0 THEN  y.CloseNet ELSE 0 END), 0),
        @SumTotBlcCredit = ISNULL(SUM(CASE WHEN y.CloseNet < 0 THEN -y.CloseNet ELSE 0 END), 0)
    FROM
    (
        SELECT l.OpenNet, l.PerDeb, l.PerCrd,
               l.PerDeb - l.PerCrd                AS PerNet,
               l.OpenNet + l.PerDeb - l.PerCrd    AS CloseNet
        FROM #LeafAmt AS l
    ) AS y;

    /* ---------- 9. تجميع كل حساب مع أحفاده ---------- */
    SELECT a.AccID, a.AccCode, a.AccName, a.AccParentID, a.AccLevel, a.AccChid,
           CAST(ISNULL(SUM(l.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(l.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(l.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(l.PerCnt ), 0) AS BIGINT)        AS PerCnt
    INTO #Roll
    FROM #Acc AS a
    JOIN #Cl  AS c ON c.NodeID = a.AccID
    LEFT JOIN #LeafAmt AS l ON l.AccID = c.DescID
    GROUP BY a.AccID, a.AccCode, a.AccName, a.AccParentID, a.AccLevel, a.AccChid;

    CREATE UNIQUE CLUSTERED INDEX IX_Roll ON #Roll (AccID);

    /* ---------- 10. النتيجة النهائية ---------- */
    SELECT
        x.AccID,
        x.AccCode,
        x.AccName                          AS AccARName,
        x.AccLevel,
        x.AccParentID                      AS AccParint,
        p.AccName                          AS AccParintName,
        x.AccChid                          AS AccCountChid,

        -- رصيد أول المدة
        CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
        CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
        -- الحركة بالمجاميع
        x.PerDeb                                            AS NewDebit,
        x.PerCrd                                            AS NewCredit,
        -- الحركة بالأرصدة
        CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END    AS BalanceDebit,
        CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END    AS BalanceCredit,
        -- رصيد نهاية الفترة
        CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotBlcDebit,
        CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,

        -- إجماليات الميزان (تتكرر على كل صف)
        @SumBlcOldDebit  AS SumBlcOldDebit,
        @SumBlcOldCredit AS SumBlcOldCredit,
        @SumTotDebit     AS SumTotDebit,
        @SumTotCredit    AS SumTotCredit,
        @SumBlcDebit     AS SumBlcDebit,
        @SumBlcCredit    AS SumBlcCredit,
        @SumTotBlcDebit  AS SumTotBlcDebit,
        @SumTotBlcCredit AS SumTotBlcCredit,

        -- فحوص ذاتية في آخر النتيجة: يجب أن تكون كلها صفرًا
        @SumBlcOldDebit - @SumBlcOldCredit AS ChkOpenDiff,
        @SumTotDebit    - @SumTotCredit    AS ChkPeriodDiff,
        @SumTotBlcDebit - @SumTotBlcCredit AS ChkCloseDiff,
        @ChkNonLeaf                        AS ChkNonLeafAccounts,
        @ChkOrphan                         AS ChkOrphanAccounts,
        @ChkCrossCo                        AS ChkCrossCompanyParents,
        @ChkForeign                        AS ChkForeignAccounts,
        @ChkChid                           AS ChkChidMismatch

    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #Roll AS r
    ) AS x
    LEFT JOIN #Acc AS p ON p.AccID = x.AccParentID
    LEFT JOIN #Kid AS k ON k.AccID = x.AccID
    WHERE (@AllAcc    = 0 OR k.AccID IS NULL)
      AND (@LevelAcc  = 0 OR x.AccLevel = @LevelAcc OR (x.AccLevel < @LevelAcc AND k.AccID IS NULL))
      AND (@MoveAcc   = 0 OR x.PerCnt   > 0)
      AND (@BalnceAcc = 0 OR x.CloseNet <> 0)
    ORDER BY x.AccCode, x.AccID
    OPTION (RECOMPILE);
END;
GO
GO

/* ---------- Acc_SelectAccountStatement ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountStatement]
    @Cmp      INT,
    @UserID   INT = 0,         -- لا يؤثر على النتيجة (للاستخدام في ترويسة التقرير فقط)
    @Year     INT,
    @AccId    BIGINT = 0,      -- الحساب (تحليلي فقط)
    @FromDate DATE,
    @ToDate   DATE,
    @Debit    BIT = 0,         -- 1 = الحركات المدينة فقط
    @Credit   BIT = 0,         -- 1 = الحركات الدائنة فقط
    @CsCID    BIGINT = 0       -- 0 = بلا فلتر مركز تكلفة
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF ISNULL(@AccId, 0) <= 0
        THROW 50001, N'يجب تحديد الحساب.', 1;
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    DECLARE @AccCode NVARCHAR(60), @AccName NVARCHAR(500);

    SELECT @AccCode = a.AccCode, @AccName = a.AccName
    FROM dbo.Acc_Account AS a
    WHERE a.AccID = @AccId AND a.AccCompany = @Cmp;

    IF @AccCode IS NULL
        THROW 50005, N'الحساب غير موجود أو لا يتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = @AccId)
        THROW 50006, N'كشف الحساب متاح للحسابات التحليلية فقط.', 1;

    /* ---------- مركز التكلفة وفروعه ---------- */
    DECLARE @CC TABLE (CsCID BIGINT NOT NULL PRIMARY KEY);

    IF ISNULL(@CsCID, 0) > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
            THROW 50007, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

        ;WITH Tree AS
        (
            SELECT CsCID, 0 AS Lvl
            FROM dbo.Acc_CostCenter
            WHERE CsCID = @CsCID AND CsCCompany = @Cmp

            UNION ALL

            SELECT c.CsCID, t.Lvl + 1
            FROM dbo.Acc_CostCenter AS c
            JOIN Tree AS t ON c.CsCParentID = t.CsCID
            WHERE c.CsCCompany = @Cmp
              AND t.Lvl < 30
        )
        INSERT INTO @CC (CsCID) SELECT CsCID FROM Tree;
    END;

    /* ---------- رصيد بداية المدة: كل الحركات قبل @FromDate من كل السنوات ---------- */
    DECLARE @Opening DECIMAL(18,3);

    SELECT @Opening = ISNULL(SUM(d.DayDDeb), 0) - ISNULL(SUM(d.DayDCrd), 0)
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE d.DayDAccID = @AccId
      AND m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate < @FromDate
      AND (ISNULL(@CsCID, 0) = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
    OPTION (RECOMPILE);

    /* ---------- حركات الفترة (الترتيب: الشهر ثم DayMNo ثم البند) ---------- */
    SELECT
        CAST(ROW_NUMBER() OVER (ORDER BY MONTH(m.DayMDate), m.DayMNo, d.DayDID) AS INT) AS Seq,
        m.DayMID, m.DayMNo, m.DayMDate,
        m.DayMDescription, d.DayDDescription, d.DayDNum,
        d.DayDCsCID, c.CsCCode, c.CsCName,
        d.DayDDeb, d.DayDCrd
    INTO #Mov
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DayDCsCID
    WHERE d.DayDAccID = @AccId
      AND m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate >= @FromDate AND m.DayMDate <= @ToDate
      AND (ISNULL(@CsCID, 0) = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
      AND (@Debit  = 0 OR d.DayDDeb > 0)
      AND (@Credit = 0 OR d.DayDCrd > 0)
    OPTION (RECOMPILE);

    DECLARE @PerDeb DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDDeb), 0) FROM #Mov),
            @PerCrd DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDCrd), 0) FROM #Mov);
    DECLARE @Closing DECIMAL(18,3) = @Opening + @PerDeb - @PerCrd;

    /* ---------- النتيجة: جدول واحد ---------- */
    SELECT R.RowType, R.Seq, R.RowLabel,
           R.DayMID, R.DayMNo,
           CASE WHEN R.RowType = 1
                THEN CONCAT(CAST(R.DayMNo AS NVARCHAR(10)), N'/', RIGHT(CONCAT(N'0', MONTH(R.DayMDate)), 2))
           END AS EntryNo,
           R.DayMDate, R.EntryDescription, R.ItemDescription, R.DayDNum,
           R.CsCID, R.CsCCode, R.CsCName,
           R.Debit, R.Credit, R.Balance,
           CASE WHEN R.Balance > 0 THEN N'مدين' WHEN R.Balance < 0 THEN N'دائن' ELSE N'' END AS BalanceSide,
           @AccId AS AccID, @AccCode AS AccCode, @AccName AS AccName
    FROM
    (
        -- رصيد بداية المدة
        SELECT CAST(0 AS TINYINT) AS RowType, 0 AS Seq, N'رصيد بداية المدة' AS RowLabel,
               CAST(NULL AS BIGINT) AS DayMID, CAST(NULL AS INT) AS DayMNo, CAST(NULL AS DATE) AS DayMDate,
               CAST(NULL AS NVARCHAR(MAX)) AS EntryDescription, CAST(NULL AS NVARCHAR(MAX)) AS ItemDescription,
               CAST(NULL AS NVARCHAR(50)) AS DayDNum,
               CAST(NULL AS BIGINT) AS CsCID, CAST(NULL AS NVARCHAR(60)) AS CsCCode, CAST(NULL AS NVARCHAR(500)) AS CsCName,
               CAST(NULL AS DECIMAL(18,3)) AS Debit, CAST(NULL AS DECIMAL(18,3)) AS Credit,
               @Opening AS Balance

        UNION ALL
        -- الحركات مع الرصيد الجاري على الصفوف الظاهرة
        SELECT CAST(1 AS TINYINT), Seq, CAST(NULL AS NVARCHAR(50)),
               DayMID, DayMNo, DayMDate,
               DayMDescription, DayDDescription, DayDNum,
               DayDCsCID, CsCCode, CsCName,
               DayDDeb, DayDCrd,
               @Opening + SUM(DayDDeb - DayDCrd) OVER (ORDER BY Seq ROWS UNBOUNDED PRECEDING)
        FROM #Mov

        UNION ALL
        -- رصيد خلال الفترة
        SELECT CAST(2 AS TINYINT), 0, N'رصيد خلال الفترة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               @PerDeb, @PerCrd, @PerDeb - @PerCrd

        UNION ALL
        -- رصيد نهاية المدة
        SELECT CAST(3 AS TINYINT), 0, N'رصيد نهاية المدة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               NULL, NULL, @Closing
    ) AS R
    ORDER BY R.RowType, R.Seq;
END;
GO
GO

/* ---------- Acc_SelectCostCenterStatement ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenterStatement]
    @Cmp      INT,
    @UserID   INT = 0,         -- لا يؤثر على النتيجة (للاستخدام في ترويسة التقرير فقط)
    @Year     INT,
    @CsCId    BIGINT = 0,      -- مركز التكلفة (تحليلي فقط)
    @FromDate DATE,
    @ToDate   DATE,
    @Debit    BIT = 0,         -- 1 = الحركات المدينة فقط
    @Credit   BIT = 0,         -- 1 = الحركات الدائنة فقط
    @AccID    BIGINT = 0       -- 0 = بلا فلتر الحسابات (يقبل أب/جد/ابن)
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF ISNULL(@CsCId, 0) <= 0
        THROW 50001, N'يجب تحديد مركز التكلفة.', 1;
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @AccID = ISNULL(@AccID, 0);

    DECLARE @CsCCode NVARCHAR(60), @CsCName NVARCHAR(500);

    SELECT @CsCCode = c.CsCCode, @CsCName = c.CsCName
    FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCID = @CsCId AND c.CsCCompany = @Cmp;

    IF @CsCCode IS NULL
        THROW 50005, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS k WHERE k.CsCParentID = @CsCId)
        THROW 50006, N'كشف مركز التكلفة متاح لمراكز التكلفة التحليلية فقط.', 1;

    /* ---------- الحساب وفروعه (إن وُجد فلتر) ---------- */
    DECLARE @Acc TABLE (AccID BIGINT NOT NULL PRIMARY KEY);

    IF @AccID > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID AND AccCompany = @Cmp)
            THROW 50007, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

        ;WITH AccTree AS
        (
            SELECT a.AccID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_Account AS a
            WHERE a.AccID = @AccID AND a.AccCompany = @Cmp

            UNION ALL

            SELECT a.AccID, p.Lvl + 1
            FROM dbo.Acc_Account AS a
            JOIN AccTree AS p ON a.AccParentID = p.AccID
            WHERE a.AccCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @Acc (AccID) SELECT AccID FROM AccTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- رصيد بداية المدة: كل الحركات قبل @FromDate من كل السنوات ---------- */
    DECLARE @Opening DECIMAL(18,3);

    SELECT @Opening = ISNULL(SUM(d.DayDDeb), 0) - ISNULL(SUM(d.DayDCrd), 0)
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE d.DayDCsCID = @CsCId
      AND m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate < @FromDate
      AND (@AccID = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
    OPTION (RECOMPILE);

    /* ---------- حركات الفترة (الترتيب: الشهر ثم DayMNo ثم البند) ---------- */
    SELECT
        CAST(ROW_NUMBER() OVER (ORDER BY MONTH(m.DayMDate), m.DayMNo, d.DayDID) AS INT) AS Seq,
        m.DayMID, m.DayMNo, m.DayMDate,
        m.DayMDescription, d.DayDDescription, d.DayDNum,
        d.DayDAccID, a.AccCode, a.AccName,
        d.DayDDeb, d.DayDCrd
    INTO #Mov
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    LEFT JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
    WHERE d.DayDCsCID = @CsCId
      AND m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate >= @FromDate AND m.DayMDate <= @ToDate
      AND (@AccID = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
      AND (@Debit  = 0 OR d.DayDDeb > 0)
      AND (@Credit = 0 OR d.DayDCrd > 0)
    OPTION (RECOMPILE);

    DECLARE @PerDeb DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDDeb), 0) FROM #Mov),
            @PerCrd DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDCrd), 0) FROM #Mov);
    DECLARE @Closing DECIMAL(18,3) = @Opening + @PerDeb - @PerCrd;

    /* ---------- النتيجة: جدول واحد ---------- */
    SELECT R.RowType, R.Seq, R.RowLabel,
           R.DayMID, R.DayMNo,
           CASE WHEN R.RowType = 1
                THEN CONCAT(CAST(R.DayMNo AS NVARCHAR(10)), N'/', RIGHT(CONCAT(N'0', MONTH(R.DayMDate)), 2))
           END AS EntryNo,
           R.DayMDate, R.EntryDescription, R.ItemDescription, R.DayDNum,
           R.AccountID AS AccID, R.AccountCode AS AccCode, R.AccountName AS AccName,
           R.Debit, R.Credit, R.Balance,
           CASE WHEN R.Balance > 0 THEN N'مدين' WHEN R.Balance < 0 THEN N'دائن' ELSE N'' END AS BalanceSide,
           @CsCId AS CsCID, @CsCCode AS CsCCode, @CsCName AS CsCName
    FROM
    (
        -- رصيد بداية المدة
        SELECT CAST(0 AS TINYINT) AS RowType, 0 AS Seq, N'رصيد بداية المدة' AS RowLabel,
               CAST(NULL AS BIGINT) AS DayMID, CAST(NULL AS INT) AS DayMNo, CAST(NULL AS DATE) AS DayMDate,
               CAST(NULL AS NVARCHAR(MAX)) AS EntryDescription, CAST(NULL AS NVARCHAR(MAX)) AS ItemDescription,
               CAST(NULL AS NVARCHAR(50)) AS DayDNum,
               CAST(NULL AS BIGINT) AS AccountID, CAST(NULL AS NVARCHAR(60)) AS AccountCode, CAST(NULL AS NVARCHAR(500)) AS AccountName,
               CAST(NULL AS DECIMAL(18,3)) AS Debit, CAST(NULL AS DECIMAL(18,3)) AS Credit,
               @Opening AS Balance

        UNION ALL
        -- الحركات مع الرصيد الجاري على الصفوف الظاهرة
        SELECT CAST(1 AS TINYINT), Seq, CAST(NULL AS NVARCHAR(50)),
               DayMID, DayMNo, DayMDate,
               DayMDescription, DayDDescription, DayDNum,
               DayDAccID, AccCode, AccName,
               DayDDeb, DayDCrd,
               @Opening + SUM(DayDDeb - DayDCrd) OVER (ORDER BY Seq ROWS UNBOUNDED PRECEDING)
        FROM #Mov

        UNION ALL
        -- رصيد خلال الفترة
        SELECT CAST(2 AS TINYINT), 0, N'رصيد خلال الفترة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               @PerDeb, @PerCrd, @PerDeb - @PerCrd

        UNION ALL
        -- رصيد نهاية المدة
        SELECT CAST(3 AS TINYINT), 0, N'رصيد نهاية المدة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               NULL, NULL, @Closing
    ) AS R
    ORDER BY R.RowType, R.Seq;
END;
GO

/* =========== اختبار سريع ===========
EXEC dbo.Acc_SelectCostCenterStatement @Cmp = 1, @Year = 2026, @CsCId = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30';
EXEC dbo.Acc_SelectCostCenterStatement @Cmp = 1, @Year = 2026, @CsCId = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @AccID = 213;   -- حساب أب بكل أحفاده
EXEC dbo.Acc_SelectCostCenterStatement @Cmp = 1, @Year = 2026, @CsCId = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @Debit = 1;
=================================================== */
GO

/* ---------- Acc_SelectAccountAnalysis ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountAnalysis]
    @Cmp       INT,
    @UserID    INT      = 0,   -- لا يؤثر على النتيجة (للترويسة فقط)
    @Year      INT,
    @AccId     BIGINT   = 0,   -- الحساب الأب (0 = من الجذور)
    @FromDate  DATE,
    @ToDate    DATE,
    @AllAcc    BIT      = 0,   -- 1 = الحسابات التحليلية فقط ، 0 = الكل (آباء وتحليلية)
    @AllLevel  BIT      = 0,   -- 1 = كل المستويات (أبناء وأحفاد) ، 0 = الأبناء المباشرون فقط
    @MoveAcc   BIT      = 0,   -- 1 = الحسابات التي لها حركة خلال الفترة فقط
    @BalnceAcc BIT      = 1,   -- 1 = الحسابات التي رصيد نهاية مدتها <> 0 فقط
    @LevelAcc  TINYINT  = 0,   -- 0 = بلا فلتر ؛ المستوى المطلق AccLevel (+ التحليلي الأقل مستوى)
    @Debit     BIT      = 0,   -- 1 = رصيد نهاية المدة مدين فقط
    @Credit    BIT      = 0,   -- 1 = رصيد نهاية المدة دائن فقط
    @CsCID     BIGINT   = 0    -- مركز التكلفة (أب/جد/ابن) ؛ 0 = بلا فلتر
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @AccId = ISNULL(@AccId, 0);
    SET @CsCID = ISNULL(@CsCID, 0);

    IF @AccId > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccId AND AccCompany = @Cmp)
        THROW 50005, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

    /* ---------- مركز التكلفة وفروعه ---------- */
    DECLARE @CC TABLE (CsCID BIGINT NOT NULL PRIMARY KEY);

    IF @CsCID > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
            THROW 50007, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

        ;WITH CcTree AS
        (
            SELECT CsCID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_CostCenter
            WHERE CsCID = @CsCID AND CsCCompany = @Cmp

            UNION ALL

            SELECT c.CsCID, p.Lvl + 1
            FROM dbo.Acc_CostCenter AS c
            JOIN CcTree AS p ON c.CsCParentID = p.CsCID
            WHERE c.CsCCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @CC (CsCID) SELECT CsCID FROM CcTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- شجرة الحسابات تحت الحساب المطلوب (Depth 1 = الأبناء المباشرون) ---------- */
    ;WITH AccTree AS
    (
        SELECT a.AccID, a.AccParentID, a.AccLevel, a.AccCode, a.AccName, CAST(1 AS INT) AS Depth
        FROM dbo.Acc_Account AS a
        WHERE a.AccCompany = @Cmp
          AND a.AccID <> ISNULL(a.AccParentID, 0)
          AND (   (@AccId > 0 AND a.AccParentID = @AccId)
               OR (@AccId = 0 AND (a.AccParentID IS NULL OR a.AccParentID = 0)))

        UNION ALL

        SELECT a.AccID, a.AccParentID, a.AccLevel, a.AccCode, a.AccName, p.Depth + 1
        FROM dbo.Acc_Account AS a
        JOIN AccTree AS p ON a.AccParentID = p.AccID
        WHERE a.AccCompany = @Cmp AND p.Depth < 30
    )
    SELECT AccID, AccParentID, AccLevel, AccCode, AccName, Depth
    INTO #Node
    FROM AccTree
    OPTION (MAXRECURSION 100);

    CREATE UNIQUE CLUSTERED INDEX IX_Node ON #Node (AccID);

    /* ---------- (الحساب ← كل أحفاده بما فيهم نفسه) لتجميع الأرصدة نحو الآباء ---------- */
    ;WITH Cl AS
    (
        SELECT n.AccID AS NodeID, n.AccID AS DescID
        FROM #Node AS n

        UNION ALL

        SELECT c.NodeID, k.AccID
        FROM Cl AS c
        JOIN #Node AS k ON k.AccParentID = c.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 100);

    CREATE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- حركة كل حساب: مرة واحدة على الجداول الكبيرة ---------- */
    SELECT d.DayDAccID AS AccID,
           SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)                      AS PerCnt
    INTO #Amt
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    JOIN #Node              AS n ON n.AccID  = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate   <= @ToDate
      AND (@CsCID = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
    GROUP BY d.DayDAccID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amt ON #Amt (AccID);

    /* ---------- ملخص الترويسة: رصيد الحساب المطلوب نفسه (يتجاهل فلاتر العرض) ---------- */
    DECLARE @HOpen DECIMAL(18,3), @HPerDeb DECIMAL(18,3), @HPerCrd DECIMAL(18,3);

    SELECT @HOpen   = CAST(ISNULL(SUM(OpenNet), 0) AS DECIMAL(18,3)),
           @HPerDeb = CAST(ISNULL(SUM(PerDeb ), 0) AS DECIMAL(18,3)),
           @HPerCrd = CAST(ISNULL(SUM(PerCrd ), 0) AS DECIMAL(18,3))
    FROM #Amt;

    DECLARE @HPerNet DECIMAL(18,3) = @HPerDeb - @HPerCrd;
    DECLARE @HClose  DECIMAL(18,3) = @HOpen + @HPerNet;

    /* ---------- تجميع كل حساب مع أحفاده ---------- */
    SELECT n.AccID, n.AccParentID, n.AccLevel, n.AccCode, n.AccName, n.Depth,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM #Node AS k WHERE k.AccParentID = n.AccID) THEN 0 ELSE 1 END AS BIT) AS IsLeaf,
           CAST(ISNULL(SUM(a.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(a.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(a.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(a.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #R
    FROM #Node AS n
    JOIN #Cl   AS c ON c.NodeID = n.AccID
    LEFT JOIN #Amt AS a ON a.AccID = c.DescID
    GROUP BY n.AccID, n.AccParentID, n.AccLevel, n.AccCode, n.AccName, n.Depth;

    /* ---------- النتيجة ---------- */
    SELECT x.AccID, x.AccCode, x.AccName, x.AccLevel, x.AccParentID,
           pa.AccName AS AccParentName,
           x.IsLeaf,

           -- رصيد أول المدة
           CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
           CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
           -- الحركة بالمجاميع
           x.PerDeb AS NewDebit,
           x.PerCrd AS NewCredit,
           -- الحركة بالأرصدة
           CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END AS BalanceDebit,
           CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
           -- رصيد آخر المدة
           CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotDebit,
           CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotCredit,

           -- ملخص الترويسة (يتكرر على كل صف)
           CASE WHEN @HOpen   > 0 THEN  @HOpen   ELSE 0 END AS SumBlcOldDebit,
           CASE WHEN @HOpen   < 0 THEN -@HOpen   ELSE 0 END AS SumBlcOldCredit,
           @HPerDeb AS SumTotDebit,
           @HPerCrd AS SumTotCredit,
           CASE WHEN @HPerNet > 0 THEN  @HPerNet ELSE 0 END AS SumBlcDebit,
           CASE WHEN @HPerNet < 0 THEN -@HPerNet ELSE 0 END AS SumBlcCredit,
           CASE WHEN @HClose  > 0 THEN  @HClose  ELSE 0 END AS SumTotBlcDebit,
           CASE WHEN @HClose  < 0 THEN -@HClose  ELSE 0 END AS SumTotBlcCredit
    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #R AS r
    ) AS x
    LEFT JOIN dbo.Acc_Account AS pa ON pa.AccID = x.AccParentID
    WHERE (@AllAcc   = 0 OR x.IsLeaf = 1)
      AND (@AllLevel = 1 OR x.Depth  = 1)
      AND (@LevelAcc = 0 OR x.AccLevel = @LevelAcc OR (x.AccLevel < @LevelAcc AND x.IsLeaf = 1))
      AND (@MoveAcc   = 0 OR x.PerCnt   > 0)
      AND (@BalnceAcc = 0 OR x.CloseNet <> 0)
      AND (@Debit     = 0 OR x.CloseNet > 0)
      AND (@Credit    = 0 OR x.CloseNet < 0)
    ORDER BY x.AccCode, x.AccLevel;
END;
GO

/* =========== اختبار سريع (غيّر الأرقام) ===========
EXEC dbo.Acc_SelectAccountAnalysis @Cmp = 1, @Year = 2026, @AccId = 213,
     @FromDate = '2026-10-01', @ToDate = '2026-10-30';          -- الأبناء المباشرون ، رصيد نهاية <> 0
EXEC dbo.Acc_SelectAccountAnalysis @Cmp = 1, @Year = 2026, @AccId = 213,
     @FromDate = '2026-10-01', @ToDate = '2026-10-30', @AllLevel = 1, @AllAcc = 1;  -- كل التحليلية
EXEC dbo.Acc_SelectAccountAnalysis @Cmp = 1, @Year = 2026, @AccId = 213,
     @FromDate = '2026-10-01', @ToDate = '2026-10-30', @MoveAcc = 1, @Credit = 1;
-- تحقق: SumBlcOld + SumBlcPeriod = SumTotBlc ، ويطابق أرقام الـ PDF القديم (35,085,046.106 / 587,476.779 / 35,672,522.885)
=================================================== */

/* فهارس مقترحة (إن لم تكن موجودة):
CREATE INDEX IX_DayDetails_Acc ON dbo.Acc_DayDetails (DayDAccID) INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID);
CREATE INDEX IX_DayMaster_Cmp_State_Date ON dbo.Acc_DayMaster (DayMCompany, DayMState, DayMDate) INCLUDE (DayMNo);
CREATE INDEX IX_Account_Parent ON dbo.Acc_Account (AccParentID) INCLUDE (AccCompany);
*/
GO

/* ---------- Acc_SelectCostCenterAnalysis ---------- */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenterAnalysis]
    @Cmp       INT,
    @UserID    INT      = 0,   -- لا يؤثر على النتيجة (للترويسة فقط)
    @Year      INT,
    @CsCID     BIGINT   = 0,   -- مركز التكلفة الأب (0 = من الجذور)
    @FromDate  DATE,
    @ToDate    DATE,
    @AllCsC    BIT      = 0,   -- 1 = مراكز التكلفة التحليلية فقط ، 0 = الكل (آباء وتحليلية)
    @AllLevel  BIT      = 0,   -- 1 = كل المستويات (أبناء وأحفاد) ، 0 = الأبناء المباشرون فقط
    @MoveCsC   BIT      = 0,   -- 1 = المراكز التي لها حركة خلال الفترة فقط
    @BalnceCsC BIT      = 1,   -- 1 = المراكز التي رصيد نهاية مدتها <> 0 فقط
    @LevelCsC  TINYINT  = 0,   -- 0 = بلا فلتر ؛ المستوى المطلق CsCLevel (+ التحليلي الأقل مستوى)
    @Debit     BIT      = 0,   -- 1 = رصيد نهاية المدة مدين فقط
    @Credit    BIT      = 0,   -- 1 = رصيد نهاية المدة دائن فقط
    @AccId     BIGINT   = 0    -- الحساب (أب/جد/ابن) ؛ 0 = بلا فلتر
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @CsCID = ISNULL(@CsCID, 0);
    SET @AccId = ISNULL(@AccId, 0);

    IF @CsCID > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
        THROW 50005, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

    /* ---------- الحساب وفروعه (إن وُجد فلتر) ---------- */
    DECLARE @Acc TABLE (AccID BIGINT NOT NULL PRIMARY KEY);

    IF @AccId > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccId AND AccCompany = @Cmp)
            THROW 50007, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

        ;WITH AccTree AS
        (
            SELECT a.AccID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_Account AS a
            WHERE a.AccID = @AccId AND a.AccCompany = @Cmp

            UNION ALL

            SELECT a.AccID, p.Lvl + 1
            FROM dbo.Acc_Account AS a
            JOIN AccTree AS p ON a.AccParentID = p.AccID
            WHERE a.AccCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @Acc (AccID) SELECT AccID FROM AccTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- شجرة مراكز التكلفة تحت المركز المطلوب (Depth 1 = الأبناء المباشرون) ---------- */
    ;WITH CcTree AS
    (
        SELECT c.CsCID, c.CsCParentID, c.CsCLevel, c.CsCCode, c.CsCName, CAST(1 AS INT) AS Depth
        FROM dbo.Acc_CostCenter AS c
        WHERE c.CsCCompany = @Cmp
          AND c.CsCID <> ISNULL(c.CsCParentID, 0)
          AND (   (@CsCID > 0 AND c.CsCParentID = @CsCID)
               OR (@CsCID = 0 AND (c.CsCParentID IS NULL OR c.CsCParentID = 0)))

        UNION ALL

        SELECT c.CsCID, c.CsCParentID, c.CsCLevel, c.CsCCode, c.CsCName, p.Depth + 1
        FROM dbo.Acc_CostCenter AS c
        JOIN CcTree AS p ON c.CsCParentID = p.CsCID
        WHERE c.CsCCompany = @Cmp AND p.Depth < 30
    )
    SELECT CsCID, CsCParentID, CsCLevel, CsCCode, CsCName, Depth
    INTO #Node
    FROM CcTree
    OPTION (MAXRECURSION 100);

    CREATE UNIQUE CLUSTERED INDEX IX_Node ON #Node (CsCID);

    /* ---------- (المركز ← كل أحفاده بما فيهم نفسه) لتجميع الأرصدة نحو الآباء ---------- */
    ;WITH Cl AS
    (
        SELECT n.CsCID AS NodeID, n.CsCID AS DescID
        FROM #Node AS n

        UNION ALL

        SELECT c.NodeID, k.CsCID
        FROM Cl AS c
        JOIN #Node AS k ON k.CsCParentID = c.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 100);

    CREATE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- حركة كل مركز: مرة واحدة على الجداول الكبيرة ---------- */
    SELECT d.DayDCsCID AS CsCID,
           SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)                      AS PerCnt
    INTO #Amt
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    JOIN #Node              AS n ON n.CsCID  = d.DayDCsCID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate   <= @ToDate
      AND (@AccId = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
    GROUP BY d.DayDCsCID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amt ON #Amt (CsCID);

    /* ---------- ملخص الترويسة: رصيد المركز المطلوب نفسه (يتجاهل فلاتر العرض) ---------- */
    DECLARE @HOpen DECIMAL(18,3), @HPerDeb DECIMAL(18,3), @HPerCrd DECIMAL(18,3);

    SELECT @HOpen   = CAST(ISNULL(SUM(OpenNet), 0) AS DECIMAL(18,3)),
           @HPerDeb = CAST(ISNULL(SUM(PerDeb ), 0) AS DECIMAL(18,3)),
           @HPerCrd = CAST(ISNULL(SUM(PerCrd ), 0) AS DECIMAL(18,3))
    FROM #Amt;

    DECLARE @HPerNet DECIMAL(18,3) = @HPerDeb - @HPerCrd;
    DECLARE @HClose  DECIMAL(18,3) = @HOpen + @HPerNet;

    /* ---------- تجميع كل مركز مع أحفاده ---------- */
    SELECT n.CsCID, n.CsCParentID, n.CsCLevel, n.CsCCode, n.CsCName, n.Depth,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM #Node AS k WHERE k.CsCParentID = n.CsCID) THEN 0 ELSE 1 END AS BIT) AS IsLeaf,
           CAST(ISNULL(SUM(a.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(a.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(a.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(a.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #R
    FROM #Node AS n
    JOIN #Cl   AS c ON c.NodeID = n.CsCID
    LEFT JOIN #Amt AS a ON a.CsCID = c.DescID
    GROUP BY n.CsCID, n.CsCParentID, n.CsCLevel, n.CsCCode, n.CsCName, n.Depth;

    /* ---------- النتيجة ---------- */
    SELECT x.CsCID, x.CsCCode, x.CsCName, x.CsCLevel, x.CsCParentID,
           pc.CsCName AS CsCParentName,
           x.IsLeaf,

           -- رصيد أول المدة
           CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
           CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
           -- الحركة بالمجاميع
           x.PerDeb AS NewDebit,
           x.PerCrd AS NewCredit,
           -- الحركة بالأرصدة
           CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END AS BalanceDebit,
           CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
           -- رصيد آخر المدة
           CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotDebit,
           CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotCredit,

           -- ملخص الترويسة (يتكرر على كل صف)
           CASE WHEN @HOpen   > 0 THEN  @HOpen   ELSE 0 END AS SumBlcOldDebit,
           CASE WHEN @HOpen   < 0 THEN -@HOpen   ELSE 0 END AS SumBlcOldCredit,
           @HPerDeb AS SumTotDebit,
           @HPerCrd AS SumTotCredit,
           CASE WHEN @HPerNet > 0 THEN  @HPerNet ELSE 0 END AS SumBlcDebit,
           CASE WHEN @HPerNet < 0 THEN -@HPerNet ELSE 0 END AS SumBlcCredit,
           CASE WHEN @HClose  > 0 THEN  @HClose  ELSE 0 END AS SumTotBlcDebit,
           CASE WHEN @HClose  < 0 THEN -@HClose  ELSE 0 END AS SumTotBlcCredit
    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #R AS r
    ) AS x
    LEFT JOIN dbo.Acc_CostCenter AS pc ON pc.CsCID = x.CsCParentID
    WHERE (@AllCsC   = 0 OR x.IsLeaf = 1)
      AND (@AllLevel = 1 OR x.Depth  = 1)
      AND (@LevelCsC = 0 OR x.CsCLevel = @LevelCsC OR (x.CsCLevel < @LevelCsC AND x.IsLeaf = 1))
      AND (@MoveCsC   = 0 OR x.PerCnt   > 0)
      AND (@BalnceCsC = 0 OR x.CloseNet <> 0)
      AND (@Debit     = 0 OR x.CloseNet > 0)
      AND (@Credit    = 0 OR x.CloseNet < 0)
    ORDER BY x.CsCCode, x.CsCLevel;
END;
GO

/* =========== اختبار سريع ===========
EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = 1, @Year = 2026, @CsCID = 0,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30';                       -- مراكز الجذور
EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = 1, @Year = 2026, @CsCID = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @AllLevel = 1, @AllCsC = 1;  -- كل التحليلية تحت المركز 5
EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = 1, @Year = 2026, @CsCID = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @AccId = 5;           -- بحساب مصروفات مثلًا
-- تحقق: مجموع مراكز الأب بعد فلتر الحساب = رصيد الحساب نفسه عند ذلك المركز
=================================================== */

/* فهرس مقترح (إن لم يكن موجودًا):
CREATE INDEX IX_DayDetails_CsC ON dbo.Acc_DayDetails (DayDCsCID) INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd);
CREATE INDEX IX_CostCenter_Parent ON dbo.Acc_CostCenter (CsCParentID) INCLUDE (CsCCompany);
*/
GO

/* =====================================================================
   اختبار إجراءات قيد اليومية (Acc_SaveDayVoucher وما حوله)
   كل شيء داخل معاملة تنتهي بـ ROLLBACK: لا يبقى أي قيد تجريبي.
   غيّر @UserId (مستخدم موجود في Mng_User) ثم نفّذ الملف كله.
   النتيجة: أسطر PASS / FAIL في تبويب Messages.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
SET XACT_ABORT OFF;

DECLARE @Cmp    INT    = 10;
DECLARE @UserId BIGINT = 1;      -- رقم مستخدم موجود في Mng_User
DECLARE @Year   INT    = 2026;

BEGIN TRY
    BEGIN TRAN;

    CREATE TABLE #Res (N INT IDENTITY(1,1), Name NVARCHAR(300), Ok BIT);
    CREATE TABLE #R   (DayMID BIGINT, DayMNo INT, DayMState TINYINT, VoucherNo NVARCHAR(50));

    /* ---------- اختيار حسابات ومركز ---------- */
    DECLARE @A1 BIGINT, @A2 BIGINT, @PA BIGINT, @K1 BIGINT;

    SELECT TOP (1) @A1 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 1 AND a.AccType = 0
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode;

    SELECT TOP (1) @A2 = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND a.AccEnd = 2 AND a.AccType = 1
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode;

    SELECT TOP (1) @PA = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp AND EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
    ORDER BY a.AccCode;

    SELECT TOP (1) @K1 = c.CsCID FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS g WHERE g.CsCParentID = c.CsCID)
    ORDER BY c.CsCCode;

    IF @A1 IS NULL OR @A2 IS NULL OR @PA IS NULL OR @K1 IS NULL
        THROW 51001, N'تعذّر اختيار الحسابات أو مركز التكلفة.', 1;

    /* ---------- بنود جاهزة ---------- */
    DECLARE @Bal dbo.Acc_DayLineType, @Unbal dbo.Acc_DayLineType, @Parent dbo.Acc_DayLineType,
            @Both dbo.Acc_DayLineType, @One dbo.Acc_DayLineType;

    INSERT @Bal   VALUES (1, @A1, 500, 0, @K1, N'D1', N'بند 1'), (2, @A2, 0, 500, NULL, N'D2', N'بند 2');
    INSERT @Unbal VALUES (1, @A1, 500, 0, NULL, NULL, NULL),    (2, @A2, 0, 300, NULL, NULL, NULL);
    INSERT @Parent VALUES (1, @PA, 100, 0, NULL, NULL, NULL),   (2, @A2, 0, 100, NULL, NULL, NULL);
    INSERT @Both  VALUES (1, @A1, 100, 100, NULL, NULL, NULL),  (2, @A2, 0, 0, NULL, NULL, NULL);
    INSERT @One   VALUES (1, @A1, 100, 0, NULL, NULL, NULL);

    DECLARE @en INT, @id1 BIGINT, @id2 BIGINT, @id3 BIGINT, @id4 BIGINT, @no INT, @expect INT, @st TINYINT;

    /* ===== T1: حفظ مؤقت لقيد غير متوازن: يُقبل بلا رقم ===== */
    INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
         @Date = '2026-03-10', @Info = N'TEST مؤقت', @Post = 0, @Lines = @Unbal;
    SELECT TOP (1) @id1 = DayMID FROM #R ORDER BY DayMID DESC;
    INSERT #Res VALUES (N'T1 حفظ مؤقت لقيد غير متوازن: حالة 0 ورقم 0 و2 بند',
        CASE WHEN EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id1 AND DayMState = 0 AND DayMNo = 0)
              AND (SELECT COUNT(*) FROM dbo.Acc_DayDetails WHERE DayDMID = @id1) = 2 THEN 1 ELSE 0 END);

    /* ===== T2: ترحيل غير متوازن مرفوض (50111) ولا يتغير شيء ===== */
    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = @id1,
             @Date = '2026-03-10', @Info = N'TEST مؤقت', @Post = 1, @Lines = @Unbal;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T2 ترحيل قيد غير متوازن = خطأ 50111 والقيد يبقى مؤقتًا',
        CASE WHEN @en = 50111
              AND EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id1 AND DayMState = 0 AND DayMNo = 0) THEN 1 ELSE 0 END);

    /* ===== T3: تعديل القيد المؤقت وترحيله متوازنًا: حالة 1 ورقم = أكبر رقم في الشهر + 1 ===== */
    SELECT @expect = ISNULL(MAX(DayMNo), 0) + 1 FROM dbo.Acc_DayMaster
    WHERE DayMCompany = @Cmp AND DayMDate >= '2026-03-01' AND DayMDate < '2026-04-01';

    DELETE #R;
    INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = @id1,
         @Date = '2026-03-10', @Info = N'TEST مرحّل', @Post = 1, @Lines = @Bal;
    INSERT #Res VALUES (N'T3 ترحيل متوازن: حالة 1 ورقم الشهر = أكبر رقم + 1 وصيغة الرقم صحيحة',
        CASE WHEN EXISTS (SELECT 1 FROM #R WHERE DayMID = @id1 AND DayMState = 1 AND DayMNo = @expect
                            AND VoucherNo = CONCAT(@expect, N'/03'))
              AND EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id1 AND DayMState = 1 AND DayMNo = @expect)
              AND (SELECT COUNT(*) FROM dbo.Acc_DayDetails WHERE DayDMID = @id1) = 2
              AND (SELECT SUM(DayDDeb) - SUM(DayDCrd) FROM dbo.Acc_DayDetails WHERE DayDMID = @id1) = 0 THEN 1 ELSE 0 END);

    /* ===== T4: قيد ثانٍ في الشهر نفسه يأخذ الرقم التالي ===== */
    DELETE #R;
    INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
         @Date = '2026-03-20', @Info = N'TEST ثانٍ', @Post = 1, @Lines = @Bal;
    SELECT TOP (1) @id2 = DayMID FROM #R ORDER BY DayMID DESC;
    INSERT #Res VALUES (N'T4 قيد ثانٍ في الشهر نفسه: الرقم = السابق + 1',
        CASE WHEN EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id2 AND DayMNo = @expect + 1 AND DayMState = 1) THEN 1 ELSE 0 END);

    /* ===== T5: قيد في شهر آخر: الترقيم يبدأ حسب ذلك الشهر ===== */
    SELECT @expect = ISNULL(MAX(DayMNo), 0) + 1 FROM dbo.Acc_DayMaster
    WHERE DayMCompany = @Cmp AND DayMDate >= '2026-11-01' AND DayMDate < '2026-12-01';

    DELETE #R;
    INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
         @Date = '2026-11-05', @Info = N'TEST شهر آخر', @Post = 1, @Lines = @Bal;
    SELECT TOP (1) @id3 = DayMID FROM #R ORDER BY DayMID DESC;
    INSERT #Res VALUES (N'T5 شهر مختلف: الرقم محسوب لذلك الشهر وصيغته /11',
        CASE WHEN EXISTS (SELECT 1 FROM #R WHERE DayMID = @id3 AND DayMNo = @expect AND VoucherNo = CONCAT(@expect, N'/11')) THEN 1 ELSE 0 END);

    /* ===== T6: تعديل قيد مُرحّل مرفوض (50121) ===== */
    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = @id1,
             @Date = '2026-03-10', @Info = N'TEST تعديل', @Post = 0, @Lines = @Bal;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T6 تعديل قيد مُرحّل = خطأ 50121', CASE WHEN @en = 50121 THEN 1 ELSE 0 END);

    /* ===== T7: القيد المُعاد من المراجعة (2) يُعدَّل ويُرحَّل ويحتفظ برقمه في الشهر نفسه ===== */
    UPDATE dbo.Acc_DayMaster SET DayMState = 2 WHERE DayMID = @id1;
    SELECT @no = DayMNo FROM dbo.Acc_DayMaster WHERE DayMID = @id1;

    DELETE #R;
    INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = @id1,
         @Date = '2026-03-12', @Info = N'TEST بعد المراجعة', @Post = 1, @Lines = @Bal;
    INSERT #Res VALUES (N'T7 قيد مُعاد (2): يُرحَّل من جديد برقمه نفسه ضمن الشهر',
        CASE WHEN EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id1 AND DayMState = 1 AND DayMNo = @no) THEN 1 ELSE 0 END);

    /* ===== T8: رفض البنود غير الصحيحة ===== */
    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
             @Date = '2026-03-10', @Info = N'TEST', @Post = 0, @Lines = @Parent;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T8a بند على حساب أب = خطأ 50105', CASE WHEN @en = 50105 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
             @Date = '2026-03-10', @Info = N'TEST', @Post = 0, @Lines = @Both;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T8b بند مدين ودائن معًا أو صفري = خطأ 50106', CASE WHEN @en = 50106 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
             @Date = '2026-03-10', @Info = N'TEST', @Post = 1, @Lines = @One;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T8c ترحيل ببند واحد = خطأ 50107', CASE WHEN @en = 50107 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
             @Date = '2025-03-10', @Info = N'TEST', @Post = 0, @Lines = @Bal;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T8d تاريخ خارج السنة = خطأ 50101', CASE WHEN @en = 50101 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
             @Date = '2026-03-10', @Info = N'   ', @Post = 0, @Lines = @Bal;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T8e شرح فارغ = خطأ 50102', CASE WHEN @en = 50102 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY
        EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp + 999, @Year = @Year, @User = @UserId, @DayMID = 0,
             @Date = '2026-03-10', @Info = N'TEST', @Post = 0, @Lines = @Bal;
    END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T8f حسابات لا تتبع الشركة = خطأ 50104', CASE WHEN @en = 50104 THEN 1 ELSE 0 END);

    /* ===== T9: الحذف: المؤقت فقط ===== */
    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_DeleteDayVoucher @Cmp = @Cmp, @DayMID = @id1; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T9a حذف قيد مُرحّل = خطأ 50122 والقيد باقٍ',
        CASE WHEN @en = 50122 AND EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id1) THEN 1 ELSE 0 END);

    DELETE #R;
    INSERT #R EXEC dbo.Acc_SaveDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = 0,
         @Date = '2026-04-10', @Info = N'TEST للحذف', @Post = 0, @Lines = @Bal;
    SELECT TOP (1) @id4 = DayMID FROM #R ORDER BY DayMID DESC;
    EXEC dbo.Acc_DeleteDayVoucher @Cmp = @Cmp, @DayMID = @id4;
    INSERT #Res VALUES (N'T9b حذف قيد مؤقت: يختفي الرأس والبنود',
        CASE WHEN NOT EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @id4)
              AND NOT EXISTS (SELECT 1 FROM dbo.Acc_DayDetails WHERE DayDMID = @id4) THEN 1 ELSE 0 END);

    /* ===== T10: النسخ ينشئ قيدًا مؤقتًا بالبنود نفسها ===== */
    DECLARE @new BIGINT;
    CREATE TABLE #C (NewDayMID BIGINT);
    INSERT #C EXEC dbo.Acc_CopyDayVoucher @Cmp = @Cmp, @Year = @Year, @User = @UserId, @DayMID = @id1, @NewDate = '2026-05-01';
    SELECT @new = NewDayMID FROM #C;
    INSERT #Res VALUES (N'T10 نسخ القيد: حالة 0 ورقم 0 وبنود ومجاميع مطابقة',
        CASE WHEN EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @new AND DayMState = 0 AND DayMNo = 0
                            AND DayMDate = '2026-05-01')
              AND (SELECT COUNT(*) FROM dbo.Acc_DayDetails WHERE DayDMID = @new) = 2
              AND (SELECT SUM(DayDDeb) FROM dbo.Acc_DayDetails WHERE DayDMID = @new) = 500
              AND (SELECT SUM(DayDCrd) FROM dbo.Acc_DayDetails WHERE DayDMID = @new) = 500 THEN 1 ELSE 0 END);

    /* ===== T11: فتح القيد: غير موجود = 50120 ===== */
    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectDayEntry @Cmp = @Cmp, @DayMID = -1; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res VALUES (N'T11 فتح قيد غير موجود = خطأ 50120', CASE WHEN @en = 50120 THEN 1 ELSE 0 END);

    /* ===== النتيجة ===== */
    DECLARE @i INT = 1, @n INT = (SELECT MAX(N) FROM #Res), @nm NVARCHAR(300), @ok BIT,
            @Fail INT = (SELECT COUNT(*) FROM #Res WHERE Ok = 0);

    WHILE @i <= @n
    BEGIN
        SELECT @nm = Name, @ok = Ok FROM #Res WHERE N = @i;
        PRINT CONCAT(CASE WHEN @ok = 1 THEN N'PASS - ' ELSE N'FAIL - ' END, @nm);
        SET @i += 1;
    END;
    PRINT CONCAT(N'الإجمالي: ', @n, N' اختبار | فشل: ', @Fail);

    ROLLBACK;
    PRINT N'تم التراجع عن كل القيود التجريبية.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    PRINT CONCAT(N'خطأ غير متوقع: ', ERROR_NUMBER(), N' | سطر ', ERROR_LINE(), N' | ', ERROR_MESSAGE());
    THROW;
END CATCH;

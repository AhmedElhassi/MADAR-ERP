USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   الميزانية العمومية
   ---------------------------------------------------------------------
   القواعد المحاسبية:
   - القيود المرحّلة فقط (DayMState = 7) للشركة @Cmp، حتى @ToDate.
   - الرصيد السابق = كل الحركات قبل @FromDate من كل السنوات.
   - القيد يُسجَّل على الحسابات التحليلية فقط؛ تُجمَّع نحو الآباء تصاعديًّا.
   - الأصول (AccType=0) = الرصيد المدين، الخصوم (1) وحقوق الملكية (2) = الرصيد الدائن.
   - السنة المالية لا تُقفل، فحسابات قائمة الدخل (AccEnd=2) تتراكم، وتُضاف
     إلى حقوق الملكية بصفّين مستقلين:
       * نتائج السنوات السابقة   (كل ما قبل 1 يناير من @Year)
       * نتيجة السنة الحالية     (من 1 يناير حتى @ToDate)
     وبذلك يكون: الأصول = الخصوم + حقوق الملكية + نتائج، والفرق
     BalanceDifference يساوي فرق دفتر الأستاذ فقط (صفر إن كانت القيود متوازنة).
   - مؤشرات سلامة البيانات في آخر النتيجة (يجب أن تكون أصفارًا).
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccBalanceSheet]
    @FromDate   DATE     = NULL,
    @ToDate     DATE     = NULL,
    @Cmp        INT      = 1,
    @Year       INT      = 0,
    @AllAcc     BIT      = 0,
    @MoveAcc    BIT      = 0,
    @BalnceAcc  BIT      = 0,
    @LevelAcc   TINYINT  = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Out;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #LeafIS;
    DROP TABLE IF EXISTS #LeafAmt;
    DROP TABLE IF EXISTS #Amount;
    DROP TABLE IF EXISTS #AccIS;
    DROP TABLE IF EXISTS #AccBS;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Acc;

    /* 1. التحقق من المدخلات */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year
       OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);


    /* 2. تحميل شجرة حسابات الشركة */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);


    /* 3. التحقق من الحسابات اليتيمة */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS x
              WHERE x.AccID = a.AccParentID
          )
    )
        THROW 50011, N'شجرة الحسابات تحتوي على حسابات يتيمة؛ الحساب الأب غير موجود.', 1;


    /* 4. التحقق من الربط بين الشركات */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #Acc AS p
              WHERE p.AccID = a.AccParentID
          )
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS x
              WHERE x.AccID = a.AccParentID
          )
    )
        THROW 50012, N'شجرة الحسابات تحتوي على ربط بين حسابات شركتين مختلفتين.', 1;


    /* 5. التحقق من الحلقات والحسابات غير القابلة للوصول */

    DECLARE
        @Total   BIGINT,
        @Reached BIGINT;

    SELECT @Total = COUNT_BIG(*)
    FROM #Acc;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        INNER JOIN #Acc AS c
            ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT_BIG(*)
    FROM Reach
    OPTION (MAXRECURSION 32767);

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300);

        SET @CycleMsg =
            CONCAT(
                N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول من الجذور. عدد الحسابات المتأثرة: ',
                @Total - @Reached
            );

        THROW 50010, @CycleMsg, 1;
    END;


    /* 6. تحديد عدد الأبناء الفعلي */

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);


    /* 7. حسابات الميزانية العمومية، وحسابات قائمة الدخل (لنتيجة السنة) */

    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        AccEnd,
        AccType
    INTO #AccBS
    FROM #Acc
    WHERE AccEnd = 1
      AND AccType IN (0, 1, 2);

    CREATE UNIQUE CLUSTERED INDEX IX_AccBS
        ON #AccBS (AccID);

    SELECT AccID
    INTO #AccIS
    FROM #Acc
    WHERE AccEnd = 2
      AND AccType IN (0, 1);

    CREATE UNIQUE CLUSTERED INDEX IX_AccIS
        ON #AccIS (AccID);


    /* 8. التحقق من تجانس تصنيف حسابات الميزانية مع آبائها */

    IF EXISTS
    (
        SELECT 1
        FROM #AccBS AS c
        INNER JOIN #AccBS AS p
            ON p.AccID = c.AccParentID
        WHERE c.AccType <> p.AccType
    )
        THROW 50013, N'يوجد اختلاف في تصنيف الحساب عن تصنيف الحساب الأب في الميزانية.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #AccBS AS c
        INNER JOIN #Acc AS p
            ON p.AccID = c.AccParentID
        WHERE p.AccEnd <> 1
    )
        THROW 50014, N'يوجد حساب ميزانية تابع لحساب لا ينتمي إلى الميزانية العمومية.', 1;


    /* 9. مسح واحد للحركات حتى @ToDate (كل الحسابات) */

    SELECT
        d.DayDAccID AS AccID,

        -- كل ما قبل @FromDate
        CAST(SUM(CASE WHEN m.DayMDate < @FromDate
                      THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS OpenNet,

        -- كل ما قبل 1 يناير من السنة (لنتائج السنوات السابقة)
        CAST(SUM(CASE WHEN m.DayMDate < @YearStart
                      THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS PriorNet,

        CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END) AS DECIMAL(28,3)) AS PerDeb,
        CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END) AS DECIMAL(28,3)) AS PerCrd,

        SUM(CONVERT(BIGINT, CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)) AS PerCnt

    INTO #Amount

    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID

    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @ToDate

    GROUP BY d.DayDAccID

    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount
        ON #Amount (AccID);


    /* 10. مؤشرات سلامة البيانات */

    DECLARE
        @ChkNonLeaf BIGINT = 0,
        @ChkForeign BIGINT = 0,
        @ChkChid    BIGINT = 0;

    -- حركة مسجلة على حساب أب (لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT_BIG(*)
    FROM #Amount AS am
    INNER JOIN #Kid AS k
        ON k.AccID = am.AccID;

    -- حركة على حساب لا يتبع الشركة
    SELECT @ChkForeign = COUNT_BIG(*)
    FROM #Amount AS am
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS a WHERE a.AccID = am.AccID);

    -- عدم تطابق AccChid مع الأبناء الفعليين
    SELECT @ChkChid = COUNT_BIG(*)
    FROM #Acc AS a
    LEFT JOIN #Kid AS k
        ON k.AccID = a.AccID
    WHERE (CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
        <> (CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);


    /* 11. حركات الحسابات التحليلية */

    -- الميزانية
    SELECT
        am.AccID,
        am.OpenNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    INNER JOIN #AccBS AS a
        ON a.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
        ON #LeafAmt (AccID);

    -- قائمة الدخل (لنتائج السنوات السابقة والسنة الحالية)
    SELECT
        am.AccID,
        am.OpenNet,
        am.PriorNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafIS
    FROM #Amount AS am
    INNER JOIN #AccIS AS i
        ON i.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );


    /* 12. إجماليات الأصول والخصوم وحقوق الملكية + نتائج السنوات */

    DECLARE
        @TotalAssets      DECIMAL(38,3),
        @TotalLiabilities DECIMAL(38,3),
        @TotalEquityAcc   DECIMAL(38,3),   -- حسابات حقوق الملكية فقط
        @PriorNet         DECIMAL(38,3),   -- صافي مدين قائمة الدخل قبل بداية السنة
        @CurOpenNet       DECIMAL(38,3),   -- من بداية السنة حتى قبل @FromDate
        @CurPerDeb        DECIMAL(38,3),
        @CurPerCrd        DECIMAL(38,3),
        @CurPerCnt        BIGINT,
        @PriorResult      DECIMAL(38,3),   -- نتائج السنوات السابقة (الدائن موجب)
        @CurResult        DECIMAL(38,3),   -- نتيجة السنة الحالية (الدائن موجب)
        @TotalEquity      DECIMAL(38,3);

    SELECT
        @TotalAssets =
            ISNULL(SUM(CASE WHEN a.AccType = 0 THEN  (l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalLiabilities =
            ISNULL(SUM(CASE WHEN a.AccType = 1 THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalEquityAcc =
            ISNULL(SUM(CASE WHEN a.AccType = 2 THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0)
    FROM #LeafAmt AS l
    INNER JOIN #AccBS AS a
        ON a.AccID = l.AccID;

    SELECT
        @PriorNet   = ISNULL(SUM(i.PriorNet), 0),
        @CurOpenNet = ISNULL(SUM(i.OpenNet - i.PriorNet), 0),
        @CurPerDeb  = ISNULL(SUM(i.PerDeb), 0),
        @CurPerCrd  = ISNULL(SUM(i.PerCrd), 0),
        @CurPerCnt  = ISNULL(SUM(i.PerCnt), 0)
    FROM #LeafIS AS i;

    SET @PriorResult = -@PriorNet;
    SET @CurResult   = -(@CurOpenNet + @CurPerDeb - @CurPerCrd);
    SET @TotalEquity = @TotalEquityAcc + @PriorResult + @CurResult;


    /* 13. التجميع التصاعدي من الحسابات التحليلية إلى الآباء */

    ;WITH RollUp AS
    (
        SELECT
            l.AccID AS NodeID,
            l.OpenNet,
            l.PerDeb,
            l.PerCrd,
            l.PerCnt
        FROM #LeafAmt AS l

        UNION ALL

        SELECT
            p.AccID AS NodeID,
            r.OpenNet,
            r.PerDeb,
            r.PerCrd,
            r.PerCnt
        FROM RollUp AS r
        INNER JOIN #AccBS AS c
            ON c.AccID = r.NodeID
        INNER JOIN #AccBS AS p
            ON p.AccID = c.AccParentID
           AND c.AccParentID > 0
    ),
    RollTotals AS
    (
        SELECT
            NodeID AS AccID,
            SUM(OpenNet) AS OpenNet,
            SUM(PerDeb) AS PerDeb,
            SUM(PerCrd) AS PerCrd,
            SUM(PerCnt) AS PerCnt
        FROM RollUp
        GROUP BY NodeID
    )
    SELECT
        a.AccID,
        a.AccCode,
        a.AccName,
        a.AccParentID,
        a.AccLevel,
        a.AccChid,
        a.AccType,

        CAST(ISNULL(t.OpenNet, 0) AS DECIMAL(28,3)) AS OpenNet,
        CAST(ISNULL(t.PerDeb, 0) AS DECIMAL(28,3)) AS PerDeb,
        CAST(ISNULL(t.PerCrd, 0) AS DECIMAL(28,3)) AS PerCrd,

        ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt

    INTO #Roll

    FROM #AccBS AS a
    LEFT JOIN RollTotals AS t
        ON t.AccID = a.AccID

    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_Roll
        ON #Roll (AccID);


    /* 14. صفوف الميزانية + صفّا نتائج السنوات (Kind: 0 حساب، 1 سنوات سابقة، 2 السنة الحالية) */

    SELECT
        x.AccID,
        x.AccCode,
        x.AccName,
        x.AccLevel,
        x.AccParentID,
        p.AccName AS AccParentName,
        x.AccChid,
        x.AccType,
        CAST(CASE WHEN k.AccID IS NULL THEN 1 ELSE 0 END AS BIT) AS IsLeaf,
        x.OpenNet,
        x.PerDeb,
        x.PerCrd,
        x.PerCnt,
        CAST(0 AS TINYINT) AS Kind
    INTO #Out
    FROM #Roll AS x
    LEFT JOIN #AccBS AS p
        ON p.AccID = x.AccParentID
    LEFT JOIN #Kid AS k
        ON k.AccID = x.AccID;

    INSERT INTO #Out
    (
        AccID, AccCode, AccName, AccLevel, AccParentID, AccParentName,
        AccChid, AccType, IsLeaf, OpenNet, PerDeb, PerCrd, PerCnt, Kind
    )
    VALUES
    (
        -1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', 1, NULL, NULL,
        0, 2, 1, @PriorNet, 0, 0, 0, 1
    ),
    (
        -2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', 1, NULL, NULL,
        0, 2, 1, @CurOpenNet, @CurPerDeb, @CurPerCrd, @CurPerCnt, 2
    );


    /* 15. النتيجة النهائية */

    SELECT
        x.AccID,
        x.AccCode,
        x.AccName AS AccARName,
        x.AccLevel,
        x.AccParentID AS AccParint,
        x.AccParentName AS AccParintName,
        x.AccChid AS AccCountChid,
        x.AccType,

        CASE
            WHEN x.AccType = 0 THEN N'الأصول'
            WHEN x.AccType = 1 THEN N'الخصوم'
            WHEN x.AccType = 2 THEN N'حقوق الملكية'
        END AS AccountCategory,

        -- الرصيد السابق
        CASE WHEN x.OpenNet > 0 THEN x.OpenNet ELSE 0 END AS OldDebit,
        CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,

        -- حركة الفترة
        x.PerDeb AS NewDebit,
        x.PerCrd AS NewCredit,

        -- صافي حركة الفترة
        CASE WHEN x.PerNet > 0 THEN x.PerNet ELSE 0 END AS BalanceDebit,
        CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,

        -- الرصيد الختامي
        CASE WHEN x.CloseNet > 0 THEN x.CloseNet ELSE 0 END AS TotBlcDebit,
        CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,

        x.CloseNet AS NetBalance,
        x.PerCnt AS MovementCount,

        CAST(CASE WHEN x.Kind = 2 THEN 1 ELSE 0 END AS BIT) AS IsCurrentYearResult,

        @TotalAssets AS TotalAssets,
        @TotalLiabilities AS TotalLiabilities,
        @TotalEquity AS TotalEquity,

        @TotalAssets - (@TotalLiabilities + @TotalEquity)
            AS BalanceDifference,

        CAST(CASE WHEN x.Kind = 1 THEN 1 ELSE 0 END AS BIT) AS IsPriorYearsResult,
        @PriorResult AS PriorYearsResult,
        @CurResult   AS CurrentYearResult,

        -- مؤشرات سلامة البيانات
        @ChkNonLeaf AS ChkNonLeafAccounts,
        @ChkForeign AS ChkForeignAccounts,
        @ChkChid    AS ChkChidMismatch

    FROM
    (
        SELECT
            o.*,

            CAST(o.PerDeb - o.PerCrd AS DECIMAL(28,3)) AS PerNet,

            CAST(o.OpenNet + o.PerDeb - o.PerCrd AS DECIMAL(28,3)) AS CloseNet

        FROM #Out AS o
    ) AS x

    WHERE
        -- صفّا النتائج يظهران دائمًا (ولا يخضعان لفلاتر العرض إلا الحركة والرصيد)
        (
            x.Kind > 0
            OR
            (
                (@AllAcc = 0 OR x.IsLeaf = 1)

                AND
                (
                    @LevelAcc = 0
                    OR x.AccLevel = @LevelAcc
                    OR (x.AccLevel < @LevelAcc AND x.IsLeaf = 1)
                )
            )
        )

        AND (@MoveAcc = 0 OR x.PerCnt > 0)

        AND (@BalnceAcc = 0 OR x.CloseNet <> 0)

    ORDER BY
        x.Kind,
        x.AccCode,
        x.AccID

    OPTION (RECOMPILE);

END;
GO

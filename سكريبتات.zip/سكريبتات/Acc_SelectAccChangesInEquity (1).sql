USE [MADARERPDataBase]
GO
/****** Object:  StoredProcedure [dbo].[Acc_SelectAccChangesInEquity]    Script Date: 2026-10-31 4:03:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccChangesInEquity]
    @FromDate DATE,
    @ToDate   DATE,
    @Cmp      INT = 1
AS
BEGIN
    /* =====================================================================
       اسم التقرير : قائمة التغيّرات في حقوق الملكية
                     (Statement of Changes in Equity)
       الإجراء     : dbo.Acc_SelectAccChangesInEquity
       المدخلات    : @FromDate و@ToDate ضمن سنة مالية واحدة، و@Cmp = الشركة.
       المحتوى     : مكوّنا حقوق الملكية تحت الحساب 12997:
                       13012 = رأس المال
                       13906 = الأرباح والخسائر
                     لكل مكوّن: الرصيد الافتتاحي، حركة الفترة (مدين/دائن)،
                     صافي التغيّر، الرصيد الختامي، ثم صف إجمالي حقوق الملكية.
       القواعد     : القيود المرحّلة فقط (DayMState = 7)؛
                     الافتتاحي = كل الحركات قبل @FromDate من كل السنوات؛
                     القيد يُسجَّل على الحساب التحليلي فقط (حركة على حساب أب
                     ضمن الشجرة = خطأ 50006).
       نتائج النشاط: السنة المالية لا تُقفل، فنتيجة النشاط تبقى في حسابات قائمة الدخل.
                     لذلك يضيف التقرير صفّين لتطابق إجمالي حقوق الملكية مع الميزانية:
                       AccID = -1 نتائج السنوات السابقة (كل ما قبل 1 يناير)
                       AccID = -2 نتيجة السنة الحالية (من 1 يناير حتى @ToDate،
                                  وافتتاحيها ما كان من 1 يناير حتى قبل @FromDate)
       ملاحظات     :
         1) أرقام الحسابات 12997 و13012 و13906 ثابتة داخل الكود، فالتقرير
            مرتبط بدليل حسابات شركة بعينها رغم وجود @Cmp.
         2) أي حساب حقوق ملكية آخر تحت غير 13012 و13906 لا يدخل هذا التقرير.
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #EquityTree;
    DROP TABLE IF EXISTS #EquityKid;
    DROP TABLE IF EXISTS #Result;
    DROP TABLE IF EXISTS #Output;

    /* 1. التحقق من المدخلات */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50001, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50002, N'الشركة المحددة غير صحيحة.', 1;

    IF YEAR(@FromDate) <> YEAR(@ToDate)
        THROW 50003, N'يجب أن تقع الفترة ضمن السنة المالية نفسها.', 1;


    /* 2. التحقق من حساب حقوق الملكية ومكوناته */

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Acc_Account
        WHERE AccID = 12997
          AND AccCompany = @Cmp
          AND AccEnd = 1
          AND AccType = 2
    )
        THROW 50004, N'حساب حقوق الملكية غير موجود أو تصنيفه غير صحيح.', 1;

    IF
    (
        SELECT COUNT(*)
        FROM dbo.Acc_Account
        WHERE AccID IN (13012, 13906)
          AND AccCompany = @Cmp
          AND AccParentID = 12997
    ) <> 2
        THROW 50005, N'حسابا رأس المال والأرباح والخسائر غير مرتبطين بحساب حقوق الملكية المحدد.', 1;


    /* 3. تحميل شجرة حقوق الملكية */

    ;WITH EquityTree AS
    (
        SELECT
            A.AccID,
            A.AccParentID,
            A.AccLevel,
            A.AccChid,
            A.AccCode,
            A.AccName,
            A.AccID AS EquityRoot,
            CAST(
                '/' + CAST(A.AccID AS VARCHAR(20)) + '/'
                AS VARCHAR(MAX)
            ) AS AccountPath
        FROM dbo.Acc_Account A
        WHERE A.AccID IN (13012, 13906)
          AND A.AccCompany = @Cmp
          AND A.AccParentID = 12997

        UNION ALL

        SELECT
            C.AccID,
            C.AccParentID,
            C.AccLevel,
            C.AccChid,
            C.AccCode,
            C.AccName,
            P.EquityRoot,
            CAST(
                P.AccountPath + CAST(C.AccID AS VARCHAR(20)) + '/'
                AS VARCHAR(MAX)
            )
        FROM dbo.Acc_Account C
        INNER JOIN EquityTree P
            ON C.AccParentID = P.AccID
        WHERE C.AccCompany = @Cmp
          AND P.AccountPath NOT LIKE
              '%/' + CAST(C.AccID AS VARCHAR(20)) + '/%'
    )
    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        EquityRoot
    INTO #EquityTree
    FROM EquityTree
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_EquityTree
        ON #EquityTree (AccID);


    /* 4. تحديد الحسابات الأب */

    SELECT DISTINCT
        AccParentID AS AccID
    INTO #EquityKid
    FROM #EquityTree
    WHERE AccParentID IS NOT NULL;

    CREATE UNIQUE CLUSTERED INDEX IX_EquityKid
        ON #EquityKid (AccID);


    /* 5. منع الحركات المباشرة على الحسابات الأب */

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Acc_DayMaster M
        INNER JOIN dbo.Acc_DayDetails D
            ON D.DayDMID = M.DayMID
        INNER JOIN #EquityKid K
            ON K.AccID = D.DayDAccID
        WHERE M.DayMCompany = @Cmp
          AND M.DayMState = 7
          AND M.DayMDate <= @ToDate
    )
        THROW 50006, N'توجد حركات مباشرة على حساب أب ضمن شجرة حقوق الملكية. يجب مراجعة توزيع الحركات على الحسابات التحليلية.', 1;


    /* 6. استخراج الأرصدة والحركات من الحسابات التحليلية */

    ;WITH LeafAmounts AS
    (
        SELECT
            T.EquityRoot,

            SUM
            (
                CASE
                    WHEN M.DayMDate < @FromDate
                    THEN ISNULL(D.DayDDeb, 0) - ISNULL(D.DayDCrd, 0)
                    ELSE 0
                END
            ) AS OpeningNet,

            SUM
            (
                CASE
                    WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                    THEN ISNULL(D.DayDDeb, 0)
                    ELSE 0
                END
            ) AS PeriodDebit,

            SUM
            (
                CASE
                    WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                    THEN ISNULL(D.DayDCrd, 0)
                    ELSE 0
                END
            ) AS PeriodCredit

        FROM #EquityTree T
        INNER JOIN dbo.Acc_DayDetails D
            ON D.DayDAccID = T.AccID
        INNER JOIN dbo.Acc_DayMaster M
            ON M.DayMID = D.DayDMID
        WHERE M.DayMCompany = @Cmp
          AND M.DayMState = 7
          AND M.DayMDate <= @ToDate
          AND NOT EXISTS
          (
              SELECT 1
              FROM #EquityKid K
              WHERE K.AccID = T.AccID
          )
        GROUP BY T.EquityRoot
    )
    SELECT
        T.AccID,
        T.AccCode,
        T.AccName,

        CAST(ISNULL(L.OpeningNet, 0) AS DECIMAL(28,3)) AS OpeningNet,
        CAST(ISNULL(L.PeriodDebit, 0) AS DECIMAL(28,3)) AS PeriodDebit,
        CAST(ISNULL(L.PeriodCredit, 0) AS DECIMAL(28,3)) AS PeriodCredit

    INTO #Result
    FROM #EquityTree T
    LEFT JOIN LeafAmounts L
        ON L.EquityRoot = T.AccID
    WHERE T.AccID IN (13012, 13906);

    CREATE UNIQUE CLUSTERED INDEX IX_Result
        ON #Result (AccID);

    ALTER TABLE #Result ALTER COLUMN AccCode NVARCHAR(100) NULL;
    ALTER TABLE #Result ALTER COLUMN AccName NVARCHAR(200) NULL;

    /* نتائج السنوات من حسابات قائمة الدخل التحليلية (السنة لا تُقفل) */

    DECLARE @YearStart DATE = DATEFROMPARTS(YEAR(@FromDate), 1, 1);

    DECLARE
        @PriorNet  DECIMAL(28,3),
        @CurOpen   DECIMAL(28,3),
        @CurDebit  DECIMAL(28,3),
        @CurCredit DECIMAL(28,3);

    SELECT
        @PriorNet  = ISNULL(SUM(CASE WHEN M.DayMDate < @YearStart
                                     THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @CurOpen   = ISNULL(SUM(CASE WHEN M.DayMDate >= @YearStart AND M.DayMDate < @FromDate
                                     THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @CurDebit  = ISNULL(SUM(CASE WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                                     THEN D.DayDDeb ELSE 0 END), 0),
        @CurCredit = ISNULL(SUM(CASE WHEN M.DayMDate BETWEEN @FromDate AND @ToDate
                                     THEN D.DayDCrd ELSE 0 END), 0)
    FROM dbo.Acc_DayMaster M
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = M.DayMID
    INNER JOIN dbo.Acc_Account A
        ON A.AccID = D.DayDAccID
       AND A.AccCompany = @Cmp
       AND A.AccEnd = 2
       AND A.AccType IN (0, 1)
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate <= @ToDate
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Acc_Account C
          WHERE C.AccParentID = A.AccID
      );

    INSERT INTO #Result (AccID, AccCode, AccName, OpeningNet, PeriodDebit, PeriodCredit)
    VALUES
        (-1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', @PriorNet, 0, 0),
        (-2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', @CurOpen, @CurDebit, @CurCredit);


    /* 7. تجهيز التقرير */

    CREATE TABLE #Output
    (
        SortOrder       TINYINT NOT NULL,
        AccID           INT NOT NULL,
        AccCode         NVARCHAR(100) NOT NULL,
        EquityComponent NVARCHAR(200) NOT NULL,

        OpeningDebit    DECIMAL(28,3) NOT NULL,
        OpeningCredit   DECIMAL(28,3) NOT NULL,

        PeriodDebit     DECIMAL(28,3) NOT NULL,
        PeriodCredit    DECIMAL(28,3) NOT NULL,

        NetChange       DECIMAL(28,3) NOT NULL,

        ClosingDebit    DECIMAL(28,3) NOT NULL,
        ClosingCredit   DECIMAL(28,3) NOT NULL
    );


    /* 8. تفاصيل مكونات حقوق الملكية */

    INSERT INTO #Output
    (
        SortOrder,
        AccID,
        AccCode,
        EquityComponent,
        OpeningDebit,
        OpeningCredit,
        PeriodDebit,
        PeriodCredit,
        NetChange,
        ClosingDebit,
        ClosingCredit
    )
    SELECT
        CASE R.AccID
            WHEN 13012 THEN 1
            WHEN 13906 THEN 2
            WHEN -1    THEN 3
            WHEN -2    THEN 4
        END,

        R.AccID,
        R.AccCode,
        R.AccName,

        CASE
            WHEN R.OpeningNet > 0 THEN R.OpeningNet
            ELSE 0
        END,

        CASE
            WHEN R.OpeningNet < 0 THEN -R.OpeningNet
            ELSE 0
        END,

        R.PeriodDebit,
        R.PeriodCredit,

        R.PeriodCredit - R.PeriodDebit,

        CASE
            WHEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit > 0
            THEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit
            ELSE 0
        END,

        CASE
            WHEN R.OpeningNet + R.PeriodDebit - R.PeriodCredit < 0
            THEN -(R.OpeningNet + R.PeriodDebit - R.PeriodCredit)
            ELSE 0
        END

    FROM #Result R;


    /* 9. إجمالي حقوق الملكية */

    DECLARE
        @OpeningTotal DECIMAL(28,3),
        @DebitTotal   DECIMAL(28,3),
        @CreditTotal  DECIMAL(28,3),
        @ClosingTotal DECIMAL(28,3);

    SELECT
        @OpeningTotal = ISNULL(SUM(OpeningNet), 0),
        @DebitTotal   = ISNULL(SUM(PeriodDebit), 0),
        @CreditTotal  = ISNULL(SUM(PeriodCredit), 0)
    FROM #Result;

    SET @ClosingTotal =
        @OpeningTotal + @DebitTotal - @CreditTotal;

    INSERT INTO #Output
    (
        SortOrder,
        AccID,
        AccCode,
        EquityComponent,
        OpeningDebit,
        OpeningCredit,
        PeriodDebit,
        PeriodCredit,
        NetChange,
        ClosingDebit,
        ClosingCredit
    )
    VALUES
    (
        5,
        0,
        N'',
        N'إجمالي حقوق الملكية',

        CASE WHEN @OpeningTotal > 0
             THEN @OpeningTotal ELSE 0 END,

        CASE WHEN @OpeningTotal < 0
             THEN -@OpeningTotal ELSE 0 END,

        @DebitTotal,
        @CreditTotal,
        @CreditTotal - @DebitTotal,

        CASE WHEN @ClosingTotal > 0
             THEN @ClosingTotal ELSE 0 END,

        CASE WHEN @ClosingTotal < 0
             THEN -@ClosingTotal ELSE 0 END
    );


    /* 10. إخراج التقرير */

    SELECT
        AccID,
        AccCode,
        EquityComponent,

        OpeningDebit,
        OpeningCredit,

        PeriodDebit,
        PeriodCredit,

        NetChange,

        ClosingDebit,
        ClosingCredit,

        @FromDate AS FromDate,
        @ToDate AS ToDate

    FROM #Output
    ORDER BY SortOrder;

END;

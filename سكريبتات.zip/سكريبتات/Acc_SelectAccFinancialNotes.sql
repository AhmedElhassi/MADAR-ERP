USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccFinancialNotes]
    @FromDate   DATE     = NULL,
    @ToDate     DATE     = NULL,
    @Cmp        INT      = 1,
    @Year       INT      = 0,
    @AllAcc     BIT      = 0,
    @MoveAcc    BIT      = 0,
    @BalnceAcc  BIT      = 0,
    @LevelAcc   TINYINT  = 0
AS
BEGIN
    /* =====================================================================
       اسم التقرير : الإيضاحات المتممة للقوائم المالية
                     (Notes to the Financial Statements)
       الإجراء     : dbo.Acc_SelectAccFinancialNotes
       المدخلات    : @FromDate و@ToDate ضمن @Year، و@Cmp = الشركة،
                     @AllAcc (1 = التحليلية فقط)، @MoveAcc، @BalnceAcc، @LevelAcc.
       المحتوى     : خمسة إيضاحات:
                       1 الأصول   2 الالتزامات   3 حقوق الملكية
                       4 الإيرادات   5 المصروفات
       الأرصدة     :
         - إيضاحات الميزانية (1-3): الافتتاحي = كل ما قبل @FromDate من كل السنوات.
         - إيضاحات قائمة الدخل (4-5): الافتتاحي = من 1 يناير حتى قبل @FromDate
           (السنة الحالية فقط)، والختامي = من 1 يناير حتى @ToDate.
           ما قبل 1 يناير يظهر ضمن صف «نتائج السنوات السابقة» في إيضاح 3.
       القواعد     : القيود المرحّلة فقط (DayMState = 7)؛ القيد على الحساب
                     التحليلي فقط ويُجمَّع نحو الآباء؛ السنة لا تُقفل.
       حقوق الملكية: إيضاح 3 يضم حسابات حقوق الملكية + صفّين:
                       AccID = -1 نتائج السنوات السابقة
                       AccID = -2 نتيجة السنة الحالية
                     (يظهران مهما كانت @AllAcc و@LevelAcc، ويخضعان لـ @MoveAcc و@BalnceAcc).
                     وبذلك: الأصول = الخصوم + حقوق الملكية، ويكون
                     BalanceDifference صفرًا إذا كانت القيود متوازنة، وإجمالي
                     إيضاح 4 - إيضاح 5 = نتيجة السنة الحالية.
       الفحوص      : ChkNonLeafAccounts = حسابات أب عليها حركة (لا تدخل في الأرقام)
                     ChkOtherAccounts   = حركة على حسابات غير تابعة للشركة أو غير مصنفة
                     يجب أن تكون صفرًا.
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DROP TABLE IF EXISTS #Notes;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #RollTotals;
    DROP TABLE IF EXISTS #LeafAmt;
    DROP TABLE IF EXISTS #Amount;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #AccNote;
    DROP TABLE IF EXISTS #Acc;

    /* =========================================================
       1. التحقق من المدخلات
       ========================================================= */

    IF @FromDate IS NULL
       OR @ToDate IS NULL
       OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year
       OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @YearStart DATE = DATEFROMPARTS(@Year, 1, 1);


    /* =========================================================
       2. تحميل شجرة حسابات الشركة
       ========================================================= */

    SELECT
        a.AccID,
        a.AccParentID,
        a.AccLevel,
        CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(a.AccCode, N'') AS AccCode,
        ISNULL(a.AccName, N'') AS AccName,
        a.AccEnd,
        a.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_Acc_Parent
        ON #Acc (AccParentID);


    /* =========================================================
       3. التحقق من سلامة ارتباط الحسابات بالآباء
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS a
        WHERE a.AccParentID IS NOT NULL
          AND a.AccParentID <> 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #Acc AS p
              WHERE p.AccID = a.AccParentID
          )
    )
        THROW 50011, N'شجرة الحسابات تحتوي على حساب أب غير موجود ضمن حسابات الشركة.', 1;


    /* =========================================================
       4. التحقق من الحلقات والحسابات غير القابلة للوصول
       ========================================================= */

    DECLARE
        @Total   BIGINT,
        @Reached BIGINT;

    SELECT @Total = COUNT_BIG(*)
    FROM #Acc;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        INNER JOIN #Acc AS c
            ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT_BIG(*)
    FROM Reach
    OPTION (MAXRECURSION 32767);

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300);

        SET @CycleMsg =
            CONCAT(
                N'شجرة الحسابات تحتوي على حلقة أو حساب غير قابل للوصول. عدد الحسابات المتأثرة: ',
                @Total - @Reached
            );

        THROW 50010, @CycleMsg, 1;
    END;


    /* =========================================================
       5. حسابات القوائم المالية
          الميزانية    : AccEnd = 1 ، AccType 0 أصول / 1 خصوم / 2 حقوق ملكية
          قائمة الدخل : AccEnd = 2 ، AccType 0 إيرادات / 1 مصروفات
          DebitNature = 1 للحسابات ذات الطبيعة المدينة (أصول، مصروفات)
       ========================================================= */

    SELECT
        AccID,
        AccParentID,
        AccLevel,
        AccChid,
        AccCode,
        AccName,
        AccEnd,
        AccType,
        CAST
        (
            CASE
                WHEN (AccEnd = 1 AND AccType = 0)
                  OR (AccEnd = 2 AND AccType = 1)
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS DebitNature
    INTO #AccNote
    FROM #Acc
    WHERE (AccEnd = 1 AND AccType IN (0, 1, 2))
       OR (AccEnd = 2 AND AccType IN (0, 1));

    IF NOT EXISTS (SELECT 1 FROM #AccNote)
        THROW 50015, N'لا توجد حسابات مصنفة ضمن القوائم المالية للشركة المحددة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_AccNote
        ON #AccNote (AccID);

    CREATE NONCLUSTERED INDEX IX_AccNote_Parent
        ON #AccNote (AccParentID);


    /* =========================================================
       6. التحقق من تصنيف الحسابات وعلاقة الأب بالابن
       ========================================================= */

    -- أب الحساب المصنف يجب أن يكون ضمن الحسابات المصنفة.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS c
        WHERE c.AccParentID IS NOT NULL
          AND c.AccParentID <> 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM #AccNote AS p
              WHERE p.AccID = c.AccParentID
          )
    )
        THROW 50014, N'يوجد حساب تابع لحساب لا ينتمي إلى تصنيف القوائم المالية.', 1;

    -- يجب أن يتطابق التصنيف (القائمة والنوع) مع تصنيف الأب.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS c
        INNER JOIN #AccNote AS p
            ON p.AccID = c.AccParentID
        WHERE c.AccEnd <> p.AccEnd
           OR c.AccType <> p.AccType
    )
        THROW 50013, N'يوجد اختلاف في تصنيف الحساب عن تصنيف الحساب الأب.', 1;

    -- لا يجوز أن يكون لحساب مصنف ابن غير مصنف.
    IF EXISTS
    (
        SELECT 1
        FROM #AccNote AS p
        INNER JOIN #Acc AS c
            ON c.AccParentID = p.AccID
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM #AccNote AS n
            WHERE n.AccID = c.AccID
        )
    )
        THROW 50016, N'يوجد حساب ابن غير مصنف ضمن شجرة حسابات القوائم المالية.', 1;


    /* =========================================================
       7. تحديد الأبناء الفعليين من كامل شجرة الشركة
       ========================================================= */

    SELECT
        c.AccParentID AS AccID,
        COUNT_BIG(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
      AND c.AccParentID > 0
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid
        ON #Kid (AccID);


    /* =========================================================
       8. تجميع الحركات المحاسبية (القيود المرحّلة فقط) في مسح واحد
          OpenNet  : كل ما قبل @FromDate
          PriorNet : كل ما قبل 1 يناير من السنة (للسنوات السابقة)
       ========================================================= */

    SELECT
        d.DayDAccID AS AccID,

        SUM
        (
            CASE
                WHEN m.DayMDate < @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb) - CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS OpenNet,

        SUM
        (
            CASE
                WHEN m.DayMDate < @YearStart
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb) - CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PriorNet,

        SUM
        (
            CASE
                WHEN m.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDDeb)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PerDeb,

        SUM
        (
            CASE
                WHEN m.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(28,3), d.DayDCrd)
                ELSE CONVERT(DECIMAL(28,3), 0)
            END
        ) AS PerCrd,

        SUM
        (
            CONVERT
            (
                BIGINT,
                CASE
                    WHEN m.DayMDate >= @FromDate THEN 1
                    ELSE 0
                END
            )
        ) AS PerCnt

    INTO #Amount

    FROM dbo.Acc_DayMaster AS m
    INNER JOIN dbo.Acc_DayDetails AS d
        ON d.DayDMID = m.DayMID

    WHERE m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate <= @ToDate

    GROUP BY d.DayDAccID

    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount
        ON #Amount (AccID);


    /* =========================================================
       9. مؤشرات سلامة البيانات + الحسابات التحليلية فقط
       ========================================================= */

    DECLARE
        @ChkNonLeaf BIGINT = 0,
        @ChkOther   BIGINT = 0;

    -- حركة على حساب أب (لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT_BIG(*)
    FROM #Amount AS am
    INNER JOIN #Kid AS k
        ON k.AccID = am.AccID;

    -- حركة على حساب لا يتبع الشركة أو غير مصنف في القوائم
    SELECT @ChkOther = COUNT_BIG(*)
    FROM #Amount AS am
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #AccNote AS n
        WHERE n.AccID = am.AccID
    );

    SELECT
        am.AccID,
        n.AccEnd,
        n.AccType,
        am.OpenNet,
        am.PriorNet,
        am.PerDeb,
        am.PerCrd,
        am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    INNER JOIN #AccNote AS n
        ON n.AccID = am.AccID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM #Kid AS k
        WHERE k.AccID = am.AccID
    );

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt
        ON #LeafAmt (AccID);


    /* =========================================================
       10. تجميع الأرصدة والحركات من الحسابات التحليلية إلى الآباء
       ========================================================= */

    ;WITH RollUp AS
    (
        SELECT
            l.AccID AS NodeID,
            l.OpenNet,
            l.PriorNet,
            l.PerDeb,
            l.PerCrd,
            l.PerCnt
        FROM #LeafAmt AS l

        UNION ALL

        SELECT
            p.AccID AS NodeID,
            r.OpenNet,
            r.PriorNet,
            r.PerDeb,
            r.PerCrd,
            r.PerCnt
        FROM RollUp AS r
        INNER JOIN #AccNote AS c
            ON c.AccID = r.NodeID
        INNER JOIN #AccNote AS p
            ON p.AccID = c.AccParentID
           AND c.AccParentID > 0
    )
    SELECT
        NodeID AS AccID,
        SUM(OpenNet)  AS OpenNet,
        SUM(PriorNet) AS PriorNet,
        SUM(PerDeb)   AS PerDeb,
        SUM(PerCrd)   AS PerCrd,
        SUM(PerCnt)   AS PerCnt
    INTO #RollTotals
    FROM RollUp
    GROUP BY NodeID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_RollTotals
        ON #RollTotals (AccID);


    /* =========================================================
       11. تجهيز أرصدة جميع حسابات القوائم المالية
       ========================================================= */

    SELECT
        a.AccID,
        a.AccCode,
        a.AccName,
        a.AccParentID,
        a.AccLevel,
        a.AccChid,
        a.AccEnd,
        a.AccType,
        a.DebitNature,

        CAST(ISNULL(t.OpenNet, 0)  AS DECIMAL(28,3)) AS OpenNet,
        CAST(ISNULL(t.PriorNet, 0) AS DECIMAL(28,3)) AS PriorNet,
        CAST(ISNULL(t.PerDeb, 0)   AS DECIMAL(28,3)) AS PerDeb,
        CAST(ISNULL(t.PerCrd, 0)   AS DECIMAL(28,3)) AS PerCrd,

        ISNULL(t.PerCnt, CONVERT(BIGINT, 0)) AS PerCnt

    INTO #Roll

    FROM #AccNote AS a
    LEFT JOIN #RollTotals AS t
        ON t.AccID = a.AccID;

    CREATE UNIQUE CLUSTERED INDEX IX_Roll
        ON #Roll (AccID);


    /* =========================================================
       12. الإجماليات ونتائج السنوات
           نتائج السنوات السابقة = - صافي قائمة الدخل قبل 1 يناير
           نتيجة السنة الحالية   = - صافي قائمة الدخل من 1 يناير حتى @ToDate
       ========================================================= */

    DECLARE
        @TotalAssets      DECIMAL(38,3),
        @TotalLiabilities DECIMAL(38,3),
        @TotalEquityAcc   DECIMAL(38,3),
        @TotalRevenue     DECIMAL(38,3),
        @TotalExpenses    DECIMAL(38,3),
        @PriorNet         DECIMAL(38,3),
        @CurOpenNet       DECIMAL(38,3),
        @CurPerDeb        DECIMAL(38,3),
        @CurPerCrd        DECIMAL(38,3),
        @CurPerCnt        BIGINT,
        @PriorResult      DECIMAL(38,3),
        @CurResult        DECIMAL(38,3),
        @TotalEquity      DECIMAL(38,3),
        @BalanceDiff      DECIMAL(38,3);

    SELECT
        @TotalAssets =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 0
                            THEN  (l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalLiabilities =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 1
                            THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalEquityAcc =
            ISNULL(SUM(CASE WHEN l.AccEnd = 1 AND l.AccType = 2
                            THEN -(l.OpenNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalRevenue =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 AND l.AccType = 0
                            THEN -(l.OpenNet - l.PriorNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @TotalExpenses =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 AND l.AccType = 1
                            THEN  (l.OpenNet - l.PriorNet + l.PerDeb - l.PerCrd) ELSE 0 END), 0),

        @PriorNet =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PriorNet ELSE 0 END), 0),

        @CurOpenNet =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.OpenNet - l.PriorNet ELSE 0 END), 0),

        @CurPerDeb =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerDeb ELSE 0 END), 0),

        @CurPerCrd =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerCrd ELSE 0 END), 0),

        @CurPerCnt =
            ISNULL(SUM(CASE WHEN l.AccEnd = 2 THEN l.PerCnt ELSE CONVERT(BIGINT, 0) END), 0)

    FROM #LeafAmt AS l;

    SET @PriorResult = -@PriorNet;
    SET @CurResult   = -(@CurOpenNet + @CurPerDeb - @CurPerCrd);
    SET @TotalEquity = @TotalEquityAcc + @PriorResult + @CurResult;
    SET @BalanceDiff = @TotalAssets - (@TotalLiabilities + @TotalEquity);


    /* =========================================================
       13. صفوف الإيضاحات
       ========================================================= */

    SELECT
        CAST
        (
            CASE
                WHEN r.AccEnd = 1 THEN r.AccType + 1
                ELSE r.AccType + 4
            END
            AS INT
        ) AS NoteNo,

        CASE
            WHEN r.AccEnd = 1 AND r.AccType = 0 THEN N'إيضاح رقم 1 - الأصول'
            WHEN r.AccEnd = 1 AND r.AccType = 1 THEN N'إيضاح رقم 2 - الالتزامات'
            WHEN r.AccEnd = 1 AND r.AccType = 2 THEN N'إيضاح رقم 3 - حقوق الملكية'
            WHEN r.AccEnd = 2 AND r.AccType = 0 THEN N'إيضاح رقم 4 - الإيرادات'
            WHEN r.AccEnd = 2 AND r.AccType = 1 THEN N'إيضاح رقم 5 - المصروفات'
        END AS NoteTitle,

        CASE
            WHEN r.AccEnd = 1 AND r.AccType = 0 THEN N'الأصول'
            WHEN r.AccEnd = 1 AND r.AccType = 1 THEN N'الخصوم'
            WHEN r.AccEnd = 1 AND r.AccType = 2 THEN N'حقوق الملكية'
            WHEN r.AccEnd = 2 AND r.AccType = 0 THEN N'الإيرادات'
            WHEN r.AccEnd = 2 AND r.AccType = 1 THEN N'المصروفات'
        END AS AccountCategory,

        r.AccID,
        r.AccCode,
        r.AccName AS AccARName,
        r.AccParentID,
        p.AccName AS AccParentName,
        r.AccLevel,
        r.AccType,

        CAST
        (
            CASE
                WHEN k.AccID IS NULL THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsAnalyticalAccount,

        -- الافتتاحي: الميزانية = كل السنوات السابقة، قائمة الدخل = السنة الحالية فقط
        CAST(x.Sgn * x.OpenAdj AS DECIMAL(28,3)) AS OpeningBalance,

        r.PerDeb AS PeriodDebit,
        r.PerCrd AS PeriodCredit,

        CAST(x.Sgn * (x.OpenAdj + r.PerDeb - r.PerCrd) AS DECIMAL(28,3)) AS ClosingBalance,

        r.PerCnt AS MovementCount,

        @FromDate AS FromDate,
        @ToDate AS ToDate,
        @Year AS FinancialYear,
        @Cmp AS CompanyID,

        @TotalAssets AS TotalAssets,
        @TotalLiabilities AS TotalLiabilities,
        @TotalEquity AS TotalEquity,
        @BalanceDiff AS BalanceDifference,

        CAST(0 AS BIT) AS IsResultRow,
        @TotalRevenue AS TotalRevenue,
        @TotalExpenses AS TotalExpenses,
        @CurResult AS NetIncome,
        @PriorResult AS PriorYearsResult,
        @CurResult AS CurrentYearResult,

        @ChkNonLeaf AS ChkNonLeafAccounts,
        @ChkOther AS ChkOtherAccounts

    INTO #Notes

    FROM #Roll AS r
    CROSS APPLY
    (
        SELECT
            CASE WHEN r.DebitNature = 1 THEN CAST(1 AS INT) ELSE CAST(-1 AS INT) END AS Sgn,
            r.OpenNet - CASE WHEN r.AccEnd = 2 THEN r.PriorNet ELSE CAST(0 AS DECIMAL(28,3)) END AS OpenAdj
    ) AS x
    LEFT JOIN #AccNote AS p
        ON p.AccID = r.AccParentID
    LEFT JOIN #Kid AS k
        ON k.AccID = r.AccID;

    ALTER TABLE #Notes ALTER COLUMN AccCode   NVARCHAR(200) NULL;
    ALTER TABLE #Notes ALTER COLUMN AccARName NVARCHAR(400) NULL;


    /* =========================================================
       14. صفّا نتائج السنوات ضمن إيضاح حقوق الملكية (إيضاح 3)
           قيم الحقول بطبيعة دائنة (الدائن موجب)
       ========================================================= */

    INSERT INTO #Notes
    (
        NoteNo, NoteTitle, AccountCategory,
        AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccType, IsAnalyticalAccount,
        OpeningBalance, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
        FromDate, ToDate, FinancialYear, CompanyID,
        TotalAssets, TotalLiabilities, TotalEquity, BalanceDifference,
        IsResultRow, TotalRevenue, TotalExpenses, NetIncome, PriorYearsResult, CurrentYearResult,
        ChkNonLeafAccounts, ChkOtherAccounts
    )
    VALUES
    (
        3, N'إيضاح رقم 3 - حقوق الملكية', N'حقوق الملكية',
        -1, N'~1', N'نتائج السنوات السابقة (أرباح / خسائر مرحّلة)', NULL, NULL, 1, 2, 1,
        @PriorResult, 0, 0, @PriorResult, 0,
        @FromDate, @ToDate, @Year, @Cmp,
        @TotalAssets, @TotalLiabilities, @TotalEquity, @BalanceDiff,
        1, @TotalRevenue, @TotalExpenses, @CurResult, @PriorResult, @CurResult,
        @ChkNonLeaf, @ChkOther
    ),
    (
        3, N'إيضاح رقم 3 - حقوق الملكية', N'حقوق الملكية',
        -2, N'~2', N'نتيجة السنة الحالية (أرباح / خسائر)', NULL, NULL, 1, 2, 1,
        -@CurOpenNet, @CurPerDeb, @CurPerCrd, @CurResult, @CurPerCnt,
        @FromDate, @ToDate, @Year, @Cmp,
        @TotalAssets, @TotalLiabilities, @TotalEquity, @BalanceDiff,
        1, @TotalRevenue, @TotalExpenses, @CurResult, @PriorResult, @CurResult,
        @ChkNonLeaf, @ChkOther
    );


    /* =========================================================
       15. إخراج الإيضاحات
       ========================================================= */

    SELECT
        NoteNo,
        NoteTitle,
        AccountCategory,

        AccID,
        AccCode,
        AccARName,
        AccParentID,
        AccParentName,
        AccLevel,
        AccType,
        IsAnalyticalAccount,

        OpeningBalance,
        PeriodDebit,
        PeriodCredit,
        ClosingBalance,
        MovementCount,

        FromDate,
        ToDate,
        FinancialYear,
        CompanyID,

        TotalAssets,
        TotalLiabilities,
        TotalEquity,
        BalanceDifference,

        IsResultRow,
        TotalRevenue,
        TotalExpenses,
        NetIncome,
        PriorYearsResult,
        CurrentYearResult,

        ChkNonLeafAccounts,
        ChkOtherAccounts

    FROM #Notes

    WHERE
        (
            IsResultRow = 1
            OR
            (
                (@AllAcc = 0 OR IsAnalyticalAccount = 1)

                AND
                (
                    @LevelAcc = 0
                    OR AccLevel = @LevelAcc
                    OR (AccLevel < @LevelAcc AND IsAnalyticalAccount = 1)
                )
            )
        )

        AND
        (
            @MoveAcc = 0
            OR MovementCount > 0
        )

        AND
        (
            @BalnceAcc = 0
            OR ClosingBalance <> 0
        )

    ORDER BY
        NoteNo,
        IsResultRow,
        AccCode,
        AccID;

END;
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountAnalysis]
    @Cmp       INT,
    @UserID    INT      = 0,   -- لا يؤثر على النتيجة (للترويسة فقط)
    @Year      INT,
    @AccId     BIGINT   = 0,   -- الحساب الأب (0 = من الجذور)
    @FromDate  DATE,
    @ToDate    DATE,
    @AllAcc    BIT      = 0,   -- 1 = الحسابات التحليلية فقط ، 0 = الكل (آباء وتحليلية)
    @AllLevel  BIT      = 0,   -- 1 = كل المستويات (أبناء وأحفاد) ، 0 = الأبناء المباشرون فقط
    @MoveAcc   BIT      = 0,   -- 1 = الحسابات التي لها حركة خلال الفترة فقط
    @BalnceAcc BIT      = 1,   -- 1 = الحسابات التي رصيد نهاية مدتها <> 0 فقط
    @LevelAcc  TINYINT  = 0,   -- 0 = بلا فلتر ؛ المستوى المطلق AccLevel (+ التحليلي الأقل مستوى)
    @Debit     BIT      = 0,   -- 1 = رصيد نهاية المدة مدين فقط
    @Credit    BIT      = 0,   -- 1 = رصيد نهاية المدة دائن فقط
    @CsCID     BIGINT   = 0    -- مركز التكلفة (أب/جد/ابن) ؛ 0 = بلا فلتر
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @AccId = ISNULL(@AccId, 0);
    SET @CsCID = ISNULL(@CsCID, 0);

    IF @AccId > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccId AND AccCompany = @Cmp)
        THROW 50005, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

    /* ---------- مركز التكلفة وفروعه ---------- */
    DECLARE @CC TABLE (CsCID BIGINT NOT NULL PRIMARY KEY);

    IF @CsCID > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
            THROW 50007, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

        ;WITH CcTree AS
        (
            SELECT CsCID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_CostCenter
            WHERE CsCID = @CsCID AND CsCCompany = @Cmp

            UNION ALL

            SELECT c.CsCID, p.Lvl + 1
            FROM dbo.Acc_CostCenter AS c
            JOIN CcTree AS p ON c.CsCParentID = p.CsCID
            WHERE c.CsCCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @CC (CsCID) SELECT CsCID FROM CcTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- شجرة الحسابات تحت الحساب المطلوب (Depth 1 = الأبناء المباشرون) ---------- */
    ;WITH AccTree AS
    (
        SELECT a.AccID, a.AccParentID, a.AccLevel, a.AccCode, a.AccName, CAST(1 AS INT) AS Depth
        FROM dbo.Acc_Account AS a
        WHERE a.AccCompany = @Cmp
          AND a.AccID <> ISNULL(a.AccParentID, 0)
          AND (   (@AccId > 0 AND a.AccParentID = @AccId)
               OR (@AccId = 0 AND (a.AccParentID IS NULL OR a.AccParentID = 0)))

        UNION ALL

        SELECT a.AccID, a.AccParentID, a.AccLevel, a.AccCode, a.AccName, p.Depth + 1
        FROM dbo.Acc_Account AS a
        JOIN AccTree AS p ON a.AccParentID = p.AccID
        WHERE a.AccCompany = @Cmp AND p.Depth < 30
    )
    SELECT AccID, AccParentID, AccLevel, AccCode, AccName, Depth
    INTO #Node
    FROM AccTree
    OPTION (MAXRECURSION 100);

    CREATE UNIQUE CLUSTERED INDEX IX_Node ON #Node (AccID);

    /* ---------- (الحساب ← كل أحفاده بما فيهم نفسه) لتجميع الأرصدة نحو الآباء ---------- */
    ;WITH Cl AS
    (
        SELECT n.AccID AS NodeID, n.AccID AS DescID
        FROM #Node AS n

        UNION ALL

        SELECT c.NodeID, k.AccID
        FROM Cl AS c
        JOIN #Node AS k ON k.AccParentID = c.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 100);

    CREATE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- حركة كل حساب: مرة واحدة على الجداول الكبيرة ---------- */
    SELECT d.DayDAccID AS AccID,
           SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)                      AS PerCnt
    INTO #Amt
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    JOIN #Node              AS n ON n.AccID  = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState   = 7
      AND m.DayMDate   <= @ToDate
      AND (@CsCID = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
    GROUP BY d.DayDAccID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amt ON #Amt (AccID);

    /* ---------- ملخص الترويسة: رصيد الحساب المطلوب نفسه (يتجاهل فلاتر العرض) ---------- */
    DECLARE @HOpen DECIMAL(18,3), @HPerDeb DECIMAL(18,3), @HPerCrd DECIMAL(18,3);

    SELECT @HOpen   = CAST(ISNULL(SUM(OpenNet), 0) AS DECIMAL(18,3)),
           @HPerDeb = CAST(ISNULL(SUM(PerDeb ), 0) AS DECIMAL(18,3)),
           @HPerCrd = CAST(ISNULL(SUM(PerCrd ), 0) AS DECIMAL(18,3))
    FROM #Amt;

    DECLARE @HPerNet DECIMAL(18,3) = @HPerDeb - @HPerCrd;
    DECLARE @HClose  DECIMAL(18,3) = @HOpen + @HPerNet;

    /* ---------- تجميع كل حساب مع أحفاده ---------- */
    SELECT n.AccID, n.AccParentID, n.AccLevel, n.AccCode, n.AccName, n.Depth,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM #Node AS k WHERE k.AccParentID = n.AccID) THEN 0 ELSE 1 END AS BIT) AS IsLeaf,
           CAST(ISNULL(SUM(a.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(a.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(a.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(a.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #R
    FROM #Node AS n
    JOIN #Cl   AS c ON c.NodeID = n.AccID
    LEFT JOIN #Amt AS a ON a.AccID = c.DescID
    GROUP BY n.AccID, n.AccParentID, n.AccLevel, n.AccCode, n.AccName, n.Depth;

    /* ---------- النتيجة ---------- */
    SELECT x.AccID, x.AccCode, x.AccName, x.AccLevel, x.AccParentID,
           pa.AccName AS AccParentName,
           x.IsLeaf,

           -- رصيد أول المدة
           CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
           CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
           -- الحركة بالمجاميع
           x.PerDeb AS NewDebit,
           x.PerCrd AS NewCredit,
           -- الحركة بالأرصدة
           CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END AS BalanceDebit,
           CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
           -- رصيد آخر المدة
           CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotDebit,
           CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotCredit,

           -- ملخص الترويسة (يتكرر على كل صف)
           CASE WHEN @HOpen   > 0 THEN  @HOpen   ELSE 0 END AS SumBlcOldDebit,
           CASE WHEN @HOpen   < 0 THEN -@HOpen   ELSE 0 END AS SumBlcOldCredit,
           @HPerDeb AS SumTotDebit,
           @HPerCrd AS SumTotCredit,
           CASE WHEN @HPerNet > 0 THEN  @HPerNet ELSE 0 END AS SumBlcDebit,
           CASE WHEN @HPerNet < 0 THEN -@HPerNet ELSE 0 END AS SumBlcCredit,
           CASE WHEN @HClose  > 0 THEN  @HClose  ELSE 0 END AS SumTotBlcDebit,
           CASE WHEN @HClose  < 0 THEN -@HClose  ELSE 0 END AS SumTotBlcCredit
    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #R AS r
    ) AS x
    LEFT JOIN dbo.Acc_Account AS pa ON pa.AccID = x.AccParentID
    WHERE (@AllAcc   = 0 OR x.IsLeaf = 1)
      AND (@AllLevel = 1 OR x.Depth  = 1)
      AND (@LevelAcc = 0 OR x.AccLevel = @LevelAcc OR (x.AccLevel < @LevelAcc AND x.IsLeaf = 1))
      AND (@MoveAcc   = 0 OR x.PerCnt   > 0)
      AND (@BalnceAcc = 0 OR x.CloseNet <> 0)
      AND (@Debit     = 0 OR x.CloseNet > 0)
      AND (@Credit    = 0 OR x.CloseNet < 0)
    ORDER BY x.AccCode, x.AccLevel;
END;
GO

/* =========== اختبار سريع (غيّر الأرقام) ===========
EXEC dbo.Acc_SelectAccountAnalysis @Cmp = 1, @Year = 2026, @AccId = 213,
     @FromDate = '2026-10-01', @ToDate = '2026-10-30';          -- الأبناء المباشرون ، رصيد نهاية <> 0
EXEC dbo.Acc_SelectAccountAnalysis @Cmp = 1, @Year = 2026, @AccId = 213,
     @FromDate = '2026-10-01', @ToDate = '2026-10-30', @AllLevel = 1, @AllAcc = 1;  -- كل التحليلية
EXEC dbo.Acc_SelectAccountAnalysis @Cmp = 1, @Year = 2026, @AccId = 213,
     @FromDate = '2026-10-01', @ToDate = '2026-10-30', @MoveAcc = 1, @Credit = 1;
-- تحقق: SumBlcOld + SumBlcPeriod = SumTotBlc ، ويطابق أرقام الـ PDF القديم (35,085,046.106 / 587,476.779 / 35,672,522.885)
=================================================== */

/* فهارس مقترحة (إن لم تكن موجودة):
CREATE INDEX IX_DayDetails_Acc ON dbo.Acc_DayDetails (DayDAccID) INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID);
CREATE INDEX IX_DayMaster_Cmp_State_Date ON dbo.Acc_DayMaster (DayMCompany, DayMState, DayMDate) INCLUDE (DayMNo);
CREATE INDEX IX_Account_Parent ON dbo.Acc_Account (AccParentID) INCLUDE (AccCompany);
*/

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectAccountStatement]
    @Cmp      INT,
    @UserID   INT = 0,         -- لا يؤثر على النتيجة (للاستخدام في ترويسة التقرير فقط)
    @Year     INT,
    @AccId    BIGINT = 0,      -- الحساب (تحليلي فقط)
    @FromDate DATE,
    @ToDate   DATE,
    @Debit    BIT = 0,         -- 1 = الحركات المدينة فقط
    @Credit   BIT = 0,         -- 1 = الحركات الدائنة فقط
    @CsCID    BIGINT = 0       -- 0 = بلا فلتر مركز تكلفة
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF ISNULL(@AccId, 0) <= 0
        THROW 50001, N'يجب تحديد الحساب.', 1;
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    DECLARE @AccCode NVARCHAR(60), @AccName NVARCHAR(500);

    SELECT @AccCode = a.AccCode, @AccName = a.AccName
    FROM dbo.Acc_Account AS a
    WHERE a.AccID = @AccId AND a.AccCompany = @Cmp;

    IF @AccCode IS NULL
        THROW 50005, N'الحساب غير موجود أو لا يتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = @AccId)
        THROW 50006, N'كشف الحساب متاح للحسابات التحليلية فقط.', 1;

    /* ---------- مركز التكلفة وفروعه ---------- */
    DECLARE @CC TABLE (CsCID BIGINT NOT NULL PRIMARY KEY);

    IF ISNULL(@CsCID, 0) > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
            THROW 50007, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

        ;WITH Tree AS
        (
            SELECT CsCID, 0 AS Lvl
            FROM dbo.Acc_CostCenter
            WHERE CsCID = @CsCID AND CsCCompany = @Cmp

            UNION ALL

            SELECT c.CsCID, t.Lvl + 1
            FROM dbo.Acc_CostCenter AS c
            JOIN Tree AS t ON c.CsCParentID = t.CsCID
            WHERE c.CsCCompany = @Cmp
              AND t.Lvl < 30
        )
        INSERT INTO @CC (CsCID) SELECT CsCID FROM Tree;
    END;

    /* ---------- رصيد بداية المدة: كل الحركات قبل @FromDate من كل السنوات ---------- */
    DECLARE @Opening DECIMAL(18,3);

    SELECT @Opening = ISNULL(SUM(d.DayDDeb), 0) - ISNULL(SUM(d.DayDCrd), 0)
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE d.DayDAccID = @AccId
      AND m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate < @FromDate
      AND (ISNULL(@CsCID, 0) = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
    OPTION (RECOMPILE);

    /* ---------- حركات الفترة (الترتيب: الشهر ثم DayMNo ثم البند) ---------- */
    SELECT
        CAST(ROW_NUMBER() OVER (ORDER BY MONTH(m.DayMDate), m.DayMNo, d.DayDID) AS INT) AS Seq,
        m.DayMID, m.DayMNo, m.DayMDate,
        m.DayMDescription, d.DayDDescription, d.DayDNum,
        d.DayDCsCID, c.CsCCode, c.CsCName,
        d.DayDDeb, d.DayDCrd
    INTO #Mov
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DayDCsCID
    WHERE d.DayDAccID = @AccId
      AND m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate >= @FromDate AND m.DayMDate <= @ToDate
      AND (ISNULL(@CsCID, 0) = 0 OR d.DayDCsCID IN (SELECT CsCID FROM @CC))
      AND (@Debit  = 0 OR d.DayDDeb > 0)
      AND (@Credit = 0 OR d.DayDCrd > 0)
    OPTION (RECOMPILE);

    DECLARE @PerDeb DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDDeb), 0) FROM #Mov),
            @PerCrd DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDCrd), 0) FROM #Mov);
    DECLARE @Closing DECIMAL(18,3) = @Opening + @PerDeb - @PerCrd;

    /* ---------- النتيجة: جدول واحد ---------- */
    SELECT R.RowType, R.Seq, R.RowLabel,
           R.DayMID, R.DayMNo,
           CASE WHEN R.RowType = 1
                THEN CONCAT(CAST(R.DayMNo AS NVARCHAR(10)), N'/', RIGHT(CONCAT(N'0', MONTH(R.DayMDate)), 2))
           END AS EntryNo,
           R.DayMDate, R.EntryDescription, R.ItemDescription, R.DayDNum,
           R.CsCID, R.CsCCode, R.CsCName,
           R.Debit, R.Credit, R.Balance,
           CASE WHEN R.Balance > 0 THEN N'مدين' WHEN R.Balance < 0 THEN N'دائن' ELSE N'' END AS BalanceSide,
           @AccId AS AccID, @AccCode AS AccCode, @AccName AS AccName
    FROM
    (
        -- رصيد بداية المدة
        SELECT CAST(0 AS TINYINT) AS RowType, 0 AS Seq, N'رصيد بداية المدة' AS RowLabel,
               CAST(NULL AS BIGINT) AS DayMID, CAST(NULL AS INT) AS DayMNo, CAST(NULL AS DATE) AS DayMDate,
               CAST(NULL AS NVARCHAR(MAX)) AS EntryDescription, CAST(NULL AS NVARCHAR(MAX)) AS ItemDescription,
               CAST(NULL AS NVARCHAR(50)) AS DayDNum,
               CAST(NULL AS BIGINT) AS CsCID, CAST(NULL AS NVARCHAR(60)) AS CsCCode, CAST(NULL AS NVARCHAR(500)) AS CsCName,
               CAST(NULL AS DECIMAL(18,3)) AS Debit, CAST(NULL AS DECIMAL(18,3)) AS Credit,
               @Opening AS Balance

        UNION ALL
        -- الحركات مع الرصيد الجاري على الصفوف الظاهرة
        SELECT CAST(1 AS TINYINT), Seq, CAST(NULL AS NVARCHAR(50)),
               DayMID, DayMNo, DayMDate,
               DayMDescription, DayDDescription, DayDNum,
               DayDCsCID, CsCCode, CsCName,
               DayDDeb, DayDCrd,
               @Opening + SUM(DayDDeb - DayDCrd) OVER (ORDER BY Seq ROWS UNBOUNDED PRECEDING)
        FROM #Mov

        UNION ALL
        -- رصيد خلال الفترة
        SELECT CAST(2 AS TINYINT), 0, N'رصيد خلال الفترة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               @PerDeb, @PerCrd, @PerDeb - @PerCrd

        UNION ALL
        -- رصيد نهاية المدة
        SELECT CAST(3 AS TINYINT), 0, N'رصيد نهاية المدة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               NULL, NULL, @Closing
    ) AS R
    ORDER BY R.RowType, R.Seq;
END;
GO

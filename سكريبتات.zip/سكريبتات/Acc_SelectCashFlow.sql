USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   قائمة التدفقات النقدية (الطريقة المباشرة) — IAS 7
   ---------------------------------------------------------------------
   Acc_CashFlowAccounts.CashFlowType:
       1 = النقدية وما يعادلها
       2 = أنشطة تشغيلية   3 = أنشطة استثمارية   4 = أنشطة تمويلية
   يُورَّث التصنيف من أقرب حساب أعلى مصنَّف (الأقرب يغلب).

   المبدأ:
   - لكل قيد مرحّل (DayMState = 7) يمس حسابات النقدية في الفترة، صافي حركة
     النقدية = صافي بنوده المقابلة (إن كان القيد متوازنًا).
   - داخل القيد الواحد تُجمَّع البنود المقابلة حسب نوع النشاط (2/3/4)،
     فيصبح لكل نشاط صافٍ واحد: موجب = متحصلات، سالب = مدفوعات.
     بهذا لا يُستثنى قيد صحيح لمجرد أن بنوده المقابلة باتجاهين.
   - الاستثناء فقط لخلل حقيقي: لا بنود مقابلة، أو حساب مقابل غير مصنف،
     أو صافي البنود لا يطابق صافي النقدية (قيد غير متوازن).
   - التسوية مضمونة: الافتتاحي + (تشغيلي + استثماري + تمويلي) + المستثنى = الختامي،
     وفرق التسوية يجب أن يكون صفرًا دائمًا.
   - حركة النقدية بين حسابات نقدية (صافيها صفر) لا تُعد تدفقًا.
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCashFlow]
(
    @CompanyID INT,
    @DateFrom  DATE,
    @DateTo    DATE
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CompanyID IS NULL OR @CompanyID <= 0
        THROW 50001, N'يجب تحديد الشركة بصورة صحيحة.', 1;

    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo
        THROW 50002, N'نطاق التاريخ غير صحيح.', 1;

    DROP TABLE IF EXISTS #EntryFlow;
    DROP TABLE IF EXISTS #Exceptions;
    DROP TABLE IF EXISTS #JournalCheck;
    DROP TABLE IF EXISTS #CounterLines;
    DROP TABLE IF EXISTS #CashJournal;
    DROP TABLE IF EXISTS #AccountClass;

    /*==============================================================
      1. تصنيف الحسابات وتوريث أقرب تصنيف من الحسابات الأعلى
    ==============================================================*/

    ;WITH AccountAncestors AS
    (
        SELECT
            A.AccID AS LeafAccID,
            A.AccID AS AncestorAccID,
            CAST(0 AS INT) AS Distance,
            CAST('/' + CONVERT(VARCHAR(30), A.AccID) + '/' AS VARCHAR(MAX)) AS VisitedPath
        FROM dbo.Acc_Account A
        WHERE A.AccCompany = @CompanyID

        UNION ALL

        SELECT
            H.LeafAccID,
            P.AccParentID,
            H.Distance + 1,
            CAST(H.VisitedPath + CONVERT(VARCHAR(30), P.AccParentID) + '/' AS VARCHAR(MAX))
        FROM AccountAncestors H
        INNER JOIN dbo.Acc_Account P
            ON P.AccID = H.AncestorAccID
           AND P.AccCompany = @CompanyID
        WHERE P.AccParentID IS NOT NULL
          AND CHARINDEX('/' + CONVERT(VARCHAR(30), P.AccParentID) + '/', H.VisitedPath) = 0
    ),
    RankedClassification AS
    (
        SELECT
            H.LeafAccID,
            C.CashFlowType,
            ROW_NUMBER() OVER (PARTITION BY H.LeafAccID ORDER BY H.Distance ASC) AS RN
        FROM AccountAncestors H
        INNER JOIN dbo.Acc_CashFlowAccounts C
            ON C.AccID = H.AncestorAccID
    )
    SELECT
        A.AccID,
        R.CashFlowType
    INTO #AccountClass
    FROM dbo.Acc_Account A
    LEFT JOIN RankedClassification R
        ON R.LeafAccID = A.AccID
       AND R.RN = 1
    WHERE A.AccCompany = @CompanyID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_AccountClass
        ON #AccountClass (AccID);

    -- حسابات النقدية يجب أن تكون حسابات ميزانية من نوع أصول
    IF EXISTS
    (
        SELECT 1
        FROM #AccountClass C
        INNER JOIN dbo.Acc_Account A
            ON A.AccID = C.AccID
        WHERE C.CashFlowType = 1
          AND (A.AccEnd <> 1 OR A.AccType <> 0)
    )
        THROW 50020, N'تصنيف النقدية (1) مطبق على حساب ليس من أصول الميزانية العمومية.', 1;


    /*==============================================================
      2. قيود الفترة التي تمس النقدية وصافي حركة النقدية لكل قيد
         (القيود التي صافي نقديتها صفر، كالتحويل بين الصناديق، لا تُعد تدفقًا)
    ==============================================================*/

    SELECT
        D.DayDMID,
        CAST(SUM(D.DayDDeb) AS DECIMAL(19,3)) AS CashDebit,
        CAST(SUM(D.DayDCrd) AS DECIMAL(19,3)) AS CashCredit,
        CAST(SUM(D.DayDDeb - D.DayDCrd) AS DECIMAL(19,3)) AS CashNet
    INTO #CashJournal
    FROM dbo.Acc_DayMaster M
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = M.DayMID
    INNER JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
       AND A.CashFlowType = 1
    WHERE M.DayMCompany = @CompanyID
      AND M.DayMState = 7
      AND M.DayMDate >= @DateFrom
      AND M.DayMDate <= @DateTo
    GROUP BY D.DayDMID
    HAVING SUM(D.DayDDeb - D.DayDCrd) <> 0;

    CREATE UNIQUE CLUSTERED INDEX IX_CashJournal
        ON #CashJournal (DayDMID);


    /*==============================================================
      3. البنود المقابلة (غير النقدية) في هذه القيود فقط
         FlowAmount: موجب = تدفق داخل، سالب = تدفق خارج
         CashFlowType = NULL يعني حسابًا غير مصنف
    ==============================================================*/

    SELECT
        D.DayDMID,
        D.DayDID,
        A.CashFlowType,
        CAST(D.DayDCrd - D.DayDDeb AS DECIMAL(19,3)) AS FlowAmount
    INTO #CounterLines
    FROM #CashJournal CJ
    INNER JOIN dbo.Acc_DayDetails D
        ON D.DayDMID = CJ.DayDMID
    LEFT JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
    WHERE ISNULL(A.CashFlowType, 0) <> 1;

    CREATE INDEX IX_CounterLines_Journal
        ON #CounterLines (DayDMID);


    /*==============================================================
      4. فحص كل قيد
    ==============================================================*/

    SELECT
        CJ.DayDMID,
        CJ.CashNet,
        COUNT(CL.DayDID) AS CounterLineCount,
        SUM(CASE WHEN CL.DayDID IS NOT NULL AND CL.CashFlowType IS NULL THEN 1 ELSE 0 END) AS UnclassifiedCount,
        CAST(ISNULL(SUM(CASE WHEN CL.CashFlowType BETWEEN 2 AND 4 THEN CL.FlowAmount END), 0)
             AS DECIMAL(19,3)) AS ClassifiedNet
    INTO #JournalCheck
    FROM #CashJournal CJ
    LEFT JOIN #CounterLines CL
        ON CL.DayDMID = CJ.DayDMID
    GROUP BY CJ.DayDMID, CJ.CashNet;

    CREATE UNIQUE CLUSTERED INDEX IX_JournalCheck
        ON #JournalCheck (DayDMID);


    /*==============================================================
      5. القيود المستثناة وأسبابها
    ==============================================================*/

    SELECT
        X.DayDMID,
        X.ExceptionReason
    INTO #Exceptions
    FROM
    (
        SELECT
            JC.DayDMID,
            CASE
                WHEN JC.CounterLineCount = 0
                    THEN N'لا توجد بنود مقابلة لحركة النقدية'
                WHEN JC.UnclassifiedCount > 0
                    THEN N'يوجد حساب مقابل غير مصنف في قائمة التدفقات'
                WHEN ABS(JC.ClassifiedNet - JC.CashNet) > 0.001
                    THEN N'صافي البنود المقابلة لا يطابق صافي حركة النقدية (قيد غير متوازن)'
                ELSE NULL
            END AS ExceptionReason
        FROM #JournalCheck JC
    ) X
    WHERE X.ExceptionReason IS NOT NULL;

    CREATE UNIQUE CLUSTERED INDEX IX_Exceptions
        ON #Exceptions (DayDMID);


    /*==============================================================
      6. صافي كل نشاط داخل كل قيد سليم
         (موجب = متحصلات، سالب = مدفوعات)
    ==============================================================*/

    SELECT
        CL.DayDMID,
        CL.CashFlowType,
        CAST(SUM(CL.FlowAmount) AS DECIMAL(19,3)) AS NetFlow
    INTO #EntryFlow
    FROM #CounterLines CL
    WHERE CL.CashFlowType BETWEEN 2 AND 4
      AND NOT EXISTS (SELECT 1 FROM #Exceptions E WHERE E.DayDMID = CL.DayDMID)
    GROUP BY CL.DayDMID, CL.CashFlowType
    HAVING SUM(CL.FlowAmount) <> 0;


    /*==============================================================
      7. أرصدة النقدية وأرقام التسوية
    ==============================================================*/

    DECLARE
        @Opening       DECIMAL(19,3),
        @Period        DECIMAL(19,3),
        @NetClassified DECIMAL(19,3),
        @ExceptionsNet DECIMAL(19,3),
        @ExceptionCnt  INT;

    SELECT
        @Opening = ISNULL(SUM(CASE WHEN M.DayMDate <  @DateFrom THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0),
        @Period  = ISNULL(SUM(CASE WHEN M.DayMDate >= @DateFrom THEN D.DayDDeb - D.DayDCrd ELSE 0 END), 0)
    FROM dbo.Acc_DayDetails D
    INNER JOIN dbo.Acc_DayMaster M
        ON M.DayMID = D.DayDMID
    INNER JOIN #AccountClass A
        ON A.AccID = D.DayDAccID
       AND A.CashFlowType = 1
    WHERE M.DayMCompany = @CompanyID
      AND M.DayMState = 7
      AND M.DayMDate <= @DateTo;

    SELECT @NetClassified = ISNULL(SUM(NetFlow), 0)
    FROM #EntryFlow;

    SELECT
        @ExceptionsNet = ISNULL(SUM(CJ.CashNet), 0),
        @ExceptionCnt  = COUNT(*)
    FROM #Exceptions E
    INNER JOIN #CashJournal CJ
        ON CJ.DayDMID = E.DayDMID;


    /*==============================================================
      RESULT SET 1: التدفقات حسب النشاط
    ==============================================================*/

    SELECT
        V.CashFlowType,
        V.FlowName,
        CAST(ISNULL(F.CashInflows, 0)  AS DECIMAL(19,3)) AS CashInflows,
        CAST(ISNULL(F.CashOutflows, 0) AS DECIMAL(19,3)) AS CashOutflows,
        CAST(ISNULL(F.NetFlow, 0)      AS DECIMAL(19,3)) AS NetFlow
    FROM
    (
        VALUES
            (2, N'التدفقات النقدية من الأنشطة التشغيلية'),
            (3, N'التدفقات النقدية من الأنشطة الاستثمارية'),
            (4, N'التدفقات النقدية من الأنشطة التمويلية')
    ) V(CashFlowType, FlowName)
    LEFT JOIN
    (
        SELECT
            EF.CashFlowType,
            SUM(EF.NetFlow) AS NetFlow,
            SUM(CASE WHEN EF.NetFlow > 0 THEN  EF.NetFlow ELSE 0 END) AS CashInflows,
            SUM(CASE WHEN EF.NetFlow < 0 THEN -EF.NetFlow ELSE 0 END) AS CashOutflows
        FROM #EntryFlow EF
        GROUP BY EF.CashFlowType
    ) F
        ON F.CashFlowType = V.CashFlowType
    ORDER BY V.CashFlowType;


    /*==============================================================
      RESULT SET 2: أرصدة النقدية والتسوية
         ReconciliationDifference يجب أن يكون صفرًا دائمًا
    ==============================================================*/

    SELECT
        @Opening                 AS OpeningCashBalance,
        @Period                  AS PeriodCashMovement,
        @Opening + @Period       AS ClosingCashBalance,
        @NetClassified           AS NetClassifiedFlow,
        @ExceptionsNet           AS ExceptionsNet,
        @ExceptionCnt            AS ExceptionCount,
        @Period - @NetClassified - @ExceptionsNet AS ReconciliationDifference;


    /*==============================================================
      RESULT SET 3: القيود المستثناة للمراجعة
    ==============================================================*/

    SELECT
        M.DayMID,
        M.DayMNo,
        M.DayMDate,
        M.DayMDescription,
        M.DayMState,
        E.ExceptionReason,
        CJ.CashDebit,
        CJ.CashCredit,
        CJ.CashNet
    FROM #Exceptions E
    INNER JOIN dbo.Acc_DayMaster M
        ON M.DayMID = E.DayDMID
    INNER JOIN #CashJournal CJ
        ON CJ.DayDMID = E.DayDMID
    ORDER BY
        M.DayMDate,
        M.DayMNo,
        M.DayMID;

END;
GO

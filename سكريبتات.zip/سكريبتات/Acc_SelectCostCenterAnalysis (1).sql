CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenterAnalysis]
    @Cmp       INT,
    @UserID    INT      = 0,   -- لا يؤثر على النتيجة (للترويسة فقط)
    @Year      INT,
    @CsCID     BIGINT   = 0,   -- مركز التكلفة الأب (0 = من الجذور)
    @FromDate  DATE,
    @ToDate    DATE,
    @AllCsC    BIT      = 0,   -- 1 = مراكز التكلفة التحليلية فقط ، 0 = الكل (آباء وتحليلية)
    @AllLevel  BIT      = 0,   -- 1 = كل المستويات (أبناء وأحفاد) ، 0 = الأبناء المباشرون فقط
    @MoveCsC   BIT      = 0,   -- 1 = المراكز التي لها حركة خلال الفترة فقط
    @BalnceCsC BIT      = 1,   -- 1 = المراكز التي رصيد نهاية مدتها <> 0 فقط
    @LevelCsC  TINYINT  = 0,   -- 0 = بلا فلتر ؛ المستوى المطلق CsCLevel (+ التحليلي الأقل مستوى)
    @Debit     BIT      = 0,   -- 1 = رصيد نهاية المدة مدين فقط
    @Credit    BIT      = 0,   -- 1 = رصيد نهاية المدة دائن فقط
    @AccId     BIGINT   = 0    -- الحساب (أب/جد/ابن) ؛ 0 = بلا فلتر
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @CsCID = ISNULL(@CsCID, 0);
    SET @AccId = ISNULL(@AccId, 0);

    IF @CsCID > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CsCID AND CsCCompany = @Cmp)
        THROW 50005, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

    /* ---------- الحساب وفروعه (إن وُجد فلتر) ---------- */
    DECLARE @Acc TABLE (AccID BIGINT NOT NULL PRIMARY KEY);

    IF @AccId > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccId AND AccCompany = @Cmp)
            THROW 50007, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

        ;WITH AccTree AS
        (
            SELECT a.AccID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_Account AS a
            WHERE a.AccID = @AccId AND a.AccCompany = @Cmp

            UNION ALL

            SELECT a.AccID, p.Lvl + 1
            FROM dbo.Acc_Account AS a
            JOIN AccTree AS p ON a.AccParentID = p.AccID
            WHERE a.AccCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @Acc (AccID) SELECT AccID FROM AccTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- شجرة مراكز التكلفة تحت المركز المطلوب (Depth 1 = الأبناء المباشرون) ---------- */
    ;WITH CcTree AS
    (
        SELECT c.CsCID, c.CsCParentID, c.CsCLevel, c.CsCCode, c.CsCName, CAST(1 AS INT) AS Depth
        FROM dbo.Acc_CostCenter AS c
        WHERE c.CsCCompany = @Cmp
          AND c.CsCID <> ISNULL(c.CsCParentID, 0)
          AND (   (@CsCID > 0 AND c.CsCParentID = @CsCID)
               OR (@CsCID = 0 AND (c.CsCParentID IS NULL OR c.CsCParentID = 0)))

        UNION ALL

        SELECT c.CsCID, c.CsCParentID, c.CsCLevel, c.CsCCode, c.CsCName, p.Depth + 1
        FROM dbo.Acc_CostCenter AS c
        JOIN CcTree AS p ON c.CsCParentID = p.CsCID
        WHERE c.CsCCompany = @Cmp AND p.Depth < 30
    )
    SELECT CsCID, CsCParentID, CsCLevel, CsCCode, CsCName, Depth
    INTO #Node
    FROM CcTree
    OPTION (MAXRECURSION 100);

    CREATE UNIQUE CLUSTERED INDEX IX_Node ON #Node (CsCID);

    /* ---------- (المركز ← كل أحفاده بما فيهم نفسه) لتجميع الأرصدة نحو الآباء ---------- */
    ;WITH Cl AS
    (
        SELECT n.CsCID AS NodeID, n.CsCID AS DescID
        FROM #Node AS n

        UNION ALL

        SELECT c.NodeID, k.CsCID
        FROM Cl AS c
        JOIN #Node AS k ON k.CsCParentID = c.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 100);

    CREATE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- حركة كل مركز: مرة واحدة على الجداول الكبيرة ---------- */
    SELECT d.DayDCsCID AS CsCID,
           SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd,
           SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END)                      AS PerCnt
    INTO #Amt
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    JOIN #Node              AS n ON n.CsCID  = d.DayDCsCID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState   = 7
      AND m.DayMDate   <= @ToDate
      AND (@AccId = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
    GROUP BY d.DayDCsCID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amt ON #Amt (CsCID);

    /* ---------- ملخص الترويسة: رصيد المركز المطلوب نفسه (يتجاهل فلاتر العرض) ---------- */
    DECLARE @HOpen DECIMAL(18,3), @HPerDeb DECIMAL(18,3), @HPerCrd DECIMAL(18,3);

    SELECT @HOpen   = CAST(ISNULL(SUM(OpenNet), 0) AS DECIMAL(18,3)),
           @HPerDeb = CAST(ISNULL(SUM(PerDeb ), 0) AS DECIMAL(18,3)),
           @HPerCrd = CAST(ISNULL(SUM(PerCrd ), 0) AS DECIMAL(18,3))
    FROM #Amt;

    DECLARE @HPerNet DECIMAL(18,3) = @HPerDeb - @HPerCrd;
    DECLARE @HClose  DECIMAL(18,3) = @HOpen + @HPerNet;

    /* ---------- تجميع كل مركز مع أحفاده ---------- */
    SELECT n.CsCID, n.CsCParentID, n.CsCLevel, n.CsCCode, n.CsCName, n.Depth,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM #Node AS k WHERE k.CsCParentID = n.CsCID) THEN 0 ELSE 1 END AS BIT) AS IsLeaf,
           CAST(ISNULL(SUM(a.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(a.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(a.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(a.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #R
    FROM #Node AS n
    JOIN #Cl   AS c ON c.NodeID = n.CsCID
    LEFT JOIN #Amt AS a ON a.CsCID = c.DescID
    GROUP BY n.CsCID, n.CsCParentID, n.CsCLevel, n.CsCCode, n.CsCName, n.Depth;

    /* ---------- النتيجة ---------- */
    SELECT x.CsCID, x.CsCCode, x.CsCName, x.CsCLevel, x.CsCParentID,
           pc.CsCName AS CsCParentName,
           x.IsLeaf,

           -- رصيد أول المدة
           CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
           CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
           -- الحركة بالمجاميع
           x.PerDeb AS NewDebit,
           x.PerCrd AS NewCredit,
           -- الحركة بالأرصدة
           CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END AS BalanceDebit,
           CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END AS BalanceCredit,
           -- رصيد آخر المدة
           CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotDebit,
           CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotCredit,

           -- ملخص الترويسة (يتكرر على كل صف)
           CASE WHEN @HOpen   > 0 THEN  @HOpen   ELSE 0 END AS SumBlcOldDebit,
           CASE WHEN @HOpen   < 0 THEN -@HOpen   ELSE 0 END AS SumBlcOldCredit,
           @HPerDeb AS SumTotDebit,
           @HPerCrd AS SumTotCredit,
           CASE WHEN @HPerNet > 0 THEN  @HPerNet ELSE 0 END AS SumBlcDebit,
           CASE WHEN @HPerNet < 0 THEN -@HPerNet ELSE 0 END AS SumBlcCredit,
           CASE WHEN @HClose  > 0 THEN  @HClose  ELSE 0 END AS SumTotBlcDebit,
           CASE WHEN @HClose  < 0 THEN -@HClose  ELSE 0 END AS SumTotBlcCredit
    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #R AS r
    ) AS x
    LEFT JOIN dbo.Acc_CostCenter AS pc ON pc.CsCID = x.CsCParentID
    WHERE (@AllCsC   = 0 OR x.IsLeaf = 1)
      AND (@AllLevel = 1 OR x.Depth  = 1)
      AND (@LevelCsC = 0 OR x.CsCLevel = @LevelCsC OR (x.CsCLevel < @LevelCsC AND x.IsLeaf = 1))
      AND (@MoveCsC   = 0 OR x.PerCnt   > 0)
      AND (@BalnceCsC = 0 OR x.CloseNet <> 0)
      AND (@Debit     = 0 OR x.CloseNet > 0)
      AND (@Credit    = 0 OR x.CloseNet < 0)
    ORDER BY x.CsCCode, x.CsCLevel;
END;
GO

/* =========== اختبار سريع ===========
EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = 1, @Year = 2026, @CsCID = 0,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30';                       -- مراكز الجذور
EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = 1, @Year = 2026, @CsCID = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @AllLevel = 1, @AllCsC = 1;  -- كل التحليلية تحت المركز 5
EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = 1, @Year = 2026, @CsCID = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @AccId = 5;           -- بحساب مصروفات مثلًا
-- تحقق: مجموع مراكز الأب بعد فلتر الحساب = رصيد الحساب نفسه عند ذلك المركز
=================================================== */

/* فهرس مقترح (إن لم يكن موجودًا):
CREATE INDEX IX_DayDetails_CsC ON dbo.Acc_DayDetails (DayDCsCID) INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd);
CREATE INDEX IX_CostCenter_Parent ON dbo.Acc_CostCenter (CsCParentID) INCLUDE (CsCCompany);
*/

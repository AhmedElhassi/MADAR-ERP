CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectCostCenterStatement]
    @Cmp      INT,
    @UserID   INT = 0,         -- لا يؤثر على النتيجة (للاستخدام في ترويسة التقرير فقط)
    @Year     INT,
    @CsCId    BIGINT = 0,      -- مركز التكلفة (تحليلي فقط)
    @FromDate DATE,
    @ToDate   DATE,
    @Debit    BIT = 0,         -- 1 = الحركات المدينة فقط
    @Credit   BIT = 0,         -- 1 = الحركات الدائنة فقط
    @AccID    BIGINT = 0       -- 0 = بلا فلتر الحسابات (يقبل أب/جد/ابن)
AS
BEGIN
    SET NOCOUNT ON;

    /* ---------- التحقق من المدخلات ---------- */
    IF ISNULL(@CsCId, 0) <= 0
        THROW 50001, N'يجب تحديد مركز التكلفة.', 1;
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'الفترة غير صحيحة.', 1;
    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع الفترة داخل السنة المالية المحددة.', 1;
    IF @Debit = 1 AND @Credit = 1
        THROW 50004, N'لا يمكن اختيار المدين والدائن معًا.', 1;

    SET @AccID = ISNULL(@AccID, 0);

    DECLARE @CsCCode NVARCHAR(60), @CsCName NVARCHAR(500);

    SELECT @CsCCode = c.CsCCode, @CsCName = c.CsCName
    FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCID = @CsCId AND c.CsCCompany = @Cmp;

    IF @CsCCode IS NULL
        THROW 50005, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS k WHERE k.CsCParentID = @CsCId)
        THROW 50006, N'كشف مركز التكلفة متاح لمراكز التكلفة التحليلية فقط.', 1;

    /* ---------- الحساب وفروعه (إن وُجد فلتر) ---------- */
    DECLARE @Acc TABLE (AccID BIGINT NOT NULL PRIMARY KEY);

    IF @AccID > 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID AND AccCompany = @Cmp)
            THROW 50007, N'الحساب غير موجود أو لا يتبع الشركة.', 1;

        ;WITH AccTree AS
        (
            SELECT a.AccID, CAST(0 AS INT) AS Lvl
            FROM dbo.Acc_Account AS a
            WHERE a.AccID = @AccID AND a.AccCompany = @Cmp

            UNION ALL

            SELECT a.AccID, p.Lvl + 1
            FROM dbo.Acc_Account AS a
            JOIN AccTree AS p ON a.AccParentID = p.AccID
            WHERE a.AccCompany = @Cmp AND p.Lvl < 30
        )
        INSERT INTO @Acc (AccID) SELECT AccID FROM AccTree OPTION (MAXRECURSION 100);
    END;

    /* ---------- رصيد بداية المدة: كل الحركات قبل @FromDate من كل السنوات ---------- */
    DECLARE @Opening DECIMAL(18,3);

    SELECT @Opening = ISNULL(SUM(d.DayDDeb), 0) - ISNULL(SUM(d.DayDCrd), 0)
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE d.DayDCsCID = @CsCId
      AND m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate < @FromDate
      AND (@AccID = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
    OPTION (RECOMPILE);

    /* ---------- حركات الفترة (الترتيب: الشهر ثم DayMNo ثم البند) ---------- */
    SELECT
        CAST(ROW_NUMBER() OVER (ORDER BY MONTH(m.DayMDate), m.DayMNo, d.DayDID) AS INT) AS Seq,
        m.DayMID, m.DayMNo, m.DayMDate,
        m.DayMDescription, d.DayDDescription, d.DayDNum,
        d.DayDAccID, a.AccCode, a.AccName,
        d.DayDDeb, d.DayDCrd
    INTO #Mov
    FROM dbo.Acc_DayDetails AS d
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    LEFT JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
    WHERE d.DayDCsCID = @CsCId
      AND m.DayMCompany = @Cmp
      AND m.DayMState = 7
      AND m.DayMDate >= @FromDate AND m.DayMDate <= @ToDate
      AND (@AccID = 0 OR d.DayDAccID IN (SELECT AccID FROM @Acc))
      AND (@Debit  = 0 OR d.DayDDeb > 0)
      AND (@Credit = 0 OR d.DayDCrd > 0)
    OPTION (RECOMPILE);

    DECLARE @PerDeb DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDDeb), 0) FROM #Mov),
            @PerCrd DECIMAL(18,3) = (SELECT ISNULL(SUM(DayDCrd), 0) FROM #Mov);
    DECLARE @Closing DECIMAL(18,3) = @Opening + @PerDeb - @PerCrd;

    /* ---------- النتيجة: جدول واحد ---------- */
    SELECT R.RowType, R.Seq, R.RowLabel,
           R.DayMID, R.DayMNo,
           CASE WHEN R.RowType = 1
                THEN CONCAT(CAST(R.DayMNo AS NVARCHAR(10)), N'/', RIGHT(CONCAT(N'0', MONTH(R.DayMDate)), 2))
           END AS EntryNo,
           R.DayMDate, R.EntryDescription, R.ItemDescription, R.DayDNum,
           R.AccountID AS AccID, R.AccountCode AS AccCode, R.AccountName AS AccName,
           R.Debit, R.Credit, R.Balance,
           CASE WHEN R.Balance > 0 THEN N'مدين' WHEN R.Balance < 0 THEN N'دائن' ELSE N'' END AS BalanceSide,
           @CsCId AS CsCID, @CsCCode AS CsCCode, @CsCName AS CsCName
    FROM
    (
        -- رصيد بداية المدة
        SELECT CAST(0 AS TINYINT) AS RowType, 0 AS Seq, N'رصيد بداية المدة' AS RowLabel,
               CAST(NULL AS BIGINT) AS DayMID, CAST(NULL AS INT) AS DayMNo, CAST(NULL AS DATE) AS DayMDate,
               CAST(NULL AS NVARCHAR(MAX)) AS EntryDescription, CAST(NULL AS NVARCHAR(MAX)) AS ItemDescription,
               CAST(NULL AS NVARCHAR(50)) AS DayDNum,
               CAST(NULL AS BIGINT) AS AccountID, CAST(NULL AS NVARCHAR(60)) AS AccountCode, CAST(NULL AS NVARCHAR(500)) AS AccountName,
               CAST(NULL AS DECIMAL(18,3)) AS Debit, CAST(NULL AS DECIMAL(18,3)) AS Credit,
               @Opening AS Balance

        UNION ALL
        -- الحركات مع الرصيد الجاري على الصفوف الظاهرة
        SELECT CAST(1 AS TINYINT), Seq, CAST(NULL AS NVARCHAR(50)),
               DayMID, DayMNo, DayMDate,
               DayMDescription, DayDDescription, DayDNum,
               DayDAccID, AccCode, AccName,
               DayDDeb, DayDCrd,
               @Opening + SUM(DayDDeb - DayDCrd) OVER (ORDER BY Seq ROWS UNBOUNDED PRECEDING)
        FROM #Mov

        UNION ALL
        -- رصيد خلال الفترة
        SELECT CAST(2 AS TINYINT), 0, N'رصيد خلال الفترة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               @PerDeb, @PerCrd, @PerDeb - @PerCrd

        UNION ALL
        -- رصيد نهاية المدة
        SELECT CAST(3 AS TINYINT), 0, N'رصيد نهاية المدة',
               NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               NULL, NULL, @Closing
    ) AS R
    ORDER BY R.RowType, R.Seq;
END;
GO

/* =========== اختبار سريع ===========
EXEC dbo.Acc_SelectCostCenterStatement @Cmp = 1, @Year = 2026, @CsCId = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30';
EXEC dbo.Acc_SelectCostCenterStatement @Cmp = 1, @Year = 2026, @CsCId = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @AccID = 213;   -- حساب أب بكل أحفاده
EXEC dbo.Acc_SelectCostCenterStatement @Cmp = 1, @Year = 2026, @CsCId = 5,
     @FromDate = '2026-01-01', @ToDate = '2026-10-30', @Debit = 1;
=================================================== */

USE MADARERPDataBase;
GO
/* =====================================================================
   Acc_SelectDashboard — بيانات لوحة المحاسبة (قراءة فقط)
   المدخلات: @Cmp, @Year
   القيود المحتسبة: DayMState من 1 إلى 7 (كل ما عدا المؤقت)
   المخرجات (7 مجموعات بالترتيب):
     1) KPI      : صف واحد بالمؤشرات
     2) Monthly  : 12 صفًا (الإيراد والمصروف لكل شهر)
     3) States   : 8 صفوف (عدد القيود لكل حالة 0..7 في السنة)
     4) Latest   : آخر 8 قيود
     5) TopExp   : أعلى 5 حسابات مصروفات
     6) Cash     : أرصدة حسابات النقدية (حتى 6 حسابات)
     7) Health   : مؤشرات سلامة (قيود مُرحّلة غير متوازنة، قيود مؤقتة قديمة)
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_SelectDashboard
    @Cmp  INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @Cmp IS NULL OR @Cmp <= 0 THROW 53001, N'الشركة المحددة غير صحيحة.', 1;
    IF @Year IS NULL OR @Year < 1900 OR @Year > 2200 THROW 53002, N'السنة المالية غير صحيحة.', 1;

    DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
            @To   DATE = DATEFROMPARTS(@Year, 12, 31);

    /* حركات السنة (غير المؤقتة) مع تصنيف الحساب */
    SELECT m.DayMID, m.DayMDate, d.DayDAccID, d.DayDDeb, d.DayDCrd,
           a.AccEnd, a.AccType
    INTO #Y
    FROM dbo.Acc_DayMaster AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    JOIN dbo.Acc_Account   AS a ON a.AccID = d.DayDAccID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState BETWEEN 1 AND 7
      AND m.DayMDate >= @From AND m.DayMDate <= @To;

    /* ---------- النقدية: الحسابات التحليلية تحت تصنيف CashFlowType = 1 ---------- */
    SELECT AccID, AccParentID INTO #Acc FROM dbo.Acc_Account WHERE AccCompany = @Cmp;

    ;WITH Up AS
    (
        SELECT a.AccID AS LeafID, a.AccID AS NodeID, a.AccParentID AS ParentID, 0 AS Dist
        FROM #Acc AS a
        UNION ALL
        SELECT u.LeafID, p.AccID, p.AccParentID, u.Dist + 1
        FROM Up AS u JOIN #Acc AS p ON p.AccID = u.ParentID
        WHERE u.ParentID > 0
    )
    SELECT DISTINCT u.LeafID AS AccID
    INTO #CashLeaf
    FROM Up AS u
    JOIN dbo.Acc_CashFlowAccounts AS c ON c.AccID = u.NodeID AND c.CashFlowType = 1
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS k WHERE k.AccParentID = u.LeafID)
    OPTION (MAXRECURSION 200);

    SELECT l.AccID,
           CAST(SUM(d.DayDDeb - d.DayDCrd) AS DECIMAL(28,3)) AS Bal
    INTO #CashBal
    FROM #CashLeaf AS l
    JOIN dbo.Acc_DayDetails AS d ON d.DayDAccID = l.AccID
    JOIN dbo.Acc_DayMaster  AS m ON m.DayMID = d.DayDMID
    WHERE m.DayMCompany = @Cmp AND m.DayMState BETWEEN 1 AND 7 AND m.DayMDate <= @To
    GROUP BY l.AccID;

    /* ---------- 1) KPI ---------- */
    DECLARE @Rev DECIMAL(28,3) =
        (SELECT ISNULL(SUM(DayDCrd - DayDDeb), 0) FROM #Y WHERE AccEnd = 2 AND AccType = 0);
    DECLARE @Exp DECIMAL(28,3) =
        (SELECT ISNULL(SUM(DayDDeb - DayDCrd), 0) FROM #Y WHERE AccEnd = 2 AND AccType = 1);

    SELECT
        @Rev AS Revenue,
        @Exp AS Expenses,
        @Rev - @Exp AS NetProfit,
        (SELECT ISNULL(SUM(Bal), 0) FROM #CashBal) AS CashBalance,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState BETWEEN 1 AND 7
            AND DayMDate BETWEEN @From AND @To) AS PostedCount,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState = 0
            AND DayMDate BETWEEN @From AND @To) AS DraftCount,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState IN (2, 4, 6)
            AND DayMDate BETWEEN @From AND @To) AS ReturnedCount,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState = 1
            AND DayMDate BETWEEN @From AND @To) AS AwaitingReviewCount;

    /* ---------- 2) الشهري ---------- */
    ;WITH M AS (SELECT 1 AS Mo UNION ALL SELECT Mo + 1 FROM M WHERE Mo < 12)
    SELECT M.Mo,
           CAST(ISNULL(SUM(CASE WHEN y.AccEnd = 2 AND y.AccType = 0 THEN y.DayDCrd - y.DayDDeb END), 0) AS DECIMAL(28,3)) AS Revenue,
           CAST(ISNULL(SUM(CASE WHEN y.AccEnd = 2 AND y.AccType = 1 THEN y.DayDDeb - y.DayDCrd END), 0) AS DECIMAL(28,3)) AS Expenses
    FROM M
    LEFT JOIN #Y AS y ON MONTH(y.DayMDate) = M.Mo
    GROUP BY M.Mo
    ORDER BY M.Mo;

    /* ---------- 3) الحالات ---------- */
    ;WITH S AS (SELECT CAST(0 AS TINYINT) AS St UNION ALL SELECT CAST(St + 1 AS TINYINT) FROM S WHERE St < 7)
    SELECT S.St AS DayMState,
           CASE S.St
                WHEN 0 THEN N'مؤقت'
                WHEN 1 THEN N'مُرحّل'
                WHEN 2 THEN N'مُعاد للمحاسب'
                WHEN 3 THEN N'اعتُمد من المراجعة'
                WHEN 4 THEN N'مُعاد للمراجعة'
                WHEN 5 THEN N'اعتمده المدير المالي'
                WHEN 6 THEN N'مُعاد للمدير المالي'
                WHEN 7 THEN N'مُؤرشف'
           END AS StateName,
           (SELECT COUNT(*) FROM dbo.Acc_DayMaster AS m
             WHERE m.DayMCompany = @Cmp AND m.DayMState = S.St
               AND m.DayMDate BETWEEN @From AND @To) AS Cnt
    FROM S
    ORDER BY S.St;

    /* ---------- 4) آخر القيود ---------- */
    SELECT TOP (8)
           m.DayMID,
           CASE WHEN m.DayMNo > 0
                THEN CONCAT(m.DayMNo, N'/', RIGHT(CONCAT(N'0', MONTH(m.DayMDate)), 2))
                ELSE N'—' END AS VoucherNo,
           m.DayMDate,
           m.DayMDescription,
           m.DayMState,
           CAST(ISNULL(t.TotDeb, 0) AS DECIMAL(28,3)) AS Amount
    FROM dbo.Acc_DayMaster AS m
    OUTER APPLY (SELECT SUM(d.DayDDeb) AS TotDeb FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS t
    WHERE m.DayMCompany = @Cmp AND m.DayMDate BETWEEN @From AND @To
    ORDER BY m.DayMID DESC;

    /* ---------- 5) أعلى المصروفات ---------- */
    SELECT TOP (5)
           a.AccCode, a.AccName,
           CAST(SUM(y.DayDDeb - y.DayDCrd) AS DECIMAL(28,3)) AS Amount
    FROM #Y AS y
    JOIN dbo.Acc_Account AS a ON a.AccID = y.DayDAccID
    WHERE y.AccEnd = 2 AND y.AccType = 1
    GROUP BY a.AccID, a.AccCode, a.AccName
    HAVING SUM(y.DayDDeb - y.DayDCrd) <> 0
    ORDER BY SUM(y.DayDDeb - y.DayDCrd) DESC;

    /* ---------- 6) النقدية ---------- */
    SELECT TOP (6) a.AccCode, a.AccName, b.Bal AS Balance
    FROM #CashBal AS b
    JOIN dbo.Acc_Account AS a ON a.AccID = b.AccID
    WHERE b.Bal <> 0
    ORDER BY ABS(b.Bal) DESC;

    /* ---------- 7) السلامة ---------- */
    SELECT
        (SELECT COUNT(*) FROM
            (SELECT d.DayDMID
               FROM dbo.Acc_DayMaster AS m
               JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
              WHERE m.DayMCompany = @Cmp AND m.DayMState BETWEEN 1 AND 7
                AND m.DayMDate BETWEEN @From AND @To
              GROUP BY d.DayDMID
             HAVING SUM(d.DayDDeb) <> SUM(d.DayDCrd)) AS x) AS UnbalancedPosted,
        (SELECT COUNT(*) FROM dbo.Acc_DayMaster
          WHERE DayMCompany = @Cmp AND DayMState = 0
            AND DayMDate BETWEEN @From AND @To
            AND DayMDateTime < DATEADD(DAY, -7, SYSUTCDATETIME())) AS StaleDrafts;
END;
GO

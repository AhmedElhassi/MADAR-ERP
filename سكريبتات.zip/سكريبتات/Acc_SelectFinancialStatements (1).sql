USE [MADARERPDataBase]
GO
/****** Object:  StoredProcedure [dbo].[Acc_SelectFinancialStatements]    Script Date: 2026-10-31 3:55:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[Acc_SelectFinancialStatements]
    @FromDate  DATE = NULL,
    @ToDate    DATE,
    @Cmp       INT = 1,
    @Year      INT = 0,
    @AllAcc    BIT = 0,
    @MoveAcc   BIT = 0,
    @BalnceAcc BIT = 0,
    @LevelAcc  TINYINT = 0
AS
BEGIN
    /* =====================================================================
       اسم التقرير : القوائم المالية (Financial Statements)
       الإجراء     : dbo.Acc_SelectFinancialStatements
       المدخلات    : @ToDate و@Cmp و@Year؛ الفترة دائمًا من 1 يناير حتى @ToDate
                     (يُتجاهل @FromDate).
       النتائج     : 1 قائمة الدخل
                     2 قائمة المركز المالي (الميزانية العمومية)
                     3 حركة حقوق الملكية
                     4 ملخص القوائم المالية
                     5 فحوص سلامة البيانات
                     6-8 قائمة التدفقات النقدية (Acc_SelectCashFlow)
                     9 ميزان المراجعة
       القواعد     : القيود المرحّلة فقط (DayMState = 7)؛ القيد على الحساب
                     التحليلي فقط؛ السنة لا تُقفل.
                     حقوق الملكية = حساباتها + نتائج السنوات السابقة
                     + نتيجة السنة الحالية، وفرق الميزانية (BalanceSheetDifference)
                     يجب أن يكون صفرًا إذا كانت القيود متوازنة.
       ملاحظة     : معنى @AllAcc هنا: 0 = التحليلية فقط، 1 = كل الحسابات
                     (عكس بقية إجراءات التقارير).
       ===================================================================== */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    /* =========================================================
       1. التحقق من المدخلات وتحديد السنة المالية
       ========================================================= */

    IF @ToDate IS NULL
        THROW 50201, N'تاريخ نهاية التقرير مطلوب.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50202, N'رقم الشركة غير صحيح.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_Company
        WHERE CmpID = @Cmp
    )
        THROW 50203, N'الشركة المحددة غير موجودة.', 1;

    SET @Year = ISNULL(@Year, 0);

    IF @Year = 0
        SET @Year = YEAR(@ToDate);

    IF @Year < 1900 OR @Year > 9999
        THROW 50204, N'السنة المالية غير صحيحة.', 1;

    IF YEAR(@ToDate) <> @Year
        THROW 50205, N'تاريخ نهاية التقرير لا يتوافق مع السنة المالية.', 1;

    SET @FromDate = DATEFROMPARTS(@Year, 1, 1);

    IF @ToDate < @FromDate
        THROW 50206, N'تاريخ نهاية التقرير يسبق بداية السنة المالية.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    DECLARE @ToDateExclusive DATE = DATEADD(DAY, 1, @ToDate);

    IF OBJECT_ID(N'dbo.Acc_SelectCashFlow', N'P') IS NULL
        THROW 50208, N'إجراء التدفقات النقدية غير موجود.', 1;


    /* =========================================================
       2. تحميل شجرة حسابات الشركة
       ========================================================= */

    DROP TABLE IF EXISTS #Acc;
    DROP TABLE IF EXISTS #Kid;
    DROP TABLE IF EXISTS #Leaf;
    DROP TABLE IF EXISTS #Roll;
    DROP TABLE IF EXISTS #JournalBalance;
    DROP TABLE IF EXISTS #BsOut;
    DROP TABLE IF EXISTS #EqOut;

    SELECT
        A.AccID,
        A.AccParentID,
        A.AccLevel,
        CAST(ISNULL(A.AccChid, 0) AS SMALLINT) AS AccChid,
        ISNULL(A.AccCode, N'') AS AccCode,
        ISNULL(A.AccName, N'') AS AccName,
        A.AccEnd,
        A.AccType
    INTO #Acc
    FROM dbo.Acc_Account AS A
    WHERE A.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50209, N'لا توجد حسابات مسجلة للشركة المحددة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Acc
        ON #Acc (AccID);

    CREATE NONCLUSTERED INDEX IX_FS_AccParent
        ON #Acc (AccParentID);


    /* =========================================================
       3. التحقق من سلامة الشجرة
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        WHERE C.AccParentID > 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Acc_Account AS P
              WHERE P.AccID = C.AccParentID
          )
    )
        THROW 50210, N'توجد حسابات يتيمة؛ الحساب الأب غير موجود.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        INNER JOIN dbo.Acc_Account AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccParentID > 0
          AND P.AccCompany <> @Cmp
    )
        THROW 50211, N'توجد علاقة أب وابن بين حسابات شركتين مختلفتين.', 1;

    DECLARE
        @AccountCount BIGINT,
        @ReachCount BIGINT;

    SELECT @AccountCount = COUNT_BIG(*)
    FROM #Acc;

    ;WITH AccountReach AS
    (
        SELECT AccID
        FROM #Acc
        WHERE AccParentID IS NULL
           OR AccParentID = 0

        UNION ALL

        SELECT C.AccID
        FROM #Acc AS C
        INNER JOIN AccountReach AS P
            ON C.AccParentID = P.AccID
    )
    SELECT @ReachCount = COUNT_BIG(*)
    FROM AccountReach
    OPTION (MAXRECURSION 32767);

    IF ISNULL(@ReachCount, 0) <> @AccountCount
        THROW 50212, N'توجد دورة أو حسابات غير مرتبطة بجذر شجرة الحسابات.', 1;


    /* =========================================================
       4. التحقق من التصنيف المالي

       الميزانية:
       AccEnd = 1
       AccType = 0 أصول
       AccType = 1 خصوم
       AccType = 2 حقوق ملكية

       قائمة الدخل:
       AccEnd = 2
       AccType = 0 إيرادات
       AccType = 1 مصروفات
       ========================================================= */

    IF EXISTS
    (
        SELECT 1
        FROM #Acc
        WHERE AccEnd IS NULL
           OR AccType IS NULL
           OR NOT
           (
               (AccEnd = 1 AND AccType IN (0,1,2))
               OR
               (AccEnd = 2 AND AccType IN (0,1))
           )
    )
        THROW 50213, N'توجد حسابات بتصنيف مالي غير صحيح.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM #Acc AS C
        INNER JOIN #Acc AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccEnd <> P.AccEnd
           OR C.AccType <> P.AccType
    )
        THROW 50214, N'يوجد اختلاف في التصنيف المالي بين حساب أب وأحد أبنائه.', 1;


    /* =========================================================
       5. تحديد الأبناء الفعليين
       ========================================================= */

    SELECT
        AccParentID AS AccID,
        COUNT_BIG(*) AS ChildCount
    INTO #Kid
    FROM #Acc
    WHERE AccParentID IS NOT NULL
      AND AccParentID > 0
    GROUP BY AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Kid
        ON #Kid (AccID);


    /* =========================================================
       6. فحص القيود المؤرشفة غير المتوازنة
       ========================================================= */

    SELECT
        M.DayMID,
        SUM(CONVERT(DECIMAL(38,3), D.DayDDeb)) AS TotalDebit,
        SUM(CONVERT(DECIMAL(38,3), D.DayDCrd)) AS TotalCredit
    INTO #JournalBalance
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive
    GROUP BY M.DayMID;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_JournalBalance
        ON #JournalBalance (DayMID);

    DECLARE
        @UnbalancedJournalCount BIGINT = 0,
        @ForeignAccountCount BIGINT = 0,
        @OrphanAccountCount BIGINT = 0,
        @CrossCompanyParentCount BIGINT = 0,
        @InvalidClassCount BIGINT = 0,
        @NonLeafPostingCount BIGINT = 0;

    SELECT @UnbalancedJournalCount = COUNT_BIG(*)
    FROM #JournalBalance
    WHERE ABS(TotalDebit - TotalCredit) >= 0.001;


    /* =========================================================
       7. تجميع حركات الحسابات التحليلية
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccParentID,
        A.AccLevel,
        A.AccChid,
        A.AccEnd,
        A.AccType,

        SUM
        (
            CASE
                WHEN M.DayMDate < @FromDate
                THEN
                    CONVERT(DECIMAL(38,3), D.DayDDeb)
                    - CONVERT(DECIMAL(38,3), D.DayDCrd)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS OpeningNet,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(38,3), D.DayDDeb)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS PeriodDebit,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(DECIMAL(38,3), D.DayDCrd)
                ELSE CONVERT(DECIMAL(38,3), 0)
            END
        ) AS PeriodCredit,

        SUM
        (
            CASE
                WHEN M.DayMDate >= @FromDate
                THEN CONVERT(BIGINT, 1)
                ELSE CONVERT(BIGINT, 0)
            END
        ) AS MovementCount

    INTO #Leaf
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    INNER JOIN #Acc AS A
        ON A.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Kid AS K
          WHERE K.AccID = A.AccID
      )
    GROUP BY
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccParentID,
        A.AccLevel,
        A.AccChid,
        A.AccEnd,
        A.AccType;

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Leaf
        ON #Leaf (AccID);


    /* =========================================================
       8. تجميع الحسابات التحليلية إلى الحسابات الأب
       ========================================================= */

    ;WITH AccountRollup AS
    (
        SELECT
            L.AccID AS NodeID,
            L.OpeningNet,
            L.PeriodDebit,
            L.PeriodCredit,
            L.MovementCount
        FROM #Leaf AS L

        UNION ALL

        SELECT
            P.AccID AS NodeID,
            R.OpeningNet,
            R.PeriodDebit,
            R.PeriodCredit,
            R.MovementCount
        FROM AccountRollup AS R
        INNER JOIN #Acc AS C
            ON C.AccID = R.NodeID
        INNER JOIN #Acc AS P
            ON P.AccID = C.AccParentID
        WHERE C.AccParentID > 0
    )
    SELECT
        NodeID AS AccID,
        SUM(OpeningNet) AS OpeningNet,
        SUM(PeriodDebit) AS PeriodDebit,
        SUM(PeriodCredit) AS PeriodCredit,
        SUM(MovementCount) AS MovementCount
    INTO #Roll
    FROM AccountRollup
    GROUP BY NodeID
    OPTION (MAXRECURSION 32767);

    CREATE UNIQUE CLUSTERED INDEX IX_FS_Roll
        ON #Roll (AccID);


    /* =========================================================
       9. فحوص الحركات والتصنيفات
       ========================================================= */

    SELECT
        @ForeignAccountCount = COUNT_BIG(*)
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    LEFT JOIN #Acc AS A
        ON A.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive
      AND A.AccID IS NULL;

    -- حركات مسجلة على حسابات أب (لا تدخل في الأرقام لأن القيد يُسجل على الحساب التحليلي فقط)
    SELECT
        @NonLeafPostingCount = COUNT_BIG(*)
    FROM dbo.Acc_DayMaster AS M
    INNER JOIN dbo.Acc_DayDetails AS D
        ON D.DayDMID = M.DayMID
    INNER JOIN #Kid AS K
        ON K.AccID = D.DayDAccID
    WHERE M.DayMCompany = @Cmp
      AND M.DayMState = 7
      AND M.DayMDate < @ToDateExclusive;

    SELECT
        @OrphanAccountCount = COUNT_BIG(*)
    FROM #Acc AS C
    WHERE C.AccParentID > 0
      AND NOT EXISTS
      (
          SELECT 1
          FROM #Acc AS P
          WHERE P.AccID = C.AccParentID
      );

    SELECT
        @CrossCompanyParentCount = COUNT_BIG(*)
    FROM #Acc AS C
    INNER JOIN dbo.Acc_Account AS P
        ON P.AccID = C.AccParentID
    WHERE P.AccCompany <> @Cmp;

    SELECT
        @InvalidClassCount = COUNT_BIG(*)
    FROM #Acc
    WHERE AccEnd IS NULL
       OR AccType IS NULL
       OR NOT
       (
           (AccEnd = 1 AND AccType IN (0,1,2))
           OR
           (AccEnd = 2 AND AccType IN (0,1))
       );


    /* =========================================================
       10. إجماليات قائمة الدخل
       ========================================================= */

    DECLARE
        @Revenue DECIMAL(38,3) = 0,
        @Expenses DECIMAL(38,3) = 0,
        @NetIncome DECIMAL(38,3) = 0;

    SELECT
        @Revenue =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN AccType = 0
                        THEN PeriodCredit - PeriodDebit
                        ELSE 0
                    END
                ),
                0
            ),
        @Expenses =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN AccType = 1
                        THEN PeriodDebit - PeriodCredit
                        ELSE 0
                    END
                ),
                0
            )
    FROM #Leaf
    WHERE AccEnd = 2;

    SET @NetIncome = @Revenue - @Expenses;

    /* السنة المالية لا تُقفل، فحسابات قائمة الدخل تتراكم:
       نتائج السنوات السابقة = كل ما قبل بداية السنة (الدائن موجب)،
       وصافي حركة حسابات قائمة الدخل خلال السنة = نتيجة السنة الحالية. */
    DECLARE
        @PriorResult DECIMAL(38,3) = 0,
        @IsDebit     DECIMAL(38,3) = 0,
        @IsCredit    DECIMAL(38,3) = 0,
        @IsCount     BIGINT = 0;

    SELECT
        @PriorResult = -ISNULL(SUM(OpeningNet), 0),
        @IsDebit     = ISNULL(SUM(PeriodDebit), 0),
        @IsCredit    = ISNULL(SUM(PeriodCredit), 0),
        @IsCount     = ISNULL(SUM(MovementCount), 0)
    FROM #Leaf
    WHERE AccEnd = 2;


    /* =========================================================
       11. إجماليات المركز المالي
       ========================================================= */

    DECLARE
        @Assets DECIMAL(38,3) = 0,
        @Liabilities DECIMAL(38,3) = 0,
        @EquityAcc DECIMAL(38,3) = 0;

    SELECT
        @Assets =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 0
                        THEN ISNULL(R.OpeningNet,0)
                           + ISNULL(R.PeriodDebit,0)
                           - ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            ),

        @Liabilities =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 1
                        THEN -ISNULL(R.OpeningNet,0)
                             - ISNULL(R.PeriodDebit,0)
                             + ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            ),

        @EquityAcc =
            ISNULL
            (
                SUM
                (
                    CASE
                        WHEN A.AccType = 2
                        THEN -ISNULL(R.OpeningNet,0)
                             - ISNULL(R.PeriodDebit,0)
                             + ISNULL(R.PeriodCredit,0)
                        ELSE 0
                    END
                ),
                0
            )
    FROM #Acc AS A
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND
      (
          A.AccParentID IS NULL
          OR A.AccParentID = 0
      );


    /* =========================================================
       12. فروقات المطابقة
       ========================================================= */

    DECLARE
        @BalanceDifference DECIMAL(38,3),
        @Equity DECIMAL(38,3);

    /* حقوق الملكية = حساباتها + نتائج السنوات السابقة + نتيجة السنة الحالية */
    SET @Equity = @EquityAcc + @PriorResult + @NetIncome;

    SET @BalanceDifference =
        @Assets - @Liabilities - @Equity;



    /* =========================================================
       RESULT SET 1: قائمة الدخل
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        P.AccName AS AccParentName,
        A.AccLevel,
        A.AccChid,
        A.AccType,

        CASE
            WHEN A.AccType = 0 THEN N'إيرادات'
            WHEN A.AccType = 1 THEN N'مصروفات'
        END AS AccountCategory,

        ISNULL(R.PeriodDebit,0) AS PeriodDebit,
        ISNULL(R.PeriodCredit,0) AS PeriodCredit,

        CAST
        (
            CASE
                WHEN A.AccType = 0
                    THEN ISNULL(R.PeriodCredit,0)
                       - ISNULL(R.PeriodDebit,0)
                WHEN A.AccType = 1
                    THEN ISNULL(R.PeriodDebit,0)
                       - ISNULL(R.PeriodCredit,0)
                ELSE 0
            END
            AS DECIMAL(38,3)
        ) AS PeriodAmount,

        ISNULL(R.MovementCount,0) AS MovementCount,

        @Revenue AS TotalRevenue,
        @Expenses AS TotalExpenses,
        @NetIncome AS NetIncome

    FROM #Acc AS A
    LEFT JOIN #Acc AS P
        ON P.AccID = A.AccParentID
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 2
      AND A.AccType IN (0,1)
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ORDER BY A.AccCode, A.AccID;


    /* =========================================================
       RESULT SET 2: قائمة المركز المالي
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        P.AccName AS AccParentName,
        A.AccLevel,
        A.AccChid,
        A.AccType,

        CASE
            WHEN A.AccType = 0 THEN N'الأصول'
            WHEN A.AccType = 1 THEN N'الخصوم'
            WHEN A.AccType = 2 THEN N'حقوق الملكية'
        END AS AccountCategory,

        ISNULL(R.OpeningNet,0) AS OpeningNet,
        ISNULL(R.PeriodDebit,0) AS PeriodDebit,
        ISNULL(R.PeriodCredit,0) AS PeriodCredit,

        CAST
        (
            CASE
                WHEN A.AccType = 0
                    THEN ISNULL(R.OpeningNet,0)
                       + ISNULL(R.PeriodDebit,0)
                       - ISNULL(R.PeriodCredit,0)
                WHEN A.AccType IN (1,2)
                    THEN -ISNULL(R.OpeningNet,0)
                       - ISNULL(R.PeriodDebit,0)
                       + ISNULL(R.PeriodCredit,0)
                ELSE 0
            END
            AS DECIMAL(38,3)
        ) AS ClosingBalance,

        ISNULL(R.MovementCount,0) AS MovementCount,

        @Assets AS TotalAssets,
        @Liabilities AS TotalLiabilities,
        @Equity AS TotalEquity,
        CAST(0 AS TINYINT) AS RowKind
    INTO #BsOut

    FROM #Acc AS A
    LEFT JOIN #Acc AS P
        ON P.AccID = A.AccParentID
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND A.AccType IN (0,1,2)
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @BalnceAcc = 0
          OR
          (
              CASE
                  WHEN A.AccType = 0
                      THEN ISNULL(R.OpeningNet,0)
                         + ISNULL(R.PeriodDebit,0)
                         - ISNULL(R.PeriodCredit,0)
                  ELSE -ISNULL(R.OpeningNet,0)
                       - ISNULL(R.PeriodDebit,0)
                       + ISNULL(R.PeriodCredit,0)
              END
          ) <> 0
      )
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ALTER TABLE #BsOut ALTER COLUMN AccCode NVARCHAR(200) NULL;
    ALTER TABLE #BsOut ALTER COLUMN AccARName NVARCHAR(400) NULL;

    -- صفّا نتائج السنوات ضمن حقوق الملكية (يظهران حتى مع @AllAcc و@LevelAcc)
    IF @MoveAcc = 0 AND (@BalnceAcc = 0 OR @PriorResult <> 0)
        INSERT INTO #BsOut
        (
            AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccChid, AccType,
            AccountCategory, OpeningNet, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
            TotalAssets, TotalLiabilities, TotalEquity, RowKind
        )
        VALUES
        (
            -1, N'~1', N'نتائج السنوات السابقة', NULL, NULL, 1, 0, 2,
            N'حقوق الملكية', -@PriorResult, 0, 0, @PriorResult, 0,
            @Assets, @Liabilities, @Equity, 1
        );

    IF (@MoveAcc = 0 OR @IsCount > 0) AND (@BalnceAcc = 0 OR @NetIncome <> 0)
        INSERT INTO #BsOut
        (
            AccID, AccCode, AccARName, AccParentID, AccParentName, AccLevel, AccChid, AccType,
            AccountCategory, OpeningNet, PeriodDebit, PeriodCredit, ClosingBalance, MovementCount,
            TotalAssets, TotalLiabilities, TotalEquity, RowKind
        )
        VALUES
        (
            -2, N'~2', N'نتيجة السنة الحالية', NULL, NULL, 1, 0, 2,
            N'حقوق الملكية', 0, @IsDebit, @IsCredit, @NetIncome, @IsCount,
            @Assets, @Liabilities, @Equity, 2
        );

    SELECT *
    FROM #BsOut
    ORDER BY AccType, RowKind, AccCode, AccID;


    /* =========================================================
       RESULT SET 3: حركة حقوق الملكية
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName AS AccARName,
        A.AccParentID,
        A.AccLevel,

        CAST
        (
            -ISNULL(R.OpeningNet,0)
            AS DECIMAL(38,3)
        ) AS OpeningEquity,

        CAST
        (
            ISNULL(R.PeriodCredit,0)
            - ISNULL(R.PeriodDebit,0)
            AS DECIMAL(38,3)
        ) AS PeriodMovement,

        CAST
        (
            -ISNULL(R.OpeningNet,0)
            - ISNULL(R.PeriodDebit,0)
            + ISNULL(R.PeriodCredit,0)
            AS DECIMAL(38,3)
        ) AS ClosingEquity,

        ISNULL(R.MovementCount,0) AS MovementCount,
        CAST(0 AS TINYINT) AS RowKind
    INTO #EqOut

    FROM #Acc AS A
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID
    WHERE A.AccEnd = 1
      AND A.AccType = 2
      AND (@AllAcc = 1 OR K.AccID IS NULL)
      AND (@MoveAcc = 0 OR ISNULL(R.MovementCount,0) > 0)
      AND
      (
          @LevelAcc = 0
          OR A.AccLevel = @LevelAcc
          OR (A.AccLevel < @LevelAcc AND K.AccID IS NULL)
      )
    ALTER TABLE #EqOut ALTER COLUMN AccCode NVARCHAR(200) NULL;
    ALTER TABLE #EqOut ALTER COLUMN AccARName NVARCHAR(400) NULL;

    IF @MoveAcc = 0
        INSERT INTO #EqOut
        (AccID, AccCode, AccARName, AccParentID, AccLevel, OpeningEquity, PeriodMovement, ClosingEquity, MovementCount, RowKind)
        VALUES
        (-1, N'~1', N'نتائج السنوات السابقة', NULL, 1, @PriorResult, 0, @PriorResult, 0, 1);

    IF @MoveAcc = 0 OR @IsCount > 0
        INSERT INTO #EqOut
        (AccID, AccCode, AccARName, AccParentID, AccLevel, OpeningEquity, PeriodMovement, ClosingEquity, MovementCount, RowKind)
        VALUES
        (-2, N'~2', N'نتيجة السنة الحالية', NULL, 1, 0, @NetIncome, @NetIncome, @IsCount, 2);

    SELECT *
    FROM #EqOut
    ORDER BY RowKind, AccCode, AccID;


    /* =========================================================
       RESULT SET 4: ملخص القوائم المالية
       ========================================================= */

    SELECT
        @Cmp AS CompanyID,
        @Year AS FinancialYear,
        @FromDate AS FromDate,
        @ToDate AS ToDate,

        @Revenue AS TotalRevenue,
        @Expenses AS TotalExpenses,
        @NetIncome AS NetIncome,
        @PriorResult AS PriorYearsResult,
        @EquityAcc AS EquityAccountsTotal,

        @Assets AS TotalAssets,
        @Liabilities AS TotalLiabilities,
        @Equity AS TotalEquity,

        @BalanceDifference AS BalanceSheetDifference,

        CASE
            WHEN ABS(@BalanceDifference) < 0.001
                THEN N'متوازن'
            ELSE N'توجد فروقات'
        END AS BalanceSheetStatus;


    /* =========================================================
       RESULT SET 5: فحوص سلامة البيانات
       ========================================================= */

    SELECT
        @ForeignAccountCount AS ForeignAccountMovementCount,
        @OrphanAccountCount AS OrphanAccountCount,
        @CrossCompanyParentCount AS CrossCompanyParentCount,
        @InvalidClassCount AS InvalidAccountClassificationCount,
        @UnbalancedJournalCount AS UnbalancedJournalCount,
        @NonLeafPostingCount AS NonLeafPostingCount,

        CASE
            WHEN @ForeignAccountCount = 0
             AND @OrphanAccountCount = 0
             AND @CrossCompanyParentCount = 0
             AND @InvalidClassCount = 0
             AND @UnbalancedJournalCount = 0
             AND @NonLeafPostingCount = 0
                THEN N'اجتازت البيانات فحوص السلامة المحددة'
            ELSE N'توجد ملاحظات تتطلب المراجعة'
        END AS DataIntegrityStatus;


    /* =========================================================
       RESULT SETS 6-8: التدفقات النقدية
       ========================================================= */

    EXEC dbo.Acc_SelectCashFlow
        @CompanyID = @Cmp,
        @DateFrom  = @FromDate,
        @DateTo    = @ToDate;


    /* =========================================================
       RESULT SET 9: ميزان المراجعة

       ملاحظة:
       OpenNet = صافي الرصيد الافتتاحي مديناً ناقص دائناً.
       PerDeb  = إجمالي مدين الفترة.
       PerCrd  = إجمالي دائن الفترة.
       PerCnt  = عدد تفاصيل الحركات خلال الفترة.
       ========================================================= */

    SELECT
        A.AccID,
        A.AccCode,
        A.AccName,
        A.AccLevel,
        A.AccParentID,
        A.AccChid,

        CAST(ISNULL(R.OpeningNet,0) AS DECIMAL(38,3))
            AS OpenNet,

        CAST(ISNULL(R.PeriodDebit,0) AS DECIMAL(38,3))
            AS PerDeb,

        CAST(ISNULL(R.PeriodCredit,0) AS DECIMAL(38,3))
            AS PerCrd,

        CAST(ISNULL(R.MovementCount,0) AS BIGINT)
            AS PerCnt,

        CAST
        (
            ISNULL(R.OpeningNet,0)
            + ISNULL(R.PeriodDebit,0)
            - ISNULL(R.PeriodCredit,0)
            AS DECIMAL(38,3)
        ) AS ClosingNet

    FROM #Acc AS A
    LEFT JOIN #Kid AS K
        ON K.AccID = A.AccID
    LEFT JOIN #Roll AS R
        ON R.AccID = A.AccID

    WHERE
        (@AllAcc = 1 OR K.AccID IS NULL)
        AND
        (
            @MoveAcc = 0
            OR ISNULL(R.MovementCount,0) > 0
        )
        AND
        (
            @BalnceAcc = 0
            OR
            (
                ISNULL(R.OpeningNet,0)
                + ISNULL(R.PeriodDebit,0)
                - ISNULL(R.PeriodCredit,0)
            ) <> 0
        )
        AND
        (
            @LevelAcc = 0
            OR A.AccLevel = @LevelAcc
            OR
            (
                A.AccLevel < @LevelAcc
                AND K.AccID IS NULL
            )
        )

    ORDER BY A.AccCode, A.AccID;

END;

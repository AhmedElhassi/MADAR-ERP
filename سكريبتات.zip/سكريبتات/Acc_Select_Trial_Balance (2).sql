USE [MADARERPDataBase];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* =====================================================================
   ميزان المراجعة
   ---------------------------------------------------------------------
   القواعد المحاسبية:
   - القيود المرحّلة فقط (DayMState = 7)، وتخص الشركة @Cmp.
   - رصيد أول المدة = كل الحركات قبل @FromDate من كل السنوات.
   - حركة الفترة = من @FromDate حتى @ToDate.
   - القيود تُسجَّل على الحسابات التحليلية (التي لا أبناء لها) فقط، وتُجمَّع
     أرصدتها نحو الآباء عبر شجرة الحسابات.
   - الصفوف والإجماليات تُحسب من الحسابات التحليلية فقط؛ أي حركة على حساب أب
     لا تدخل في الأرقام وتظهر فقط في ChkNonLeafAccounts.
   - إجماليات الميزان تُحسب لكل حساب تحليلي على حدة (مدين/دائن) دون مقاصة بين
     الحسابات، وتتجاهل فلاتر العرض.
   - شجرة الحسابات تُعالَج كاملة بلا حد عمق. أي حلقة (حساب أبوه نفسه، أو
     دورة بين حسابين أو أكثر) تُوقف التقرير بخطأ صريح 50010.

   الأداء:
   - مسح واحد لجداول القيود، ومنه تُشتق الصفوف والإجماليات والفحوص.
   - لا CURSOR ولا قيود مسمّاة على الجداول المؤقتة (آمن للتشغيل المتزامن).

   فهارس مقترحة (إن لم تكن موجودة):
     CREATE INDEX IX_DayMaster_Cmp_State_Date
         ON dbo.Acc_DayMaster (DayMCompany, DayMState, DayMDate) INCLUDE (DayMNo);
     CREATE INDEX IX_DayDetails_Master
         ON dbo.Acc_DayDetails (DayDMID) INCLUDE (DayDAccID, DayDDeb, DayDCrd);
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Acc_Select_Trial_Balance
    @FromDate  DATE     = NULL,
    @ToDate    DATE     = NULL,
    @Cmp       INT      = 1,
    @Year      INT      = 0,
    @AllAcc    BIT      = 0,    -- 1 = الحسابات التحليلية فقط
    @MoveAcc   BIT      = 0,    -- 1 = الحسابات التي لها حركة خلال الفترة فقط
    @BalnceAcc BIT      = 0,    -- 1 = الحسابات التي رصيد نهاية مدتها <> 0 فقط
    @LevelAcc  TINYINT  = 0     -- 0 = كل المستويات ؛ AccLevel المطلق (+ التحليلي الأقل مستوى)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    /* ---------- 1. التحقق من المدخلات ---------- */
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50002, N'فترة التقرير غير صحيحة.', 1;

    IF @Cmp IS NULL OR @Cmp <= 0
        THROW 50008, N'الشركة المحددة غير صحيحة.', 1;

    SET @Year = ISNULL(@Year, 0);
    IF @Year = 0
        SET @Year = YEAR(@FromDate);

    IF YEAR(@FromDate) <> @Year OR YEAR(@ToDate) <> @Year
        THROW 50003, N'يجب أن تقع فترة التقرير داخل السنة المالية المحددة.', 1;

    SET @AllAcc    = ISNULL(@AllAcc, 0);
    SET @MoveAcc   = ISNULL(@MoveAcc, 0);
    SET @BalnceAcc = ISNULL(@BalnceAcc, 0);
    SET @LevelAcc  = ISNULL(@LevelAcc, 0);

    /* ---------- 2. شجرة حسابات الشركة ---------- */
    SELECT a.AccID,
           a.AccParentID,
           a.AccLevel,
           CAST(ISNULL(a.AccChid, 0) AS SMALLINT) AS AccChid,
           ISNULL(a.AccCode, N'') AS AccCode,
           ISNULL(a.AccName, N'') AS AccName
    INTO #Acc
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp;

    IF NOT EXISTS (SELECT 1 FROM #Acc)
        THROW 50005, N'لا توجد حسابات لهذه الشركة.', 1;

    CREATE UNIQUE CLUSTERED INDEX IX_Acc ON #Acc (AccID);
    CREATE NONCLUSTERED INDEX IX_Acc_Parent ON #Acc (AccParentID);

    /* ---------- 3. سلامة الشجرة: لا حلقات ولا حساب أبوه نفسه ----------
       نمشي من الجذور إلى الأسفل. كل حساب داخل حلقة (أو أبوه نفسه) لا يمكن
       الوصول إليه من أي جذر، فإذا اختلف عدد المُوصَل إليهم عن العدد الكلي
       فالشجرة فيها حلقة. لا حد للعمق: الشجرة بلا حلقات تنتهي دائمًا. */
    DECLARE @Total INT = (SELECT COUNT(*) FROM #Acc), @Reached INT;

    ;WITH Reach AS
    (
        SELECT a.AccID
        FROM #Acc AS a
        WHERE a.AccParentID IS NULL
           OR a.AccParentID = 0
           OR NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)

        UNION ALL

        SELECT c.AccID
        FROM Reach AS r
        JOIN #Acc  AS c ON c.AccParentID = r.AccID
    )
    SELECT @Reached = COUNT(*) FROM Reach
    OPTION (MAXRECURSION 0);   -- بلا حد: لكل حساب أب واحد، والمشي من الجذور لا يدخل أي حلقة أبدًا فينتهي دائمًا

    IF @Reached <> @Total
    BEGIN
        DECLARE @CycleMsg NVARCHAR(300) =
            CONCAT(N'شجرة الحسابات فيها حلقة أو حساب أبوه نفسه (عدد الحسابات المتأثرة: ',
                   @Total - @Reached, N'). راجع الحسابات الأب والابن.');
        THROW 50010, @CycleMsg, 1;
    END;

    -- الآباء وعدد أبناء كل منهم (الحساب بلا أبناء = تحليلي)
    SELECT c.AccParentID AS AccID, COUNT(*) AS Cnt
    INTO #Kid
    FROM #Acc AS c
    WHERE c.AccParentID IS NOT NULL
    GROUP BY c.AccParentID;

    CREATE UNIQUE CLUSTERED INDEX IX_Kid ON #Kid (AccID);

    /* ---------- 4. (الحساب ← كل أحفاده بما فيهم نفسه) ---------- */
    ;WITH Cl AS
    (
        SELECT a.AccID AS NodeID, a.AccID AS DescID
        FROM #Acc AS a

        UNION ALL

        SELECT t.NodeID, c.AccID
        FROM Cl AS t
        JOIN #Acc AS c ON c.AccParentID = t.DescID
    )
    SELECT NodeID, DescID
    INTO #Cl
    FROM Cl
    OPTION (MAXRECURSION 0);   -- بلا حد: الشجرة خالية من الحلقات بعد فحص الخطوة 3 فينتهي دائمًا

    CREATE UNIQUE CLUSTERED INDEX IX_Cl ON #Cl (NodeID, DescID);

    /* ---------- 5. مسح واحد للقيود (أول المدة + حركة الفترة) ---------- */
    SELECT d.DayDAccID AS AccID,
           CAST(SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS DECIMAL(18,3)) AS OpenNet,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END) AS DECIMAL(18,3))              AS PerDeb,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END) AS DECIMAL(18,3))              AS PerCrd,
           CAST(SUM(CASE WHEN m.DayMDate >= @FromDate THEN 1 ELSE 0 END) AS BIGINT)                             AS PerCnt
    INTO #Amount
    FROM dbo.Acc_DayMaster  AS m
    JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
    WHERE m.DayMCompany = @Cmp
      AND m.DayMState   = 7
      AND m.DayMDate   <= @ToDate
    GROUP BY d.DayDAccID
    OPTION (RECOMPILE);

    CREATE UNIQUE CLUSTERED INDEX IX_Amount ON #Amount (AccID);

    /* ---------- 6. فحوص سلامة البيانات (النتيجة المتوقعة: أصفار) ---------- */
    DECLARE @ChkNonLeaf INT, @ChkOrphan INT, @ChkCrossCo INT, @ChkForeign INT, @ChkChid INT;

    -- حسابات عليها حركة وهي أب (الحركة لا تدخل في الأرقام)
    SELECT @ChkNonLeaf = COUNT(*)
    FROM #Amount AS am
    JOIN #Kid    AS k ON k.AccID = am.AccID;

    -- حسابات أبوها غير موجود في أي شركة (يتيمة فعلًا)
    SELECT @ChkOrphan = COUNT(*)
    FROM #Acc AS a
    WHERE a.AccParentID > 0
      AND NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS x WHERE x.AccID = a.AccParentID);

    -- حسابات أبوها موجود لكنه يتبع شركة أخرى (ربط خاطئ بين الشركات)
    SELECT @ChkCrossCo = COUNT(*)
    FROM #Acc AS a
    WHERE a.AccParentID > 0
      AND NOT EXISTS (SELECT 1 FROM #Acc AS p WHERE p.AccID = a.AccParentID)
      AND EXISTS     (SELECT 1 FROM dbo.Acc_Account AS x WHERE x.AccID = a.AccParentID);

    -- حركة على حساب لا يتبع هذه الشركة
    SELECT @ChkForeign = COUNT(*)
    FROM #Amount AS am
    WHERE NOT EXISTS (SELECT 1 FROM #Acc AS a WHERE a.AccID = am.AccID);

    -- AccChid المخزَّن لا يطابق وجود الأبناء الفعلي في الشجرة
    SELECT @ChkChid = COUNT(*)
    FROM #Acc AS a
    LEFT JOIN #Kid AS k ON k.AccID = a.AccID
    WHERE (CASE WHEN a.AccChid > 0 THEN 1 ELSE 0 END)
       <> (CASE WHEN k.AccID IS NULL THEN 0 ELSE 1 END);

    /* ---------- 7. حركات الحسابات التحليلية فقط (أساس الصفوف والإجماليات) ---------- */
    SELECT am.AccID, am.OpenNet, am.PerDeb, am.PerCrd, am.PerCnt
    INTO #LeafAmt
    FROM #Amount AS am
    JOIN #Acc    AS a ON a.AccID = am.AccID
    WHERE NOT EXISTS (SELECT 1 FROM #Kid AS k WHERE k.AccID = am.AccID);

    CREATE UNIQUE CLUSTERED INDEX IX_LeafAmt ON #LeafAmt (AccID);

    /* ---------- 8. إجماليات الميزان (لكل حساب تحليلي على حدة) ---------- */
    DECLARE
        @SumBlcOldDebit  DECIMAL(18,3), @SumBlcOldCredit  DECIMAL(18,3),
        @SumTotDebit     DECIMAL(18,3), @SumTotCredit     DECIMAL(18,3),
        @SumBlcDebit     DECIMAL(18,3), @SumBlcCredit     DECIMAL(18,3),
        @SumTotBlcDebit  DECIMAL(18,3), @SumTotBlcCredit  DECIMAL(18,3);

    SELECT
        @SumBlcOldDebit  = ISNULL(SUM(CASE WHEN y.OpenNet  > 0 THEN  y.OpenNet  ELSE 0 END), 0),
        @SumBlcOldCredit = ISNULL(SUM(CASE WHEN y.OpenNet  < 0 THEN -y.OpenNet  ELSE 0 END), 0),
        @SumTotDebit     = ISNULL(SUM(y.PerDeb), 0),
        @SumTotCredit    = ISNULL(SUM(y.PerCrd), 0),
        @SumBlcDebit     = ISNULL(SUM(CASE WHEN y.PerNet   > 0 THEN  y.PerNet   ELSE 0 END), 0),
        @SumBlcCredit    = ISNULL(SUM(CASE WHEN y.PerNet   < 0 THEN -y.PerNet   ELSE 0 END), 0),
        @SumTotBlcDebit  = ISNULL(SUM(CASE WHEN y.CloseNet > 0 THEN  y.CloseNet ELSE 0 END), 0),
        @SumTotBlcCredit = ISNULL(SUM(CASE WHEN y.CloseNet < 0 THEN -y.CloseNet ELSE 0 END), 0)
    FROM
    (
        SELECT l.OpenNet, l.PerDeb, l.PerCrd,
               l.PerDeb - l.PerCrd                AS PerNet,
               l.OpenNet + l.PerDeb - l.PerCrd    AS CloseNet
        FROM #LeafAmt AS l
    ) AS y;

    /* ---------- 9. تجميع كل حساب مع أحفاده ---------- */
    SELECT a.AccID, a.AccCode, a.AccName, a.AccParentID, a.AccLevel, a.AccChid,
           CAST(ISNULL(SUM(l.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(l.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(l.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(l.PerCnt ), 0) AS BIGINT)        AS PerCnt
    INTO #Roll
    FROM #Acc AS a
    JOIN #Cl  AS c ON c.NodeID = a.AccID
    LEFT JOIN #LeafAmt AS l ON l.AccID = c.DescID
    GROUP BY a.AccID, a.AccCode, a.AccName, a.AccParentID, a.AccLevel, a.AccChid;

    CREATE UNIQUE CLUSTERED INDEX IX_Roll ON #Roll (AccID);

    /* ---------- 10. النتيجة النهائية ---------- */
    SELECT
        x.AccID,
        x.AccCode,
        x.AccName                          AS AccARName,
        x.AccLevel,
        x.AccParentID                      AS AccParint,
        p.AccName                          AS AccParintName,
        x.AccChid                          AS AccCountChid,

        -- رصيد أول المدة
        CASE WHEN x.OpenNet > 0 THEN  x.OpenNet ELSE 0 END AS OldDebit,
        CASE WHEN x.OpenNet < 0 THEN -x.OpenNet ELSE 0 END AS OldCredit,
        -- الحركة بالمجاميع
        x.PerDeb                                            AS NewDebit,
        x.PerCrd                                            AS NewCredit,
        -- الحركة بالأرصدة
        CASE WHEN x.PerNet > 0 THEN  x.PerNet ELSE 0 END    AS BalanceDebit,
        CASE WHEN x.PerNet < 0 THEN -x.PerNet ELSE 0 END    AS BalanceCredit,
        -- رصيد نهاية الفترة
        CASE WHEN x.CloseNet > 0 THEN  x.CloseNet ELSE 0 END AS TotBlcDebit,
        CASE WHEN x.CloseNet < 0 THEN -x.CloseNet ELSE 0 END AS TotBlcCredit,

        -- إجماليات الميزان (تتكرر على كل صف)
        @SumBlcOldDebit  AS SumBlcOldDebit,
        @SumBlcOldCredit AS SumBlcOldCredit,
        @SumTotDebit     AS SumTotDebit,
        @SumTotCredit    AS SumTotCredit,
        @SumBlcDebit     AS SumBlcDebit,
        @SumBlcCredit    AS SumBlcCredit,
        @SumTotBlcDebit  AS SumTotBlcDebit,
        @SumTotBlcCredit AS SumTotBlcCredit,

        -- فحوص ذاتية في آخر النتيجة: يجب أن تكون كلها صفرًا
        @SumBlcOldDebit - @SumBlcOldCredit AS ChkOpenDiff,
        @SumTotDebit    - @SumTotCredit    AS ChkPeriodDiff,
        @SumTotBlcDebit - @SumTotBlcCredit AS ChkCloseDiff,
        @ChkNonLeaf                        AS ChkNonLeafAccounts,
        @ChkOrphan                         AS ChkOrphanAccounts,
        @ChkCrossCo                        AS ChkCrossCompanyParents,
        @ChkForeign                        AS ChkForeignAccounts,
        @ChkChid                           AS ChkChidMismatch

    FROM
    (
        SELECT r.*,
               r.PerDeb - r.PerCrd               AS PerNet,
               r.OpenNet + r.PerDeb - r.PerCrd   AS CloseNet
        FROM #Roll AS r
    ) AS x
    LEFT JOIN #Acc AS p ON p.AccID = x.AccParentID
    LEFT JOIN #Kid AS k ON k.AccID = x.AccID
    WHERE (@AllAcc    = 0 OR k.AccID IS NULL)
      AND (@LevelAcc  = 0 OR x.AccLevel = @LevelAcc OR (x.AccLevel < @LevelAcc AND k.AccID IS NULL))
      AND (@MoveAcc   = 0 OR x.PerCnt   > 0)
      AND (@BalnceAcc = 0 OR x.CloseNet <> 0)
    ORDER BY x.AccCode, x.AccID
    OPTION (RECOMPILE);
END;
GO

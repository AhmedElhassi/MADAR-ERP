/* =====================================================================
   سكربت التحقق من ميزان المراجعة — شغّله بعد إنشاء الإجراء
   غيّر الإعدادات الثلاثة التالية ثم نفّذ الملف كله.
   كل فحص يطبع PASS أو FAIL مع التفاصيل.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;

DECLARE @Cmp      INT  = 1;
DECLARE @FromDate DATE = '2026-07-01';
DECLARE @ToDate   DATE = '2026-12-31';
DECLARE @Year     INT  = YEAR(@FromDate);

/* ---------- تشغيل الإجراء بلا أي فلتر (كل الحسابات) ---------- */
CREATE TABLE #TB
(
    AccID BIGINT, AccCode NVARCHAR(60), AccARName NVARCHAR(500), AccLevel INT,
    AccParint BIGINT NULL, AccParintName NVARCHAR(500) NULL, AccCountChid INT,
    OldDebit DECIMAL(18,3), OldCredit DECIMAL(18,3),
    NewDebit DECIMAL(18,3), NewCredit DECIMAL(18,3),
    BalanceDebit DECIMAL(18,3), BalanceCredit DECIMAL(18,3),
    TotBlcDebit DECIMAL(18,3), TotBlcCredit DECIMAL(18,3),
    SumBlcOldDebit DECIMAL(18,3), SumBlcOldCredit DECIMAL(18,3),
    SumTotDebit DECIMAL(18,3), SumTotCredit DECIMAL(18,3),
    SumBlcDebit DECIMAL(18,3), SumBlcCredit DECIMAL(18,3),
    SumTotBlcDebit DECIMAL(18,3), SumTotBlcCredit DECIMAL(18,3),
    ChkOpenDiff DECIMAL(18,3), ChkPeriodDiff DECIMAL(18,3), ChkCloseDiff DECIMAL(18,3),
    ChkNonLeafAccounts INT, ChkOrphanAccounts INT, ChkCrossCompanyParents INT,
    ChkForeignAccounts INT, ChkChidMismatch INT
);

SET STATISTICS TIME ON;
INSERT INTO #TB
EXEC dbo.Acc_Select_Trial_Balance
     @FromDate = @FromDate, @ToDate = @ToDate, @Cmp = @Cmp, @Year = @Year,
     @AllAcc = 0, @MoveAcc = 0, @BalnceAcc = 0, @LevelAcc = 0;
SET STATISTICS TIME OFF;

DECLARE @RowsCnt INT = (SELECT COUNT(*) FROM #TB);
PRINT N'عدد الصفوف: ' + CAST(@RowsCnt AS NVARCHAR(20));

/* ---------- 1) الميزان متوازن (مدين = دائن) في الأعمدة الثلاثة ---------- */
IF EXISTS (SELECT 1 FROM #TB WHERE ChkOpenDiff <> 0 OR ChkPeriodDiff <> 0 OR ChkCloseDiff <> 0)
BEGIN
    PRINT N'FAIL 1: الميزان غير متوازن';
    SELECT TOP 1 ChkOpenDiff, ChkPeriodDiff, ChkCloseDiff FROM #TB;
END
ELSE PRINT N'PASS 1: الميزان متوازن (أول المدة / الحركة / آخر المدة)';

/* ---------- 2) لكل صف: أول المدة + الحركة = آخر المدة ---------- */
IF EXISTS (SELECT 1 FROM #TB
           WHERE (OldDebit - OldCredit) + (NewDebit - NewCredit) <> (TotBlcDebit - TotBlcCredit))
BEGIN
    PRINT N'FAIL 2: صفوف لا يتحقق فيها أول المدة + الحركة = آخر المدة';
    SELECT TOP 20 AccCode, AccARName, OldDebit, OldCredit, NewDebit, NewCredit, TotBlcDebit, TotBlcCredit
    FROM #TB
    WHERE (OldDebit - OldCredit) + (NewDebit - NewCredit) <> (TotBlcDebit - TotBlcCredit);
END
ELSE PRINT N'PASS 2: أول المدة + الحركة = آخر المدة لكل الصفوف';

/* ---------- 3) لكل أب: صافيه = مجموع صافي أبنائه المباشرين (أول المدة والحركة والنهاية) ---------- */
;WITH Kids AS
(
    SELECT AccParint AS PID,
           SUM(OldDebit - OldCredit)         AS OpenNet,
           SUM(NewDebit - NewCredit)         AS PerNet,
           SUM(TotBlcDebit - TotBlcCredit)   AS CloseNet
    FROM #TB
    WHERE AccParint IS NOT NULL
    GROUP BY AccParint
)
SELECT p.AccCode, p.AccARName
INTO #Bad3
FROM #TB AS p
JOIN Kids AS k ON k.PID = p.AccID
WHERE (p.OldDebit - p.OldCredit)       <> k.OpenNet
   OR (p.NewDebit - p.NewCredit)       <> k.PerNet
   OR (p.TotBlcDebit - p.TotBlcCredit) <> k.CloseNet;

IF EXISTS (SELECT 1 FROM #Bad3)
BEGIN
    PRINT N'FAIL 3: آباء لا يساوي رصيدهم مجموع أبنائهم';
    SELECT TOP 20 * FROM #Bad3;
END
ELSE PRINT N'PASS 3: كل أب = مجموع أبنائه';

/* ---------- 4) مقارنة مستقلة بالجداول الخام للحسابات التحليلية ---------- */
SELECT d.DayDAccID AS AccID,
       SUM(CASE WHEN m.DayMDate <  @FromDate THEN d.DayDDeb - d.DayDCrd ELSE 0 END) AS OpenNet,
       SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDDeb ELSE 0 END)              AS PerDeb,
       SUM(CASE WHEN m.DayMDate >= @FromDate THEN d.DayDCrd ELSE 0 END)              AS PerCrd
INTO #Raw
FROM dbo.Acc_DayMaster  AS m
JOIN dbo.Acc_DayDetails AS d ON d.DayDMID = m.DayMID
WHERE m.DayMCompany = @Cmp AND m.DayMState = 7 AND m.DayMDate <= @ToDate
GROUP BY d.DayDAccID;

SELECT AccID,
       CAST(CASE WHEN OpenNet > 0 THEN OpenNet ELSE 0 END AS DECIMAL(18,3))  AS OldDebit,
       CAST(CASE WHEN OpenNet < 0 THEN -OpenNet ELSE 0 END AS DECIMAL(18,3)) AS OldCredit,
       CAST(PerDeb AS DECIMAL(18,3)) AS NewDebit,
       CAST(PerCrd AS DECIMAL(18,3)) AS NewCredit
INTO #Expected
FROM #Raw
WHERE OpenNet <> 0 OR PerDeb <> 0 OR PerCrd <> 0;

SELECT AccID, OldDebit, OldCredit, NewDebit, NewCredit
INTO #Actual
FROM #TB AS t
WHERE NOT EXISTS (SELECT 1 FROM #TB AS c WHERE c.AccParint = t.AccID)   -- حساب تحليلي = بلا أبناء في النتيجة
  AND (OldDebit <> 0 OR OldCredit <> 0 OR NewDebit <> 0 OR NewCredit <> 0);

SELECT N'مفقود/مختلف في الإجراء' AS Side, * FROM (SELECT * FROM #Expected EXCEPT SELECT * FROM #Actual) AS e
UNION ALL
SELECT N'زائد/مختلف في الإجراء', * FROM (SELECT * FROM #Actual EXCEPT SELECT * FROM #Expected) AS a;

IF @@ROWCOUNT = 0
    PRINT N'PASS 4: الحسابات التحليلية مطابقة للحساب المستقل من الجداول الخام';
ELSE
    PRINT N'FAIL 4: اختلافات بين الإجراء والحساب المستقل (انظر الجدول أعلاه)';

/* ---------- 5) الإجماليات = مجموع الحسابات التحليلية ---------- */
IF EXISTS
(
    SELECT 1
    FROM (SELECT TOP 1 * FROM #TB) AS t
    CROSS JOIN (SELECT SUM(OldDebit) AS OD, SUM(OldCredit) AS OC,
                       SUM(NewDebit) AS ND, SUM(NewCredit) AS NC,
                       SUM(TotBlcDebit) AS TD, SUM(TotBlcCredit) AS TC
                FROM #TB AS t
                WHERE NOT EXISTS (SELECT 1 FROM #TB AS c WHERE c.AccParint = t.AccID)) AS s
    WHERE t.SumBlcOldDebit <> s.OD OR t.SumBlcOldCredit <> s.OC
       OR t.SumTotDebit    <> s.ND OR t.SumTotCredit    <> s.NC
       OR t.SumTotBlcDebit <> s.TD OR t.SumTotBlcCredit <> s.TC
)
    PRINT N'FAIL 5: الإجماليات لا تساوي مجموع الحسابات التحليلية';
ELSE PRINT N'PASS 5: الإجماليات = مجموع الحسابات التحليلية';

/* ---------- 6) فحوص سلامة البيانات (يجب أن تكون أصفارًا) ---------- */
IF EXISTS (SELECT 1 FROM #TB WHERE ChkNonLeafAccounts <> 0 OR ChkOrphanAccounts <> 0
                                OR ChkCrossCompanyParents <> 0 OR ChkForeignAccounts <> 0 OR ChkChidMismatch <> 0)
BEGIN
    PRINT N'WARN 6: توجد مشاكل في البيانات';
    SELECT TOP 1 ChkNonLeafAccounts      AS [حسابات أب عليها حركة (لا تدخل في الأرقام)],
                 ChkOrphanAccounts       AS [حسابات أبوها غير موجود],
                 ChkCrossCompanyParents  AS [حسابات أبوها من شركة أخرى],
                 ChkForeignAccounts      AS [حركة على حساب من شركة أخرى],
                 ChkChidMismatch         AS [AccChid لا يطابق الأبناء الفعليين]
    FROM #TB;
END
ELSE PRINT N'PASS 6: بيانات الشجرة والحركات سليمة (كل الفحوص أصفار)';

/* ---------- 7) الفلاتر ---------- */
SELECT * INTO #TB2 FROM #TB WHERE 1 = 0;

INSERT INTO #TB2
EXEC dbo.Acc_Select_Trial_Balance @FromDate=@FromDate,@ToDate=@ToDate,@Cmp=@Cmp,@Year=@Year,@AllAcc=1;

IF EXISTS (SELECT 1 FROM #TB WHERE AccID IN (SELECT AccID FROM #TB2)
                               AND AccID IN (SELECT AccParint FROM #TB WHERE AccParint IS NOT NULL))
    PRINT N'FAIL 7a: ظهرت حسابات أب مع @AllAcc = 1';
ELSE PRINT N'PASS 7a: @AllAcc = 1 يعرض الحسابات التحليلية فقط';

DELETE FROM #TB2;
INSERT INTO #TB2
EXEC dbo.Acc_Select_Trial_Balance @FromDate=@FromDate,@ToDate=@ToDate,@Cmp=@Cmp,@Year=@Year,@BalnceAcc=1;

IF EXISTS (SELECT 1 FROM #TB2 WHERE (TotBlcDebit = 0 AND TotBlcCredit = 0))
    PRINT N'FAIL 7b: ظهر حساب رصيده صفر مع @BalnceAcc = 1';
ELSE PRINT N'PASS 7b: @BalnceAcc = 1 يخفي الأرصدة الصفرية';

DELETE FROM #TB2;
INSERT INTO #TB2
EXEC dbo.Acc_Select_Trial_Balance @FromDate=@FromDate,@ToDate=@ToDate,@Cmp=@Cmp,@Year=@Year,@MoveAcc=1;

IF EXISTS (SELECT 1 FROM #TB2 WHERE NewDebit = 0 AND NewCredit = 0)
    PRINT N'FAIL 7c: ظهر حساب بلا حركة مع @MoveAcc = 1';
ELSE PRINT N'PASS 7c: @MoveAcc = 1 يعرض الحسابات ذات الحركة فقط';

/* ---------- 7د) حجم شجرة الحسابات وجدول الربط #Cl (معلومات للأداء) ----------
   عدد صفوف #Cl = مجموع أعماق كل الحسابات (كل حساب يظهر مرة لكل أب له ولنفسه). */
;WITH Reach AS
(
    SELECT a.AccID, CAST(1 AS INT) AS Depth
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp
      AND (a.AccParentID IS NULL OR a.AccParentID = 0
           OR NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS p WHERE p.AccID = a.AccParentID AND p.AccCompany = @Cmp))
    UNION ALL
    SELECT c.AccID, r.Depth + 1
    FROM Reach AS r
    JOIN dbo.Acc_Account AS c ON c.AccParentID = r.AccID AND c.AccCompany = @Cmp
)
SELECT COUNT(*)               AS [عدد الحسابات],
       MAX(Depth)             AS [أقصى عمق],
       CAST(AVG(CAST(Depth AS FLOAT)) AS DECIMAL(6,2)) AS [متوسط العمق],
       SUM(CAST(Depth AS BIGINT)) AS [صفوف #Cl المتوقعة]
FROM Reach
OPTION (MAXRECURSION 1000);
-- قاعدة تقريبية: إن بقي «صفوف #Cl» أقل من نحو مليون فلا أثر محسوس مقارنة بمسح القيود.

/* ---------- 8) القيم المرجعية من الصورة (قارنها يدويًّا) ----------
   من 2026-07-01 إلى 2026-12-31 ، @LevelAcc = 3 ، @BalnceAcc = 1 :
   أول المدة   : 233,148,758.657 مدين / 233,148,758.657 دائن
   الحركة      : 216,263,116.143 على الجانبين
   بالأرصدة    : 114,738,283.469 على الجانبين
   آخر المدة   : 304,527,663.274 على الجانبين
   ------------------------------------------------------------------ */
EXEC dbo.Acc_Select_Trial_Balance
     @FromDate = '2026-07-01', @ToDate = '2026-12-31', @Cmp = 1, @Year = 2026,
     @BalnceAcc = 1, @LevelAcc = 3;

/* ---------- 9) اختبار التزامن (يدوي) ----------
   افتح نافذتين في SSMS وشغّل في كل منهما في الوقت نفسه:
     WHILE 1 = 1 BEGIN EXEC dbo.Acc_Select_Trial_Balance @FromDate='2026-07-01',@ToDate='2026-12-31',@Cmp=1; END
   النتيجة الصحيحة: لا خطأ "There is already an object named ..." ثم أوقفهما.
   ------------------------------------------------------------------ */

DROP TABLE #TB, #TB2, #Raw, #Expected, #Actual, #Bad3;

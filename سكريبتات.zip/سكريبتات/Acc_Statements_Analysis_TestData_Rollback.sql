/* =====================================================================
   اختبار الإجراءات الأربعة (يعمل على قاعدة فيها بيانات، وينتهي بـ ROLLBACK دائمًا):
     Acc_SelectAccountStatement      كشف حساب
     Acc_SelectCostCenterStatement   كشف مركز تكلفة
     Acc_SelectAccountAnalysis       تحليل حساب
     Acc_SelectCostCenterAnalysis    تحليل مركز تكلفة
   ---------------------------------------------------------------------
   الطريقة (اختبار فروق):
     1) تشغيل كل الحالات قبل أي قيد تجريبي (خط الأساس).
     2) إدخال قيود تجريبية متوازنة داخل معاملة (مرحّلة، مسودة، سنة سابقة، بعد @ToDate).
     3) إعادة التشغيل ومقارنة الفرق بالأثر المتوقع محسوبًا مستقلًا من القيود التجريبية.
     4) اختبار فلاتر العرض (الأوراق/المستوى/الحركة/الرصيد/مدين/دائن) على كامل الدليل،
        واختبار سلامة الرصيد الجاري والترويسة ورسائل الخطأ.
   يختار الحسابات ومراكز التكلفة تلقائيًا من بياناتك:
     حساب أب له ورقتان على الأقل (A1,A2) + حساب آخر خارج فرعه (B)
     مركز أب له ورقتان على الأقل (K1,K2) + مركز آخر خارج فرعه (K0)
   غيّر @UserId (مستخدم موجود في Mng_User) ثم نفّذ الملف كله.
   النتيجة: أسطر PASS / FAIL في تبويب Messages.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
SET XACT_ABORT OFF;      -- مطلوب: اختبارات الأخطاء داخل TRY لا يجوز أن تُفسد المعاملة

DECLARE @Cmp    INT    = 10;
DECLARE @UserId BIGINT = 1;      -- رقم مستخدم موجود في Mng_User
DECLARE @Year   INT    = 2026;
DECLARE @From   DATE   = '2026-04-01';
DECLARE @To     DATE   = '2026-06-30';

BEGIN TRY
    BEGIN TRAN;

    /* ---------- 1) اختيار الحسابات ومراكز التكلفة ---------- */
    DECLARE @PA BIGINT, @A1 BIGINT, @A2 BIGINT, @B BIGINT,
            @KP BIGINT, @K1 BIGINT, @K2 BIGINT, @K0 BIGINT;

    SELECT TOP (1) @PA = p.AccID
    FROM dbo.Acc_Account AS p
    WHERE p.AccCompany = @Cmp
      AND (SELECT COUNT(*) FROM dbo.Acc_Account AS c
           WHERE c.AccParentID = p.AccID AND c.AccCompany = @Cmp
             AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS g WHERE g.AccParentID = c.AccID)) >= 2
    ORDER BY p.AccCode;

    SELECT TOP (1) @KP = p.CsCID
    FROM dbo.Acc_CostCenter AS p
    WHERE p.CsCCompany = @Cmp
      AND (SELECT COUNT(*) FROM dbo.Acc_CostCenter AS c
           WHERE c.CsCParentID = p.CsCID AND c.CsCCompany = @Cmp
             AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS g WHERE g.CsCParentID = c.CsCID)) >= 2
    ORDER BY p.CsCCode;

    IF @PA IS NULL THROW 51001, N'لا يوجد حساب أب له ورقتان تحليليتان على الأقل.', 1;
    IF @KP IS NULL THROW 51002, N'لا يوجد مركز تكلفة أب له ورقتان تحليليتان على الأقل.', 1;

    SELECT TOP (1) @A1 = c.AccID FROM dbo.Acc_Account AS c
    WHERE c.AccParentID = @PA AND c.AccCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS g WHERE g.AccParentID = c.AccID)
    ORDER BY c.AccCode ASC;

    SELECT TOP (1) @A2 = c.AccID FROM dbo.Acc_Account AS c
    WHERE c.AccParentID = @PA AND c.AccCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS g WHERE g.AccParentID = c.AccID)
    ORDER BY c.AccCode DESC;

    SELECT TOP (1) @K1 = c.CsCID FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCParentID = @KP AND c.CsCCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS g WHERE g.CsCParentID = c.CsCID)
    ORDER BY c.CsCCode ASC;

    SELECT TOP (1) @K2 = c.CsCID FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCParentID = @KP AND c.CsCCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS g WHERE g.CsCParentID = c.CsCID)
    ORDER BY c.CsCCode DESC;

    -- فرع الحساب الأب وفرع المركز الأب (لاستبعادهما عند اختيار B و K0)
    ;WITH T AS
    (
        SELECT AccID FROM dbo.Acc_Account WHERE AccID = @PA
        UNION ALL
        SELECT a.AccID FROM dbo.Acc_Account AS a JOIN T ON a.AccParentID = T.AccID WHERE a.AccCompany = @Cmp
    )
    SELECT AccID INTO #PASub FROM T OPTION (MAXRECURSION 1000);

    ;WITH T AS
    (
        SELECT CsCID FROM dbo.Acc_CostCenter WHERE CsCID = @KP
        UNION ALL
        SELECT c.CsCID FROM dbo.Acc_CostCenter AS c JOIN T ON c.CsCParentID = T.CsCID WHERE c.CsCCompany = @Cmp
    )
    SELECT CsCID INTO #KPSub FROM T OPTION (MAXRECURSION 1000);

    SELECT TOP (1) @B = a.AccID FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS g WHERE g.AccParentID = a.AccID)
      AND a.AccID NOT IN (SELECT AccID FROM #PASub)
    ORDER BY a.AccCode DESC;

    SELECT TOP (1) @K0 = c.CsCID FROM dbo.Acc_CostCenter AS c
    WHERE c.CsCCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS g WHERE g.CsCParentID = c.CsCID)
      AND c.CsCID NOT IN (SELECT CsCID FROM #KPSub)
    ORDER BY c.CsCCode DESC;

    IF @A1 IS NULL OR @A2 IS NULL OR @A1 = @A2 OR @B IS NULL
        THROW 51003, N'تعذّر اختيار الحسابات التحليلية.', 1;
    IF @K1 IS NULL OR @K2 IS NULL OR @K1 = @K2 OR @K0 IS NULL
        THROW 51004, N'تعذّر اختيار مراكز التكلفة التحليلية.', 1;

    PRINT CONCAT(N'الحسابات: أب=', @PA, N' A1=', @A1, N' A2=', @A2, N' B=', @B,
                 N' | المراكز: أب=', @KP, N' K1=', @K1, N' K2=', @K2, N' K0=', @K0);

    CREATE TABLE #Res (N INT IDENTITY(1,1), Name NVARCHAR(300), Ok BIT);

    /* ---------- 2) القيود التجريبية (كلها متوازنة) ---------- */
    CREATE TABLE #Line (EntryNo INT, EntryDate DATE, State TINYINT, AccID BIGINT, CsC BIGINT, Deb DECIMAL(18,3), Crd DECIMAL(18,3));

    INSERT #Line VALUES
      -- 1: قبل الفترة داخل السنة
      (1, '2026-03-05', 7, @A1, @K1, 1000, 0), (1, '2026-03-05', 7, @B,  @K0, 0, 1000),
      -- 2: داخل الفترة
      (2, '2026-05-10', 7, @A1, @K2, 300, 0), (2, '2026-05-10', 7, @A2, @K1, 200, 0), (2, '2026-05-10', 7, @B, @K0, 0, 500),
      -- 3: داخل الفترة (دائن على A2)
      (3, '2026-05-20', 7, @B,  @K0, 150, 0), (3, '2026-05-20', 7, @A2, @K2, 0, 150),
      -- 4: السنة السابقة (يدخل في الافتتاحي)
      (4, '2025-12-20', 7, @A2, @K1, 600, 0), (4, '2025-12-20', 7, @B, @K0, 0, 600),
      -- 5: مسودة داخل الفترة: يجب ألا تظهر
      (5, '2026-04-15', 0, @A1, @K1, 9999, 0), (5, '2026-04-15', 0, @B, @K0, 0, 9999),
      -- 6: بعد @ToDate: يجب ألا تظهر
      (6, '2026-09-01', 7, @A1, @K1, 50, 0), (6, '2026-09-01', 7, @B, @K0, 0, 50);

    /* ---------- 3) جداول الحالات ---------- */
    -- كشوف الحساب (AS) ومراكز التكلفة (CS)
    CREATE TABLE #SC (Rid INT IDENTITY(1,1), Kind CHAR(2), CaseNo INT, ObjID BIGINT, FilterID BIGINT,
                      c1 BIGINT NULL, c2 BIGINT NULL, Dbt BIT, Crd BIT);
    INSERT #SC (Kind, CaseNo, ObjID, FilterID, c1, c2, Dbt, Crd) VALUES
      ('AS', 1, @A1, 0,   NULL, NULL, 0, 0),
      ('AS', 2, @A1, @K1, @K1,  @K1,  0, 0),
      ('AS', 3, @A1, @KP, @K1,  @K2,  0, 0),     -- فلتر مركز أب = مجموع ابنيه
      ('AS', 4, @A1, 0,   NULL, NULL, 1, 0),
      ('AS', 5, @A2, 0,   NULL, NULL, 0, 1),
      ('AS', 6, @A2, @K2, @K2,  @K2,  0, 0),
      ('CS', 1, @K1, 0,   NULL, NULL, 0, 0),
      ('CS', 2, @K1, @A1, @A1,  @A1,  0, 0),
      ('CS', 3, @K2, @PA, @A1,  @A2,  0, 0),     -- فلتر حساب أب = مجموع ابنيه
      ('CS', 4, @K1, 0,   NULL, NULL, 1, 0),
      ('CS', 5, @K2, 0,   NULL, NULL, 0, 1),
      ('CS', 6, @K0, 0,   NULL, NULL, 0, 0),
      ('CS', 7, @K0, @PA, @A1,  @A2,  0, 0);     -- لا حركة متوقعة

    -- التحليل: AA تحليل حساب (الأب @PA) ، CA تحليل مركز (الأب @KP)
    CREATE TABLE #AC (Kind CHAR(2), CaseNo INT, ParamID BIGINT, c1 BIGINT NULL, c2 BIGINT NULL);
    INSERT #AC VALUES
      ('AA', 1, 0,   NULL, NULL),
      ('AA', 2, @K1, @K1,  @K1),
      ('AA', 3, @KP, @K1,  @K2),
      ('CA', 1, 0,   NULL, NULL),
      ('CA', 2, @A1, @A1,  @A1),
      ('CA', 3, @PA, @A1,  @A2);

    -- جداول التقاط النتائج
    CREATE TABLE #S (RowType TINYINT, Seq INT, RowLabel NVARCHAR(MAX), DayMID BIGINT, DayMNo BIGINT, EntryNo NVARCHAR(MAX),
        DayMDate DATE, EntryDescription NVARCHAR(MAX), ItemDescription NVARCHAR(MAX), DayDNum NVARCHAR(MAX),
        CsCID BIGINT, CsCCode NVARCHAR(MAX), CsCName NVARCHAR(MAX),
        Debit DECIMAL(18,3), Credit DECIMAL(18,3), Balance DECIMAL(18,3), BalanceSide NVARCHAR(MAX),
        AccID BIGINT, AccCode NVARCHAR(MAX), AccName NVARCHAR(MAX));

    CREATE TABLE #S2 (RowType TINYINT, Seq INT, RowLabel NVARCHAR(MAX), DayMID BIGINT, DayMNo BIGINT, EntryNo NVARCHAR(MAX),
        DayMDate DATE, EntryDescription NVARCHAR(MAX), ItemDescription NVARCHAR(MAX), DayDNum NVARCHAR(MAX),
        AccID BIGINT, AccCode NVARCHAR(MAX), AccName NVARCHAR(MAX),
        Debit DECIMAL(18,3), Credit DECIMAL(18,3), Balance DECIMAL(18,3), BalanceSide NVARCHAR(MAX),
        CsCID BIGINT, CsCCode NVARCHAR(MAX), CsCName NVARCHAR(MAX));

    CREATE TABLE #Raw (Id BIGINT, Code NVARCHAR(MAX), Name NVARCHAR(MAX), Lvl INT, ParentId BIGINT, ParentName NVARCHAR(MAX), IsLeaf BIT,
        OldDebit DECIMAL(18,3), OldCredit DECIMAL(18,3), NewDebit DECIMAL(18,3), NewCredit DECIMAL(18,3),
        BalanceDebit DECIMAL(18,3), BalanceCredit DECIMAL(18,3), TotDebit DECIMAL(18,3), TotCredit DECIMAL(18,3),
        SumBlcOldDebit DECIMAL(18,3), SumBlcOldCredit DECIMAL(18,3), SumTotDebit DECIMAL(18,3), SumTotCredit DECIMAL(18,3),
        SumBlcDebit DECIMAL(18,3), SumBlcCredit DECIMAL(18,3), SumTotBlcDebit DECIMAL(18,3), SumTotBlcCredit DECIMAL(18,3));

    CREATE TABLE #Sum (Kind CHAR(2), Phase INT, CaseNo INT, Opening DECIMAL(18,3), PerDeb DECIMAL(18,3), PerCrd DECIMAL(18,3),
        Closing DECIMAL(18,3), Cnt INT, ChainBad INT, LastBal DECIMAL(18,3), TestRows INT, TestDeb DECIMAL(18,3),
        TestCrd DECIMAL(18,3), EntryBad INT);

    CREATE TABLE #An (Kind CHAR(2), Phase INT, CaseNo INT, Id BIGINT, ParentId BIGINT, IsLeaf BIT, Lvl INT,
        OldNet DECIMAL(18,3), NewDeb DECIMAL(18,3), NewCrd DECIMAL(18,3), TotNet DECIMAL(18,3),
        HOld DECIMAL(18,3), HDeb DECIMAL(18,3), HCrd DECIMAL(18,3), HClose DECIMAL(18,3));

    /* ---------- 4) تشغيل الحالات: Phase 1 = قبل القيود ، Phase 2 = بعدها ---------- */
    DECLARE @Phase INT = 1, @rid INT, @maxRid INT = (SELECT MAX(Rid) FROM #SC),
            @k CHAR(2), @cn INT, @o BIGINT, @f BIGINT, @dbt BIT, @crd BIT,
            @open DECIMAL(18,3), @bad INT;

    WHILE @Phase <= 2
    BEGIN
        IF @Phase = 2
        BEGIN
            DECLARE @no INT = (SELECT MIN(EntryNo) FROM #Line), @m BIGINT;
            WHILE @no IS NOT NULL
            BEGIN
                INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
                SELECT TOP (1) EntryDate, N'TEST كشوف وتحليل', 93000 + @no, State, @UserId, @Cmp
                FROM #Line WHERE EntryNo = @no;

                SET @m = SCOPE_IDENTITY();

                INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDCsCID, DayDDescription)
                SELECT @m, AccID, Deb, Crd, CsC, N'TEST-RPT' FROM #Line WHERE EntryNo = @no;

                SET @no = (SELECT MIN(EntryNo) FROM #Line WHERE EntryNo > @no);
            END;
        END;

        /* --- الكشوف --- */
        SET @rid = 1;
        WHILE @rid <= @maxRid
        BEGIN
            SELECT @k = Kind, @cn = CaseNo, @o = ObjID, @f = FilterID, @dbt = Dbt, @crd = Crd FROM #SC WHERE Rid = @rid;

            IF @k = 'AS'
            BEGIN
                TRUNCATE TABLE #S;
                INSERT #S EXEC dbo.Acc_SelectAccountStatement
                     @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @AccId = @o,
                     @FromDate = @From, @ToDate = @To, @Debit = @dbt, @Credit = @crd, @CsCID = @f;

                SELECT @open = Balance FROM #S WHERE RowType = 0;
                SELECT @bad = COUNT(*)
                FROM (SELECT Balance - ISNULL(LAG(Balance) OVER (ORDER BY Seq), @open)
                              - (ISNULL(Debit, 0) - ISNULL(Credit, 0)) AS d
                      FROM #S WHERE RowType = 1) AS q
                WHERE ABS(d) > 0.0005;

                INSERT #Sum
                SELECT 'AS', @Phase, @cn,
                    (SELECT Balance FROM #S WHERE RowType = 0),
                    (SELECT Debit   FROM #S WHERE RowType = 2),
                    (SELECT Credit  FROM #S WHERE RowType = 2),
                    (SELECT Balance FROM #S WHERE RowType = 3),
                    (SELECT COUNT(*) FROM #S WHERE RowType = 1), @bad,
                    (SELECT TOP (1) Balance FROM #S WHERE RowType = 1 ORDER BY Seq DESC),
                    (SELECT COUNT(*) FROM #S WHERE RowType = 1 AND ItemDescription = N'TEST-RPT'),
                    (SELECT ISNULL(SUM(Debit), 0)  FROM #S WHERE RowType = 1 AND ItemDescription = N'TEST-RPT'),
                    (SELECT ISNULL(SUM(Credit), 0) FROM #S WHERE RowType = 1 AND ItemDescription = N'TEST-RPT'),
                    (SELECT COUNT(*) FROM #S WHERE RowType = 1
                        AND EntryNo <> CONCAT(DayMNo, N'/', RIGHT(CONCAT(N'0', MONTH(DayMDate)), 2)));
            END
            ELSE
            BEGIN
                TRUNCATE TABLE #S2;
                INSERT #S2 EXEC dbo.Acc_SelectCostCenterStatement
                     @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @CsCId = @o,
                     @FromDate = @From, @ToDate = @To, @Debit = @dbt, @Credit = @crd, @AccID = @f;

                SELECT @open = Balance FROM #S2 WHERE RowType = 0;
                SELECT @bad = COUNT(*)
                FROM (SELECT Balance - ISNULL(LAG(Balance) OVER (ORDER BY Seq), @open)
                              - (ISNULL(Debit, 0) - ISNULL(Credit, 0)) AS d
                      FROM #S2 WHERE RowType = 1) AS q
                WHERE ABS(d) > 0.0005;

                INSERT #Sum
                SELECT 'CS', @Phase, @cn,
                    (SELECT Balance FROM #S2 WHERE RowType = 0),
                    (SELECT Debit   FROM #S2 WHERE RowType = 2),
                    (SELECT Credit  FROM #S2 WHERE RowType = 2),
                    (SELECT Balance FROM #S2 WHERE RowType = 3),
                    (SELECT COUNT(*) FROM #S2 WHERE RowType = 1), @bad,
                    (SELECT TOP (1) Balance FROM #S2 WHERE RowType = 1 ORDER BY Seq DESC),
                    (SELECT COUNT(*) FROM #S2 WHERE RowType = 1 AND ItemDescription = N'TEST-RPT'),
                    (SELECT ISNULL(SUM(Debit), 0)  FROM #S2 WHERE RowType = 1 AND ItemDescription = N'TEST-RPT'),
                    (SELECT ISNULL(SUM(Credit), 0) FROM #S2 WHERE RowType = 1 AND ItemDescription = N'TEST-RPT'),
                    (SELECT COUNT(*) FROM #S2 WHERE RowType = 1
                        AND EntryNo <> CONCAT(DayMNo, N'/', RIGHT(CONCAT(N'0', MONTH(DayMDate)), 2)));
            END;

            SET @rid += 1;
        END;

        /* --- التحليل: حالات الفروق --- */
        DECLARE @ak CHAR(2), @acn INT, @ap BIGINT;
        DECLARE ac CURSOR LOCAL FAST_FORWARD FOR SELECT Kind, CaseNo, ParamID FROM #AC ORDER BY Kind, CaseNo;
        OPEN ac;
        FETCH NEXT FROM ac INTO @ak, @acn, @ap;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            TRUNCATE TABLE #Raw;

            IF @ak = 'AA'
            BEGIN
                INSERT #Raw EXEC dbo.Acc_SelectAccountAnalysis
                     @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @AccId = @PA,
                     @FromDate = @From, @ToDate = @To, @AllAcc = 0, @AllLevel = 1, @MoveAcc = 0,
                     @BalnceAcc = 0, @LevelAcc = 0, @Debit = 0, @Credit = 0, @CsCID = @ap;
            END
            ELSE
            BEGIN
                INSERT #Raw EXEC dbo.Acc_SelectCostCenterAnalysis
                     @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @CsCID = @KP,
                     @FromDate = @From, @ToDate = @To, @AllCsC = 0, @AllLevel = 1, @MoveCsC = 0,
                     @BalnceCsC = 0, @LevelCsC = 0, @Debit = 0, @Credit = 0, @AccId = @ap;
            END;

            INSERT #An
            SELECT @ak, @Phase, @acn, Id, ParentId, IsLeaf, Lvl,
                   OldDebit - OldCredit, NewDebit, NewCredit, TotDebit - TotCredit,
                   SumBlcOldDebit - SumBlcOldCredit, SumTotDebit, SumTotCredit, SumTotBlcDebit - SumTotBlcCredit
            FROM #Raw;

            FETCH NEXT FROM ac INTO @ak, @acn, @ap;
        END;
        CLOSE ac;
        DEALLOCATE ac;

        SET @Phase += 1;
    END;

    /* ---------- 5) المتوقع المحسوب مستقلًا من القيود التجريبية ---------- */
    SELECT sc.Kind, sc.CaseNo,
        ISNULL(SUM(CASE WHEN l.EntryDate < @From THEN l.Deb - l.Crd END), 0) AS eo,
        ISNULL(SUM(CASE WHEN l.EntryDate >= @From AND (sc.Dbt = 0 OR l.Deb > 0) AND (sc.Crd = 0 OR l.Crd > 0) THEN l.Deb END), 0) AS ed,
        ISNULL(SUM(CASE WHEN l.EntryDate >= @From AND (sc.Dbt = 0 OR l.Deb > 0) AND (sc.Crd = 0 OR l.Crd > 0) THEN l.Crd END), 0) AS ec,
        ISNULL(SUM(CASE WHEN l.EntryDate >= @From AND (sc.Dbt = 0 OR l.Deb > 0) AND (sc.Crd = 0 OR l.Crd > 0) THEN 1 END), 0)     AS en
    INTO #SExp
    FROM #SC AS sc
    LEFT JOIN #Line AS l
           ON l.State = 7 AND l.EntryDate <= @To
          AND (   (sc.Kind = 'AS' AND l.AccID = sc.ObjID AND (sc.c1 IS NULL OR l.CsC  IN (sc.c1, sc.c2)))
               OR (sc.Kind = 'CS' AND l.CsC   = sc.ObjID AND (sc.c1 IS NULL OR l.AccID IN (sc.c1, sc.c2))))
    GROUP BY sc.Kind, sc.CaseNo;

    SELECT ac.Kind, ac.CaseNo,
        CASE WHEN ac.Kind = 'AA' THEN v.AId ELSE v.KId END AS Id,
        ISNULL(SUM(CASE WHEN l.EntryDate <  @From THEN l.Deb - l.Crd END), 0) AS eo,
        ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN l.Deb END), 0)         AS ed,
        ISNULL(SUM(CASE WHEN l.EntryDate >= @From THEN l.Crd END), 0)         AS ec
    INTO #AnExp
    FROM #AC AS ac
    CROSS JOIN (VALUES (@A1, @K1), (@A2, @K2)) AS v(AId, KId)
    LEFT JOIN #Line AS l
           ON l.State = 7 AND l.EntryDate <= @To
          AND (   (ac.Kind = 'AA' AND l.AccID = v.AId AND (ac.c1 IS NULL OR l.CsC  IN (ac.c1, ac.c2)))
               OR (ac.Kind = 'CA' AND l.CsC   = v.KId AND (ac.c1 IS NULL OR l.AccID IN (ac.c1, ac.c2))))
    GROUP BY ac.Kind, ac.CaseNo, v.AId, v.KId;

    /* ---------- 6) مقارنة الكشوف ---------- */
    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'كشف ', CASE a.Kind WHEN 'AS' THEN N'حساب' ELSE N'مركز تكلفة' END, N' حالة ', a.CaseNo,
                  N': فرق الافتتاحي والمدين والدائن والختامي = المتوقع'),
           CASE WHEN a.Opening - b.Opening = e.eo AND a.PerDeb - b.PerDeb = e.ed
                 AND a.PerCrd - b.PerCrd = e.ec AND a.Closing - b.Closing = e.eo + e.ed - e.ec
                THEN 1 ELSE 0 END
    FROM #Sum AS a
    JOIN #Sum AS b ON b.Kind = a.Kind AND b.CaseNo = a.CaseNo AND b.Phase = 1
    JOIN #SExp AS e ON e.Kind = a.Kind AND e.CaseNo = a.CaseNo
    WHERE a.Phase = 2
    ORDER BY a.Kind DESC, a.CaseNo;

    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'كشف ', CASE a.Kind WHEN 'AS' THEN N'حساب' ELSE N'مركز تكلفة' END, N' حالة ', a.CaseNo,
                  N': صفوف القيود التجريبية الظاهرة = المتوقع (المسودة وما بعد الفترة مستبعدة)'),
           CASE WHEN a.Cnt - b.Cnt = e.en AND a.TestRows = e.en AND a.TestDeb = e.ed AND a.TestCrd = e.ec
                THEN 1 ELSE 0 END
    FROM #Sum AS a
    JOIN #Sum AS b ON b.Kind = a.Kind AND b.CaseNo = a.CaseNo AND b.Phase = 1
    JOIN #SExp AS e ON e.Kind = a.Kind AND e.CaseNo = a.CaseNo
    WHERE a.Phase = 2
    ORDER BY a.Kind DESC, a.CaseNo;

    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'كشف ', CASE a.Kind WHEN 'AS' THEN N'حساب' ELSE N'مركز تكلفة' END, N' حالة ', a.CaseNo,
                  N': الرصيد الجاري متسلسل وآخر صف = الختامي = الافتتاحي + المدين - الدائن ورقم القيد صحيح'),
           CASE WHEN a.Closing = a.Opening + a.PerDeb - a.PerCrd AND a.ChainBad = 0 AND a.EntryBad = 0
                 AND (a.Cnt = 0 OR a.LastBal = a.Closing)
                THEN 1 ELSE 0 END
    FROM #Sum AS a
    WHERE a.Phase = 2
    ORDER BY a.Kind DESC, a.CaseNo;

    /* ---------- 7) مقارنة التحليل ---------- */
    SELECT Kind, Phase, CaseNo, MAX(HOld) AS HOld, MAX(HDeb) AS HDeb, MAX(HCrd) AS HCrd, MAX(HClose) AS HClose, COUNT(*) AS Rws
    INTO #AnH
    FROM #An
    GROUP BY Kind, Phase, CaseNo;

    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'تحليل ', CASE g.Kind WHEN 'AA' THEN N'حساب' ELSE N'مركز تكلفة' END, N' حالة ', g.CaseNo,
                  N': فرق كل صف = المتوقع وبقية الصفوف بلا تغيير'),
           CASE WHEN g.Bad = 0 AND g.Missing = 0 AND ha.Rws = hb.Rws
                 AND (SELECT COUNT(*) FROM #AnExp AS e
                      WHERE e.Kind = g.Kind AND e.CaseNo = g.CaseNo
                        AND EXISTS (SELECT 1 FROM #An AS z WHERE z.Phase = 2 AND z.Kind = e.Kind AND z.CaseNo = e.CaseNo AND z.Id = e.Id)) = 2
                THEN 1 ELSE 0 END
    FROM
    (
        SELECT a.Kind, a.CaseNo,
               SUM(CASE WHEN b.Id IS NULL THEN 1 ELSE 0 END) AS Missing,
               SUM(CASE WHEN b.Id IS NOT NULL
                         AND (   a.OldNet - b.OldNet <> ISNULL(e.eo, 0)
                              OR a.NewDeb - b.NewDeb <> ISNULL(e.ed, 0)
                              OR a.NewCrd - b.NewCrd <> ISNULL(e.ec, 0)
                              OR a.TotNet - b.TotNet <> ISNULL(e.eo, 0) + ISNULL(e.ed, 0) - ISNULL(e.ec, 0))
                        THEN 1 ELSE 0 END) AS Bad
        FROM #An AS a
        LEFT JOIN #An AS b ON b.Phase = 1 AND b.Kind = a.Kind AND b.CaseNo = a.CaseNo AND b.Id = a.Id
        LEFT JOIN #AnExp AS e ON e.Kind = a.Kind AND e.CaseNo = a.CaseNo AND e.Id = a.Id
        WHERE a.Phase = 2
        GROUP BY a.Kind, a.CaseNo
    ) AS g
    JOIN #AnH AS ha ON ha.Kind = g.Kind AND ha.CaseNo = g.CaseNo AND ha.Phase = 2
    JOIN #AnH AS hb ON hb.Kind = g.Kind AND hb.CaseNo = g.CaseNo AND hb.Phase = 1
    ORDER BY g.Kind, g.CaseNo;

    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'تحليل ', CASE ha.Kind WHEN 'AA' THEN N'حساب' ELSE N'مركز تكلفة' END, N' حالة ', ha.CaseNo,
                  N': فرق ملخص الترويسة = مجموع أثر الابنين'),
           CASE WHEN ha.HOld - hb.HOld = x.so AND ha.HDeb - hb.HDeb = x.sd
                 AND ha.HCrd - hb.HCrd = x.sc AND ha.HClose - hb.HClose = x.so + x.sd - x.sc
                THEN 1 ELSE 0 END
    FROM #AnH AS ha
    JOIN #AnH AS hb ON hb.Kind = ha.Kind AND hb.CaseNo = ha.CaseNo AND hb.Phase = 1
    JOIN (SELECT Kind, CaseNo, SUM(eo) AS so, SUM(ed) AS sd, SUM(ec) AS sc FROM #AnExp GROUP BY Kind, CaseNo) AS x
         ON x.Kind = ha.Kind AND x.CaseNo = ha.CaseNo
    WHERE ha.Phase = 2
    ORDER BY ha.Kind, ha.CaseNo;

    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'تحليل ', CASE r.Kind WHEN 'AA' THEN N'حساب' ELSE N'مركز تكلفة' END, N' حالة ', r.CaseNo,
                  N': أول + حركة = آخر لكل صف، والترويسة = مجموع الأبناء المباشرين'),
           CASE WHEN r.RowBad = 0 AND ABS(h.HOld + h.HDeb - h.HCrd - h.HClose) < 0.0005
                 AND ABS(r.ChildSum - h.HClose) < 0.0005
                THEN 1 ELSE 0 END
    FROM
    (
        SELECT Kind, CaseNo,
               SUM(CASE WHEN ABS(OldNet + NewDeb - NewCrd - TotNet) > 0.0005 THEN 1 ELSE 0 END) AS RowBad,
               SUM(CASE WHEN ParentId = CASE WHEN Kind = 'AA' THEN @PA ELSE @KP END THEN TotNet ELSE 0 END) AS ChildSum
        FROM #An
        WHERE Phase = 2
        GROUP BY Kind, CaseNo
    ) AS r
    JOIN #AnH AS h ON h.Kind = r.Kind AND h.CaseNo = r.CaseNo AND h.Phase = 2
    ORDER BY r.Kind, r.CaseNo;

    /* ---------- 8) فلاتر العرض على كامل الدليل (من الجذور) ---------- */
    CREATE TABLE #Full (Kind CHAR(2), Id BIGINT, ParentId BIGINT, IsLeaf BIT, Lvl INT,
                        NewDeb DECIMAL(18,3), NewCrd DECIMAL(18,3), TotNet DECIMAL(18,3));
    CREATE TABLE #FP (CaseNo INT, AllX BIT, AllLevel BIT, Mv BIT, Bal BIT, Lv TINYINT, Dbt BIT, Crd BIT);
    CREATE TABLE #Filt (Kind CHAR(2), CaseNo INT, Id BIGINT);

    INSERT #FP VALUES
      (1, 1, 1, 0, 0, 0, 0, 0),    -- الأوراق فقط
      (2, 0, 0, 0, 0, 0, 0, 0),    -- المستوى الأول فقط
      (3, 0, 1, 1, 0, 0, 0, 0),    -- ذات الحركة
      (4, 0, 1, 0, 1, 0, 0, 0),    -- رصيد <> 0
      (5, 0, 1, 0, 0, 0, 1, 0),    -- رصيد مدين
      (6, 0, 1, 0, 0, 0, 0, 1),    -- رصيد دائن
      (7, 0, 1, 0, 0, 2, 0, 0),    -- المستوى 2 (+ الأوراق الأقل مستوى)
      (8, 1, 1, 1, 1, 3, 0, 0);    -- مركّب

    DECLARE @fi INT = 1, @fk CHAR(2), @fc INT, @fax BIT, @fal BIT, @fmv BIT, @fbl BIT, @flv TINYINT, @fdb BIT, @fcr BIT;

    WHILE @fi <= 2
    BEGIN
        SET @fk = CASE WHEN @fi = 1 THEN 'AA' ELSE 'CA' END;

        TRUNCATE TABLE #Raw;
        IF @fk = 'AA'
        BEGIN
            INSERT #Raw EXEC dbo.Acc_SelectAccountAnalysis
                 @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @AccId = 0, @FromDate = @From, @ToDate = @To,
                 @AllAcc = 0, @AllLevel = 1, @MoveAcc = 0, @BalnceAcc = 0, @LevelAcc = 0, @Debit = 0, @Credit = 0, @CsCID = 0;
        END
        ELSE
        BEGIN
            INSERT #Raw EXEC dbo.Acc_SelectCostCenterAnalysis
                 @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @CsCID = 0, @FromDate = @From, @ToDate = @To,
                 @AllCsC = 0, @AllLevel = 1, @MoveCsC = 0, @BalnceCsC = 0, @LevelCsC = 0, @Debit = 0, @Credit = 0, @AccId = 0;
        END;

        INSERT #Full
        SELECT @fk, Id, ParentId, IsLeaf, Lvl, NewDebit, NewCredit, TotDebit - TotCredit FROM #Raw;

        DECLARE fcur CURSOR LOCAL FAST_FORWARD FOR
            SELECT CaseNo, AllX, AllLevel, Mv, Bal, Lv, Dbt, Crd FROM #FP ORDER BY CaseNo;
        OPEN fcur;
        FETCH NEXT FROM fcur INTO @fc, @fax, @fal, @fmv, @fbl, @flv, @fdb, @fcr;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            TRUNCATE TABLE #Raw;
            IF @fk = 'AA'
            BEGIN
                INSERT #Raw EXEC dbo.Acc_SelectAccountAnalysis
                     @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @AccId = 0, @FromDate = @From, @ToDate = @To,
                     @AllAcc = @fax, @AllLevel = @fal, @MoveAcc = @fmv, @BalnceAcc = @fbl, @LevelAcc = @flv,
                     @Debit = @fdb, @Credit = @fcr, @CsCID = 0;
            END
            ELSE
            BEGIN
                INSERT #Raw EXEC dbo.Acc_SelectCostCenterAnalysis
                     @Cmp = @Cmp, @UserID = @UserId, @Year = @Year, @CsCID = 0, @FromDate = @From, @ToDate = @To,
                     @AllCsC = @fax, @AllLevel = @fal, @MoveCsC = @fmv, @BalnceCsC = @fbl, @LevelCsC = @flv,
                     @Debit = @fdb, @Credit = @fcr, @AccId = 0;
            END;

            INSERT #Filt SELECT @fk, @fc, Id FROM #Raw;

            FETCH NEXT FROM fcur INTO @fc, @fax, @fal, @fmv, @fbl, @flv, @fdb, @fcr;
        END;
        CLOSE fcur;
        DEALLOCATE fcur;

        SET @fi += 1;
    END;

    SELECT p.CaseNo, f.Kind, f.Id
    INTO #FExp
    FROM #FP AS p
    JOIN #Full AS f
      ON (p.AllX = 0 OR f.IsLeaf = 1)
     AND (p.AllLevel = 1 OR ISNULL(f.ParentId, 0) = 0)
     AND (p.Lv = 0 OR f.Lvl = p.Lv OR (f.Lvl < p.Lv AND f.IsLeaf = 1))
     AND (p.Mv = 0 OR f.NewDeb + f.NewCrd > 0)
     AND (p.Bal = 0 OR f.TotNet <> 0)
     AND (p.Dbt = 0 OR f.TotNet > 0)
     AND (p.Crd = 0 OR f.TotNet < 0);

    INSERT #Res (Name, Ok)
    SELECT CONCAT(N'فلتر ', CASE k.Kind WHEN 'AA' THEN N'تحليل حساب' ELSE N'تحليل مركز تكلفة' END, N' حالة ', k.CaseNo,
                  N' (', CASE k.CaseNo WHEN 1 THEN N'الأوراق فقط' WHEN 2 THEN N'المستوى الأول' WHEN 3 THEN N'ذات حركة'
                                      WHEN 4 THEN N'رصيد<>0' WHEN 5 THEN N'مدين' WHEN 6 THEN N'دائن'
                                      WHEN 7 THEN N'مستوى 2' ELSE N'مركّب' END,
                  N'): الصفوف = المتوقع من النتيجة الكاملة'),
           CASE WHEN NOT EXISTS (SELECT Id FROM #FExp WHERE Kind = k.Kind AND CaseNo = k.CaseNo
                                 EXCEPT SELECT Id FROM #Filt WHERE Kind = k.Kind AND CaseNo = k.CaseNo)
                 AND NOT EXISTS (SELECT Id FROM #Filt WHERE Kind = k.Kind AND CaseNo = k.CaseNo
                                 EXCEPT SELECT Id FROM #FExp WHERE Kind = k.Kind AND CaseNo = k.CaseNo)
                THEN 1 ELSE 0 END
    FROM (SELECT DISTINCT Kind, CaseNo FROM #Filt) AS k
    ORDER BY k.Kind, k.CaseNo;

    /* ---------- 9) رسائل الأخطاء ---------- */
    DECLARE @en INT;
    DECLARE @BigId BIGINT = 999999999999;

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountStatement @Cmp = @Cmp, @Year = @Year, @AccId = @PA, @FromDate = @From, @ToDate = @To; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف حساب لحساب أب = 50006', CASE WHEN @en = 50006 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountStatement @Cmp = @Cmp, @Year = @Year, @AccId = @A1, @FromDate = @From, @ToDate = @To, @Debit = 1, @Credit = 1; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف حساب مدين ودائن معًا = 50004', CASE WHEN @en = 50004 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountStatement @Cmp = @Cmp, @Year = @Year, @AccId = @A1, @FromDate = '2025-12-01', @ToDate = '2026-01-31'; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف حساب فترة خارج السنة = 50003', CASE WHEN @en = 50003 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountStatement @Cmp = @Cmp, @Year = @Year, @AccId = 0, @FromDate = @From, @ToDate = @To; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف حساب بلا حساب = 50001', CASE WHEN @en = 50001 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountStatement @Cmp = @Cmp, @Year = @Year, @AccId = @A1, @FromDate = @From, @ToDate = @To, @CsCID = @BigId; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف حساب بمركز غير موجود = 50007', CASE WHEN @en = 50007 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectCostCenterStatement @Cmp = @Cmp, @Year = @Year, @CsCId = @KP, @FromDate = @From, @ToDate = @To; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف مركز لمركز أب = 50006', CASE WHEN @en = 50006 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectCostCenterStatement @Cmp = @Cmp, @Year = @Year, @CsCId = @K1, @FromDate = @From, @ToDate = @To, @AccID = @BigId; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: كشف مركز بحساب غير موجود = 50007', CASE WHEN @en = 50007 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountAnalysis @Cmp = @Cmp, @Year = @Year, @AccId = @PA, @FromDate = '2025-12-01', @ToDate = '2026-01-31'; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: تحليل حساب فترة خارج السنة = 50003', CASE WHEN @en = 50003 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectAccountAnalysis @Cmp = @Cmp, @Year = @Year, @AccId = @PA, @FromDate = @From, @ToDate = @To, @CsCID = @BigId; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: تحليل حساب بمركز غير موجود = 50007', CASE WHEN @en = 50007 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = @Cmp, @Year = @Year, @CsCID = @KP, @FromDate = @From, @ToDate = @To, @AccId = @BigId; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: تحليل مركز بحساب غير موجود = 50007', CASE WHEN @en = 50007 THEN 1 ELSE 0 END);

    SET @en = 0;
    BEGIN TRY EXEC dbo.Acc_SelectCostCenterAnalysis @Cmp = @Cmp, @Year = @Year, @CsCID = @KP, @FromDate = @From, @ToDate = @To, @Debit = 1, @Credit = 1; END TRY
    BEGIN CATCH SET @en = ERROR_NUMBER(); END CATCH;
    INSERT #Res (Name, Ok) VALUES (N'خطأ: تحليل مركز مدين ودائن معًا = 50004', CASE WHEN @en = 50004 THEN 1 ELSE 0 END);

    /* ---------- 10) النتيجة ثم التراجع ---------- */
    DECLARE @i INT = 1, @n INT = (SELECT MAX(N) FROM #Res), @nm NVARCHAR(300), @ok BIT,
            @Fail INT = (SELECT COUNT(*) FROM #Res WHERE Ok = 0);

    WHILE @i <= @n
    BEGIN
        SELECT @nm = Name, @ok = Ok FROM #Res WHERE N = @i;
        PRINT CONCAT(CASE WHEN @ok = 1 THEN N'PASS - ' ELSE N'FAIL - ' END, @nm);
        SET @i += 1;
    END;

    PRINT CONCAT(N'الإجمالي: ', @n, N' اختبار | فشل: ', @Fail);

    ROLLBACK;
    PRINT N'تم التراجع عن كل القيود التجريبية.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    PRINT CONCAT(N'خطأ غير متوقع: ', ERROR_NUMBER(), N' | سطر ', ERROR_LINE(), N' | ', ERROR_MESSAGE());
    THROW;
END CATCH;

/* =====================================================================
   اختبار ميزان المراجعة وتحليل الحساب ببيانات تجريبية
   ---------------------------------------------------------------------
   - يعمل كله داخل معاملة تنتهي دائمًا بـ ROLLBACK، فلا يبقى في قاعدتك أي قيد.
   - يختار خمسة حسابات تحليلية من دليل الشركة تلقائيًّا، ويُدخل قيودًا
     نعرف نتيجتها مسبقًا، ثم يقارن ما يعيده الإجراء بالمتوقع ويطبع PASS/FAIL.
   - غيّر الإعدادات الأربعة التالية فقط (إن لزم) ثم نفّذ الملف كله.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Cmp    INT    = 10;
DECLARE @Year   INT    = 2026;
DECLARE @UserId BIGINT = 1;            -- رقم مستخدم موجود في Mng_User (DayMUser غالبًا مفتاح أجنبي)
DECLARE @From   DATE   = '2026-07-01';
DECLARE @To     DATE   = '2026-12-31';

DECLARE @Fail INT = 0;

BEGIN TRY
    BEGIN TRAN;

    /* ---------- 1) اختيار خمسة حسابات تحليلية من الدليل ---------- */
    SELECT x.AccID, ROW_NUMBER() OVER (ORDER BY x.AccCode) AS rn
    INTO #Pick
    FROM (SELECT TOP (5) a.AccID, a.AccCode
          FROM dbo.Acc_Account AS a
          WHERE a.AccCompany = @Cmp
            AND ISNULL(a.AccChid, 0) = 0
            AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
          ORDER BY a.AccCode) AS x;

    IF (SELECT COUNT(*) FROM #Pick) < 5
        THROW 51001, N'لا يوجد خمسة حسابات تحليلية في هذه الشركة.', 1;

    DECLARE @A1 BIGINT = (SELECT AccID FROM #Pick WHERE rn = 1),
            @A2 BIGINT = (SELECT AccID FROM #Pick WHERE rn = 2),
            @A3 BIGINT = (SELECT AccID FROM #Pick WHERE rn = 3),
            @A4 BIGINT = (SELECT AccID FROM #Pick WHERE rn = 4),
            @A5 BIGINT = (SELECT AccID FROM #Pick WHERE rn = 5);

    /* ---------- 2) قيود تجريبية ---------- */
    DECLARE @m BIGINT;

    -- E1: السنة السابقة (مرحّل) → يدخل في رصيد أول المدة
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2025-12-15', N'TEST E1 سنة سابقة', 90001, 7, @UserId, @Cmp);
    SET @m = SCOPE_IDENTITY();
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
    VALUES (@m, @A1, 1000.000, 0, N'TEST'), (@m, @A2, 0, 1000.000, N'TEST');

    -- E2: قبل بداية الفترة (مرحّل) → أول المدة
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2026-03-10', N'TEST E2 قبل الفترة', 90002, 7, @UserId, @Cmp);
    SET @m = SCOPE_IDENTITY();
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
    VALUES (@m, @A3, 500.250, 0, N'TEST'), (@m, @A1, 0, 500.250, N'TEST');

    -- E3: داخل الفترة (مرحّل)
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2026-07-05', N'TEST E3 داخل الفترة', 90003, 7, @UserId, @Cmp);
    SET @m = SCOPE_IDENTITY();
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
    VALUES (@m, @A1, 200.000, 0, N'TEST'), (@m, @A2, 300.000, 0, N'TEST'), (@m, @A4, 0, 500.000, N'TEST');

    -- E4: داخل الفترة (مرحّل)
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2026-09-20', N'TEST E4 داخل الفترة', 90004, 7, @UserId, @Cmp);
    SET @m = SCOPE_IDENTITY();
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
    VALUES (@m, @A4, 120.500, 0, N'TEST'), (@m, @A5, 0, 120.500, N'TEST');

    -- E5: مسودة (حالة 0) داخل الفترة → يجب ألا يظهر أبدًا
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2026-08-01', N'TEST E5 مسودة', 90005, 0, @UserId, @Cmp);
    SET @m = SCOPE_IDENTITY();
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
    VALUES (@m, @A1, 9999.000, 0, N'TEST'), (@m, @A2, 0, 9999.000, N'TEST');

    -- E6: بعد نهاية الفترة (مرحّل) → يجب ألا يظهر
    INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
    VALUES ('2027-01-10', N'TEST E6 بعد الفترة', 90006, 7, @UserId, @Cmp);
    SET @m = SCOPE_IDENTITY();
    INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDDescription)
    VALUES (@m, @A1, 7777.000, 0, N'TEST'), (@m, @A2, 0, 7777.000, N'TEST');

    /* ---------- 3) المتوقع لكل حساب تحليلي (للفترة 2026-07-01 → 2026-12-31) ---------- */
    CREATE TABLE #Exp (AccID BIGINT, OpenNet DECIMAL(18,3), PerDeb DECIMAL(18,3), PerCrd DECIMAL(18,3), PerCnt INT);
    INSERT #Exp VALUES
        (@A1,  499.750, 200.000,   0.000, 1),   -- 1000 - 500.25 | +200
        (@A2, -1000.000, 300.000,  0.000, 1),
        (@A3,  500.250,   0.000,   0.000, 0),
        (@A4,    0.000, 120.500, 500.000, 2),
        (@A5,    0.000,   0.000, 120.500, 1);

    -- (الحساب ← أحفاده بما فيهم نفسه) لكل دليل الشركة، لحساب المتوقع للآباء
    ;WITH Cl AS
    (
        SELECT a.AccID AS NodeID, a.AccID AS DescID
        FROM dbo.Acc_Account AS a
        WHERE a.AccCompany = @Cmp
        UNION ALL
        SELECT c.NodeID, k.AccID
        FROM Cl AS c
        JOIN dbo.Acc_Account AS k ON k.AccParentID = c.DescID AND k.AccCompany = @Cmp
    )
    SELECT NodeID, DescID INTO #XCl FROM Cl OPTION (MAXRECURSION 1000);

    SELECT c.NodeID AS AccID,
           CAST(ISNULL(SUM(e.OpenNet), 0) AS DECIMAL(18,3)) AS OpenNet,
           CAST(ISNULL(SUM(e.PerDeb ), 0) AS DECIMAL(18,3)) AS PerDeb,
           CAST(ISNULL(SUM(e.PerCrd ), 0) AS DECIMAL(18,3)) AS PerCrd,
           CAST(ISNULL(SUM(e.PerCnt ), 0) AS INT)           AS PerCnt
    INTO #ExpNode
    FROM #XCl AS c
    LEFT JOIN #Exp AS e ON e.AccID = c.DescID
    GROUP BY c.NodeID;

    /* ---------- 4) ميزان المراجعة ---------- */
    CREATE TABLE #TB
    (
        AccID BIGINT, AccCode NVARCHAR(60), AccARName NVARCHAR(500), AccLevel INT,
        AccParint BIGINT NULL, AccParintName NVARCHAR(500) NULL, AccCountChid INT,
        OldDebit DECIMAL(18,3), OldCredit DECIMAL(18,3),
        NewDebit DECIMAL(18,3), NewCredit DECIMAL(18,3),
        BalanceDebit DECIMAL(18,3), BalanceCredit DECIMAL(18,3),
        TotBlcDebit DECIMAL(18,3), TotBlcCredit DECIMAL(18,3),
        SumBlcOldDebit DECIMAL(18,3), SumBlcOldCredit DECIMAL(18,3),
        SumTotDebit DECIMAL(18,3), SumTotCredit DECIMAL(18,3),
        SumBlcDebit DECIMAL(18,3), SumBlcCredit DECIMAL(18,3),
        SumTotBlcDebit DECIMAL(18,3), SumTotBlcCredit DECIMAL(18,3),
        ChkOpenDiff DECIMAL(18,3), ChkPeriodDiff DECIMAL(18,3), ChkCloseDiff DECIMAL(18,3),
        ChkNonLeafAccounts INT, ChkOrphanAccounts INT, ChkCrossCompanyParents INT,
        ChkForeignAccounts INT, ChkChidMismatch INT
    );
    SELECT * INTO #TB2 FROM #TB WHERE 1 = 0;

    INSERT #TB
    EXEC dbo.Acc_Select_Trial_Balance @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year;

    DECLARE @Rows INT = (SELECT COUNT(*) FROM #TB);
    DECLARE @AccRows INT = (SELECT COUNT(*) FROM #ExpNode);

    -- T1: عدد الصفوف = عدد حسابات الدليل
    IF @Rows = @AccRows PRINT N'PASS T1: عدد الصفوف = عدد حسابات الدليل';
    ELSE BEGIN PRINT N'FAIL T1: عدد الصفوف لا يطابق الدليل'; SET @Fail += 1; END;

    -- T2: كل صف (حتى الآباء) يطابق المتوقع: أول المدة، المجاميع، آخر المدة
    SELECT t.AccCode, t.AccARName,
           e.OpenNet AS ExpOpen, t.OldDebit - t.OldCredit AS ActOpen,
           e.PerDeb  AS ExpPerDeb, t.NewDebit  AS ActPerDeb,
           e.PerCrd  AS ExpPerCrd, t.NewCredit AS ActPerCrd,
           e.OpenNet + e.PerDeb - e.PerCrd AS ExpClose, t.TotBlcDebit - t.TotBlcCredit AS ActClose
    INTO #Bad2
    FROM #TB AS t
    JOIN #ExpNode AS e ON e.AccID = t.AccID
    WHERE (t.OldDebit - t.OldCredit) <> e.OpenNet
       OR t.NewDebit  <> e.PerDeb
       OR t.NewCredit <> e.PerCrd
       OR (t.TotBlcDebit - t.TotBlcCredit) <> e.OpenNet + e.PerDeb - e.PerCrd;

    IF NOT EXISTS (SELECT 1 FROM #Bad2) PRINT N'PASS T2: كل الحسابات (التحليلية والآباء) تطابق المتوقع';
    ELSE BEGIN PRINT N'FAIL T2: اختلافات في الأرقام'; SELECT TOP 30 * FROM #Bad2; SET @Fail += 1; END;

    -- T3: الإجماليات
    IF EXISTS (SELECT 1 FROM (SELECT TOP 1 * FROM #TB) AS t
               WHERE t.SumBlcOldDebit = 1000.000 AND t.SumBlcOldCredit = 1000.000
                 AND t.SumTotDebit = 620.500     AND t.SumTotCredit = 620.500
                 AND t.SumBlcDebit = 500.000     AND t.SumBlcCredit = 500.000
                 AND t.SumTotBlcDebit = 1200.000 AND t.SumTotBlcCredit = 1200.000)
        PRINT N'PASS T3: إجماليات الميزان مطابقة (1000 / 620.5 / 500 / 1200)';
    ELSE BEGIN PRINT N'FAIL T3: إجماليات الميزان لا تطابق المتوقع'; SELECT TOP 1 * FROM #TB; SET @Fail += 1; END;

    -- T4: فحوص الإجراء الذاتية أصفار
    IF EXISTS (SELECT 1 FROM #TB WHERE ChkOpenDiff <> 0 OR ChkPeriodDiff <> 0 OR ChkCloseDiff <> 0
                                   OR ChkNonLeafAccounts <> 0 OR ChkOrphanAccounts <> 0
                                   OR ChkCrossCompanyParents <> 0 OR ChkForeignAccounts <> 0 OR ChkChidMismatch <> 0)
    BEGIN PRINT N'FAIL T4: فحوص الإجراء الذاتية ليست أصفارًا'; SELECT TOP 1 ChkOpenDiff, ChkPeriodDiff, ChkCloseDiff,
           ChkNonLeafAccounts, ChkOrphanAccounts, ChkCrossCompanyParents, ChkForeignAccounts, ChkChidMismatch FROM #TB; SET @Fail += 1; END
    ELSE PRINT N'PASS T4: فحوص الإجراء الذاتية كلها أصفار';

    -- T5: @BalnceAcc = 1
    INSERT #TB2 EXEC dbo.Acc_Select_Trial_Balance @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year, @BalnceAcc = 1;
    DECLARE @N5 INT = (SELECT COUNT(*) FROM #TB2);
    DECLARE @E5 INT = (SELECT COUNT(*) FROM #ExpNode WHERE OpenNet + PerDeb - PerCrd <> 0);
    IF @N5 = @E5 PRINT N'PASS T5: @BalnceAcc = 1 يعرض الحسابات ذات الرصيد فقط';
    ELSE BEGIN PRINT N'FAIL T5: @BalnceAcc = 1 عدد الصفوف لا يطابق'; SET @Fail += 1; END;
    DELETE #TB2;

    -- T6: @MoveAcc = 1
    INSERT #TB2 EXEC dbo.Acc_Select_Trial_Balance @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year, @MoveAcc = 1;
    DECLARE @N6 INT = (SELECT COUNT(*) FROM #TB2);
    DECLARE @E6 INT = (SELECT COUNT(*) FROM #ExpNode WHERE PerCnt > 0);
    IF @N6 = @E6 PRINT N'PASS T6: @MoveAcc = 1 يعرض الحسابات ذات الحركة فقط (A3 بلا حركة في الفترة فلا يظهر)';
    ELSE BEGIN PRINT N'FAIL T6: @MoveAcc = 1 عدد الصفوف لا يطابق'; SET @Fail += 1; END;
    DELETE #TB2;

    -- T7: @AllAcc = 1 (التحليلية فقط)
    INSERT #TB2 EXEC dbo.Acc_Select_Trial_Balance @FromDate = @From, @ToDate = @To, @Cmp = @Cmp, @Year = @Year, @AllAcc = 1;
    DECLARE @N7 INT = (SELECT COUNT(*) FROM #TB2);
    DECLARE @E7 INT = (SELECT COUNT(*) FROM dbo.Acc_Account AS a
                       WHERE a.AccCompany = @Cmp
                         AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID));
    IF @N7 = @E7 PRINT N'PASS T7: @AllAcc = 1 يعرض الحسابات التحليلية فقط';
    ELSE BEGIN PRINT N'FAIL T7: @AllAcc = 1 عدد الصفوف لا يطابق'; SET @Fail += 1; END;
    DELETE #TB2;

    /* ---------- 5) تحليل الحساب على أب الحساب الأول (للتأكد من التجميع نحو الأب) ---------- */
    BEGIN TRY
        DECLARE @P1 BIGINT = (SELECT AccParentID FROM dbo.Acc_Account WHERE AccID = @A1);

        CREATE TABLE #AN
        (
            AccID BIGINT, AccCode NVARCHAR(60), AccName NVARCHAR(500), AccLevel INT,
            AccParentID BIGINT NULL, AccParentName NVARCHAR(500) NULL, IsLeaf BIT,
            OldDebit DECIMAL(18,3), OldCredit DECIMAL(18,3),
            NewDebit DECIMAL(18,3), NewCredit DECIMAL(18,3),
            BalanceDebit DECIMAL(18,3), BalanceCredit DECIMAL(18,3),
            TotDebit DECIMAL(18,3), TotCredit DECIMAL(18,3),
            SumBlcOldDebit DECIMAL(18,3), SumBlcOldCredit DECIMAL(18,3),
            SumTotDebit DECIMAL(18,3), SumTotCredit DECIMAL(18,3),
            SumBlcDebit DECIMAL(18,3), SumBlcCredit DECIMAL(18,3),
            SumTotBlcDebit DECIMAL(18,3), SumTotBlcCredit DECIMAL(18,3)
        );

        INSERT #AN
        EXEC dbo.Acc_SelectAccountAnalysis @Cmp = @Cmp, @Year = @Year, @AccId = @P1,
             @FromDate = @From, @ToDate = @To, @AllLevel = 1, @BalnceAcc = 0;

        DECLARE @EO DECIMAL(18,3), @ED DECIMAL(18,3), @EC DECIMAL(18,3);
        SELECT @EO = OpenNet, @ED = PerDeb, @EC = PerCrd FROM #ExpNode WHERE AccID = @P1;

        -- ترويسة تحليل الحساب = رصيد الأب المتوقع (أول المدة والحركة بالأرصدة وآخر المدة)
        IF EXISTS (SELECT 1 FROM (SELECT TOP 1 * FROM #AN) AS a
                   WHERE (a.SumBlcOldDebit - a.SumBlcOldCredit) = @EO
                     AND a.SumTotDebit = @ED AND a.SumTotCredit = @EC
                     AND (a.SumTotBlcDebit - a.SumTotBlcCredit) = @EO + @ED - @EC)
            PRINT N'PASS T8: ترويسة تحليل الحساب تطابق رصيد الأب المتوقع';
        ELSE BEGIN PRINT N'FAIL T8: ترويسة تحليل الحساب لا تطابق'; SELECT TOP 1 * FROM #AN; SET @Fail += 1; END;
    END TRY
    BEGIN CATCH
        PRINT N'WARN T8: تعذّر تشغيل تحليل الحساب: ' + ERROR_MESSAGE();
    END CATCH;

    /* ---------- 6) النتيجة ---------- */
    IF @Fail = 0 PRINT N'==== كل الاختبارات نجحت ====';
    ELSE PRINT N'==== توجد اختبارات فاشلة (انظر FAIL أعلاه) ====';

    ROLLBACK TRAN;
    PRINT N'تم التراجع عن كل القيود التجريبية (ROLLBACK).';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    PRINT N'خطأ أثناء الاختبار (تم التراجع عن كل شيء): ' + ERROR_MESSAGE();
END CATCH;

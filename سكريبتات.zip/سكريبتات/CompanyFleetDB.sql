
/*
=========================================================
 Fleet & Heavy Equipment Management
 SQL Server - Private Company
=========================================================
Vehicles + Heavy Equipment + Drivers/Operators
Movements + Work Orders + Fuel + Maintenance + Spare Parts
Documents + Accidents + Expenses + Meter Readings
=========================================================
*/

IF DB_ID(N'CompanyFleetDB') IS NULL
    CREATE DATABASE CompanyFleetDB;
GO

USE CompanyFleetDB;
GO

/* =========================
   COMPANY / ORGANIZATION
   ========================= */

IF OBJECT_ID('dbo.Departments','U') IS NULL
CREATE TABLE dbo.Departments
(
    DepartmentID INT IDENTITY PRIMARY KEY,
    DepartmentCode NVARCHAR(30) NOT NULL UNIQUE,
    DepartmentName NVARCHAR(150) NOT NULL UNIQUE,
    IsActive BIT NOT NULL DEFAULT 1,
    Notes NVARCHAR(500) NULL
);
GO

IF OBJECT_ID('dbo.Locations','U') IS NULL
CREATE TABLE dbo.Locations
(
    LocationID INT IDENTITY PRIMARY KEY,
    LocationCode NVARCHAR(30) NOT NULL UNIQUE,
    LocationName NVARCHAR(150) NOT NULL,
    Address NVARCHAR(300) NULL,
    IsActive BIT NOT NULL DEFAULT 1
);
GO

/* =========================
   TYPES
   ========================= */

IF OBJECT_ID('dbo.AssetCategories','U') IS NULL
CREATE TABLE dbo.AssetCategories
(
    AssetCategoryID INT IDENTITY PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL UNIQUE,
    CategoryKind NVARCHAR(30) NOT NULL,
    IsHeavyEquipment BIT NOT NULL DEFAULT 0,
    CONSTRAINT CK_AssetCategories_Kind
        CHECK (CategoryKind IN (N'سيارة',N'شاحنة',N'معدات ثقيلة',N'معدة خفيفة',N'مقطورة',N'أخرى'))
);
GO

IF OBJECT_ID('dbo.FuelTypes','U') IS NULL
CREATE TABLE dbo.FuelTypes
(
    FuelTypeID INT IDENTITY PRIMARY KEY,
    FuelName NVARCHAR(50) NOT NULL UNIQUE,
    IsActive BIT NOT NULL DEFAULT 1
);
GO

IF OBJECT_ID('dbo.MaintenanceTypes','U') IS NULL
CREATE TABLE dbo.MaintenanceTypes
(
    MaintenanceTypeID INT IDENTITY PRIMARY KEY,
    TypeName NVARCHAR(100) NOT NULL UNIQUE,
    IsPreventive BIT NOT NULL DEFAULT 0
);
GO

/* =========================
   EMPLOYEES / OPERATORS
   ========================= */

IF OBJECT_ID('dbo.Employees','U') IS NULL
CREATE TABLE dbo.Employees
(
    EmployeeID BIGINT IDENTITY PRIMARY KEY,
    EmployeeCode NVARCHAR(30) NOT NULL UNIQUE,
    FullName NVARCHAR(200) NOT NULL,
    NationalID NVARCHAR(50) NULL,
    Phone NVARCHAR(50) NULL,
    DepartmentID INT NULL,
    JobTitle NVARCHAR(100) NULL,
    EmploymentDate DATE NULL,
    IsDriver BIT NOT NULL DEFAULT 0,
    IsOperator BIT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Employees_Department
        FOREIGN KEY (DepartmentID) REFERENCES dbo.Departments(DepartmentID)
);
GO

IF OBJECT_ID('dbo.DriverLicenses','U') IS NULL
CREATE TABLE dbo.DriverLicenses
(
    DriverLicenseID BIGINT IDENTITY PRIMARY KEY,
    EmployeeID BIGINT NOT NULL,
    LicenseNumber NVARCHAR(50) NOT NULL,
    LicenseType NVARCHAR(50) NULL,
    IssueDate DATE NULL,
    ExpiryDate DATE NULL,
    IssuingAuthority NVARCHAR(150) NULL,
    Notes NVARCHAR(500) NULL,

    CONSTRAINT UQ_DriverLicenses_Number UNIQUE (LicenseNumber),
    CONSTRAINT FK_DriverLicenses_Employee
        FOREIGN KEY (EmployeeID) REFERENCES dbo.Employees(EmployeeID),

    CONSTRAINT CK_DriverLicenses_Dates
        CHECK (ExpiryDate IS NULL OR IssueDate IS NULL OR ExpiryDate >= IssueDate)
);
GO

/* =========================
   ASSETS
   ========================= */

IF OBJECT_ID('dbo.Assets','U') IS NULL
CREATE TABLE dbo.Assets
(
    AssetID BIGINT IDENTITY PRIMARY KEY,
    AssetCode NVARCHAR(40) NOT NULL UNIQUE,
    AssetCategoryID INT NOT NULL,

    PlateNumber NVARCHAR(30) NULL,
    Manufacturer NVARCHAR(100) NULL,
    Model NVARCHAR(100) NULL,
    ModelYear SMALLINT NULL,

    VIN NVARCHAR(100) NULL,
    EngineNumber NVARCHAR(100) NULL,
    SerialNumber NVARCHAR(100) NULL,

    FuelTypeID INT NULL,
    TankCapacity DECIMAL(12,2) NULL,

    CurrentOdometer DECIMAL(14,2) NOT NULL DEFAULT 0,
    CurrentEngineHours DECIMAL(14,2) NOT NULL DEFAULT 0,

    DepartmentID INT NULL,
    CurrentLocationID INT NULL,

    PurchaseDate DATE NULL,
    PurchasePrice DECIMAL(18,3) NULL,

    Status NVARCHAR(30) NOT NULL DEFAULT N'متاحة',
    IsActive BIT NOT NULL DEFAULT 1,

    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT UQ_Assets_Plate UNIQUE (PlateNumber),
    CONSTRAINT FK_Assets_Category
        FOREIGN KEY (AssetCategoryID) REFERENCES dbo.AssetCategories(AssetCategoryID),
    CONSTRAINT FK_Assets_Fuel
        FOREIGN KEY (FuelTypeID) REFERENCES dbo.FuelTypes(FuelTypeID),
    CONSTRAINT FK_Assets_Department
        FOREIGN KEY (DepartmentID) REFERENCES dbo.Departments(DepartmentID),
    CONSTRAINT FK_Assets_Location
        FOREIGN KEY (CurrentLocationID) REFERENCES dbo.Locations(LocationID),

    CONSTRAINT CK_Assets_Status
        CHECK (Status IN
        (N'متاحة',N'في العمل',N'خارج الخدمة',N'في الصيانة',N'مباعة',N'مفقودة')),

    CONSTRAINT CK_Assets_Meters
        CHECK (CurrentOdometer >= 0 AND CurrentEngineHours >= 0)
);
GO

/* =========================
   ATTACHMENTS / IMPLEMENTS
   ========================= */

IF OBJECT_ID('dbo.AssetAttachments','U') IS NULL
CREATE TABLE dbo.AssetAttachments
(
    AttachmentID BIGINT IDENTITY PRIMARY KEY,
    AttachmentCode NVARCHAR(40) NOT NULL UNIQUE,
    AttachmentName NVARCHAR(150) NOT NULL,
    SerialNumber NVARCHAR(100) NULL,
    AttachmentType NVARCHAR(100) NULL,
    PurchaseDate DATE NULL,
    PurchasePrice DECIMAL(18,3) NULL,
    Status NVARCHAR(30) NOT NULL DEFAULT N'متاحة',
    Notes NVARCHAR(500) NULL,

    CONSTRAINT CK_AssetAttachments_Status
        CHECK (Status IN (N'متاحة',N'مستخدمة',N'في الصيانة',N'خارج الخدمة'))
);
GO

/* =========================
   MOVEMENTS
   ========================= */

IF OBJECT_ID('dbo.AssetMovements','U') IS NULL
CREATE TABLE dbo.AssetMovements
(
    MovementID BIGINT IDENTITY PRIMARY KEY,
    MovementNumber NVARCHAR(40) NOT NULL UNIQUE,

    AssetID BIGINT NOT NULL,
    DriverOperatorID BIGINT NULL,

    FromLocationID INT NULL,
    ToLocationID INT NULL,

    ExitDateTime DATETIME2(0) NOT NULL,
    ReturnDateTime DATETIME2(0) NULL,

    Purpose NVARCHAR(500) NULL,
    Destination NVARCHAR(250) NULL,

    StartOdometer DECIMAL(14,2) NULL,
    EndOdometer DECIMAL(14,2) NULL,

    StartEngineHours DECIMAL(14,2) NULL,
    EndEngineHours DECIMAL(14,2) NULL,

    Distance AS
    (
        CASE WHEN EndOdometer IS NOT NULL
             THEN EndOdometer - StartOdometer
        END
    ) PERSISTED,

    OperatingHours AS
    (
        CASE WHEN EndEngineHours IS NOT NULL
             THEN EndEngineHours - StartEngineHours
        END
    ) PERSISTED,

    Status NVARCHAR(30) NOT NULL DEFAULT N'خارج',

    AuthorizedBy NVARCHAR(150) NULL,
    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Movements_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),
    CONSTRAINT FK_Movements_Employee
        FOREIGN KEY (DriverOperatorID) REFERENCES dbo.Employees(EmployeeID),
    CONSTRAINT FK_Movements_FromLocation
        FOREIGN KEY (FromLocationID) REFERENCES dbo.Locations(LocationID),
    CONSTRAINT FK_Movements_ToLocation
        FOREIGN KEY (ToLocationID) REFERENCES dbo.Locations(LocationID),

    CONSTRAINT CK_Movements_Status
        CHECK (Status IN (N'خارج',N'عادت',N'ملغاة')),

    CONSTRAINT CK_Movements_Dates
        CHECK (ReturnDateTime IS NULL OR ReturnDateTime >= ExitDateTime),

    CONSTRAINT CK_Movements_Odometer
        CHECK (EndOdometer IS NULL OR StartOdometer IS NULL OR EndOdometer >= StartOdometer),

    CONSTRAINT CK_Movements_Hours
        CHECK (EndEngineHours IS NULL OR StartEngineHours IS NULL OR EndEngineHours >= StartEngineHours)
);
GO

/* =========================
   WORK ORDERS
   ========================= */

IF OBJECT_ID('dbo.WorkOrders','U') IS NULL
CREATE TABLE dbo.WorkOrders
(
    WorkOrderID BIGINT IDENTITY PRIMARY KEY,
    WorkOrderNumber NVARCHAR(40) NOT NULL UNIQUE,

    AssetID BIGINT NOT NULL,
    OperatorID BIGINT NULL,
    DepartmentID INT NULL,

    WorkDate DATE NOT NULL,
    StartDateTime DATETIME2(0) NULL,
    EndDateTime DATETIME2(0) NULL,

    WorkType NVARCHAR(100) NOT NULL,
    WorkDescription NVARCHAR(1000) NULL,
    WorkLocation NVARCHAR(250) NULL,

    StartMeter DECIMAL(14,2) NULL,
    EndMeter DECIMAL(14,2) NULL,

    Quantity DECIMAL(14,3) NULL,
    Unit NVARCHAR(50) NULL,

    Status NVARCHAR(30) NOT NULL DEFAULT N'مفتوح',

    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_WorkOrders_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),
    CONSTRAINT FK_WorkOrders_Operator
        FOREIGN KEY (OperatorID) REFERENCES dbo.Employees(EmployeeID),
    CONSTRAINT FK_WorkOrders_Department
        FOREIGN KEY (DepartmentID) REFERENCES dbo.Departments(DepartmentID),

    CONSTRAINT CK_WorkOrders_Status
        CHECK (Status IN (N'مفتوح',N'قيد التنفيذ',N'منجز',N'ملغى')),

    CONSTRAINT CK_WorkOrders_Dates
        CHECK (EndDateTime IS NULL OR StartDateTime IS NULL OR EndDateTime >= StartDateTime)
);
GO

/* =========================
   FUEL
   ========================= */

IF OBJECT_ID('dbo.FuelTransactions','U') IS NULL
CREATE TABLE dbo.FuelTransactions
(
    FuelTransactionID BIGINT IDENTITY PRIMARY KEY,
    AssetID BIGINT NOT NULL,
    EmployeeID BIGINT NULL,
    FuelTypeID INT NOT NULL,

    TransactionDateTime DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    Quantity DECIMAL(12,3) NOT NULL,
    UnitPrice DECIMAL(12,3) NULL,
    TotalAmount AS
    (
        CASE WHEN UnitPrice IS NOT NULL
             THEN Quantity * UnitPrice
        END
    ) PERSISTED,

    Odometer DECIMAL(14,2) NULL,
    EngineHours DECIMAL(14,2) NULL,

    StationName NVARCHAR(200) NULL,
    InvoiceNumber NVARCHAR(100) NULL,
    Notes NVARCHAR(500) NULL,

    CONSTRAINT FK_Fuel_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),
    CONSTRAINT FK_Fuel_Employee
        FOREIGN KEY (EmployeeID) REFERENCES dbo.Employees(EmployeeID),
    CONSTRAINT FK_Fuel_Type
        FOREIGN KEY (FuelTypeID) REFERENCES dbo.FuelTypes(FuelTypeID),

    CONSTRAINT CK_Fuel_Quantity CHECK (Quantity > 0)
);
GO

/* =========================
   MAINTENANCE
   ========================= */

IF OBJECT_ID('dbo.Maintenance','U') IS NULL
CREATE TABLE dbo.Maintenance
(
    MaintenanceID BIGINT IDENTITY PRIMARY KEY,

    AssetID BIGINT NOT NULL,
    MaintenanceTypeID INT NOT NULL,

    MaintenanceNumber NVARCHAR(40) NOT NULL UNIQUE,

    StartDateTime DATETIME2(0) NOT NULL,
    EndDateTime DATETIME2(0) NULL,

    Odometer DECIMAL(14,2) NULL,
    EngineHours DECIMAL(14,2) NULL,

    WorkshopName NVARCHAR(200) NULL,
    Description NVARCHAR(1500) NULL,

    PartsCost DECIMAL(18,3) NOT NULL DEFAULT 0,
    LaborCost DECIMAL(18,3) NOT NULL DEFAULT 0,
    OtherCost DECIMAL(18,3) NOT NULL DEFAULT 0,

    TotalCost AS (PartsCost + LaborCost + OtherCost) PERSISTED,

    Status NVARCHAR(30) NOT NULL DEFAULT N'مفتوحة',

    NextMaintenanceDate DATE NULL,
    NextMaintenanceMeter DECIMAL(14,2) NULL,

    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Maintenance_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),
    CONSTRAINT FK_Maintenance_Type
        FOREIGN KEY (MaintenanceTypeID) REFERENCES dbo.MaintenanceTypes(MaintenanceTypeID),

    CONSTRAINT CK_Maintenance_Cost
        CHECK (PartsCost >= 0 AND LaborCost >= 0 AND OtherCost >= 0),

    CONSTRAINT CK_Maintenance_Status
        CHECK (Status IN (N'مفتوحة',N'منتهية',N'ملغاة'))
);
GO

/* =========================
   SPARE PARTS
   ========================= */

IF OBJECT_ID('dbo.SpareParts','U') IS NULL
CREATE TABLE dbo.SpareParts
(
    PartID BIGINT IDENTITY PRIMARY KEY,
    PartCode NVARCHAR(50) NOT NULL UNIQUE,
    PartName NVARCHAR(200) NOT NULL,
    Unit NVARCHAR(50) NULL,
    MinimumStock DECIMAL(14,3) NOT NULL DEFAULT 0,
    CurrentStock DECIMAL(14,3) NOT NULL DEFAULT 0,
    AverageCost DECIMAL(18,3) NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1
);
GO

IF OBJECT_ID('dbo.MaintenanceParts','U') IS NULL
CREATE TABLE dbo.MaintenanceParts
(
    MaintenancePartID BIGINT IDENTITY PRIMARY KEY,
    MaintenanceID BIGINT NOT NULL,
    PartID BIGINT NOT NULL,
    Quantity DECIMAL(14,3) NOT NULL,
    UnitCost DECIMAL(18,3) NOT NULL DEFAULT 0,
    TotalCost AS (Quantity * UnitCost) PERSISTED,

    CONSTRAINT FK_MaintenanceParts_Maintenance
        FOREIGN KEY (MaintenanceID) REFERENCES dbo.Maintenance(MaintenanceID),
    CONSTRAINT FK_MaintenanceParts_Part
        FOREIGN KEY (PartID) REFERENCES dbo.SpareParts(PartID),

    CONSTRAINT CK_MaintenanceParts_Qty CHECK (Quantity > 0)
);
GO

/* =========================
   ACCIDENTS
   ========================= */

IF OBJECT_ID('dbo.Accidents','U') IS NULL
CREATE TABLE dbo.Accidents
(
    AccidentID BIGINT IDENTITY PRIMARY KEY,
    AssetID BIGINT NOT NULL,
    EmployeeID BIGINT NULL,
    MovementID BIGINT NULL,

    AccidentDateTime DATETIME2(0) NOT NULL,
    Location NVARCHAR(300) NULL,
    Description NVARCHAR(2000) NOT NULL,

    OtherParty NVARCHAR(500) NULL,
    EstimatedDamage DECIMAL(18,3) NULL,
    CompanyDamage DECIMAL(18,3) NULL,

    PoliceReportNumber NVARCHAR(100) NULL,
    InsuranceClaimNumber NVARCHAR(100) NULL,

    Status NVARCHAR(30) NOT NULL DEFAULT N'مفتوح',
    Notes NVARCHAR(1000) NULL,

    CONSTRAINT FK_Accidents_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),
    CONSTRAINT FK_Accidents_Employee
        FOREIGN KEY (EmployeeID) REFERENCES dbo.Employees(EmployeeID),
    CONSTRAINT FK_Accidents_Movement
        FOREIGN KEY (MovementID) REFERENCES dbo.AssetMovements(MovementID),

    CONSTRAINT CK_Accidents_Status
        CHECK (Status IN (N'مفتوح',N'قيد المعالجة',N'مغلق'))
);
GO

/* =========================
   EXPENSES
   ========================= */

IF OBJECT_ID('dbo.AssetExpenses','U') IS NULL
CREATE TABLE dbo.AssetExpenses
(
    ExpenseID BIGINT IDENTITY PRIMARY KEY,
    AssetID BIGINT NOT NULL,
    ExpenseDate DATE NOT NULL,
    ExpenseType NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL,
    Amount DECIMAL(18,3) NOT NULL,
    SupplierName NVARCHAR(200) NULL,
    InvoiceNumber NVARCHAR(100) NULL,
    Notes NVARCHAR(500) NULL,

    CONSTRAINT FK_Expenses_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),

    CONSTRAINT CK_Expenses_Amount CHECK (Amount >= 0)
);
GO

/* =========================
   DOCUMENTS
   ========================= */

IF OBJECT_ID('dbo.AssetDocuments','U') IS NULL
CREATE TABLE dbo.AssetDocuments
(
    DocumentID BIGINT IDENTITY PRIMARY KEY,
    AssetID BIGINT NOT NULL,
    DocumentType NVARCHAR(100) NOT NULL,
    DocumentNumber NVARCHAR(100) NULL,
    IssueDate DATE NULL,
    ExpiryDate DATE NULL,
    IssuingAuthority NVARCHAR(200) NULL,
    FilePath NVARCHAR(1000) NULL,
    Notes NVARCHAR(500) NULL,

    CONSTRAINT FK_AssetDocuments_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID),

    CONSTRAINT CK_AssetDocuments_Dates
        CHECK (ExpiryDate IS NULL OR IssueDate IS NULL OR ExpiryDate >= IssueDate)
);
GO

/* =========================
   METER READINGS
   ========================= */

IF OBJECT_ID('dbo.AssetMeterReadings','U') IS NULL
CREATE TABLE dbo.AssetMeterReadings
(
    ReadingID BIGINT IDENTITY PRIMARY KEY,
    AssetID BIGINT NOT NULL,
    ReadingDateTime DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),

    Odometer DECIMAL(14,2) NULL,
    EngineHours DECIMAL(14,2) NULL,

    Source NVARCHAR(50) NOT NULL DEFAULT N'يدوي',
    Notes NVARCHAR(500) NULL,

    CONSTRAINT FK_MeterReadings_Asset
        FOREIGN KEY (AssetID) REFERENCES dbo.Assets(AssetID)
);
GO

/* =========================
   INDEXES
   ========================= */

CREATE INDEX IX_Assets_Category ON dbo.Assets(AssetCategoryID);
CREATE INDEX IX_Assets_Department ON dbo.Assets(DepartmentID);
CREATE INDEX IX_Assets_Status ON dbo.Assets(Status);

CREATE INDEX IX_Movements_Asset_Date
ON dbo.AssetMovements(AssetID, ExitDateTime);

CREATE INDEX IX_WorkOrders_Asset_Date
ON dbo.WorkOrders(AssetID, WorkDate);

CREATE INDEX IX_Fuel_Asset_Date
ON dbo.FuelTransactions(AssetID, TransactionDateTime);

CREATE INDEX IX_Maintenance_Asset_Date
ON dbo.Maintenance(AssetID, StartDateTime);

CREATE INDEX IX_Accidents_Asset_Date
ON dbo.Accidents(AssetID, AccidentDateTime);

CREATE INDEX IX_MeterReadings_Asset_Date
ON dbo.AssetMeterReadings(AssetID, ReadingDateTime);
GO

/* =========================
   INITIAL DATA
   ========================= */

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'سيارة صالون',N'سيارة',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'سيارة صالون');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'دفع رباعي',N'سيارة',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'دفع رباعي');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'شاحنة',N'شاحنة',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'شاحنة');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'قلاب',N'معدات ثقيلة',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'قلاب');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'حفارة',N'معدات ثقيلة',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'حفارة');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'لودر',N'معدات ثقيلة',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'لودر');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'رافعة',N'معدات ثقيلة',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'رافعة');

INSERT INTO dbo.AssetCategories(CategoryName,CategoryKind,IsHeavyEquipment)
SELECT N'مولد كهربائي',N'معدات ثقيلة',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.AssetCategories WHERE CategoryName=N'مولد كهربائي');
GO

INSERT INTO dbo.FuelTypes(FuelName)
SELECT N'بنزين'
WHERE NOT EXISTS (SELECT 1 FROM dbo.FuelTypes WHERE FuelName=N'بنزين');

INSERT INTO dbo.FuelTypes(FuelName)
SELECT N'ديزل'
WHERE NOT EXISTS (SELECT 1 FROM dbo.FuelTypes WHERE FuelName=N'ديزل');

GO

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'صيانة دورية',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'صيانة دورية');

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'تغيير زيت',1
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'تغيير زيت');

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'فرامل',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'فرامل');

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'كهرباء',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'كهرباء');

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'محرك',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'محرك');

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'هيدروليك',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'هيدروليك');

INSERT INTO dbo.MaintenanceTypes(TypeName,IsPreventive)
SELECT N'إطارات',0
WHERE NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes WHERE TypeName=N'إطارات');
GO

/* =========================
   VIEWS
   ========================= */

CREATE OR ALTER VIEW dbo.vw_Assets
AS
SELECT
    a.AssetID,
    a.AssetCode,
    ac.CategoryName,
    ac.CategoryKind,
    a.PlateNumber,
    a.Manufacturer,
    a.Model,
    a.ModelYear,
    a.SerialNumber,
    ft.FuelName,
    a.CurrentOdometer,
    a.CurrentEngineHours,
    d.DepartmentName,
    l.LocationName,
    a.Status,
    a.IsActive
FROM dbo.Assets a
JOIN dbo.AssetCategories ac ON ac.AssetCategoryID=a.AssetCategoryID
LEFT JOIN dbo.FuelTypes ft ON ft.FuelTypeID=a.FuelTypeID
LEFT JOIN dbo.Departments d ON d.DepartmentID=a.DepartmentID
LEFT JOIN dbo.Locations l ON l.LocationID=a.CurrentLocationID;
GO

CREATE OR ALTER VIEW dbo.vw_AssetMovements
AS
SELECT
    m.MovementID,
    m.MovementNumber,
    a.AssetCode,
    a.PlateNumber,
    e.EmployeeCode,
    e.FullName AS DriverOperator,
    fl.LocationName AS FromLocation,
    tl.LocationName AS ToLocation,
    m.ExitDateTime,
    m.ReturnDateTime,
    m.Destination,
    m.Purpose,
    m.StartOdometer,
    m.EndOdometer,
    m.Distance,
    m.StartEngineHours,
    m.EndEngineHours,
    m.OperatingHours,
    m.Status
FROM dbo.AssetMovements m
JOIN dbo.Assets a ON a.AssetID=m.AssetID
LEFT JOIN dbo.Employees e ON e.EmployeeID=m.DriverOperatorID
LEFT JOIN dbo.Locations fl ON fl.LocationID=m.FromLocationID
LEFT JOIN dbo.Locations tl ON tl.LocationID=m.ToLocationID;
GO

CREATE OR ALTER VIEW dbo.vw_AssetCosts
AS
SELECT
    a.AssetID,
    a.AssetCode,
    a.PlateNumber,

    ISNULL((
        SELECT SUM(f.TotalAmount)
        FROM dbo.FuelTransactions f
        WHERE f.AssetID=a.AssetID
    ),0) AS FuelCost,

    ISNULL((
        SELECT SUM(m.TotalCost)
        FROM dbo.Maintenance m
        WHERE m.AssetID=a.AssetID
    ),0) AS MaintenanceCost,

    ISNULL((
        SELECT SUM(e.Amount)
        FROM dbo.AssetExpenses e
        WHERE e.AssetID=a.AssetID
    ),0) AS OtherExpenses,

    ISNULL((
        SELECT SUM(f.TotalAmount)
        FROM dbo.FuelTransactions f
        WHERE f.AssetID=a.AssetID
    ),0)
    +
    ISNULL((
        SELECT SUM(m.TotalCost)
        FROM dbo.Maintenance m
        WHERE m.AssetID=a.AssetID
    ),0)
    +
    ISNULL((
        SELECT SUM(e.Amount)
        FROM dbo.AssetExpenses e
        WHERE e.AssetID=a.AssetID
    ),0) AS TotalCost

FROM dbo.Assets a;
GO

/* =========================
   PROCEDURES
   ========================= */

CREATE OR ALTER PROCEDURE dbo.usp_StartMovement
    @AssetID BIGINT,
    @EmployeeID BIGINT=NULL,
    @FromLocationID INT=NULL,
    @ToLocationID INT=NULL,
    @Destination NVARCHAR(250)=NULL,
    @Purpose NVARCHAR(500)=NULL,
    @StartOdometer DECIMAL(14,2)=NULL,
    @StartEngineHours DECIMAL(14,2)=NULL,
    @AuthorizedBy NVARCHAR(150)=NULL,
    @Notes NVARCHAR(1000)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRAN;

    DECLARE @Status NVARCHAR(30);

    SELECT @Status=Status
    FROM dbo.Assets WITH (UPDLOCK)
    WHERE AssetID=@AssetID AND IsActive=1;

    IF @Status IS NULL
        THROW 51001,N'الآلية غير موجودة أو غير فعالة.',1;

    IF @Status<>N'متاحة'
        THROW 51002,N'الآلية ليست متاحة للحركة.',1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.AssetMovements
        WHERE AssetID=@AssetID AND Status=N'خارج'
    )
        THROW 51003,N'الآلية موجودة حالياً خارج الموقع.',1;

    IF @EmployeeID IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1 FROM dbo.Employees
           WHERE EmployeeID=@EmployeeID
             AND IsActive=1
             AND (IsDriver=1 OR IsOperator=1)
       )
        THROW 51004,N'الموظف ليس سائقاً أو مشغلاً فعالاً.',1;

    DECLARE @No BIGINT =
        ISNULL((SELECT MAX(MovementID)+1 FROM dbo.AssetMovements),1);

    DECLARE @MovementNumber NVARCHAR(40)=
        N'MOV-'+CONVERT(NVARCHAR(8),GETDATE(),112)+N'-'+
        RIGHT(N'000000'+CONVERT(NVARCHAR(20),@No),6);

    INSERT dbo.AssetMovements
    (
        MovementNumber,AssetID,DriverOperatorID,
        FromLocationID,ToLocationID,
        ExitDateTime,Destination,Purpose,
        StartOdometer,StartEngineHours,
        Status,AuthorizedBy,Notes
    )
    VALUES
    (
        @MovementNumber,@AssetID,@EmployeeID,
        @FromLocationID,@ToLocationID,
        SYSDATETIME(),@Destination,@Purpose,
        @StartOdometer,@StartEngineHours,
        N'خارج',@AuthorizedBy,@Notes
    );

    UPDATE dbo.Assets
    SET Status=N'في العمل',
        CurrentOdometer=ISNULL(@StartOdometer,CurrentOdometer),
        CurrentEngineHours=ISNULL(@StartEngineHours,CurrentEngineHours),
        CurrentLocationID=ISNULL(@ToLocationID,CurrentLocationID)
    WHERE AssetID=@AssetID;

    SELECT CAST(SCOPE_IDENTITY() AS BIGINT) MovementID,@MovementNumber MovementNumber;

    COMMIT;
END
GO

CREATE OR ALTER PROCEDURE dbo.usp_ReturnMovement
    @MovementID BIGINT,
    @EndOdometer DECIMAL(14,2)=NULL,
    @EndEngineHours DECIMAL(14,2)=NULL,
    @ReturnLocationID INT=NULL,
    @Notes NVARCHAR(1000)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRAN;

    DECLARE
        @AssetID BIGINT,
        @StartOdometer DECIMAL(14,2),
        @StartHours DECIMAL(14,2),
        @Status NVARCHAR(30);

    SELECT
        @AssetID=AssetID,
        @StartOdometer=StartOdometer,
        @StartHours=StartEngineHours,
        @Status=Status
    FROM dbo.AssetMovements WITH (UPDLOCK)
    WHERE MovementID=@MovementID;

    IF @AssetID IS NULL
        THROW 51010,N'الحركة غير موجودة.',1;

    IF @Status<>N'خارج'
        THROW 51011,N'الحركة ليست في حالة خروج.',1;

    IF @EndOdometer IS NOT NULL
       AND @StartOdometer IS NOT NULL
       AND @EndOdometer<@StartOdometer
        THROW 51012,N'عداد العودة أقل من عداد الخروج.',1;

    IF @EndEngineHours IS NOT NULL
       AND @StartHours IS NOT NULL
       AND @EndEngineHours<@StartHours
        THROW 51013,N'ساعات التشغيل عند العودة أقل من البداية.',1;

    UPDATE dbo.AssetMovements
    SET ReturnDateTime=SYSDATETIME(),
        EndOdometer=@EndOdometer,
        EndEngineHours=@EndEngineHours,
        Status=N'عادت',
        Notes=COALESCE(@Notes,Notes)
    WHERE MovementID=@MovementID;

    UPDATE dbo.Assets
    SET Status=N'متاحة',
        CurrentOdometer=ISNULL(@EndOdometer,CurrentOdometer),
        CurrentEngineHours=ISNULL(@EndEngineHours,CurrentEngineHours),
        CurrentLocationID=ISNULL(@ReturnLocationID,CurrentLocationID)
    WHERE AssetID=@AssetID;

    COMMIT;
END
GO

PRINT N'تم إنشاء CompanyFleetDB بنجاح.';
GO

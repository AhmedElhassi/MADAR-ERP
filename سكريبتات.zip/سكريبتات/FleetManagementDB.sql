
/*
    Fleet Management Database - Private Company
    SQL Server 2019+ / 2022 / 2025
    Arabic/English friendly schema
*/

IF DB_ID(N'FleetManagementDB') IS NULL
BEGIN
    CREATE DATABASE FleetManagementDB;
END
GO

USE FleetManagementDB;
GO

/* =========================
   1. Master Tables
   ========================= */

IF OBJECT_ID(N'dbo.Departments', N'U') IS NULL
CREATE TABLE dbo.Departments
(
    DepartmentID INT IDENTITY(1,1) CONSTRAINT PK_Departments PRIMARY KEY,
    DepartmentCode NVARCHAR(30) NOT NULL,
    DepartmentName NVARCHAR(150) NOT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_Departments_IsActive DEFAULT (1),
    Notes NVARCHAR(500) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Departments_CreatedAt DEFAULT SYSDATETIME(),
    CONSTRAINT UQ_Departments_Code UNIQUE (DepartmentCode),
    CONSTRAINT UQ_Departments_Name UNIQUE (DepartmentName)
);
GO

IF OBJECT_ID(N'dbo.VehicleTypes', N'U') IS NULL
CREATE TABLE dbo.VehicleTypes
(
    VehicleTypeID INT IDENTITY(1,1) CONSTRAINT PK_VehicleTypes PRIMARY KEY,
    TypeName NVARCHAR(100) NOT NULL,
    IsHeavyEquipment BIT NOT NULL CONSTRAINT DF_VehicleTypes_IsHeavyEquipment DEFAULT (0),
    IsActive BIT NOT NULL CONSTRAINT DF_VehicleTypes_IsActive DEFAULT (1),
    CONSTRAINT UQ_VehicleTypes_Name UNIQUE (TypeName)
);
GO

IF OBJECT_ID(N'dbo.FuelTypes', N'U') IS NULL
CREATE TABLE dbo.FuelTypes
(
    FuelTypeID INT IDENTITY(1,1) CONSTRAINT PK_FuelTypes PRIMARY KEY,
    FuelName NVARCHAR(50) NOT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_FuelTypes_IsActive DEFAULT (1),
    CONSTRAINT UQ_FuelTypes_Name UNIQUE (FuelName)
);
GO

IF OBJECT_ID(N'dbo.Drivers', N'U') IS NULL
CREATE TABLE dbo.Drivers
(
    DriverID BIGINT IDENTITY(1,1) CONSTRAINT PK_Drivers PRIMARY KEY,
    DriverCode NVARCHAR(30) NOT NULL,
    FullName NVARCHAR(200) NOT NULL,
    NationalID NVARCHAR(50) NULL,
    Phone NVARCHAR(50) NULL,
    LicenseNumber NVARCHAR(50) NULL,
    LicenseType NVARCHAR(50) NULL,
    LicenseExpiryDate DATE NULL,
    DepartmentID INT NULL,
    EmploymentDate DATE NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_Drivers_IsActive DEFAULT (1),
    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Drivers_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT UQ_Drivers_Code UNIQUE (DriverCode),
    CONSTRAINT FK_Drivers_Department
        FOREIGN KEY (DepartmentID) REFERENCES dbo.Departments(DepartmentID)
);
GO

IF OBJECT_ID(N'dbo.Vehicles', N'U') IS NULL
CREATE TABLE dbo.Vehicles
(
    VehicleID BIGINT IDENTITY(1,1) CONSTRAINT PK_Vehicles PRIMARY KEY,
    VehicleCode NVARCHAR(30) NOT NULL,
    PlateNumber NVARCHAR(30) NOT NULL,
    VehicleTypeID INT NOT NULL,
    DepartmentID INT NULL,

    Manufacturer NVARCHAR(100) NULL,
    Model NVARCHAR(100) NULL,
    ModelYear SMALLINT NULL,
    Color NVARCHAR(50) NULL,

    VIN NVARCHAR(100) NULL,
    EngineNumber NVARCHAR(100) NULL,

    FuelTypeID INT NULL,
    TankCapacity DECIMAL(10,2) NULL,

    CurrentOdometer DECIMAL(12,2) NOT NULL CONSTRAINT DF_Vehicles_CurrentOdometer DEFAULT (0),

    PurchaseDate DATE NULL,
    PurchasePrice DECIMAL(18,3) NULL,

    Status NVARCHAR(30) NOT NULL CONSTRAINT DF_Vehicles_Status DEFAULT (N'متاحة'),
    IsActive BIT NOT NULL CONSTRAINT DF_Vehicles_IsActive DEFAULT (1),

    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Vehicles_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT UQ_Vehicles_Code UNIQUE (VehicleCode),
    CONSTRAINT UQ_Vehicles_Plate UNIQUE (PlateNumber),

    CONSTRAINT FK_Vehicles_Type
        FOREIGN KEY (VehicleTypeID) REFERENCES dbo.VehicleTypes(VehicleTypeID),

    CONSTRAINT FK_Vehicles_Department
        FOREIGN KEY (DepartmentID) REFERENCES dbo.Departments(DepartmentID),

    CONSTRAINT FK_Vehicles_FuelType
        FOREIGN KEY (FuelTypeID) REFERENCES dbo.FuelTypes(FuelTypeID),

    CONSTRAINT CK_Vehicles_Status
        CHECK (Status IN (N'متاحة',N'خارج الخدمة',N'في الصيانة',N'مباعة',N'مفقودة')),

    CONSTRAINT CK_Vehicles_Odometer
        CHECK (CurrentOdometer >= 0)
);
GO

/* =========================
   2. Movement
   ========================= */

IF OBJECT_ID(N'dbo.VehicleMovements', N'U') IS NULL
CREATE TABLE dbo.VehicleMovements
(
    MovementID BIGINT IDENTITY(1,1) CONSTRAINT PK_VehicleMovements PRIMARY KEY,

    VehicleID BIGINT NOT NULL,
    DriverID BIGINT NOT NULL,
    DepartmentID INT NULL,

    MovementNumber NVARCHAR(40) NOT NULL,

    ExitDateTime DATETIME2(0) NOT NULL,
    ReturnDateTime DATETIME2(0) NULL,

    Destination NVARCHAR(250) NOT NULL,
    MovementPurpose NVARCHAR(500) NULL,

    StartOdometer DECIMAL(12,2) NOT NULL,
    EndOdometer DECIMAL(12,2) NULL,

    Distance AS
    (
        CASE
            WHEN EndOdometer IS NOT NULL
            THEN EndOdometer - StartOdometer
            ELSE NULL
        END
    ) PERSISTED,

    Status NVARCHAR(30) NOT NULL CONSTRAINT DF_Movements_Status DEFAULT (N'خارج'),

    AuthorizedBy NVARCHAR(150) NULL,
    Notes NVARCHAR(1000) NULL,

    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Movements_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT UQ_Movements_Number UNIQUE (MovementNumber),

    CONSTRAINT FK_Movements_Vehicle
        FOREIGN KEY (VehicleID) REFERENCES dbo.Vehicles(VehicleID),

    CONSTRAINT FK_Movements_Driver
        FOREIGN KEY (DriverID) REFERENCES dbo.Drivers(DriverID),

    CONSTRAINT FK_Movements_Department
        FOREIGN KEY (DepartmentID) REFERENCES dbo.Departments(DepartmentID),

    CONSTRAINT CK_Movements_Dates
        CHECK (ReturnDateTime IS NULL OR ReturnDateTime >= ExitDateTime),

    CONSTRAINT CK_Movements_Odometer
        CHECK (EndOdometer IS NULL OR EndOdometer >= StartOdometer),

    CONSTRAINT CK_Movements_Status
        CHECK (Status IN (N'خارج',N'عادت',N'ملغاة'))
);
GO

/* =========================
   3. Fuel
   ========================= */

IF OBJECT_ID(N'dbo.FuelTransactions', N'U') IS NULL
CREATE TABLE dbo.FuelTransactions
(
    FuelTransactionID BIGINT IDENTITY(1,1) CONSTRAINT PK_FuelTransactions PRIMARY KEY,

    VehicleID BIGINT NOT NULL,
    DriverID BIGINT NULL,
    FuelTypeID INT NOT NULL,

    TransactionDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Fuel_Date DEFAULT SYSDATETIME(),

    Quantity DECIMAL(12,3) NOT NULL,
    UnitPrice DECIMAL(12,3) NULL,

    TotalAmount AS
    (
        CASE
            WHEN UnitPrice IS NOT NULL THEN Quantity * UnitPrice
            ELSE NULL
        END
    ) PERSISTED,

    Odometer DECIMAL(12,2) NOT NULL,

    StationName NVARCHAR(200) NULL,
    InvoiceNumber NVARCHAR(100) NULL,

    Notes NVARCHAR(500) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Fuel_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Fuel_Vehicle
        FOREIGN KEY (VehicleID) REFERENCES dbo.Vehicles(VehicleID),

    CONSTRAINT FK_Fuel_Driver
        FOREIGN KEY (DriverID) REFERENCES dbo.Drivers(DriverID),

    CONSTRAINT FK_Fuel_Type
        FOREIGN KEY (FuelTypeID) REFERENCES dbo.FuelTypes(FuelTypeID),

    CONSTRAINT CK_Fuel_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_Fuel_Odometer CHECK (Odometer >= 0)
);
GO

/* =========================
   4. Maintenance
   ========================= */

IF OBJECT_ID(N'dbo.MaintenanceTypes', N'U') IS NULL
CREATE TABLE dbo.MaintenanceTypes
(
    MaintenanceTypeID INT IDENTITY(1,1) CONSTRAINT PK_MaintenanceTypes PRIMARY KEY,
    TypeName NVARCHAR(100) NOT NULL,
    CONSTRAINT UQ_MaintenanceTypes_Name UNIQUE (TypeName)
);
GO

IF OBJECT_ID(N'dbo.Maintenance', N'U') IS NULL
CREATE TABLE dbo.Maintenance
(
    MaintenanceID BIGINT IDENTITY(1,1) CONSTRAINT PK_Maintenance PRIMARY KEY,

    VehicleID BIGINT NOT NULL,
    MaintenanceTypeID INT NOT NULL,

    StartDateTime DATETIME2(0) NOT NULL,
    EndDateTime DATETIME2(0) NULL,

    Odometer DECIMAL(12,2) NOT NULL,

    WorkshopName NVARCHAR(200) NULL,
    Description NVARCHAR(1000) NULL,

    PartsCost DECIMAL(18,3) NOT NULL CONSTRAINT DF_Maintenance_PartsCost DEFAULT (0),
    LaborCost DECIMAL(18,3) NOT NULL CONSTRAINT DF_Maintenance_LaborCost DEFAULT (0),

    TotalCost AS (PartsCost + LaborCost) PERSISTED,

    Status NVARCHAR(30) NOT NULL CONSTRAINT DF_Maintenance_Status DEFAULT (N'مفتوحة'),

    NextMaintenanceDate DATE NULL,
    NextMaintenanceOdometer DECIMAL(12,2) NULL,

    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Maintenance_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Maintenance_Vehicle
        FOREIGN KEY (VehicleID) REFERENCES dbo.Vehicles(VehicleID),

    CONSTRAINT FK_Maintenance_Type
        FOREIGN KEY (MaintenanceTypeID) REFERENCES dbo.MaintenanceTypes(MaintenanceTypeID),

    CONSTRAINT CK_Maintenance_Cost
        CHECK (PartsCost >= 0 AND LaborCost >= 0),

    CONSTRAINT CK_Maintenance_Dates
        CHECK (EndDateTime IS NULL OR EndDateTime >= StartDateTime),

    CONSTRAINT CK_Maintenance_Status
        CHECK (Status IN (N'مفتوحة',N'منتهية',N'ملغاة'))
);
GO

/* =========================
   5. Accidents
   ========================= */

IF OBJECT_ID(N'dbo.Accidents', N'U') IS NULL
CREATE TABLE dbo.Accidents
(
    AccidentID BIGINT IDENTITY(1,1) CONSTRAINT PK_Accidents PRIMARY KEY,

    VehicleID BIGINT NOT NULL,
    DriverID BIGINT NULL,
    MovementID BIGINT NULL,

    AccidentDateTime DATETIME2(0) NOT NULL,
    Location NVARCHAR(300) NULL,

    Description NVARCHAR(2000) NOT NULL,
    OtherParty NVARCHAR(500) NULL,

    EstimatedDamage DECIMAL(18,3) NULL,
    CompanyDamage DECIMAL(18,3) NULL,

    PoliceReportNumber NVARCHAR(100) NULL,
    InsuranceClaimNumber NVARCHAR(100) NULL,

    Status NVARCHAR(30) NOT NULL CONSTRAINT DF_Accidents_Status DEFAULT (N'مفتوح'),

    Notes NVARCHAR(1000) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Accidents_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Accidents_Vehicle
        FOREIGN KEY (VehicleID) REFERENCES dbo.Vehicles(VehicleID),

    CONSTRAINT FK_Accidents_Driver
        FOREIGN KEY (DriverID) REFERENCES dbo.Drivers(DriverID),

    CONSTRAINT FK_Accidents_Movement
        FOREIGN KEY (MovementID) REFERENCES dbo.VehicleMovements(MovementID),

    CONSTRAINT CK_Accidents_Status
        CHECK (Status IN (N'مفتوح',N'قيد المعالجة',N'مغلق'))
);
GO

/* =========================
   6. Expenses
   ========================= */

IF OBJECT_ID(N'dbo.VehicleExpenses', N'U') IS NULL
CREATE TABLE dbo.VehicleExpenses
(
    ExpenseID BIGINT IDENTITY(1,1) CONSTRAINT PK_VehicleExpenses PRIMARY KEY,

    VehicleID BIGINT NOT NULL,
    ExpenseDate DATE NOT NULL,

    ExpenseType NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL,

    Amount DECIMAL(18,3) NOT NULL,

    InvoiceNumber NVARCHAR(100) NULL,
    SupplierName NVARCHAR(200) NULL,

    Notes NVARCHAR(500) NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Expenses_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Expenses_Vehicle
        FOREIGN KEY (VehicleID) REFERENCES dbo.Vehicles(VehicleID),

    CONSTRAINT CK_Expenses_Amount CHECK (Amount >= 0)
);
GO

/* =========================
   7. Documents
   ========================= */

IF OBJECT_ID(N'dbo.VehicleDocuments', N'U') IS NULL
CREATE TABLE dbo.VehicleDocuments
(
    DocumentID BIGINT IDENTITY(1,1) CONSTRAINT PK_VehicleDocuments PRIMARY KEY,

    VehicleID BIGINT NOT NULL,

    DocumentType NVARCHAR(100) NOT NULL,
    DocumentNumber NVARCHAR(100) NULL,

    IssueDate DATE NULL,
    ExpiryDate DATE NULL,

    IssuingAuthority NVARCHAR(200) NULL,

    FilePath NVARCHAR(1000) NULL,
    Notes NVARCHAR(500) NULL,

    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_VehicleDocuments_CreatedAt DEFAULT SYSDATETIME(),

    CONSTRAINT FK_VehicleDocuments_Vehicle
        FOREIGN KEY (VehicleID) REFERENCES dbo.Vehicles(VehicleID),

    CONSTRAINT CK_VehicleDocuments_Dates
        CHECK (ExpiryDate IS NULL OR IssueDate IS NULL OR ExpiryDate >= IssueDate)
);
GO

/* =========================
   8. Indexes
   ========================= */

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Vehicles_Department' AND object_id = OBJECT_ID(N'dbo.Vehicles'))
    CREATE INDEX IX_Vehicles_Department ON dbo.Vehicles(DepartmentID);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Vehicles_Status' AND object_id = OBJECT_ID(N'dbo.Vehicles'))
    CREATE INDEX IX_Vehicles_Status ON dbo.Vehicles(Status);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Movements_Vehicle_Date' AND object_id = OBJECT_ID(N'dbo.VehicleMovements'))
    CREATE INDEX IX_Movements_Vehicle_Date ON dbo.VehicleMovements(VehicleID, ExitDateTime);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Movements_Driver_Date' AND object_id = OBJECT_ID(N'dbo.VehicleMovements'))
    CREATE INDEX IX_Movements_Driver_Date ON dbo.VehicleMovements(DriverID, ExitDateTime);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Fuel_Vehicle_Date' AND object_id = OBJECT_ID(N'dbo.FuelTransactions'))
    CREATE INDEX IX_Fuel_Vehicle_Date ON dbo.FuelTransactions(VehicleID, TransactionDateTime);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Maintenance_Vehicle_Date' AND object_id = OBJECT_ID(N'dbo.Maintenance'))
    CREATE INDEX IX_Maintenance_Vehicle_Date ON dbo.Maintenance(VehicleID, StartDateTime);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Accidents_Vehicle_Date' AND object_id = OBJECT_ID(N'dbo.Accidents'))
    CREATE INDEX IX_Accidents_Vehicle_Date ON dbo.Accidents(VehicleID, AccidentDateTime);
GO

/* =========================
   9. Initial Data
   ========================= */

IF NOT EXISTS (SELECT 1 FROM dbo.VehicleTypes)
BEGIN
    INSERT INTO dbo.VehicleTypes(TypeName, IsHeavyEquipment)
    VALUES
    (N'سيارة صالون',0),
    (N'سيارة دفع رباعي',0),
    (N'شاحنة',1),
    (N'حافلة',1),
    (N'قلاب',1),
    (N'حفارة',1),
    (N'رافعة',1),
    (N'مولد',1);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.FuelTypes)
BEGIN
    INSERT INTO dbo.FuelTypes(FuelName)
    VALUES
    (N'بنزين'),
    (N'ديزل'),
    (N'غاز');
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.MaintenanceTypes)
BEGIN
    INSERT INTO dbo.MaintenanceTypes(TypeName)
    VALUES
    (N'دورية'),
    (N'تغيير زيت'),
    (N'إطارات'),
    (N'محرك'),
    (N'كهرباء'),
    (N'فرامل'),
    (N'تكييف'),
    (N'سمكرة ودهان'),
    (N'أخرى');
END
GO

/* =========================
   10. Views
   ========================= */

CREATE OR ALTER VIEW dbo.vw_Vehicles
AS
SELECT
    v.VehicleID,
    v.VehicleCode,
    v.PlateNumber,
    vt.TypeName AS VehicleType,
    d.DepartmentName,
    v.Manufacturer,
    v.Model,
    v.ModelYear,
    v.Color,
    ft.FuelName,
    v.CurrentOdometer,
    v.Status,
    v.IsActive
FROM dbo.Vehicles v
INNER JOIN dbo.VehicleTypes vt
    ON vt.VehicleTypeID = v.VehicleTypeID
LEFT JOIN dbo.Departments d
    ON d.DepartmentID = v.DepartmentID
LEFT JOIN dbo.FuelTypes ft
    ON ft.FuelTypeID = v.FuelTypeID;
GO

CREATE OR ALTER VIEW dbo.vw_VehicleMovements
AS
SELECT
    m.MovementID,
    m.MovementNumber,
    v.VehicleCode,
    v.PlateNumber,
    dr.DriverCode,
    dr.FullName AS DriverName,
    d.DepartmentName,
    m.ExitDateTime,
    m.ReturnDateTime,
    m.Destination,
    m.MovementPurpose,
    m.StartOdometer,
    m.EndOdometer,
    m.Distance,
    m.Status,
    m.AuthorizedBy
FROM dbo.VehicleMovements m
INNER JOIN dbo.Vehicles v ON v.VehicleID = m.VehicleID
INNER JOIN dbo.Drivers dr ON dr.DriverID = m.DriverID
LEFT JOIN dbo.Departments d ON d.DepartmentID = m.DepartmentID;
GO

CREATE OR ALTER VIEW dbo.vw_VehicleFuel
AS
SELECT
    f.FuelTransactionID,
    f.TransactionDateTime,
    v.VehicleCode,
    v.PlateNumber,
    dr.FullName AS DriverName,
    ft.FuelName,
    f.Quantity,
    f.UnitPrice,
    f.TotalAmount,
    f.Odometer,
    f.StationName,
    f.InvoiceNumber
FROM dbo.FuelTransactions f
INNER JOIN dbo.Vehicles v ON v.VehicleID = f.VehicleID
LEFT JOIN dbo.Drivers dr ON dr.DriverID = f.DriverID
INNER JOIN dbo.FuelTypes ft ON ft.FuelTypeID = f.FuelTypeID;
GO

CREATE OR ALTER VIEW dbo.vw_VehicleMaintenance
AS
SELECT
    m.MaintenanceID,
    v.VehicleCode,
    v.PlateNumber,
    mt.TypeName AS MaintenanceType,
    m.StartDateTime,
    m.EndDateTime,
    m.Odometer,
    m.WorkshopName,
    m.Description,
    m.PartsCost,
    m.LaborCost,
    m.TotalCost,
    m.Status,
    m.NextMaintenanceDate,
    m.NextMaintenanceOdometer
FROM dbo.Maintenance m
INNER JOIN dbo.Vehicles v ON v.VehicleID = m.VehicleID
INNER JOIN dbo.MaintenanceTypes mt ON mt.MaintenanceTypeID = m.MaintenanceTypeID;
GO

/* =========================
   11. Procedures
   ========================= */

CREATE OR ALTER PROCEDURE dbo.usp_StartVehicleMovement
    @VehicleID BIGINT,
    @DriverID BIGINT,
    @DepartmentID INT = NULL,
    @Destination NVARCHAR(250),
    @MovementPurpose NVARCHAR(500) = NULL,
    @StartOdometer DECIMAL(12,2),
    @AuthorizedBy NVARCHAR(150) = NULL,
    @Notes NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRAN;

    DECLARE @CurrentStatus NVARCHAR(30);
    DECLARE @CurrentOdometer DECIMAL(12,2);

    SELECT
        @CurrentStatus = Status,
        @CurrentOdometer = CurrentOdometer
    FROM dbo.Vehicles WITH (UPDLOCK, ROWLOCK)
    WHERE VehicleID = @VehicleID
      AND IsActive = 1;

    IF @CurrentStatus IS NULL
        THROW 50001, N'الآلية غير موجودة أو غير فعالة.', 1;

    IF @CurrentStatus <> N'متاحة'
        THROW 50002, N'الآلية ليست متاحة للحركة حالياً.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.VehicleMovements
        WHERE VehicleID = @VehicleID
          AND Status = N'خارج'
    )
        THROW 50003, N'الآلية مسجلة حالياً خارج الشركة.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Drivers
        WHERE DriverID = @DriverID
          AND IsActive = 1
    )
        THROW 50004, N'السائق غير موجود أو غير فعال.', 1;

    IF @StartOdometer < @CurrentOdometer
        THROW 50005, N'عداد الخروج أقل من العداد الحالي للآلية.', 1;

    DECLARE @MovementNumber NVARCHAR(40);

    SET @MovementNumber =
        N'MOV-' +
        CONVERT(NVARCHAR(8), GETDATE(), 112) +
        N'-' +
        RIGHT(N'000000' + CONVERT(NVARCHAR(20),
        ISNULL((SELECT MAX(MovementID) + 1 FROM dbo.VehicleMovements),1)),6);

    INSERT INTO dbo.VehicleMovements
    (
        VehicleID, DriverID, DepartmentID, MovementNumber,
        ExitDateTime, Destination, MovementPurpose,
        StartOdometer, Status, AuthorizedBy, Notes
    )
    VALUES
    (
        @VehicleID, @DriverID, @DepartmentID, @MovementNumber,
        SYSDATETIME(), @Destination, @MovementPurpose,
        @StartOdometer, N'خارج', @AuthorizedBy, @Notes
    );

    UPDATE dbo.Vehicles
    SET
        Status = N'خارج الخدمة',
        CurrentOdometer = @StartOdometer
    WHERE VehicleID = @VehicleID;

    SELECT
        CAST(SCOPE_IDENTITY() AS BIGINT) AS MovementID,
        @MovementNumber AS MovementNumber;

    COMMIT;
END
GO

CREATE OR ALTER PROCEDURE dbo.usp_ReturnVehicle
    @MovementID BIGINT,
    @EndOdometer DECIMAL(12,2),
    @Notes NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRAN;

    DECLARE @VehicleID BIGINT;
    DECLARE @StartOdometer DECIMAL(12,2);
    DECLARE @Status NVARCHAR(30);

    SELECT
        @VehicleID = VehicleID,
        @StartOdometer = StartOdometer,
        @Status = Status
    FROM dbo.VehicleMovements WITH (UPDLOCK, ROWLOCK)
    WHERE MovementID = @MovementID;

    IF @VehicleID IS NULL
        THROW 50010, N'سجل الحركة غير موجود.', 1;

    IF @Status <> N'خارج'
        THROW 50011, N'الحركة ليست في حالة خروج.', 1;

    IF @EndOdometer < @StartOdometer
        THROW 50012, N'عداد العودة أقل من عداد الخروج.', 1;

    UPDATE dbo.VehicleMovements
    SET
        ReturnDateTime = SYSDATETIME(),
        EndOdometer = @EndOdometer,
        Status = N'عادت',
        Notes = COALESCE(@Notes, Notes)
    WHERE MovementID = @MovementID;

    UPDATE dbo.Vehicles
    SET
        Status = N'متاحة',
        CurrentOdometer = @EndOdometer
    WHERE VehicleID = @VehicleID;

    COMMIT;
END
GO

/* =========================
   12. Reports
   ========================= */

CREATE OR ALTER VIEW dbo.vw_VehicleSummary
AS
SELECT
    v.VehicleID,
    v.VehicleCode,
    v.PlateNumber,
    v.Manufacturer,
    v.Model,
    v.CurrentOdometer,
    v.Status,

    ISNULL
    (
        (
            SELECT SUM(f.TotalAmount)
            FROM dbo.FuelTransactions f
            WHERE f.VehicleID = v.VehicleID
        ), 0
    ) AS TotalFuelCost,

    ISNULL
    (
        (
            SELECT SUM(m.TotalCost)
            FROM dbo.Maintenance m
            WHERE m.VehicleID = v.VehicleID
        ), 0
    ) AS TotalMaintenanceCost,

    ISNULL
    (
        (
            SELECT SUM(e.Amount)
            FROM dbo.VehicleExpenses e
            WHERE e.VehicleID = v.VehicleID
        ), 0
    ) AS TotalOtherExpenses,

    ISNULL
    (
        (
            SELECT COUNT_BIG(*)
            FROM dbo.VehicleMovements vm
            WHERE vm.VehicleID = v.VehicleID
        ), 0
    ) AS MovementCount

FROM dbo.Vehicles v;
GO

PRINT N'تم إنشاء قاعدة بيانات FleetManagementDB بنجاح.';
GO

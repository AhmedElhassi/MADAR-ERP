﻿/*
    MADAR Enterprise ERP
    Database tables and stored procedures
    Target: SQL Server 2025 Enterprise
    Required database: MADARERPDataBase
    Required database collation: Arabic_100_CI_AI

    Run this script ONCE against a newly created, empty MADARERPDataBase.
    It does not create the database itself.

    Notes:
    - All data CRUD/search operations are implemented as stored procedures.
    - Manual IDs are generated inside insert procedures using MAX(ID) + 1,
      with table/transaction locks to serialize concurrent inserts.
    - User passwords passed to Mng_InsertUser / Mng_UpdateUserPassword must
      already be PBKDF2-SHA256 hashes created in the C# application.
    - Company/system logos use VARBINARY(MAX), replacing the deprecated IMAGE type.
    - The separate dbo.Tafkeet scalar function is not included in this CRUD script;
      its updated currency wording is a separate database object to finalize and test.
    - SQL logins/database users and GRANT permissions are not created here because
      the deployment identity and least-privilege role assignment will be configured separately.
*/

USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF DB_NAME() <> N'MADARERPDataBase'
BEGIN
    ;THROW 51000, N'يجب تنفيذ السكربت داخل قاعدة البيانات MADARERPDataBase.', 1;
END
GO

IF CONVERT(nvarchar(128), DATABASEPROPERTYEX(DB_NAME(), 'Collation')) <> N'Arabic_100_CI_AI'
BEGIN
    ;THROW 51001, N'ترتيب قاعدة البيانات يجب أن يكون Arabic_100_CI_AI قبل تنفيذ السكربت.', 1;
END
GO

IF (SELECT compatibility_level FROM sys.databases WHERE database_id = DB_ID()) < 130
BEGIN
    ;THROW 51003, N'مستوى التوافق يجب أن يكون 130 أو أعلى لدعم STRING_SPLIT المستخدم في التحقق من القوائم.', 1;
END
GO

IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Mng_System', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Mng_SystemMenu', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Mng_User', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Mng_UserParmations', N'U') IS NOT NULL
BEGIN
    ;THROW 51002, N'توجد جداول من جداول مدار مسبقًا. هذا السكربت مخصص للتنفيذ مرة واحدة على قاعدة فارغة، وليس لترقية قاعدة موجودة.', 1;
END
GO

/* =====================================================================
   1. Mng_Company - الشركات
   ===================================================================== */
CREATE TABLE dbo.Mng_Company
(
    CmpID       int             NOT NULL,
    CmpName     nvarchar(255)   NULL,
    CmpEName    nvarchar(255)   NULL,
    CmpLogo     varbinary(max)  NULL,
    CmpState    tinyint         NULL CONSTRAINT DF_Mng_Company_CmpState DEFAULT ((0)),
    CmpDateTime datetime        NULL CONSTRAINT DF_Mng_Company_CmpDateTime DEFAULT (GETDATE()),
    CmpUser     int             NULL,
    CmpSystems  nvarchar(500)   NULL,

    CONSTRAINT PK_Mng_Company PRIMARY KEY CLUSTERED (CmpID ASC),
    CONSTRAINT CK_Mng_Company_CmpID_Positive CHECK (CmpID > 0)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/* =====================================================================
   2. Mng_System - المنظومات
   ===================================================================== */
CREATE TABLE dbo.Mng_System
(
    SysID       tinyint         NOT NULL,
    SysName     nvarchar(50)    NULL,
    SysEName    nvarchar(50)    NULL,
    SysLogo     varbinary(max)  NULL,
    SysState    tinyint         NULL CONSTRAINT DF_Mng_System_SysState DEFAULT ((0)),
    SysDateTime datetime        NULL CONSTRAINT DF_Mng_System_SysDateTime DEFAULT (GETDATE()),
    SysUser     int             NULL,
    SysMenu     nvarchar(500)   NULL,

    CONSTRAINT PK_Mng_System PRIMARY KEY CLUSTERED (SysID ASC),
    CONSTRAINT CK_Mng_System_SysID_Positive CHECK (SysID BETWEEN 1 AND 255)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/* =====================================================================
   3. Mng_SystemMenu - قوائم المنظومات
   PK: (SysMSysID, SysMID), so menu IDs may repeat in different systems.
   SysMParent = 0 indicates a top-level menu.
   ===================================================================== */
CREATE TABLE dbo.Mng_SystemMenu
(
    SysMID       tinyint         NOT NULL,
    SysMSysID    tinyint         NOT NULL,
    SysMParent   tinyint         NULL CONSTRAINT DF_Mng_SystemMenu_SysMParent DEFAULT ((0)),
    SysMName     nvarchar(50)    NULL,
    SysMEName    nvarchar(50)    NULL,
    SysMLogo     nvarchar(50)    NULL,
    SysMMap      nvarchar(50)    NULL,
    SysMState    tinyint         NULL CONSTRAINT DF_Mng_SystemMenu_SysMState DEFAULT ((0)),
    SysMDateTime datetime        NULL CONSTRAINT DF_Mng_SystemMenu_SysMDateTime DEFAULT (GETDATE()),
    SysMUser     int             NULL,

    CONSTRAINT PK_Mng_SystemMenu PRIMARY KEY CLUSTERED (SysMSysID ASC, SysMID ASC),
    CONSTRAINT CK_Mng_SystemMenu_SysMID_Positive CHECK (SysMID BETWEEN 1 AND 255),
    CONSTRAINT CK_Mng_SystemMenu_SysMParent_NotSelf CHECK (SysMParent IS NULL OR SysMParent = 0 OR SysMParent <> SysMID),
    CONSTRAINT FK_Mng_SystemMenu_Mng_System FOREIGN KEY (SysMSysID)
        REFERENCES dbo.Mng_System (SysID)
) ON [PRIMARY]
GO

CREATE INDEX IX_Mng_SystemMenu_SystemParent
    ON dbo.Mng_SystemMenu (SysMSysID, SysMParent)
GO

/* =====================================================================
   4. Mng_User - المستخدمون
   UsrLogIn is generated by Mng_InsertUser and is unique.
   UsrPassWord stores a password hash, not a reversible encrypted password.
   ===================================================================== */
CREATE TABLE dbo.Mng_User
(
    UsrID         int IDENTITY(1,1) NOT NULL,
    UsrEmployeeID bigint            NULL,
    UsrLogIn      nvarchar(50)      NOT NULL,
    UsrPassWord   nvarchar(255)     NOT NULL,
    UsrState      tinyint           NOT NULL CONSTRAINT DF_Mng_User_UsrState DEFAULT ((0)),
    UsrDateTime   datetime          NOT NULL CONSTRAINT DF_Mng_User_UsrDateTime DEFAULT (GETDATE()),
    UsrUser       int               NULL,

    CONSTRAINT PK_Mng_User PRIMARY KEY CLUSTERED (UsrID ASC),
    CONSTRAINT UQ_Mng_User_UsrLogIn UNIQUE (UsrLogIn)
) ON [PRIMARY]
GO

/* =====================================================================
   5. Mng_UserParmations - صلاحيات المستخدمين
   ===================================================================== */
CREATE TABLE dbo.Mng_UserParmations
(
    USPID         bigint IDENTITY(1,1) NOT NULL,
    USPUserID     int                 NULL,
    USPCompanyID  int                 NULL,
    USPSystemID   tinyint             NULL,
    USPParmations nvarchar(500)       NULL,
    USPState      tinyint             NULL CONSTRAINT DF_Mng_UserParmations_USPState DEFAULT ((0)),
    USPDateTime   datetime            NULL CONSTRAINT DF_Mng_UserParmations_USPDateTime DEFAULT (GETDATE()),
    USPUser       int                 NULL,

    CONSTRAINT PK_Mng_UserParmations PRIMARY KEY CLUSTERED (USPID ASC),
    CONSTRAINT FK_Mng_UserParmations_Mng_User FOREIGN KEY (USPUserID)
        REFERENCES dbo.Mng_User (UsrID),
    CONSTRAINT FK_Mng_UserParmations_Mng_Company FOREIGN KEY (USPCompanyID)
        REFERENCES dbo.Mng_Company (CmpID),
    CONSTRAINT FK_Mng_UserParmations_Mng_System FOREIGN KEY (USPSystemID)
        REFERENCES dbo.Mng_System (SysID)
) ON [PRIMARY]
GO

CREATE INDEX IX_Mng_UserParmations_UserCompanySystem
    ON dbo.Mng_UserParmations (USPUserID, USPCompanyID, USPSystemID)
GO

CREATE INDEX IX_Mng_UserParmations_CompanySystem
    ON dbo.Mng_UserParmations (USPCompanyID, USPSystemID)
GO

/* =====================================================================
   COMPANY PROCEDURES
   ===================================================================== */

CREATE OR ALTER PROCEDURE dbo.Mng_InsertCompany
    @CmpName     nvarchar(255) = NULL,
    @CmpEName    nvarchar(255) = NULL,
    @CmpLogo     varbinary(max) = NULL,
    @CmpState    tinyint = NULL,
    @CmpDateTime datetime = NULL,
    @CmpUser     int = NULL,
    @CmpSystems  nvarchar(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @CmpSystems = NULLIF(LTRIM(RTRIM(@CmpSystems)), N'');

    BEGIN TRY
        BEGIN TRANSACTION;

        /* Validate every system ID in the company's comma-separated list. */
        IF @CmpSystems IS NOT NULL AND EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(@CmpSystems, N',') ss
            CROSS APPLY (SELECT TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) AS SystemID) v
            WHERE NULLIF(LTRIM(RTRIM(ss.value)), N'') IS NULL
               OR v.SystemID IS NULL
               OR v.SystemID NOT BETWEEN 1 AND 255
               OR NOT EXISTS (SELECT 1 FROM dbo.Mng_System s WITH (UPDLOCK, HOLDLOCK) WHERE s.SysID = v.SystemID)
        )
        BEGIN
            ;THROW 51100, N'قائمة المنظومات في CmpSystems تحتوي على معرّف غير صحيح أو منظومة غير موجودة.', 1;
        END

        DECLARE @NewCmpID bigint;
        SELECT @NewCmpID = ISNULL(MAX(CONVERT(bigint, CmpID)), 0) + 1
        FROM dbo.Mng_Company WITH (TABLOCKX, HOLDLOCK);

        IF @NewCmpID > 2147483647
        BEGIN
            ;THROW 51101, N'تم بلوغ الحد الأعلى لمعرّف الشركة من نوع INT.', 1;
        END

        DECLARE @CmpID int = CONVERT(int, @NewCmpID);

        INSERT INTO dbo.Mng_Company
            (CmpID, CmpName, CmpEName, CmpLogo, CmpState, CmpDateTime, CmpUser, CmpSystems)
        VALUES
            (@CmpID, @CmpName, @CmpEName, @CmpLogo, COALESCE(@CmpState, 0), COALESCE(@CmpDateTime, GETDATE()), @CmpUser, @CmpSystems);

        COMMIT TRANSACTION;
        SELECT @CmpID AS CmpID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_UpdateCompany
    @CmpID       int,
    @CmpName     nvarchar(255),
    @CmpEName    nvarchar(255),
    @CmpLogo     varbinary(max),
    @CmpState    tinyint,
    @CmpDateTime datetime,
    @CmpUser     int,
    @CmpSystems  nvarchar(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @CmpSystems = NULLIF(LTRIM(RTRIM(@CmpSystems)), N'');

    BEGIN TRY
        BEGIN TRANSACTION;

        IF @CmpSystems IS NOT NULL AND EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(@CmpSystems, N',') ss
            CROSS APPLY (SELECT TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) AS SystemID) v
            WHERE NULLIF(LTRIM(RTRIM(ss.value)), N'') IS NULL
               OR v.SystemID IS NULL
               OR v.SystemID NOT BETWEEN 1 AND 255
               OR NOT EXISTS (SELECT 1 FROM dbo.Mng_System s WITH (UPDLOCK, HOLDLOCK) WHERE s.SysID = v.SystemID)
        )
        BEGIN
            ;THROW 51102, N'قائمة المنظومات في CmpSystems تحتوي على معرّف غير صحيح أو منظومة غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @CmpID)
        BEGIN
            ;THROW 51103, N'الشركة المطلوب تعديلها غير موجودة.', 1;
        END

        /* Do not remove a system assignment while permissions still use it. */
        IF EXISTS
        (
            SELECT 1
            FROM dbo.Mng_UserParmations p
            WHERE p.USPCompanyID = @CmpID
              AND ( @CmpSystems IS NULL OR NOT EXISTS
                    (
                        SELECT 1
                        FROM STRING_SPLIT(@CmpSystems, N',') ss
                        WHERE TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) = p.USPSystemID
                    ))
        )
        BEGIN
            ;THROW 51104, N'لا يمكن إزالة منظومة من الشركة ما دامت لها سجلات صلاحيات مرتبطة بها.', 1;
        END

        UPDATE dbo.Mng_Company
        SET CmpName = @CmpName,
            CmpEName = @CmpEName,
            CmpState = COALESCE(@CmpState, CmpState),
            CmpDateTime = COALESCE(@CmpDateTime, GETDATE()),
            CmpUser = @CmpUser,
            CmpSystems = @CmpSystems
        WHERE CmpID = @CmpID;

        /* A NULL logo means keep the existing logo; pass a byte array to replace it. */
        IF @CmpLogo IS NOT NULL
            UPDATE dbo.Mng_Company SET CmpLogo = @CmpLogo WHERE CmpID = @CmpID;

        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_DeleteCompany
    @CmpID int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @CmpID)
        BEGIN
            ;THROW 51105, N'الشركة المطلوب حذفها غير موجودة.', 1;
        END

        IF EXISTS (SELECT 1 FROM dbo.Mng_UserParmations WHERE USPCompanyID = @CmpID)
        BEGIN
            ;THROW 51106, N'لا يمكن حذف الشركة لوجود سجلات صلاحيات مرتبطة بها.', 1;
        END

        DELETE FROM dbo.Mng_Company WHERE CmpID = @CmpID;
        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_SearchCompany
    @CmpID      int = NULL,
    @CmpName    nvarchar(255) = NULL,
    @CmpEName   nvarchar(255) = NULL,
    @CmpState   tinyint = NULL,
    @CmpSystems nvarchar(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CmpID, CmpName, CmpEName, CmpState, CmpDateTime, CmpUser, CmpSystems
    FROM dbo.Mng_Company
    WHERE (@CmpID IS NULL OR CmpID = @CmpID)
      AND (@CmpName IS NULL OR CmpName LIKE N'%' + @CmpName + N'%')
      AND (@CmpEName IS NULL OR CmpEName LIKE N'%' + @CmpEName + N'%')
      AND (@CmpState IS NULL OR CmpState = @CmpState)
      AND (@CmpSystems IS NULL OR CmpSystems LIKE N'%' + @CmpSystems + N'%')
    ORDER BY CmpID;
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_GetCompanyByID
    @CmpID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CmpID, CmpName, CmpEName, CmpLogo, CmpState, CmpDateTime, CmpUser, CmpSystems
    FROM dbo.Mng_Company
    WHERE CmpID = @CmpID;
END
GO

/* =====================================================================
   SYSTEM PROCEDURES
   ===================================================================== */

CREATE OR ALTER PROCEDURE dbo.Mng_InsertSystem
    @SysName     nvarchar(50) = NULL,
    @SysEName    nvarchar(50) = NULL,
    @SysLogo     varbinary(max) = NULL,
    @SysState    tinyint = NULL,
    @SysDateTime datetime = NULL,
    @SysUser     int = NULL,
    @SysMenu     nvarchar(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @NewSysID int;
        SELECT @NewSysID = ISNULL(MAX(CONVERT(int, SysID)), 0) + 1
        FROM dbo.Mng_System WITH (TABLOCKX, HOLDLOCK);

        IF @NewSysID > 255
        BEGIN
            ;THROW 51200, N'لا يمكن إضافة منظومة أخرى؛ الحد الأعلى لمعرّف TINYINT هو 255، والمعرّفات تبدأ من 1.', 1;
        END

        DECLARE @SysID tinyint = CONVERT(tinyint, @NewSysID);
        INSERT INTO dbo.Mng_System (SysID, SysName, SysEName, SysLogo, SysState, SysDateTime, SysUser, SysMenu)
        VALUES (@SysID, @SysName, @SysEName, @SysLogo, COALESCE(@SysState, 0), COALESCE(@SysDateTime, GETDATE()), @SysUser, @SysMenu);

        COMMIT TRANSACTION;
        SELECT @SysID AS SysID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_UpdateSystem
    @SysID       tinyint,
    @SysName     nvarchar(50),
    @SysEName    nvarchar(50),
    @SysLogo     varbinary(max),
    @SysState    tinyint,
    @SysDateTime datetime,
    @SysUser     int,
    @SysMenu     nvarchar(500)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @SysID)
        BEGIN
            ;THROW 51201, N'المنظومة المطلوب تعديلها غير موجودة.', 1;
        END

        UPDATE dbo.Mng_System
        SET SysName = @SysName,
            SysEName = @SysEName,
            SysState = COALESCE(@SysState, SysState),
            SysDateTime = COALESCE(@SysDateTime, GETDATE()),
            SysUser = @SysUser,
            SysMenu = @SysMenu
        WHERE SysID = @SysID;

        IF @SysLogo IS NOT NULL
            UPDATE dbo.Mng_System SET SysLogo = @SysLogo WHERE SysID = @SysID;

        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_DeleteSystem
    @SysID tinyint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @SysID)
        BEGIN
            ;THROW 51202, N'المنظومة المطلوب حذفها غير موجودة.', 1;
        END

        IF EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WHERE SysMSysID = @SysID)
        BEGIN
            ;THROW 51203, N'لا يمكن حذف المنظومة قبل حذف قوائمها.', 1;
        END

        IF EXISTS (SELECT 1 FROM dbo.Mng_UserParmations WHERE USPSystemID = @SysID)
        BEGIN
            ;THROW 51204, N'لا يمكن حذف المنظومة لوجود سجلات صلاحيات مرتبطة بها.', 1;
        END

        IF EXISTS
        (
            SELECT 1
            FROM dbo.Mng_Company c
            CROSS APPLY STRING_SPLIT(COALESCE(c.CmpSystems, N''), N',') ss
            WHERE TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) = @SysID
        )
        BEGIN
            ;THROW 51205, N'لا يمكن حذف المنظومة؛ ما زالت مرتبطة بقائمة منظومات إحدى الشركات.', 1;
        END

        DELETE FROM dbo.Mng_System WHERE SysID = @SysID;
        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_SearchSystem
    @SysID    tinyint = NULL,
    @SysName  nvarchar(50) = NULL,
    @SysEName nvarchar(50) = NULL,
    @SysState tinyint = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SysID, SysName, SysEName, SysState, SysDateTime, SysUser, SysMenu
    FROM dbo.Mng_System
    WHERE (@SysID IS NULL OR SysID = @SysID)
      AND (@SysName IS NULL OR SysName LIKE N'%' + @SysName + N'%')
      AND (@SysEName IS NULL OR SysEName LIKE N'%' + @SysEName + N'%')
      AND (@SysState IS NULL OR SysState = @SysState)
    ORDER BY SysID;
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_GetSystemByID
    @SysID tinyint
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SysID, SysName, SysEName, SysLogo, SysState, SysDateTime, SysUser, SysMenu
    FROM dbo.Mng_System
    WHERE SysID = @SysID;
END
GO

/* =====================================================================
   SYSTEM MENU PROCEDURES
   ===================================================================== */

CREATE OR ALTER PROCEDURE dbo.Mng_InsertSystemMenu
    @SysMSysID    tinyint,
    @SysMParent   tinyint = 0,
    @SysMName     nvarchar(50) = NULL,
    @SysMEName    nvarchar(50) = NULL,
    @SysMLogo     nvarchar(50) = NULL,
    @SysMMap      nvarchar(50) = NULL,
    @SysMState    tinyint = NULL,
    @SysMDateTime datetime = NULL,
    @SysMUser     int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @SysMParent = COALESCE(@SysMParent, 0);

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @SysMSysID)
        BEGIN
            ;THROW 51300, N'المنظومة المحددة للقائمة غير موجودة.', 1;
        END

        IF @SysMParent <> 0 AND NOT EXISTS
        (
            SELECT 1 FROM dbo.Mng_SystemMenu WITH (UPDLOCK, HOLDLOCK)
            WHERE SysMSysID = @SysMSysID AND SysMID = @SysMParent
        )
        BEGIN
            ;THROW 51301, N'القائمة الأم غير موجودة داخل المنظومة نفسها.', 1;
        END

        DECLARE @NewSysMID int;
        SELECT @NewSysMID = ISNULL(MAX(CONVERT(int, SysMID)), 0) + 1
        FROM dbo.Mng_SystemMenu WITH (TABLOCKX, HOLDLOCK)
        WHERE SysMSysID = @SysMSysID;

        IF @NewSysMID > 255
        BEGIN
            ;THROW 51302, N'لا يمكن إضافة قائمة أخرى لهذه المنظومة؛ الحد الأعلى هو 255 قائمة.', 1;
        END

        DECLARE @SysMID tinyint = CONVERT(tinyint, @NewSysMID);
        IF @SysMParent = @SysMID
        BEGIN
            ;THROW 51303, N'لا يمكن أن تكون القائمة أبًا لنفسها.', 1;
        END

        INSERT INTO dbo.Mng_SystemMenu
            (SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime, SysMUser)
        VALUES
            (@SysMID, @SysMSysID, @SysMParent, @SysMName, @SysMEName, @SysMLogo, @SysMMap,
             COALESCE(@SysMState, 0), COALESCE(@SysMDateTime, GETDATE()), @SysMUser);

        COMMIT TRANSACTION;
        SELECT @SysMSysID AS SysMSysID, @SysMID AS SysMID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_UpdateSystemMenu
    @SysMSysID    tinyint,
    @SysMID       tinyint,
    @SysMParent   tinyint,
    @SysMName     nvarchar(50),
    @SysMEName    nvarchar(50),
    @SysMLogo     nvarchar(50),
    @SysMMap      nvarchar(50),
    @SysMState    tinyint,
    @SysMDateTime datetime,
    @SysMUser     int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @SysMParent = COALESCE(@SysMParent, 0);

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @SysMSysID)
        BEGIN
            ;THROW 51304, N'المنظومة المحددة للقائمة غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WITH (UPDLOCK, HOLDLOCK) WHERE SysMSysID = @SysMSysID AND SysMID = @SysMID)
        BEGIN
            ;THROW 51305, N'القائمة المطلوب تعديلها غير موجودة.', 1;
        END

        IF @SysMParent = @SysMID
        BEGIN
            ;THROW 51306, N'لا يمكن أن تكون القائمة أبًا لنفسها.', 1;
        END

        IF @SysMParent <> 0 AND NOT EXISTS
        (
            SELECT 1 FROM dbo.Mng_SystemMenu WITH (UPDLOCK, HOLDLOCK)
            WHERE SysMSysID = @SysMSysID AND SysMID = @SysMParent
        )
        BEGIN
            ;THROW 51307, N'القائمة الأم غير موجودة داخل المنظومة نفسها.', 1;
        END

        /* Prevent assigning a menu beneath one of its own descendants. */
        DECLARE @WouldCreateCycle bit = 0;
        ;WITH Descendants AS
        (
            SELECT SysMID, SysMParent
            FROM dbo.Mng_SystemMenu
            WHERE SysMSysID = @SysMSysID AND SysMParent = @SysMID
            UNION ALL
            SELECT child.SysMID, child.SysMParent
            FROM dbo.Mng_SystemMenu child
            INNER JOIN Descendants parentNode
                ON child.SysMSysID = @SysMSysID
               AND child.SysMParent = parentNode.SysMID
        )
        SELECT @WouldCreateCycle = CASE WHEN EXISTS
                    (SELECT 1 FROM Descendants WHERE SysMID = @SysMParent)
                THEN 1 ELSE 0 END
        OPTION (MAXRECURSION 255);

        IF @WouldCreateCycle = 1
        BEGIN
            ;THROW 51308, N'لا يمكن نقل القائمة إلى أحد فروعها؛ لأن ذلك ينشئ دورة في شجرة القوائم.', 1;
        END

        UPDATE dbo.Mng_SystemMenu
        SET SysMParent = @SysMParent,
            SysMName = @SysMName,
            SysMEName = @SysMEName,
            SysMLogo = @SysMLogo,
            SysMMap = @SysMMap,
            SysMState = COALESCE(@SysMState, SysMState),
            SysMDateTime = COALESCE(@SysMDateTime, GETDATE()),
            SysMUser = @SysMUser
        WHERE SysMSysID = @SysMSysID AND SysMID = @SysMID;

        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_DeleteSystemMenu
    @SysMSysID tinyint,
    @SysMID    tinyint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @SysMSysID)
        BEGIN
            ;THROW 51309, N'المنظومة المحددة للقائمة غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WITH (UPDLOCK, HOLDLOCK) WHERE SysMSysID = @SysMSysID AND SysMID = @SysMID)
        BEGIN
            ;THROW 51310, N'القائمة المطلوب حذفها غير موجودة.', 1;
        END

        IF EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WHERE SysMSysID = @SysMSysID AND SysMParent = @SysMID)
        BEGIN
            ;THROW 51311, N'لا يمكن حذف القائمة قبل نقل قوائمها الفرعية أو حذفها.', 1;
        END

        IF EXISTS
        (
            SELECT 1
            FROM dbo.Mng_UserParmations p
            CROSS APPLY STRING_SPLIT(COALESCE(p.USPParmations, N''), N',') ss
            WHERE p.USPSystemID = @SysMSysID
              AND TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) = @SysMID
        )
        BEGIN
            ;THROW 51312, N'لا يمكن حذف القائمة لأنها موجودة في صلاحيات مستخدمين.', 1;
        END

        DELETE FROM dbo.Mng_SystemMenu WHERE SysMSysID = @SysMSysID AND SysMID = @SysMID;
        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_SearchSystemMenu
    @SysMSysID tinyint = NULL,
    @SysMID    tinyint = NULL,
    @SysMParent tinyint = NULL,
    @SysMName  nvarchar(50) = NULL,
    @SysMEName nvarchar(50) = NULL,
    @SysMState tinyint = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime, SysMUser
    FROM dbo.Mng_SystemMenu
    WHERE (@SysMSysID IS NULL OR SysMSysID = @SysMSysID)
      AND (@SysMID IS NULL OR SysMID = @SysMID)
      AND (@SysMParent IS NULL OR SysMParent = @SysMParent)
      AND (@SysMName IS NULL OR SysMName LIKE N'%' + @SysMName + N'%')
      AND (@SysMEName IS NULL OR SysMEName LIKE N'%' + @SysMEName + N'%')
      AND (@SysMState IS NULL OR SysMState = @SysMState)
    ORDER BY SysMSysID, SysMParent, SysMID;
END
GO

/* =====================================================================
   USER PROCEDURES
   ===================================================================== */

CREATE OR ALTER PROCEDURE dbo.Mng_InsertUser
    @UsrEmployeeID bigint = NULL,
    @UsrPassWord   nvarchar(255) = NULL, -- PBKDF2-SHA256 hash generated by C#; validated below
    @UsrState      tinyint = NULL,
    @UsrDateTime   datetime = NULL,
    @UsrUser       int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @UsrPassWord IS NULL OR @UsrPassWord NOT LIKE N'PBKDF2-SHA256$%'
    BEGIN
        ;THROW 51400, N'يجب تمرير تجزئة كلمة المرور PBKDF2-SHA256 من التطبيق، وليس كلمة المرور الأصلية.', 1;
    END

    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @TemporaryLogin nvarchar(50) = N'TMP_' + REPLACE(CONVERT(nvarchar(36), NEWID()), N'-', N'');
        INSERT INTO dbo.Mng_User (UsrEmployeeID, UsrLogIn, UsrPassWord, UsrState, UsrDateTime, UsrUser)
        VALUES (@UsrEmployeeID, @TemporaryLogin, @UsrPassWord, COALESCE(@UsrState, 0), COALESCE(@UsrDateTime, GETDATE()), @UsrUser);

        DECLARE @UsrID int = CONVERT(int, SCOPE_IDENTITY());
        DECLARE @UsrIDText nvarchar(20) = CONVERT(nvarchar(20), @UsrID);
        DECLARE @UsrLogIn nvarchar(50) = N'USR'
            + REPLICATE(N'0', CASE WHEN LEN(@UsrIDText) < 6 THEN 6 - LEN(@UsrIDText) ELSE 0 END)
            + @UsrIDText + N'@madar.com';

        UPDATE dbo.Mng_User SET UsrLogIn = @UsrLogIn WHERE UsrID = @UsrID;

        COMMIT TRANSACTION;
        SELECT @UsrID AS UsrID, @UsrLogIn AS UsrLogIn;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_UpdateUser
    @UsrID         int,
    @UsrEmployeeID bigint,
    @UsrState      tinyint,
    @UsrDateTime   datetime,
    @UsrUser       int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WITH (UPDLOCK, HOLDLOCK) WHERE UsrID = @UsrID)
        BEGIN
            ;THROW 51401, N'المستخدم المطلوب تعديله غير موجود.', 1;
        END

        UPDATE dbo.Mng_User
        SET UsrEmployeeID = @UsrEmployeeID,
            UsrState = COALESCE(@UsrState, UsrState),
            UsrDateTime = COALESCE(@UsrDateTime, GETDATE()),
            UsrUser = @UsrUser
        WHERE UsrID = @UsrID;

        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_UpdateUserPassword
    @UsrID       int,
    @UsrPassWord nvarchar(255),
    @UsrUser     int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @UsrPassWord IS NULL OR @UsrPassWord NOT LIKE N'PBKDF2-SHA256$%'
    BEGIN
        ;THROW 51402, N'يجب تمرير تجزئة كلمة المرور PBKDF2-SHA256 من التطبيق، وليس كلمة المرور الأصلية.', 1;
    END

    UPDATE dbo.Mng_User
    SET UsrPassWord = @UsrPassWord,
        UsrDateTime = GETDATE(),
        UsrUser = @UsrUser
    WHERE UsrID = @UsrID;
    IF @@ROWCOUNT = 0
    BEGIN
        ;THROW 51403, N'المستخدم المطلوب تغيير كلمة مروره غير موجود.', 1;
    END
    SELECT CAST(1 AS bit) AS Success;
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_DeleteUser
    @UsrID int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WITH (UPDLOCK, HOLDLOCK) WHERE UsrID = @UsrID)
        BEGIN
            ;THROW 51404, N'المستخدم المطلوب حذفه غير موجود.', 1;
        END

        IF EXISTS (SELECT 1 FROM dbo.Mng_UserParmations WHERE USPUserID = @UsrID)
        BEGIN
            ;THROW 51405, N'لا يمكن حذف المستخدم لوجود سجلات صلاحيات مرتبطة به.', 1;
        END

        DELETE FROM dbo.Mng_User WHERE UsrID = @UsrID;
        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_SearchUser
    @UsrID         int = NULL,
    @UsrEmployeeID bigint = NULL,
    @UsrLogIn      nvarchar(50) = NULL,
    @UsrState      tinyint = NULL
AS
BEGIN
    SET NOCOUNT ON;
    /* Intentionally omits UsrPassWord from ordinary user search results. */
    SELECT UsrID, UsrEmployeeID, UsrLogIn, UsrState, UsrDateTime, UsrUser
    FROM dbo.Mng_User
    WHERE (@UsrID IS NULL OR UsrID = @UsrID)
      AND (@UsrEmployeeID IS NULL OR UsrEmployeeID = @UsrEmployeeID)
      AND (@UsrLogIn IS NULL OR UsrLogIn LIKE N'%' + @UsrLogIn + N'%')
      AND (@UsrState IS NULL OR UsrState = @UsrState)
    ORDER BY UsrID;
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_GetUserForLogin
    @UsrLogIn nvarchar(50)
AS
BEGIN
    SET NOCOUNT ON;
    /* Restrict EXECUTE permission on this procedure to the application identity. */
    SELECT UsrID, UsrLogIn, UsrPassWord, UsrState, UsrEmployeeID
    FROM dbo.Mng_User
    WHERE UsrLogIn = @UsrLogIn;
END
GO

/* =====================================================================
   USER PERMISSION PROCEDURES
   ===================================================================== */

CREATE OR ALTER PROCEDURE dbo.Mng_InsertUserParmations
    @USPUserID     int,
    @USPCompanyID  int,
    @USPSystemID   tinyint,
    @USPParmations nvarchar(500) = NULL,
    @USPState      tinyint = NULL,
    @USPDateTime   datetime = NULL,
    @USPUser       int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @USPParmations = NULLIF(LTRIM(RTRIM(@USPParmations)), N'');

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @USPSystemID)
        BEGIN
            ;THROW 51500, N'المنظومة المحددة للصلاحية غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @USPCompanyID)
        BEGIN
            ;THROW 51501, N'الشركة المحددة للصلاحية غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WITH (UPDLOCK, HOLDLOCK) WHERE UsrID = @USPUserID)
        BEGIN
            ;THROW 51502, N'المستخدم المحدد للصلاحية غير موجود.', 1;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Mng_Company c
            CROSS APPLY STRING_SPLIT(COALESCE(c.CmpSystems, N''), N',') ss
            WHERE c.CmpID = @USPCompanyID
              AND TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) = @USPSystemID
        )
        BEGIN
            ;THROW 51503, N'المنظومة غير مدرجة ضمن المنظومات المخصصة لهذه الشركة في CmpSystems.', 1;
        END

        IF @USPParmations IS NOT NULL AND EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(@USPParmations, N',') ss
            CROSS APPLY (SELECT TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) AS MenuID) v
            WHERE NULLIF(LTRIM(RTRIM(ss.value)), N'') IS NULL
               OR v.MenuID IS NULL
               OR v.MenuID NOT BETWEEN 1 AND 255
               OR NOT EXISTS
                  (SELECT 1 FROM dbo.Mng_SystemMenu m WITH (UPDLOCK, HOLDLOCK)
                   WHERE m.SysMSysID = @USPSystemID AND m.SysMID = v.MenuID)
        )
        BEGIN
            ;THROW 51504, N'قائمة الصلاحيات تحتوي على معرّف قائمة غير صحيح أو لا يتبع المنظومة المحددة.', 1;
        END

        INSERT INTO dbo.Mng_UserParmations
            (USPUserID, USPCompanyID, USPSystemID, USPParmations, USPState, USPDateTime, USPUser)
        VALUES
            (@USPUserID, @USPCompanyID, @USPSystemID, @USPParmations, COALESCE(@USPState, 0), COALESCE(@USPDateTime, GETDATE()), @USPUser);

        DECLARE @USPID bigint = CONVERT(bigint, SCOPE_IDENTITY());
        COMMIT TRANSACTION;
        SELECT @USPID AS USPID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_UpdateUserParmations
    @USPID         bigint,
    @USPUserID     int,
    @USPCompanyID  int,
    @USPSystemID   tinyint,
    @USPParmations nvarchar(500),
    @USPState      tinyint,
    @USPDateTime   datetime,
    @USPUser       int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @USPParmations = NULLIF(LTRIM(RTRIM(@USPParmations)), N'');

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_UserParmations WITH (UPDLOCK, HOLDLOCK) WHERE USPID = @USPID)
        BEGIN
            ;THROW 51505, N'سجل الصلاحيات المطلوب تعديله غير موجود.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WITH (UPDLOCK, HOLDLOCK) WHERE SysID = @USPSystemID)
        BEGIN
            ;THROW 51506, N'المنظومة المحددة للصلاحية غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @USPCompanyID)
        BEGIN
            ;THROW 51507, N'الشركة المحددة للصلاحية غير موجودة.', 1;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WITH (UPDLOCK, HOLDLOCK) WHERE UsrID = @USPUserID)
        BEGIN
            ;THROW 51508, N'المستخدم المحدد للصلاحية غير موجود.', 1;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Mng_Company c
            CROSS APPLY STRING_SPLIT(COALESCE(c.CmpSystems, N''), N',') ss
            WHERE c.CmpID = @USPCompanyID
              AND TRY_CONVERT(int, LTRIM(RTRIM(ss.value))) = @USPSystemID
        )
        BEGIN
            ;THROW 51509, N'المنظومة غير مدرجة ضمن المنظومات المخصصة لهذه الشركة في CmpSystems.', 1;
        END

        IF @USPParmations IS NOT NULL AND EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(@USPParmations, N',') ss
            CROSS APPLY (SELECT TRY_CONVERT(int, LTRIM(RTRIM(ss.value)) ) AS MenuID) v
            WHERE NULLIF(LTRIM(RTRIM(ss.value)), N'') IS NULL
               OR v.MenuID IS NULL
               OR v.MenuID NOT BETWEEN 1 AND 255
               OR NOT EXISTS
                  (SELECT 1 FROM dbo.Mng_SystemMenu m WITH (UPDLOCK, HOLDLOCK)
                   WHERE m.SysMSysID = @USPSystemID AND m.SysMID = v.MenuID)
        )
        BEGIN
            ;THROW 51510, N'قائمة الصلاحيات تحتوي على معرّف قائمة غير صحيح أو لا يتبع المنظومة المحددة.', 1;
        END

        UPDATE dbo.Mng_UserParmations
        SET USPUserID = @USPUserID,
            USPCompanyID = @USPCompanyID,
            USPSystemID = @USPSystemID,
            USPParmations = @USPParmations,
            USPState = COALESCE(@USPState, USPState),
            USPDateTime = COALESCE(@USPDateTime, GETDATE()),
            USPUser = @USPUser
        WHERE USPID = @USPID;

        COMMIT TRANSACTION;
        SELECT CAST(1 AS bit) AS Success;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_DeleteUserParmations
    @USPID bigint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DELETE FROM dbo.Mng_UserParmations WHERE USPID = @USPID;
    IF @@ROWCOUNT = 0
    BEGIN
        ;THROW 51511, N'سجل الصلاحيات المطلوب حذفه غير موجود.', 1;
    END
    SELECT CAST(1 AS bit) AS Success;
END
GO

CREATE OR ALTER PROCEDURE dbo.Mng_SearchUserParmations
    @USPID        bigint = NULL,
    @USPUserID    int = NULL,
    @USPCompanyID int = NULL,
    @USPSystemID  tinyint = NULL,
    @USPState     tinyint = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT USPID, USPUserID, USPCompanyID, USPSystemID, USPParmations, USPState, USPDateTime, USPUser
    FROM dbo.Mng_UserParmations
    WHERE (@USPID IS NULL OR USPID = @USPID)
      AND (@USPUserID IS NULL OR USPUserID = @USPUserID)
      AND (@USPCompanyID IS NULL OR USPCompanyID = @USPCompanyID)
      AND (@USPSystemID IS NULL OR USPSystemID = @USPSystemID)
      AND (@USPState IS NULL OR USPState = @USPState)
    ORDER BY USPID;
END
GO

/* =====================================================================
   USER MENU RETRIEVAL
   Returns directly permitted menu entries and their ancestor menus.
   State fields are returned as data; state-code meanings were not fixed
   in the agreement and therefore are not hard-coded as filters here.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Mng_GetUserMenu
    @USPUserID    int,
    @USPCompanyID int,
    @USPSystemID  tinyint
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH DirectAllowed AS
    (
        SELECT DISTINCT TRY_CONVERT(tinyint, LTRIM(RTRIM(ss.value))) AS SysMID
        FROM dbo.Mng_UserParmations p
        CROSS APPLY STRING_SPLIT(COALESCE(p.USPParmations, N''), N',') ss
        WHERE p.USPUserID = @USPUserID
          AND p.USPCompanyID = @USPCompanyID
          AND p.USPSystemID = @USPSystemID
          AND TRY_CONVERT(tinyint, LTRIM(RTRIM(ss.value))) IS NOT NULL
    ),
    MenuAndParents AS
    (
        SELECT m.SysMSysID, m.SysMID, m.SysMParent
        FROM dbo.Mng_SystemMenu m
        INNER JOIN DirectAllowed d ON d.SysMID = m.SysMID
        WHERE m.SysMSysID = @USPSystemID

        UNION ALL

        SELECT parentMenu.SysMSysID, parentMenu.SysMID, parentMenu.SysMParent
        FROM dbo.Mng_SystemMenu parentMenu
        INNER JOIN MenuAndParents childMenu
            ON parentMenu.SysMSysID = childMenu.SysMSysID
           AND parentMenu.SysMID = childMenu.SysMParent
        WHERE childMenu.SysMParent > 0
    )
    SELECT DISTINCT m.SysMID, m.SysMSysID, m.SysMParent, m.SysMName, m.SysMEName,
                    m.SysMLogo, m.SysMMap, m.SysMState, m.SysMDateTime, m.SysMUser
    FROM dbo.Mng_SystemMenu m
    INNER JOIN MenuAndParents ap
        ON ap.SysMSysID = m.SysMSysID AND ap.SysMID = m.SysMID
    WHERE m.SysMSysID = @USPSystemID
    ORDER BY m.SysMParent, m.SysMID
    OPTION (MAXRECURSION 255);
END
GO

/* =====================================================================
   END OF SCRIPT
   ===================================================================== */
PRINT N'تم إنشاء جداول وإجراءات قاعدة MADARERPDataBase بنجاح.';
GO

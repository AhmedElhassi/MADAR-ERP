/*
 MADAR Enterprise ERP - General Ledger (Acc_)
 Initial implementation script for SQL Server.

 IMPORTANT:
 - Target database: MADARERPDataBase
 - This is a standalone first-pass script because the existing database schema
   has not yet been supplied. It intentionally does NOT add foreign keys to
   unknown MADAR company/user tables.
 - Review table/column names and integrate company/user/logo references with
   the existing MADAR schema before production deployment.
 - Execute first in a backup/non-production database. No claim is made that this
   script has been tested against the user's live database.
 - All monetary ledger values are in the company's official local currency.
*/

USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* Company reporting identity. Integrate CompanyID with the existing company table. */
IF OBJECT_ID(N'dbo.Acc_CompanyReportProfile', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_CompanyReportProfile
    (
        CompanyID       int            NOT NULL,
        CompanyNumber   nvarchar(50)   NULL,
        CompanyNameAr   nvarchar(255)  NOT NULL,
        CompanyNameEn   nvarchar(255)  NULL,
        CompanyLogo     varbinary(max) NULL,
        LogoContentType nvarchar(100)  NULL,
        IsActive        bit            NOT NULL CONSTRAINT DF_Acc_CompanyReportProfile_IsActive DEFAULT (1),
        CreatedAt       datetime2(0)   NOT NULL CONSTRAINT DF_Acc_CompanyReportProfile_CreatedAt DEFAULT (SYSUTCDATETIME()),
        UpdatedAt       datetime2(0)   NULL,
        CONSTRAINT PK_Acc_CompanyReportProfile PRIMARY KEY (CompanyID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Acc_FiscalYears', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_FiscalYears
    (
        FiscalYearID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_FiscalYears PRIMARY KEY,
        CompanyID    int NOT NULL,
        YearCode     nvarchar(20) NOT NULL,
        YearName     nvarchar(100) NOT NULL,
        StartDate    date NOT NULL,
        EndDate      date NOT NULL,
        YearStatus   tinyint NOT NULL CONSTRAINT DF_Acc_FiscalYears_Status DEFAULT (0), -- 0 open, 1 closing, 2 closed
        CreatedBy    int NULL,
        CreatedAt    datetime2(0) NOT NULL CONSTRAINT DF_Acc_FiscalYears_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Acc_FiscalYears_Company_Code UNIQUE (CompanyID, YearCode),
        CONSTRAINT CK_Acc_FiscalYears_Dates CHECK (EndDate >= StartDate),
        CONSTRAINT CK_Acc_FiscalYears_Status CHECK (YearStatus IN (0,1,2))
    );
END;
GO

IF OBJECT_ID(N'dbo.Acc_FiscalPeriods', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_FiscalPeriods
    (
        FiscalPeriodID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_FiscalPeriods PRIMARY KEY,
        CompanyID      int NOT NULL,
        FiscalYearID   bigint NOT NULL,
        PeriodNumber   tinyint NOT NULL,
        PeriodName     nvarchar(100) NOT NULL,
        StartDate      date NOT NULL,
        EndDate        date NOT NULL,
        PeriodStatus   tinyint NOT NULL CONSTRAINT DF_Acc_FiscalPeriods_Status DEFAULT (0), -- 0 open, 1 closing, 2 closed
        CONSTRAINT FK_Acc_FiscalPeriods_Year FOREIGN KEY (FiscalYearID) REFERENCES dbo.Acc_FiscalYears(FiscalYearID),
        CONSTRAINT UQ_Acc_FiscalPeriods_Year_Number UNIQUE (FiscalYearID, PeriodNumber),
        CONSTRAINT CK_Acc_FiscalPeriods_Number CHECK (PeriodNumber BETWEEN 1 AND 13),
        CONSTRAINT CK_Acc_FiscalPeriods_Dates CHECK (EndDate >= StartDate),
        CONSTRAINT CK_Acc_FiscalPeriods_Status CHECK (PeriodStatus IN (0,1,2))
    );
END;
GO

/* Main account and subaccount are separate, as required by the agreed design. */
IF OBJECT_ID(N'dbo.Acc_MainAccounts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_MainAccounts
    (
        MainAccountID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_MainAccounts PRIMARY KEY,
        CompanyID     int NOT NULL,
        MainAccountNo nvarchar(50) NOT NULL,
        MainAccountNameAr nvarchar(255) NOT NULL,
        MainAccountNameEn nvarchar(255) NULL,
        AccountClass  tinyint NOT NULL, -- 1 assets, 2 liabilities, 3 equity, 4 revenue, 5 expenses
        NormalBalance char(1) NOT NULL, -- D debit, C credit
        IsActive      bit NOT NULL CONSTRAINT DF_Acc_MainAccounts_IsActive DEFAULT (1),
        CreatedBy     int NULL,
        CreatedAt     datetime2(0) NOT NULL CONSTRAINT DF_Acc_MainAccounts_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy    int NULL,
        ModifiedAt    datetime2(0) NULL,
        RowVer        rowversion,
        CONSTRAINT UQ_Acc_MainAccounts_Company_No UNIQUE (CompanyID, MainAccountNo),
        CONSTRAINT CK_Acc_MainAccounts_Class CHECK (AccountClass BETWEEN 1 AND 5),
        CONSTRAINT CK_Acc_MainAccounts_NormalBalance CHECK (NormalBalance IN ('D','C'))
    );
END;
GO

IF OBJECT_ID(N'dbo.Acc_SubAccounts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_SubAccounts
    (
        SubAccountID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_SubAccounts PRIMARY KEY,
        CompanyID    int NOT NULL,
        MainAccountID bigint NOT NULL,
        ParentSubAccountID bigint NULL,
        SubAccountNo nvarchar(100) NOT NULL,
        SubAccountNameAr nvarchar(255) NOT NULL,
        SubAccountNameEn nvarchar(255) NULL,
        AccountLevel  tinyint NOT NULL CONSTRAINT DF_Acc_SubAccounts_Level DEFAULT (1),
        IsPostingAccount bit NOT NULL CONSTRAINT DF_Acc_SubAccounts_Posting DEFAULT (1),
        IsActive     bit NOT NULL CONSTRAINT DF_Acc_SubAccounts_IsActive DEFAULT (1),
        CreatedBy    int NULL,
        CreatedAt    datetime2(0) NOT NULL CONSTRAINT DF_Acc_SubAccounts_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy   int NULL,
        ModifiedAt   datetime2(0) NULL,
        RowVer       rowversion,
        CONSTRAINT FK_Acc_SubAccounts_Main FOREIGN KEY (MainAccountID) REFERENCES dbo.Acc_MainAccounts(MainAccountID),
        CONSTRAINT FK_Acc_SubAccounts_Parent FOREIGN KEY (ParentSubAccountID) REFERENCES dbo.Acc_SubAccounts(SubAccountID),
        CONSTRAINT UQ_Acc_SubAccounts_Company_No UNIQUE (CompanyID, SubAccountNo),
        CONSTRAINT CK_Acc_SubAccounts_Level CHECK (AccountLevel >= 1),
        CONSTRAINT CK_Acc_SubAccounts_NotSelfParent CHECK (ParentSubAccountID IS NULL OR ParentSubAccountID <> SubAccountID)
    );
END;
GO
CREATE INDEX IX_Acc_SubAccounts_MainAccount ON dbo.Acc_SubAccounts(CompanyID, MainAccountID, IsActive);
GO

/* Single hierarchical cost-center table; parent 0/NULL represents a root. */
IF OBJECT_ID(N'dbo.Acc_CostCenters', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_CostCenters
    (
        CostCenterID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_CostCenters PRIMARY KEY,
        CompanyID    int NOT NULL,
        ParentCostCenterID bigint NULL,
        CostCenterName nvarchar(255) NOT NULL,
        CostCenterCode nvarchar(100) NOT NULL,
        CostCenterNumber bigint NULL,
        CostCenterLevel tinyint NULL,
        ChildCount smallint NULL,
        CostCenterMap nvarchar(max) NULL,
        CostCenterStatus tinyint NOT NULL CONSTRAINT DF_Acc_CostCenters_Status DEFAULT (1),
        CreatedBy int NULL,
        CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_CostCenters_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy int NULL,
        ModifiedAt datetime2(0) NULL,
        RowVer rowversion,
        CONSTRAINT FK_Acc_CostCenters_Parent FOREIGN KEY (ParentCostCenterID) REFERENCES dbo.Acc_CostCenters(CostCenterID),
        CONSTRAINT UQ_Acc_CostCenters_Company_Code UNIQUE (CompanyID, CostCenterCode),
        CONSTRAINT CK_Acc_CostCenters_NotSelfParent CHECK (ParentCostCenterID IS NULL OR ParentCostCenterID <> CostCenterID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Acc_JournalHeaders', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_JournalHeaders
    (
        JournalID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalHeaders PRIMARY KEY,
        CompanyID int NOT NULL,
        FiscalYearID bigint NOT NULL,
        FiscalPeriodID bigint NOT NULL,
        JournalNumber nvarchar(50) NOT NULL,
        JournalDate date NOT NULL,
        JournalType nvarchar(30) NOT NULL, -- Manual / Automated / Reversal / Adjustment
        SourceSystem nvarchar(100) NULL,
        SourceDocumentType nvarchar(100) NULL,
        SourceDocumentID nvarchar(150) NULL,
        IdempotencyKey nvarchar(200) NULL,
        Description nvarchar(1000) NULL,
        JournalStatus tinyint NOT NULL CONSTRAINT DF_Acc_JournalHeaders_Status DEFAULT (0),
        -- 0 draft, 1 submitted, 2 reviewed, 3 approved, 4 posted, 5 archived, 6 rejected, 7 reversed
        PreparedBy int NULL,
        PreparedAt datetime2(0) NULL,
        ReviewedBy int NULL,
        ReviewedAt datetime2(0) NULL,
        ApprovedBy int NULL,
        ApprovedAt datetime2(0) NULL,
        PostedBy int NULL,
        PostedAt datetime2(0) NULL,
        ArchivedBy int NULL,
        ArchivedAt datetime2(0) NULL,
        RejectedBy int NULL,
        RejectedAt datetime2(0) NULL,
        RejectionReason nvarchar(1000) NULL,
        ReversesJournalID bigint NULL,
        CreatedBy int NOT NULL,
        CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_JournalHeaders_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy int NULL,
        ModifiedAt datetime2(0) NULL,
        RowVer rowversion,
        CONSTRAINT FK_Acc_JournalHeaders_Year FOREIGN KEY (FiscalYearID) REFERENCES dbo.Acc_FiscalYears(FiscalYearID),
        CONSTRAINT FK_Acc_JournalHeaders_Period FOREIGN KEY (FiscalPeriodID) REFERENCES dbo.Acc_FiscalPeriods(FiscalPeriodID),
        CONSTRAINT FK_Acc_JournalHeaders_Reverses FOREIGN KEY (ReversesJournalID) REFERENCES dbo.Acc_JournalHeaders(JournalID),
        CONSTRAINT UQ_Acc_JournalHeaders_Company_Number UNIQUE (CompanyID, JournalNumber),
        CONSTRAINT CK_Acc_JournalHeaders_Status CHECK (JournalStatus BETWEEN 0 AND 7),
        CONSTRAINT CK_Acc_JournalHeaders_Type CHECK (JournalType IN (N'Manual',N'Automated',N'Reversal',N'Adjustment'))
    );
END;
GO

IF OBJECT_ID(N'dbo.Acc_JournalDetails', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_JournalDetails
    (
        JournalDetailID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalDetails PRIMARY KEY,
        JournalID bigint NOT NULL,
        LineNumber int NOT NULL,
        SubAccountID bigint NOT NULL,
        CostCenterID bigint NULL,
        LineDescription nvarchar(1000) NULL,
        DebitAmount decimal(19,4) NOT NULL CONSTRAINT DF_Acc_JournalDetails_Debit DEFAULT (0),
        CreditAmount decimal(19,4) NOT NULL CONSTRAINT DF_Acc_JournalDetails_Credit DEFAULT (0),
        CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_JournalDetails_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT FK_Acc_JournalDetails_Header FOREIGN KEY (JournalID) REFERENCES dbo.Acc_JournalHeaders(JournalID),
        CONSTRAINT FK_Acc_JournalDetails_Account FOREIGN KEY (SubAccountID) REFERENCES dbo.Acc_SubAccounts(SubAccountID),
        CONSTRAINT FK_Acc_JournalDetails_CostCenter FOREIGN KEY (CostCenterID) REFERENCES dbo.Acc_CostCenters(CostCenterID),
        CONSTRAINT UQ_Acc_JournalDetails_Line UNIQUE (JournalID, LineNumber),
        CONSTRAINT CK_Acc_JournalDetails_Amounts CHECK
            (DebitAmount >= 0 AND CreditAmount >= 0 AND
             NOT (DebitAmount > 0 AND CreditAmount > 0) AND
             (DebitAmount > 0 OR CreditAmount > 0))
    );
END;
GO
CREATE INDEX IX_Acc_JournalHeaders_Report ON dbo.Acc_JournalHeaders(CompanyID, JournalStatus, JournalDate) INCLUDE (JournalNumber, FiscalYearID, FiscalPeriodID);
GO
CREATE INDEX IX_Acc_JournalDetails_Account ON dbo.Acc_JournalDetails(SubAccountID, JournalID) INCLUDE (DebitAmount, CreditAmount, CostCenterID);
GO
CREATE INDEX IX_Acc_JournalDetails_CostCenter ON dbo.Acc_JournalDetails(CostCenterID, JournalID) INCLUDE (DebitAmount, CreditAmount, SubAccountID);
GO

/* Configurable company workflow/settings. */
IF OBJECT_ID(N'dbo.Acc_CompanySettings', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_CompanySettings
    (
        CompanyID int NOT NULL CONSTRAINT PK_Acc_CompanySettings PRIMARY KEY,
        RequireReview bit NOT NULL CONSTRAINT DF_Acc_CompanySettings_Review DEFAULT (1),
        RequireApproval bit NOT NULL CONSTRAINT DF_Acc_CompanySettings_Approval DEFAULT (1),
        RequireArchive bit NOT NULL CONSTRAINT DF_Acc_CompanySettings_Archive DEFAULT (0),
        AllowManualJournal bit NOT NULL CONSTRAINT DF_Acc_CompanySettings_Manual DEFAULT (1),
        SettingsVersion int NOT NULL CONSTRAINT DF_Acc_CompanySettings_Version DEFAULT (1),
        UpdatedBy int NULL,
        UpdatedAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_CompanySettings_UpdatedAt DEFAULT (SYSUTCDATETIME())
    );
END;
GO

IF OBJECT_ID(N'dbo.Acc_JournalWorkflowHistory', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_JournalWorkflowHistory
    (
        WorkflowHistoryID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalWorkflowHistory PRIMARY KEY,
        JournalID bigint NOT NULL,
        FromStatus tinyint NULL,
        ToStatus tinyint NOT NULL,
        ActionBy int NOT NULL,
        ActionAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_JournalWorkflowHistory_ActionAt DEFAULT (SYSUTCDATETIME()),
        ActionNote nvarchar(1000) NULL,
        CONSTRAINT FK_Acc_JournalWorkflowHistory_Journal FOREIGN KEY (JournalID) REFERENCES dbo.Acc_JournalHeaders(JournalID)
    );
END;
GO

/* Audit trail for account directory, cost centers, journals and related objects. */
IF OBJECT_ID(N'dbo.Acc_AuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_AuditLog
    (
        AuditID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_AuditLog PRIMARY KEY,
        CompanyID int NOT NULL,
        EntityName sysname NOT NULL,
        EntityID nvarchar(150) NOT NULL,
        OperationType nvarchar(20) NOT NULL, -- INSERT / UPDATE / DELETE / MOVE / POST / ARCHIVE
        ChangedBy int NOT NULL,
        ChangedAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_AuditLog_ChangedAt DEFAULT (SYSUTCDATETIME()),
        ChangeReason nvarchar(1000) NULL,
        OldValues nvarchar(max) NULL,
        NewValues nvarchar(max) NULL,
        ClientApp nvarchar(200) NULL,
        CONSTRAINT CK_Acc_AuditLog_Operation CHECK (OperationType IN (N'INSERT',N'UPDATE',N'DELETE',N'MOVE',N'POST',N'ARCHIVE',N'REJECT',N'REVERSE'))
    );
END;
GO
CREATE INDEX IX_Acc_AuditLog_Company_Date ON dbo.Acc_AuditLog(CompanyID, ChangedAt DESC);
GO

IF OBJECT_ID(N'dbo.Acc_ReportRequestLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Acc_ReportRequestLog
    (
        ReportRequestID bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_ReportRequestLog PRIMARY KEY,
        CompanyID int NOT NULL,
        RequestedBy int NOT NULL,
        ReportCode nvarchar(100) NOT NULL,
        RequestedAt datetime2(0) NOT NULL CONSTRAINT DF_Acc_ReportRequestLog_RequestedAt DEFAULT (SYSUTCDATETIME()),
        ParametersJson nvarchar(max) NULL,
        OutputFormat nvarchar(20) NULL,
        CONSTRAINT CK_Acc_ReportRequestLog_Json CHECK (ParametersJson IS NULL OR ISJSON(ParametersJson) = 1)
    );
END;
GO

/* Add one fiscal year and its periods only after validating company-specific dates. */
CREATE OR ALTER PROCEDURE dbo.Acc_FiscalYear_Create
    @CompanyID int,
    @YearCode nvarchar(20),
    @YearName nvarchar(100),
    @StartDate date,
    @EndDate date,
    @CreatedBy int,
    @FiscalYearID bigint OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @EndDate < @StartDate THROW 51001, N'تاريخ نهاية السنة يجب ألا يسبق تاريخ بدايتها.', 1;
    BEGIN TRAN;
    INSERT dbo.Acc_FiscalYears(CompanyID,YearCode,YearName,StartDate,EndDate,CreatedBy)
    VALUES(@CompanyID,@YearCode,@YearName,@StartDate,@EndDate,@CreatedBy);
    SET @FiscalYearID = SCOPE_IDENTITY();
    COMMIT;
END;
GO

/* Save/update a draft journal. Posting remains a separate, controlled operation. */
CREATE OR ALTER PROCEDURE dbo.Acc_Journal_SaveDraft
    @JournalID bigint = NULL OUTPUT,
    @CompanyID int,
    @FiscalYearID bigint,
    @FiscalPeriodID bigint,
    @JournalNumber nvarchar(50),
    @JournalDate date,
    @JournalType nvarchar(30),
    @Description nvarchar(1000) = NULL,
    @CreatedBy int,
    @LinesJson nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF ISJSON(@LinesJson) <> 1 THROW 51002, N'تفاصيل القيد ليست بصيغة JSON صحيحة.', 1;
    IF NOT EXISTS (SELECT 1 FROM OPENJSON(@LinesJson)
                   WITH (DebitAmount decimal(19,4) '$.debit', CreditAmount decimal(19,4) '$.credit'))
        THROW 51003, N'القيد يجب أن يحتوي على سطر واحد على الأقل.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM OPENJSON(@LinesJson)
        WITH (SubAccountID bigint '$.subAccountId',
              CostCenterID bigint '$.costCenterId',
              DebitAmount decimal(19,4) '$.debit',
              CreditAmount decimal(19,4) '$.credit')
        WHERE SubAccountID IS NULL OR
              DebitAmount IS NULL OR CreditAmount IS NULL OR
              DebitAmount < 0 OR CreditAmount < 0 OR
              (DebitAmount > 0 AND CreditAmount > 0) OR
              (DebitAmount = 0 AND CreditAmount = 0)
    ) THROW 51004, N'يوجد سطر قيد غير صحيح.', 1;

    BEGIN TRAN;
    IF @JournalID IS NULL
    BEGIN
        INSERT dbo.Acc_JournalHeaders
            (CompanyID,FiscalYearID,FiscalPeriodID,JournalNumber,JournalDate,JournalType,
             Description,JournalStatus,CreatedBy,PreparedBy,PreparedAt)
        VALUES
            (@CompanyID,@FiscalYearID,@FiscalPeriodID,@JournalNumber,@JournalDate,@JournalType,
             @Description,0,@CreatedBy,@CreatedBy,SYSUTCDATETIME());
        SET @JournalID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_JournalHeaders WITH (UPDLOCK,HOLDLOCK)
                       WHERE JournalID=@JournalID AND CompanyID=@CompanyID AND JournalStatus=0)
            THROW 51005, N'لا يمكن تعديل هذا القيد؛ يجب أن يكون مسودة تابعة للشركة المحددة.', 1;

        UPDATE dbo.Acc_JournalHeaders
        SET FiscalYearID=@FiscalYearID, FiscalPeriodID=@FiscalPeriodID,
            JournalNumber=@JournalNumber, JournalDate=@JournalDate,
            JournalType=@JournalType, Description=@Description,
            ModifiedBy=@CreatedBy, ModifiedAt=SYSUTCDATETIME()
        WHERE JournalID=@JournalID AND CompanyID=@CompanyID;

        DELETE dbo.Acc_JournalDetails WHERE JournalID=@JournalID;
    END;

    INSERT dbo.Acc_JournalDetails(JournalID,LineNumber,SubAccountID,CostCenterID,LineDescription,DebitAmount,CreditAmount)
    SELECT @JournalID, CONVERT(int,j.[key])+1, x.SubAccountID, x.CostCenterID, x.LineDescription,
           x.DebitAmount, x.CreditAmount
    FROM OPENJSON(@LinesJson) j
    CROSS APPLY OPENJSON(j.value)
    WITH (SubAccountID bigint '$.subAccountId',
          CostCenterID bigint '$.costCenterId',
          LineDescription nvarchar(1000) '$.description',
          DebitAmount decimal(19,4) '$.debit',
          CreditAmount decimal(19,4) '$.credit') x;

    INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,OperationType,ChangedBy,ChangeReason,NewValues)
    VALUES(@CompanyID,N'Acc_JournalHeaders',CONVERT(nvarchar(150),@JournalID),N'INSERT',@CreatedBy,
           N'Save draft journal',JSON_OBJECT('JournalNumber':@JournalNumber,'JournalDate':CONVERT(nvarchar(10),@JournalDate,23)));

    COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_Journal_Submit
    @JournalID bigint,
    @CompanyID int,
    @ActionBy int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @Debit decimal(19,4), @Credit decimal(19,4), @OldStatus tinyint;
    BEGIN TRAN;
    SELECT @OldStatus=JournalStatus
    FROM dbo.Acc_JournalHeaders WITH (UPDLOCK,HOLDLOCK)
    WHERE JournalID=@JournalID AND CompanyID=@CompanyID;
    IF @OldStatus IS NULL OR @OldStatus<>0 THROW 51006, N'القيد غير موجود أو ليس مسودة.', 1;

    SELECT @Debit=SUM(DebitAmount), @Credit=SUM(CreditAmount)
    FROM dbo.Acc_JournalDetails WHERE JournalID=@JournalID;
    IF ISNULL(@Debit,0)<=0 OR ISNULL(@Credit,0)<=0 OR @Debit<>@Credit
        THROW 51007, N'يجب أن يكون القيد غير صفري ومتوازنًا قبل إرساله للمراجعة.', 1;

    IF EXISTS
    (
        SELECT 1 FROM dbo.Acc_JournalHeaders h
        JOIN dbo.Acc_FiscalYears y ON y.FiscalYearID=h.FiscalYearID
        JOIN dbo.Acc_FiscalPeriods p ON p.FiscalPeriodID=h.FiscalPeriodID
        WHERE h.JournalID=@JournalID AND
             (y.YearStatus<>0 OR p.PeriodStatus<>0 OR h.JournalDate NOT BETWEEN y.StartDate AND y.EndDate
              OR h.JournalDate NOT BETWEEN p.StartDate AND p.EndDate)
    ) THROW 51008, N'السنة أو الفترة المالية مغلقة أو لا تطابق تاريخ القيد.', 1;

    UPDATE dbo.Acc_JournalHeaders SET JournalStatus=1 WHERE JournalID=@JournalID;
    INSERT dbo.Acc_JournalWorkflowHistory(JournalID,FromStatus,ToStatus,ActionBy,ActionNote)
    VALUES(@JournalID,@OldStatus,1,@ActionBy,N'Submitted');
    COMMIT;
END;
GO

/* Review/approval transitions are deliberately explicit and auditable. */
CREATE OR ALTER PROCEDURE dbo.Acc_Journal_Transition
    @JournalID bigint,
    @CompanyID int,
    @ToStatus tinyint,
    @ActionBy int,
    @ActionNote nvarchar(1000)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @FromStatus tinyint;
    IF @ToStatus NOT IN (2,3,4,5,6) THROW 51009, N'حالة انتقال غير مسموح بها.', 1;
    BEGIN TRAN;
    SELECT @FromStatus=JournalStatus FROM dbo.Acc_JournalHeaders WITH (UPDLOCK,HOLDLOCK)
    WHERE JournalID=@JournalID AND CompanyID=@CompanyID;
    IF @FromStatus IS NULL THROW 51010, N'القيد غير موجود.', 1;

    IF NOT ((@FromStatus=1 AND @ToStatus IN (2,6)) OR
            (@FromStatus=2 AND @ToStatus IN (3,6)) OR
            (@FromStatus=3 AND @ToStatus IN (4,6)) OR
            (@FromStatus=4 AND @ToStatus=5))
        THROW 51011, N'انتقال الحالة غير مسموح وفق المسار الافتراضي.', 1;

    IF @ToStatus=4
    BEGIN
        DECLARE @D decimal(19,4), @C decimal(19,4);
        SELECT @D=SUM(DebitAmount), @C=SUM(CreditAmount) FROM dbo.Acc_JournalDetails WHERE JournalID=@JournalID;
        IF ISNULL(@D,0)<=0 OR ISNULL(@C,0)<=0 OR @D<>@C
            THROW 51012, N'لا يمكن ترحيل قيد غير متوازن أو صفري.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeaders h
                   JOIN dbo.Acc_FiscalYears y ON y.FiscalYearID=h.FiscalYearID
                   JOIN dbo.Acc_FiscalPeriods p ON p.FiscalPeriodID=h.FiscalPeriodID
                   WHERE h.JournalID=@JournalID AND (y.YearStatus<>0 OR p.PeriodStatus<>0))
            THROW 51013, N'لا يمكن الترحيل في سنة أو فترة مغلقة.', 1;
    END;

    UPDATE dbo.Acc_JournalHeaders
    SET JournalStatus=@ToStatus,
        ReviewedBy=CASE WHEN @ToStatus=2 THEN @ActionBy ELSE ReviewedBy END,
        ReviewedAt=CASE WHEN @ToStatus=2 THEN SYSUTCDATETIME() ELSE ReviewedAt END,
        ApprovedBy=CASE WHEN @ToStatus=3 THEN @ActionBy ELSE ApprovedBy END,
        ApprovedAt=CASE WHEN @ToStatus=3 THEN SYSUTCDATETIME() ELSE ApprovedAt END,
        PostedBy=CASE WHEN @ToStatus=4 THEN @ActionBy ELSE PostedBy END,
        PostedAt=CASE WHEN @ToStatus=4 THEN SYSUTCDATETIME() ELSE PostedAt END,
        ArchivedBy=CASE WHEN @ToStatus=5 THEN @ActionBy ELSE ArchivedBy END,
        ArchivedAt=CASE WHEN @ToStatus=5 THEN SYSUTCDATETIME() ELSE ArchivedAt END,
        RejectedBy=CASE WHEN @ToStatus=6 THEN @ActionBy ELSE RejectedBy END,
        RejectedAt=CASE WHEN @ToStatus=6 THEN SYSUTCDATETIME() ELSE RejectedAt END,
        RejectionReason=CASE WHEN @ToStatus=6 THEN @ActionNote ELSE RejectionReason END
    WHERE JournalID=@JournalID AND CompanyID=@CompanyID;

    INSERT dbo.Acc_JournalWorkflowHistory(JournalID,FromStatus,ToStatus,ActionBy,ActionNote)
    VALUES(@JournalID,@FromStatus,@ToStatus,@ActionBy,@ActionNote);

    INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,OperationType,ChangedBy,ChangeReason)
    VALUES(@CompanyID,N'Acc_JournalHeaders',CONVERT(nvarchar(150),@JournalID),
           CASE @ToStatus WHEN 4 THEN N'POST' WHEN 5 THEN N'ARCHIVE' WHEN 6 THEN N'REJECT' ELSE N'UPDATE' END,
           @ActionBy,@ActionNote);
    COMMIT;
END;
GO

/* Trial balance: posted/archived entries only (statuses 4 and 5). */
CREATE OR ALTER PROCEDURE dbo.Acc_Report_TrialBalance
    @CompanyID int,
    @DateFrom date,
    @DateTo date,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateTo < @DateFrom THROW 51020, N'تاريخ النهاية يجب ألا يسبق تاريخ البداية.', 1;
    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'TrialBalance',
               (SELECT CONVERT(nvarchar(10),@DateFrom,23) AS dateFrom,
                       CONVERT(nvarchar(10),@DateTo,23) AS dateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT p.CompanyID, p.CompanyNumber, p.CompanyNameAr, p.CompanyNameEn, p.CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo,
           m.MainAccountNo, m.MainAccountNameAr, m.MainAccountNameEn,
           a.SubAccountNo, a.SubAccountNameAr, a.SubAccountNameEn,
           SUM(d.DebitAmount) AS TotalDebit, SUM(d.CreditAmount) AS TotalCredit,
           SUM(d.DebitAmount-d.CreditAmount) AS NetBalance
    FROM dbo.Acc_JournalHeaders h
    JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=d.SubAccountID
    JOIN dbo.Acc_MainAccounts m ON m.MainAccountID=a.MainAccountID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=h.CompanyID
    WHERE h.CompanyID=@CompanyID AND h.JournalStatus IN (4,5)
      AND h.JournalDate BETWEEN @DateFrom AND @DateTo
    GROUP BY p.CompanyID,p.CompanyNumber,p.CompanyNameAr,p.CompanyNameEn,p.CompanyLogo,
             m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,
             a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn
    ORDER BY m.MainAccountNo,a.SubAccountNo;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_Report_AccountStatement
    @CompanyID int,
    @SubAccountID bigint,
    @DateFrom date,
    @DateTo date,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateTo < @DateFrom THROW 51021, N'تاريخ النهاية يجب ألا يسبق تاريخ البداية.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_SubAccounts WHERE CompanyID=@CompanyID AND SubAccountID=@SubAccountID)
        THROW 51022, N'الحساب غير موجود ضمن الشركة المحددة.', 1;

    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'AccountStatement',
               (SELECT @SubAccountID AS subAccountId, CONVERT(nvarchar(10),@DateFrom,23) AS dateFrom,
                       CONVERT(nvarchar(10),@DateTo,23) AS dateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    ;WITH Movements AS
    (
        SELECT h.JournalDate,h.JournalNumber,h.JournalID,d.LineNumber,d.LineDescription,
               d.DebitAmount,d.CreditAmount,
               SUM(d.DebitAmount-d.CreditAmount) OVER
                 (ORDER BY h.JournalDate,h.JournalID,d.LineNumber ROWS UNBOUNDED PRECEDING) AS RunningBalance
        FROM dbo.Acc_JournalHeaders h
        JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
        WHERE h.CompanyID=@CompanyID AND d.SubAccountID=@SubAccountID
          AND h.JournalStatus IN (4,5) AND h.JournalDate BETWEEN @DateFrom AND @DateTo
    )
    SELECT p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
           a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn,
           m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,
           @DateFrom AS DateFrom,@DateTo AS DateTo,
           JournalDate,JournalNumber,JournalID,LineNumber,LineDescription,
           DebitAmount,CreditAmount,RunningBalance
    FROM Movements
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=@SubAccountID
    JOIN dbo.Acc_MainAccounts m ON m.MainAccountID=a.MainAccountID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=@CompanyID
    ORDER BY JournalDate,JournalID,LineNumber;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_Report_CostCenterStatement
    @CompanyID int,
    @CostCenterID bigint,
    @DateFrom date,
    @DateTo date,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateTo < @DateFrom THROW 51023, N'تاريخ النهاية يجب ألا يسبق تاريخ البداية.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenters WHERE CompanyID=@CompanyID AND CostCenterID=@CostCenterID)
        THROW 51024, N'مركز التكلفة غير موجود ضمن الشركة المحددة.', 1;

    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'CostCenterStatement',
               (SELECT @CostCenterID AS costCenterId, CONVERT(nvarchar(10),@DateFrom,23) AS dateFrom,
                       CONVERT(nvarchar(10),@DateTo,23) AS dateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
           cc.CostCenterCode,cc.CostCenterName,
           h.JournalDate,h.JournalNumber,h.JournalID,d.LineNumber,
           a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn,
           d.LineDescription,d.DebitAmount,d.CreditAmount,
           d.DebitAmount-d.CreditAmount AS NetAmount
    FROM dbo.Acc_JournalHeaders h
    JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=d.SubAccountID
    JOIN dbo.Acc_CostCenters cc ON cc.CostCenterID=d.CostCenterID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=h.CompanyID
    WHERE h.CompanyID=@CompanyID AND cc.CostCenterID=@CostCenterID
      AND h.JournalStatus IN (4,5) AND h.JournalDate BETWEEN @DateFrom AND @DateTo
    ORDER BY h.JournalDate,h.JournalID,d.LineNumber;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_Report_IncomeStatement
    @CompanyID int,
    @DateFrom date,
    @DateTo date,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateTo < @DateFrom THROW 51025, N'تاريخ النهاية يجب ألا يسبق تاريخ البداية.', 1;
    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'IncomeStatement',
               (SELECT CONVERT(nvarchar(10),@DateFrom,23) AS dateFrom,
                       CONVERT(nvarchar(10),@DateTo,23) AS dateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
           m.AccountClass,m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,
           a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn,
           SUM(d.DebitAmount) AS TotalDebit,SUM(d.CreditAmount) AS TotalCredit,
           CASE WHEN m.AccountClass=4 THEN SUM(d.CreditAmount-d.DebitAmount)
                WHEN m.AccountClass=5 THEN SUM(d.DebitAmount-d.CreditAmount) END AS StatementAmount
    FROM dbo.Acc_JournalHeaders h
    JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=d.SubAccountID
    JOIN dbo.Acc_MainAccounts m ON m.MainAccountID=a.MainAccountID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=h.CompanyID
    WHERE h.CompanyID=@CompanyID AND h.JournalStatus IN (4,5)
      AND h.JournalDate BETWEEN @DateFrom AND @DateTo
      AND m.AccountClass IN (4,5)
    GROUP BY p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
             m.AccountClass,m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,
             a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn
    ORDER BY m.AccountClass,m.MainAccountNo,a.SubAccountNo;
END;
GO

/* General report data for expenses or revenues; classification comes from main account class. */
CREATE OR ALTER PROCEDURE dbo.Acc_Report_ExpenseRevenueAnalysis
    @CompanyID int,
    @AccountClass tinyint, -- 4 revenue, 5 expenses
    @DateFrom date,
    @DateTo date,
    @CostCenterID bigint = NULL,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @AccountClass NOT IN (4,5) THROW 51026, N'نوع التحليل يجب أن يكون إيرادات (4) أو مصروفات (5).', 1;
    IF @DateTo < @DateFrom THROW 51027, N'تاريخ النهاية يجب ألا يسبق تاريخ البداية.', 1;
    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'ExpenseRevenueAnalysis',
               (SELECT @AccountClass AS accountClass,@CostCenterID AS costCenterId,
                       CONVERT(nvarchar(10),@DateFrom,23) AS dateFrom,
                       CONVERT(nvarchar(10),@DateTo,23) AS dateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
           m.AccountClass,m.MainAccountNo,m.MainAccountNameAr,
           a.SubAccountNo,a.SubAccountNameAr,
           cc.CostCenterCode,cc.CostCenterName,
           SUM(d.DebitAmount) AS TotalDebit,SUM(d.CreditAmount) AS TotalCredit,
           CASE WHEN @AccountClass=4 THEN SUM(d.CreditAmount-d.DebitAmount)
                ELSE SUM(d.DebitAmount-d.CreditAmount) END AS NetAmount
    FROM dbo.Acc_JournalHeaders h
    JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=d.SubAccountID
    JOIN dbo.Acc_MainAccounts m ON m.MainAccountID=a.MainAccountID
    LEFT JOIN dbo.Acc_CostCenters cc ON cc.CostCenterID=d.CostCenterID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=h.CompanyID
    WHERE h.CompanyID=@CompanyID AND h.JournalStatus IN (4,5)
      AND h.JournalDate BETWEEN @DateFrom AND @DateTo
      AND m.AccountClass=@AccountClass
      AND (@CostCenterID IS NULL OR d.CostCenterID=@CostCenterID)
    GROUP BY p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
             m.AccountClass,m.MainAccountNo,m.MainAccountNameAr,
             a.SubAccountNo,a.SubAccountNameAr,cc.CostCenterCode,cc.CostCenterName
    ORDER BY m.MainAccountNo,a.SubAccountNo,cc.CostCenterCode;
END;
GO

/* Balance sheet report data; final presentation/grouping depends on approved chart-of-accounts mapping. */
CREATE OR ALTER PROCEDURE dbo.Acc_Report_BalanceSheet
    @CompanyID int,
    @AsOfDate date,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'BalanceSheet',
               (SELECT CONVERT(nvarchar(10),@AsOfDate,23) AS asOfDate FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
           m.AccountClass,m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,
           a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn,
           SUM(d.DebitAmount) AS TotalDebit,SUM(d.CreditAmount) AS TotalCredit,
           CASE WHEN m.AccountClass=1 THEN SUM(d.DebitAmount-d.CreditAmount)
                WHEN m.AccountClass IN (2,3) THEN SUM(d.CreditAmount-d.DebitAmount) END AS BalanceAmount
    FROM dbo.Acc_JournalHeaders h
    JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=d.SubAccountID
    JOIN dbo.Acc_MainAccounts m ON m.MainAccountID=a.MainAccountID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=h.CompanyID
    WHERE h.CompanyID=@CompanyID AND h.JournalStatus IN (4,5)
      AND h.JournalDate <= @AsOfDate AND m.AccountClass IN (1,2,3)
    GROUP BY p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
             m.AccountClass,m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,
             a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn
    ORDER BY m.AccountClass,m.MainAccountNo,a.SubAccountNo;
END;
GO

/* Cash-flow report is a movement dataset, not a final statutory statement until
   cash/bank accounts and activity classifications are mapped by the company. */
CREATE OR ALTER PROCEDURE dbo.Acc_Report_CashFlowMovements
    @CompanyID int,
    @DateFrom date,
    @DateTo date,
    @RequestedBy int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateTo < @DateFrom THROW 51028, N'تاريخ النهاية يجب ألا يسبق تاريخ البداية.', 1;
    IF @RequestedBy IS NOT NULL
        INSERT dbo.Acc_ReportRequestLog(CompanyID,RequestedBy,ReportCode,ParametersJson)
        VALUES(@CompanyID,@RequestedBy,N'CashFlowMovements',
               (SELECT CONVERT(nvarchar(10),@DateFrom,23) AS dateFrom,
                       CONVERT(nvarchar(10),@DateTo,23) AS dateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT p.CompanyNameAr,p.CompanyNameEn,p.CompanyNumber,p.CompanyLogo,
           h.JournalDate,h.JournalNumber,h.JournalID,
           a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn,
           cc.CostCenterCode,cc.CostCenterName,d.LineDescription,
           d.DebitAmount,d.CreditAmount,d.DebitAmount-d.CreditAmount AS NetMovement
    FROM dbo.Acc_JournalHeaders h
    JOIN dbo.Acc_JournalDetails d ON d.JournalID=h.JournalID
    JOIN dbo.Acc_SubAccounts a ON a.SubAccountID=d.SubAccountID
    LEFT JOIN dbo.Acc_CostCenters cc ON cc.CostCenterID=d.CostCenterID
    LEFT JOIN dbo.Acc_CompanyReportProfile p ON p.CompanyID=h.CompanyID
    WHERE h.CompanyID=@CompanyID AND h.JournalStatus IN (4,5)
      AND h.JournalDate BETWEEN @DateFrom AND @DateTo
    ORDER BY h.JournalDate,h.JournalID,d.LineNumber;
END;
GO

/* Useful read-only account hierarchy query. */
CREATE OR ALTER PROCEDURE dbo.Acc_Report_AccountDirectory
    @CompanyID int,
    @IncludeInactive bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT m.MainAccountID,m.MainAccountNo,m.MainAccountNameAr,m.MainAccountNameEn,m.AccountClass,
           a.SubAccountID,a.SubAccountNo,a.SubAccountNameAr,a.SubAccountNameEn,
           a.ParentSubAccountID,a.AccountLevel,a.IsPostingAccount,a.IsActive
    FROM dbo.Acc_MainAccounts m
    LEFT JOIN dbo.Acc_SubAccounts a ON a.MainAccountID=m.MainAccountID AND a.CompanyID=m.CompanyID
    WHERE m.CompanyID=@CompanyID
      AND (@IncludeInactive=1 OR (m.IsActive=1 AND (a.SubAccountID IS NULL OR a.IsActive=1)))
    ORDER BY m.MainAccountNo,a.SubAccountNo;
END;
GO

/* Implementation notes:
   1) Balance sheet and cash flow require company-approved mapping/classification
      rules before they can be treated as final statutory statements.
   2) A production-ready dynamic approval path needs configurable stage definitions
      and a per-journal workflow snapshot; this script supplies an auditable default
      transition path, not every company-specific workflow variant.
   3) This first pass does not include DELETE procedures for posted accounting
      records by design. Draft-only deletion should be implemented with the actual
      MADAR permission model and audit requirements.
   4) Company/user foreign keys must be wired to the real MADAR master tables after
      the schema script is reviewed.
*/

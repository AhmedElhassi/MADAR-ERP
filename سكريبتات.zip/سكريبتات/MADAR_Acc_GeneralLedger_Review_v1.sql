/*
  MADAR Enterprise ERP - General Ledger module
  File: MADAR_Acc_GeneralLedger_Review_v1.sql
  Target: SQL Server 2019+ (OPENJSON required; compatibility level 130+)
  Database: MADARERPDataBase

  REVIEW STATUS: REVIEW CANDIDATE V1 — NOT EXECUTED ON SQL SERVER.
  Do not deploy to production until run against a restored test database and integrated
  with MADAR's canonical base schema and number-to-Arabic-words function.

  IMPORTANT:
  - This script creates the Acc_ module tables and core stored procedures.
  - It does not create the database or duplicate Mng_Company / Mng_User.
  - Run first in a restored/test database. Review integration assumptions before production.
  - All date/time values are stored as UTC using SYSUTCDATETIME().
  - Journal status: 0 Draft, 1 PendingReview, 2 PendingApproval, 3 Approved,
                    4 Posted, 5 Archived, 6 Rejected, 7 Reversed.
  - The schema supports a configurable review/approval/archive workflow.
  - General Ledger currency is restricted to LYD (1 Dinar = 1000 Dirhams).
  - Uses the existing dbo.Tafkeet function only where explicitly wired by reviewed reports; this script does not create a duplicate function.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF DB_NAME() <> N'MADARERPDataBase'
    THROW 51000, 'Run this script in MADARERPDataBase.', 1;

IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NULL
    THROW 51001, 'Required table dbo.Mng_Company was not found.', 1;
IF OBJECT_ID(N'dbo.Mng_User', N'U') IS NULL
    THROW 51002, 'Required table dbo.Mng_User was not found.', 1;
IF COL_LENGTH(N'dbo.Mng_Company', N'CmpID') IS NULL
    THROW 51003, 'dbo.Mng_Company must contain CmpID.', 1;
IF COL_LENGTH(N'dbo.Mng_User', N'UsrID') IS NULL
    THROW 51004, 'dbo.Mng_User must contain UsrID.', 1;

IF OBJECT_ID(N'dbo.Acc_FiscalYear', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_FiscalPeriod', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_MainAccount', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_SubAccount', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_CostCenter', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_JournalHeader', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_JournalLine', N'U') IS NOT NULL
    THROW 51005, 'Acc module tables already exist. Use a clean test database or a reviewed migration script.', 1;

BEGIN TRY
BEGIN TRANSACTION;

CREATE TABLE dbo.Acc_CompanySettings
(
    CompanyID INT NOT NULL CONSTRAINT PK_Acc_CompanySettings PRIMARY KEY,
    CurrencyCode CHAR(3) NOT NULL CONSTRAINT DF_Acc_Settings_Currency DEFAULT ('LYD'),
    CONSTRAINT CK_Acc_Settings_Currency_LYD CHECK (CurrencyCode = 'LYD'),
    RequireReview BIT NOT NULL CONSTRAINT DF_Acc_Settings_Review DEFAULT (1),
    RequireApproval BIT NOT NULL CONSTRAINT DF_Acc_Settings_Approval DEFAULT (1),
    RequireArchive BIT NOT NULL CONSTRAINT DF_Acc_Settings_Archive DEFAULT (1),
    AllowPrintBeforeApproval BIT NOT NULL CONSTRAINT DF_Acc_Settings_Print DEFAULT (1),
    RequireCostCenter BIT NOT NULL CONSTRAINT DF_Acc_Settings_CC DEFAULT (0),
    AllowManualJournal BIT NOT NULL CONSTRAINT DF_Acc_Settings_Manual DEFAULT (1),
    AllowAutomatedJournal BIT NOT NULL CONSTRAINT DF_Acc_Settings_Auto DEFAULT (1),
    ModifiedBy INT NULL,
    ModifiedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_Settings_ModifiedAt DEFAULT (SYSUTCDATETIME()),
    RowVer ROWVERSION,
    CONSTRAINT FK_Acc_Settings_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_Settings_User FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_FiscalYear
(
    FiscalYearID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_FiscalYear PRIMARY KEY,
    CompanyID INT NOT NULL,
    YearCode INT NOT NULL,
    YearName NVARCHAR(100) NOT NULL,
    DateFrom DATE NOT NULL,
    DateTo DATE NOT NULL,
    YearStatus TINYINT NOT NULL CONSTRAINT DF_Acc_FiscalYear_Status DEFAULT (0), -- 0 open, 1 closing, 2 closed
    CreatedBy INT NOT NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_FiscalYear_CreatedAt DEFAULT (SYSUTCDATETIME()),
    ModifiedBy INT NULL,
    ModifiedAt DATETIME2(0) NULL,
    RowVer ROWVERSION,
    CONSTRAINT UQ_Acc_FiscalYear_Company_Year UNIQUE (CompanyID, YearCode),
    CONSTRAINT UQ_Acc_FiscalYear_Company_ID UNIQUE (CompanyID, FiscalYearID),
    CONSTRAINT CK_Acc_FiscalYear_Dates CHECK (DateFrom <= DateTo),
    CONSTRAINT CK_Acc_FiscalYear_Status CHECK (YearStatus IN (0,1,2)),
    CONSTRAINT FK_Acc_FiscalYear_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_FiscalYear_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_FiscalYear_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_FiscalPeriod
(
    FiscalPeriodID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_FiscalPeriod PRIMARY KEY,
    CompanyID INT NOT NULL,
    FiscalYearID BIGINT NOT NULL,
    PeriodNo TINYINT NOT NULL,
    PeriodName NVARCHAR(100) NOT NULL,
    DateFrom DATE NOT NULL,
    DateTo DATE NOT NULL,
    PeriodStatus TINYINT NOT NULL CONSTRAINT DF_Acc_FiscalPeriod_Status DEFAULT (0), -- 0 open, 1 closing, 2 closed
    CreatedBy INT NOT NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_FiscalPeriod_CreatedAt DEFAULT (SYSUTCDATETIME()),
    RowVer ROWVERSION,
    CONSTRAINT UQ_Acc_FiscalPeriod_Company_ID UNIQUE (CompanyID, FiscalPeriodID),
    CONSTRAINT UQ_Acc_FiscalPeriod_Year_No UNIQUE (CompanyID, FiscalYearID, PeriodNo),
    CONSTRAINT CK_Acc_FiscalPeriod_No CHECK (PeriodNo BETWEEN 1 AND 13),
    CONSTRAINT CK_Acc_FiscalPeriod_Dates CHECK (DateFrom <= DateTo),
    CONSTRAINT CK_Acc_FiscalPeriod_Status CHECK (PeriodStatus IN (0,1,2)),
    CONSTRAINT FK_Acc_FiscalPeriod_Year FOREIGN KEY (CompanyID, FiscalYearID) REFERENCES dbo.Acc_FiscalYear(CompanyID, FiscalYearID),
    CONSTRAINT FK_Acc_FiscalPeriod_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_MainAccount
(
    MainAccountID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_MainAccount PRIMARY KEY,
    CompanyID INT NOT NULL,
    MainAccountCode NVARCHAR(30) NOT NULL,
    MainAccountNameAr NVARCHAR(200) NOT NULL,
    MainAccountNameEn NVARCHAR(200) NULL,
    AccountCategory TINYINT NOT NULL, -- 1 assets, 2 liabilities, 3 equity, 4 revenue, 5 expenses
    NormalBalance CHAR(1) NOT NULL, -- D debit, C credit
    IsActive BIT NOT NULL CONSTRAINT DF_Acc_MainAccount_Active DEFAULT (1),
    AllowPosting BIT NOT NULL CONSTRAINT DF_Acc_MainAccount_Posting DEFAULT (0),
    SortOrder INT NOT NULL CONSTRAINT DF_Acc_MainAccount_Sort DEFAULT (0),
    CreatedBy INT NOT NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_MainAccount_CreatedAt DEFAULT (SYSUTCDATETIME()),
    ModifiedBy INT NULL,
    ModifiedAt DATETIME2(0) NULL,
    RowVer ROWVERSION,
    CONSTRAINT UQ_Acc_MainAccount_Company_Code UNIQUE (CompanyID, MainAccountCode),
    CONSTRAINT UQ_Acc_MainAccount_Company_ID UNIQUE (CompanyID, MainAccountID),
    CONSTRAINT CK_Acc_MainAccount_Category CHECK (AccountCategory BETWEEN 1 AND 5),
    CONSTRAINT CK_Acc_MainAccount_Balance CHECK (NormalBalance IN ('D','C')),
    CONSTRAINT FK_Acc_MainAccount_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_MainAccount_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_MainAccount_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_SubAccount
(
    SubAccountID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_SubAccount PRIMARY KEY,
    CompanyID INT NOT NULL,
    MainAccountID BIGINT NOT NULL,
    ParentSubAccountID BIGINT NULL,
    AccountCode NVARCHAR(60) NOT NULL,
    AccountNameAr NVARCHAR(200) NOT NULL,
    AccountNameEn NVARCHAR(200) NULL,
    AccountLevel SMALLINT NOT NULL CONSTRAINT DF_Acc_SubAccount_Level DEFAULT (1),
    AccountCategory TINYINT NOT NULL,
    NormalBalance CHAR(1) NOT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_Acc_SubAccount_Active DEFAULT (1),
    AllowPosting BIT NOT NULL CONSTRAINT DF_Acc_SubAccount_Posting DEFAULT (1),
    IsCashEquivalent BIT NOT NULL CONSTRAINT DF_Acc_SubAccount_Cash DEFAULT (0),
    CashFlowCategory TINYINT NULL, -- 1 operating, 2 investing, 3 financing
    CreatedBy INT NOT NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_SubAccount_CreatedAt DEFAULT (SYSUTCDATETIME()),
    ModifiedBy INT NULL,
    ModifiedAt DATETIME2(0) NULL,
    RowVer ROWVERSION,
    CONSTRAINT UQ_Acc_SubAccount_Company_Code UNIQUE (CompanyID, AccountCode),
    CONSTRAINT UQ_Acc_SubAccount_Company_ID UNIQUE (CompanyID, SubAccountID),
    CONSTRAINT CK_Acc_SubAccount_Level CHECK (AccountLevel >= 1),
    CONSTRAINT CK_Acc_SubAccount_Category CHECK (AccountCategory BETWEEN 1 AND 5),
    CONSTRAINT CK_Acc_SubAccount_Balance CHECK (NormalBalance IN ('D','C')),
    CONSTRAINT CK_Acc_SubAccount_CashFlow CHECK (CashFlowCategory IS NULL OR CashFlowCategory BETWEEN 1 AND 3),
    CONSTRAINT FK_Acc_SubAccount_Main FOREIGN KEY (CompanyID, MainAccountID) REFERENCES dbo.Acc_MainAccount(CompanyID, MainAccountID),
    CONSTRAINT FK_Acc_SubAccount_Parent FOREIGN KEY (CompanyID, ParentSubAccountID) REFERENCES dbo.Acc_SubAccount(CompanyID, SubAccountID),
    CONSTRAINT FK_Acc_SubAccount_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_SubAccount_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_CostCenter
(
    CostCenterID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_CostCenter PRIMARY KEY,
    CompanyID INT NOT NULL,
    ParentCostCenterID BIGINT NULL,
    CostCenterCode NVARCHAR(60) NOT NULL,
    CostCenterNameAr NVARCHAR(200) NOT NULL,
    CostCenterNameEn NVARCHAR(200) NULL,
    CenterLevel SMALLINT NOT NULL CONSTRAINT DF_Acc_CostCenter_Level DEFAULT (1),
    IsActive BIT NOT NULL CONSTRAINT DF_Acc_CostCenter_Active DEFAULT (1),
    CreatedBy INT NOT NULL,
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CostCenter_CreatedAt DEFAULT (SYSUTCDATETIME()),
    ModifiedBy INT NULL,
    ModifiedAt DATETIME2(0) NULL,
    RowVer ROWVERSION,
    CONSTRAINT UQ_Acc_CostCenter_Company_Code UNIQUE (CompanyID, CostCenterCode),
    CONSTRAINT UQ_Acc_CostCenter_Company_ID UNIQUE (CompanyID, CostCenterID),
    CONSTRAINT CK_Acc_CostCenter_Level CHECK (CenterLevel >= 1),
    CONSTRAINT FK_Acc_CostCenter_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_CostCenter_Parent FOREIGN KEY (CompanyID, ParentCostCenterID) REFERENCES dbo.Acc_CostCenter(CompanyID, CostCenterID),
    CONSTRAINT FK_Acc_CostCenter_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_CostCenter_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_JournalHeader
(
    JournalID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalHeader PRIMARY KEY,
    CompanyID INT NOT NULL,
    FiscalYearID BIGINT NOT NULL,
    FiscalPeriodID BIGINT NOT NULL,
    JournalNo BIGINT NOT NULL,
    JournalDate DATE NOT NULL,
    JournalType TINYINT NOT NULL, -- 1 manual, 2 automated, 3 opening, 4 adjustment, 5 closing
    SourceSystemID TINYINT NULL,
    SourceReference NVARCHAR(100) NULL,
    ExternalRequestKey NVARCHAR(150) NULL,
    Description NVARCHAR(500) NOT NULL,
    JournalStatus TINYINT NOT NULL CONSTRAINT DF_Acc_JournalHeader_Status DEFAULT (0),
    PreparedBy INT NOT NULL,
    PreparedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_JournalHeader_PreparedAt DEFAULT (SYSUTCDATETIME()),
    ReviewedBy INT NULL,
    ReviewedAt DATETIME2(0) NULL,
    ApprovedBy INT NULL,
    ApprovedAt DATETIME2(0) NULL,
    PostedBy INT NULL,
    PostedAt DATETIME2(0) NULL,
    ArchivedBy INT NULL,
    ArchivedAt DATETIME2(0) NULL,
    RejectedBy INT NULL,
    RejectedAt DATETIME2(0) NULL,
    RejectionReason NVARCHAR(1000) NULL,
    TotalDebit DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalHeader_Debit DEFAULT (0),
    TotalCredit DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalHeader_Credit DEFAULT (0),
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_JournalHeader_CreatedAt DEFAULT (SYSUTCDATETIME()),
    ModifiedBy INT NULL,
    ModifiedAt DATETIME2(0) NULL,
    RowVer ROWVERSION,
    CONSTRAINT UQ_Acc_JournalHeader_Company_Journal UNIQUE (CompanyID, JournalID),
    CONSTRAINT UQ_Acc_JournalHeader_Number UNIQUE (CompanyID, FiscalYearID, FiscalPeriodID, JournalNo),
    CONSTRAINT CK_Acc_JournalHeader_Type CHECK (JournalType BETWEEN 1 AND 5),
    CONSTRAINT CK_Acc_JournalHeader_Status CHECK (JournalStatus BETWEEN 0 AND 7),
    CONSTRAINT CK_Acc_JournalHeader_Totals CHECK (TotalDebit >= 0 AND TotalCredit >= 0),
    CONSTRAINT FK_Acc_JournalHeader_Year FOREIGN KEY (CompanyID, FiscalYearID) REFERENCES dbo.Acc_FiscalYear(CompanyID, FiscalYearID),
    CONSTRAINT FK_Acc_JournalHeader_Period FOREIGN KEY (CompanyID, FiscalPeriodID) REFERENCES dbo.Acc_FiscalPeriod(CompanyID, FiscalPeriodID),
    CONSTRAINT FK_Acc_JournalHeader_PreparedBy FOREIGN KEY (PreparedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_JournalHeader_ReviewedBy FOREIGN KEY (ReviewedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_JournalHeader_ApprovedBy FOREIGN KEY (ApprovedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_JournalHeader_PostedBy FOREIGN KEY (PostedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_JournalHeader_ArchivedBy FOREIGN KEY (ArchivedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_JournalHeader_RejectedBy FOREIGN KEY (RejectedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_JournalHeader_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
);
CREATE UNIQUE INDEX UX_Acc_JournalHeader_ExternalRequest
ON dbo.Acc_JournalHeader(CompanyID, SourceSystemID, ExternalRequestKey)
WHERE ExternalRequestKey IS NOT NULL;

CREATE TABLE dbo.Acc_JournalLine
(
    JournalLineID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalLine PRIMARY KEY,
    CompanyID INT NOT NULL,
    JournalID BIGINT NOT NULL,
    LineNum INT NOT NULL,
    SubAccountID BIGINT NOT NULL,
    CostCenterID BIGINT NULL,
    LineDescription NVARCHAR(500) NULL,
    DebitAmount DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalLine_Debit DEFAULT (0),
    CreditAmount DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalLine_Credit DEFAULT (0),
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_JournalLine_CreatedAt DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_Acc_JournalLine_Company_ID UNIQUE (CompanyID, JournalLineID),
    CONSTRAINT UQ_Acc_JournalLine_Journal_Line UNIQUE (CompanyID, JournalID, LineNum),
    CONSTRAINT CK_Acc_JournalLine_LineNum CHECK (LineNum > 0),
    CONSTRAINT CK_Acc_JournalLine_Amounts CHECK (DebitAmount >= 0 AND CreditAmount >= 0 AND NOT (DebitAmount > 0 AND CreditAmount > 0)),
    CONSTRAINT FK_Acc_JournalLine_Header FOREIGN KEY (CompanyID, JournalID) REFERENCES dbo.Acc_JournalHeader(CompanyID, JournalID),
    CONSTRAINT FK_Acc_JournalLine_Account FOREIGN KEY (CompanyID, SubAccountID) REFERENCES dbo.Acc_SubAccount(CompanyID, SubAccountID),
    CONSTRAINT FK_Acc_JournalLine_CostCenter FOREIGN KEY (CompanyID, CostCenterID) REFERENCES dbo.Acc_CostCenter(CompanyID, CostCenterID)
);

CREATE TABLE dbo.Acc_WorkflowHistory
(
    WorkflowHistoryID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_WorkflowHistory PRIMARY KEY,
    CompanyID INT NOT NULL,
    JournalID BIGINT NOT NULL,
    FromStatus TINYINT NULL,
    ToStatus TINYINT NOT NULL,
    ActionCode NVARCHAR(30) NOT NULL,
    ActionBy INT NOT NULL,
    ActionAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_WorkflowHistory_At DEFAULT (SYSUTCDATETIME()),
    ActionNote NVARCHAR(1000) NULL,
    CONSTRAINT FK_Acc_WorkflowHistory_Journal FOREIGN KEY (CompanyID, JournalID) REFERENCES dbo.Acc_JournalHeader(CompanyID, JournalID),
    CONSTRAINT FK_Acc_WorkflowHistory_User FOREIGN KEY (ActionBy) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_AuditLog
(
    AuditLogID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_AuditLog PRIMARY KEY,
    CompanyID INT NOT NULL,
    EntityName SYSNAME NOT NULL,
    EntityID NVARCHAR(100) NOT NULL,
    ActionType NVARCHAR(20) NOT NULL,
    BeforeData NVARCHAR(MAX) NULL,
    AfterData NVARCHAR(MAX) NULL,
    ChangedBy INT NOT NULL,
    ChangedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_AuditLog_At DEFAULT (SYSUTCDATETIME()),
    ClientApp NVARCHAR(150) NULL,
    CorrelationID UNIQUEIDENTIFIER NULL,
    CONSTRAINT FK_Acc_AuditLog_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_AuditLog_User FOREIGN KEY (ChangedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT CK_Acc_AuditLog_Action CHECK (ActionType IN (N'INSERT',N'UPDATE',N'DELETE',N'MOVE',N'POST',N'APPROVE',N'ARCHIVE',N'REJECT',N'PRINT'))
);

CREATE TABLE dbo.Acc_ReportRequestLog
(
    ReportRequestID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_ReportRequestLog PRIMARY KEY,
    CompanyID INT NOT NULL,
    ReportCode NVARCHAR(80) NOT NULL,
    RequestedBy INT NOT NULL,
    RequestedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_ReportRequestLog_At DEFAULT (SYSUTCDATETIME()),
    ParametersJson NVARCHAR(MAX) NULL,
    OutputFormat NVARCHAR(10) NULL,
    CONSTRAINT FK_Acc_ReportRequestLog_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_ReportRequestLog_User FOREIGN KEY (RequestedBy) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT CK_Acc_ReportRequestLog_Json CHECK (ParametersJson IS NULL OR ISJSON(ParametersJson) = 1)
);

CREATE INDEX IX_Acc_JournalHeader_Company_Date_Status
ON dbo.Acc_JournalHeader(CompanyID, JournalDate, JournalStatus)
INCLUDE (JournalNo, FiscalYearID, FiscalPeriodID, TotalDebit, TotalCredit);
CREATE INDEX IX_Acc_JournalLine_Company_Account
ON dbo.Acc_JournalLine(CompanyID, SubAccountID, JournalID)
INCLUDE (DebitAmount, CreditAmount, CostCenterID);
CREATE INDEX IX_Acc_JournalLine_Company_CostCenter
ON dbo.Acc_JournalLine(CompanyID, CostCenterID, JournalID)
INCLUDE (SubAccountID, DebitAmount, CreditAmount);
CREATE INDEX IX_Acc_AuditLog_Company_Entity
ON dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ChangedAt DESC);

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

CREATE OR ALTER VIEW dbo.Acc_vPostedLedger
AS
SELECT h.CompanyID, h.FiscalYearID, h.FiscalPeriodID, h.JournalID, h.JournalNo,
       h.JournalDate, h.JournalType, h.Description AS JournalDescription,
       h.PreparedBy, h.ReviewedBy, h.ApprovedBy, h.PostedBy, h.PostedAt,
       l.JournalLineID, l.LineNum, l.SubAccountID, a.AccountCode, a.AccountNameAr,
       a.AccountNameEn, a.MainAccountID, m.MainAccountCode, m.MainAccountNameAr,
       m.MainAccountNameEn, l.CostCenterID, c.CostCenterCode, c.CostCenterNameAr,
       c.CostCenterNameEn, l.LineDescription, l.DebitAmount, l.CreditAmount
FROM dbo.Acc_JournalHeader h
JOIN dbo.Acc_JournalLine l ON l.CompanyID=h.CompanyID AND l.JournalID=h.JournalID
JOIN dbo.Acc_SubAccount a ON a.CompanyID=l.CompanyID AND a.SubAccountID=l.SubAccountID
JOIN dbo.Acc_MainAccount m ON m.CompanyID=a.CompanyID AND m.MainAccountID=a.MainAccountID
LEFT JOIN dbo.Acc_CostCenter c ON c.CompanyID=l.CompanyID AND c.CostCenterID=l.CostCenterID
WHERE h.JournalStatus IN (4,5);
GO

CREATE OR ALTER PROCEDURE dbo.Acc_CreateJournalDraft
    @CompanyID INT,
    @FiscalYearID BIGINT,
    @FiscalPeriodID BIGINT,
    @JournalDate DATE,
    @JournalType TINYINT,
    @Description NVARCHAR(500),
    @PreparedBy INT,
    @LinesJson NVARCHAR(MAX),
    @SourceSystemID TINYINT = NULL,
    @SourceReference NVARCHAR(100) = NULL,
    @ExternalRequestKey NVARCHAR(150) = NULL,
    @JournalID BIGINT OUTPUT,
    @JournalNo BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF ISJSON(@LinesJson) <> 1 THROW 51100, 'LinesJson must be a valid JSON array.', 1;
    IF @JournalType NOT BETWEEN 1 AND 5 THROW 51101, 'Invalid journal type.', 1;
    IF NULLIF(LTRIM(RTRIM(@Description)), N'') IS NULL THROW 51102, 'Journal description is required.', 1;

    DECLARE @Lines TABLE
    (
        LineNum INT NOT NULL PRIMARY KEY,
        SubAccountID BIGINT NOT NULL,
        CostCenterID BIGINT NULL,
        LineDescription NVARCHAR(500) NULL,
        DebitAmount DECIMAL(19,4) NOT NULL,
        CreditAmount DECIMAL(19,4) NOT NULL
    );

    INSERT INTO @Lines(LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
    SELECT LineNum, SubAccountID, CostCenterID, LineDescription,
           COALESCE(DebitAmount,0), COALESCE(CreditAmount,0)
    FROM OPENJSON(@LinesJson)
    WITH
    (
        LineNum INT '$.lineNum',
        SubAccountID BIGINT '$.subAccountId',
        CostCenterID BIGINT '$.costCenterId',
        LineDescription NVARCHAR(500) '$.description',
        DebitAmount DECIMAL(19,4) '$.debit',
        CreditAmount DECIMAL(19,4) '$.credit'
    );

    IF NOT EXISTS (SELECT 1 FROM @Lines) THROW 51103, 'At least one journal line is required.', 1;
    IF EXISTS (SELECT 1 FROM @Lines WHERE LineNum IS NULL OR LineNum <= 0 OR SubAccountID IS NULL OR DebitAmount < 0 OR CreditAmount < 0 OR (DebitAmount > 0 AND CreditAmount > 0) OR (DebitAmount = 0 AND CreditAmount = 0))
        THROW 51104, 'Each line needs a valid account and exactly one positive debit or credit amount.', 1;

    BEGIN TRY
      BEGIN TRANSACTION;

      IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID=@CompanyID)
        THROW 51105, 'Company does not exist.', 1;
      IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID=@PreparedBy)
        THROW 51106, 'Preparing user does not exist.', 1;
      IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID)
        INSERT dbo.Acc_CompanySettings(CompanyID) VALUES (@CompanyID);

      IF NOT EXISTS
      (
        SELECT 1 FROM dbo.Acc_FiscalYear y
        JOIN dbo.Acc_FiscalPeriod p ON p.CompanyID=y.CompanyID AND p.FiscalYearID=y.FiscalYearID
        WHERE y.CompanyID=@CompanyID AND y.FiscalYearID=@FiscalYearID
          AND p.FiscalPeriodID=@FiscalPeriodID
          AND @JournalDate BETWEEN y.DateFrom AND y.DateTo
          AND @JournalDate BETWEEN p.DateFrom AND p.DateTo
          AND y.YearStatus=0 AND p.PeriodStatus=0
      ) THROW 51107, 'Journal date is outside an open fiscal year/period.', 1;

      IF EXISTS
      (
        SELECT 1 FROM @Lines x
        LEFT JOIN dbo.Acc_SubAccount a ON a.CompanyID=@CompanyID AND a.SubAccountID=x.SubAccountID
        WHERE a.SubAccountID IS NULL OR a.IsActive=0 OR a.AllowPosting=0
      ) THROW 51108, 'One or more accounts are invalid, inactive, or not postable.', 1;

      IF EXISTS
      (
        SELECT 1 FROM @Lines x
        LEFT JOIN dbo.Acc_CostCenter c ON c.CompanyID=@CompanyID AND c.CostCenterID=x.CostCenterID
        WHERE x.CostCenterID IS NOT NULL AND (c.CostCenterID IS NULL OR c.IsActive=0)
      ) THROW 51109, 'One or more cost centers are invalid or inactive.', 1;

      IF EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID AND RequireCostCenter=1)
         AND EXISTS (SELECT 1 FROM @Lines WHERE CostCenterID IS NULL)
        THROW 51110, 'This company requires a cost center on every journal line.', 1;

      IF @JournalType=1 AND EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID AND AllowManualJournal=0)
        THROW 51111, 'Manual journals are disabled for this company.', 1;
      IF @JournalType=2 AND EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID AND AllowAutomatedJournal=0)
        THROW 51112, 'Automated journals are disabled for this company.', 1;

      IF @ExternalRequestKey IS NOT NULL AND EXISTS
        (SELECT 1 FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK)
         WHERE CompanyID=@CompanyID AND SourceSystemID=@SourceSystemID AND ExternalRequestKey=@ExternalRequestKey)
        THROW 51113, 'Duplicate external request key for this company/source.', 1;

      SELECT @JournalNo=ISNULL(MAX(JournalNo),0)+1
      FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK)
      WHERE CompanyID=@CompanyID AND FiscalYearID=@FiscalYearID AND FiscalPeriodID=@FiscalPeriodID;

      INSERT dbo.Acc_JournalHeader
      (CompanyID,FiscalYearID,FiscalPeriodID,JournalNo,JournalDate,JournalType,SourceSystemID,SourceReference,ExternalRequestKey,Description,JournalStatus,PreparedBy)
      VALUES
      (@CompanyID,@FiscalYearID,@FiscalPeriodID,@JournalNo,@JournalDate,@JournalType,@SourceSystemID,@SourceReference,@ExternalRequestKey,@Description,0,@PreparedBy);

      SET @JournalID=SCOPE_IDENTITY();

      INSERT dbo.Acc_JournalLine(CompanyID,JournalID,LineNum,SubAccountID,CostCenterID,LineDescription,DebitAmount,CreditAmount)
      SELECT @CompanyID,@JournalID,LineNum,SubAccountID,CostCenterID,LineDescription,DebitAmount,CreditAmount
      FROM @Lines;

      INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
      VALUES(@CompanyID,@JournalID,NULL,0,N'CREATE_DRAFT',@PreparedBy,N'Created as draft');

      INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,ActionType,AfterData,ChangedBy)
      VALUES(@CompanyID,N'Acc_JournalHeader',CONVERT(NVARCHAR(100),@JournalID),N'INSERT',
             (SELECT @JournalNo AS JournalNo,@JournalDate AS JournalDate,@JournalType AS JournalType,@Description AS Description FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
             @PreparedBy);

      COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
      IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
      THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SubmitJournalForReview
    @CompanyID INT, @JournalID BIGINT, @ActionBy INT, @Note NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Status TINYINT, @RequireReview BIT, @RequireApproval BIT, @Debit DECIMAL(19,4), @Credit DECIMAL(19,4);
  SELECT @Status=JournalStatus FROM dbo.Acc_JournalHeader WITH (UPDLOCK,HOLDLOCK)
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF @Status IS NULL THROW 51200,'Journal not found for this company.',1;
  IF @Status NOT IN (0,6) THROW 51201,'Only a draft or rejected journal can be submitted.',1;
  SELECT @Debit=SUM(DebitAmount),@Credit=SUM(CreditAmount) FROM dbo.Acc_JournalLine WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF ISNULL(@Debit,0)<=0 OR ISNULL(@Credit,0)<=0 THROW 51202,'Journal must contain debit and credit amounts.',1;
  SELECT @RequireReview=RequireReview, @RequireApproval=RequireApproval
  FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID;
  DECLARE @ToStatus TINYINT =
      CASE WHEN ISNULL(@RequireReview,1)=1 THEN 1
           WHEN ISNULL(@RequireApproval,1)=1 THEN 2
           ELSE 3 END;
  UPDATE dbo.Acc_JournalHeader SET JournalStatus=@ToStatus,TotalDebit=@Debit,TotalCredit=@Credit,
      RejectedBy=NULL,RejectedAt=NULL,RejectionReason=NULL,ModifiedBy=@ActionBy,ModifiedAt=SYSUTCDATETIME()
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
  VALUES(@CompanyID,@JournalID,@Status,@ToStatus,N'SUBMIT_REVIEW',@ActionBy,@Note);
  COMMIT TRANSACTION;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK TRANSACTION; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReviewJournal
    @CompanyID INT, @JournalID BIGINT, @ReviewerID INT, @Approve BIT, @Note NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Status TINYINT,@RequireApproval BIT,@Debit DECIMAL(19,4),@Credit DECIMAL(19,4),@ToStatus TINYINT;
  SELECT @Status=JournalStatus FROM dbo.Acc_JournalHeader WITH (UPDLOCK,HOLDLOCK)
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF @Status IS NULL THROW 51210,'Journal not found for this company.',1;
  IF @Status<>1 THROW 51211,'Journal is not awaiting review.',1;
  IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID=@CompanyID AND JournalID=@JournalID AND PreparedBy=@ReviewerID)
    THROW 51213,'The preparer cannot review their own journal.',1;
  IF @Approve=0
  BEGIN
   UPDATE dbo.Acc_JournalHeader SET JournalStatus=6,RejectedBy=@ReviewerID,RejectedAt=SYSUTCDATETIME(),
     RejectionReason=@Note,ModifiedBy=@ReviewerID,ModifiedAt=SYSUTCDATETIME()
   WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
   INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
   VALUES(@CompanyID,@JournalID,@Status,6,N'REVIEW_REJECT',@ReviewerID,@Note);
   INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,ActionType,AfterData,ChangedBy)
   VALUES(@CompanyID,N'Acc_JournalHeader',CONVERT(NVARCHAR(100),@JournalID),N'REJECT',
          (SELECT @Note AS Reason FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),@ReviewerID);
  END
  ELSE
  BEGIN
   SELECT @Debit=SUM(DebitAmount),@Credit=SUM(CreditAmount) FROM dbo.Acc_JournalLine WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
   IF ISNULL(@Debit,0)<=0 OR ISNULL(@Credit,0)<=0 OR ABS(@Debit-@Credit)>0.0000 THROW 51212,'Journal must be balanced before review can pass.',1;
   SELECT @RequireApproval=RequireApproval FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID;
   SET @ToStatus=CASE WHEN ISNULL(@RequireApproval,1)=1 THEN 2 ELSE 3 END;
   UPDATE dbo.Acc_JournalHeader SET JournalStatus=@ToStatus,ReviewedBy=@ReviewerID,ReviewedAt=SYSUTCDATETIME(),
      TotalDebit=@Debit,TotalCredit=@Credit,ModifiedBy=@ReviewerID,ModifiedAt=SYSUTCDATETIME()
   WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
   INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
   VALUES(@CompanyID,@JournalID,@Status,@ToStatus,N'REVIEW_PASS',@ReviewerID,@Note);
  END
  COMMIT TRANSACTION;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK TRANSACTION; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ApproveJournal
    @CompanyID INT, @JournalID BIGINT, @ApproverID INT, @Approve BIT, @Note NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Status TINYINT,@RequireArchive BIT;
  SELECT @Status=JournalStatus FROM dbo.Acc_JournalHeader WITH (UPDLOCK,HOLDLOCK)
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF @Status IS NULL THROW 51220,'Journal not found for this company.',1;
  IF @Status<>2 THROW 51221,'Journal is not awaiting approval.',1;
  IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID=@CompanyID AND JournalID=@JournalID AND (PreparedBy=@ApproverID OR ReviewedBy=@ApproverID))
    THROW 51223,'The preparer or reviewer cannot approve the same journal.',1;
  IF @Approve=0
  BEGIN
   UPDATE dbo.Acc_JournalHeader SET JournalStatus=6,RejectedBy=@ApproverID,RejectedAt=SYSUTCDATETIME(),
      RejectionReason=@Note,ModifiedBy=@ApproverID,ModifiedAt=SYSUTCDATETIME()
   WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
   INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
   VALUES(@CompanyID,@JournalID,@Status,6,N'APPROVAL_REJECT',@ApproverID,@Note);
   INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,ActionType,AfterData,ChangedBy)
   VALUES(@CompanyID,N'Acc_JournalHeader',CONVERT(NVARCHAR(100),@JournalID),N'REJECT',
          (SELECT @Note AS Reason FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),@ApproverID);
  END
  ELSE
  BEGIN
   SELECT @RequireArchive=RequireArchive FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID;
   UPDATE dbo.Acc_JournalHeader SET JournalStatus=3,ApprovedBy=@ApproverID,ApprovedAt=SYSUTCDATETIME(),
       ModifiedBy=@ApproverID,ModifiedAt=SYSUTCDATETIME()
   WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
   INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
   VALUES(@CompanyID,@JournalID,@Status,3,N'APPROVE',@ApproverID,@Note);
  END
  COMMIT TRANSACTION;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK TRANSACTION; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_PostJournal
    @CompanyID INT, @JournalID BIGINT, @PostedBy INT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Status TINYINT,@JournalDate DATE,@YearID BIGINT,@PeriodID BIGINT,@Debit DECIMAL(19,4),@Credit DECIMAL(19,4);
  SELECT @Status=JournalStatus,@JournalDate=JournalDate,@YearID=FiscalYearID,@PeriodID=FiscalPeriodID
  FROM dbo.Acc_JournalHeader WITH (UPDLOCK,HOLDLOCK)
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF @Status IS NULL THROW 51230,'Journal not found for this company.',1;
  IF @Status<>3 THROW 51231,'Only an approved journal can be posted.',1;
  IF NOT EXISTS (SELECT 1 FROM dbo.Acc_FiscalYear WHERE CompanyID=@CompanyID AND FiscalYearID=@YearID AND YearStatus=0)
    THROW 51232,'Fiscal year is not open.',1;
  IF NOT EXISTS (SELECT 1 FROM dbo.Acc_FiscalPeriod WHERE CompanyID=@CompanyID AND FiscalPeriodID=@PeriodID AND PeriodStatus=0 AND @JournalDate BETWEEN DateFrom AND DateTo)
    THROW 51233,'Fiscal period is not open or does not contain the journal date.',1;
  SELECT @Debit=SUM(DebitAmount),@Credit=SUM(CreditAmount)
  FROM dbo.Acc_JournalLine WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF ISNULL(@Debit,0)<=0 OR ISNULL(@Credit,0)<=0 OR ABS(@Debit-@Credit)>0.0000
    THROW 51234,'Cannot post an empty or unbalanced journal.',1;
  IF EXISTS
  (
   SELECT 1 FROM dbo.Acc_JournalLine l
   JOIN dbo.Acc_SubAccount a ON a.CompanyID=l.CompanyID AND a.SubAccountID=l.SubAccountID
   WHERE l.CompanyID=@CompanyID AND l.JournalID=@JournalID AND (a.IsActive=0 OR a.AllowPosting=0)
  ) THROW 51235,'Journal contains an inactive or non-postable account.',1;
  UPDATE dbo.Acc_JournalHeader SET JournalStatus=4,PostedBy=@PostedBy,PostedAt=SYSUTCDATETIME(),
      TotalDebit=@Debit,TotalCredit=@Credit,ModifiedBy=@PostedBy,ModifiedAt=SYSUTCDATETIME()
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
  VALUES(@CompanyID,@JournalID,@Status,4,N'POST',@PostedBy,N'Posted atomically');
  INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,ActionType,AfterData,ChangedBy)
  VALUES(@CompanyID,N'Acc_JournalHeader',CONVERT(NVARCHAR(100),@JournalID),N'POST',
         (SELECT @Debit AS TotalDebit,@Credit AS TotalCredit FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),@PostedBy);
  COMMIT TRANSACTION;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK TRANSACTION; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ArchiveJournal
    @CompanyID INT, @JournalID BIGINT, @ArchivedBy INT, @Note NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Status TINYINT,@RequireArchive BIT;
  SELECT @Status=JournalStatus FROM dbo.Acc_JournalHeader WITH (UPDLOCK,HOLDLOCK)
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  IF @Status IS NULL THROW 51240,'Journal not found for this company.',1;
  IF @Status<>4 THROW 51241,'Only a posted journal can be archived.',1;
  SELECT @RequireArchive=RequireArchive FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID;
  UPDATE dbo.Acc_JournalHeader SET JournalStatus=5,ArchivedBy=@ArchivedBy,ArchivedAt=SYSUTCDATETIME(),
      ModifiedBy=@ArchivedBy,ModifiedAt=SYSUTCDATETIME()
  WHERE CompanyID=@CompanyID AND JournalID=@JournalID;
  INSERT dbo.Acc_WorkflowHistory(CompanyID,JournalID,FromStatus,ToStatus,ActionCode,ActionBy,ActionNote)
  VALUES(@CompanyID,@JournalID,@Status,5,N'ARCHIVE',@ArchivedBy,@Note);
  INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,ActionType,AfterData,ChangedBy)
  VALUES(@CompanyID,N'Acc_JournalHeader',CONVERT(NVARCHAR(100),@JournalID),N'ARCHIVE',
         (SELECT @Note AS Note FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),@ArchivedBy);
  COMMIT TRANSACTION;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK TRANSACTION; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_PrintJournal
    @CompanyID INT, @JournalID BIGINT, @RequestedBy INT
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @AllowPrint BIT;
 SELECT @AllowPrint=AllowPrintBeforeApproval FROM dbo.Acc_CompanySettings WHERE CompanyID=@CompanyID;
 IF NOT EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID=@CompanyID AND JournalID=@JournalID)
   THROW 51250,'Journal not found for this company.',1;
 IF @AllowPrint=0 AND EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID=@CompanyID AND JournalID=@JournalID AND JournalStatus<3)
   THROW 51251,'Printing before approval is disabled for this company.',1;

 INSERT dbo.Acc_ReportRequestLog(CompanyID,ReportCode,RequestedBy,ParametersJson,OutputFormat)
 VALUES(@CompanyID,N'JOURNAL',@RequestedBy,(SELECT @JournalID AS JournalID FOR JSON PATH,WITHOUT_ARRAY_WRAPPER),N'PRINT');
 INSERT dbo.Acc_AuditLog(CompanyID,EntityName,EntityID,ActionType,ChangedBy)
 VALUES(@CompanyID,N'Acc_JournalHeader',CONVERT(NVARCHAR(100),@JournalID),N'PRINT',@RequestedBy);

 SELECT h.CompanyID, c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn,
        CONVERT(VARBINARY(MAX),c.CmpLogo) AS CompanyLogo,
        h.JournalID,h.JournalNo,h.JournalDate,h.JournalType,h.Description,h.JournalStatus,
        CASE h.JournalStatus WHEN 0 THEN N'مسودة — غير معتمد'
             WHEN 1 THEN N'بانتظار المراجعة' WHEN 2 THEN N'بانتظار الاعتماد'
             WHEN 3 THEN N'معتمد — غير مرحّل' WHEN 4 THEN N'مرحّل'
             WHEN 5 THEN N'مؤرشف' WHEN 6 THEN N'مرفوض' WHEN 7 THEN N'معكوس' END AS JournalStatusAr,
        h.PreparedBy, pu.UsrLogIn AS PreparedByLogin, h.PreparedAt,
        h.ReviewedBy, ru.UsrLogIn AS ReviewedByLogin, h.ReviewedAt,
        h.ApprovedBy, au.UsrLogIn AS ApprovedByLogin, h.ApprovedAt,
        h.PostedBy, po.UsrLogIn AS PostedByLogin, h.PostedAt,
        @RequestedBy AS ReportRequestedBy, req.UsrLogIn AS ReportRequestedByLogin,
        l.LineNum,l.SubAccountID,a.AccountCode,a.AccountNameAr,a.AccountNameEn,
        l.CostCenterID,cc.CostCenterCode,cc.CostCenterNameAr,l.LineDescription,l.DebitAmount,l.CreditAmount
 FROM dbo.Acc_JournalHeader h
 JOIN dbo.Mng_Company c ON c.CmpID=h.CompanyID
 JOIN dbo.Mng_User pu ON pu.UsrID=h.PreparedBy
 LEFT JOIN dbo.Mng_User ru ON ru.UsrID=h.ReviewedBy
 LEFT JOIN dbo.Mng_User au ON au.UsrID=h.ApprovedBy
 LEFT JOIN dbo.Mng_User po ON po.UsrID=h.PostedBy
 JOIN dbo.Mng_User req ON req.UsrID=@RequestedBy
 JOIN dbo.Acc_JournalLine l ON l.CompanyID=h.CompanyID AND l.JournalID=h.JournalID
 JOIN dbo.Acc_SubAccount a ON a.CompanyID=l.CompanyID AND a.SubAccountID=l.SubAccountID
 LEFT JOIN dbo.Acc_CostCenter cc ON cc.CompanyID=l.CompanyID AND cc.CostCenterID=l.CostCenterID
 WHERE h.CompanyID=@CompanyID AND h.JournalID=@JournalID
 ORDER BY l.LineNum;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportTrialBalance
    @CompanyID INT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT,
    @IncludeZeroBalances BIT=0, @AccountLevel SMALLINT=NULL
AS
BEGIN
 SET NOCOUNT ON;
 IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom>@DateTo THROW 51300,'Invalid report date range.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Mng_Company WHERE CmpID=@CompanyID) THROW 51301,'Company does not exist.',1;
 INSERT dbo.Acc_ReportRequestLog(CompanyID,ReportCode,RequestedBy,ParametersJson)
 VALUES(@CompanyID,N'TRIAL_BALANCE',@RequestedBy,
        (SELECT @DateFrom AS DateFrom,@DateTo AS DateTo,@IncludeZeroBalances AS IncludeZeroBalances,@AccountLevel AS AccountLevel FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));

 ;WITH Movements AS
 (
  SELECT l.SubAccountID,SUM(l.DebitAmount) AS PeriodDebit,SUM(l.CreditAmount) AS PeriodCredit
  FROM dbo.Acc_vPostedLedger l
  WHERE l.CompanyID=@CompanyID AND l.JournalDate BETWEEN @DateFrom AND @DateTo
  GROUP BY l.SubAccountID
 ),
 Opening AS
 (
  SELECT l.SubAccountID,SUM(l.DebitAmount-l.CreditAmount) AS OpeningNet
  FROM dbo.Acc_vPostedLedger l
  WHERE l.CompanyID=@CompanyID AND l.JournalDate<@DateFrom
  GROUP BY l.SubAccountID
 )
 SELECT c.CmpID AS CompanyID,c.CmpName AS CompanyNameAr,c.CmpEName AS CompanyNameEn,
        CONVERT(VARBINARY(MAX),c.CmpLogo) AS CompanyLogo,@DateFrom AS DateFrom,@DateTo AS DateTo,
        @RequestedBy AS ReportRequestedBy,u.UsrLogIn AS ReportRequestedByLogin,
        a.SubAccountID,a.AccountCode,a.AccountNameAr,a.AccountNameEn,a.AccountLevel,
        ISNULL(o.OpeningNet,0) AS OpeningNet,
        CASE WHEN ISNULL(o.OpeningNet,0)>0 THEN o.OpeningNet ELSE 0 END AS OpeningDebit,
        CASE WHEN ISNULL(o.OpeningNet,0)<0 THEN -o.OpeningNet ELSE 0 END AS OpeningCredit,
        ISNULL(m.PeriodDebit,0) AS PeriodDebit,ISNULL(m.PeriodCredit,0) AS PeriodCredit,
        ISNULL(o.OpeningNet,0)+ISNULL(m.PeriodDebit,0)-ISNULL(m.PeriodCredit,0) AS ClosingNet,
        CASE WHEN ISNULL(o.OpeningNet,0)+ISNULL(m.PeriodDebit,0)-ISNULL(m.PeriodCredit,0)>0
             THEN ISNULL(o.OpeningNet,0)+ISNULL(m.PeriodDebit,0)-ISNULL(m.PeriodCredit,0) ELSE 0 END AS ClosingDebit,
        CASE WHEN ISNULL(o.OpeningNet,0)+ISNULL(m.PeriodDebit,0)-ISNULL(m.PeriodCredit,0)<0
             THEN -(ISNULL(o.OpeningNet,0)+ISNULL(m.PeriodDebit,0)-ISNULL(m.PeriodCredit,0)) ELSE 0 END AS ClosingCredit
 FROM dbo.Mng_Company c
 JOIN dbo.Mng_User u ON u.UsrID=@RequestedBy
 JOIN dbo.Acc_SubAccount a ON a.CompanyID=c.CmpID
 LEFT JOIN Movements m ON m.SubAccountID=a.SubAccountID
 LEFT JOIN Opening o ON o.SubAccountID=a.SubAccountID
 WHERE c.CmpID=@CompanyID
   AND (@AccountLevel IS NULL OR a.AccountLevel=@AccountLevel)
   AND (@IncludeZeroBalances=1 OR ISNULL(m.PeriodDebit,0)<>0 OR ISNULL(m.PeriodCredit,0)<>0 OR ISNULL(o.OpeningNet,0)<>0)
 ORDER BY a.AccountCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportAccountStatement
    @CompanyID INT, @SubAccountID BIGINT, @DateFrom DATE, @DateTo DATE,
    @RequestedBy INT, @CostCenterID BIGINT=NULL, @DebitOnly BIT=0, @CreditOnly BIT=0
AS
BEGIN
 SET NOCOUNT ON;
 IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom>@DateTo THROW 51310,'Invalid report date range.',1;
 IF @DebitOnly=1 AND @CreditOnly=1 THROW 51311,'DebitOnly and CreditOnly cannot both be enabled.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Acc_SubAccount WHERE CompanyID=@CompanyID AND SubAccountID=@SubAccountID)
   THROW 51312,'Account not found for this company.',1;
 INSERT dbo.Acc_ReportRequestLog(CompanyID,ReportCode,RequestedBy,ParametersJson)
 VALUES(@CompanyID,N'ACCOUNT_STATEMENT',@RequestedBy,
        (SELECT @SubAccountID AS SubAccountID,@DateFrom AS DateFrom,@DateTo AS DateTo,@CostCenterID AS CostCenterID,@DebitOnly AS DebitOnly,@CreditOnly AS CreditOnly FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));

 ;WITH Opening AS
 (
  SELECT SUM(l.DebitAmount-l.CreditAmount) AS OpeningNet
  FROM dbo.Acc_vPostedLedger l
  WHERE l.CompanyID=@CompanyID AND l.SubAccountID=@SubAccountID AND l.JournalDate<@DateFrom
    AND (@CostCenterID IS NULL OR l.CostCenterID=@CostCenterID)
 ),
 RowsInPeriod AS
 (
  SELECT l.*, SUM(l.DebitAmount-l.CreditAmount) OVER(ORDER BY l.JournalDate,l.JournalNo,l.LineNum ROWS UNBOUNDED PRECEDING) AS PeriodRunning
  FROM dbo.Acc_vPostedLedger l
  WHERE l.CompanyID=@CompanyID AND l.SubAccountID=@SubAccountID
    AND l.JournalDate BETWEEN @DateFrom AND @DateTo
    AND (@CostCenterID IS NULL OR l.CostCenterID=@CostCenterID)
 )
 SELECT c.CmpID AS CompanyID,c.CmpName AS CompanyNameAr,c.CmpEName AS CompanyNameEn,
        CONVERT(VARBINARY(MAX),c.CmpLogo) AS CompanyLogo,@DateFrom AS DateFrom,@DateTo AS DateTo,
        @RequestedBy AS ReportRequestedBy,u.UsrLogIn AS ReportRequestedByLogin,
        a.AccountCode,a.AccountNameAr,a.AccountNameEn,
        o.OpeningNet AS OpeningNet,
        r.JournalID,r.JournalNo,r.JournalDate,r.JournalDescription AS JournalDescription,
        r.LineNum,r.LineDescription,r.CostCenterID,r.CostCenterCode,r.CostCenterNameAr,
        r.DebitAmount,r.CreditAmount,
        ISNULL(o.OpeningNet,0)+r.PeriodRunning AS RunningBalance
 FROM dbo.Mng_Company c
 JOIN dbo.Mng_User u ON u.UsrID=@RequestedBy
 JOIN dbo.Acc_SubAccount a ON a.CompanyID=c.CmpID AND a.SubAccountID=@SubAccountID
 CROSS JOIN Opening o
 LEFT JOIN RowsInPeriod r ON r.CompanyID=c.CmpID
 WHERE c.CmpID=@CompanyID
   AND (r.JournalID IS NULL OR (@DebitOnly=0 OR r.DebitAmount>0))
   AND (r.JournalID IS NULL OR (@CreditOnly=0 OR r.CreditAmount>0))
 ORDER BY r.JournalDate,r.JournalNo,r.LineNum;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_GetJournalWorkflow
    @CompanyID INT, @JournalID BIGINT
AS
BEGIN
 SET NOCOUNT ON;
 SELECT h.CompanyID,h.JournalID,h.JournalNo,h.JournalDate,h.Description,h.JournalStatus,
        h.PreparedBy,pu.UsrLogIn AS PreparedByLogin,h.PreparedAt,
        h.ReviewedBy,ru.UsrLogIn AS ReviewedByLogin,h.ReviewedAt,
        h.ApprovedBy,au.UsrLogIn AS ApprovedByLogin,h.ApprovedAt,
        h.PostedBy,po.UsrLogIn AS PostedByLogin,h.PostedAt,
        h.ArchivedBy,ar.UsrLogIn AS ArchivedByLogin,h.ArchivedAt,
        h.RejectedBy,re.UsrLogIn AS RejectedByLogin,h.RejectedAt,h.RejectionReason,
        h.TotalDebit,h.TotalCredit
 FROM dbo.Acc_JournalHeader h
 JOIN dbo.Mng_User pu ON pu.UsrID=h.PreparedBy
 LEFT JOIN dbo.Mng_User ru ON ru.UsrID=h.ReviewedBy
 LEFT JOIN dbo.Mng_User au ON au.UsrID=h.ApprovedBy
 LEFT JOIN dbo.Mng_User po ON po.UsrID=h.PostedBy
 LEFT JOIN dbo.Mng_User ar ON ar.UsrID=h.ArchivedBy
 LEFT JOIN dbo.Mng_User re ON re.UsrID=h.RejectedBy
 WHERE h.CompanyID=@CompanyID AND h.JournalID=@JournalID;

 SELECT WorkflowHistoryID,FromStatus,ToStatus,ActionCode,ActionBy,u.UsrLogIn AS ActionByLogin,ActionAt,ActionNote
 FROM dbo.Acc_WorkflowHistory w JOIN dbo.Mng_User u ON u.UsrID=w.ActionBy
 WHERE w.CompanyID=@CompanyID AND w.JournalID=@JournalID ORDER BY WorkflowHistoryID;
END;
GO

/*
  Operational notes:
  1) The workflow procedures above are core building blocks, not a substitute for application authorization.
  2) Configure database permissions so end users cannot directly UPDATE/DELETE posted journal rows;
     grant EXECUTE on approved procedures and deny direct DML as appropriate.
  3) Reviewer/approver role separation and company permissions must be checked by the application or
     a company-specific permission model before calling workflow procedures.
  4) Cash-flow reporting needs an approved mapping of accounts to operating/investing/financing categories;
     account-level classification is stored but a formal statement is not generated by this script.
  5) This script does not assume an employee table or a full-name column. It displays Mng_User.UsrLogIn
     until MADAR defines the canonical user display-name source.
*/


/*
  STATIC REVIEW FINDINGS / RELEASE GATE
  ------------------------------------
  Improvements made in this candidate:
  - Prevents a journal preparer from reviewing their own journal.
  - Prevents the preparer or reviewer from approving the same journal.
  - Fixes account-statement running balance so debit-only/credit-only display filters
    do not corrupt the cumulative balance (the running balance uses all period lines).

  Remaining release blockers / integration work (not silently guessed here):
  1) The user's canonical MADAR base script must be checked for the actual number-to-Arabic-
     words function name/signature, then that existing function should be used by print/report
     outputs. This candidate intentionally does not invent or duplicate that function.
  2) Validate all Mng_Company / Mng_User columns and types against the actual database.
  3) Add or integrate controlled CRUD for fiscal years/periods, account tree and cost-center tree.
  4) Add the full set of required reports (income statement, balance sheet, cash flow, cost-center
     analysis, account directory) using the approved MADAR account classifications and report rules.
  5) Design and implement journal reversal (status 7 is currently only a reserved status; this
     script does not create reversal entries).
  6) Enforce company-level authorization and roles in the trusted application/database security
     boundary. Foreign keys only prove that a user exists; they do not prove that user has access
     to that company or permission to perform the action.
  7) Deny direct DML to end-user database principals on posted journals and grant controlled
     EXECUTE permissions. This is deployment/security configuration, not guaranteed by this file.
  8) Enforce fiscal-period non-overlap, audit/approval policy, archival retention, and any required
     same-user restrictions consistently across all entry points.
  9) Validate SQL Server version/compatibility (OPENJSON requires compatibility level 130+),
     run the script on a restored test database, and execute transactional/workflow/report tests.

  Therefore this file is statically reviewed and contains targeted corrections, but is NOT
  represented as SQL Server-executed, production-ready, or a complete final implementation.
*/

/*
    MADAR Enterprise ERP
    General Ledger (Acc) - Initial Database Schema
    Target: SQL Server 2019+ (compatibility level 150+ recommended)
    Database: MADARERPDataBase

    IMPORTANT:
    - This script does NOT create the database.
    - Requires dbo.Mng_Company(CmpID) and dbo.Mng_User(UsrID) to exist first.
    - Intended for a new Acc module schema. Review and run first in a test database.
    - All module-owned tables and procedures use the Acc_ prefix.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF DB_NAME() <> N'MADARERPDataBase'
    THROW 51000, 'Run this script in MADARERPDataBase.', 1;

IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NULL
    THROW 51001, 'Required table dbo.Mng_Company was not found.', 1;

IF OBJECT_ID(N'dbo.Mng_User', N'U') IS NULL
    THROW 51002, 'Required table dbo.Mng_User was not found.', 1;

IF COL_LENGTH(N'dbo.Mng_Company', N'CmpID') IS NULL
    THROW 51003, 'dbo.Mng_Company must contain CmpID.', 1;

IF COL_LENGTH(N'dbo.Mng_User', N'UsrID') IS NULL
    THROW 51004, 'dbo.Mng_User must contain UsrID.', 1;

IF OBJECT_ID(N'dbo.Acc_FiscalYear', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Acc_FiscalPeriod', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Acc_MainAccount', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Acc_SubAccount', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Acc_CostCenter', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Acc_JournalHeader', N'U') IS NOT NULL
   OR OBJECT_ID(N'dbo.Acc_JournalLine', N'U') IS NOT NULL
    THROW 51005, 'One or more Acc tables already exist. This is an initial schema script; do not rerun over existing tables.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    CREATE TABLE dbo.Acc_FiscalYear
    (
        FiscalYearID       BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_FiscalYear PRIMARY KEY,
        CompanyID          INT NOT NULL,
        YearCode            INT NOT NULL,
        YearName            NVARCHAR(100) NOT NULL,
        DateFrom            DATE NOT NULL,
        DateTo              DATE NOT NULL,
        YearStatus          TINYINT NOT NULL CONSTRAINT DF_Acc_FiscalYear_Status DEFAULT (0), -- 0 Open, 1 Closing, 2 Closed
        CreatedBy           INT NULL,
        CreatedAt           DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_FiscalYear_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy          INT NULL,
        ModifiedAt          DATETIME2(0) NULL,
        RowVer              ROWVERSION,
        CONSTRAINT UQ_Acc_FiscalYear_Company_Year UNIQUE (CompanyID, YearCode),
        CONSTRAINT UQ_Acc_FiscalYear_Company_ID UNIQUE (CompanyID, FiscalYearID),
        CONSTRAINT CK_Acc_FiscalYear_Dates CHECK (DateFrom <= DateTo),
        CONSTRAINT CK_Acc_FiscalYear_Status CHECK (YearStatus IN (0,1,2)),
        CONSTRAINT FK_Acc_FiscalYear_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
        CONSTRAINT FK_Acc_FiscalYear_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_FiscalYear_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_FiscalPeriod
    (
        FiscalPeriodID     BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_FiscalPeriod PRIMARY KEY,
        CompanyID          INT NOT NULL,
        FiscalYearID       BIGINT NOT NULL,
        PeriodNo           TINYINT NOT NULL,
        PeriodName         NVARCHAR(100) NOT NULL,
        DateFrom           DATE NOT NULL,
        DateTo             DATE NOT NULL,
        PeriodStatus       TINYINT NOT NULL CONSTRAINT DF_Acc_FiscalPeriod_Status DEFAULT (0), -- 0 Open, 1 Closing, 2 Closed
        CreatedBy          INT NULL,
        CreatedAt          DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_FiscalPeriod_CreatedAt DEFAULT (SYSUTCDATETIME()),
        RowVer             ROWVERSION,
        CONSTRAINT UQ_Acc_FiscalPeriod_Company_ID UNIQUE (CompanyID, FiscalPeriodID),
        CONSTRAINT UQ_Acc_FiscalPeriod_Year_No UNIQUE (FiscalYearID, PeriodNo),
        CONSTRAINT CK_Acc_FiscalPeriod_No CHECK (PeriodNo BETWEEN 1 AND 13),
        CONSTRAINT CK_Acc_FiscalPeriod_Dates CHECK (DateFrom <= DateTo),
        CONSTRAINT CK_Acc_FiscalPeriod_Status CHECK (PeriodStatus IN (0,1,2)),
        CONSTRAINT FK_Acc_FiscalPeriod_Year FOREIGN KEY (CompanyID, FiscalYearID) REFERENCES dbo.Acc_FiscalYear(CompanyID, FiscalYearID),
        CONSTRAINT FK_Acc_FiscalPeriod_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_MainAccount
    (
        MainAccountID      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_MainAccount PRIMARY KEY,
        CompanyID          INT NOT NULL,
        MainAccountCode    NVARCHAR(30) NOT NULL,
        MainAccountNameAr  NVARCHAR(200) NOT NULL,
        MainAccountNameEn  NVARCHAR(200) NULL,
        AccountCategory    TINYINT NOT NULL, -- 1 Assets, 2 Liabilities, 3 Equity, 4 Revenue, 5 Expenses
        NormalBalance      CHAR(1) NOT NULL, -- D or C
        IsActive           BIT NOT NULL CONSTRAINT DF_Acc_MainAccount_IsActive DEFAULT (1),
        AllowPosting       BIT NOT NULL CONSTRAINT DF_Acc_MainAccount_AllowPosting DEFAULT (0),
        SortOrder          INT NOT NULL CONSTRAINT DF_Acc_MainAccount_Sort DEFAULT (0),
        CreatedBy          INT NULL,
        CreatedAt          DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_MainAccount_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy         INT NULL,
        ModifiedAt         DATETIME2(0) NULL,
        RowVer             ROWVERSION,
        CONSTRAINT UQ_Acc_MainAccount_Company_Code UNIQUE (CompanyID, MainAccountCode),
        CONSTRAINT UQ_Acc_MainAccount_Company_ID UNIQUE (CompanyID, MainAccountID),
        CONSTRAINT CK_Acc_MainAccount_Category CHECK (AccountCategory BETWEEN 1 AND 5),
        CONSTRAINT CK_Acc_MainAccount_NormalBalance CHECK (NormalBalance IN ('D','C')),
        CONSTRAINT FK_Acc_MainAccount_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
        CONSTRAINT FK_Acc_MainAccount_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_MainAccount_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_SubAccount
    (
        SubAccountID       BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_SubAccount PRIMARY KEY,
        CompanyID          INT NOT NULL,
        MainAccountID      BIGINT NOT NULL,
        ParentSubAccountID BIGINT NULL,
        AccountCode        NVARCHAR(60) NOT NULL,
        AccountNameAr      NVARCHAR(200) NOT NULL,
        AccountNameEn      NVARCHAR(200) NULL,
        AccountLevel       SMALLINT NOT NULL CONSTRAINT DF_Acc_SubAccount_Level DEFAULT (1),
        AccountCategory    TINYINT NOT NULL,
        NormalBalance      CHAR(1) NOT NULL,
        IsActive           BIT NOT NULL CONSTRAINT DF_Acc_SubAccount_IsActive DEFAULT (1),
        AllowPosting       BIT NOT NULL CONSTRAINT DF_Acc_SubAccount_AllowPosting DEFAULT (1),
        IsCashEquivalent   BIT NOT NULL CONSTRAINT DF_Acc_SubAccount_Cash DEFAULT (0),
        CashFlowCategory   TINYINT NULL, -- 1 Operating, 2 Investing, 3 Financing; NULL if not classified
        CreatedBy          INT NULL,
        CreatedAt          DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_SubAccount_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy         INT NULL,
        ModifiedAt         DATETIME2(0) NULL,
        RowVer             ROWVERSION,
        CONSTRAINT UQ_Acc_SubAccount_Company_Code UNIQUE (CompanyID, AccountCode),
        CONSTRAINT UQ_Acc_SubAccount_Company_ID UNIQUE (CompanyID, SubAccountID),
        CONSTRAINT CK_Acc_SubAccount_Level CHECK (AccountLevel >= 1),
        CONSTRAINT CK_Acc_SubAccount_Category CHECK (AccountCategory BETWEEN 1 AND 5),
        CONSTRAINT CK_Acc_SubAccount_NormalBalance CHECK (NormalBalance IN ('D','C')),
        CONSTRAINT CK_Acc_SubAccount_CashFlow CHECK (CashFlowCategory IS NULL OR CashFlowCategory BETWEEN 1 AND 3),
        CONSTRAINT FK_Acc_SubAccount_Main FOREIGN KEY (CompanyID, MainAccountID) REFERENCES dbo.Acc_MainAccount(CompanyID, MainAccountID),
        CONSTRAINT FK_Acc_SubAccount_Parent FOREIGN KEY (CompanyID, ParentSubAccountID) REFERENCES dbo.Acc_SubAccount(CompanyID, SubAccountID),
        CONSTRAINT FK_Acc_SubAccount_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_SubAccount_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_CostCenter
    (
        CostCenterID       BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_CostCenter PRIMARY KEY,
        CompanyID          INT NOT NULL,
        ParentCostCenterID BIGINT NULL,
        CostCenterCode     NVARCHAR(60) NOT NULL,
        CostCenterNameAr   NVARCHAR(200) NOT NULL,
        CostCenterNameEn   NVARCHAR(200) NULL,
        CenterLevel        SMALLINT NOT NULL CONSTRAINT DF_Acc_CostCenter_Level DEFAULT (1),
        IsActive           BIT NOT NULL CONSTRAINT DF_Acc_CostCenter_IsActive DEFAULT (1),
        CreatedBy          INT NULL,
        CreatedAt          DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CostCenter_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy         INT NULL,
        ModifiedAt         DATETIME2(0) NULL,
        RowVer             ROWVERSION,
        CONSTRAINT UQ_Acc_CostCenter_Company_Code UNIQUE (CompanyID, CostCenterCode),
        CONSTRAINT UQ_Acc_CostCenter_Company_ID UNIQUE (CompanyID, CostCenterID),
        CONSTRAINT CK_Acc_CostCenter_Level CHECK (CenterLevel >= 1),
        CONSTRAINT FK_Acc_CostCenter_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
        CONSTRAINT FK_Acc_CostCenter_Parent FOREIGN KEY (CompanyID, ParentCostCenterID) REFERENCES dbo.Acc_CostCenter(CompanyID, CostCenterID),
        CONSTRAINT FK_Acc_CostCenter_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_CostCenter_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_JournalHeader
    (
        JournalID          BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalHeader PRIMARY KEY,
        CompanyID          INT NOT NULL,
        FiscalYearID       BIGINT NOT NULL,
        FiscalPeriodID     BIGINT NOT NULL,
        JournalNo          BIGINT NOT NULL, -- user-facing sequence within company/year/period
        JournalDate        DATE NOT NULL,
        JournalType        TINYINT NOT NULL, -- 1 Manual, 2 Automated, 3 Opening, 4 Adjustment, 5 Closing
        SourceSystemID     TINYINT NULL,
        SourceReference    NVARCHAR(100) NULL,
        ExternalRequestKey NVARCHAR(150) NULL,
        Description        NVARCHAR(500) NOT NULL,
        JournalStatus      TINYINT NOT NULL CONSTRAINT DF_Acc_JournalHeader_Status DEFAULT (0),
        -- 0 Draft, 1 PendingReview, 2 PendingApproval, 3 Approved, 4 Posted, 5 Archived, 6 Rejected, 7 Reversed
        PreparedBy         INT NOT NULL,
        PreparedAt         DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_JournalHeader_PreparedAt DEFAULT (SYSUTCDATETIME()),
        ReviewedBy         INT NULL,
        ReviewedAt         DATETIME2(0) NULL,
        ApprovedBy         INT NULL,
        ApprovedAt         DATETIME2(0) NULL,
        PostedBy           INT NULL,
        PostedAt           DATETIME2(0) NULL,
        ArchivedBy         INT NULL,
        ArchivedAt         DATETIME2(0) NULL,
        RejectedBy         INT NULL,
        RejectedAt         DATETIME2(0) NULL,
        RejectionReason    NVARCHAR(1000) NULL,
        TotalDebit         DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalHeader_Debit DEFAULT (0),
        TotalCredit        DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalHeader_Credit DEFAULT (0),
        CreatedAt          DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_JournalHeader_CreatedAt DEFAULT (SYSUTCDATETIME()),
        ModifiedBy         INT NULL,
        ModifiedAt         DATETIME2(0) NULL,
        RowVer             ROWVERSION,
        CONSTRAINT UQ_Acc_JournalHeader_Company_Journal UNIQUE (CompanyID, JournalID),
        CONSTRAINT UQ_Acc_JournalHeader_Number UNIQUE (CompanyID, FiscalYearID, FiscalPeriodID, JournalNo),
        CONSTRAINT CK_Acc_JournalHeader_Type CHECK (JournalType BETWEEN 1 AND 5),
        CONSTRAINT CK_Acc_JournalHeader_Status CHECK (JournalStatus BETWEEN 0 AND 7),
        CONSTRAINT CK_Acc_JournalHeader_Totals CHECK (TotalDebit >= 0 AND TotalCredit >= 0),
        CONSTRAINT FK_Acc_JournalHeader_Year FOREIGN KEY (CompanyID, FiscalYearID) REFERENCES dbo.Acc_FiscalYear(CompanyID, FiscalYearID),
        CONSTRAINT FK_Acc_JournalHeader_Period FOREIGN KEY (CompanyID, FiscalPeriodID) REFERENCES dbo.Acc_FiscalPeriod(CompanyID, FiscalPeriodID),
        CONSTRAINT FK_Acc_JournalHeader_PreparedBy FOREIGN KEY (PreparedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_JournalHeader_ReviewedBy FOREIGN KEY (ReviewedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_JournalHeader_ApprovedBy FOREIGN KEY (ApprovedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_JournalHeader_PostedBy FOREIGN KEY (PostedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_JournalHeader_ArchivedBy FOREIGN KEY (ArchivedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_JournalHeader_RejectedBy FOREIGN KEY (RejectedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT FK_Acc_JournalHeader_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE UNIQUE INDEX UX_Acc_JournalHeader_ExternalRequest
        ON dbo.Acc_JournalHeader(CompanyID, SourceSystemID, ExternalRequestKey)
        WHERE ExternalRequestKey IS NOT NULL;

    CREATE TABLE dbo.Acc_JournalLine
    (
        JournalLineID      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_JournalLine PRIMARY KEY,
        CompanyID          INT NOT NULL,
        JournalID          BIGINT NOT NULL,
        LineNo              INT NOT NULL,
        SubAccountID        BIGINT NOT NULL,
        CostCenterID        BIGINT NULL,
        LineDescription     NVARCHAR(500) NULL,
        DebitAmount         DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalLine_Debit DEFAULT (0),
        CreditAmount        DECIMAL(19,4) NOT NULL CONSTRAINT DF_Acc_JournalLine_Credit DEFAULT (0),
        CreatedAt           DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_JournalLine_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Acc_JournalLine_Company_ID UNIQUE (CompanyID, JournalLineID),
        CONSTRAINT UQ_Acc_JournalLine_Journal_Line UNIQUE (JournalID, LineNo),
        CONSTRAINT CK_Acc_JournalLine_LineNo CHECK (LineNo > 0),
        CONSTRAINT CK_Acc_JournalLine_Amounts CHECK (DebitAmount >= 0 AND CreditAmount >= 0 AND NOT (DebitAmount > 0 AND CreditAmount > 0)),
        CONSTRAINT FK_Acc_JournalLine_Header FOREIGN KEY (CompanyID, JournalID) REFERENCES dbo.Acc_JournalHeader(CompanyID, JournalID),
        CONSTRAINT FK_Acc_JournalLine_Account FOREIGN KEY (CompanyID, SubAccountID) REFERENCES dbo.Acc_SubAccount(CompanyID, SubAccountID),
        CONSTRAINT FK_Acc_JournalLine_CostCenter FOREIGN KEY (CompanyID, CostCenterID) REFERENCES dbo.Acc_CostCenter(CompanyID, CostCenterID)
    );

    CREATE TABLE dbo.Acc_CompanySettings
    (
        CompanyID                  INT NOT NULL CONSTRAINT PK_Acc_CompanySettings PRIMARY KEY,
        RequireReview               BIT NOT NULL CONSTRAINT DF_Acc_Settings_Review DEFAULT (1),
        RequireApproval             BIT NOT NULL CONSTRAINT DF_Acc_Settings_Approval DEFAULT (1),
        RequireArchive              BIT NOT NULL CONSTRAINT DF_Acc_Settings_Archive DEFAULT (1),
        AllowPrintBeforeApproval    BIT NOT NULL CONSTRAINT DF_Acc_Settings_Print DEFAULT (1),
        RequireCostCenter           BIT NOT NULL CONSTRAINT DF_Acc_Settings_CostCenter DEFAULT (0),
        AllowManualJournal          BIT NOT NULL CONSTRAINT DF_Acc_Settings_Manual DEFAULT (1),
        AllowAutomatedJournal       BIT NOT NULL CONSTRAINT DF_Acc_Settings_Automated DEFAULT (1),
        RequireBalancedPosting      BIT NOT NULL CONSTRAINT DF_Acc_Settings_Balanced DEFAULT (1),
        CurrencyCode                CHAR(3) NOT NULL CONSTRAINT DF_Acc_Settings_Currency DEFAULT ('LYD'),
        ModifiedBy                  INT NULL,
        ModifiedAt                  DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_Settings_ModifiedAt DEFAULT (SYSUTCDATETIME()),
        RowVer                      ROWVERSION,
        CONSTRAINT FK_Acc_CompanySettings_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
        CONSTRAINT FK_Acc_CompanySettings_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_WorkflowHistory
    (
        WorkflowHistoryID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_WorkflowHistory PRIMARY KEY,
        CompanyID         INT NOT NULL,
        JournalID         BIGINT NOT NULL,
        FromStatus        TINYINT NULL,
        ToStatus          TINYINT NOT NULL,
        ActionCode        NVARCHAR(30) NOT NULL,
        ActionBy          INT NOT NULL,
        ActionAt          DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_WorkflowHistory_ActionAt DEFAULT (SYSUTCDATETIME()),
        ActionNote        NVARCHAR(1000) NULL,
        CONSTRAINT FK_Acc_WorkflowHistory_Journal FOREIGN KEY (CompanyID, JournalID) REFERENCES dbo.Acc_JournalHeader(CompanyID, JournalID),
        CONSTRAINT FK_Acc_WorkflowHistory_User FOREIGN KEY (ActionBy) REFERENCES dbo.Mng_User(UsrID)
    );

    CREATE TABLE dbo.Acc_AuditLog
    (
        AuditLogID        BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_AuditLog PRIMARY KEY,
        CompanyID         INT NOT NULL,
        EntityName        SYSNAME NOT NULL,
        EntityID          NVARCHAR(100) NOT NULL,
        ActionType        NVARCHAR(20) NOT NULL, -- INSERT, UPDATE, DELETE, MOVE, POST, APPROVE, ARCHIVE
        BeforeData        NVARCHAR(MAX) NULL,
        AfterData         NVARCHAR(MAX) NULL,
        ChangedBy         INT NOT NULL,
        ChangedAt         DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_AuditLog_ChangedAt DEFAULT (SYSUTCDATETIME()),
        ClientApp         NVARCHAR(150) NULL,
        CorrelationID     UNIQUEIDENTIFIER NULL,
        CONSTRAINT FK_Acc_AuditLog_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
        CONSTRAINT FK_Acc_AuditLog_User FOREIGN KEY (ChangedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT CK_Acc_AuditLog_Action CHECK (ActionType IN (N'INSERT',N'UPDATE',N'DELETE',N'MOVE',N'POST',N'APPROVE',N'ARCHIVE',N'REJECT',N'PRINT'))
    );

    CREATE TABLE dbo.Acc_ReportRequestLog
    (
        ReportRequestID   BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_ReportRequestLog PRIMARY KEY,
        CompanyID         INT NOT NULL,
        ReportCode        NVARCHAR(80) NOT NULL,
        RequestedBy       INT NOT NULL,
        RequestedAt       DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_ReportRequestLog_RequestedAt DEFAULT (SYSUTCDATETIME()),
        ParametersJson    NVARCHAR(MAX) NULL,
        OutputFormat      NVARCHAR(10) NULL,
        CONSTRAINT FK_Acc_ReportRequestLog_Company FOREIGN KEY (CompanyID) REFERENCES dbo.Mng_Company(CmpID),
        CONSTRAINT FK_Acc_ReportRequestLog_User FOREIGN KEY (RequestedBy) REFERENCES dbo.Mng_User(UsrID),
        CONSTRAINT CK_Acc_ReportRequestLog_Json CHECK (ParametersJson IS NULL OR ISJSON(ParametersJson) = 1)
    );

    CREATE INDEX IX_Acc_JournalHeader_Company_Date_Status
        ON dbo.Acc_JournalHeader(CompanyID, JournalDate, JournalStatus)
        INCLUDE (JournalNo, FiscalYearID, FiscalPeriodID, TotalDebit, TotalCredit);

    CREATE INDEX IX_Acc_JournalLine_Company_Account
        ON dbo.Acc_JournalLine(CompanyID, SubAccountID, JournalID)
        INCLUDE (DebitAmount, CreditAmount, CostCenterID);

    CREATE INDEX IX_Acc_JournalLine_Company_CostCenter
        ON dbo.Acc_JournalLine(CompanyID, CostCenterID, JournalID)
        INCLUDE (SubAccountID, DebitAmount, CreditAmount);

    CREATE INDEX IX_Acc_AuditLog_Company_Entity
        ON dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ChangedAt DESC);

    -- View: posted ledger movements only. Draft/under-review journals are intentionally excluded.
    EXEC(N'
    CREATE VIEW dbo.Acc_vPostedLedger
    AS
    SELECT
        h.CompanyID,
        h.FiscalYearID,
        h.FiscalPeriodID,
        h.JournalID,
        h.JournalNo,
        h.JournalDate,
        h.JournalType,
        h.Description AS JournalDescription,
        h.PreparedBy,
        h.ReviewedBy,
        h.ApprovedBy,
        l.JournalLineID,
        l.LineNo,
        l.SubAccountID,
        a.AccountCode,
        a.AccountNameAr,
        a.AccountNameEn,
        a.MainAccountID,
        m.MainAccountCode,
        m.MainAccountNameAr,
        m.MainAccountNameEn,
        l.CostCenterID,
        c.CostCenterCode,
        c.CostCenterNameAr,
        c.CostCenterNameEn,
        l.LineDescription,
        l.DebitAmount,
        l.CreditAmount
    FROM dbo.Acc_JournalHeader AS h
    INNER JOIN dbo.Acc_JournalLine AS l
        ON l.CompanyID = h.CompanyID AND l.JournalID = h.JournalID
    INNER JOIN dbo.Acc_SubAccount AS a
        ON a.CompanyID = l.CompanyID AND a.SubAccountID = l.SubAccountID
    INNER JOIN dbo.Acc_MainAccount AS m
        ON m.CompanyID = a.CompanyID AND m.MainAccountID = a.MainAccountID
    LEFT JOIN dbo.Acc_CostCenter AS c
        ON c.CompanyID = l.CompanyID AND c.CostCenterID = l.CostCenterID
    WHERE h.JournalStatus IN (4,5);
    ');

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

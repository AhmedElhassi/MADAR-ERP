/*
  MADAR Enterprise ERP - General Ledger module (Acc_) - UNIFIED / CORRECTED
  File    : MADAR_Acc_GeneralLedger_Unified.sql
  Target  : SQL Server 2019+ (compatibility level 130+ for OPENJSON)
  Database: MADARERPDataBase

  REVIEW STATUS: STATICALLY WRITTEN - NOT EXECUTED ON SQL SERVER.
  Run first on a restored test database. Do not deploy to production before testing.

  Built on MADAR_Acc_GeneralLedger_LineNum_Corrected.sql, with these changes:
   - Display names come from dbo.Emplooy.EmpName via Mng_User.UsrEmployeeID
     (ASSUMPTION: Emplooy key column is EmpID; change ONE line in Acc_vUserDisplay if different).
   - Preflight stops the whole script (SET NOEXEC) if anything required is missing.
   - Gap-free journal numbering through Acc_JournalCounter.
   - Journal reversal (status 7 + type 6) - the original stays in the ledger with its reversal.
   - Year closing: Acc_PrepareYearClosing -> normal workflow -> Acc_FinalizeFiscalYear.
   - Posted journals are protected by triggers (no UPDATE/DELETE of figures after posting).
   - Opening balances: balance-sheet accounts carry forward; revenue/expense accounts
     start at the fiscal-year start (prior unclosed residue is shown as PRIOR-RESULT).
   - Account category / normal balance live on Acc_MainAccount only (no duplicate on sub accounts).
   - Draft update/delete, fiscal-year creation with periods, period open/close,
     account tree and cost-center tree maintenance.
   - Reports: trial balance, account statement, cost-center statement, income statement,
     balance sheet, cash flow (direct method), revenue/expense analysis, general journal,
     account directory, journal print, workflow.

  Status codes: 0 Draft, 1 PendingReview, 2 PendingApproval, 3 Approved, 4 Posted,
                5 Archived, 6 Rejected, 7 Reversed.
  Journal types: 1 manual, 2 automated, 3 opening, 4 adjustment, 5 closing, 6 reversal.
  Account categories: 1 assets, 2 liabilities, 3 equity, 4 revenue, 5 expenses.
  All monetary values are in the company's local currency. Dates/times are UTC.

  NOT covered here (needs separate design): multi-currency, budgets, recurring journals,
  attachments, sub-ledger (AR/AP/inventory/assets/payroll) integration, bank reconciliation,
  tax reports, equity-change statement, consolidation, application-level permissions,
  and the number-to-Arabic-words function (name/signature not yet provided).
*/
USE [MADARERPDataBase];
GO
SET NOEXEC OFF;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* ===================== PREFLIGHT ===================== */
DECLARE @err NVARCHAR(500) = NULL;
IF DB_NAME() <> N'MADARERPDataBase' SET @err = N'Run this script in MADARERPDataBase.';
ELSE IF (SELECT compatibility_level FROM sys.databases WHERE name = DB_NAME()) < 130 SET @err = N'Compatibility level 130 or higher is required (OPENJSON).';
ELSE IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NULL SET @err = N'Table dbo.Mng_Company not found.';
ELSE IF OBJECT_ID(N'dbo.Mng_User', N'U') IS NULL SET @err = N'Table dbo.Mng_User not found.';
ELSE IF OBJECT_ID(N'dbo.Emplooy', N'U') IS NULL SET @err = N'Table dbo.Emplooy not found.';
ELSE IF COL_LENGTH(N'dbo.Mng_Company', N'CmpID') IS NULL OR COL_LENGTH(N'dbo.Mng_Company', N'CmpName') IS NULL
     OR COL_LENGTH(N'dbo.Mng_Company', N'CmpEName') IS NULL OR COL_LENGTH(N'dbo.Mng_Company', N'CmpLogo') IS NULL
    SET @err = N'dbo.Mng_Company must contain CmpID, CmpName, CmpEName, CmpLogo.';
ELSE IF COL_LENGTH(N'dbo.Mng_User', N'UsrID') IS NULL OR COL_LENGTH(N'dbo.Mng_User', N'UsrLogIn') IS NULL
     OR COL_LENGTH(N'dbo.Mng_User', N'UsrEmployeeID') IS NULL
    SET @err = N'dbo.Mng_User must contain UsrID, UsrLogIn, UsrEmployeeID.';
ELSE IF COL_LENGTH(N'dbo.Emplooy', N'EmpID') IS NULL OR COL_LENGTH(N'dbo.Emplooy', N'EmpName') IS NULL
    SET @err = N'dbo.Emplooy must contain EmpID (assumed key) and EmpName. If the key column has another name, edit Acc_vUserDisplay and this check.';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.indexes i
        WHERE i.object_id = OBJECT_ID(N'dbo.Mng_Company') AND (i.is_primary_key = 1 OR i.is_unique = 1)
          AND (SELECT COUNT(*) FROM sys.index_columns x WHERE x.object_id = i.object_id AND x.index_id = i.index_id AND x.is_included_column = 0) = 1
          AND EXISTS (SELECT 1 FROM sys.index_columns x JOIN sys.columns c ON c.object_id = x.object_id AND c.column_id = x.column_id
                      WHERE x.object_id = i.object_id AND x.index_id = i.index_id AND c.name = N'CmpID'))
    SET @err = N'Mng_Company.CmpID must be a PRIMARY KEY or UNIQUE (needed for foreign keys).';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.indexes i
        WHERE i.object_id = OBJECT_ID(N'dbo.Mng_User') AND (i.is_primary_key = 1 OR i.is_unique = 1)
          AND (SELECT COUNT(*) FROM sys.index_columns x WHERE x.object_id = i.object_id AND x.index_id = i.index_id AND x.is_included_column = 0) = 1
          AND EXISTS (SELECT 1 FROM sys.index_columns x JOIN sys.columns c ON c.object_id = x.object_id AND c.column_id = x.column_id
                      WHERE x.object_id = i.object_id AND x.index_id = i.index_id AND c.name = N'UsrID'))
    SET @err = N'Mng_User.UsrID must be a PRIMARY KEY or UNIQUE (needed for foreign keys).';
ELSE IF EXISTS (SELECT 1 FROM sys.objects WHERE schema_id = SCHEMA_ID(N'dbo') AND type = 'U' AND name IN
        (N'Acc_CompanySettings',N'Acc_FiscalYear',N'Acc_FiscalPeriod',N'Acc_MainAccount',N'Acc_SubAccount',
         N'Acc_CostCenter',N'Acc_JournalCounter',N'Acc_JournalHeader',N'Acc_JournalLine',N'Acc_WorkflowHistory',
         N'Acc_AuditLog',N'Acc_ReportRequestLog'))
    SET @err = N'Acc_ tables already exist. Use a clean test database or a reviewed migration script.';
IF @err IS NOT NULL
BEGIN
    RAISERROR(@err, 16, 1);
    SET NOEXEC ON;   -- skips every remaining batch until SET NOEXEC OFF at the end
END;
GO

/* ===================== TABLES ===================== */
SET XACT_ABORT ON;
BEGIN TRY
BEGIN TRANSACTION;

CREATE TABLE dbo.Acc_CompanySettings
(
    ِAccSCmpID INT NOT NULL CONSTRAINT PK_Acc_CompanySettings PRIMARY KEY,
    AccSReview BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_Review DEFAULT (0),
    AccSApproval BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_Approval DEFAULT (0),
    AccSArchive BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_Archive DEFAULT (0),      
    AccSState BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_AccSState DEFAULT (0),
    AccSDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CompanySettings_AccSDateTime DEFAULT (SYSUTCDATETIME()),
    AccSUser INT NULL,
    CONSTRAINT FK_Acc_CompanySettings_Company FOREIGN KEY (AccSCmpID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_CompanySettings_User FOREIGN KEY (AccSUser) REFERENCES dbo.Mng_User(UsrID)
);

CREATE TABLE dbo.Acc_FiscalYear
(
    AccFYear INT NOT NULL CONSTRAINT PK_Acc_FiscalYear (AccFYear ASC , AccFCmpID ASC) PRIMARY KEY,
    AccFName NVARCHAR(100) NOT NULL,
    AccFState BIT NOT NULL CONSTRAINT DF_Acc_FiscalYear_AccFState DEFAULT (0),
    AccFDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_FiscalYear_AccFDateTime DEFAULT (SYSUTCDATETIME()),
    AccFUser INT NOT NULL,
    AccFCmpID  INT  NOT NULL CONSTRAINT PK_Acc_FiscalYear (AccFYear ASC , AccFCmpID ASC) PRIMARY KEY,
    CONSTRAINT FK_Acc_FiscalYear_AccFUser FOREIGN KEY (AccFUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_FiscalYear_AccFCmpID FOREIGN KEY (AccFCmpID) REFERENCES dbo.Mng_Company(CmpID)
);


CREATE TABLE dbo.Acc_Account
(
    AccID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_Account PRIMARY KEY,
    AccEnd TINYINT NOT NULL,
    AccType TINYINT NOT NULL,
    AccParentID BIGINT NULL,
    AccOrder TINYINT NOT NULL,
    AccLevel SMALLINT NOT NULL,
    AccChid SMALLINT NOT NULL,
    AccCode NVARCHAR(60) NOT NULL,
    AccName NVARCHAR(500) NOT NULL,
    AccState TINYINT NOT NULL  CONSTRAINT DF_Acc_Account_AccState DEFAULT (0),
    AccDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_Account_AccDateTime DEFAULT (SYSUTCDATETIME()),
    AccUser INT NOT NULL,
    AccCompany INT NOT NULL,
    CONSTRAINT FK_Acc_Account_AccUser FOREIGN KEY (AccUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_Account_AccCompany FOREIGN KEY (AccCompany) REFERENCES dbo.Mng_Company(CmpID)
);

CREATE TABLE dbo.Acc_CostCenter
(
    CsCID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_CostCenter PRIMARY KEY,
    CsCParentID BIGINT NULL,
    CsCOrder TINYINT NOT NULL,
    CsCLevel SMALLINT NOT NULL,
    CsCChid SMALLINT NOT NULL,
    CsCCode NVARCHAR(60) NOT NULL,
    CsCName NVARCHAR(500) NOT NULL,
    CsCState TINYINT NOT NULL  CONSTRAINT DF_Acc_CostCenter_CsCState DEFAULT (0),
    CsCDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CostCenter_CsCDateTime DEFAULT (SYSUTCDATETIME()),
    CsCUser INT NOT NULL,
    CsCCompany INT NOT NULL,
    CONSTRAINT FK_Acc_CostCenter_CsCUser FOREIGN KEY (CsCUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_CostCenter_CsCCompany FOREIGN KEY (CsCCompany) REFERENCES dbo.Mng_Company(CmpID)
);


CREATE TABLE dbo.Acc_DayHeader
(
    DayMID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayHeader PRIMARY KEY,
    DayMDate DATE NOT NULL,
    DayMDescription NVARCHAR(MAX) NOT NULL,
    DayMNo INT NOT NULL,
    DayMState TINYINT NOT NULL  CONSTRAINT DF_Acc_DayHeader_DayMState DEFAULT (0),
    DayMDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_DayHeader_DayMDateTime DEFAULT (SYSUTCDATETIME()),
    DayMUser INT NOT NULL,
    DayMCompany INT NOT NULL,
    DayMReviewed INT NULL,
    DayMReviewedAt DATETIME2(0) NULL,
    DayMApproved INT NULL,
    DayMApprovedAt DATETIME2(0) NULL,
    DayMArchived INT NULL,
    DayMArchivedAt DATETIME2(0) NULL,
    CONSTRAINT FK_Acc_Acc_DayHeader_DayMUser FOREIGN KEY (DayMUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_Acc_DayHeader_DayMReviewed FOREIGN KEY (DayMReviewed) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_Acc_DayHeader_DayMApproved FOREIGN KEY (DayMApproved) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_Acc_DayHeader_DayMApproved FOREIGN KEY (DayMApproved) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_Acc_DayHeader_DayMCompany FOREIGN KEY (DayMCompany) REFERENCES dbo.Mng_Company(CmpID)
);


CREATE TABLE dbo.Acc_DayDetails
(
    DayDID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayDetails PRIMARY KEY,
    DayDMDayID BIGINT NOT NULL,
    JournalID BIGINT NOT NULL,
    LineNum INT NOT NULL,
    DayDAccID BIGINT NOT NULL,
    [DayDDebit] [decimal](15, 3) NOT NULL,
	[DayDCridit] [decimal](15, 3) NOT NULL,
    [DayDCsCID] [bigint] NULL,
    [DayDNum] [nvarchar](50) NULL,
	[DayDDescription] [nvarchar](max) NULL,
     CONSTRAINT FK_Acc_Acc_DayDetails_DayDMDayID FOREIGN KEY (DayDMDayID) REFERENCES dbo.Acc_DayHeader(DayMID),
     CONSTRAINT FK_Acc_Acc_DayDetails_DayDAccID FOREIGN KEY (DayDAccID) REFERENCES dbo.Acc_Account(AccID),
     CONSTRAINT FK_Acc_Acc_DayDetails_DayDCsCID FOREIGN KEY (DayDCsCID) REFERENCES dbo.Acc_CostCenter(CsCID)
);

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* ===================== TRIGGERS (data protection) ===================== */
CREATE OR ALTER TRIGGER dbo.trg_Acc_FiscalYear_Guard ON dbo.Acc_FiscalYear AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM inserted i JOIN dbo.Acc_FiscalYear y
               ON y.CompanyID = i.CompanyID AND y.FiscalYearID <> i.FiscalYearID
              AND y.DateFrom <= i.DateTo AND y.DateTo >= i.DateFrom)
        THROW 52010, N'Fiscal years of the same company cannot overlap.', 1;
END;
GO
CREATE OR ALTER TRIGGER dbo.trg_Acc_FiscalPeriod_Guard ON dbo.Acc_FiscalPeriod AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM inserted i JOIN dbo.Acc_FiscalPeriod p
               ON p.CompanyID = i.CompanyID AND p.FiscalPeriodID <> i.FiscalPeriodID
              AND p.DateFrom <= i.DateTo AND p.DateTo >= i.DateFrom)
        THROW 52011, N'Fiscal periods of the same company cannot overlap.', 1;
    IF EXISTS (SELECT 1 FROM inserted i JOIN dbo.Acc_FiscalYear y
               ON y.CompanyID = i.CompanyID AND y.FiscalYearID = i.FiscalYearID
              WHERE i.DateFrom < y.DateFrom OR i.DateTo > y.DateTo)
        THROW 52012, N'A fiscal period must lie inside its fiscal year.', 1;
END;
GO
CREATE OR ALTER TRIGGER dbo.trg_Acc_JournalLine_Guard ON dbo.Acc_JournalLine AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1
               FROM (SELECT CompanyID, JournalID FROM inserted UNION SELECT CompanyID, JournalID FROM deleted) k
               JOIN dbo.Acc_JournalHeader h ON h.CompanyID = k.CompanyID AND h.JournalID = k.JournalID
               WHERE h.JournalStatus NOT IN (0,6))
        THROW 52001, N'Journal lines can only be changed while the journal is a draft or rejected.', 1;
END;
GO
CREATE OR ALTER TRIGGER dbo.trg_Acc_JournalHeader_Guard ON dbo.Acc_JournalHeader AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted)   -- DELETE
    BEGIN
        IF EXISTS (SELECT 1 FROM deleted WHERE JournalStatus NOT IN (0,6) OR PostedAt IS NOT NULL)
            THROW 52002, N'Only never-posted draft or rejected journals can be deleted.', 1;
        RETURN;
    END;
    IF EXISTS (SELECT 1 FROM deleted d JOIN inserted i ON i.JournalID = d.JournalID
               WHERE d.JournalStatus IN (4,5,7)
                 AND (i.JournalStatus < d.JournalStatus
                      OR i.CompanyID <> d.CompanyID OR i.FiscalYearID <> d.FiscalYearID
                      OR i.FiscalPeriodID <> d.FiscalPeriodID OR i.JournalNo <> d.JournalNo
                      OR i.JournalDate <> d.JournalDate OR i.JournalType <> d.JournalType
                      OR i.Description <> d.Description OR i.TotalDebit <> d.TotalDebit
                      OR i.TotalCredit <> d.TotalCredit OR i.PreparedBy <> d.PreparedBy
                      OR ISNULL(i.ReversesJournalID, -1) <> ISNULL(d.ReversesJournalID, -1)))
        THROW 52003, N'Posted journals are immutable: only archiving or reversal status changes are allowed.', 1;
END;
GO

/* ===================== VIEWS ===================== */
/* ASSUMPTION: dbo.Emplooy primary key is EmpID. Edit the ON clause if the real column differs. */
CREATE OR ALTER VIEW dbo.Acc_vUserDisplay
AS
SELECT u.UsrID,
       COALESCE(NULLIF(LTRIM(RTRIM(e.EmpName)), N''), u.UsrLogIn) AS UserName
FROM dbo.Mng_User u
LEFT JOIN dbo.Emplooy e ON e.EmpID = u.UsrEmployeeID;
GO

CREATE OR ALTER VIEW dbo.Acc_vPostedLedger
AS
SELECT h.CompanyID, h.FiscalYearID, h.FiscalPeriodID, h.JournalID, h.JournalNo, h.JournalDate,
       h.JournalType, h.JournalStatus, h.ReversesJournalID, h.Description AS JournalDescription,
       h.PostedBy, h.PostedAt,
       l.JournalLineID, l.LineNum, l.SubAccountID, a.AccountCode, a.AccountNameAr, a.AccountNameEn,
       a.AccountLevel, a.IsCashEquivalent, a.CashFlowCategory,
       a.MainAccountID, m.MainAccountCode, m.MainAccountNameAr, m.MainAccountNameEn,
       m.AccountCategory, m.NormalBalance,
       l.CostCenterID, c.CostCenterCode, c.CostCenterNameAr, c.CostCenterNameEn,
       l.LineDescription, l.DebitAmount, l.CreditAmount
FROM dbo.Acc_JournalHeader h
JOIN dbo.Acc_JournalLine l ON l.CompanyID = h.CompanyID AND l.JournalID = h.JournalID
JOIN dbo.Acc_SubAccount a ON a.CompanyID = l.CompanyID AND a.SubAccountID = l.SubAccountID
JOIN dbo.Acc_MainAccount m ON m.CompanyID = a.CompanyID AND m.MainAccountID = a.MainAccountID
LEFT JOIN dbo.Acc_CostCenter c ON c.CompanyID = l.CompanyID AND c.CostCenterID = l.CostCenterID
WHERE h.JournalStatus IN (4,5,7);   -- posted, archived, reversed (the original stays beside its reversal)
GO

/* ===================== HELPERS ===================== */
CREATE OR ALTER FUNCTION dbo.Acc_fnPostingAllowed
    (@CompanyID INT, @YearID BIGINT, @PeriodID BIGINT, @Date DATE, @JournalType TINYINT)
RETURNS BIT
AS
BEGIN
    RETURN CASE WHEN EXISTS
    (
        SELECT 1
        FROM dbo.Acc_FiscalYear y
        JOIN dbo.Acc_FiscalPeriod p ON p.CompanyID = y.CompanyID AND p.FiscalYearID = y.FiscalYearID
        WHERE y.CompanyID = @CompanyID AND y.FiscalYearID = @YearID AND p.FiscalPeriodID = @PeriodID
          AND @Date BETWEEN y.DateFrom AND y.DateTo AND @Date BETWEEN p.DateFrom AND p.DateTo
          AND p.PeriodStatus = 0
          AND ((@JournalType <> 5 AND y.YearStatus = 0) OR (@JournalType = 5 AND y.YearStatus = 1))
    ) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ResolvePeriod
    @CompanyID INT, @Date DATE, @FiscalYearID BIGINT OUTPUT, @FiscalPeriodID BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @FiscalYearID = NULL, @FiscalPeriodID = NULL;
    SELECT TOP (1) @FiscalYearID = y.FiscalYearID, @FiscalPeriodID = p.FiscalPeriodID
    FROM dbo.Acc_FiscalYear y
    JOIN dbo.Acc_FiscalPeriod p ON p.CompanyID = y.CompanyID AND p.FiscalYearID = y.FiscalYearID
    WHERE y.CompanyID = @CompanyID AND @Date BETWEEN y.DateFrom AND y.DateTo AND @Date BETWEEN p.DateFrom AND p.DateTo;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_NextJournalNo
    @CompanyID INT, @FiscalYearID BIGINT, @FiscalPeriodID BIGINT, @JournalNo BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    IF @@TRANCOUNT = 0 THROW 51190, N'Acc_NextJournalNo must run inside the caller transaction.', 1;
    INSERT dbo.Acc_JournalCounter(CompanyID, FiscalYearID, FiscalPeriodID, LastNo)
    SELECT @CompanyID, @FiscalYearID, @FiscalPeriodID, 0
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_JournalCounter WITH (UPDLOCK, HOLDLOCK)
                      WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND FiscalPeriodID = @FiscalPeriodID);
    UPDATE dbo.Acc_JournalCounter SET @JournalNo = LastNo = LastNo + 1
    WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND FiscalPeriodID = @FiscalPeriodID;
END;
GO

/* Caller must create:  CREATE TABLE #JL (LineNum INT NOT NULL, SubAccountID BIGINT NULL, CostCenterID BIGINT NULL,
                                           LineDescription NVARCHAR(500) NULL, DebitAmount DECIMAL(19,4) NOT NULL, CreditAmount DECIMAL(19,4) NOT NULL); */
CREATE OR ALTER PROCEDURE dbo.Acc_ParseJournalLines
    @CompanyID INT, @LinesJson NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    IF OBJECT_ID(N'tempdb..#JL') IS NULL THROW 51090, N'Temp table #JL must be created by the caller.', 1;
    IF @LinesJson IS NULL OR ISJSON(@LinesJson) <> 1 OR LEFT(LTRIM(@LinesJson), 1) <> N'['
        THROW 51100, N'LinesJson must be a valid JSON array of line objects.', 1;

    INSERT #JL(LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
    SELECT COALESCE(x.LineNum, CONVERT(INT, j.[key]) + 1), x.SubAccountID, x.CostCenterID, x.LineDescription,
           COALESCE(x.DebitAmount, 0), COALESCE(x.CreditAmount, 0)
    FROM OPENJSON(@LinesJson) j
    CROSS APPLY OPENJSON(j.value)
    WITH (LineNum INT '$.lineNum',
          SubAccountID BIGINT '$.subAccountId',
          CostCenterID BIGINT '$.costCenterId',
          LineDescription NVARCHAR(500) '$.description',
          DebitAmount DECIMAL(19,4) '$.debit',
          CreditAmount DECIMAL(19,4) '$.credit') x;

    IF NOT EXISTS (SELECT 1 FROM #JL) THROW 51103, N'At least one journal line is required.', 1;
    IF EXISTS (SELECT 1 FROM #JL WHERE LineNum <= 0 OR SubAccountID IS NULL OR DebitAmount < 0 OR CreditAmount < 0
                  OR (DebitAmount > 0 AND CreditAmount > 0) OR (DebitAmount = 0 AND CreditAmount = 0))
        THROW 51104, N'Each line needs an account and exactly one positive debit or credit amount.', 1;
    IF EXISTS (SELECT LineNum FROM #JL GROUP BY LineNum HAVING COUNT(*) > 1)
        THROW 51114, N'Duplicate line numbers in LinesJson.', 1;
    IF EXISTS (SELECT 1 FROM #JL x
               LEFT JOIN dbo.Acc_SubAccount a ON a.CompanyID = @CompanyID AND a.SubAccountID = x.SubAccountID
               LEFT JOIN dbo.Acc_MainAccount m ON m.CompanyID = a.CompanyID AND m.MainAccountID = a.MainAccountID
               WHERE a.SubAccountID IS NULL OR a.IsActive = 0 OR a.AllowPosting = 0 OR m.IsActive = 0)
        THROW 51108, N'One or more accounts are invalid, inactive, or not postable.', 1;
    IF EXISTS (SELECT 1 FROM #JL x
               LEFT JOIN dbo.Acc_CostCenter c ON c.CompanyID = @CompanyID AND c.CostCenterID = x.CostCenterID
               WHERE x.CostCenterID IS NOT NULL AND (c.CostCenterID IS NULL OR c.IsActive = 0))
        THROW 51109, N'One or more cost centers are invalid or inactive.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID AND RequireCostCenter = 1)
       AND EXISTS (SELECT 1 FROM #JL WHERE CostCenterID IS NULL)
        THROW 51110, N'This company requires a cost center on every journal line.', 1;
END;
GO

/* ===================== FISCAL YEAR / PERIODS ===================== */
CREATE OR ALTER PROCEDURE dbo.Acc_CreateFiscalYear
    @CompanyID INT, @YearCode INT, @YearName NVARCHAR(100), @StartDate DATE, @CreatedBy INT,
    @FiscalYearID BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF DAY(@StartDate) <> 1 THROW 51001, N'Fiscal year must start on the first day of a month.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51002, N'Company does not exist.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @CreatedBy) THROW 51003, N'User does not exist.', 1;
    DECLARE @EndDate DATE = DATEADD(DAY, -1, DATEADD(MONTH, 12, @StartDate));
    BEGIN TRY
        BEGIN TRANSACTION;
        INSERT dbo.Acc_FiscalYear(CompanyID, YearCode, YearName, DateFrom, DateTo, CreatedBy)
        VALUES(@CompanyID, @YearCode, @YearName, @StartDate, @EndDate, @CreatedBy);
        SET @FiscalYearID = SCOPE_IDENTITY();

        INSERT dbo.Acc_FiscalPeriod(CompanyID, FiscalYearID, PeriodNo, PeriodName, DateFrom, DateTo, CreatedBy)
        SELECT @CompanyID, @FiscalYearID, n.i, N'الفترة ' + CONVERT(NVARCHAR(2), n.i),
               DATEADD(MONTH, n.i - 1, @StartDate), DATEADD(DAY, -1, DATEADD(MONTH, n.i, @StartDate)), @CreatedBy
        FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12)) n(i);

        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_FiscalYear', CONVERT(NVARCHAR(100), @FiscalYearID), N'INSERT',
               (SELECT @YearCode AS YearCode, @StartDate AS DateFrom, @EndDate AS DateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @CreatedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SetPeriodStatus
    @CompanyID INT, @FiscalPeriodID BIGINT, @NewStatus TINYINT, @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @NewStatus NOT IN (0,2) THROW 51010, N'New status must be 0 (open) or 2 (closed).', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @Old TINYINT, @YearStatus TINYINT;
        SELECT @Old = p.PeriodStatus, @YearStatus = y.YearStatus
        FROM dbo.Acc_FiscalPeriod p WITH (UPDLOCK, HOLDLOCK)
        JOIN dbo.Acc_FiscalYear y ON y.CompanyID = p.CompanyID AND y.FiscalYearID = p.FiscalYearID
        WHERE p.CompanyID = @CompanyID AND p.FiscalPeriodID = @FiscalPeriodID;
        IF @Old IS NULL THROW 51011, N'Period not found for this company.', 1;
        IF @YearStatus = 2 THROW 51012, N'The fiscal year is closed; its periods cannot be changed.', 1;
        IF @NewStatus = 2 AND EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader
                                      WHERE CompanyID = @CompanyID AND FiscalPeriodID = @FiscalPeriodID AND JournalStatus IN (1,2,3))
            THROW 51013, N'The period still has journals pending review, approval or posting.', 1;
        UPDATE dbo.Acc_FiscalPeriod SET PeriodStatus = @NewStatus WHERE CompanyID = @CompanyID AND FiscalPeriodID = @FiscalPeriodID;
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, BeforeData, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_FiscalPeriod', CONVERT(NVARCHAR(100), @FiscalPeriodID), N'UPDATE',
               (SELECT @Old AS PeriodStatus FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
               (SELECT @NewStatus AS PeriodStatus FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* ===================== ACCOUNT / COST-CENTER MAINTENANCE ===================== */
CREATE OR ALTER PROCEDURE dbo.Acc_SaveMainAccount
    @CompanyID INT, @MainAccountID BIGINT = NULL OUTPUT, @MainAccountCode NVARCHAR(30),
    @NameAr NVARCHAR(200), @NameEn NVARCHAR(200) = NULL, @AccountCategory TINYINT,
    @NormalBalance CHAR(1) = NULL, @IsActive BIT = 1, @SortOrder INT = 0, @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @AccountCategory NOT BETWEEN 1 AND 5 THROW 51020, N'Invalid account category.', 1;
    SET @NormalBalance = ISNULL(@NormalBalance, CASE WHEN @AccountCategory IN (1,5) THEN 'D' ELSE 'C' END);
    IF @NormalBalance NOT IN ('D','C') THROW 51021, N'Normal balance must be D or C.', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51022, N'Company does not exist.', 1;
        IF @MainAccountID IS NULL
        BEGIN
            INSERT dbo.Acc_MainAccount(CompanyID, MainAccountCode, MainAccountNameAr, MainAccountNameEn, AccountCategory, NormalBalance, IsActive, SortOrder, CreatedBy)
            VALUES(@CompanyID, @MainAccountCode, @NameAr, @NameEn, @AccountCategory, @NormalBalance, @IsActive, @SortOrder, @ActionBy);
            SET @MainAccountID = SCOPE_IDENTITY();
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_MainAccount', CONVERT(NVARCHAR(100), @MainAccountID), N'INSERT',
                   (SELECT @MainAccountCode AS Code, @AccountCategory AS Category FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        END
        ELSE
        BEGIN
            DECLARE @OldCat TINYINT, @Before NVARCHAR(MAX);
            SELECT @OldCat = AccountCategory,
                   @Before = (SELECT MainAccountCode, MainAccountNameAr, AccountCategory, NormalBalance, IsActive FROM dbo.Acc_MainAccount
                              WHERE CompanyID = @CompanyID AND MainAccountID = @MainAccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
            FROM dbo.Acc_MainAccount WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND MainAccountID = @MainAccountID;
            IF @OldCat IS NULL THROW 51023, N'Main account not found for this company.', 1;
            IF @OldCat <> @AccountCategory AND EXISTS
               (SELECT 1 FROM dbo.Acc_JournalLine l JOIN dbo.Acc_SubAccount a ON a.CompanyID = l.CompanyID AND a.SubAccountID = l.SubAccountID
                WHERE a.CompanyID = @CompanyID AND a.MainAccountID = @MainAccountID)
                THROW 51024, N'Cannot change the category of an account that already has journal lines.', 1;
            UPDATE dbo.Acc_MainAccount
            SET MainAccountCode = @MainAccountCode, MainAccountNameAr = @NameAr, MainAccountNameEn = @NameEn,
                AccountCategory = @AccountCategory, NormalBalance = @NormalBalance, IsActive = @IsActive,
                SortOrder = @SortOrder, ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND MainAccountID = @MainAccountID;
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, BeforeData, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_MainAccount', CONVERT(NVARCHAR(100), @MainAccountID), N'UPDATE', @Before,
                   (SELECT @MainAccountCode AS MainAccountCode, @NameAr AS MainAccountNameAr, @AccountCategory AS AccountCategory,
                           @NormalBalance AS NormalBalance, @IsActive AS IsActive FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SaveSubAccount
    @CompanyID INT, @SubAccountID BIGINT = NULL OUTPUT, @MainAccountID BIGINT, @ParentSubAccountID BIGINT = NULL,
    @AccountCode NVARCHAR(60), @NameAr NVARCHAR(200), @NameEn NVARCHAR(200) = NULL,
    @AllowPosting BIT = 1, @IsActive BIT = 1, @IsCashEquivalent BIT = 0, @CashFlowCategory TINYINT = NULL,
    @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_MainAccount WHERE CompanyID = @CompanyID AND MainAccountID = @MainAccountID)
            THROW 51030, N'Main account not found for this company.', 1;
        DECLARE @Level SMALLINT = 1, @ParentMain BIGINT;
        IF @ParentSubAccountID IS NOT NULL
        BEGIN
            SELECT @Level = AccountLevel + 1, @ParentMain = MainAccountID
            FROM dbo.Acc_SubAccount WITH (UPDLOCK, HOLDLOCK)
            WHERE CompanyID = @CompanyID AND SubAccountID = @ParentSubAccountID;
            IF @ParentMain IS NULL THROW 51031, N'Parent account not found for this company.', 1;
            IF @ParentMain <> @MainAccountID THROW 51032, N'Parent account must belong to the same main account.', 1;
            IF @SubAccountID IS NOT NULL AND @ParentSubAccountID = @SubAccountID THROW 51033, N'An account cannot be its own parent.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND SubAccountID = @ParentSubAccountID)
                THROW 51034, N'The parent account already has journal lines and cannot become a group account.', 1;
        END;

        IF @SubAccountID IS NULL
        BEGIN
            INSERT dbo.Acc_SubAccount(CompanyID, MainAccountID, ParentSubAccountID, AccountCode, AccountNameAr, AccountNameEn,
                                      AccountLevel, IsActive, AllowPosting, IsCashEquivalent, CashFlowCategory, CreatedBy)
            VALUES(@CompanyID, @MainAccountID, @ParentSubAccountID, @AccountCode, @NameAr, @NameEn,
                   @Level, @IsActive, @AllowPosting, @IsCashEquivalent, @CashFlowCategory, @ActionBy);
            SET @SubAccountID = SCOPE_IDENTITY();
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_SubAccount', CONVERT(NVARCHAR(100), @SubAccountID), N'INSERT',
                   (SELECT @AccountCode AS AccountCode, @MainAccountID AS MainAccountID, @ParentSubAccountID AS ParentSubAccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        END
        ELSE
        BEGIN
            DECLARE @OldMain BIGINT, @OldParent BIGINT, @Before NVARCHAR(MAX);
            SELECT @OldMain = MainAccountID, @OldParent = ParentSubAccountID,
                   @Before = (SELECT AccountCode, AccountNameAr, MainAccountID, ParentSubAccountID, AllowPosting, IsActive FROM dbo.Acc_SubAccount
                              WHERE CompanyID = @CompanyID AND SubAccountID = @SubAccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
            FROM dbo.Acc_SubAccount WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND SubAccountID = @SubAccountID;
            IF @OldMain IS NULL THROW 51035, N'Account not found for this company.', 1;
            IF @OldMain <> @MainAccountID AND EXISTS (SELECT 1 FROM dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND SubAccountID = @SubAccountID)
                THROW 51036, N'Cannot move an account with journal lines to another main account.', 1;
            IF @OldMain <> @MainAccountID AND EXISTS (SELECT 1 FROM dbo.Acc_SubAccount WHERE CompanyID = @CompanyID AND ParentSubAccountID = @SubAccountID)
                THROW 51037, N'Move the child accounts first; a group account cannot change its main account.', 1;
            IF @AllowPosting = 1 AND EXISTS (SELECT 1 FROM dbo.Acc_SubAccount WHERE CompanyID = @CompanyID AND ParentSubAccountID = @SubAccountID)
                THROW 51038, N'An account with children cannot accept postings.', 1;
            IF @ParentSubAccountID IS NOT NULL
            BEGIN
                ;WITH D AS
                (
                    SELECT SubAccountID FROM dbo.Acc_SubAccount WHERE CompanyID = @CompanyID AND ParentSubAccountID = @SubAccountID
                    UNION ALL
                    SELECT c.SubAccountID FROM dbo.Acc_SubAccount c JOIN D ON c.ParentSubAccountID = D.SubAccountID WHERE c.CompanyID = @CompanyID
                )
                SELECT @ParentMain = 0 WHERE EXISTS (SELECT 1 FROM D WHERE SubAccountID = @ParentSubAccountID);
                IF @ParentMain = 0 THROW 51039, N'The new parent is a descendant of this account (cycle).', 1;
            END;
            UPDATE dbo.Acc_SubAccount
            SET MainAccountID = @MainAccountID, ParentSubAccountID = @ParentSubAccountID, AccountCode = @AccountCode,
                AccountNameAr = @NameAr, AccountNameEn = @NameEn, AccountLevel = @Level, IsActive = @IsActive,
                AllowPosting = @AllowPosting, IsCashEquivalent = @IsCashEquivalent, CashFlowCategory = @CashFlowCategory,
                ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND SubAccountID = @SubAccountID;

            ;WITH T AS
            (
                SELECT SubAccountID, CAST(@Level AS SMALLINT) AS Lvl FROM dbo.Acc_SubAccount WHERE CompanyID = @CompanyID AND SubAccountID = @SubAccountID
                UNION ALL
                SELECT c.SubAccountID, CAST(T.Lvl + 1 AS SMALLINT) FROM dbo.Acc_SubAccount c JOIN T ON c.ParentSubAccountID = T.SubAccountID WHERE c.CompanyID = @CompanyID
            )
            UPDATE a SET AccountLevel = T.Lvl FROM dbo.Acc_SubAccount a JOIN T ON a.SubAccountID = T.SubAccountID WHERE a.CompanyID = @CompanyID;

            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, BeforeData, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_SubAccount', CONVERT(NVARCHAR(100), @SubAccountID),
                   CASE WHEN ISNULL(@OldParent, -1) <> ISNULL(@ParentSubAccountID, -1) THEN N'MOVE' ELSE N'UPDATE' END, @Before,
                   (SELECT @AccountCode AS AccountCode, @NameAr AS AccountNameAr, @MainAccountID AS MainAccountID,
                           @ParentSubAccountID AS ParentSubAccountID, @AllowPosting AS AllowPosting, @IsActive AS IsActive FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        END;

        IF @ParentSubAccountID IS NOT NULL   -- a parent becomes a group (non-posting) account
            UPDATE dbo.Acc_SubAccount SET AllowPosting = 0, ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND SubAccountID = @ParentSubAccountID AND AllowPosting = 1;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SaveCostCenter
    @CompanyID INT, @CostCenterID BIGINT = NULL OUTPUT, @ParentCostCenterID BIGINT = NULL,
    @CostCenterCode NVARCHAR(60), @NameAr NVARCHAR(200), @NameEn NVARCHAR(200) = NULL,
    @IsActive BIT = 1, @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51050, N'Company does not exist.', 1;
        DECLARE @Level SMALLINT = 1, @Found BIT = 0;
        IF @ParentCostCenterID IS NOT NULL
        BEGIN
            SELECT @Level = CenterLevel + 1, @Found = 1 FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND CostCenterID = @ParentCostCenterID;
            IF @Found = 0 THROW 51051, N'Parent cost center not found for this company.', 1;
            IF @CostCenterID IS NOT NULL AND @ParentCostCenterID = @CostCenterID THROW 51052, N'A cost center cannot be its own parent.', 1;
        END;
        IF @CostCenterID IS NULL
        BEGIN
            INSERT dbo.Acc_CostCenter(CompanyID, ParentCostCenterID, CostCenterCode, CostCenterNameAr, CostCenterNameEn, CenterLevel, IsActive, CreatedBy)
            VALUES(@CompanyID, @ParentCostCenterID, @CostCenterCode, @NameAr, @NameEn, @Level, @IsActive, @ActionBy);
            SET @CostCenterID = SCOPE_IDENTITY();
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_CostCenter', CONVERT(NVARCHAR(100), @CostCenterID), N'INSERT',
                   (SELECT @CostCenterCode AS CostCenterCode, @ParentCostCenterID AS ParentCostCenterID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        END
        ELSE
        BEGIN
            DECLARE @OldParent BIGINT, @Exists BIT = 0, @Before NVARCHAR(MAX);
            SELECT @OldParent = ParentCostCenterID, @Exists = 1,
                   @Before = (SELECT CostCenterCode, CostCenterNameAr, ParentCostCenterID, IsActive FROM dbo.Acc_CostCenter
                              WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
            FROM dbo.Acc_CostCenter WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID;
            IF @Exists = 0 THROW 51053, N'Cost center not found for this company.', 1;
            IF @ParentCostCenterID IS NOT NULL
            BEGIN
                DECLARE @Cycle BIT = 0;
                ;WITH D AS
                (
                    SELECT CostCenterID FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND ParentCostCenterID = @CostCenterID
                    UNION ALL
                    SELECT c.CostCenterID FROM dbo.Acc_CostCenter c JOIN D ON c.ParentCostCenterID = D.CostCenterID WHERE c.CompanyID = @CompanyID
                )
                SELECT @Cycle = 1 WHERE EXISTS (SELECT 1 FROM D WHERE CostCenterID = @ParentCostCenterID);
                IF @Cycle = 1 THROW 51054, N'The new parent is a descendant of this cost center (cycle).', 1;
            END;
            UPDATE dbo.Acc_CostCenter
            SET ParentCostCenterID = @ParentCostCenterID, CostCenterCode = @CostCenterCode, CostCenterNameAr = @NameAr,
                CostCenterNameEn = @NameEn, CenterLevel = @Level, IsActive = @IsActive, ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID;

            ;WITH T AS
            (
                SELECT CostCenterID, CAST(@Level AS SMALLINT) AS Lvl FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID
                UNION ALL
                SELECT c.CostCenterID, CAST(T.Lvl + 1 AS SMALLINT) FROM dbo.Acc_CostCenter c JOIN T ON c.ParentCostCenterID = T.CostCenterID WHERE c.CompanyID = @CompanyID
            )
            UPDATE c SET CenterLevel = T.Lvl FROM dbo.Acc_CostCenter c JOIN T ON c.CostCenterID = T.CostCenterID WHERE c.CompanyID = @CompanyID;

            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, BeforeData, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_CostCenter', CONVERT(NVARCHAR(100), @CostCenterID),
                   CASE WHEN ISNULL(@OldParent, -1) <> ISNULL(@ParentCostCenterID, -1) THEN N'MOVE' ELSE N'UPDATE' END, @Before,
                   (SELECT @CostCenterCode AS CostCenterCode, @NameAr AS CostCenterNameAr, @ParentCostCenterID AS ParentCostCenterID, @IsActive AS IsActive FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* ===================== JOURNAL WORKFLOW ===================== */
CREATE OR ALTER PROCEDURE dbo.Acc_CreateJournalDraft
    @CompanyID INT, @JournalDate DATE, @JournalType TINYINT, @Description NVARCHAR(500),
    @PreparedBy INT, @LinesJson NVARCHAR(MAX),
    @SourceSystemID TINYINT = NULL, @SourceReference NVARCHAR(100) = NULL, @ExternalRequestKey NVARCHAR(150) = NULL,
    @JournalID BIGINT OUTPUT, @JournalNo BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @JournalType NOT IN (1,2,3,4)
        THROW 51101, N'Type must be 1 manual, 2 automated, 3 opening or 4 adjustment (closing/reversal are generated by dedicated procedures).', 1;
    IF NULLIF(LTRIM(RTRIM(@Description)), N'') IS NULL THROW 51102, N'Journal description is required.', 1;
    CREATE TABLE #JL (LineNum INT NOT NULL, SubAccountID BIGINT NULL, CostCenterID BIGINT NULL,
                      LineDescription NVARCHAR(500) NULL, DebitAmount DECIMAL(19,4) NOT NULL, CreditAmount DECIMAL(19,4) NOT NULL);
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51105, N'Company does not exist.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @PreparedBy) THROW 51106, N'Preparing user does not exist.', 1;
        INSERT dbo.Acc_CompanySettings(CompanyID)
        SELECT @CompanyID WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID);

        DECLARE @YearID BIGINT, @PeriodID BIGINT;
        EXEC dbo.Acc_ResolvePeriod @CompanyID, @JournalDate, @YearID OUTPUT, @PeriodID OUTPUT;
        IF @YearID IS NULL THROW 51107, N'No fiscal year/period covers the journal date.', 1;
        IF dbo.Acc_fnPostingAllowed(@CompanyID, @YearID, @PeriodID, @JournalDate, @JournalType) = 0
            THROW 51115, N'The fiscal year or period is not open for this journal.', 1;

        EXEC dbo.Acc_ParseJournalLines @CompanyID, @LinesJson;

        IF @JournalType = 1 AND EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID AND AllowManualJournal = 0)
            THROW 51111, N'Manual journals are disabled for this company.', 1;
        IF @JournalType = 2 AND EXISTS (SELECT 1 FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID AND AllowAutomatedJournal = 0)
            THROW 51112, N'Automated journals are disabled for this company.', 1;
        IF @ExternalRequestKey IS NOT NULL AND EXISTS
           (SELECT 1 FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK)
            WHERE CompanyID = @CompanyID AND SourceSystemID = @SourceSystemID AND ExternalRequestKey = @ExternalRequestKey)
            THROW 51113, N'Duplicate external request key for this company/source.', 1;

        EXEC dbo.Acc_NextJournalNo @CompanyID, @YearID, @PeriodID, @JournalNo OUTPUT;

        INSERT dbo.Acc_JournalHeader(CompanyID, FiscalYearID, FiscalPeriodID, JournalNo, JournalDate, JournalType, SourceSystemID,
                                     SourceReference, ExternalRequestKey, Description, JournalStatus, PreparedBy)
        VALUES(@CompanyID, @YearID, @PeriodID, @JournalNo, @JournalDate, @JournalType, @SourceSystemID,
               @SourceReference, @ExternalRequestKey, @Description, 0, @PreparedBy);
        SET @JournalID = SCOPE_IDENTITY();

        INSERT dbo.Acc_JournalLine(CompanyID, JournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
        SELECT @CompanyID, @JournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount FROM #JL;

        INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
        VALUES(@CompanyID, @JournalID, NULL, 0, N'CREATE_DRAFT', @PreparedBy, N'Created as draft');
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'INSERT',
               (SELECT @JournalNo AS JournalNo, @JournalDate AS JournalDate, @JournalType AS JournalType, @Description AS Description FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @PreparedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_UpdateJournalDraft
    @CompanyID INT, @JournalID BIGINT, @JournalDate DATE, @Description NVARCHAR(500),
    @ModifiedBy INT, @LinesJson NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF NULLIF(LTRIM(RTRIM(@Description)), N'') IS NULL THROW 51102, N'Journal description is required.', 1;
    CREATE TABLE #JL (LineNum INT NOT NULL, SubAccountID BIGINT NULL, CostCenterID BIGINT NULL,
                      LineDescription NVARCHAR(500) NULL, DebitAmount DECIMAL(19,4) NOT NULL, CreditAmount DECIMAL(19,4) NOT NULL);
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ModifiedBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT, @Type TINYINT, @OldYear BIGINT, @OldPeriod BIGINT, @OldNo BIGINT, @OldDate DATE, @OldDesc NVARCHAR(500);
        SELECT @Status = JournalStatus, @Type = JournalType, @OldYear = FiscalYearID, @OldPeriod = FiscalPeriodID,
               @OldNo = JournalNo, @OldDate = JournalDate, @OldDesc = Description
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51120, N'Journal not found for this company.', 1;
        IF @Status NOT IN (0,6) THROW 51121, N'Only a draft or rejected journal can be edited.', 1;
        IF @Type IN (5,6) THROW 51122, N'Generated closing/reversal journals cannot be edited; delete the draft and regenerate it.', 1;

        DECLARE @YearID BIGINT, @PeriodID BIGINT, @JournalNo BIGINT = @OldNo;
        EXEC dbo.Acc_ResolvePeriod @CompanyID, @JournalDate, @YearID OUTPUT, @PeriodID OUTPUT;
        IF @YearID IS NULL THROW 51107, N'No fiscal year/period covers the journal date.', 1;
        IF dbo.Acc_fnPostingAllowed(@CompanyID, @YearID, @PeriodID, @JournalDate, @Type) = 0
            THROW 51115, N'The fiscal year or period is not open for this journal.', 1;
        EXEC dbo.Acc_ParseJournalLines @CompanyID, @LinesJson;
        IF @PeriodID <> @OldPeriod EXEC dbo.Acc_NextJournalNo @CompanyID, @YearID, @PeriodID, @JournalNo OUTPUT;

        DELETE dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        UPDATE dbo.Acc_JournalHeader
        SET FiscalYearID = @YearID, FiscalPeriodID = @PeriodID, JournalNo = @JournalNo, JournalDate = @JournalDate,
            Description = @Description, ModifiedBy = @ModifiedBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        INSERT dbo.Acc_JournalLine(CompanyID, JournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
        SELECT @CompanyID, @JournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount FROM #JL;

        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, BeforeData, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'UPDATE',
               (SELECT @OldNo AS JournalNo, @OldDate AS JournalDate, @OldDesc AS Description FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
               (SELECT @JournalNo AS JournalNo, @JournalDate AS JournalDate, @Description AS Description FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ModifiedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_DeleteJournalDraft
    @CompanyID INT, @JournalID BIGINT, @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @Status TINYINT, @Posted DATETIME2(0), @Snapshot NVARCHAR(MAX);
        SELECT @Status = JournalStatus, @Posted = PostedAt
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51130, N'Journal not found for this company.', 1;
        IF @Status NOT IN (0,6) OR @Posted IS NOT NULL THROW 51131, N'Only a never-posted draft or rejected journal can be deleted.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND ReversesJournalID = @JournalID)
            THROW 51132, N'A reversal journal references this journal.', 1;

        SET @Snapshot = (SELECT h.JournalNo, h.JournalDate, h.JournalType, h.Description, h.JournalStatus, h.PreparedBy,
                                JSON_QUERY((SELECT l.LineNum, l.SubAccountID, l.CostCenterID, l.DebitAmount, l.CreditAmount
                                            FROM dbo.Acc_JournalLine l WHERE l.CompanyID = h.CompanyID AND l.JournalID = h.JournalID FOR JSON PATH)) AS Lines,
                                JSON_QUERY((SELECT w.ActionCode, w.ActionBy, w.ActionAt, w.ActionNote
                                            FROM dbo.Acc_WorkflowHistory w WHERE w.CompanyID = h.CompanyID AND w.JournalID = h.JournalID FOR JSON PATH)) AS History
                         FROM dbo.Acc_JournalHeader h WHERE h.CompanyID = @CompanyID AND h.JournalID = @JournalID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        DELETE dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        DELETE dbo.Acc_WorkflowHistory WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        DELETE dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, BeforeData, ChangedBy)
        VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'DELETE', @Snapshot, @ActionBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_SubmitJournalForReview
    @CompanyID INT, @JournalID BIGINT, @ActionBy INT, @Note NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ActionBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT, @Type TINYINT, @Date DATE, @YearID BIGINT, @PeriodID BIGINT,
                @RequireReview BIT, @RequireApproval BIT, @Debit DECIMAL(19,4), @Credit DECIMAL(19,4);
        SELECT @Status = JournalStatus, @Type = JournalType, @Date = JournalDate, @YearID = FiscalYearID, @PeriodID = FiscalPeriodID
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51200, N'Journal not found for this company.', 1;
        IF @Status NOT IN (0,6) THROW 51201, N'Only a draft or rejected journal can be submitted.', 1;
        IF dbo.Acc_fnPostingAllowed(@CompanyID, @YearID, @PeriodID, @Date, @Type) = 0
            THROW 51203, N'The fiscal year or period is not open for this journal.', 1;
        SELECT @Debit = SUM(DebitAmount), @Credit = SUM(CreditAmount) FROM dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF ISNULL(@Debit, 0) <= 0 OR ISNULL(@Credit, 0) <= 0 OR @Debit <> @Credit
            THROW 51202, N'The journal must be balanced and non-zero before submission.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalLine l
                   JOIN dbo.Acc_SubAccount a ON a.CompanyID = l.CompanyID AND a.SubAccountID = l.SubAccountID
                   WHERE l.CompanyID = @CompanyID AND l.JournalID = @JournalID AND (a.IsActive = 0 OR a.AllowPosting = 0))
            THROW 51204, N'The journal contains an inactive or non-postable account.', 1;
        SELECT @RequireReview = RequireReview, @RequireApproval = RequireApproval FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID;
        DECLARE @ToStatus TINYINT = CASE WHEN ISNULL(@RequireReview, 1) = 1 THEN 1 WHEN ISNULL(@RequireApproval, 1) = 1 THEN 2 ELSE 3 END;
        UPDATE dbo.Acc_JournalHeader
        SET JournalStatus = @ToStatus, TotalDebit = @Debit, TotalCredit = @Credit,
            RejectedBy = NULL, RejectedAt = NULL, RejectionReason = NULL, ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
        VALUES(@CompanyID, @JournalID, @Status, @ToStatus, N'SUBMIT_REVIEW', @ActionBy, @Note);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReviewJournal
    @CompanyID INT, @JournalID BIGINT, @ReviewerID INT, @Approve BIT, @Note NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ReviewerID) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT, @Prepared INT, @RequireApproval BIT, @Enforce BIT, @ToStatus TINYINT;
        SELECT @Status = JournalStatus, @Prepared = PreparedBy
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51210, N'Journal not found for this company.', 1;
        IF @Status <> 1 THROW 51211, N'The journal is not awaiting review.', 1;
        SELECT @RequireApproval = RequireApproval, @Enforce = EnforceSegregation FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID;
        IF ISNULL(@Enforce, 1) = 1 AND @Prepared = @ReviewerID THROW 51213, N'The preparer cannot review their own journal.', 1;
        IF @Approve = 0
        BEGIN
            UPDATE dbo.Acc_JournalHeader SET JournalStatus = 6, RejectedBy = @ReviewerID, RejectedAt = SYSUTCDATETIME(),
                RejectionReason = @Note, ModifiedBy = @ReviewerID, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
            INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
            VALUES(@CompanyID, @JournalID, @Status, 6, N'REVIEW_REJECT', @ReviewerID, @Note);
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'REJECT',
                   (SELECT @Note AS Reason FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ReviewerID);
        END
        ELSE
        BEGIN
            SET @ToStatus = CASE WHEN ISNULL(@RequireApproval, 1) = 1 THEN 2 ELSE 3 END;
            UPDATE dbo.Acc_JournalHeader SET JournalStatus = @ToStatus, ReviewedBy = @ReviewerID, ReviewedAt = SYSUTCDATETIME(),
                ModifiedBy = @ReviewerID, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
            INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
            VALUES(@CompanyID, @JournalID, @Status, @ToStatus, N'REVIEW_PASS', @ReviewerID, @Note);
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ApproveJournal
    @CompanyID INT, @JournalID BIGINT, @ApproverID INT, @Approve BIT, @Note NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ApproverID) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT, @Prepared INT, @Reviewed INT, @Enforce BIT;
        SELECT @Status = JournalStatus, @Prepared = PreparedBy, @Reviewed = ReviewedBy
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51220, N'Journal not found for this company.', 1;
        IF @Status <> 2 THROW 51221, N'The journal is not awaiting approval.', 1;
        SELECT @Enforce = EnforceSegregation FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID;
        IF ISNULL(@Enforce, 1) = 1 AND (@Prepared = @ApproverID OR @Reviewed = @ApproverID)
            THROW 51223, N'The preparer or reviewer cannot approve the same journal.', 1;
        IF @Approve = 0
        BEGIN
            UPDATE dbo.Acc_JournalHeader SET JournalStatus = 6, RejectedBy = @ApproverID, RejectedAt = SYSUTCDATETIME(),
                RejectionReason = @Note, ModifiedBy = @ApproverID, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
            INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
            VALUES(@CompanyID, @JournalID, @Status, 6, N'APPROVAL_REJECT', @ApproverID, @Note);
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'REJECT',
                   (SELECT @Note AS Reason FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ApproverID);
        END
        ELSE
        BEGIN
            UPDATE dbo.Acc_JournalHeader SET JournalStatus = 3, ApprovedBy = @ApproverID, ApprovedAt = SYSUTCDATETIME(),
                ModifiedBy = @ApproverID, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
            INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
            VALUES(@CompanyID, @JournalID, @Status, 3, N'APPROVE', @ApproverID, @Note);
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'APPROVE',
                   (SELECT @Note AS Note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ApproverID);
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_PostJournal
    @CompanyID INT, @JournalID BIGINT, @PostedBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @PostedBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT, @Type TINYINT, @Date DATE, @YearID BIGINT, @PeriodID BIGINT, @Prepared INT, @Reverses BIGINT,
                @Debit DECIMAL(19,4), @Credit DECIMAL(19,4), @Enforce BIT, @RequireReview BIT, @RequireApproval BIT;
        SELECT @Status = JournalStatus, @Type = JournalType, @Date = JournalDate, @YearID = FiscalYearID,
               @PeriodID = FiscalPeriodID, @Prepared = PreparedBy, @Reverses = ReversesJournalID
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51230, N'Journal not found for this company.', 1;
        IF @Status <> 3 THROW 51231, N'Only an approved journal can be posted.', 1;
        SELECT @Enforce = EnforceSegregation, @RequireReview = RequireReview, @RequireApproval = RequireApproval
        FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID;
        IF ISNULL(@Enforce, 1) = 1 AND (ISNULL(@RequireReview, 1) = 1 OR ISNULL(@RequireApproval, 1) = 1) AND @Prepared = @PostedBy
            THROW 51236, N'The preparer cannot post their own journal.', 1;
        IF dbo.Acc_fnPostingAllowed(@CompanyID, @YearID, @PeriodID, @Date, @Type) = 0
            THROW 51232, N'The fiscal year or period is not open for posting this journal.', 1;
        SELECT @Debit = SUM(DebitAmount), @Credit = SUM(CreditAmount) FROM dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF ISNULL(@Debit, 0) <= 0 OR ISNULL(@Credit, 0) <= 0 OR @Debit <> @Credit
            THROW 51234, N'Cannot post an empty or unbalanced journal.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalLine l
                   JOIN dbo.Acc_SubAccount a ON a.CompanyID = l.CompanyID AND a.SubAccountID = l.SubAccountID
                   WHERE l.CompanyID = @CompanyID AND l.JournalID = @JournalID AND (a.IsActive = 0 OR a.AllowPosting = 0))
            THROW 51235, N'The journal contains an inactive or non-postable account.', 1;

        IF @Reverses IS NOT NULL
        BEGIN
            DECLARE @OrigStatus TINYINT;
            SELECT @OrigStatus = JournalStatus FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @Reverses;
            IF @OrigStatus NOT IN (4,5) THROW 51237, N'The journal being reversed is no longer in a posted/archived state.', 1;
            UPDATE dbo.Acc_JournalHeader SET JournalStatus = 7, ModifiedBy = @PostedBy, ModifiedAt = SYSUTCDATETIME()
            WHERE CompanyID = @CompanyID AND JournalID = @Reverses;
            INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
            VALUES(@CompanyID, @Reverses, @OrigStatus, 7, N'REVERSED', @PostedBy, N'Reversed by journal id ' + CONVERT(NVARCHAR(30), @JournalID));
            INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
            VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @Reverses), N'REVERSE',
                   (SELECT @JournalID AS ReversalJournalID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @PostedBy);
        END;

        UPDATE dbo.Acc_JournalHeader SET JournalStatus = 4, PostedBy = @PostedBy, PostedAt = SYSUTCDATETIME(),
            TotalDebit = @Debit, TotalCredit = @Credit, ModifiedBy = @PostedBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
        VALUES(@CompanyID, @JournalID, @Status, 4, N'POST', @PostedBy, N'Posted atomically');
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'POST',
               (SELECT @Debit AS TotalDebit, @Credit AS TotalCredit FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @PostedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ArchiveJournal
    @CompanyID INT, @JournalID BIGINT, @ArchivedBy INT, @Note NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ArchivedBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT;
        SELECT @Status = JournalStatus FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51240, N'Journal not found for this company.', 1;
        IF @Status <> 4 THROW 51241, N'Only a posted journal can be archived.', 1;
        UPDATE dbo.Acc_JournalHeader SET JournalStatus = 5, ArchivedBy = @ArchivedBy, ArchivedAt = SYSUTCDATETIME(),
            ModifiedBy = @ArchivedBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
        VALUES(@CompanyID, @JournalID, @Status, 5, N'ARCHIVE', @ArchivedBy, @Note);
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'ARCHIVE',
               (SELECT @Note AS Note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ArchivedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* Creates a DRAFT reversal journal (type 6) with debit/credit swapped; it follows the normal workflow.
   When the reversal is posted, the original becomes status 7 and stays in the ledger beside it. */
CREATE OR ALTER PROCEDURE dbo.Acc_ReverseJournal
    @CompanyID INT, @JournalID BIGINT, @ReversalDate DATE, @PreparedBy INT, @Reason NVARCHAR(300),
    @NewJournalID BIGINT OUTPUT, @NewJournalNo BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF NULLIF(LTRIM(RTRIM(@Reason)), N'') IS NULL THROW 51140, N'A reversal reason is required.', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @PreparedBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @Status TINYINT, @Type TINYINT, @OrigDate DATE, @OrigNo BIGINT;
        SELECT @Status = JournalStatus, @Type = JournalType, @OrigDate = JournalDate, @OrigNo = JournalNo
        FROM dbo.Acc_JournalHeader WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        IF @Status IS NULL THROW 51141, N'Journal not found for this company.', 1;
        IF @Status NOT IN (4,5) THROW 51142, N'Only a posted or archived journal can be reversed.', 1;
        IF @Type = 6 THROW 51143, N'A reversal journal cannot itself be reversed; enter a new journal.', 1;
        IF @ReversalDate < @OrigDate THROW 51144, N'The reversal date cannot precede the original journal date.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND ReversesJournalID = @JournalID)
            THROW 51145, N'This journal already has a reversal journal.', 1;

        DECLARE @YearID BIGINT, @PeriodID BIGINT;
        EXEC dbo.Acc_ResolvePeriod @CompanyID, @ReversalDate, @YearID OUTPUT, @PeriodID OUTPUT;
        IF @YearID IS NULL THROW 51107, N'No fiscal year/period covers the reversal date.', 1;
        IF dbo.Acc_fnPostingAllowed(@CompanyID, @YearID, @PeriodID, @ReversalDate, 6) = 0
            THROW 51115, N'The fiscal year or period is not open for the reversal.', 1;

        EXEC dbo.Acc_NextJournalNo @CompanyID, @YearID, @PeriodID, @NewJournalNo OUTPUT;
        INSERT dbo.Acc_JournalHeader(CompanyID, FiscalYearID, FiscalPeriodID, JournalNo, JournalDate, JournalType,
                                     ReversesJournalID, Description, JournalStatus, PreparedBy)
        VALUES(@CompanyID, @YearID, @PeriodID, @NewJournalNo, @ReversalDate, 6, @JournalID,
               LEFT(N'Reversal of journal no. ' + CONVERT(NVARCHAR(30), @OrigNo) + N': ' + @Reason, 500), 0, @PreparedBy);
        SET @NewJournalID = SCOPE_IDENTITY();
        INSERT dbo.Acc_JournalLine(CompanyID, JournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
        SELECT @CompanyID, @NewJournalID, LineNum, SubAccountID, CostCenterID, LineDescription, CreditAmount, DebitAmount
        FROM dbo.Acc_JournalLine WHERE CompanyID = @CompanyID AND JournalID = @JournalID;
        INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
        VALUES(@CompanyID, @NewJournalID, NULL, 0, N'CREATE_REVERSAL', @PreparedBy, @Reason);
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @NewJournalID), N'REVERSE',
               (SELECT @JournalID AS ReversesJournalID, @Reason AS Reason FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @PreparedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* ===================== YEAR CLOSING ===================== */
/* Step 1: sets the year to "closing" and creates a DRAFT closing journal (type 5) that zeroes every
   revenue/expense account (per cost center) into the retained-earnings account.
   Step 2: run the closing journal through submit/review/approve/post.  Step 3: Acc_FinalizeFiscalYear. */
CREATE OR ALTER PROCEDURE dbo.Acc_PrepareYearClosing
    @CompanyID INT, @FiscalYearID BIGINT, @RetainedEarningsSubAccountID BIGINT, @PreparedBy INT,
    @ClosingJournalID BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    CREATE TABLE #JL (LineNum INT NOT NULL, SubAccountID BIGINT NULL, CostCenterID BIGINT NULL,
                      LineDescription NVARCHAR(500) NULL, DebitAmount DECIMAL(19,4) NOT NULL, CreditAmount DECIMAL(19,4) NOT NULL);
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @PreparedBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @YearStatus TINYINT, @From DATE, @To DATE, @YearName NVARCHAR(100);
        SELECT @YearStatus = YearStatus, @From = DateFrom, @To = DateTo, @YearName = YearName
        FROM dbo.Acc_FiscalYear WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;
        IF @YearStatus IS NULL THROW 51150, N'Fiscal year not found for this company.', 1;
        IF @YearStatus <> 0 THROW 51151, N'The fiscal year must be open to start closing.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND JournalStatus IN (1,2,3))
            THROW 51152, N'Journals are still pending review, approval or posting in this year.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND JournalType = 5)
            THROW 51153, N'A closing journal already exists for this year.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_SubAccount a JOIN dbo.Acc_MainAccount m ON m.CompanyID = a.CompanyID AND m.MainAccountID = a.MainAccountID
                       WHERE a.CompanyID = @CompanyID AND a.SubAccountID = @RetainedEarningsSubAccountID
                         AND a.IsActive = 1 AND a.AllowPosting = 1 AND m.AccountCategory = 3)
            THROW 51154, N'The retained-earnings account must be an active, postable equity account.', 1;

        SELECT l.SubAccountID, l.CostCenterID, SUM(l.DebitAmount - l.CreditAmount) AS Net
        INTO #Net
        FROM dbo.Acc_vPostedLedger l
        WHERE l.CompanyID = @CompanyID AND l.JournalDate BETWEEN @From AND @To AND l.AccountCategory IN (4,5) AND l.JournalType <> 5
        GROUP BY l.SubAccountID, l.CostCenterID
        HAVING SUM(l.DebitAmount - l.CreditAmount) <> 0;
        IF NOT EXISTS (SELECT 1 FROM #Net) THROW 51155, N'There are no revenue/expense balances to close.', 1;

        INSERT #JL(LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
        SELECT ROW_NUMBER() OVER (ORDER BY SubAccountID, CostCenterID), SubAccountID, CostCenterID, N'Closing entry',
               CASE WHEN Net < 0 THEN -Net ELSE 0 END, CASE WHEN Net > 0 THEN Net ELSE 0 END
        FROM #Net;
        DECLARE @Total DECIMAL(19,4) = (SELECT SUM(Net) FROM #Net), @Cnt INT = (SELECT COUNT(*) FROM #JL);
        INSERT #JL(LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
        VALUES(@Cnt + 1, @RetainedEarningsSubAccountID, NULL, N'Transfer of year result to retained earnings',
               CASE WHEN @Total > 0 THEN @Total ELSE 0 END, CASE WHEN @Total < 0 THEN -@Total ELSE 0 END);

        UPDATE dbo.Acc_FiscalYear SET YearStatus = 1, ModifiedBy = @PreparedBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;

        DECLARE @PeriodID BIGINT, @ResolvedYear BIGINT, @JournalNo BIGINT;
        EXEC dbo.Acc_ResolvePeriod @CompanyID, @To, @ResolvedYear OUTPUT, @PeriodID OUTPUT;
        IF @PeriodID IS NULL OR @ResolvedYear <> @FiscalYearID THROW 51156, N'The last period of the year was not found.', 1;
        IF dbo.Acc_fnPostingAllowed(@CompanyID, @FiscalYearID, @PeriodID, @To, 5) = 0
            THROW 51157, N'The last period of the year must be open to receive the closing journal.', 1;
        EXEC dbo.Acc_NextJournalNo @CompanyID, @FiscalYearID, @PeriodID, @JournalNo OUTPUT;

        DECLARE @TD DECIMAL(19,4) = (SELECT SUM(DebitAmount) FROM #JL), @TC DECIMAL(19,4) = (SELECT SUM(CreditAmount) FROM #JL);
        IF @TD <> @TC THROW 51158, N'Internal error: the generated closing journal is unbalanced.', 1;
        INSERT dbo.Acc_JournalHeader(CompanyID, FiscalYearID, FiscalPeriodID, JournalNo, JournalDate, JournalType, Description,
                                     JournalStatus, PreparedBy, TotalDebit, TotalCredit)
        VALUES(@CompanyID, @FiscalYearID, @PeriodID, @JournalNo, @To, 5, LEFT(N'Closing entry for fiscal year ' + @YearName, 500), 0, @PreparedBy, @TD, @TC);
        SET @ClosingJournalID = SCOPE_IDENTITY();
        INSERT dbo.Acc_JournalLine(CompanyID, JournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount)
        SELECT @CompanyID, @ClosingJournalID, LineNum, SubAccountID, CostCenterID, LineDescription, DebitAmount, CreditAmount FROM #JL;
        INSERT dbo.Acc_WorkflowHistory(CompanyID, JournalID, FromStatus, ToStatus, ActionCode, ActionBy, ActionNote)
        VALUES(@CompanyID, @ClosingJournalID, NULL, 0, N'CREATE_CLOSING', @PreparedBy, N'Generated closing journal');
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_FiscalYear', CONVERT(NVARCHAR(100), @FiscalYearID), N'CLOSE',
               (SELECT N'closing-started' AS Step, @ClosingJournalID AS ClosingJournalID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @PreparedBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_CancelYearClosing
    @CompanyID INT, @FiscalYearID BIGINT, @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @YearStatus TINYINT;
        SELECT @YearStatus = YearStatus FROM dbo.Acc_FiscalYear WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;
        IF @YearStatus IS NULL THROW 51150, N'Fiscal year not found for this company.', 1;
        IF @YearStatus <> 1 THROW 51160, N'The fiscal year is not in the closing state.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND JournalType = 5)
            THROW 51161, N'Delete the closing journal (Acc_DeleteJournalDraft) before cancelling; a posted closing journal must be reversed instead.', 1;
        UPDATE dbo.Acc_FiscalYear SET YearStatus = 0, ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_FiscalYear', CONVERT(NVARCHAR(100), @FiscalYearID), N'CLOSE',
               (SELECT N'closing-cancelled' AS Step FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_FinalizeFiscalYear
    @CompanyID INT, @FiscalYearID BIGINT, @ActionBy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @ActionBy) THROW 51106, N'User does not exist.', 1;
        DECLARE @YearStatus TINYINT;
        SELECT @YearStatus = YearStatus FROM dbo.Acc_FiscalYear WITH (UPDLOCK, HOLDLOCK) WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;
        IF @YearStatus IS NULL THROW 51150, N'Fiscal year not found for this company.', 1;
        IF @YearStatus <> 1 THROW 51160, N'The fiscal year is not in the closing state.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND JournalType = 5 AND JournalStatus IN (4,5))
            THROW 51162, N'The closing journal has not been posted yet.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID AND JournalStatus IN (0,1,2,3,6))
            THROW 51163, N'Unposted journals remain in this year; post or delete them first.', 1;
        UPDATE dbo.Acc_FiscalPeriod SET PeriodStatus = 2 WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;
        UPDATE dbo.Acc_FiscalYear SET YearStatus = 2, ModifiedBy = @ActionBy, ModifiedAt = SYSUTCDATETIME()
        WHERE CompanyID = @CompanyID AND FiscalYearID = @FiscalYearID;
        INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, AfterData, ChangedBy)
        VALUES(@CompanyID, N'Acc_FiscalYear', CONVERT(NVARCHAR(100), @FiscalYearID), N'CLOSE',
               (SELECT N'closed' AS Step FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), @ActionBy);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* ===================== PRINT / WORKFLOW ===================== */
CREATE OR ALTER PROCEDURE dbo.Acc_PrintJournal
    @CompanyID INT, @JournalID BIGINT, @RequestedBy INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @AllowPrint BIT;
    SELECT @AllowPrint = AllowPrintBeforeApproval FROM dbo.Acc_CompanySettings WHERE CompanyID = @CompanyID;
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND JournalID = @JournalID)
        THROW 51250, N'Journal not found for this company.', 1;
    IF @AllowPrint = 0 AND EXISTS (SELECT 1 FROM dbo.Acc_JournalHeader WHERE CompanyID = @CompanyID AND JournalID = @JournalID AND JournalStatus < 3)
        THROW 51251, N'Printing before approval is disabled for this company.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson, OutputFormat)
    VALUES(@CompanyID, N'JOURNAL', @RequestedBy, (SELECT @JournalID AS JournalID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'PRINT');
    INSERT dbo.Acc_AuditLog(CompanyID, EntityName, EntityID, ActionType, ChangedBy)
    VALUES(@CompanyID, N'Acc_JournalHeader', CONVERT(NVARCHAR(100), @JournalID), N'PRINT', @RequestedBy);

    SELECT h.CompanyID, c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           h.JournalID, h.JournalNo, h.JournalDate, h.JournalType, h.Description, h.JournalStatus,
           CASE h.JournalStatus WHEN 0 THEN N'مسودة — غير معتمد' WHEN 1 THEN N'بانتظار المراجعة' WHEN 2 THEN N'بانتظار الاعتماد'
                WHEN 3 THEN N'معتمد — غير مرحّل' WHEN 4 THEN N'مرحّل' WHEN 5 THEN N'مؤرشف' WHEN 6 THEN N'مرفوض' WHEN 7 THEN N'معكوس' END AS JournalStatusAr,
           h.ReversesJournalID,
           h.PreparedBy, pu.UserName AS PreparedByName, h.PreparedAt,
           h.ReviewedBy, ru.UserName AS ReviewedByName, h.ReviewedAt,
           h.ApprovedBy, au.UserName AS ApprovedByName, h.ApprovedAt,
           h.PostedBy, po.UserName AS PostedByName, h.PostedAt,
           @RequestedBy AS ReportRequestedBy, req.UserName AS ReportRequestedByName,
           l.LineNum, l.SubAccountID, a.AccountCode, a.AccountNameAr, a.AccountNameEn,
           l.CostCenterID, cc.CostCenterCode, cc.CostCenterNameAr, l.LineDescription, l.DebitAmount, l.CreditAmount
    FROM dbo.Acc_JournalHeader h
    JOIN dbo.Mng_Company c ON c.CmpID = h.CompanyID
    JOIN dbo.Acc_vUserDisplay pu ON pu.UsrID = h.PreparedBy
    LEFT JOIN dbo.Acc_vUserDisplay ru ON ru.UsrID = h.ReviewedBy
    LEFT JOIN dbo.Acc_vUserDisplay au ON au.UsrID = h.ApprovedBy
    LEFT JOIN dbo.Acc_vUserDisplay po ON po.UsrID = h.PostedBy
    LEFT JOIN dbo.Acc_vUserDisplay req ON req.UsrID = @RequestedBy
    JOIN dbo.Acc_JournalLine l ON l.CompanyID = h.CompanyID AND l.JournalID = h.JournalID
    JOIN dbo.Acc_SubAccount a ON a.CompanyID = l.CompanyID AND a.SubAccountID = l.SubAccountID
    LEFT JOIN dbo.Acc_CostCenter cc ON cc.CompanyID = l.CompanyID AND cc.CostCenterID = l.CostCenterID
    WHERE h.CompanyID = @CompanyID AND h.JournalID = @JournalID
    ORDER BY l.LineNum;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_GetJournalWorkflow
    @CompanyID INT, @JournalID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT h.CompanyID, h.JournalID, h.JournalNo, h.JournalDate, h.Description, h.JournalStatus, h.JournalType, h.ReversesJournalID,
           h.PreparedBy, pu.UserName AS PreparedByName, h.PreparedAt,
           h.ReviewedBy, ru.UserName AS ReviewedByName, h.ReviewedAt,
           h.ApprovedBy, au.UserName AS ApprovedByName, h.ApprovedAt,
           h.PostedBy, po.UserName AS PostedByName, h.PostedAt,
           h.ArchivedBy, ar.UserName AS ArchivedByName, h.ArchivedAt,
           h.RejectedBy, re.UserName AS RejectedByName, h.RejectedAt, h.RejectionReason,
           h.TotalDebit, h.TotalCredit
    FROM dbo.Acc_JournalHeader h
    JOIN dbo.Acc_vUserDisplay pu ON pu.UsrID = h.PreparedBy
    LEFT JOIN dbo.Acc_vUserDisplay ru ON ru.UsrID = h.ReviewedBy
    LEFT JOIN dbo.Acc_vUserDisplay au ON au.UsrID = h.ApprovedBy
    LEFT JOIN dbo.Acc_vUserDisplay po ON po.UsrID = h.PostedBy
    LEFT JOIN dbo.Acc_vUserDisplay ar ON ar.UsrID = h.ArchivedBy
    LEFT JOIN dbo.Acc_vUserDisplay re ON re.UsrID = h.RejectedBy
    WHERE h.CompanyID = @CompanyID AND h.JournalID = @JournalID;

    SELECT w.WorkflowHistoryID, w.FromStatus, w.ToStatus, w.ActionCode, w.ActionBy, u.UserName AS ActionByName, w.ActionAt, w.ActionNote
    FROM dbo.Acc_WorkflowHistory w JOIN dbo.Acc_vUserDisplay u ON u.UsrID = w.ActionBy
    WHERE w.CompanyID = @CompanyID AND w.JournalID = @JournalID
    ORDER BY w.WorkflowHistoryID;
END;
GO

/* ===================== REPORTS ===================== */
/* Trial balance. Balance-sheet accounts carry all history forward; revenue/expense accounts open at the start of the
   fiscal year containing @DateFrom. Unclosed revenue/expense residue of earlier years appears as one PRIOR-RESULT row,
   so opening and closing columns always balance. @ExcludeClosingEntries=1 gives a pre-closing trial balance. */
CREATE OR ALTER PROCEDURE dbo.Acc_ReportTrialBalance
    @CompanyID INT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT,
    @IncludeZeroBalances BIT = 0, @AccountLevel SMALLINT = NULL, @ExcludeClosingEntries BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51300, N'Invalid report date range.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51301, N'Company does not exist.', 1;
    DECLARE @YearStart DATE;
    SELECT @YearStart = DateFrom FROM dbo.Acc_FiscalYear WHERE CompanyID = @CompanyID AND @DateFrom BETWEEN DateFrom AND DateTo;
    IF @YearStart IS NULL THROW 51302, N'DateFrom is not inside a defined fiscal year.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'TRIAL_BALANCE', @RequestedBy,
           (SELECT @DateFrom AS DateFrom, @DateTo AS DateTo, @IncludeZeroBalances AS IncludeZeroBalances, @AccountLevel AS AccountLevel,
                   @ExcludeClosingEntries AS ExcludeClosingEntries FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT l.SubAccountID, l.AccountCategory, l.JournalDate, l.JournalType, l.DebitAmount, l.CreditAmount
    INTO #L FROM dbo.Acc_vPostedLedger l WHERE l.CompanyID = @CompanyID AND l.JournalDate <= @DateTo;

    CREATE TABLE #TB (SubAccountID BIGINT NULL, AccountCode NVARCHAR(60) NOT NULL, AccountNameAr NVARCHAR(200) NOT NULL,
                      AccountNameEn NVARCHAR(200) NULL, AccountLevel SMALLINT NOT NULL, MainAccountCode NVARCHAR(30) NULL,
                      MainAccountNameAr NVARCHAR(200) NULL, AccountCategory TINYINT NULL,
                      OpeningNet DECIMAL(19,4) NOT NULL, PeriodDebit DECIMAL(19,4) NOT NULL, PeriodCredit DECIMAL(19,4) NOT NULL);

    INSERT #TB
    SELECT a.SubAccountID, a.AccountCode, a.AccountNameAr, a.AccountNameEn, a.AccountLevel, m.MainAccountCode, m.MainAccountNameAr, m.AccountCategory,
           ISNULL(o.OpeningNet, 0), ISNULL(mv.PeriodDebit, 0), ISNULL(mv.PeriodCredit, 0)
    FROM dbo.Acc_SubAccount a
    JOIN dbo.Acc_MainAccount m ON m.CompanyID = a.CompanyID AND m.MainAccountID = a.MainAccountID
    LEFT JOIN (SELECT SubAccountID, SUM(DebitAmount - CreditAmount) AS OpeningNet FROM #L
               WHERE JournalDate < @DateFrom AND (AccountCategory <= 3 OR JournalDate >= @YearStart) GROUP BY SubAccountID) o ON o.SubAccountID = a.SubAccountID
    LEFT JOIN (SELECT SubAccountID, SUM(DebitAmount) AS PeriodDebit, SUM(CreditAmount) AS PeriodCredit FROM #L
               WHERE JournalDate BETWEEN @DateFrom AND @DateTo AND (@ExcludeClosingEntries = 0 OR JournalType <> 5) GROUP BY SubAccountID) mv ON mv.SubAccountID = a.SubAccountID
    WHERE a.CompanyID = @CompanyID AND (@AccountLevel IS NULL OR a.AccountLevel = @AccountLevel);

    DECLARE @Residue DECIMAL(19,4) = ISNULL((SELECT SUM(DebitAmount - CreditAmount) FROM #L WHERE AccountCategory >= 4 AND JournalDate < @YearStart), 0);
    IF @Residue <> 0 AND @AccountLevel IS NULL
        INSERT #TB VALUES(NULL, N'PRIOR-RESULT', N'نتيجة سنوات سابقة غير مقفلة', N'Unclosed prior-year result', 0, NULL, NULL, 3, @Residue, 0, 0);

    SELECT c.CmpID AS CompanyID, c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName,
           t.SubAccountID, t.AccountCode, t.AccountNameAr, t.AccountNameEn, t.AccountLevel, t.MainAccountCode, t.MainAccountNameAr, t.AccountCategory,
           t.OpeningNet,
           CASE WHEN t.OpeningNet > 0 THEN t.OpeningNet ELSE 0 END AS OpeningDebit,
           CASE WHEN t.OpeningNet < 0 THEN -t.OpeningNet ELSE 0 END AS OpeningCredit,
           t.PeriodDebit, t.PeriodCredit,
           t.OpeningNet + t.PeriodDebit - t.PeriodCredit AS ClosingNet,
           CASE WHEN t.OpeningNet + t.PeriodDebit - t.PeriodCredit > 0 THEN t.OpeningNet + t.PeriodDebit - t.PeriodCredit ELSE 0 END AS ClosingDebit,
           CASE WHEN t.OpeningNet + t.PeriodDebit - t.PeriodCredit < 0 THEN -(t.OpeningNet + t.PeriodDebit - t.PeriodCredit) ELSE 0 END AS ClosingCredit
    FROM #TB t
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    WHERE @IncludeZeroBalances = 1 OR t.PeriodDebit <> 0 OR t.PeriodCredit <> 0 OR t.OpeningNet <> 0
    ORDER BY t.AccountCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportAccountStatement
    @CompanyID INT, @SubAccountID BIGINT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT,
    @CostCenterID BIGINT = NULL, @DebitOnly BIT = 0, @CreditOnly BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51310, N'Invalid report date range.', 1;
    IF @DebitOnly = 1 AND @CreditOnly = 1 THROW 51311, N'DebitOnly and CreditOnly cannot both be enabled.', 1;
    DECLARE @Cat TINYINT, @OpenFrom DATE = '00010101', @YearStart DATE;
    SELECT @Cat = m.AccountCategory FROM dbo.Acc_SubAccount a
    JOIN dbo.Acc_MainAccount m ON m.CompanyID = a.CompanyID AND m.MainAccountID = a.MainAccountID
    WHERE a.CompanyID = @CompanyID AND a.SubAccountID = @SubAccountID;
    IF @Cat IS NULL THROW 51312, N'Account not found for this company.', 1;
    IF @Cat >= 4
    BEGIN
        SELECT @YearStart = DateFrom FROM dbo.Acc_FiscalYear WHERE CompanyID = @CompanyID AND @DateFrom BETWEEN DateFrom AND DateTo;
        IF @YearStart IS NULL THROW 51313, N'DateFrom is not inside a defined fiscal year.', 1;
        SET @OpenFrom = @YearStart;
    END;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'ACCOUNT_STATEMENT', @RequestedBy,
           (SELECT @SubAccountID AS SubAccountID, @DateFrom AS DateFrom, @DateTo AS DateTo, @CostCenterID AS CostCenterID,
                   @DebitOnly AS DebitOnly, @CreditOnly AS CreditOnly FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    DECLARE @OpeningNet DECIMAL(19,4) = ISNULL((SELECT SUM(l.DebitAmount - l.CreditAmount) FROM dbo.Acc_vPostedLedger l
        WHERE l.CompanyID = @CompanyID AND l.SubAccountID = @SubAccountID AND l.JournalDate < @DateFrom AND l.JournalDate >= @OpenFrom
          AND (@CostCenterID IS NULL OR l.CostCenterID = @CostCenterID)), 0);

    ;WITH RowsInPeriod AS
    (
        SELECT l.JournalID, l.JournalNo, l.JournalDate, l.JournalDescription, l.LineNum, l.LineDescription, l.CostCenterID,
               l.CostCenterCode, l.CostCenterNameAr, l.DebitAmount, l.CreditAmount,
               SUM(l.DebitAmount - l.CreditAmount) OVER (ORDER BY l.JournalDate, l.JournalID, l.LineNum ROWS UNBOUNDED PRECEDING) AS PeriodRunning
        FROM dbo.Acc_vPostedLedger l
        WHERE l.CompanyID = @CompanyID AND l.SubAccountID = @SubAccountID AND l.JournalDate BETWEEN @DateFrom AND @DateTo
          AND (@CostCenterID IS NULL OR l.CostCenterID = @CostCenterID)
    )
    SELECT c.CmpID AS CompanyID, c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName,
           a.AccountCode, a.AccountNameAr, a.AccountNameEn, @OpeningNet AS OpeningNet,
           r.JournalID, r.JournalNo, r.JournalDate, r.JournalDescription, r.LineNum, r.LineDescription,
           r.CostCenterID, r.CostCenterCode, r.CostCenterNameAr, r.DebitAmount, r.CreditAmount,
           @OpeningNet + r.PeriodRunning AS RunningBalance
    FROM dbo.Mng_Company c
    JOIN dbo.Acc_SubAccount a ON a.CompanyID = c.CmpID AND a.SubAccountID = @SubAccountID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    LEFT JOIN RowsInPeriod r ON 1 = 1
    WHERE c.CmpID = @CompanyID
      AND (r.JournalID IS NULL OR ((@DebitOnly = 0 OR r.DebitAmount > 0) AND (@CreditOnly = 0 OR r.CreditAmount > 0)))
    ORDER BY r.JournalDate, r.JournalID, r.LineNum;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportCostCenterStatement
    @CompanyID INT, @CostCenterID BIGINT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT, @IncludeChildren BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51320, N'Invalid report date range.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID)
        THROW 51321, N'Cost center not found for this company.', 1;
    DECLARE @YearStart DATE;
    SELECT @YearStart = DateFrom FROM dbo.Acc_FiscalYear WHERE CompanyID = @CompanyID AND @DateFrom BETWEEN DateFrom AND DateTo;
    IF @YearStart IS NULL THROW 51322, N'DateFrom is not inside a defined fiscal year.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'COST_CENTER_STATEMENT', @RequestedBy,
           (SELECT @CostCenterID AS CostCenterID, @DateFrom AS DateFrom, @DateTo AS DateTo, @IncludeChildren AS IncludeChildren FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    CREATE TABLE #CC (CostCenterID BIGINT NOT NULL PRIMARY KEY);
    ;WITH CC AS
    (
        SELECT CostCenterID FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID
        UNION ALL
        SELECT c.CostCenterID FROM dbo.Acc_CostCenter c JOIN CC ON c.ParentCostCenterID = CC.CostCenterID
        WHERE c.CompanyID = @CompanyID AND @IncludeChildren = 1
    )
    INSERT #CC SELECT CostCenterID FROM CC;

    DECLARE @OpeningNet DECIMAL(19,4) = ISNULL((SELECT SUM(l.DebitAmount - l.CreditAmount) FROM dbo.Acc_vPostedLedger l
        JOIN #CC x ON x.CostCenterID = l.CostCenterID
        WHERE l.CompanyID = @CompanyID AND l.JournalType <> 5 AND l.JournalDate >= @YearStart AND l.JournalDate < @DateFrom), 0);

    SELECT c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName,
           root.CostCenterCode AS RootCostCenterCode, root.CostCenterNameAr AS RootCostCenterNameAr, @OpeningNet AS OpeningNet,
           l.CostCenterCode, l.CostCenterNameAr, l.JournalDate, l.JournalNo, l.JournalID, l.LineNum,
           l.AccountCode, l.AccountNameAr, l.AccountNameEn, l.LineDescription, l.DebitAmount, l.CreditAmount,
           l.DebitAmount - l.CreditAmount AS NetAmount,
           @OpeningNet + SUM(l.DebitAmount - l.CreditAmount) OVER (ORDER BY l.JournalDate, l.JournalID, l.LineNum ROWS UNBOUNDED PRECEDING) AS RunningBalance
    FROM dbo.Acc_vPostedLedger l
    JOIN #CC x ON x.CostCenterID = l.CostCenterID
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    JOIN dbo.Acc_CostCenter root ON root.CompanyID = @CompanyID AND root.CostCenterID = @CostCenterID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    WHERE l.CompanyID = @CompanyID AND l.JournalType <> 5 AND l.JournalDate BETWEEN @DateFrom AND @DateTo
    ORDER BY l.JournalDate, l.JournalID, l.LineNum;
END;
GO

/* Result set 1: lines of revenue (4) and expense (5) accounts, closing entries excluded.  Result set 2: totals. */
CREATE OR ALTER PROCEDURE dbo.Acc_ReportIncomeStatement
    @CompanyID INT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51330, N'Invalid report date range.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51331, N'Company does not exist.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'INCOME_STATEMENT', @RequestedBy, (SELECT @DateFrom AS DateFrom, @DateTo AS DateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT l.AccountCategory, l.MainAccountCode, l.MainAccountNameAr, l.MainAccountNameEn, l.AccountCode, l.AccountNameAr, l.AccountNameEn,
           SUM(l.DebitAmount) AS TotalDebit, SUM(l.CreditAmount) AS TotalCredit,
           CASE WHEN l.AccountCategory = 4 THEN SUM(l.CreditAmount - l.DebitAmount) ELSE SUM(l.DebitAmount - l.CreditAmount) END AS StatementAmount
    INTO #IS
    FROM dbo.Acc_vPostedLedger l
    WHERE l.CompanyID = @CompanyID AND l.JournalDate BETWEEN @DateFrom AND @DateTo AND l.JournalType <> 5 AND l.AccountCategory IN (4,5)
    GROUP BY l.AccountCategory, l.MainAccountCode, l.MainAccountNameAr, l.MainAccountNameEn, l.AccountCode, l.AccountNameAr, l.AccountNameEn;

    SELECT c.CmpID AS CompanyID, c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName, i.*
    FROM #IS i
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    ORDER BY i.AccountCategory, i.MainAccountCode, i.AccountCode;

    SELECT ISNULL(SUM(CASE WHEN AccountCategory = 4 THEN StatementAmount END), 0) AS TotalRevenue,
           ISNULL(SUM(CASE WHEN AccountCategory = 5 THEN StatementAmount END), 0) AS TotalExpenses,
           ISNULL(SUM(CASE WHEN AccountCategory = 4 THEN StatementAmount END), 0)
         - ISNULL(SUM(CASE WHEN AccountCategory = 5 THEN StatementAmount END), 0) AS NetIncome
    FROM #IS;
END;
GO

/* Result set 1: assets/liabilities/equity accounts plus one computed CURRENT-RESULT row (all revenue/expense
   not yet closed to equity, so the sheet balances before and after closing).  Result set 2: totals and difference. */
CREATE OR ALTER PROCEDURE dbo.Acc_ReportBalanceSheet
    @CompanyID INT, @AsOfDate DATE, @RequestedBy INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @AsOfDate IS NULL THROW 51340, N'AsOfDate is required.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51341, N'Company does not exist.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'BALANCE_SHEET', @RequestedBy, (SELECT @AsOfDate AS AsOfDate FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT l.AccountCategory, l.MainAccountCode, l.MainAccountNameAr, l.MainAccountNameEn, l.AccountCode, l.AccountNameAr, l.AccountNameEn,
           SUM(l.DebitAmount) AS TotalDebit, SUM(l.CreditAmount) AS TotalCredit,
           CASE WHEN l.AccountCategory = 1 THEN SUM(l.DebitAmount - l.CreditAmount) ELSE SUM(l.CreditAmount - l.DebitAmount) END AS BalanceAmount
    INTO #BS
    FROM dbo.Acc_vPostedLedger l
    WHERE l.CompanyID = @CompanyID AND l.JournalDate <= @AsOfDate AND l.AccountCategory IN (1,2,3)
    GROUP BY l.AccountCategory, l.MainAccountCode, l.MainAccountNameAr, l.MainAccountNameEn, l.AccountCode, l.AccountNameAr, l.AccountNameEn
    HAVING SUM(l.DebitAmount) <> 0 OR SUM(l.CreditAmount) <> 0;

    DECLARE @Result DECIMAL(19,4) = ISNULL((SELECT SUM(CreditAmount - DebitAmount) FROM dbo.Acc_vPostedLedger
                                            WHERE CompanyID = @CompanyID AND JournalDate <= @AsOfDate AND AccountCategory IN (4,5)), 0);
    IF @Result <> 0
        INSERT #BS VALUES(3, N'CURRENT', N'نتيجة غير مقفلة', N'Unclosed result', N'CURRENT-RESULT', N'نتيجة الفترة الجارية (غير مقفلة)',
                          N'Current unclosed result', 0, 0, @Result);

    SELECT c.CmpID AS CompanyID, c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @AsOfDate AS AsOfDate, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName, b.*
    FROM #BS b
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    ORDER BY b.AccountCategory, b.MainAccountCode, b.AccountCode;

    SELECT ISNULL(SUM(CASE WHEN AccountCategory = 1 THEN BalanceAmount END), 0) AS TotalAssets,
           ISNULL(SUM(CASE WHEN AccountCategory = 2 THEN BalanceAmount END), 0) AS TotalLiabilities,
           ISNULL(SUM(CASE WHEN AccountCategory = 3 THEN BalanceAmount END), 0) AS TotalEquityIncludingResult,
           ISNULL(SUM(CASE WHEN AccountCategory = 1 THEN BalanceAmount END), 0)
         - ISNULL(SUM(CASE WHEN AccountCategory IN (2,3) THEN BalanceAmount END), 0) AS Difference
    FROM #BS;
END;
GO

/* Direct-method cash movements. Cash accounts = Acc_SubAccount.IsCashEquivalent=1. For every journal touching cash,
   each non-cash line is classified by its account's CashFlowCategory (1 operating, 2 investing, 3 financing, 0 unclassified).
   Result sets: 1 summary by category, 2 detail, 3 cash reconciliation (opening + net change = closing). */
CREATE OR ALTER PROCEDURE dbo.Acc_ReportCashFlow
    @CompanyID INT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51350, N'Invalid report date range.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51351, N'Company does not exist.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'CASH_FLOW', @RequestedBy, (SELECT @DateFrom AS DateFrom, @DateTo AS DateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    DECLARE @OpenCash DECIMAL(19,4) = ISNULL((SELECT SUM(DebitAmount - CreditAmount) FROM dbo.Acc_vPostedLedger
                                              WHERE CompanyID = @CompanyID AND IsCashEquivalent = 1 AND JournalDate < @DateFrom), 0);
    DECLARE @NetCash DECIMAL(19,4) = ISNULL((SELECT SUM(DebitAmount - CreditAmount) FROM dbo.Acc_vPostedLedger
                                             WHERE CompanyID = @CompanyID AND IsCashEquivalent = 1 AND JournalDate BETWEEN @DateFrom AND @DateTo), 0);

    SELECT l.JournalID, l.JournalNo, l.JournalDate, l.SubAccountID, l.AccountCode, l.AccountNameAr, l.AccountNameEn,
           ISNULL(l.CashFlowCategory, 0) AS CashFlowCategory, l.LineDescription, l.CreditAmount - l.DebitAmount AS CashEffect
    INTO #CF
    FROM dbo.Acc_vPostedLedger l
    WHERE l.CompanyID = @CompanyID AND l.JournalDate BETWEEN @DateFrom AND @DateTo AND l.IsCashEquivalent = 0
      AND EXISTS (SELECT 1 FROM dbo.Acc_vPostedLedger k WHERE k.CompanyID = l.CompanyID AND k.JournalID = l.JournalID AND k.IsCashEquivalent = 1);

    SELECT c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo, @DateFrom AS DateFrom, @DateTo AS DateTo,
           @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName,
           f.CashFlowCategory,
           CASE f.CashFlowCategory WHEN 1 THEN N'أنشطة تشغيلية' WHEN 2 THEN N'أنشطة استثمارية' WHEN 3 THEN N'أنشطة تمويلية' ELSE N'غير مصنفة' END AS CategoryNameAr,
           SUM(f.CashEffect) AS NetCashEffect
    FROM #CF f
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    GROUP BY c.CmpName, c.CmpEName, c.CmpLogo, u.UserName, f.CashFlowCategory
    ORDER BY f.CashFlowCategory;

    SELECT * FROM #CF ORDER BY JournalDate, JournalID, AccountCode;

    SELECT @OpenCash AS OpeningCash, @NetCash AS NetCashChange, @OpenCash + @NetCash AS ClosingCash,
           ISNULL((SELECT SUM(CashEffect) FROM #CF), 0) AS ClassifiedTotal,
           @NetCash - ISNULL((SELECT SUM(CashEffect) FROM #CF), 0) AS UnreconciledDifference;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportExpenseRevenueAnalysis
    @CompanyID INT, @AccountCategory TINYINT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT,
    @CostCenterID BIGINT = NULL, @IncludeChildren BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF @AccountCategory NOT IN (4,5) THROW 51360, N'Category must be 4 (revenue) or 5 (expenses).', 1;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51361, N'Invalid report date range.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51362, N'Company does not exist.', 1;
    IF @CostCenterID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID)
        THROW 51363, N'Cost center not found for this company.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'EXPENSE_REVENUE_ANALYSIS', @RequestedBy,
           (SELECT @AccountCategory AS AccountCategory, @CostCenterID AS CostCenterID, @IncludeChildren AS IncludeChildren,
                   @DateFrom AS DateFrom, @DateTo AS DateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    CREATE TABLE #CC (CostCenterID BIGINT NOT NULL PRIMARY KEY);
    IF @CostCenterID IS NOT NULL
    BEGIN
        ;WITH CC AS
        (
            SELECT CostCenterID FROM dbo.Acc_CostCenter WHERE CompanyID = @CompanyID AND CostCenterID = @CostCenterID
            UNION ALL
            SELECT c.CostCenterID FROM dbo.Acc_CostCenter c JOIN CC ON c.ParentCostCenterID = CC.CostCenterID
            WHERE c.CompanyID = @CompanyID AND @IncludeChildren = 1
        )
        INSERT #CC SELECT CostCenterID FROM CC;
    END;

    SELECT c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName,
           l.AccountCategory, l.MainAccountCode, l.MainAccountNameAr, l.AccountCode, l.AccountNameAr,
           l.CostCenterCode, l.CostCenterNameAr,
           SUM(l.DebitAmount) AS TotalDebit, SUM(l.CreditAmount) AS TotalCredit,
           CASE WHEN @AccountCategory = 4 THEN SUM(l.CreditAmount - l.DebitAmount) ELSE SUM(l.DebitAmount - l.CreditAmount) END AS NetAmount
    FROM dbo.Acc_vPostedLedger l
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    WHERE l.CompanyID = @CompanyID AND l.AccountCategory = @AccountCategory AND l.JournalType <> 5
      AND l.JournalDate BETWEEN @DateFrom AND @DateTo
      AND (@CostCenterID IS NULL OR l.CostCenterID IN (SELECT CostCenterID FROM #CC))
    GROUP BY c.CmpName, c.CmpEName, c.CmpLogo, u.UserName, l.AccountCategory, l.MainAccountCode, l.MainAccountNameAr,
             l.AccountCode, l.AccountNameAr, l.CostCenterCode, l.CostCenterNameAr
    ORDER BY l.MainAccountCode, l.AccountCode, l.CostCenterCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportGeneralJournal
    @CompanyID INT, @DateFrom DATE, @DateTo DATE, @RequestedBy INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateFrom > @DateTo THROW 51370, N'Invalid report date range.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51371, N'Company does not exist.', 1;
    INSERT dbo.Acc_ReportRequestLog(CompanyID, ReportCode, RequestedBy, ParametersJson)
    VALUES(@CompanyID, N'GENERAL_JOURNAL', @RequestedBy, (SELECT @DateFrom AS DateFrom, @DateTo AS DateTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER));

    SELECT c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           @DateFrom AS DateFrom, @DateTo AS DateTo, @RequestedBy AS ReportRequestedBy, u.UserName AS ReportRequestedByName,
           l.JournalDate, l.JournalNo, l.JournalID, l.JournalType, l.JournalStatus, l.JournalDescription, l.ReversesJournalID,
           l.LineNum, l.AccountCode, l.AccountNameAr, l.AccountNameEn, l.CostCenterCode, l.CostCenterNameAr,
           l.LineDescription, l.DebitAmount, l.CreditAmount
    FROM dbo.Acc_vPostedLedger l
    JOIN dbo.Mng_Company c ON c.CmpID = @CompanyID
    LEFT JOIN dbo.Acc_vUserDisplay u ON u.UsrID = @RequestedBy
    WHERE l.CompanyID = @CompanyID AND l.JournalDate BETWEEN @DateFrom AND @DateTo
    ORDER BY l.JournalDate, l.JournalID, l.LineNum;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Acc_ReportAccountDirectory
    @CompanyID INT, @IncludeInactive BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @CompanyID) THROW 51380, N'Company does not exist.', 1;
    SELECT c.CmpName AS CompanyNameAr, c.CmpEName AS CompanyNameEn, c.CmpLogo AS CompanyLogo,
           m.MainAccountID, m.MainAccountCode, m.MainAccountNameAr, m.MainAccountNameEn, m.AccountCategory, m.NormalBalance, m.IsActive AS MainIsActive,
           a.SubAccountID, a.AccountCode, a.AccountNameAr, a.AccountNameEn, a.ParentSubAccountID, p.AccountCode AS ParentAccountCode,
           a.AccountLevel, a.AllowPosting, a.IsActive, a.IsCashEquivalent, a.CashFlowCategory
    FROM dbo.Acc_MainAccount m
    JOIN dbo.Mng_Company c ON c.CmpID = m.CompanyID
    LEFT JOIN dbo.Acc_SubAccount a ON a.CompanyID = m.CompanyID AND a.MainAccountID = m.MainAccountID
    LEFT JOIN dbo.Acc_SubAccount p ON p.CompanyID = a.CompanyID AND p.SubAccountID = a.ParentSubAccountID
    WHERE m.CompanyID = @CompanyID
      AND (@IncludeInactive = 1 OR (m.IsActive = 1 AND (a.SubAccountID IS NULL OR a.IsActive = 1)))
    ORDER BY m.SortOrder, m.MainAccountCode, a.AccountCode;
END;
GO

/* ===================== END ===================== */
SET NOEXEC OFF;
GO
PRINT N'MADAR Acc_ unified general-ledger script finished (if a preflight error was printed above, nothing was created).';
GO

/*
  OPERATIONAL NOTES
  1) Permissions: grant EXECUTE on the Acc_ procedures and deny direct INSERT/UPDATE/DELETE on Acc_ tables to end-user
     principals. The triggers protect posted data but a sysadmin/db_owner can disable them.
  2) Company-level and role-level authorization (who may post, close a year, change the account tree) must be enforced
     by the MADAR application or a permission model; this script only proves that users exist.
  3) Cash-flow classification needs IsCashEquivalent on cash/bank accounts and CashFlowCategory on counter accounts.
  4) Year-end order: Acc_PrepareYearClosing -> submit/review/approve/post the closing journal -> Acc_FinalizeFiscalYear.
     Create the next year with Acc_CreateFiscalYear before posting into it.
  5) Reversal order: Acc_ReverseJournal creates a draft; post it through the normal workflow.
  6) Arabic number-to-words: not included - provide the existing MADAR function name/signature to wire it into
     Acc_PrintJournal.
  7) NOT EXECUTED on SQL Server. Test on a restored copy, including: preflight, create year, create accounts,
     draft -> post, reversal, trigger protection, closing, and every report with and without data.
*/

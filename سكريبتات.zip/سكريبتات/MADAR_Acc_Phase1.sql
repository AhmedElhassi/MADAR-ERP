/* =====================================================================
   MADAR ERP - Accounting Module - Phase 1 (integrity core)
   Run AFTER MADAR_Acc_Phase0.sql, on a TEST database first.
   No columns added, no business rule changed. Constraints, indexes, one guard trigger.
   If the tables already contain data, run the CHECK ... duplicate-scan queries
   at the bottom of this file BEFORE creating the unique indexes / constraints.
   ===================================================================== */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ---------- 1. Unique codes per company ---------- */
CREATE UNIQUE NONCLUSTERED INDEX UX_Acc_Account_AccCompany_AccCode
    ON dbo.Acc_Account (AccCompany, AccCode);
GO
CREATE UNIQUE NONCLUSTERED INDEX UX_Acc_CostCenter_CsCCompany_CsCCode
    ON dbo.Acc_CostCenter (CsCCompany, CsCCode);
GO

/* ---------- 2. Tree integrity: self-referencing FKs ---------- */
ALTER TABLE dbo.Acc_Account WITH CHECK
    ADD CONSTRAINT FK_Acc_Account_AccParentID
    FOREIGN KEY (AccParentID) REFERENCES dbo.Acc_Account(AccID);
GO
ALTER TABLE dbo.Acc_CostCenter WITH CHECK
    ADD CONSTRAINT FK_Acc_CostCenter_CsCParentID
    FOREIGN KEY (CsCParentID) REFERENCES dbo.Acc_CostCenter(CsCID);
GO

/* ---------- 3. Domain checks ---------- */
-- AccEnd: 1 = Balance sheet, 2 = Income statement. AccType: 1 / 2 (meaning depends on AccEnd)
ALTER TABLE dbo.Acc_Account WITH CHECK
    ADD CONSTRAINT CK_Acc_Account_AccEnd  CHECK (AccEnd  IN (1,2));
ALTER TABLE dbo.Acc_Account WITH CHECK
    ADD CONSTRAINT CK_Acc_Account_AccType CHECK (AccType IN (1,2));
GO
-- A parent can never be itself
ALTER TABLE dbo.Acc_Account WITH CHECK
    ADD CONSTRAINT CK_Acc_Account_NotOwnParent CHECK (AccParentID IS NULL OR AccParentID <> AccID);
ALTER TABLE dbo.Acc_CostCenter WITH CHECK
    ADD CONSTRAINT CK_Acc_CostCenter_NotOwnParent CHECK (CsCParentID IS NULL OR CsCParentID <> CsCID);
GO
-- Journal state codes 0..7 (0 temp, 1 posted, 2 back-to-fix, 3 reviewed,
-- 4 back-to-review, 5 approved, 6 back-from-archive, 7 archived)
ALTER TABLE dbo.Acc_DayMaster WITH CHECK
    ADD CONSTRAINT CK_Acc_DayMaster_DayMState CHECK (DayMState BETWEEN 0 AND 7);
GO

/* ---------- 4. Journal line amounts ---------- */
-- Defaults: an unfilled side is 0, so a line entered on one side only passes the one-side rule
ALTER TABLE dbo.Acc_DayDetails
    ADD CONSTRAINT DF_Acc_DayDetails_DayDDeb DEFAULT (0) FOR DayDDeb;
ALTER TABLE dbo.Acc_DayDetails
    ADD CONSTRAINT DF_Acc_DayDetails_DayDCrd DEFAULT (0) FOR DayDCrd;
GO
-- Never negative
ALTER TABLE dbo.Acc_DayDetails WITH CHECK
    ADD CONSTRAINT CK_Acc_DayDetails_NonNegative CHECK (DayDDeb >= 0 AND DayDCrd >= 0);
GO
-- A line must carry exactly one side: debit > 0 and credit = 0, or credit > 0 and debit = 0.
-- Forbids zero/zero lines and lines with both sides filled.
ALTER TABLE dbo.Acc_DayDetails WITH CHECK
    ADD CONSTRAINT CK_Acc_DayDetails_OneSide
    CHECK ((DayDDeb > 0 AND DayDCrd = 0) OR (DayDDeb = 0 AND DayDCrd > 0));
GO

/* ---------- 5. Indexes ---------- */
-- Journal header: reports by company/date, alerts by company/state
CREATE NONCLUSTERED INDEX IX_Acc_DayMaster_Company_Date
    ON dbo.Acc_DayMaster (DayMCompany, DayMDate) INCLUDE (DayMState, DayMNo);
CREATE NONCLUSTERED INDEX IX_Acc_DayMaster_Company_State
    ON dbo.Acc_DayMaster (DayMCompany, DayMState) INCLUDE (DayMDate, DayMNo);
GO
-- Journal lines: by header, by account (ledger / trial balance), by cost center
CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDMID
    ON dbo.Acc_DayDetails (DayDMID) INCLUDE (DayDAccID, DayDDeb, DayDCrd, DayDCsCID);
CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDAccID
    ON dbo.Acc_DayDetails (DayDAccID) INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID);
CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDCsCID
    ON dbo.Acc_DayDetails (DayDCsCID) INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd)
    WHERE DayDCsCID IS NOT NULL;
GO
-- Tree navigation
CREATE NONCLUSTERED INDEX IX_Acc_Account_Parent
    ON dbo.Acc_Account (AccCompany, AccParentID) INCLUDE (AccOrder, AccChid);
CREATE NONCLUSTERED INDEX IX_Acc_CostCenter_Parent
    ON dbo.Acc_CostCenter (CsCCompany, CsCParentID) INCLUDE (CsCOrder, CsCChid);
GO
-- History tables: audit screens filter by company/date, user and original id
CREATE NONCLUSTERED INDEX IX_Acc_AccountHistory_Company_Date
    ON dbo.Acc_AccountHistory (AccHCompany, AccHDateTime) INCLUDE (AccHOpration, AccHUser, AccHAccID);
CREATE NONCLUSTERED INDEX IX_Acc_AccountHistory_AccID
    ON dbo.Acc_AccountHistory (AccHAccID, AccHDateTime);
CREATE NONCLUSTERED INDEX IX_Acc_CostCenterHistory_Company_Date
    ON dbo.Acc_CostCenterHistory (CsCHCompany, CsCHDateTime) INCLUDE (CsCHOpration, CsCHUser, CsCHCsCID);
CREATE NONCLUSTERED INDEX IX_Acc_CostCenterHistory_CsCID
    ON dbo.Acc_CostCenterHistory (CsCHCsCID, CsCHDateTime);
CREATE NONCLUSTERED INDEX IX_Acc_DayMasterHistory_MID
    ON dbo.Acc_DayMasterHistory (DayMHMID, DayMHDateTime) INCLUDE (DayMHOpration, DayMHState, DayMHUser);
CREATE NONCLUSTERED INDEX IX_Acc_DayMasterHistory_DateTime
    ON dbo.Acc_DayMasterHistory (DayMHDateTime) INCLUDE (DayMHMID, DayMHState, DayMHUser);
CREATE NONCLUSTERED INDEX IX_Acc_DayDetailsHistory_MID
    ON dbo.Acc_DayDetailsHistory (DayDHMID, DayDHDateTime);
CREATE NONCLUSTERED INDEX IX_Acc_DayDetailsHistory_DID
    ON dbo.Acc_DayDetailsHistory (DayDHDID);
GO

/* ---------- 6. Posting guard trigger ----------
   Blocks, whatever the entry path (UI, import, other modules):
   a) a line on an account that has children (only AccChid = 0 may be posted to)
   b) a line on a cost center that has children
   c) account or cost center belonging to a different company than the journal header
   Not checked here (state values not yet defined): AccState / CsCState = active. */
CREATE OR ALTER TRIGGER dbo.TR_Acc_DayDetails_PostingGuard
ON dbo.Acc_DayDetails
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted i
               JOIN dbo.Acc_Account a ON a.AccID = i.DayDAccID
               WHERE a.AccChid > 0)
    BEGIN
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW 51001, N'لا يمكن الترحيل على حساب له حسابات فرعية (يُرحَّل على الحسابات التحليلية فقط).', 1;
    END;

    IF EXISTS (SELECT 1 FROM inserted i
               JOIN dbo.Acc_CostCenter c ON c.CsCID = i.DayDCsCID
               WHERE c.CsCChid > 0)
    BEGIN
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW 51002, N'لا يمكن الترحيل على مركز تكلفة له مراكز فرعية.', 1;
    END;

    IF EXISTS (SELECT 1 FROM inserted i
               JOIN dbo.Acc_DayMaster m ON m.DayMID = i.DayDMID
               JOIN dbo.Acc_Account a   ON a.AccID  = i.DayDAccID
               WHERE a.AccCompany <> m.DayMCompany)
    BEGIN
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW 51003, N'الحساب لا يتبع شركة القيد.', 1;
    END;

    IF EXISTS (SELECT 1 FROM inserted i
               JOIN dbo.Acc_DayMaster m ON m.DayMID = i.DayDMID
               JOIN dbo.Acc_CostCenter c ON c.CsCID = i.DayDCsCID
               WHERE c.CsCCompany <> m.DayMCompany)
    BEGIN
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW 51004, N'مركز التكلفة لا يتبع شركة القيد.', 1;
    END;
END;
GO

/* ---------- 7. Pre-checks (only needed if tables already hold data) ----------
-- duplicate account codes
SELECT AccCompany, AccCode, COUNT(*) FROM dbo.Acc_Account GROUP BY AccCompany, AccCode HAVING COUNT(*) > 1;
-- duplicate cost center codes
SELECT CsCCompany, CsCCode, COUNT(*) FROM dbo.Acc_CostCenter GROUP BY CsCCompany, CsCCode HAVING COUNT(*) > 1;
-- orphan parents
SELECT a.AccID FROM dbo.Acc_Account a WHERE a.AccParentID IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account p WHERE p.AccID = a.AccParentID);
-- lines with negative or double-sided amounts
SELECT DayDID FROM dbo.Acc_DayDetails
WHERE DayDDeb < 0 OR DayDCrd < 0 OR (DayDDeb > 0 AND DayDCrd > 0) OR (DayDDeb = 0 AND DayDCrd = 0);
-- out-of-range states
SELECT DayMID FROM dbo.Acc_DayMaster WHERE DayMState NOT BETWEEN 0 AND 7;
*/

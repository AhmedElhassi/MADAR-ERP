﻿/*
===============================================================================
MADAR ERP - Accounting Module
Unified installation script: Phase 0 + Phase 1
Database: MADARERPDataBase

PURPOSE
- Unifies the accounting tables, constraints, indexes, and posting guard.
- Preserves the current table/column names and the stated business rules.
- Preserves dbo.Tafkeet currency wording/rounding and rejects a NULL currency type.

IMPORTANT
- Run first on a TEST database, not production.
- Creates missing base management tables using the supplied source definitions;
  existing management tables are left unchanged.
- This is a clean-install script for the accounting module. It intentionally
  stops if any Acc_* accounting table already exists; do not run over Phase 0.
- Journal balance is enforced for every journal state except state 0 (temporary).
- Includes safeguards for closed fiscal years, archived journals, journal balance,
  account/cost-center tree cycles, and parent/child company consistency.
===============================================================================
*/
USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO


/* Abort before any change if this is not a clean accounting installation. */
IF OBJECT_ID(N'dbo.Acc_CompanySettings', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_FiscalYear', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_Account', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_CostCenter', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_DayMaster', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_DayDetails', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_AccountHistory', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_CostCenterHistory', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_DayMasterHistory', N'U') IS NOT NULL
 OR OBJECT_ID(N'dbo.Acc_DayDetailsHistory', N'U') IS NOT NULL
    THROW 51094, N'توجد جداول محاسبة Acc_* بالفعل. أوقف التنفيذ ولا تشغّل سكريبت التثبيت فوق Phase 0؛ يلزم مسار ترقية منفصل.', 1;
GO


CREATE OR ALTER FUNCTION dbo.Tafkeet
(
    @TheNo numeric(18,3),
    @TheNoType tinyint
)
RETURNS nvarchar(1000)
AS
BEGIN
    IF @TheNo IS NULL OR @TheNo < 0 RETURN N'مبلغ غير صالح';
    IF @TheNoType IS NULL OR @TheNoType NOT IN (1,2,3) RETURN N'نوع العملة غير صحيح';

    DECLARE @Amount numeric(18,3) = @TheNo;
    DECLARE @FractionScale int = 1000;
    IF @TheNoType IN (2,3)
    BEGIN
        SET @Amount = ROUND(@Amount, 2);
        SET @FractionScale = 100;
    END

    DECLARE @Whole bigint = CONVERT(bigint, FLOOR(@Amount));
    DECLARE @Fraction int = CONVERT(int, ROUND((@Amount - FLOOR(@Amount)) * @FractionScale, 0));
    DECLARE @IntegerWords nvarchar(800) = N'';
    DECLARE @Remaining bigint = @Whole;
    DECLARE @GroupIndex int = 0;
    DECLARE @GroupValue int;
    DECLARE @Hundreds int;
    DECLARE @Remainder int;
    DECLARE @HundredsWord nvarchar(40);
    DECLARE @RemainderWords nvarchar(100);
    DECLARE @TensWord nvarchar(40);
    DECLARE @UnitsWord nvarchar(40);
    DECLARE @GroupWords nvarchar(200);
    DECLARE @GroupPhrase nvarchar(300);

    WHILE @Remaining > 0
    BEGIN
        SET @GroupValue = CONVERT(int, @Remaining % 1000);
        IF @GroupValue > 0
        BEGIN
            SET @Hundreds = @GroupValue / 100;
            SET @Remainder = @GroupValue % 100;
            SET @HundredsWord = CASE @Hundreds
                WHEN 1 THEN N'مائة' WHEN 2 THEN N'مائتان' WHEN 3 THEN N'ثلاثمائة'
                WHEN 4 THEN N'أربعمائة' WHEN 5 THEN N'خمسمائة' WHEN 6 THEN N'ستمائة'
                WHEN 7 THEN N'سبعمائة' WHEN 8 THEN N'ثمانمائة' WHEN 9 THEN N'تسعمائة'
                ELSE N'' END;
            SET @RemainderWords = N'';

            IF @Remainder BETWEEN 1 AND 19
            BEGIN
                SET @RemainderWords = CASE @Remainder
                    WHEN 1 THEN N'واحد' WHEN 2 THEN N'اثنان' WHEN 3 THEN N'ثلاثة'
                    WHEN 4 THEN N'أربعة' WHEN 5 THEN N'خمسة' WHEN 6 THEN N'ستة'
                    WHEN 7 THEN N'سبعة' WHEN 8 THEN N'ثمانية' WHEN 9 THEN N'تسعة'
                    WHEN 10 THEN N'عشرة' WHEN 11 THEN N'أحد عشر' WHEN 12 THEN N'اثنا عشر'
                    WHEN 13 THEN N'ثلاثة عشر' WHEN 14 THEN N'أربعة عشر' WHEN 15 THEN N'خمسة عشر'
                    WHEN 16 THEN N'ستة عشر' WHEN 17 THEN N'سبعة عشر' WHEN 18 THEN N'ثمانية عشر'
                    WHEN 19 THEN N'تسعة عشر' ELSE N'' END;
            END
            ELSE IF @Remainder >= 20
            BEGIN
                SET @TensWord = CASE (@Remainder / 10) * 10
                    WHEN 20 THEN N'عشرون' WHEN 30 THEN N'ثلاثون' WHEN 40 THEN N'أربعون'
                    WHEN 50 THEN N'خمسون' WHEN 60 THEN N'ستون' WHEN 70 THEN N'سبعون'
                    WHEN 80 THEN N'ثمانون' WHEN 90 THEN N'تسعون' ELSE N'' END;
                SET @UnitsWord = CASE @Remainder % 10
                    WHEN 1 THEN N'واحد' WHEN 2 THEN N'اثنان' WHEN 3 THEN N'ثلاثة'
                    WHEN 4 THEN N'أربعة' WHEN 5 THEN N'خمسة' WHEN 6 THEN N'ستة'
                    WHEN 7 THEN N'سبعة' WHEN 8 THEN N'ثمانية' WHEN 9 THEN N'تسعة' ELSE N'' END;
                SET @RemainderWords = CASE WHEN @UnitsWord = N'' THEN @TensWord ELSE @UnitsWord + N' و' + @TensWord END;
            END

            SET @GroupWords = CASE WHEN @HundredsWord = N'' THEN @RemainderWords
                                   WHEN @RemainderWords = N'' THEN @HundredsWord
                                   ELSE @HundredsWord + N' و' + @RemainderWords END;

            SET @GroupPhrase = @GroupWords;
            IF @GroupIndex = 1
            BEGIN
                SET @GroupPhrase = CASE
                    WHEN @GroupValue = 1 THEN N'ألف'
                    WHEN @GroupValue = 2 THEN N'ألفان'
                    WHEN @GroupValue BETWEEN 3 AND 10 THEN @GroupWords + N' آلاف'
                    ELSE @GroupWords + N' ألفًا' END;
            END
            ELSE IF @GroupIndex = 2
            BEGIN
                SET @GroupPhrase = CASE
                    WHEN @GroupValue = 1 THEN N'مليون'
                    WHEN @GroupValue = 2 THEN N'مليونان'
                    WHEN @GroupValue BETWEEN 3 AND 10 THEN @GroupWords + N' ملايين'
                    ELSE @GroupWords + N' مليونًا' END;
            END
            ELSE IF @GroupIndex = 3
            BEGIN
                SET @GroupPhrase = CASE
                    WHEN @GroupValue = 1 THEN N'مليار'
                    WHEN @GroupValue = 2 THEN N'ملياران'
                    WHEN @GroupValue BETWEEN 3 AND 10 THEN @GroupWords + N' مليارات'
                    ELSE @GroupWords + N' مليارًا' END;
            END
            ELSE IF @GroupIndex = 4
            BEGIN
                SET @GroupPhrase = CASE
                    WHEN @GroupValue = 1 THEN N'تريليون'
                    WHEN @GroupValue = 2 THEN N'تريليونان'
                    WHEN @GroupValue BETWEEN 3 AND 10 THEN @GroupWords + N' تريليونات'
                    ELSE @GroupWords + N' تريليونًا' END;
            END

            SET @IntegerWords = CASE WHEN @IntegerWords = N'' THEN @GroupPhrase
                                     ELSE @GroupPhrase + N' و' + @IntegerWords END;
        END

        SET @Remaining = @Remaining / 1000;
        SET @GroupIndex = @GroupIndex + 1;
    END

    DECLARE @MajorWords nvarchar(850) = N'';
    DECLARE @MinorWords nvarchar(250) = N'';
    DECLARE @FractionWords nvarchar(200) = N'';
    DECLARE @CurrencyEnding nvarchar(80);

    IF @Whole = 0 AND @Fraction = 0
        SET @MajorWords = N'صفر';
    ELSE IF @Whole > 0
    BEGIN
        IF @TheNoType = 1
            SET @MajorWords = CASE
                WHEN @Whole = 1 THEN N'دينار واحد'
                WHEN @Whole = 2 THEN N'ديناران'
                WHEN @Whole BETWEEN 3 AND 10 THEN @IntegerWords + N' دنانير'
                ELSE @IntegerWords + N' دينار' END;
        ELSE IF @TheNoType = 2
            SET @MajorWords = CASE
                WHEN @Whole = 1 THEN N'دولار واحد'
                WHEN @Whole = 2 THEN N'دولاران'
                WHEN @Whole BETWEEN 3 AND 10 THEN @IntegerWords + N' دولارات'
                ELSE @IntegerWords + N' دولار' END;
        ELSE
            SET @MajorWords = CASE
                WHEN @Whole = 1 THEN N'يورو واحد'
                WHEN @Whole = 2 THEN N'يوروان'
                WHEN @Whole BETWEEN 3 AND 10 THEN @IntegerWords + N' يوروهات'
                ELSE @IntegerWords + N' يورو' END;
    END

    IF @Fraction > 0
    BEGIN
        SET @Remaining = @Fraction;
        SET @Hundreds = CONVERT(int, @Remaining / 100);
        SET @Remainder = CONVERT(int, @Remaining % 100);
        SET @HundredsWord = CASE @Hundreds
            WHEN 1 THEN N'مائة' WHEN 2 THEN N'مائتان' WHEN 3 THEN N'ثلاثمائة'
            WHEN 4 THEN N'أربعمائة' WHEN 5 THEN N'خمسمائة' WHEN 6 THEN N'ستمائة'
            WHEN 7 THEN N'سبعمائة' WHEN 8 THEN N'ثمانمائة' WHEN 9 THEN N'تسعمائة'
            ELSE N'' END;
        SET @RemainderWords = N'';

        IF @Remainder BETWEEN 1 AND 19
        BEGIN
            SET @RemainderWords = CASE @Remainder
                WHEN 1 THEN N'واحد' WHEN 2 THEN N'اثنان' WHEN 3 THEN N'ثلاثة'
                WHEN 4 THEN N'أربعة' WHEN 5 THEN N'خمسة' WHEN 6 THEN N'ستة'
                WHEN 7 THEN N'سبعة' WHEN 8 THEN N'ثمانية' WHEN 9 THEN N'تسعة'
                WHEN 10 THEN N'عشرة' WHEN 11 THEN N'أحد عشر' WHEN 12 THEN N'اثنا عشر'
                WHEN 13 THEN N'ثلاثة عشر' WHEN 14 THEN N'أربعة عشر' WHEN 15 THEN N'خمسة عشر'
                WHEN 16 THEN N'ستة عشر' WHEN 17 THEN N'سبعة عشر' WHEN 18 THEN N'ثمانية عشر'
                WHEN 19 THEN N'تسعة عشر' ELSE N'' END;
        END
        ELSE IF @Remainder >= 20
        BEGIN
            SET @TensWord = CASE (@Remainder / 10) * 10
                WHEN 20 THEN N'عشرون' WHEN 30 THEN N'ثلاثون' WHEN 40 THEN N'أربعون'
                WHEN 50 THEN N'خمسون' WHEN 60 THEN N'ستون' WHEN 70 THEN N'سبعون'
                WHEN 80 THEN N'ثمانون' WHEN 90 THEN N'تسعون' ELSE N'' END;
            SET @UnitsWord = CASE @Remainder % 10
                WHEN 1 THEN N'واحد' WHEN 2 THEN N'اثنان' WHEN 3 THEN N'ثلاثة'
                WHEN 4 THEN N'أربعة' WHEN 5 THEN N'خمسة' WHEN 6 THEN N'ستة'
                WHEN 7 THEN N'سبعة' WHEN 8 THEN N'ثمانية' WHEN 9 THEN N'تسعة' ELSE N'' END;
            SET @RemainderWords = CASE WHEN @UnitsWord = N'' THEN @TensWord ELSE @UnitsWord + N' و' + @TensWord END;
        END

        SET @FractionWords = CASE WHEN @HundredsWord = N'' THEN @RemainderWords
                                  WHEN @RemainderWords = N'' THEN @HundredsWord
                                  ELSE @HundredsWord + N' و' + @RemainderWords END;

        IF @TheNoType = 1
            SET @MinorWords = CASE
                WHEN @Fraction = 1 THEN N'درهم واحد'
                WHEN @Fraction = 2 THEN N'درهمان'
                WHEN @Fraction BETWEEN 3 AND 10 THEN @FractionWords + N' دراهم'
                ELSE @FractionWords + N' درهم' END;
        ELSE
            SET @MinorWords = CASE
                WHEN @Fraction = 1 THEN N'سنت واحد'
                WHEN @Fraction = 2 THEN N'سنتان'
                WHEN @Fraction BETWEEN 3 AND 10 THEN @FractionWords + N' سنتات'
                ELSE @FractionWords + N' سنت' END;
    END

    DECLARE @Result nvarchar(1000) = @MajorWords;
    IF @MinorWords <> N''
        SET @Result = CASE WHEN @Result = N'' THEN @MinorWords ELSE @Result + N' و' + @MinorWords END;

    SET @CurrencyEnding = CASE @TheNoType WHEN 1 THEN N'ليبي فقط لا غير'
                                               WHEN 2 THEN N'أمريكي فقط لا غير'
                                               ELSE N'أوروبي فقط لا غير' END;
    SET @Result = LTRIM(RTRIM(COALESCE(@Result, N'')));
    IF @Result = N'' SET @Result = N'صفر';
    RETURN @Result + N' ' + @CurrencyEnding;
END

GO

/* ---------- 0. Base management tables from the supplied source ----------
   Existing tables are preserved as-is. Missing tables are created using the
   supplied definitions; no existing management table is altered. */
IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Mng_Company
    (
        CmpID INT NOT NULL,
        CmpName NVARCHAR(255) NULL,
        CmpEName NVARCHAR(255) NULL,
        CmpLogo VARBINARY(MAX) NULL,
        CmpState TINYINT NULL,
        CmpDateTime DATETIME NULL,
        CmpUser BIGINT NULL,
        CmpSystems NVARCHAR(500) NULL,
        CONSTRAINT PK_Mng_Company PRIMARY KEY CLUSTERED (CmpID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Emp_Employee', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Emp_Employee
    (
        EmpID BIGINT IDENTITY(1,1) NOT NULL,
        EmpNum NVARCHAR(10) NULL,
        EmpName NVARCHAR(50) NULL,
        EmpPic VARBINARY(MAX) NULL,
        EmpState TINYINT NULL,
        EmpDateTime DATETIME NULL,
        EmpUser BIGINT NULL,
        EmpCompany INT NULL,
        CONSTRAINT PK_Emp_Employee PRIMARY KEY CLUSTERED (EmpID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Mng_System', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Mng_System
    (
        SysID TINYINT NOT NULL,
        SysName NVARCHAR(255) NULL,
        SysEName NVARCHAR(255) NULL,
        SysLogo VARBINARY(MAX) NULL,
        SysMenu NVARCHAR(500) NULL,
        SysState TINYINT NULL,
        SysDateTime DATETIME NULL,
        CONSTRAINT PK_Mng_System PRIMARY KEY CLUSTERED (SysID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Mng_SystemMenu', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Mng_SystemMenu
    (
        SysMID TINYINT NOT NULL,
        SysMSysID TINYINT NOT NULL,
        SysMParent TINYINT NULL,
        SysMName NVARCHAR(50) NULL,
        SysMEName NVARCHAR(50) NULL,
        SysMLogo NVARCHAR(50) NULL,
        SysMMap NVARCHAR(50) NULL,
        SysMState TINYINT NULL,
        SysMDateTime DATETIME NULL,
        CONSTRAINT PK_Mng_SystemMenu PRIMARY KEY CLUSTERED (SysMSysID, SysMID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Mng_User', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Mng_User
    (
        UsrID BIGINT NOT NULL,
        UsrLogIn NVARCHAR(50) NOT NULL,
        UsrPassWord NVARCHAR(255) NOT NULL,
        UsrState TINYINT NOT NULL,
        UsrDateTime DATETIME NOT NULL,
        UsrUser BIGINT NULL,
        CONSTRAINT PK_Mng_User PRIMARY KEY CLUSTERED (UsrID),
        CONSTRAINT UQ_Mng_User_UsrLogIn UNIQUE NONCLUSTERED (UsrLogIn)
    );
END;
GO

IF OBJECT_ID(N'dbo.Mng_UserParmations', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Mng_UserParmations
    (
        USPID BIGINT IDENTITY(1,1) NOT NULL,
        USPUserID BIGINT NULL,
        USPCompanyID INT NULL,
        USPSystemID TINYINT NULL,
        USPParmations NVARCHAR(500) NULL,
        USPState TINYINT NULL,
        USPDateTime DATETIME NULL,
        USPUser BIGINT NULL,
        CONSTRAINT PK_Mng_UserParmations PRIMARY KEY CLUSTERED (USPID)
    );
END;
GO

/* Verify the management tables expose the keys required by accounting. */
IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NULL
    THROW 51090, N'الجدول dbo.Mng_Company غير موجود.', 1;
IF COL_LENGTH(N'dbo.Mng_Company', N'CmpID') IS NULL
    THROW 51091, N'العمود dbo.Mng_Company.CmpID غير موجود.', 1;
IF OBJECT_ID(N'dbo.Mng_User', N'U') IS NULL
    THROW 51092, N'الجدول dbo.Mng_User غير موجود.', 1;
IF COL_LENGTH(N'dbo.Mng_User', N'UsrID') IS NULL
    THROW 51093, N'العمود dbo.Mng_User.UsrID غير موجود.', 1;



/* ===================== PHASE 0: ACCOUNTING TABLES ===================== */

CREATE TABLE dbo.Acc_CompanySettings
(
    AccSCmpID INT NOT NULL CONSTRAINT PK_Acc_CompanySettings PRIMARY KEY,
    AccSReview BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_Review DEFAULT (0),
    AccSApproval BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_Approval DEFAULT (0),
    AccSArchive BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_Archive DEFAULT (0),
    AccSState BIT NOT NULL CONSTRAINT DF_Acc_CompanySettings_AccSState DEFAULT (0),
    AccSDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CompanySettings_AccSDateTime DEFAULT (SYSUTCDATETIME()),
    AccSUser BIGINT NULL,
    CONSTRAINT FK_Acc_CompanySettings_Company FOREIGN KEY (AccSCmpID) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_CompanySettings_User FOREIGN KEY (AccSUser) REFERENCES dbo.Mng_User(UsrID)
);
GO

CREATE TABLE dbo.Acc_FiscalYear
(
    AccFYear INT NOT NULL,
    AccFName NVARCHAR(100) NOT NULL,
    AccFState BIT NOT NULL CONSTRAINT DF_Acc_FiscalYear_AccFState DEFAULT (0),
    AccFDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_FiscalYear_AccFDateTime DEFAULT (SYSUTCDATETIME()),
    AccFUser BIGINT NOT NULL,
    AccFCmpID INT NOT NULL,
    CONSTRAINT PK_Acc_FiscalYear PRIMARY KEY (AccFYear, AccFCmpID),
    CONSTRAINT FK_Acc_FiscalYear_AccFUser FOREIGN KEY (AccFUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_FiscalYear_AccFCmpID FOREIGN KEY (AccFCmpID) REFERENCES dbo.Mng_Company(CmpID)
);
GO

CREATE TABLE dbo.Acc_Account
(
    AccID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_Account PRIMARY KEY,
    AccEnd TINYINT NOT NULL,
    AccType TINYINT NOT NULL,
    AccParentID BIGINT NULL,
    AccOrder TINYINT NOT NULL,
    AccLevel SMALLINT NOT NULL,
    AccChid SMALLINT NOT NULL,
    AccCode NVARCHAR(60) NOT NULL,
    AccName NVARCHAR(500) NOT NULL,
    AccState TINYINT NOT NULL CONSTRAINT DF_Acc_Account_AccState DEFAULT (0),
    AccDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_Account_AccDateTime DEFAULT (SYSUTCDATETIME()),
    AccUser BIGINT NOT NULL,
    AccCompany INT NOT NULL,
    CONSTRAINT FK_Acc_Account_AccUser FOREIGN KEY (AccUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_Account_AccCompany FOREIGN KEY (AccCompany) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_Account_AccParentID FOREIGN KEY (AccParentID) REFERENCES dbo.Acc_Account(AccID),
    CONSTRAINT CK_Acc_Account_AccEnd CHECK (AccEnd IN (1,2)),
    CONSTRAINT CK_Acc_Account_AccType CHECK (AccType IN (1,2)),
    CONSTRAINT CK_Acc_Account_NotOwnParent CHECK (AccParentID IS NULL OR AccParentID <> AccID)
);
GO

CREATE TABLE dbo.Acc_CostCenter
(
    CsCID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_CostCenter PRIMARY KEY,
    CsCParentID BIGINT NULL,
    CsCOrder TINYINT NOT NULL,
    CsCLevel SMALLINT NOT NULL,
    CsCChid SMALLINT NOT NULL,
    CsCCode NVARCHAR(60) NOT NULL,
    CsCName NVARCHAR(500) NOT NULL,
    CsCState TINYINT NOT NULL CONSTRAINT DF_Acc_CostCenter_CsCState DEFAULT (0),
    CsCDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CostCenter_CsCDateTime DEFAULT (SYSUTCDATETIME()),
    CsCUser BIGINT NOT NULL,
    CsCCompany INT NOT NULL,
    CONSTRAINT FK_Acc_CostCenter_CsCUser FOREIGN KEY (CsCUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_CostCenter_CsCCompany FOREIGN KEY (CsCCompany) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT FK_Acc_CostCenter_CsCParentID FOREIGN KEY (CsCParentID) REFERENCES dbo.Acc_CostCenter(CsCID),
    CONSTRAINT CK_Acc_CostCenter_NotOwnParent CHECK (CsCParentID IS NULL OR CsCParentID <> CsCID)
);
GO

CREATE TABLE dbo.Acc_DayMaster
(
    DayMID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayMaster PRIMARY KEY,
    DayMDate DATE NOT NULL,
    DayMDescription NVARCHAR(MAX) NOT NULL,
    DayMNo INT NOT NULL,
    DayMState TINYINT NOT NULL CONSTRAINT DF_Acc_DayMaster_DayMState DEFAULT (0),
    DayMDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_DayMaster_DayMDateTime DEFAULT (SYSUTCDATETIME()),
    DayMUser BIGINT NOT NULL,
    DayMCompany INT NOT NULL,
    CONSTRAINT FK_Acc_DayMaster_DayMUser FOREIGN KEY (DayMUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_DayMaster_DayMCompany FOREIGN KEY (DayMCompany) REFERENCES dbo.Mng_Company(CmpID),
    CONSTRAINT CK_Acc_DayMaster_DayMState CHECK (DayMState BETWEEN 0 AND 7)
);
GO

CREATE TABLE dbo.Acc_DayDetails
(
    DayDID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayDetails PRIMARY KEY,
    DayDMID BIGINT NOT NULL,
    DayDAccID BIGINT NOT NULL,
    DayDDeb DECIMAL(15,3) NOT NULL,
    DayDCrd DECIMAL(15,3) NOT NULL,
    DayDCsCID BIGINT NULL,
    DayDNum NVARCHAR(50) NULL,
    DayDDescription NVARCHAR(MAX) NULL,
    CONSTRAINT FK_Acc_DayDetails_DayDMID FOREIGN KEY (DayDMID) REFERENCES dbo.Acc_DayMaster(DayMID),
    CONSTRAINT FK_Acc_DayDetails_DayDAccID FOREIGN KEY (DayDAccID) REFERENCES dbo.Acc_Account(AccID),
    CONSTRAINT FK_Acc_DayDetails_DayDCsCID FOREIGN KEY (DayDCsCID) REFERENCES dbo.Acc_CostCenter(CsCID),
    CONSTRAINT CK_Acc_DayDetails_NonNegative CHECK (DayDDeb >= 0 AND DayDCrd >= 0),
    CONSTRAINT CK_Acc_DayDetails_OneSide CHECK
        ((DayDDeb > 0 AND DayDCrd = 0) OR (DayDDeb = 0 AND DayDCrd > 0))
);
GO

/* ===================== HISTORY TABLES ===================== */

CREATE TABLE dbo.Acc_AccountHistory
(
    AccHID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_AccountHistory PRIMARY KEY,
    AccHOpration TINYINT NOT NULL,
    AccHAccID BIGINT NOT NULL,
    AccHEnd TINYINT NOT NULL,
    AccHType TINYINT NOT NULL,
    AccHParentID BIGINT NULL,
    AccHOrder TINYINT NOT NULL,
    AccHLevel SMALLINT NOT NULL,
    AccHChid SMALLINT NOT NULL,
    AccHCode NVARCHAR(60) NOT NULL,
    AccHName NVARCHAR(500) NOT NULL,
    AccHState TINYINT NOT NULL CONSTRAINT DF_Acc_AccountHistory_AccHState DEFAULT (0),
    AccHDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_AccountHistory_AccHDateTime DEFAULT (SYSUTCDATETIME()),
    AccHUser BIGINT NOT NULL,
    AccHCompany INT NOT NULL,
    CONSTRAINT FK_Acc_AccountHistory_User FOREIGN KEY (AccHUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_AccountHistory_Company FOREIGN KEY (AccHCompany) REFERENCES dbo.Mng_Company(CmpID)
);
GO

CREATE TABLE dbo.Acc_CostCenterHistory
(
    CsCHID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_CostCenterHistory PRIMARY KEY,
    CsCHOpration TINYINT NOT NULL,
    CsCHCsCID BIGINT NOT NULL,
    CsCHParentID BIGINT NULL,
    CsCHOrder TINYINT NOT NULL,
    CsCHLevel SMALLINT NOT NULL,
    CsCHChid SMALLINT NOT NULL,
    CsCHCode NVARCHAR(60) NOT NULL,
    CsCHName NVARCHAR(500) NOT NULL,
    CsCHState TINYINT NOT NULL CONSTRAINT DF_Acc_CostCenterHistory_CsCHState DEFAULT (0),
    CsCHDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_CostCenterHistory_CsCHDateTime DEFAULT (SYSUTCDATETIME()),
    CsCHUser BIGINT NOT NULL,
    CsCHCompany INT NOT NULL,
    CONSTRAINT FK_Acc_CostCenterHistory_User FOREIGN KEY (CsCHUser) REFERENCES dbo.Mng_User(UsrID),
    CONSTRAINT FK_Acc_CostCenterHistory_Company FOREIGN KEY (CsCHCompany) REFERENCES dbo.Mng_Company(CmpID)
);
GO

CREATE TABLE dbo.Acc_DayMasterHistory
(
    DayMHID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayMasterHistory PRIMARY KEY,
    DayMHOpration TINYINT NOT NULL,
    DayMHMID BIGINT NOT NULL,
    DayMHMDate DATE NOT NULL,
    DayMHMDescription NVARCHAR(MAX) NOT NULL,
    DayMHState TINYINT NOT NULL,
    DayMHDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_DayMasterHistory_DayMHDateTime DEFAULT (SYSUTCDATETIME()),
    DayMHUser BIGINT NOT NULL,
    CONSTRAINT FK_Acc_DayMasterHistory_User FOREIGN KEY (DayMHUser) REFERENCES dbo.Mng_User(UsrID)
);
GO

CREATE TABLE dbo.Acc_DayDetailsHistory
(
    DayDHID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayDetailsHistory PRIMARY KEY,
    DayDHOpration TINYINT NOT NULL,
    DayDHMID BIGINT NOT NULL,
    DayDHAccID BIGINT NOT NULL,
    DayDHDeb DECIMAL(15,3) NOT NULL,
    DayDHCrd DECIMAL(15,3) NOT NULL,
    DayDHCsCID BIGINT NULL,
    DayDHNum NVARCHAR(50) NULL,
    DayDHDescription NVARCHAR(MAX) NULL,
    DayDHState TINYINT NOT NULL,
    DayDHDateTime DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_DayDetailsHistory_DayDHDateTime DEFAULT (SYSUTCDATETIME()),
    DayDHUser BIGINT NOT NULL,
    CONSTRAINT FK_Acc_DayDetailsHistory_Account FOREIGN KEY (DayDHAccID) REFERENCES dbo.Acc_Account(AccID),
    CONSTRAINT FK_Acc_DayDetailsHistory_CostCenter FOREIGN KEY (DayDHCsCID) REFERENCES dbo.Acc_CostCenter(CsCID),
    CONSTRAINT FK_Acc_DayDetailsHistory_User FOREIGN KEY (DayDHUser) REFERENCES dbo.Mng_User(UsrID)
);
GO


/* ===================== PHASE 1: INTEGRITY, INDEXES, GUARD ===================== */

/* A fiscal year may be closed only after every journal in it is archived. */
CREATE OR ALTER TRIGGER dbo.TR_Acc_FiscalYear_CloseGuard
ON dbo.Acc_FiscalYear
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS fy
        INNER JOIN dbo.Acc_DayMaster AS m
            ON m.DayMCompany = fy.AccFCmpID AND YEAR(m.DayMDate) = fy.AccFYear
        WHERE fy.AccFState = 1
          AND m.DayMState <> 7
    )
        THROW 51025, N'لا يمكن إقفال السنة المالية قبل أرشفة جميع قيودها.', 1;
END;
GO

/* Keep account hierarchy company/classification-consistent and acyclic. */
CREATE OR ALTER TRIGGER dbo.TR_Acc_Account_TreeGuard
ON dbo.Acc_Account
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_Account AS p ON p.AccID = i.AccParentID
        WHERE p.AccCompany <> i.AccCompany
    )
        THROW 51010, N'يجب أن يتبع الحساب الأب والابن الشركة نفسها.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_Account AS p ON p.AccID = i.AccParentID
        WHERE p.AccEnd <> i.AccEnd OR p.AccType <> i.AccType
    )
        THROW 51011, N'يجب أن يتوافق تصنيف الحساب مع تصنيف الحساب الأب.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS p
        INNER JOIN dbo.Acc_Account AS child ON child.AccParentID = p.AccID
        WHERE child.AccCompany <> p.AccCompany
           OR child.AccEnd <> p.AccEnd
           OR child.AccType <> p.AccType
    )
        THROW 51012, N'لا يمكن تغيير الشركة أو التصنيف بما يخالف حسابات هذا الحساب الفرعية.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN deleted AS d ON d.AccID = i.AccID
        WHERE ISNULL(i.AccParentID, CONVERT(BIGINT, -1)) <> ISNULL(d.AccParentID, CONVERT(BIGINT, -1))
          AND EXISTS (SELECT 1 FROM dbo.Acc_DayDetails AS jd WHERE jd.DayDAccID = i.AccID)
    )
        THROW 51013, N'لا يجوز نقل حساب سبق استخدامه في قيد محاسبي.', 1;

    DECLARE @AccountCycleFound BIT = 0;
    ;WITH ParentChain AS
    (
        SELECT i.AccID AS StartAccID, p.AccID AS AncestorID, p.AccParentID
        FROM inserted AS i
        INNER JOIN dbo.Acc_Account AS p ON p.AccID = i.AccParentID
        UNION ALL
        SELECT pc.StartAccID, p.AccID, p.AccParentID
        FROM ParentChain AS pc
        INNER JOIN dbo.Acc_Account AS p ON p.AccID = pc.AccParentID
    )
    SELECT @AccountCycleFound = 1
    FROM ParentChain
    WHERE AncestorID = StartAccID
    OPTION (MAXRECURSION 32767);

    IF @AccountCycleFound = 1
        THROW 51014, N'لا يمكن إنشاء دورة في شجرة الحسابات.', 1;
END;
GO

/* Keep cost-center hierarchy company-consistent and acyclic. */
CREATE OR ALTER TRIGGER dbo.TR_Acc_CostCenter_TreeGuard
ON dbo.Acc_CostCenter
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_CostCenter AS p ON p.CsCID = i.CsCParentID
        WHERE p.CsCCompany <> i.CsCCompany
    )
        THROW 51015, N'يجب أن يتبع مركز التكلفة الأب والابن الشركة نفسها.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS p
        INNER JOIN dbo.Acc_CostCenter AS child ON child.CsCParentID = p.CsCID
        WHERE child.CsCCompany <> p.CsCCompany
    )
        THROW 51016, N'لا يمكن تغيير الشركة بما يخالف مراكز التكلفة الفرعية.', 1;

    DECLARE @CostCenterCycleFound BIT = 0;
    ;WITH ParentChain AS
    (
        SELECT i.CsCID AS StartCsCID, p.CsCID AS AncestorID, p.CsCParentID
        FROM inserted AS i
        INNER JOIN dbo.Acc_CostCenter AS p ON p.CsCID = i.CsCParentID
        UNION ALL
        SELECT pc.StartCsCID, p.CsCID, p.CsCParentID
        FROM ParentChain AS pc
        INNER JOIN dbo.Acc_CostCenter AS p ON p.CsCID = pc.CsCParentID
    )
    SELECT @CostCenterCycleFound = 1
    FROM ParentChain
    WHERE AncestorID = StartCsCID
    OPTION (MAXRECURSION 32767);

    IF @CostCenterCycleFound = 1
        THROW 51017, N'لا يمكن إنشاء دورة في شجرة مراكز التكلفة.', 1;
END;
GO

/* Unique account/cost-center codes within each company. */
CREATE UNIQUE NONCLUSTERED INDEX UX_Acc_Account_AccCompany_AccCode
    ON dbo.Acc_Account (AccCompany, AccCode);
GO
CREATE UNIQUE NONCLUSTERED INDEX UX_Acc_CostCenter_CsCCompany_CsCCode
    ON dbo.Acc_CostCenter (CsCCompany, CsCCode);
GO

/* Journal and tree indexes. */
CREATE NONCLUSTERED INDEX IX_Acc_DayMaster_Company_Date
    ON dbo.Acc_DayMaster (DayMCompany, DayMDate) INCLUDE (DayMState, DayMNo);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayMaster_Company_State
    ON dbo.Acc_DayMaster (DayMCompany, DayMState) INCLUDE (DayMDate, DayMNo);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDMID
    ON dbo.Acc_DayDetails (DayDMID) INCLUDE (DayDAccID, DayDDeb, DayDCrd, DayDCsCID);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDAccID
    ON dbo.Acc_DayDetails (DayDAccID) INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDCsCID
    ON dbo.Acc_DayDetails (DayDCsCID) INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd)
    WHERE DayDCsCID IS NOT NULL;
GO
CREATE NONCLUSTERED INDEX IX_Acc_Account_Parent
    ON dbo.Acc_Account (AccCompany, AccParentID) INCLUDE (AccOrder, AccChid);
GO
CREATE NONCLUSTERED INDEX IX_Acc_CostCenter_Parent
    ON dbo.Acc_CostCenter (CsCCompany, CsCParentID) INCLUDE (CsCOrder, CsCChid);
GO

/* History indexes. The source Phase 1 referenced a non-existent DayDHDID column;
   the actual history-row key is DayDHID, so the useful lookup is by journal ID/time. */
CREATE NONCLUSTERED INDEX IX_Acc_AccountHistory_Company_Date
    ON dbo.Acc_AccountHistory (AccHCompany, AccHDateTime) INCLUDE (AccHOpration, AccHUser, AccHAccID);
GO
CREATE NONCLUSTERED INDEX IX_Acc_AccountHistory_AccID
    ON dbo.Acc_AccountHistory (AccHAccID, AccHDateTime);
GO
CREATE NONCLUSTERED INDEX IX_Acc_CostCenterHistory_Company_Date
    ON dbo.Acc_CostCenterHistory (CsCHCompany, CsCHDateTime) INCLUDE (CsCHOpration, CsCHUser, CsCHCsCID);
GO
CREATE NONCLUSTERED INDEX IX_Acc_CostCenterHistory_CsCID
    ON dbo.Acc_CostCenterHistory (CsCHCsCID, CsCHDateTime);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayMasterHistory_MID
    ON dbo.Acc_DayMasterHistory (DayMHMID, DayMHDateTime) INCLUDE (DayMHOpration, DayMHState, DayMHUser);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayMasterHistory_DateTime
    ON dbo.Acc_DayMasterHistory (DayMHDateTime) INCLUDE (DayMHMID, DayMHState, DayMHUser);
GO
CREATE NONCLUSTERED INDEX IX_Acc_DayDetailsHistory_MID
    ON dbo.Acc_DayDetailsHistory (DayDHMID, DayDHDateTime);
GO

/*
Journal balance rule:
- State 0 (temporary): may be unbalanced.
- States 1..7: must have at least one detail row and total debit = total credit.
The rule is enforced both when the journal state changes and when its details
are inserted, updated, or deleted, so an already non-temporary journal cannot
become unbalanced through later detail edits.
*/
CREATE OR ALTER TRIGGER dbo.TR_Acc_DayDetails_PostingGuard
ON dbo.Acc_DayDetails
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM
        (
            SELECT DayDMID FROM inserted
            UNION
            SELECT DayDMID FROM deleted
        ) AS changed
        INNER JOIN dbo.Acc_DayMaster AS m ON m.DayMID = changed.DayDMID
        INNER JOIN dbo.Acc_FiscalYear AS fy
            ON fy.AccFCmpID = m.DayMCompany AND fy.AccFYear = YEAR(m.DayMDate)
        WHERE fy.AccFState = 1
    )
        THROW 51020, N'لا يمكن تعديل تفاصيل قيد في سنة مالية مقفلة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM
        (
            SELECT DayDMID FROM inserted
            UNION
            SELECT DayDMID FROM deleted
        ) AS changed
        INNER JOIN dbo.Acc_DayMaster AS m ON m.DayMID = changed.DayDMID
        WHERE m.DayMState = 7
    )
        THROW 51021, N'لا يمكن تعديل تفاصيل قيد مؤرشف.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_Account AS a ON a.AccID = i.DayDAccID
        WHERE a.AccChid > 0
    )
        THROW 51001, N'لا يمكن استخدام حساب له حسابات فرعية في تفاصيل القيد؛ استخدم الحساب التحليلي.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_CostCenter AS c ON c.CsCID = i.DayDCsCID
        WHERE c.CsCChid > 0
    )
        THROW 51002, N'لا يمكن استخدام مركز تكلفة له مراكز فرعية في تفاصيل القيد.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_DayMaster AS m ON m.DayMID = i.DayDMID
        INNER JOIN dbo.Acc_Account AS a ON a.AccID = i.DayDAccID
        WHERE a.AccCompany <> m.DayMCompany
    )
        THROW 51003, N'الحساب لا يتبع شركة القيد.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_DayMaster AS m ON m.DayMID = i.DayDMID
        INNER JOIN dbo.Acc_CostCenter AS c ON c.CsCID = i.DayDCsCID
        WHERE c.CsCCompany <> m.DayMCompany
    )
        THROW 51004, N'مركز التكلفة لا يتبع شركة القيد.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM
        (
            SELECT DayDMID FROM inserted
            UNION
            SELECT DayDMID FROM deleted
        ) AS changed
        INNER JOIN dbo.Acc_DayMaster AS m ON m.DayMID = changed.DayDMID
        CROSS APPLY
        (
            SELECT COUNT_BIG(*) AS LineCount,
                   COALESCE(SUM(d.DayDDeb), CONVERT(DECIMAL(38,3), 0)) AS DebitTotal,
                   COALESCE(SUM(d.DayDCrd), CONVERT(DECIMAL(38,3), 0)) AS CreditTotal
            FROM dbo.Acc_DayDetails AS d
            WHERE d.DayDMID = changed.DayDMID
        ) AS totals
        WHERE m.DayMState <> 0
          AND (totals.LineCount = 0 OR totals.DebitTotal <> totals.CreditTotal)
    )
        THROW 51005, N'لا يمكن أن يكون القيد في حالة غير مؤقتة إلا إذا كان موزونًا وله تفاصيل.', 1;
END;
GO

/* Validate a journal when it is created or moved to any non-temporary state. */
CREATE OR ALTER TRIGGER dbo.TR_Acc_DayMaster_BalanceGuard
ON dbo.Acc_DayMaster
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_FiscalYear AS fy
            ON fy.AccFCmpID = i.DayMCompany AND fy.AccFYear = YEAR(i.DayMDate)
        WHERE fy.AccFState = 1
    )
        THROW 51022, N'لا يمكن إضافة قيد أو تعديل قيد في سنة مالية مقفلة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM deleted AS d
        INNER JOIN dbo.Acc_FiscalYear AS fy
            ON fy.AccFCmpID = d.DayMCompany AND fy.AccFYear = YEAR(d.DayMDate)
        WHERE fy.AccFState = 1
    )
        THROW 51024, N'لا يمكن تعديل قيد كان تابعًا لسنة مالية مقفلة، حتى لو تغير تاريخ القيد.', 1;

    /* State 7 is immutable. The only permitted header transition is 7 -> 6,
       without changing the journal's date, number, description, or company. */
    IF EXISTS
    (
        SELECT 1
        FROM deleted AS d
        INNER JOIN inserted AS i ON i.DayMID = d.DayMID
        WHERE d.DayMState = 7
          AND
          (
              i.DayMState <> 6
              OR i.DayMDate <> d.DayMDate
              OR i.DayMNo <> d.DayMNo
              OR i.DayMCompany <> d.DayMCompany
              OR ISNULL(i.DayMDescription, N'') <> ISNULL(d.DayMDescription, N'')
          )
    )
        THROW 51023, N'القيد المؤرشف غير قابل للتعديل؛ يسمح فقط بإرجاعه من الحالة 7 إلى الحالة 6 دون تغيير بياناته الأساسية.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS m
        CROSS APPLY
        (
            SELECT COUNT_BIG(*) AS LineCount,
                   COALESCE(SUM(d.DayDDeb), CONVERT(DECIMAL(38,3), 0)) AS DebitTotal,
                   COALESCE(SUM(d.DayDCrd), CONVERT(DECIMAL(38,3), 0)) AS CreditTotal
            FROM dbo.Acc_DayDetails AS d
            WHERE d.DayDMID = m.DayMID
        ) AS totals
        WHERE m.DayMState <> 0
          AND (totals.LineCount = 0 OR totals.DebitTotal <> totals.CreditTotal)
    )
        THROW 51006, N'يجب أن يكون القيد موزونًا وله تفاصيل قبل نقله إلى حالة غير مؤقتة.', 1;
END;
GO

/* ===================== POST-INSTALL VALIDATION ===================== */
SELECT N'Acc_Account' AS TableName, COUNT_BIG(*) AS RowCount FROM dbo.Acc_Account
UNION ALL SELECT N'Acc_CostCenter', COUNT_BIG(*) FROM dbo.Acc_CostCenter
UNION ALL SELECT N'Acc_DayMaster', COUNT_BIG(*) FROM dbo.Acc_DayMaster
UNION ALL SELECT N'Acc_DayDetails', COUNT_BIG(*) FROM dbo.Acc_DayDetails
UNION ALL SELECT N'Acc_AccountHistory', COUNT_BIG(*) FROM dbo.Acc_AccountHistory
UNION ALL SELECT N'Acc_CostCenterHistory', COUNT_BIG(*) FROM dbo.Acc_CostCenterHistory
UNION ALL SELECT N'Acc_DayMasterHistory', COUNT_BIG(*) FROM dbo.Acc_DayMasterHistory
UNION ALL SELECT N'Acc_DayDetailsHistory', COUNT_BIG(*) FROM dbo.Acc_DayDetailsHistory;
GO

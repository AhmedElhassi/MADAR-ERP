/* =====================================================================
   MADAR ERP - Audit fixes (confirmed defects only)
   Source of truth: MADARDATABASE export of 2026-11-18 7:32 PM.
   Every procedure below is the exported definition with a minimal, marked edit
   (search for "-- [AUDIT-FIX"). Idempotent (CREATE OR ALTER / guarded DDL).
   Each fix is its own batch, so a failed batch does not stop the others.
   ===================================================================== */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- F1: Emp_SaveOvertimeRequest opened a transaction and never committed it
CREATE OR ALTER PROCEDURE [dbo].[Emp_SaveOvertimeRequest]
 @CmpID INT,@OvertimeID BIGINT=0,@EmployeeID BIGINT,@WorkDate DATE,@StartAt DATETIME2(0),@EndAt DATETIME2(0),
 @Hours DECIMAL(8,2),@Reason NVARCHAR(500),@Multiplier DECIMAL(8,4)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @WorkDate IS NULL OR @StartAt IS NULL OR @EndAt IS NULL OR CONVERT(date,@StartAt)<>@WorkDate OR CONVERT(date,@EndAt)<@WorkDate
  OR @EndAt<=@StartAt OR @Hours<=0 OR @Hours>CONVERT(decimal(8,2),DATEDIFF(MINUTE,@StartAt,@EndAt)/60.0)
  OR (@Multiplier IS NOT NULL AND @Multiplier<=0) OR NULLIF(LTRIM(RTRIM(@Reason)),N'') IS NULL
  THROW 54450,N'بيانات فترة العمل الإضافي أو مدتها غير صحيحة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID AND EmpState=0) THROW 54451,N'الموظف غير نشط أو لا يتبع للشركة.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  IF EXISTS(SELECT 1 FROM dbo.Emp_OvertimeRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND RequestState<>2 AND (@OvertimeID=0 OR OvertimeID<>@OvertimeID) AND @StartAt<EndAt AND @EndAt>StartAt)
   THROW 54452,N'تتداخل فترة الإضافي مع طلب آخر للموظف.',1;
  IF ISNULL(@OvertimeID,0)=0
  BEGIN
   INSERT dbo.Emp_OvertimeRequests(CmpID,EmployeeID,WorkDate,StartAt,EndAt,Hours,Reason,Multiplier,CreatedBy)
   VALUES(@CmpID,@EmployeeID,@WorkDate,@StartAt,@EndAt,@Hours,LTRIM(RTRIM(@Reason)),@Multiplier,@UserID);
   SET @OvertimeID=SCOPE_IDENTITY();
  END
  ELSE
  BEGIN
   UPDATE dbo.Emp_OvertimeRequests SET WorkDate=@WorkDate,StartAt=@StartAt,EndAt=@EndAt,Hours=@Hours,Reason=@Reason,Multiplier=@Multiplier
   WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID AND EmployeeID=@EmployeeID AND RequestState=0;
   IF @@ROWCOUNT<>1 THROW 54453,N'طلب الإضافي غير موجود أو غير قابل للتعديل.',1;
  END;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=2 AND RecordState=0) EXEC dbo.Emp_StartApproval @CmpID,2,@OvertimeID,@UserID,1;
  COMMIT TRANSACTION; -- [AUDIT-FIX F1] the transaction was never committed
  SELECT @OvertimeID AS OvertimeID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

-- F2a: unique reference per employee (filtered: NULL references are allowed). Skipped, with a listing, if duplicates already exist.
IF EXISTS(SELECT 1 FROM dbo.Emp_ServiceHistory WHERE ReferenceNo IS NOT NULL GROUP BY CmpID,EmployeeID,ReferenceNo HAVING COUNT(*)>1)
BEGIN
 PRINT N'F2a SKIPPED: duplicate (CmpID,EmployeeID,ReferenceNo) rows exist in Emp_ServiceHistory. Resolve them (list below), then re-run this batch.';
 SELECT CmpID,EmployeeID,ReferenceNo,COUNT(*) AS Dups,MIN(ServiceID) AS FirstServiceID,MAX(ServiceID) AS LastServiceID
 FROM dbo.Emp_ServiceHistory WHERE ReferenceNo IS NOT NULL GROUP BY CmpID,EmployeeID,ReferenceNo HAVING COUNT(*)>1;
END
ELSE IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'UX_Emp_ServiceHistory_Reference' AND object_id=OBJECT_ID(N'dbo.Emp_ServiceHistory'))
 CREATE UNIQUE NONCLUSTERED INDEX UX_Emp_ServiceHistory_Reference ON dbo.Emp_ServiceHistory(CmpID,EmployeeID,ReferenceNo) WHERE ReferenceNo IS NOT NULL;
GO

-- F2b: Emp_ApplyServiceChange - concurrency-safe, idempotent per reference, conflicting reference rejected
CREATE OR ALTER PROCEDURE [dbo].[Emp_ApplyServiceChange]
 @CmpID INT,@EmployeeID BIGINT,@EffectiveDate DATE,@EventType TINYINT,@NewPositionID BIGINT=NULL,
 @NewSalary DECIMAL(15,3)=NULL,@CurrencyID BIGINT=NULL,@ReferenceNo NVARCHAR(100)=NULL,@Reason NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @EffectiveDate IS NULL OR @EffectiveDate>CONVERT(date,SYSDATETIME()) OR @EventType IS NULL OR (@NewPositionID IS NULL AND @NewSalary IS NULL) OR (@NewSalary IS NOT NULL AND (@NewSalary<=0 OR @CurrencyID IS NULL))
  THROW 54340,N'بيانات التغيير الوظيفي أو تاريخ سريانه غير صحيح.',1;
 IF @NewPositionID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Emp_Position WHERE PosCmp=@CmpID AND PosID=@NewPositionID AND PosState=0) THROW 54341,N'المنصب الجديد غير نشط أو لا يتبع للشركة.',1;
 IF @CurrencyID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurID=@CurrencyID AND CurState=0) THROW 54342,N'عملة الراتب غير نشطة أو لا تتبع للشركة.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @OldPositionID BIGINT,@OldDepartmentID BIGINT,@NewDepartmentID BIGINT,@OldSalary DECIMAL(15,3),@OldCurrencyID BIGINT;
  SELECT @OldPositionID=e.PosID FROM dbo.Emp_Employee e WITH(UPDLOCK,HOLDLOCK) WHERE e.EmpCompany=@CmpID AND e.EmpID=@EmployeeID AND e.EmpState=0;
  IF @@ROWCOUNT<>1 THROW 54343,N'الموظف غير نشط أو لا يتبع للشركة.',1;
  -- [AUDIT-FIX F2b] re-check the reference UNDER the employee lock: same movement => return it without applying twice; different movement => reject
  IF @ReferenceNo IS NOT NULL
  BEGIN
   DECLARE @ExServiceID BIGINT,@ExEvent TINYINT,@ExDate DATE,@ExNewPos BIGINT,@ExNewSalary DECIMAL(15,3);
   SELECT TOP(1) @ExServiceID=ServiceID,@ExEvent=EventType,@ExDate=EffectiveDate,@ExNewPos=NewPositionID,@ExNewSalary=NewSalary
   FROM dbo.Emp_ServiceHistory WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND ReferenceNo=@ReferenceNo ORDER BY ServiceID;
   IF @ExServiceID IS NOT NULL
   BEGIN
    IF @ExEvent<>@EventType OR @ExDate<>@EffectiveDate OR (@NewPositionID IS NOT NULL AND ISNULL(@ExNewPos,0)<>@NewPositionID) OR (@NewSalary IS NOT NULL AND ISNULL(@ExNewSalary,-1)<>@NewSalary)
     THROW 54347,N'رقم المرجع مرتبط بحركة وظيفية مختلفة لهذا الموظف؛ رُفض التنفيذ.',1;
    COMMIT TRANSACTION;
    SELECT ServiceID,EmployeeID,EffectiveDate,EventType FROM dbo.Emp_ServiceHistory WHERE CmpID=@CmpID AND ServiceID=@ExServiceID;
    RETURN;
   END;
  END;
  SELECT @OldDepartmentID=Pos.EmpOrgStrID FROM dbo.Emp_Position Pos WHERE Pos.PosCmp=@CmpID AND Pos.PosID=@OldPositionID;
  IF @NewPositionID IS NOT NULL SELECT @NewDepartmentID=Pos.EmpOrgStrID FROM dbo.Emp_Position Pos WHERE Pos.PosCmp=@CmpID AND Pos.PosID=@NewPositionID;
  SELECT @OldSalary=SalAmount,@OldCurrencyID=SalCurrencyID FROM dbo.Emp_Salary WITH(UPDLOCK,HOLDLOCK)
   WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID AND SalStartDate<=@EffectiveDate AND (SalEndDate IS NULL OR SalEndDate>=@EffectiveDate);
  IF @NewSalary IS NOT NULL AND @OldSalary IS NULL THROW 54344,N'لا يوجد راتب سارٍ لإغلاقه؛ صحح سجل الراتب قبل التغيير.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayRuns r ON r.CmpID=d.CmpID AND r.PayRunID=d.PayRunID JOIN dbo.Emp_PayPeriods p ON p.CmpID=r.CmpID AND p.PeriodID=r.PeriodID WHERE d.CmpID=@CmpID AND d.EmployeeID=@EmployeeID AND r.RunState>=1 AND p.DateTo>=@EffectiveDate)
   THROW 54345,N'يوجد مسير محسوب أو معتمد يغطي تاريخ التغيير؛ لا يمكن تغيير بياناته بأثر رجعي.',1;
  IF @NewSalary IS NOT NULL
  BEGIN
   IF EXISTS(SELECT 1 FROM dbo.Emp_Salary WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID AND SalStartDate>=@EffectiveDate)
    THROW 54346,N'يوجد راتب مستقبلي أو راتب يبدأ في تاريخ التغيير؛ راجعه قبل إضافة التغيير.',1;
   UPDATE dbo.Emp_Salary SET SalEndDate=DATEADD(DAY,-1,@EffectiveDate) WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID AND SalStartDate<=@EffectiveDate AND (SalEndDate IS NULL OR SalEndDate>=@EffectiveDate);
   INSERT dbo.Emp_Salary(EmpCompany,EmpID,SalAmount,SalCurrencyID,SalStartDate,SalUser,SalDateTime) VALUES(@CmpID,@EmployeeID,@NewSalary,@CurrencyID,@EffectiveDate,@UserID,SYSDATETIME());
  END;
  IF @NewPositionID IS NOT NULL UPDATE dbo.Emp_Employee SET PosID=@NewPositionID,EmpDateTime=SYSDATETIME(),EmpUser=@UserID WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID;
  INSERT dbo.Emp_ServiceHistory(CmpID,EmployeeID,EffectiveDate,EventType,OldPositionID,NewPositionID,OldDepartmentID,NewDepartmentID,OldSalary,NewSalary,CurrencyID,ReferenceNo,Reason,CreatedAt,CreatedBy,RecordState)
  VALUES(@CmpID,@EmployeeID,@EffectiveDate,@EventType,@OldPositionID,COALESCE(@NewPositionID,@OldPositionID),@OldDepartmentID,COALESCE(@NewDepartmentID,@OldDepartmentID),@OldSalary,COALESCE(@NewSalary,@OldSalary),COALESCE(@CurrencyID,@OldCurrencyID),@ReferenceNo,@Reason,SYSDATETIME(),@UserID,0);
  COMMIT TRANSACTION;
  SELECT TOP(1) ServiceID,EmployeeID,EffectiveDate,EventType FROM dbo.Emp_ServiceHistory WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID ORDER BY ServiceID DESC;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

-- F2c: Emp_ApplyDueEmployeeMovements
/* Applies approved movements whose effective date has arrived. Only position-changing types (3,4,5) change Emp_Employee here;
   other types are history records consumed by their owning functions. Idempotent: applied rows are skipped. */
CREATE OR ALTER PROCEDURE [dbo].[Emp_ApplyDueEmployeeMovements]
 @CmpID INT,@UserID BIGINT,@AsOfDate DATE=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @AsOfDate IS NULL OR @AsOfDate>CONVERT(date,SYSDATETIME()) SET @AsOfDate=CONVERT(date,SYSDATETIME());
 DECLARE @Failed TABLE(MovementID BIGINT NOT NULL,ErrorNumber INT NOT NULL,ErrorMessage NVARCHAR(2048) NOT NULL);
 DECLARE @Ignore TABLE(ServiceID BIGINT,EmployeeID BIGINT,EffectiveDate DATE,EventType TINYINT);
 DECLARE @Applied INT=0,@M BIGINT,@E BIGINT,@Type TINYINT,@To BIGINT,@Eff DATE,@Reason NVARCHAR(500),@Ref NVARCHAR(100);
 DECLARE c CURSOR LOCAL FAST_FORWARD FOR
  SELECT MovementID,EmployeeID,MovementType,ToPosID,EffectiveDate,Reason FROM dbo.Emp_EmployeeMovements
  WHERE CmpID=@CmpID AND MovementState=1 AND EffectiveDate<=@AsOfDate AND MovementType IN(3,4,5) ORDER BY EffectiveDate,MovementID;
 OPEN c; FETCH NEXT FROM c INTO @M,@E,@Type,@To,@Eff,@Reason;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Ref=CONCAT(N'MOV-',@M);
  BEGIN TRY
   /* Idempotent: if the history row for this movement already exists (earlier run stopped before the state update), only the state is completed. */
   IF NOT EXISTS(SELECT 1 FROM dbo.Emp_ServiceHistory WHERE CmpID=@CmpID AND EmployeeID=@E AND ReferenceNo=@Ref AND RecordState=0 AND EventType=@Type AND EffectiveDate=@Eff AND NewPositionID=@To) -- [AUDIT-FIX F2c] same reference but different content is NOT treated as applied; Emp_ApplyServiceChange rejects it (54347) and it is listed as failed
    INSERT @Ignore EXEC dbo.Emp_ApplyServiceChange @CmpID,@E,@Eff,@Type,@To,NULL,NULL,@Ref,@Reason,@UserID;
   UPDATE dbo.Emp_EmployeeMovements SET MovementState=2,AppliedAt=SYSDATETIME() WHERE CmpID=@CmpID AND MovementID=@M AND MovementState=1;
   SET @Applied+=@@ROWCOUNT;
  END TRY
  BEGIN CATCH
   IF XACT_STATE()<>0 ROLLBACK;
   INSERT @Failed(MovementID,ErrorNumber,ErrorMessage) VALUES(@M,ERROR_NUMBER(),ERROR_MESSAGE());
  END CATCH
  FETCH NEXT FROM c INTO @M,@E,@Type,@To,@Eff,@Reason;
 END
 CLOSE c; DEALLOCATE c;
 SELECT @Applied AS AppliedCount,(SELECT COUNT(*) FROM @Failed) AS FailedCount;
 SELECT MovementID,ErrorNumber,ErrorMessage FROM @Failed ORDER BY MovementID;
END
GO

-- F3a: Emp_ChangePayRunState checked only VoucherID IS NOT NULL, never the voucher state
/* Atomic state transitions for payroll approval and closeout. */
CREATE OR ALTER PROCEDURE [dbo].[Emp_ChangePayRunState]
 @CmpID INT,@PayRunID BIGINT,@UserID BIGINT,@Decision TINYINT,@StepNo SMALLINT=1,@Comments NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @Decision NOT IN(2,3) THROW 54135,N'الحالة المطلوبة غير صحيحة.',1;
 BEGIN TRY
BEGIN TRANSACTION;
  IF @Decision=2
  BEGIN
   DECLARE @RunCalculationVersion INT,@RunDeferredTotal DECIMAL(19,3),@RunZeroNetApprovalMode TINYINT,@RunDeferralApprovalRequired BIT;
   SELECT @RunCalculationVersion=r.CalculationVersion,@RunDeferredTotal=r.DeferredDeductionTotal,@RunZeroNetApprovalMode=p.ZeroNetApprovalMode,@RunDeferralApprovalRequired=p.DeferralApprovalRequired FROM dbo.Emp_PayRuns r WITH(UPDLOCK,HOLDLOCK) JOIN dbo.Emp_PayPeriods q ON q.CmpID=r.CmpID AND q.PeriodID=r.PeriodID JOIN dbo.Emp_PayPolicies p ON p.CmpID=r.CmpID AND p.RecordState=0 AND p.EffectiveFrom<=q.DateTo AND (p.EffectiveTo IS NULL OR p.EffectiveTo>=q.DateFrom) WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID AND r.RunState=1;
   IF @RunCalculationVersion IS NULL THROW 54930,N'المسير غير محسوب أو لم تعد حالته تسمح بالاعتماد.',1;
   IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d LEFT JOIN dbo.Emp_PayrollDeductionAllocations a ON a.CmpID=d.CmpID AND a.PayRunID=d.PayRunID AND a.CalculationVersion=@RunCalculationVersion AND a.PayrollDetailID=d.PayrollDetailID
    WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.LineKind=2 AND (d.CollectedAmount IS NULL OR d.DeferredAmount IS NULL OR a.AllocationID IS NULL OR a.RequestedAmount<>d.Amount OR a.CollectedAmount<>d.CollectedAmount OR a.DeferredAmount<>d.DeferredAmount OR (a.CanDefer=0 AND a.DeferredAmount>0)))
    THROW 54931,N'لم تُطبق سياسة الشركة لتوزيع الاستقطاعات؛ لا يمكن اعتماد المسير.',1;
   IF @RunDeferredTotal<>(SELECT ISNULL(SUM(DeferredAmount),0) FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND LineKind=2)
    THROW 54932,N'إجمالي العجز المؤجل لا يطابق تفاصيل المسير؛ أعد الاحتساب.',1;
   IF @RunZeroNetApprovalMode IS NULL THROW 54947,N'سياسة اعتماد صافي الصرف للشركة غير متاحة؛ لا يمكن اعتماد المسير.',1;
   IF EXISTS
   (
    SELECT x.EmployeeID FROM
    (SELECT EmployeeID,SUM(CASE WHEN LineKind=1 THEN Amount ELSE 0 END) GrossAmount,SUM(CASE WHEN LineKind=2 THEN Amount ELSE 0 END) RequestedAmount,SUM(CASE WHEN LineKind=2 THEN ISNULL(CollectedAmount,0) ELSE 0 END) CollectedAmount,SUM(CASE WHEN LineKind=2 THEN ISNULL(DeferredAmount,0) ELSE 0 END) DeferredAmount
     FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID GROUP BY EmployeeID) x
    LEFT JOIN dbo.Emp_PayrollDeficitSnapshots s ON s.CmpID=@CmpID AND s.PayRunID=@PayRunID AND s.CalculationVersion=@RunCalculationVersion AND s.EmployeeID=x.EmployeeID
    WHERE s.SnapshotID IS NULL OR s.GrossEntitlement<>x.GrossAmount OR s.RequestedDeductionTotal<>x.RequestedAmount OR s.CollectedDeductionTotal<>x.CollectedAmount OR s.DeferredDeductionTotal<>x.DeferredAmount
   ) THROW 54948,N'سجل العجز لا يطابق تفاصيل المسير؛ أعد الاحتساب.',1;
   IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=@CmpID AND s.PayRunID=@PayRunID AND s.CalculationVersion=@RunCalculationVersion AND s.PolicyApplied=0)
    THROW 54949,N'لم تُطبق سياسة معالجة العجز على جميع الموظفين.',1;
   IF @RunZeroNetApprovalMode=1 AND EXISTS(SELECT 1 FROM dbo.Emp_PayrollDeficitSnapshots WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND CalculationVersion=@RunCalculationVersion AND NetPayable=0)
    THROW 54950,N'سياسة الشركة تمنع اعتماد مسير يحتوي على صافي صرف صفري.',1;
   IF @RunDeferredTotal>0 AND @RunDeferralApprovalRequired=1 AND NOT EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=9 AND RecordState=0)
    THROW 54951,N'تتطلب سياسة الشركة مسار موافقة فعّالاً قبل اعتماد الأرصدة المؤجلة.',1;
  END;
  IF @Decision=2 AND EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=9 AND RecordState=0)
  BEGIN
   DECLARE @RunCreator BIGINT,@ApprovalResult TINYINT,@NextApproval SMALLINT;
   SELECT @RunCreator=CreatedBy FROM dbo.Emp_PayRuns WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND RunState=1;
   IF @RunCreator IS NULL THROW 54710,N'المسير غير موجود أو غير محتسب.',1;
   IF NOT EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ProcessType=9 AND EntityID=@PayRunID AND ApprovalState=0)
    EXEC dbo.Emp_StartApproval @CmpID,9,@PayRunID,@RunCreator,1;
   EXEC dbo.Emp_DecideApprovalStep @CmpID,9,@PayRunID,@StepNo,@UserID,1,@Comments,@ApprovalResult OUTPUT,@NextApproval OUTPUT,1;
   IF @ApprovalResult=0
   BEGIN
    COMMIT TRANSACTION;
    SELECT PayRunID,RunState,NetTotal FROM dbo.Emp_PayRuns WHERE CmpID=@CmpID AND PayRunID=@PayRunID;
    RETURN;
   END;
  END;
  IF @Decision=3 AND EXISTS
  (
   SELECT 1 FROM dbo.Emp_PayRuns r JOIN dbo.Emp_PayPeriods q ON q.CmpID=r.CmpID AND q.PeriodID=r.PeriodID
   JOIN dbo.Emp_PayPolicies p ON p.CmpID=r.CmpID AND p.RecordState=0 AND p.EffectiveFrom<=q.DateTo AND (p.EffectiveTo IS NULL OR p.EffectiveTo>=q.DateFrom)
   WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID AND r.RunState=2 AND
    (r.NetTotal<0 OR r.NetTotal<>(SELECT ISNULL(SUM(s.NetPayable),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion) OR r.NetDeficitTotal<>(SELECT ISNULL(SUM(NetDeficit),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion) OR r.RequestedDeductionTotal<>(SELECT ISNULL(SUM(RequestedDeductionTotal),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion) OR r.DeductionTotal<>(SELECT ISNULL(SUM(CollectedDeductionTotal),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion)
     OR r.DeferredDeductionTotal<>(SELECT ISNULL(SUM(DeferredDeductionTotal),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion)
     OR (p.ZeroNetApprovalMode=1 AND EXISTS(SELECT 1 FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion AND s.NetPayable=0))
     OR (p.DeferralApprovalRequired=1 AND r.DeferredDeductionTotal>0 AND NOT EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests a WHERE a.CmpID=r.CmpID AND a.ProcessType=9 AND a.EntityID=r.PayRunID AND a.ApprovalState=1)) OR EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d WHERE d.CmpID=r.CmpID AND d.PayRunID=r.PayRunID AND NOT EXISTS(SELECT 1 FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=d.CmpID AND s.PayRunID=d.PayRunID AND s.CalculationVersion=r.CalculationVersion AND s.EmployeeID=d.EmployeeID)) OR EXISTS(SELECT 1 FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion AND s.PolicyApplied=0))
  ) THROW 54952,N'لم تستوفَ سياسة الشركة أو موافقتها النهائية لمعالجة عجز المسير؛ لا يمكن إقفاله.',1;
  -- [AUDIT-FIX F3a] closing needs a real accounting voucher that is not a draft (0) and not returned to the preparer (2)
  IF @Decision=3 AND NOT EXISTS(SELECT 1 FROM dbo.Emp_PayRuns r JOIN dbo.Acc_DayMaster v ON v.DayMID=r.VoucherID AND v.DayMCompany=r.CmpID WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID AND v.DayMState NOT IN(0,2))
   THROW 55220,N'قيد المسير غير موجود أو لم يُرحَّل (مسودة أو معاد من المراجعة)؛ لا يمكن إقفال المسير.',1;
  UPDATE dbo.Emp_PayRuns WITH(UPDLOCK,HOLDLOCK)
  SET RunState=@Decision,
      ApprovedAt=CASE WHEN @Decision=2 THEN SYSDATETIME() ELSE ApprovedAt END,
      ApprovedBy=CASE WHEN @Decision=2 THEN @UserID ELSE ApprovedBy END,
      ClosedAt=CASE WHEN @Decision=3 THEN SYSDATETIME() ELSE ClosedAt END,
      ClosedBy=CASE WHEN @Decision=3 THEN @UserID ELSE ClosedBy END
  WHERE CmpID=@CmpID AND PayRunID=@PayRunID
    AND ((@Decision=2 AND RunState=1 AND CreatedBy<>@UserID) OR (@Decision=3 AND RunState=2 AND VoucherID IS NOT NULL AND ApprovedBy<>@UserID));
  IF @@ROWCOUNT<>1 THROW 54136,N'انتقال حالة المسير غير مسموح أو القيد المحاسبي غير مربوط.',1;
  COMMIT TRANSACTION;
  SELECT PayRunID,RunState,NetTotal FROM dbo.Emp_PayRuns WHERE CmpID=@CmpID AND PayRunID=@PayRunID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

-- F3b: Emp_PostPayRun creates the payroll voucher as Posted (state 1) so it enters the normal review/approval/archive cycle.
--      Run F3a and F3b together: F3a alone would make Emp_Proc_ClosePayRun fail on its own draft voucher.
CREATE OR ALTER PROCEDURE [dbo].[Emp_PostPayRun]
 @CmpID INT,@PayRunID BIGINT,@UserID BIGINT,@Description NVARCHAR(500)=NULL,@SuppressResult BIT=0
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF TYPE_ID(N'dbo.Acc_DayLineType') IS NULL THROW 54148,N'نوع بنود القيد المحاسبي غير موجود.',1;
 DECLARE @PeriodID BIGINT,@PeriodFrom DATE,@PeriodTo DATE,@RunState TINYINT,@ExistingVoucher BIGINT,@LoanDetailCount INT,@AdvanceDetailCount INT,@ExternalDeductionDetailCount INT,@ArrearDetailCount INT,@AdvanceArrearCount INT;
 SELECT @PeriodID=r.PeriodID,@PeriodFrom=p.DateFrom,@PeriodTo=p.DateTo,@RunState=r.RunState,@ExistingVoucher=r.VoucherID
 FROM dbo.Emp_PayRuns r JOIN dbo.Emp_PayPeriods p ON p.CmpID=r.CmpID AND p.PeriodID=r.PeriodID
 WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID;
 IF @PeriodID IS NULL OR @RunState<>2 OR @ExistingVoucher IS NOT NULL THROW 54149,N'المسير غير معتمد أو غير موجود أو سبق ربطه بقيد.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d LEFT JOIN dbo.Emp_PayrollDeductionAllocations a ON a.CmpID=d.CmpID AND a.PayRunID=d.PayRunID AND a.CalculationVersion=(SELECT CalculationVersion FROM dbo.Emp_PayRuns WHERE CmpID=@CmpID AND PayRunID=@PayRunID) AND a.PayrollDetailID=d.PayrollDetailID
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.LineKind=2 AND (d.CollectedAmount IS NULL OR d.DeferredAmount IS NULL OR a.AllocationID IS NULL OR a.RequestedAmount<>d.Amount OR a.CollectedAmount<>d.CollectedAmount OR a.DeferredAmount<>d.DeferredAmount OR (a.CanDefer=0 AND a.DeferredAmount>0)))
  THROW 54915,N'لم تُطبق سياسة توزيع الاستقطاعات كاملة أو لا تطابق تفاصيل المسير؛ لا يمكن الترحيل.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_PayRuns r WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID AND r.DeferredDeductionTotal<>(SELECT ISNULL(SUM(DeferredAmount),0) FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND LineKind=2))
  THROW 54916,N'إجمالي الأرصدة المؤجلة لا يطابق تفاصيل المسير؛ أعد احتساب المسير.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND (d.Amount<0 OR ISNULL(d.CollectedAmount,0)<0 OR ISNULL(d.DeferredAmount,0)<0 OR (d.LineKind=2 AND ISNULL(d.CollectedAmount,0)+ISNULL(d.DeferredAmount,0)<>d.Amount) OR (d.LineKind=1 AND (ISNULL(d.CollectedAmount,d.Amount)<>d.Amount OR ISNULL(d.DeferredAmount,0)<>0))))
   THROW 54953,N'توجد مبالغ سالبة أو تسوية استقطاع غير متوازنة؛ يمنع اعتماد أو ترحيل المسير.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_PayRuns r CROSS APPLY(SELECT ISNULL(SUM(CASE WHEN d.LineKind=1 THEN d.Amount ELSE 0 END),0) GrossAmount,ISNULL(SUM(CASE WHEN d.LineKind=2 THEN ISNULL(d.CollectedAmount,d.Amount) ELSE 0 END),0) CollectedAmount FROM dbo.Emp_PayrollDetails d WHERE d.CmpID=r.CmpID AND d.PayRunID=r.PayRunID) x WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID AND (r.NetTotal<0 OR r.NetTotal<>CASE WHEN x.GrossAmount>x.CollectedAmount THEN x.GrossAmount-x.CollectedAmount ELSE 0 END))
  IF EXISTS(SELECT 1 FROM dbo.Emp_PayRuns r WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID AND (r.NetDeficitTotal<>(SELECT ISNULL(SUM(s.NetDeficit),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion) OR r.RequestedDeductionTotal<>(SELECT ISNULL(SUM(s.RequestedDeductionTotal),0) FROM dbo.Emp_PayrollDeficitSnapshots s WHERE s.CmpID=r.CmpID AND s.PayRunID=r.PayRunID AND s.CalculationVersion=r.CalculationVersion))) THROW 54958,N'إجماليات عجز الرواتب لا تطابق سجل السياسات؛ يمنع الترحيل.',1;
   THROW 54954,N'صافي المسير غير متزن أو سالب؛ يمنع الترحيل والصرف.',1;
  IF EXISTS
  (
   SELECT 1 FROM (SELECT EmployeeID,SUM(CASE WHEN LineKind=1 THEN Amount ELSE 0 END) GrossAmount,SUM(CASE WHEN LineKind=2 THEN ISNULL(CollectedAmount,Amount) ELSE 0 END) CollectedAmount,SUM(CASE WHEN LineKind=2 THEN ISNULL(DeferredAmount,0) ELSE 0 END) DeferredAmount FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID GROUP BY EmployeeID) x
   LEFT JOIN dbo.Emp_PayrollDeficitSnapshots s ON s.CmpID=@CmpID AND s.PayRunID=@PayRunID AND s.CalculationVersion=(SELECT CalculationVersion FROM dbo.Emp_PayRuns WHERE CmpID=@CmpID AND PayRunID=@PayRunID) AND s.EmployeeID=x.EmployeeID
   WHERE s.SnapshotID IS NULL OR s.GrossEntitlement<>x.GrossAmount OR s.CollectedDeductionTotal<>x.CollectedAmount OR s.DeferredDeductionTotal<>x.DeferredAmount OR s.PolicyApplied=0
  ) THROW 54955,N'سجل سياسة العجز لا يطابق تفاصيل المسير؛ يمنع الترحيل.',1;
 IF EXISTS
 (
  SELECT d.PayrollDetailID FROM dbo.Emp_PayrollDetails d
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.Amount<>0
    AND (SELECT COUNT(*) FROM dbo.Emp_PayrollAccountMappings m
         WHERE m.CmpID=d.CmpID AND (m.ComponentID=d.ComponentID OR (m.ComponentID IS NULL AND d.ComponentID IS NULL))
           AND m.RecordState=0 AND m.EffectiveFrom<=@PeriodTo AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@PeriodFrom))<>2
 ) THROW 54154,N'يجب تعريف ربط مدين وربط دائن فعال لكل مكون راتب مستخدم في المسير.',1;
 IF EXISTS
 (
  SELECT 1 FROM dbo.Emp_PayrollAccountMappings m
  JOIN dbo.Emp_PayrollDetails d ON d.CmpID=m.CmpID AND d.PayRunID=@PayRunID AND (d.ComponentID=m.ComponentID OR (d.ComponentID IS NULL AND m.ComponentID IS NULL))
  JOIN dbo.Acc_Account a ON a.AccCompany=m.CmpID AND a.AccID=m.AccountID
  WHERE m.CmpID=@CmpID AND m.RecordState=0 AND m.EffectiveFrom<=@PeriodTo AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@PeriodFrom)
    AND (a.AccState<>0 OR a.AccChid<>0 OR (m.CostCenterID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Acc_CostCenter c WHERE c.CsCCompany=@CmpID AND c.CsCID=m.CostCenterID AND c.CsCState=0 AND c.CsCChid=0)))
 ) THROW 54155,N'يوجد حساب أو مركز تكلفة غير صالح ضمن خرائط الترحيل.',1;
 DECLARE @Lines dbo.Acc_DayLineType;
 DECLARE @VoucherYear INT=YEAR(@PeriodTo);
 DECLARE @VoucherInfo NVARCHAR(MAX)=COALESCE(NULLIF(LTRIM(RTRIM(@Description)),N''),N'قيد مسير الرواتب');
 ;WITH Mapped AS
 (
  SELECT d.PayrollDetailID,CASE WHEN d.LineKind=2 THEN ISNULL(d.CollectedAmount,d.Amount) ELSE d.Amount END AS Amount,m.AccountID,m.CostCenterID,m.DebitCredit,d.Description
  FROM dbo.Emp_PayrollDetails d
  JOIN dbo.Emp_PayrollAccountMappings m ON m.CmpID=d.CmpID AND (m.ComponentID=d.ComponentID OR (m.ComponentID IS NULL AND d.ComponentID IS NULL))
   AND m.RecordState=0 AND m.EffectiveFrom<=@PeriodTo AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@PeriodFrom)
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.Amount<>0
 ), Grouped AS
 (
  SELECT AccountID,CostCenterID,DebitCredit,SUM(Amount) Amount,MAX(Description) Description
  FROM Mapped GROUP BY AccountID,CostCenterID,DebitCredit
 )
 INSERT @Lines(SeqNo,DayDAccID,DayDDeb,DayDCrd,DayDCsCID,DayDNum,DayDDescription)
 SELECT ROW_NUMBER() OVER(ORDER BY AccountID,CostCenterID,DebitCredit),AccountID,
        CASE WHEN DebitCredit=1 THEN Amount ELSE 0 END,
        CASE WHEN DebitCredit=2 THEN Amount ELSE 0 END,
        CostCenterID,NULL,CONCAT(N'مسير رواتب: ',ISNULL(@Description,N''),N' - ',Description)
 FROM Grouped WHERE Amount>0;
 IF NOT EXISTS(SELECT 1 FROM @Lines) THROW 54156,N'لا توجد بنود قابلة للترحيل.',1;
 IF (SELECT SUM(DayDDeb)-SUM(DayDCrd) FROM @Lines)<>0 THROW 54157,N'خرائط الرواتب لا تنتج قيداً متوازناً.',1;
 DECLARE @Result TABLE(DayMID BIGINT,DayMNo INT,DayMState TINYINT,VoucherNo NVARCHAR(40));
  DECLARE @CreatedArrears TABLE(ArrearID BIGINT NOT NULL,OriginPayrollDetailID BIGINT NOT NULL,Amount DECIMAL(19,3) NOT NULL);
 BEGIN TRY
  BEGIN TRAN;
  EXEC sys.sp_set_session_context @key=N'Acc.SystemOperation',@value=1;
  INSERT @Result EXEC dbo.Acc_SaveDayVoucher @Cmp=@CmpID,@Year=@VoucherYear,@User=@UserID,@DayMID=0,@Date=@PeriodTo,
   @Info=@VoucherInfo,@Post=1,@Lines=@Lines; -- [AUDIT-FIX F3b] was @Post=0: the payroll voucher stayed a deletable/editable draft while the run was closed
  IF (SELECT COUNT(*) FROM @Result)<>1 THROW 54158,N'لم يُرجع إجراء القيد المحاسبي معرف القيد المتوقع.',1;
  UPDATE dbo.Emp_PayRuns SET VoucherID=(SELECT TOP(1) DayMID FROM @Result) WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND RunState=2 AND VoucherID IS NULL;
  IF @@ROWCOUNT=0 THROW 54158,N'تعذر ربط القيد بالمسير؛ تحقق من حالة المسير.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_LoanInstallments i ON i.CmpID=d.CmpID AND i.InstallmentID=d.SourceID WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=13 AND (i.InstallmentState<>0 OR i.PaidAmount+d.Amount>i.Amount))
   THROW 54359,N'تغير رصيد قسط السلفة بعد احتساب المسير؛ أعد الاحتساب قبل الترحيل.',1;
  SELECT @LoanDetailCount=COUNT(*) FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND SourceType=13 AND ISNULL(CollectedAmount,Amount)>0;
  UPDATE i SET PaidAmount=i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount),
      InstallmentState=CASE WHEN i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount)>=i.Amount THEN 1 ELSE 0 END,
      PaidAt=CASE WHEN i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount)>=i.Amount THEN SYSDATETIME() ELSE NULL END
  FROM dbo.Emp_LoanInstallments i
  JOIN dbo.Emp_PayrollDetails d ON d.CmpID=i.CmpID AND d.SourceType=13 AND d.SourceID=i.InstallmentID
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND i.InstallmentState=0 AND i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount)<=i.Amount AND ISNULL(d.CollectedAmount,d.Amount)>0;
  IF @@ROWCOUNT<>@LoanDetailCount THROW 54360,N'تعذر تحديث جميع أقساط المسير؛ أُلغيت عملية الترحيل.',1;
  INSERT dbo.Emp_LoanPayments(CmpID,InstallmentID,Amount,PaymentDate,PaymentSource,PayRunID,CreatedBy)
  SELECT d.CmpID,d.SourceID,ISNULL(d.CollectedAmount,d.Amount),CONVERT(date,SYSDATETIME()),2,@PayRunID,@UserID
  FROM dbo.Emp_PayrollDetails d WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=13 AND ISNULL(d.CollectedAmount,d.Amount)>0;  IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d LEFT JOIN dbo.Emp_SalaryAdvanceInstallments i ON i.CmpID=d.CmpID AND i.InstallmentID=d.SourceID LEFT JOIN dbo.Emp_SalaryAdvances a ON a.CmpID=i.CmpID AND a.AdvanceID=i.AdvanceID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=20 AND (i.InstallmentID IS NULL OR a.AdvanceState<>1 OR a.Disbursed<>1 OR a.PeriodID<>@PeriodID OR a.CalculationPayRunID<>@PayRunID OR i.InstallmentState<>0 OR d.Amount<=0 OR i.PaidAmount+d.Amount>i.Amount))
   THROW 54864,N'تغير رصيد قسط المرتب المقدم بعد احتساب المسير؛ أعد الاحتساب قبل الترحيل.',1;
  SELECT @AdvanceDetailCount=COUNT(*) FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND SourceType=20 AND ISNULL(CollectedAmount,Amount)>0;
  UPDATE i SET PaidAmount=i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount),InstallmentState=CASE WHEN i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount)>=i.Amount THEN 1 ELSE 0 END,PaidAt=CASE WHEN i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount)>=i.Amount THEN SYSDATETIME() ELSE NULL END
   FROM dbo.Emp_SalaryAdvanceInstallments i JOIN dbo.Emp_PayrollDetails d ON d.CmpID=i.CmpID AND d.SourceType=20 AND d.SourceID=i.InstallmentID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND i.InstallmentState=0 AND i.PaidAmount+ISNULL(d.CollectedAmount,d.Amount)<=i.Amount AND ISNULL(d.CollectedAmount,d.Amount)>0;
  IF @@ROWCOUNT<>@AdvanceDetailCount THROW 54865,N'تعذر تحديث جميع أقساط المرتب المقدم؛ أُلغيت عملية الترحيل.',1;
  INSERT dbo.Emp_SalaryAdvancePayments(CmpID,InstallmentID,Amount,PaymentDate,PaymentSource,PayRunID,CreatedBy)
   SELECT d.CmpID,d.SourceID,ISNULL(d.CollectedAmount,d.Amount),CONVERT(date,SYSDATETIME()),2,@PayRunID,@UserID FROM dbo.Emp_PayrollDetails d WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=20 AND ISNULL(d.CollectedAmount,d.Amount)>0;
  UPDATE a SET AdvanceState=3 FROM dbo.Emp_SalaryAdvances a WHERE a.CmpID=@CmpID AND a.AdvanceState=1 AND NOT EXISTS
   (SELECT 1 FROM dbo.Emp_SalaryAdvanceInstallments i WHERE i.CmpID=a.CmpID AND i.AdvanceID=a.AdvanceID AND i.InstallmentState=0)
   AND EXISTS(SELECT 1 FROM dbo.Emp_SalaryAdvanceInstallments i JOIN dbo.Emp_PayrollDetails d ON d.CmpID=i.CmpID AND d.SourceType=20 AND d.SourceID=i.InstallmentID WHERE i.CmpID=a.CmpID AND i.AdvanceID=a.AdvanceID AND d.PayRunID=@PayRunID);

  IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d LEFT JOIN dbo.Emp_EmployeeExternalDeductions x ON x.CmpID=d.CmpID AND x.DeductionID=d.SourceID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=21 AND (x.DeductionID IS NULL OR x.DeductionState<>1 OR d.Amount<=0 OR d.Amount>x.MonthlyAmount OR x.NextDueDate>@PeriodTo OR (x.EffectiveTo IS NOT NULL AND x.EffectiveTo<x.NextDueDate) OR (x.TotalAmount IS NOT NULL AND x.AssessedTotal+d.Amount>x.TotalAmount)))
   THROW 54866,N'تغير رصيد الاستقطاع الخارجي بعد احتساب المسير؛ أعد الاحتساب قبل الترحيل.',1;
  SELECT @ExternalDeductionDetailCount=COUNT(*) FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND SourceType=21;
  UPDATE x SET WithheldTotal=x.WithheldTotal+ISNULL(d.CollectedAmount,0),AssessedTotal=x.AssessedTotal+d.Amount,NextDueDate=DATEADD(MONTH,x.FrequencyMonths,x.NextDueDate),DeductionState=CASE WHEN x.TotalAmount IS NOT NULL AND x.AssessedTotal+d.Amount>=x.TotalAmount THEN 3 ELSE 1 END
   FROM dbo.Emp_EmployeeExternalDeductions x JOIN dbo.Emp_PayrollDetails d ON d.CmpID=x.CmpID AND d.SourceType=21 AND d.SourceID=x.DeductionID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND x.DeductionState=1 AND (x.TotalAmount IS NULL OR x.AssessedTotal+d.Amount<=x.TotalAmount);
  IF @@ROWCOUNT<>@ExternalDeductionDetailCount THROW 54867,N'تعذر تحديث جميع الاستقطاعات الخارجية؛ أُلغيت عملية الترحيل.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayrollDeductionArrears a ON a.CmpID=d.CmpID AND a.ArrearID=d.SourceID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=22 AND (a.ArrearState<>0 OR d.Amount>a.OutstandingAmount OR d.Amount<>d.CollectedAmount+d.DeferredAmount))
   THROW 54917,N'تغير رصيد الاستقطاع المؤجل بعد احتساب المسير؛ أعد الاحتساب قبل الترحيل.',1;
     IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayrollDeductionArrears ar ON ar.CmpID=d.CmpID AND ar.ArrearID=d.SourceID AND ar.OriginalSourceType=20 LEFT JOIN dbo.Emp_SalaryAdvanceInstallments i ON i.CmpID=ar.CmpID AND i.InstallmentID=ar.OriginalSourceID
    WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=22 AND (i.InstallmentID IS NULL OR i.InstallmentState<>0 OR i.PaidAmount+ISNULL(d.CollectedAmount,0)>i.Amount))
    THROW 54956,N'رصيد المرتب المقدم المؤجل لا يطابق قسطه الأصلي؛ أُوقف الترحيل.',1;
SELECT @ArrearDetailCount=COUNT(*) FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND SourceType=22;
   INSERT dbo.Emp_PayrollDeductionArrearEvents(CmpID,ArrearID,PayRunID,PayrollDetailID,EventType,Amount,OutstandingBefore,OutstandingAfter,CreatedBy)
   SELECT d.CmpID,a.ArrearID,@PayRunID,d.PayrollDetailID,2,d.CollectedAmount,a.OutstandingAmount,a.OutstandingAmount-d.CollectedAmount,@UserID
   FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayrollDeductionArrears a ON a.CmpID=d.CmpID AND a.ArrearID=d.SourceID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=22 AND d.CollectedAmount>0;
  UPDATE a SET CollectedAmount=a.CollectedAmount+ISNULL(d.CollectedAmount,0),OutstandingAmount=a.OutstandingAmount-ISNULL(d.CollectedAmount,0),ArrearState=CASE WHEN a.OutstandingAmount-ISNULL(d.CollectedAmount,0)=0 THEN 1 ELSE 0 END,UpdatedAt=SYSDATETIME()
   FROM dbo.Emp_PayrollDeductionArrears a JOIN dbo.Emp_PayrollDetails d ON d.CmpID=a.CmpID AND d.SourceType=22 AND d.SourceID=a.ArrearID
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND a.ArrearState=0 AND ISNULL(d.CollectedAmount,0)<=a.OutstandingAmount;
  IF @@ROWCOUNT<>@ArrearDetailCount THROW 54918,N'تعذر تحديث جميع الأرصدة المؤجلة؛ أُلغيت عملية الترحيل.',1;
   SELECT @AdvanceArrearCount=COUNT(*) FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayrollDeductionArrears ar ON ar.CmpID=d.CmpID AND ar.ArrearID=d.SourceID AND ar.OriginalSourceType=20 WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=22 AND ISNULL(d.CollectedAmount,0)>0;
   UPDATE i SET PaidAmount=i.PaidAmount+d.CollectedAmount,InstallmentState=CASE WHEN i.PaidAmount+d.CollectedAmount>=i.Amount THEN 1 ELSE 0 END,PaidAt=CASE WHEN i.PaidAmount+d.CollectedAmount>=i.Amount THEN SYSDATETIME() ELSE NULL END
    FROM dbo.Emp_SalaryAdvanceInstallments i JOIN dbo.Emp_PayrollDeductionArrears ar ON ar.CmpID=i.CmpID AND ar.OriginalSourceType=20 AND ar.OriginalSourceID=i.InstallmentID
    JOIN dbo.Emp_PayrollDetails d ON d.CmpID=ar.CmpID AND d.SourceType=22 AND d.SourceID=ar.ArrearID
    WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND i.InstallmentState=0 AND ISNULL(d.CollectedAmount,0)>0 AND i.PaidAmount+d.CollectedAmount<=i.Amount;
   IF @@ROWCOUNT<>@AdvanceArrearCount THROW 54957,N'تعذر تحديث أقساط المرتبات المقدمة المؤجلة؛ أُلغيت عملية الترحيل.',1;
   INSERT dbo.Emp_SalaryAdvancePayments(CmpID,InstallmentID,Amount,PaymentDate,PaymentSource,PayRunID,CreatedBy)
    SELECT ar.CmpID,ar.OriginalSourceID,d.CollectedAmount,CONVERT(date,SYSDATETIME()),2,@PayRunID,@UserID
    FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayrollDeductionArrears ar ON ar.CmpID=d.CmpID AND ar.ArrearID=d.SourceID AND ar.OriginalSourceType=20
    WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.SourceType=22 AND d.CollectedAmount>0;
   UPDATE a SET AdvanceState=3 FROM dbo.Emp_SalaryAdvances a WHERE a.CmpID=@CmpID AND a.AdvanceState=1
    AND NOT EXISTS(SELECT 1 FROM dbo.Emp_SalaryAdvanceInstallments i WHERE i.CmpID=a.CmpID AND i.AdvanceID=a.AdvanceID AND i.InstallmentState=0)
    AND EXISTS(SELECT 1 FROM dbo.Emp_SalaryAdvanceInstallments i JOIN dbo.Emp_PayrollDeductionArrears ar ON ar.CmpID=i.CmpID AND ar.OriginalSourceType=20 AND ar.OriginalSourceID=i.InstallmentID JOIN dbo.Emp_PayrollDeductionArrearEvents ev ON ev.CmpID=ar.CmpID AND ev.ArrearID=ar.ArrearID JOIN dbo.Emp_PayrollDetails d ON d.CmpID=ev.CmpID AND d.PayrollDetailID=ev.PayrollDetailID WHERE i.CmpID=a.CmpID AND i.AdvanceID=a.AdvanceID AND ev.PayRunID=@PayRunID AND ev.EventType=2);
  INSERT dbo.Emp_PayrollDeductionArrears(CmpID,EmployeeID,ComponentID,OriginalSourceType,OriginalSourceID,OriginPeriodID,OriginPayRunID,OriginPayrollDetailID,CurrencyID,OriginalAmount,CollectedAmount,OutstandingAmount,DeductionPriority,IsMandatoryDeduction,CanDefer)
   OUTPUT inserted.ArrearID,inserted.OriginPayrollDetailID,inserted.OutstandingAmount INTO @CreatedArrears(ArrearID,OriginPayrollDetailID,Amount)
   SELECT d.CmpID,d.EmployeeID,d.ComponentID,d.SourceType,d.SourceID,@PeriodID,@PayRunID,d.PayrollDetailID,r.CurrencyID,d.Amount,ISNULL(d.CollectedAmount,0),d.DeferredAmount,a.DeductionPriority,a.IsMandatoryDeduction,a.CanDefer
   FROM dbo.Emp_PayrollDetails d JOIN dbo.Emp_PayRuns r ON r.CmpID=d.CmpID AND r.PayRunID=d.PayRunID
   JOIN dbo.Emp_PayrollDeductionAllocations a ON a.CmpID=d.CmpID AND a.PayRunID=d.PayRunID AND a.PayrollDetailID=d.PayrollDetailID AND a.CalculationVersion=r.CalculationVersion
   WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.LineKind=2 AND d.SourceType IS DISTINCT FROM 13 AND d.SourceType IS DISTINCT FROM 22 AND d.DeferredAmount>0 AND a.CanDefer=1;
  INSERT dbo.Emp_PayrollDeductionArrearEvents(CmpID,ArrearID,PayRunID,PayrollDetailID,EventType,Amount,OutstandingBefore,OutstandingAfter,CreatedBy)
   SELECT @CmpID,ArrearID,@PayRunID,OriginPayrollDetailID,1,Amount,0,Amount,@UserID FROM @CreatedArrears;
  UPDATE a SET ActionState=3,ProcessedAt=SYSDATETIME()
  FROM dbo.Emp_RewardsPenalties a
  JOIN dbo.Emp_PayrollDetails d ON d.CmpID=a.CmpID AND d.SourceID=a.ActionID
    AND d.SourceType=CASE WHEN a.ActionType=1 THEN 10 ELSE 11 END
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND a.ActionState=1;
  UPDATE o SET RequestState=3
  FROM dbo.Emp_OvertimeRequests o
  JOIN dbo.Emp_PayrollDetails d ON d.CmpID=o.CmpID AND d.SourceType=12 AND d.SourceID=o.OvertimeID
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND o.RequestState=1;
  EXEC sys.sp_set_session_context @key=N'Acc.SystemOperation',@value=NULL;
  COMMIT;
 END TRY
 BEGIN CATCH
  EXEC sys.sp_set_session_context @key=N'Acc.SystemOperation',@value=NULL;
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
 IF @SuppressResult=0 SELECT * FROM @Result;
 END;
GO

-- F4: Acc_DeleteDayVoucher
/* =====================================================================
   3) حذف قيد مؤقت فقط (الحالة 0)
   ===================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[Acc_DeleteDayVoucher]
    @Cmp    INT,
    @DayMID BIGINT,
    @User   BIGINT = NULL      -- [HIST] المستخدم المنفِّذ؛ إن أُهمل يُسجَّل منشئ القيد
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    DECLARE @State TINYINT;
    SELECT @State = DayMState FROM dbo.Acc_DayMaster WHERE DayMID = @DayMID AND DayMCompany = @Cmp;

    IF @State IS NULL
        THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;
    IF @State <> 0
        THROW 50122, N'لا يُحذف إلا القيد المؤقت.', 1;
    /* [AUDIT-FIX F4] a voucher referenced by a pay run must not be deleted (Emp_PayRuns.VoucherID has no foreign key) */
    IF EXISTS (SELECT 1 FROM dbo.Emp_PayRuns WHERE CmpID = @Cmp AND VoucherID = @DayMID)
        THROW 50309, N'القيد مرتبط بمسير رواتب ولا يجوز حذفه.', 1;

    /* [FY] لا حذف داخل سنة مالية مقفلة */
    IF NOT EXISTS (SELECT 1
                   FROM dbo.Acc_DayMaster AS m
                   JOIN dbo.Acc_FiscalYear AS f
                     ON f.AccFCmpID = m.DayMCompany AND f.AccFYear = YEAR(m.DayMDate) AND f.AccFState = 0
                   WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp)
        THROW 50131, N'القيد يتبع سنة مالية مقفلة أو غير موجودة.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_DeleteDayVoucher;

    BEGIN TRY
        /* [HIST] حذف (6): صورة القيد وبنوده قبل الحذف، للقيود اليدوية فقط */
        IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) <> 1
           AND NOT EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucher WHERE AvDayMID = @DayMID)
        BEGIN
            INSERT dbo.Acc_DayMasterHistory
                (DayMHOpration, DayMHMID, DayMHMDate, DayMHMDescription, DayMHState, DayMHUser, DayMHNo, DayMHCompany)
            SELECT 6, m.DayMID, m.DayMDate, m.DayMDescription, m.DayMState, ISNULL(@User, m.DayMUser), m.DayMNo, m.DayMCompany
            FROM dbo.Acc_DayMaster AS m
            WHERE m.DayMID = @DayMID;

            INSERT dbo.Acc_DayDetailsHistory
                (DayDHOpration, DayHDDID, DayDHMID, DayDHAccID, DayDHDeb, DayDHCrd, DayDHCsCID, DayDHNum, DayDHDescription, DayDHState, DayDHUser)
            SELECT 6, d.DayDID, d.DayDMID, d.DayDAccID, d.DayDDeb, d.DayDCrd, d.DayDCsCID, d.DayDNum, d.DayDDescription, m.DayMState, ISNULL(@User, m.DayMUser)
            FROM dbo.Acc_DayDetails AS d
            JOIN dbo.Acc_DayMaster AS m ON m.DayMID = d.DayDMID
            WHERE d.DayDMID = @DayMID;
        END;

        DELETE dbo.Acc_DayDetails WHERE DayDMID = @DayMID;
        DELETE dbo.Acc_DayMaster  WHERE DayMID = @DayMID AND DayMCompany = @Cmp AND DayMState = 0;

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_DeleteDayVoucher;

        THROW;
    END CATCH;
END;
GO

-- F5: Pay_RegisterDisbursement
/* @Lines JSON: [{"employeeId":1,"amount":3000.000},...]. Replaying the same @IdempotencyKey returns the original batch and writes nothing. */
CREATE OR ALTER PROCEDURE [dbo].[Pay_RegisterDisbursement]
 @CmpID INT,@UserID BIGINT,@SheetID BIGINT,@IdempotencyKey NVARCHAR(100),@PaymentMethod TINYINT,@DisbursementDate DATE,@Lines NVARCHAR(MAX),@Reference NVARCHAR(200)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Pay_ValidateActor @CmpID,@UserID;
 BEGIN TRY
  SET @IdempotencyKey=LTRIM(RTRIM(@IdempotencyKey));
  IF NULLIF(@IdempotencyKey,N'') IS NULL OR @PaymentMethod NOT BETWEEN 1 AND 4 OR @DisbursementDate IS NULL OR ISJSON(@Lines)<>1 THROW 55070,N'بيانات الدفعة غير صحيحة.',1;
  DECLARE @Id BIGINT,@Batch INT,@St TINYINT,@ExistingSheet BIGINT;
  DECLARE @L TABLE(EmployeeID BIGINT NOT NULL PRIMARY KEY,Amount DECIMAL(19,3) NOT NULL);
  BEGIN TRANSACTION;
  SELECT @Id=DisbursementID,@ExistingSheet=SheetID FROM dbo.Pay_Disbursements WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND IdempotencyKey=@IdempotencyKey;
  IF @Id IS NOT NULL
  BEGIN
   IF @ExistingSheet<>@SheetID THROW 55071,N'مفتاح عدم التكرار مستخدم لمسير آخر.',1;
   INSERT dbo.Pay_DisbursementAudit(CmpID,DisbursementID,EventType,Note,EventBy) VALUES(@CmpID,@Id,4,N'طلب مكرر لم يُنفَّذ',@UserID);
   COMMIT;
   SELECT DisbursementID,BatchNo,DisbursementState,CAST(1 AS BIT) AS IsReplay FROM dbo.Pay_Disbursements WHERE DisbursementID=@Id;
   RETURN;
  END
  SELECT @St=SheetState FROM dbo.Pay_PayrollSheets WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND SheetID=@SheetID;
  IF @St IS NULL THROW 55072,N'المسير غير موجود.',1;
  IF @St<>2 THROW 55073,N'لا يُصرف قبل اعتماد المسير.',1;
  -- [AUDIT-FIX F5] money must not leave before the payroll accrual voucher is posted
  IF NOT EXISTS(SELECT 1 FROM dbo.Pay_PayrollSheets sh JOIN dbo.Emp_PayRuns r ON r.CmpID=sh.CmpID AND r.PayRunID=sh.PayRunID JOIN dbo.Acc_DayMaster v ON v.DayMID=r.VoucherID AND v.DayMCompany=r.CmpID WHERE sh.CmpID=@CmpID AND sh.SheetID=@SheetID AND v.DayMState NOT IN(0,2))
   THROW 55094,N'لا يُصرف قبل ترحيل قيد استحقاق المسير محاسبياً.',1;
  IF EXISTS(SELECT 1 FROM OPENJSON(@Lines) WITH(employeeId BIGINT '$.employeeId') GROUP BY employeeId HAVING COUNT(*)>1) THROW 55074,N'موظف مكرر داخل الدفعة.',1;
  IF EXISTS(SELECT 1 FROM OPENJSON(@Lines) WITH(employeeId BIGINT '$.employeeId',amount DECIMAL(19,3) '$.amount') WHERE employeeId IS NULL OR amount IS NULL) THROW 55079,N'بند دفعة بلا موظف أو بلا مبلغ.',1;
  INSERT @L(EmployeeID,Amount) SELECT employeeId,amount FROM OPENJSON(@Lines) WITH(employeeId BIGINT '$.employeeId',amount DECIMAL(19,3) '$.amount');
  IF NOT EXISTS(SELECT 1 FROM @L) OR EXISTS(SELECT 1 FROM @L WHERE Amount<=0) THROW 55075,N'بنود الدفعة فارغة أو بقيم غير موجبة.',1;
  IF EXISTS(SELECT 1 FROM @L l WHERE NOT EXISTS(SELECT 1 FROM dbo.Pay_SheetLines sl WHERE sl.CmpID=@CmpID AND sl.SheetID=@SheetID AND sl.EmployeeID=l.EmployeeID)) THROW 55076,N'موظف غير وارد في المسير.',1;
  IF EXISTS(SELECT 1 FROM @L l JOIN dbo.Pay_vw_SheetLineBalances b ON b.CmpID=@CmpID AND b.SheetID=@SheetID AND b.EmployeeID=l.EmployeeID WHERE l.Amount>b.Remaining)
   THROW 55077,N'مبلغ الدفعة يتجاوز المتبقي من صافي المستحق.',1;
  SELECT @Batch=ISNULL(MAX(BatchNo),0)+1 FROM dbo.Pay_Disbursements WHERE CmpID=@CmpID AND SheetID=@SheetID;
  INSERT dbo.Pay_Disbursements(CmpID,SheetID,BatchNo,IdempotencyKey,DisbursementDate,PaymentMethod,Reference,CreatedBy) VALUES(@CmpID,@SheetID,@Batch,@IdempotencyKey,@DisbursementDate,@PaymentMethod,@Reference,@UserID);
  SET @Id=SCOPE_IDENTITY();
  INSERT dbo.Pay_DisbursementLines(CmpID,DisbursementID,SheetID,EmployeeID,Amount) SELECT @CmpID,@Id,@SheetID,EmployeeID,Amount FROM @L;
  INSERT dbo.Pay_DisbursementAudit(CmpID,DisbursementID,EventType,Note,EventBy) VALUES(@CmpID,@Id,1,N'تسجيل تعليمات صرف',@UserID);
  COMMIT;
  SELECT DisbursementID,BatchNo,DisbursementState,CAST(0 AS BIT) AS IsReplay FROM dbo.Pay_Disbursements WHERE DisbursementID=@Id;
 END TRY
 BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH
END
GO

-- F6: Acc_CloseFiscalYear
CREATE OR ALTER PROCEDURE [dbo].[Acc_CloseFiscalYear]
    @CmpID   INT,
    @CmpUser BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @AccFYear INT;
    DECLARE @AccFName NVARCHAR(100);

    BEGIN TRY
        BEGIN TRANSACTION;

        -- تحديد أصغر سنة مالية مفتوحة للشركة
        SELECT TOP (1)
            @AccFYear = AccFYear,
            @AccFName = AccFName
        FROM dbo.Acc_FiscalYear WITH (UPDLOCK, HOLDLOCK)
        WHERE AccFCmpID = @CmpID
          AND AccFState = 0
        ORDER BY AccFYear ASC;

        IF @AccFYear IS NULL
            THROW 51300, N'لا توجد سنة مالية مفتوحة لهذه الشركة.', 1;

        -- التحقق من اعتماد جميع القيود اليومية للسنة
        IF EXISTS
        (
            SELECT 1
            FROM dbo.Acc_DayMaster AS m
            WHERE m.DayMCompany = @CmpID
              AND YEAR(m.DayMDate) = @AccFYear
              /* [AUDIT-FIX F6] was: DayMState <> 7, which made closing impossible when the company disables
                 review/approval/archive. A voucher is unresolved if it is draft/returned (0,2,4,6) or still
                 has a pending stage according to the company settings (Acc_VoucherFlow). */
              AND (m.DayMState IN (0, 2, 4, 6)
                   OR (m.DayMState IN (1, 3, 5)
                       AND EXISTS (SELECT 1 FROM dbo.Acc_VoucherFlow(m.DayMCompany, m.DayMState))))
        )
            THROW 51301, N'لا يمكن إقفال السنة المالية لوجود قيود يومية غير معتمدة.', 1;

        -- إقفال السنة المالية
        UPDATE dbo.Acc_FiscalYear
        SET AccFState = 1 , AccFDateTime =  SYSDATETIME(), AccFUser = @CmpUser
        WHERE AccFCmpID = @CmpID
          AND AccFYear = @AccFYear;

        COMMIT TRANSACTION;

        -- إرجاع اسم السنة ورسالة النجاح للواجهة
        SELECT
            @AccFYear AS AccFYear,
            @AccFName AS AccFName,
            N'تم إقفال السنة المالية: ' + @AccFName AS Message;

    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO
PRINT N'MADAR audit fixes finished.';
GO

﻿/* MADAR ERP - candidate replacements for data-integrity review
   Seven procedures only. Acc_InsertSubAccount is intentionally excluded pending
   verification of application-level usage after the account-transfer change.
   Generated from MADAR_Database_Master.sql. Not executed against any database.
   Review before applying; this script is not approved for production execution.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
ALTER PROCEDURE [dbo].[Wrh_CloseYear]
    @Cmp INT, @User BIGINT, @CloseDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR @CloseDate IS NULL THROW 52712, N'الشركة وتاريخ الإقفال مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52707, N'المستخدم غير موجود.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp AND WsClosedUpTo IS NOT NULL AND WsClosedUpTo >= @CloseDate)
        THROW 52712, N'تاريخ الإقفال يجب أن يكون بعد تاريخ آخر إقفال.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocCmpID = @Cmp AND DocType = 13 AND DocStatus = 1 AND DocDate <= @CloseDate)
        THROW 52711, N'توجد مسودات جرد غير معتمدة حتى تاريخ الإقفال.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocCmpID = @Cmp AND DocStatus IN (1, 2) AND DocDate <= @CloseDate)
        THROW 52710, N'توجد مستندات مفتوحة حتى تاريخ الإقفال؛ أنهِها أو ألغِها أولًا.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_CloseYear;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp) INSERT dbo.Wrh_Settings (WsCmpID) VALUES (@Cmp);

        INSERT dbo.Wrh_YearClose (CloseCmpID, CloseDate, CloseBy, LayersMoved, UsesMoved) VALUES (@Cmp, @CloseDate, @User, 0, 0);
        DECLARE @CloseID BIGINT = SCOPE_IDENTITY(), @nl INT, @nu INT;

        CREATE TABLE #A (LayerID BIGINT PRIMARY KEY);
        INSERT #A (LayerID)
        SELECT l.LayerID FROM dbo.Wrh_Layer AS l WITH (UPDLOCK)
        WHERE l.LyCmpID = @Cmp AND l.LyQtyRem = 0 AND l.LyDate <= @CloseDate
          AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Layer AS y WHERE y.LyRootID = l.LyRootID AND y.LyQtyRem > 0)
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Wrh_LayerUse AS u
              JOIN dbo.Wrh_DocLine AS dl ON dl.LineID = u.UseLineID
              JOIN dbo.Wrh_Doc AS d ON d.DocID = dl.DocID
              WHERE u.UseLayerID = l.LayerID AND d.DocDate > @CloseDate
          );

        INSERT dbo.Wrh_LayerUseArchive (UseID, UseLineID, UseLayerID, UseQty, UseValue, ArchCloseID)
        SELECT u.UseID, u.UseLineID, u.UseLayerID, u.UseQty, u.UseValue, @CloseID FROM dbo.Wrh_LayerUse AS u JOIN #A AS a ON a.LayerID = u.UseLayerID;
        SET @nu = @@ROWCOUNT;
        DELETE u FROM dbo.Wrh_LayerUse AS u JOIN #A AS a ON a.LayerID = u.UseLayerID;
        DELETE x FROM dbo.Wrh_CostAdjLayer AS x JOIN #A AS a ON a.LayerID = x.LayerID;

        INSERT dbo.Wrh_LayerArchive (LayerID, LyCmpID, LyWhID, LyItemID, LyRootID, LyDate, LyQtyIn, LyQtyRem, LyValueIn, LyValueRem, LyUnitCost, LySrcLineID, ArchCloseID)
        SELECT l.LayerID, l.LyCmpID, l.LyWhID, l.LyItemID, l.LyRootID, l.LyDate, l.LyQtyIn, l.LyQtyRem, l.LyValueIn, l.LyValueRem, l.LyUnitCost, l.LySrcLineID, @CloseID
        FROM dbo.Wrh_Layer AS l JOIN #A AS a ON a.LayerID = l.LayerID;
        SET @nl = @@ROWCOUNT;
        DELETE l FROM dbo.Wrh_Layer AS l JOIN #A AS a ON a.LayerID = l.LayerID;
        DROP TABLE #A;

        UPDATE dbo.Wrh_YearClose SET LayersMoved = @nl, UsesMoved = @nu WHERE CloseID = @CloseID;
        UPDATE dbo.Wrh_Settings SET WsClosedUpTo = @CloseDate WHERE WsCmpID = @Cmp;

        IF @Started = 1 COMMIT;
        SELECT @CloseID AS CloseID, @nl AS LayersMoved, @nu AS UsesMoved;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_CloseYear;
        THROW;
    END CATCH
END;

GO

ALTER PROCEDURE [dbo].[Wrh_StockReverse]
    @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Type TINYINT, @Wh BIGINT, @Wh2 BIGINT;
    SELECT @Type = DocType, @Wh = DocWhID, @Wh2 = DocWh2ID FROM dbo.Wrh_Doc WHERE DocID = @DocID;
    IF @Type IS NULL OR @Type NOT IN (4, 5, 7, 8, 9, 10) RETURN;

    DECLARE @LockedLayers BIGINT;
    -- مزامنة عكس الحركة مع إقفال المخزون: من يسبق يقفل الطبقة أولًا.
    SELECT @LockedLayers = COUNT_BIG(*)
    FROM dbo.Wrh_Layer AS ly WITH (UPDLOCK, HOLDLOCK)
    WHERE EXISTS
    (
        SELECT 1
        FROM dbo.Wrh_DocLine AS dl
        WHERE dl.DocID = @DocID
          AND
          (
              ly.LySrcLineID = dl.LineID
              OR EXISTS
                 (SELECT 1 FROM dbo.Wrh_LayerUse AS u
                  WHERE u.UseLineID = dl.LineID AND u.UseLayerID = ly.LayerID)
          )
    );

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Wrh_DocLine AS dl
        WHERE dl.DocID = @DocID
          AND
          (
              EXISTS (SELECT 1 FROM dbo.Wrh_LayerUseArchive AS ua WHERE ua.UseLineID = dl.LineID)
              OR EXISTS (SELECT 1 FROM dbo.Wrh_LayerArchive AS la WHERE la.LySrcLineID = dl.LineID)
          )
    )
        THROW 52411, N'لا يمكن عكس هذا المستند؛ أثر إحدى حركاته موجود في أرشيف إقفال المخزون.', 1;

    DECLARE @lid BIGINT, @item BIGINT, @q DECIMAL(18,3), @avail DECIMAL(18,3);

    DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
        SELECT LineID, ItemID, BaseQty FROM dbo.Wrh_DocLine WHERE DocID = @DocID ORDER BY ItemID, DocLineNo;
    OPEN cur;
    FETCH NEXT FROM cur INTO @lid, @item, @q;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Type IN (4, 9, 8)   -- عمليات أنشأت طبقات في @Wh
        BEGIN
            IF @Type IN (4, 8) AND EXISTS (SELECT 1 FROM dbo.Wrh_CostAdj WHERE AdjRefLineID = @lid)
                THROW 52511, N'لا يمكن تعديل/حذف هذا الاستلام: عليه تكاليف إضافية أو تسوية؛ احذفها أولًا.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_Layer WHERE LySrcLineID = @lid AND LyWhID = @Wh AND LyQtyRem <> LyQtyIn)
                THROW 52410, N'لا يمكن تعديل/حذف هذه العملية: استُهلك جزء من الطبقة التي أنشأتها.', 1;
            SELECT @avail = StkQty - StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            IF @avail < @q
                THROW 52410, N'لا يمكن تعديل/حذف هذه العملية: الرصيد الحالي (بعد المحجوز) لا يغطي كميتها.', 1;
            DELETE dbo.Wrh_Layer WHERE LySrcLineID = @lid AND LyWhID = @Wh;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END

        IF @Type IN (5, 10, 8)   -- عمليات استهلكت طبقات: تُعاد
        BEGIN
            UPDATE l SET LyQtyRem = l.LyQtyRem + u.q, LyValueRem = l.LyValueRem + u.v
              FROM dbo.Wrh_Layer AS l
              JOIN (SELECT UseLayerID, SUM(UseQty) AS q, SUM(UseValue) AS v FROM dbo.Wrh_LayerUse
                    WHERE UseLineID = @lid GROUP BY UseLayerID) AS u ON u.UseLayerID = l.LayerID;
            DELETE dbo.Wrh_LayerUse WHERE UseLineID = @lid;
            IF @Type IN (5, 10)
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q WHERE StkWhID = @Wh AND StkItemID = @item;
            ELSE
            BEGIN
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q, StkReserved = StkReserved + @q WHERE StkWhID = @Wh2 AND StkItemID = @item;
            END
        END

        IF @Type = 7
            UPDATE dbo.Wrh_Stock SET StkReserved = StkReserved - @q WHERE StkWhID = @Wh AND StkItemID = @item;

        FETCH NEXT FROM cur INTO @lid, @item, @q;
    END
    CLOSE cur; DEALLOCATE cur;
END;

GO

ALTER PROCEDURE [dbo].[Wrh_SaveDoc]
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE,
    @WhID BIGINT = NULL, @Wh2ID BIGINT = NULL, @PartyID BIGINT = NULL, @CostCID BIGINT = NULL,
    @RefDocID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52302, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Class TINYINT, @NW BIT, @NW2 BIT, @NP BIT, @NC BIT, @NR BIT, @RT TINYINT;
    SELECT @Class = DtClass, @NW = DtNeedWh, @NW2 = DtNeedWh2, @NP = DtNeedParty, @NC = DtNeedCost,
           @NR = DtNeedRef, @RT = DtRefType
    FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type AND DtEngine = 1;
    IF @Class IS NULL THROW 52301, N'نوع المستند غير صحيح أو غير مدعوم في هذا المحرك.', 1;

    -- متطلبات الرأس
    IF @NW = 1 AND @WhID IS NULL THROW 52302, N'المخزن مطلوب لهذا النوع.', 1;
    IF @NW2 = 1 AND @Wh2ID IS NULL THROW 52302, N'المخزن المقابل مطلوب لهذا النوع.', 1;
    IF @NP = 1 AND @PartyID IS NULL THROW 52302, N'الجهة (المورد/العهدة) مطلوبة لهذا النوع.', 1;
    IF @NC = 1 AND @CostCID IS NULL THROW 52302, N'الجهة الطالبة (مركز التكلفة) مطلوبة لهذا النوع.', 1;
    IF @NR = 1 AND @RefDocID IS NULL THROW 52302, N'المستند المرجعي مطلوب لهذا النوع.', 1;

    IF @WhID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Wh2ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @Wh2ID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن المقابل غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @WhID IS NOT NULL AND @Wh2ID IS NOT NULL AND @WhID = @Wh2ID
        THROW 52310, N'المخزنان في التحويل يجب أن يكونا مختلفين.', 1;
    IF @PartyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
        THROW 52310, N'الجهة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    IF @CostCID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CostCID AND CsCCompany = @Cmp)
        THROW 52310, N'مركز التكلفة غير موجود أو لا يتبع الشركة.', 1;

    -- المستند المرجعي
    IF @RefDocID IS NOT NULL
    BEGIN
        IF @RT IS NULL THROW 52306, N'هذا النوع لا يقبل مستندًا مرجعيًا.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp AND DocType = @RT AND DocStatus <> 9)
            THROW 52306, N'المستند المرجعي غير صحيح (غير موجود أو نوعه لا يناسب أو ملغى أو لا يتبع الشركة).', 1;
    END

    -- دورة طلب المواد: الصرف من الطلب وهو عند المخزن ومن مخزنه، وطلب الشراء منه وهو عند المشتريات (عند الإدخال فقط)
    IF ISNULL(@DocID, 0) = 0 AND @RefDocID IS NOT NULL
    BEGIN
        IF @Type = 5 AND EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocType = 1
                                 AND (ISNULL(DocFlow, 1) <> 1 OR ISNULL(DocWhID, 0) <> ISNULL(@WhID, 0)))
            THROW 52322, N'الصرف من الطلب يكون وهو عند المخزن وفي مخزن الطلب نفسه.', 1;
        IF @Type = 2 AND EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocType = 1 AND ISNULL(DocFlow, 2) <> 2)
            THROW 52323, N'طلب الشراء من طلب المواد يكون وهو عند المشتريات.', 1;
    END

    -- دور الجهة (خيار الشركة WsEnforcePartyRole)
    IF @PartyID IS NOT NULL AND ISNULL((SELECT WsEnforcePartyRole FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1) = 1
    BEGIN
        IF @Type IN (3, 4, 6) AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtRole IN (1, 3))
            THROW 52901, N'هذا النوع يقبل مورّدًا أو موظف عهدة فقط.', 1;
        IF @Type IN (10, 11, 12) AND @RefDocID IS NOT NULL
           AND ISNULL((SELECT DocPartyID FROM dbo.Wrh_Doc WHERE DocID = @RefDocID), 0) <> @PartyID
            THROW 52902, N'يجب أن تكون الجهة هي نفس جهة المستند الأصلي.', 1;
    END

    -- البنود
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52303, N'بنود المستند غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6),
                     RefLineID BIGINT, Factor DECIMAL(18,6), BaseQty DECIMAL(18,3));

    INSERT #L (Ord, ItemID, UnitID, Qty, Price, RefLineID)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price, j.RefLineID
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID',
                                          Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price',
                                          RefLineID BIGINT '$.RefLineID') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) THROW 52303, N'يجب أن يحتوي المستند على بند واحد على الأقل.', 1;
    IF EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty <= 0 OR Price < 0)
        THROW 52303, N'كل بند يحتاج صنفًا ووحدة وكمية أكبر من صفر وسعرًا غير سالب.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS
               (SELECT 1 FROM dbo.Wrh_Item AS i WHERE i.ItemID = l.ItemID AND i.ItemCmpID = @Cmp AND i.ItemActive = 1))
        THROW 52303, N'صنف غير موجود أو معطّل أو لا يتبع الشركة.', 1;

    -- أصناف الطلب (طلب مواد / طلب شراء) تخص مجموعات المخزن؛ والمخزن الذي لا ربط له بعد يبقى بلا قيد
    IF @Type IN (1, 2) AND @WhID IS NOT NULL
       AND EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwWhID = @WhID)
       AND EXISTS (SELECT 1 FROM #L AS l JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
                   WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse AS gw WHERE gw.GwGrpID = i.ItemGrpID AND gw.GwWhID = @WhID))
        THROW 52231, N'يوجد صنف لا يتبع مجموعات هذا المخزن.', 1;

    UPDATE l
       SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l
      JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL)
        THROW 52304, N'وحدة غير معرّفة لهذا الصنف (ليست الأساس ولا ثانوية بمعامل تحويل).', 1;
    UPDATE #L SET BaseQty = ROUND(Qty * Factor, 3);
    IF EXISTS (SELECT 1 FROM #L WHERE BaseQty <= 0) THROW 52303, N'الكمية بالوحدة الأساس تساوي صفرًا.', 1;

    -- ربط البنود بالمرجع
    IF @RefDocID IS NOT NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM #L AS l WHERE l.RefLineID IS NULL OR NOT EXISTS
                   (SELECT 1 FROM dbo.Wrh_DocLine AS r WHERE r.LineID = l.RefLineID AND r.DocID = @RefDocID AND r.ItemID = l.ItemID))
            THROW 52306, N'كل بند يجب أن يرتبط ببند من المستند المرجعي ولنفس الصنف.', 1;
    END
    ELSE IF EXISTS (SELECT 1 FROM #L WHERE RefLineID IS NOT NULL)
        THROW 52306, N'لا يجوز ربط بند بمرجع دون تحديد المستند المرجعي.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveDoc;

    BEGIN TRY
        DECLARE @OldRef BIGINT = NULL, @DocNo NVARCHAR(10), @Year INT = YEAR(@Date), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT, @OWh BIGINT, @OFlow TINYINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo, @OldRef = DocRefDocID, @OWh = DocWhID, @OFlow = DocFlow
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;

            IF @OType IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52301, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52312, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF @OType = 1 AND ISNULL(@OFlow, 1) <> 0 THROW 52320, N'الطلب المُرسَل لا يُعدَّل (ألغِه أو أعد إرساله كما هو).', 1;
            IF @OType = 1 AND ISNULL(@OWh, 0) <> ISNULL(@WhID, 0) THROW 52321, N'لا يُغيَّر مخزن الطلب بعد حفظه؛ احذف المسودة وأنشئ طلبًا جديدًا.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
                THROW 52305, N'لا يجوز تعديل مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

            IF EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID = @DocID)
                THROW 52325, N'لا يجوز تعديل مستند مرتبط بقيد محاسبي آلي؛ عالج القيد من مسار المحاسبة أولًا.', 1;

            IF EXISTS
            (
                SELECT 1 FROM dbo.Wrh_DocLine AS dl
                WHERE dl.DocID = @DocID
                  AND
                  (
                      EXISTS (SELECT 1 FROM dbo.Wrh_LayerUseArchive AS ua WHERE ua.UseLineID = dl.LineID)
                      OR EXISTS (SELECT 1 FROM dbo.Wrh_LayerArchive AS la WHERE la.LySrcLineID = dl.LineID)
                  )
            )
                THROW 52326, N'لا يجوز تعديل مستند دخل أثره في أرشيف إقفال المخزون.', 1;

            EXEC dbo.Wrh_StockReverse @DocID;   -- يعكس أثر المخزون القديم
            -- تراجع أثر الربط القديم ثم حذف البنود القديمة
            UPDATE r SET QtyReferred = r.QtyReferred - s.q
              FROM dbo.Wrh_DocLine AS r
              JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;
            DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;

            UPDATE dbo.Wrh_Doc
               SET DocDate = @Date, DocWhID = @WhID, DocWh2ID = @Wh2ID, DocPartyID = @PartyID,
                   DocCostCID = @CostCID, DocRefDocID = @RefDocID, DocNotes = @Notes
             WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            IF @Type = 1   -- مسودة طلب مواد: رقم مؤقت يبدأ بـ T، والرقم الرسمي يُعطى عند الإرسال
                SET @DocNo = N'T' + LEFT(REPLACE(CAST(NEWID() AS NVARCHAR(36)), N'-', N''), 9);
            ELSE
                EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocWh2ID,
                                DocPartyID, DocCostCID, DocRefDocID, DocNotes, DocCreatedBy, DocFlow)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, CASE WHEN @Class = 1 THEN 1 ELSE 3 END, @WhID, @Wh2ID,
                    @PartyID, @CostCID, @RefDocID, @Notes, @User, CASE WHEN @Type = 1 THEN 0 END);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_DocLine (DocID, DocLineNo, ItemID, UnitID, Factor, Qty, BaseQty, UnitPrice, Amount, RefLineID)
        SELECT @DocID, ROW_NUMBER() OVER (ORDER BY l.Ord), l.ItemID, l.UnitID, l.Factor, l.Qty, l.BaseQty, l.Price,
               CAST(ROUND(l.Qty * ISNULL(l.Price, 0), 3) AS DECIMAL(18,3)), l.RefLineID
        FROM #L AS l;

        -- أثر الربط الجديد (مع التحقق من المتبقي)
        IF EXISTS (SELECT 1
                   FROM (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
                   JOIN dbo.Wrh_DocLine AS r WITH (UPDLOCK) ON r.LineID = s.RefLineID
                   WHERE r.BaseQty - r.QtyReferred - r.QtyCancelled < s.q)
            THROW 52306, N'الكمية تتجاوز المتبقي في البند المرجعي.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred + s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
            ON s.RefLineID = r.LineID;

        EXEC dbo.Wrh_StockApply @DocID;     -- أثر المخزون الجديد

        EXEC dbo.Wrh_RecalcDocStatus @RefDocID;
        IF @OldRef IS NOT NULL AND ISNULL(@OldRef, 0) <> ISNULL(@RefDocID, 0)
            EXEC dbo.Wrh_RecalcDocStatus @OldRef;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo, d.DocStatus FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveDoc;
        THROW;
    END CATCH
END;

GO

ALTER PROCEDURE [dbo].[Wrh_DeleteDoc]
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_DeleteDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10), @Ref BIGINT;
        SELECT @Type = DocType, @No = DocNo, @Ref = DocRefDocID
        FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
        IF @Type IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
        IF @Type IN (14, 15)
            THROW 52327, N'مستندات التكلفة والتسوية تُحذف حصريًا عبر Wrh_DeleteCostDoc.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID = @DocID)
            THROW 52325, N'لا يجوز حذف مستند مرتبط بقيد محاسبي آلي؛ عالج القيد من مسار المحاسبة أولًا.', 1;
        IF EXISTS
        (
            SELECT 1 FROM dbo.Wrh_DocLine AS dl
            WHERE dl.DocID = @DocID
              AND
              (
                  EXISTS (SELECT 1 FROM dbo.Wrh_LayerUseArchive AS ua WHERE ua.UseLineID = dl.LineID)
                  OR EXISTS (SELECT 1 FROM dbo.Wrh_LayerArchive AS la WHERE la.LySrcLineID = dl.LineID)
              )
        )
            THROW 52326, N'لا يجوز حذف مستند دخل أثره في أرشيف إقفال المخزون.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
            THROW 52305, N'لا يجوز حذف مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

        EXEC dbo.Wrh_StockReverse @DocID;

        UPDATE r SET QtyReferred = r.QtyReferred - s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;

        DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;
        DELETE dbo.Wrh_Doc WHERE DocID = @DocID;
        EXEC dbo.Wrh_RecalcDocStatus @Ref;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 3, @User, NULLIF(LTRIM(RTRIM(@Reason)), N''));

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_DeleteDoc;
        THROW;
    END CATCH
END;

GO

ALTER PROCEDURE [dbo].[Wrh_SaveCostDoc]
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE, @RefDocID BIGINT,
    @PartyID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Items NVARCHAR(MAX), @OnlyLines NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52506, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52506, N'المستخدم غير موجود.', 1;
    IF @Type IS NULL OR @Type NOT IN (14, 15) THROW 52501, N'هذا الإجراء لمستندات التكلفة الإضافية (14) والتسوية (15) فقط.', 1;

    DECLARE @RefType TINYINT, @RefWh BIGINT;
    SELECT @RefType = DocType, @RefWh = DocWhID FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp;
    IF @RefType IS NULL OR (@Type = 15 AND @RefType <> 4) OR (@Type = 14 AND @RefType NOT IN (4, 8))
        THROW 52501, N'المستند المرجعي غير مناسب (التكلفة: استلام مخزني أو استلام تحويل، والتسوية: استلام مخزني).', 1;

    SET @Notes = NULLIF(LTRIM(RTRIM(@Notes)), N'');
    IF @Type = 15
    BEGIN
        IF @Notes IS NULL THROW 52502, N'سبب التسوية مطلوب.', 1;
        IF @PartyID IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
            THROW 52502, N'الجهة الدائنة (المورد) مطلوبة وصالحة.', 1;
    END
    ELSE SET @PartyID = NULL;

    IF @Items IS NULL OR ISJSON(@Items) <> 1 THROW 52506, N'بنود التكلفة غير صحيحة.', 1;

    CREATE TABLE #C (Ord INT, PartyID BIGINT, Kind TINYINT, Amount DECIMAL(18,3));
    CREATE TABLE #S (Ord INT, RefLineID BIGINT, Delta DECIMAL(18,3));
    CREATE TABLE #T (LineID BIGINT, Ord INT, Weight DECIMAL(18,3), Delta DECIMAL(18,3));

    IF @Type = 14
    BEGIN
        INSERT #C (Ord, PartyID, Kind, Amount)
        SELECT CAST(x.[key] AS INT), j.PartyID, j.Kind, j.Amount
        FROM OPENJSON(@Items) AS x
        CROSS APPLY OPENJSON(x.[value]) WITH (PartyID BIGINT '$.PartyID', Kind TINYINT '$.Kind', Amount DECIMAL(18,3) '$.Amount') AS j;
        IF NOT EXISTS (SELECT 1 FROM #C) OR EXISTS (SELECT 1 FROM #C WHERE PartyID IS NULL OR Kind IS NULL OR Kind NOT IN (1,2,3,4,5,6,9) OR Amount IS NULL OR Amount <= 0)
            THROW 52506, N'كل بند تكلفة يحتاج جهة ونوعًا (1 شحن، 2 جمارك، 3 تحميل، 4 تفريغ، 5 تعبئة، 6 نقل، 9 أخرى) ومبلغًا أكبر من صفر.', 1;
        IF EXISTS (SELECT 1 FROM #C AS c WHERE NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = c.PartyID AND PrtCmpID = @Cmp AND PrtActive = 1))
            THROW 52506, N'جهة تكلفة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    END
    ELSE
    BEGIN
        INSERT #S (Ord, RefLineID, Delta)
        SELECT CAST(x.[key] AS INT), j.RefLineID, j.Delta
        FROM OPENJSON(@Items) AS x
        CROSS APPLY OPENJSON(x.[value]) WITH (RefLineID BIGINT '$.RefLineID', Delta DECIMAL(18,3) '$.Delta') AS j;
        IF NOT EXISTS (SELECT 1 FROM #S) OR EXISTS (SELECT 1 FROM #S WHERE RefLineID IS NULL OR Delta IS NULL OR Delta = 0)
            THROW 52506, N'كل بند تسوية يحتاج بندًا مرجعيًا ومبلغًا غير صفري.', 1;
        IF EXISTS (SELECT 1 FROM #S GROUP BY RefLineID HAVING COUNT(*) > 1)
            THROW 52506, N'بند مرجعي مكرر في التسوية.', 1;
        IF EXISTS (SELECT 1 FROM #S AS s WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE LineID = s.RefLineID AND DocID = @RefDocID))
            THROW 52506, N'بند مرجعي لا يتبع المستند المرجعي.', 1;
    END

    DECLARE @Basis TINYINT = ISNULL((SELECT WsAllocBasis FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1);
    IF @Type = 14
    BEGIN
        IF @Basis = 3 THROW 52504, N'أساس التوزيع بالوزن غير متاح بعد (لا وزن للأصناف).', 1;
        IF @OnlyLines IS NOT NULL
        BEGIN
            IF ISJSON(@OnlyLines) <> 1 THROW 52506, N'قائمة البنود المحددة غير صحيحة.', 1;
            INSERT #T (LineID, Ord, Weight)
            SELECT l.LineID, l.DocLineNo, CASE WHEN @Basis = 1 THEN l.Amount ELSE l.BaseQty END
            FROM dbo.Wrh_DocLine AS l
            WHERE l.DocID = @RefDocID AND l.LineID IN (SELECT CAST(o.[value] AS BIGINT) FROM OPENJSON(@OnlyLines) AS o);
            IF (SELECT COUNT(*) FROM #T) <> (SELECT COUNT(*) FROM OPENJSON(@OnlyLines))
                THROW 52506, N'بند محدد لا يتبع المستند المرجعي.', 1;
        END
        ELSE
            INSERT #T (LineID, Ord, Weight)
            SELECT l.LineID, l.DocLineNo, CASE WHEN @Basis = 1 THEN l.Amount ELSE l.BaseQty END
            FROM dbo.Wrh_DocLine AS l WHERE l.DocID = @RefDocID;

        IF @RefType = 8   -- أساس القيمة لاستلام التحويل = قيمة الطبقات الناتجة
            IF @Basis = 1
                UPDATE t SET Weight = ISNULL((SELECT SUM(LyValueIn) FROM dbo.Wrh_Layer WHERE LySrcLineID = t.LineID), 0) FROM #T AS t;

        DECLARE @Total DECIMAL(18,3) = (SELECT SUM(Amount) FROM #C), @WSum DECIMAL(18,3) = (SELECT SUM(Weight) FROM #T);
        IF ISNULL(@WSum, 0) <= 0 THROW 52505, N'مجموع أساس التوزيع صفر؛ جرّب التوزيع بالكمية أو حدّد بنودًا.', 1;

        UPDATE t SET Delta = ROUND(@Total * t.Weight / @WSum, 3) FROM #T AS t;
        DECLARE @LastLine BIGINT = (SELECT TOP 1 LineID FROM #T ORDER BY Ord DESC, LineID DESC);
        UPDATE #T SET Delta = @Total - ISNULL((SELECT SUM(Delta) FROM #T WHERE LineID <> @LastLine), 0) WHERE LineID = @LastLine;
    END
    ELSE
    BEGIN
        INSERT #T (LineID, Ord, Weight, Delta)
        SELECT s.RefLineID, s.Ord, 0, s.Delta FROM #S AS s;
    END

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveCostDoc;

    BEGIN TRY
        DECLARE @Year INT = YEAR(@Date), @DocNo NVARCHAR(10), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
            IF @OType IS NULL THROW 52509, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52501, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52506, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID = @DocID)
                THROW 52510, N'لا يجوز تعديل مستند تكلفة مرتبط بقيد محاسبي آلي؛ عالج القيد من مسار المحاسبة أولًا.', 1;
            DECLARE @LockedCostLayers BIGINT;
            SELECT @LockedCostLayers = COUNT_BIG(*)
            FROM dbo.Wrh_Layer AS ly WITH (UPDLOCK, HOLDLOCK)
            WHERE EXISTS
            (
                SELECT 1
                FROM dbo.Wrh_CostAdjLayer AS cal
                JOIN dbo.Wrh_CostAdj AS ca ON ca.AdjID = cal.AdjID
                WHERE ca.AdjDocID = @DocID AND cal.LayerID = ly.LayerID
            );
            IF EXISTS
            (
                SELECT 1
                FROM dbo.Wrh_CostAdj AS ca
                JOIN dbo.Wrh_LayerArchive AS la ON la.LySrcLineID = ca.AdjRefLineID
                WHERE ca.AdjDocID = @DocID
            )
                THROW 52511, N'لا يجوز تعديل مستند تكلفة دخل أثره في أرشيف إقفال المخزون.', 1;
            EXEC dbo.Wrh_CostReverse @DocID;
            DELETE dbo.Wrh_CostLine WHERE CostDocID = @DocID;
            UPDATE dbo.Wrh_Doc SET DocDate = @Date, DocPartyID = @PartyID, DocRefDocID = @RefDocID, DocNotes = @Notes WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocPartyID, DocRefDocID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, 3, @PartyID, @RefDocID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        IF @Type = 14
            INSERT dbo.Wrh_CostLine (CostDocID, CostPartyID, CostKind, CostAmount)
            SELECT @DocID, PartyID, Kind, Amount FROM #C ORDER BY Ord;

        -- التطبيق على كل بند مرجعي
        DECLARE @Line BIGINT, @Delta DECIMAL(18,3), @Base DECIMAL(18,3), @Rem DECIMAL(18,3), @Root BIGINT,
                @RemPart DECIMAL(18,3), @AdjID BIGINT, @n INT, @i INT, @lyid BIGINT, @lyrem DECIMAL(18,3),
                @remSum DECIMAL(18,3), @share DECIMAL(18,3), @given DECIMAL(18,3);

        DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR SELECT LineID, Delta FROM #T ORDER BY Ord, LineID;
        OPEN cur; FETCH NEXT FROM cur INTO @Line, @Delta;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            CREATE TABLE #LY (Seq INT IDENTITY(1,1), LayerID BIGINT, Rem DECIMAL(18,3));

            IF @RefType = 4
            BEGIN
                SET @Root = NULL;
                SELECT @Root = LayerID, @Base = LyQtyIn FROM dbo.Wrh_Layer WHERE LySrcLineID = @Line AND LyWhID = @RefWh;
                IF @Root IS NULL THROW 52501, N'بند الاستلام بلا طبقة (غير صالح للتكلفة).', 1;
                INSERT #LY (LayerID, Rem) SELECT LayerID, LyQtyRem FROM dbo.Wrh_Layer WITH (UPDLOCK)
                    WHERE LyRootID = @Root AND LyQtyRem > 0 ORDER BY LayerID;
            END
            ELSE
            BEGIN
                SELECT @Base = SUM(LyQtyIn) FROM dbo.Wrh_Layer WHERE LySrcLineID = @Line;
                IF ISNULL(@Base, 0) <= 0 THROW 52501, N'بند الاستلام بلا طبقات (غير صالح للتكلفة).', 1;
                INSERT #LY (LayerID, Rem) SELECT LayerID, LyQtyRem FROM dbo.Wrh_Layer WITH (UPDLOCK)
                    WHERE LySrcLineID = @Line AND LyQtyRem > 0 ORDER BY LayerID;
            END

            SELECT @Rem = ISNULL(SUM(Rem), 0), @n = COUNT(*) FROM #LY;
            SET @RemPart = CASE WHEN @Rem = 0 THEN 0 ELSE ROUND(@Delta * CAST(@Rem AS DECIMAL(18,6)) / @Base, 3) END;

            INSERT dbo.Wrh_CostAdj (AdjDocID, AdjRefLineID, AdjAmount, AdjRemPart, AdjConsPart, AdjBaseQty, AdjRemQty)
            VALUES (@DocID, @Line, @Delta, @RemPart, @Delta - @RemPart, @Base, @Rem);
            SET @AdjID = SCOPE_IDENTITY();

            SET @i = 1; SET @given = 0; SET @remSum = @Rem;
            WHILE @i <= @n AND @RemPart <> 0
            BEGIN
                SELECT @lyid = LayerID, @lyrem = Rem FROM #LY WHERE Seq = @i;
                SET @share = CASE WHEN @i = @n THEN @RemPart - @given ELSE ROUND(@RemPart * CAST(@lyrem AS DECIMAL(18,6)) / @remSum, 3) END;
                IF @share <> 0
                BEGIN
                    IF EXISTS (SELECT 1 FROM dbo.Wrh_Layer WHERE LayerID = @lyid AND LyValueRem + @share < 0)
                        THROW 52503, N'التخفيض يتجاوز قيمة المتبقي في الطبقات.', 1;
                    UPDATE dbo.Wrh_Layer
                       SET LyValueIn = LyValueIn + @share, LyValueRem = LyValueRem + @share,
                           LyUnitCost = ROUND((LyValueRem + @share) / LyQtyRem, 6)
                     WHERE LayerID = @lyid;
                    INSERT dbo.Wrh_CostAdjLayer (AdjID, LayerID, AddValue, RemAtAdj) VALUES (@AdjID, @lyid, @share, @lyrem);
                    SET @given = @given + @share;
                END
                SET @i = @i + 1;
            END

            DROP TABLE #LY;
            FETCH NEXT FROM cur INTO @Line, @Delta;
        END
        CLOSE cur; DEALLOCATE cur;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User, @Notes);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveCostDoc;
        THROW;
    END CATCH
END;

GO

ALTER PROCEDURE [dbo].[Wrh_DeleteCostDoc]
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52506, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_DeleteCostDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10);
        SELECT @Type = DocType, @No = DocNo FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK)
        WHERE DocID = @DocID AND DocCmpID = @Cmp AND DocType IN (14, 15);
        IF @Type IS NULL THROW 52509, N'المستند غير موجود أو لا يتبع الشركة أو ليس تكلفة/تسوية.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID = @DocID)
            THROW 52510, N'لا يجوز حذف مستند تكلفة مرتبط بقيد محاسبي آلي؛ عالج القيد من مسار المحاسبة أولًا.', 1;
        DECLARE @LockedCostLayers BIGINT;
        SELECT @LockedCostLayers = COUNT_BIG(*)
        FROM dbo.Wrh_Layer AS ly WITH (UPDLOCK, HOLDLOCK)
        WHERE EXISTS
        (
            SELECT 1
            FROM dbo.Wrh_CostAdjLayer AS cal
            JOIN dbo.Wrh_CostAdj AS ca ON ca.AdjID = cal.AdjID
            WHERE ca.AdjDocID = @DocID AND cal.LayerID = ly.LayerID
        );
        IF EXISTS
        (
            SELECT 1
            FROM dbo.Wrh_CostAdj AS ca
            JOIN dbo.Wrh_LayerArchive AS la ON la.LySrcLineID = ca.AdjRefLineID
            WHERE ca.AdjDocID = @DocID
        )
            THROW 52511, N'لا يجوز حذف مستند تكلفة دخل أثره في أرشيف إقفال المخزون.', 1;

        EXEC dbo.Wrh_CostReverse @DocID;
        DELETE dbo.Wrh_CostLine WHERE CostDocID = @DocID;
        DELETE dbo.Wrh_Doc WHERE DocID = @DocID;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 3, @User, NULLIF(LTRIM(RTRIM(@Reason)), N''));

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_DeleteCostDoc;
        THROW;
    END CATCH
END;

GO

ALTER PROCEDURE [dbo].[Acc_SaveDayVoucher]
    @Cmp    INT,
    @Year   INT,
    @User   BIGINT,
    @DayMID BIGINT = 0,              -- 0 = قيد جديد
    @Date   DATE,
    @Info   NVARCHAR(MAX),
    @Post   BIT = 0,                 -- 0 = حفظ مؤقت ، 1 = حفظ نهائي
    @Lines  dbo.Acc_DayLineType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;      -- نستخدم نقطة حفظ عند وجود معاملة خارجية

    DECLARE @Cnt INT, @Deb DECIMAL(18,3), @Crd DECIMAL(18,3), @Msg NVARCHAR(400);

    SELECT @Cnt = COUNT(*),
           @Deb = ISNULL(SUM(DayDDeb), 0),
           @Crd = ISNULL(SUM(DayDCrd), 0)
    FROM @Lines;

    /* ---------- التحقق (قبل أي كتابة) ---------- */
    IF @Date IS NULL OR @Year IS NULL OR YEAR(@Date) <> @Year
        THROW 50101, N'تاريخ القيد يجب أن يقع داخل السنة المالية المحددة.', 1;

    /* [FY] السنة المالية للتاريخ الجديد يجب أن تكون مفتوحة */
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_FiscalYear
                   WHERE AccFCmpID = @Cmp AND AccFYear = YEAR(@Date) AND AccFState = 0)
        THROW 50130, N'السنة المالية للتاريخ المحدد مقفلة أو غير موجودة.', 1;

    IF NULLIF(LTRIM(RTRIM(ISNULL(@Info, N''))), N'') IS NULL
        THROW 50102, N'شرح القيد مطلوب.', 1;

    IF @Cnt = 0
        THROW 50103, N'أضف بندًا واحدًا على الأقل قبل الحفظ.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 50112, N'المستخدم غير موجود.', 1;

    IF EXISTS (SELECT 1 FROM @Lines
               WHERE DayDDeb < 0 OR DayDCrd < 0
                  OR (DayDDeb = 0 AND DayDCrd = 0)
                  OR (DayDDeb > 0 AND DayDCrd > 0))
        THROW 50106, N'يوجد بند قيمته غير صحيحة: مدين أو دائن فقط، وأكبر من صفر.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS a
                                 WHERE a.AccID = l.DayDAccID AND a.AccCompany = @Cmp))
        THROW 50104, N'يوجد بند على حساب غير موجود أو لا يتبع الشركة.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = l.DayDAccID))
        THROW 50105, N'لا يجوز القيد على حساب أب، اختر حسابًا تحليليًا.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
               WHERE NOT (   (a.AccEnd = 1 AND a.AccType IN (0, 1, 2))
                          OR (a.AccEnd = 2 AND a.AccType IN (0, 1))))
        THROW 50108, N'يوجد بند على حساب تصنيفه المالي غير صحيح (AccEnd / AccType).', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE l.DayDCsCID IS NOT NULL
                 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS c
                                 WHERE c.CsCID = l.DayDCsCID AND c.CsCCompany = @Cmp))
        THROW 50109, N'يوجد بند على مركز تكلفة غير موجود أو لا يتبع الشركة.', 1;

    /* [ACC] لا قيد على حساب غير فعّال: AccState <> 0 (0 فعّال، 1 غير فعّال، وأي حالة مستقبلية تُمنع افتراضيًا
       كما تفعل قوائم اختيار الحسابات التي تعرض الحالة 0 فقط) */
    IF EXISTS (SELECT 1 FROM @Lines AS l
               JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
               WHERE a.AccState <> 0)
    BEGIN
        SELECT TOP (1) @Msg = CONCAT(N'لا يجوز القيد على حساب غير فعّال: ', a.AccCode, N' - ', a.AccName)
        FROM @Lines AS l
        JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
        WHERE a.AccState <> 0
        ORDER BY l.SeqNo;

        THROW 50115, @Msg, 1;
    END;

    /* حسابات النظام (توجيهات حسابية): لا يجوز القيد اليدوي عليها إلا من إجراء النظام.
       علامة النظام: sp_set_session_context 'Acc.SystemOperation' = 1 */
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Acc.SystemOperation')), 0) <> 1
       AND EXISTS (SELECT 1
                   FROM @Lines AS l
                   JOIN dbo.Acc_PostingRule  AS r ON r.AccID = l.DayDAccID
                   JOIN dbo.Acc_PostingState AS s ON s.StateID = r.StateID
                   WHERE s.AllowManualPosting = 0)
        THROW 50114, N'يوجد بند على حساب نظام لا يقبل القيد اليدوي (مثل حسابات الموردين والزبائن). يُرحَّل عليه من العملية الخاصة به فقط.', 1;

    IF @Post = 1
    BEGIN
        IF @Cnt < 2
            THROW 50107, N'القيد النهائي يحتاج بندين على الأقل.', 1;

        IF @Deb <> @Crd
        BEGIN
            SET @Msg = CONCAT(N'لا يمكن الحفظ النهائي لقيد غير متوازن. الفرق: ',
                              CONVERT(NVARCHAR(40), @Deb - @Crd));
            THROW 50111, @Msg, 1;
        END;
    END;

    /* ---------- الكتابة ---------- */
    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_SaveDayVoucher;

    BEGIN TRY
        DECLARE @OldDate DATE, @OldState TINYINT, @OldNo INT, @No INT, @State TINYINT;
        DECLARE @FiscalState BIT;

        -- قفل سجل السنة داخل معاملة الحفظ؛ يتعارض مع قفل إقفال السنة المالية.
        SELECT @FiscalState = fy.AccFState
        FROM dbo.Acc_FiscalYear AS fy WITH (UPDLOCK, HOLDLOCK)
        WHERE fy.AccFCmpID = @Cmp AND fy.AccFYear = YEAR(@Date);

        IF @FiscalState IS NULL OR @FiscalState <> 0
            THROW 50130, N'السنة المالية للتاريخ المحدد مقفلة أو غير موجودة.', 1;

        IF @DayMID > 0
        BEGIN
            SELECT @OldDate = m.DayMDate, @OldState = m.DayMState, @OldNo = m.DayMNo
            FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
            WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

            IF @OldState IS NULL
                THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;

            IF @OldState NOT IN (0, 2)
                THROW 50121, N'لا يمكن تعديل القيد في حالته الحالية (يُعدَّل المؤقت والمُعاد من المراجعة فقط).', 1;

            /* [FY] التاريخ القديم للقيد يجب ألا يتبع سنة مقفلة */
            IF NOT EXISTS (SELECT 1 FROM dbo.Acc_FiscalYear WITH (UPDLOCK, HOLDLOCK)
                           WHERE AccFCmpID = @Cmp AND AccFYear = YEAR(@OldDate) AND AccFState = 0)
                THROW 50131, N'القيد الأصلي يتبع سنة مالية مقفلة أو غير موجودة.', 1;
        END;

        /* [HIST] سجل التاريخ للقيود اليدوية فقط (لا القيود الآلية من المخازن) */
        DECLARE @LogIt BIT =
            CASE WHEN ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) <> 1
                  AND NOT EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucher WHERE AvDayMID = NULLIF(@DayMID, 0))
                 THEN 1 ELSE 0 END;
        DECLARE @IsNew BIT = CASE WHEN @DayMID = 0 THEN 1 ELSE 0 END;

        DECLARE @MS DATE = DATEFROMPARTS(YEAR(@Date), MONTH(@Date), 1);
        DECLARE @ME DATE = DATEADD(MONTH, 1, @MS);

        SET @No = ISNULL(@OldNo, 0);
        SET @State = CASE WHEN @Post = 1 THEN CAST(1 AS TINYINT) ELSE ISNULL(@OldState, CAST(0 AS TINYINT)) END;

        DECLARE @MonthChanged BIT =
            CASE WHEN @OldDate IS NOT NULL
                  AND DATEFROMPARTS(YEAR(@OldDate), MONTH(@OldDate), 1) <> @MS THEN 1 ELSE 0 END;

        IF @Post = 1 AND (@No = 0 OR @MonthChanged = 1)
        BEGIN
            -- رقم القيد = أكبر رقم في الشهر نفسه للشركة + 1 (القفل يمنع تكرار الرقم عند الحفظ المتزامن)
            SELECT @No = ISNULL(MAX(m.DayMNo), 0) + 1
            FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
            WHERE m.DayMCompany = @Cmp AND m.DayMDate >= @MS AND m.DayMDate < @ME;
        END
        ELSE IF @Post = 0 AND @No > 0 AND @MonthChanged = 1
            SET @No = 0;     -- رقم الشهر القديم لا يصلح للشهر الجديد؛ يُعاد توليده عند الترحيل

        IF @DayMID = 0
        BEGIN
            INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
            VALUES (@Date, @Info, @No, @State, @User, @Cmp);

            SET @DayMID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            /* [HIST] تعديل (2): صورة القيد وبنوده قبل التعديل */
            IF @LogIt = 1
            BEGIN
                INSERT dbo.Acc_DayMasterHistory
                    (DayMHOpration, DayMHMID, DayMHMDate, DayMHMDescription, DayMHState, DayMHUser, DayMHNo, DayMHCompany)
                SELECT 2, m.DayMID, m.DayMDate, m.DayMDescription, m.DayMState, @User, m.DayMNo, m.DayMCompany
                FROM dbo.Acc_DayMaster AS m
                WHERE m.DayMID = @DayMID;

                INSERT dbo.Acc_DayDetailsHistory
                    (DayDHOpration, DayHDDID, DayDHMID, DayDHAccID, DayDHDeb, DayDHCrd, DayDHCsCID, DayDHNum, DayDHDescription, DayDHState, DayDHUser)
                SELECT 2, d.DayDID, d.DayDMID, d.DayDAccID, d.DayDDeb, d.DayDCrd, d.DayDCsCID, d.DayDNum, d.DayDDescription, @OldState, @User
                FROM dbo.Acc_DayDetails AS d
                WHERE d.DayDMID = @DayMID;
            END;

            UPDATE dbo.Acc_DayMaster
            SET DayMDate = @Date, DayMDescription = @Info, DayMNo = @No, DayMState = @State
            WHERE DayMID = @DayMID AND DayMCompany = @Cmp;

            DELETE dbo.Acc_DayDetails WHERE DayDMID = @DayMID;
        END;

        INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDCsCID, DayDNum, DayDDescription)
        SELECT @DayMID, l.DayDAccID, l.DayDDeb, l.DayDCrd, l.DayDCsCID, l.DayDNum, l.DayDDescription
        FROM @Lines AS l
        ORDER BY l.SeqNo;

        /* [HIST] إنشاء (1): صورة القيد الجديد وبنوده بعد الحفظ */
        IF @LogIt = 1 AND @IsNew = 1
        BEGIN
            INSERT dbo.Acc_DayMasterHistory
                (DayMHOpration, DayMHMID, DayMHMDate, DayMHMDescription, DayMHState, DayMHUser, DayMHNo, DayMHCompany)
            SELECT 1, m.DayMID, m.DayMDate, m.DayMDescription, m.DayMState, @User, m.DayMNo, m.DayMCompany
            FROM dbo.Acc_DayMaster AS m
            WHERE m.DayMID = @DayMID;

            INSERT dbo.Acc_DayDetailsHistory
                (DayDHOpration, DayHDDID, DayDHMID, DayDHAccID, DayDHDeb, DayDHCrd, DayDHCsCID, DayDHNum, DayDHDescription, DayDHState, DayDHUser)
            SELECT 1, d.DayDID, d.DayDMID, d.DayDAccID, d.DayDDeb, d.DayDCrd, d.DayDCsCID, d.DayDNum, d.DayDDescription, @State, @User
            FROM dbo.Acc_DayDetails AS d
            WHERE d.DayDMID = @DayMID;
        END;

        -- فحص أخير من الجدول نفسه: لا يُرحَّل قيد غير متوازن مهما حدث
        IF @Post = 1
        BEGIN
            IF (SELECT SUM(DayDDeb) - SUM(DayDCrd) FROM dbo.Acc_DayDetails WHERE DayDMID = @DayMID) <> 0
                THROW 50113, N'القيد غير متوازن بعد الحفظ؛ أُلغي الترحيل.', 1;
        END;
        IF @Post = 1
        BEGIN
            INSERT INTO dbo.Acc_DayMasterState
            (
                DayMSDayMID,
                DayMSState,
                DayMSReason,
                DayMSUser
            )
            VALUES
            (
                @DayMID,
                @State,
                NULL,
                @User
            );
        END;
        IF @Started = 1 COMMIT;

        SELECT @DayMID AS DayMID,
               @No     AS DayMNo,
               @State  AS DayMState,
               CASE WHEN @No > 0
                    THEN CONCAT(@No, N'/', RIGHT(CONCAT(N'0', MONTH(@Date)), 2))
                    ELSE N'' END AS VoucherNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_SaveDayVoucher;

        THROW;
    END CATCH;
END;

GO

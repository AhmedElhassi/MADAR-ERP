﻿/* MADAR ERP - targeted repair for the journal-state transition trigger.
   This patch changes only TR_Acc_DayMaster_BalanceGuard. It is NOT the clean-install script.
   Run against the existing MADARERPDataBase after reviewing/backup. */
USE [MADARERPDataBase];
GO
CREATE OR ALTER TRIGGER dbo.TR_Acc_DayMaster_BalanceGuard
ON dbo.Acc_DayMaster
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.Acc_FiscalYear AS fy
            ON fy.AccFCmpID = i.DayMCompany AND fy.AccFYear = YEAR(i.DayMDate)
        WHERE fy.AccFState = 1
    )
        THROW 51022, N'لا يمكن إضافة قيد أو تعديل قيد في سنة مالية مقفلة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM deleted AS d
        INNER JOIN dbo.Acc_FiscalYear AS fy
            ON fy.AccFCmpID = d.DayMCompany AND fy.AccFYear = YEAR(d.DayMDate)
        WHERE fy.AccFState = 1
    )
        THROW 51024, N'لا يمكن تعديل قيد كان تابعًا لسنة مالية مقفلة، حتى لو تغير تاريخ القيد.', 1;

    /* Allowed workflow transitions:
       0->1, 1->2/3, 3->4/5, 5->6/7, 6->4, 4->2, 2->0, 7->6.
       A new journal must start in state 0. */
    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        LEFT JOIN deleted AS d ON d.DayMID = i.DayMID
        WHERE (d.DayMID IS NULL AND i.DayMState <> 0)
           OR
           (
               d.DayMID IS NOT NULL
               AND i.DayMState <> d.DayMState
               AND NOT EXISTS
               (
                   SELECT 1
                   FROM (VALUES
                       (CONVERT(TINYINT, 0), CONVERT(TINYINT, 1)),
                       (CONVERT(TINYINT, 1), CONVERT(TINYINT, 2)),
                       (CONVERT(TINYINT, 1), CONVERT(TINYINT, 3)),
                       (CONVERT(TINYINT, 2), CONVERT(TINYINT, 0)),
                       (CONVERT(TINYINT, 3), CONVERT(TINYINT, 4)),
                       (CONVERT(TINYINT, 3), CONVERT(TINYINT, 5)),
                       (CONVERT(TINYINT, 4), CONVERT(TINYINT, 2)),
                       (CONVERT(TINYINT, 5), CONVERT(TINYINT, 6)),
                       (CONVERT(TINYINT, 5), CONVERT(TINYINT, 7)),
                       (CONVERT(TINYINT, 6), CONVERT(TINYINT, 4)),
                       (CONVERT(TINYINT, 7), CONVERT(TINYINT, 6))
                   ) AS AllowedTransition(FromState, ToState)
                   WHERE AllowedTransition.FromState = d.DayMState
                     AND AllowedTransition.ToState = i.DayMState
               )
           )
    )
    BEGIN
        ;THROW 51026, N'انتقال حالة القيد غير مسموح به وفق دورة الاعتماد المعتمدة.', 1;
    END;

    /* A non-temporary journal header cannot be edited. First move a returned
       journal to state 0; then edit it and restart the workflow. */
    IF EXISTS
    (
        SELECT 1
        FROM deleted AS d
        INNER JOIN inserted AS i ON i.DayMID = d.DayMID
        WHERE d.DayMState <> 0
          AND i.DayMState <> 0
          AND
          (
              i.DayMDate <> d.DayMDate
              OR i.DayMNo <> d.DayMNo
              OR i.DayMCompany <> d.DayMCompany
              OR ISNULL(i.DayMDescription, N'') <> ISNULL(d.DayMDescription, N'')
          )
    )
        THROW 51027, N'لا يمكن تعديل بيانات رأس القيد إلا في الحالة 0.', 1;

    /* Archived journal: only state transition 7 -> 6, with header unchanged. */
    IF EXISTS
    (
        SELECT 1
        FROM deleted AS d
        INNER JOIN inserted AS i ON i.DayMID = d.DayMID
        WHERE d.DayMState = 7
          AND
          (
              i.DayMState <> 6
              OR i.DayMDate <> d.DayMDate
              OR i.DayMNo <> d.DayMNo
              OR i.DayMCompany <> d.DayMCompany
              OR ISNULL(i.DayMDescription, N'') <> ISNULL(d.DayMDescription, N'')
          )
    )
        THROW 51023, N'القيد المؤرشف غير قابل للتعديل؛ يسمح فقط بإرجاعه من الحالة 7 إلى الحالة 6 دون تغيير بياناته الأساسية.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS m
        CROSS APPLY
        (
            SELECT COUNT_BIG(*) AS LineCount,
                   COALESCE(SUM(d.DayDDeb), CONVERT(DECIMAL(38,3), 0)) AS DebitTotal,
                   COALESCE(SUM(d.DayDCrd), CONVERT(DECIMAL(38,3), 0)) AS CreditTotal
            FROM dbo.Acc_DayDetails AS d
            WHERE d.DayDMID = m.DayMID
        ) AS totals
        WHERE m.DayMState <> 0
          AND (totals.LineCount = 0 OR totals.DebitTotal <> totals.CreditTotal)
    )
        THROW 51006, N'يجب أن يكون القيد موزونًا وله تفاصيل قبل نقله إلى حالة غير مؤقتة.', 1;
END;
GO

/*
  MADAR ERP - HR extension package
  Target: MADARERPDataBase, SQL Server 2025 (compatibility 170)
  Based on the HR schema snapshot MADARDATABASE16.sql.
  Additive/idempotent: does not drop tables, columns, data, or existing procedures.
  Company scope is enforced in keys, predicates, and foreign keys where possible.
  Variable statutory/payroll rules are configuration data; no tax/social/end-of-service
  rates or multipliers are hard-coded.
*/
USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
SET XACT_ABORT ON;
GO
IF OBJECT_ID(N'dbo.Emp_Employee',N'U') IS NULL OR OBJECT_ID(N'dbo.Emp_DocumentTypes',N'U') IS NULL
 OR OBJECT_ID(N'dbo.Emp_Salary',N'U') IS NULL OR OBJECT_ID(N'dbo.Emp_Position',N'U') IS NULL
 OR OBJECT_ID(N'dbo.Emp_Nationality',N'U') IS NULL OR OBJECT_ID(N'dbo.Emp_AttendanceDevices',N'U') IS NULL
 OR OBJECT_ID(N'dbo.Emp_AttendanceDeviceSyncLog',N'U') IS NULL OR OBJECT_ID(N'dbo.Emp_AttendanceTransactions',N'U') IS NULL
 OR OBJECT_ID(N'dbo.Mng_Company',N'U') IS NULL OR OBJECT_ID(N'dbo.Mng_User',N'U') IS NULL
 OR OBJECT_ID(N'dbo.Acc_Currency',N'U') IS NULL OR OBJECT_ID(N'dbo.Acc_Account',N'U') IS NULL
 OR OBJECT_ID(N'dbo.Acc_CostCenter',N'U') IS NULL OR TYPE_ID(N'dbo.Acc_DayLineType') IS NULL
 OR OBJECT_ID(N'dbo.Acc_SaveDayVoucher',N'P') IS NULL
 OR COL_LENGTH(N'dbo.Emp_DocumentTypes',N'DocTypeID') IS NULL
 OR COL_LENGTH(N'dbo.Emp_Position',N'PosCmp') IS NULL OR COL_LENGTH(N'dbo.Emp_Position',N'PosID') IS NULL
 OR COL_LENGTH(N'dbo.Emp_Salary',N'EmpCompany') IS NULL
 THROW 54001,N'السكريبت يستهدف مخطط MADARDATABASE16 (16 نوفمبر 2026). ملف MADAR_Databaser.sql الأقدم غير متوافق مباشرة؛ بعض الجداول أو أسماء الأعمدة المرجعية مختلفة.',1;
GO

/* ================================================================
   1. EMPLOYEE FILE EXTENSIONS
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_EmployeeDocuments', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeeDocuments
 (
  DocumentID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeeDocuments PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, DocumentTypeID BIGINT NOT NULL,
  DocumentNo NVARCHAR(100) NULL, IssueDate DATE NULL, ExpiryDate DATE NULL,
  Issuer NVARCHAR(255) NULL, FilePath NVARCHAR(1000) NULL, FileName NVARCHAR(260) NULL,
  MimeType NVARCHAR(150) NULL, FileSize BIGINT NULL, Notes NVARCHAR(1000) NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeeDocuments_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeeDocuments_Created DEFAULT(SYSDATETIME()),
  CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_EmployeeDocuments_Cmp_ID UNIQUE(CmpID,DocumentID),
  CONSTRAINT CK_Emp_EmployeeDocuments_Dates CHECK(ExpiryDate IS NULL OR IssueDate IS NULL OR ExpiryDate>=IssueDate),
  CONSTRAINT CK_Emp_EmployeeDocuments_Size CHECK(FileSize IS NULL OR FileSize>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_EmployeeContacts', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeeContacts
 (
  ContactID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeeContacts PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, ContactType TINYINT NOT NULL,
  ContactName NVARCHAR(200) NOT NULL, Relationship NVARCHAR(100) NULL,
  Phone NVARCHAR(40) NULL, Email NVARCHAR(254) NULL, IsEmergency BIT NOT NULL CONSTRAINT DF_Emp_EmployeeContacts_Emergency DEFAULT(0),
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeeContacts_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeeContacts_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_EmployeeContacts_Cmp_ID UNIQUE(CmpID,ContactID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_EmployeeAddresses', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeeAddresses
 (
  AddressID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeeAddresses PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, AddressType TINYINT NOT NULL,
  Country NVARCHAR(100) NULL, City NVARCHAR(100) NULL, District NVARCHAR(150) NULL,
  AddressText NVARCHAR(500) NOT NULL, PostalCode NVARCHAR(30) NULL,
  StartDate DATE NULL, EndDate DATE NULL, IsPrimary BIT NOT NULL CONSTRAINT DF_Emp_EmployeeAddresses_Primary DEFAULT(0),
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeeAddresses_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeeAddresses_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_EmployeeAddresses_Cmp_ID UNIQUE(CmpID,AddressID),
  CONSTRAINT CK_Emp_EmployeeAddresses_Dates CHECK(EndDate IS NULL OR StartDate IS NULL OR EndDate>=StartDate)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_EmployeeExperience', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeeExperience
 (
  ExperienceID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeeExperience PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, Employer NVARCHAR(255) NOT NULL,
  JobTitle NVARCHAR(255) NULL, StartDate DATE NOT NULL, EndDate DATE NULL,
  Description NVARCHAR(1000) NULL, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeeExperience_Created DEFAULT(SYSDATETIME()),
  CreatedBy BIGINT NOT NULL, RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeeExperience_State DEFAULT(0),
  CONSTRAINT UQ_Emp_EmployeeExperience_Cmp_ID UNIQUE(CmpID,ExperienceID),
  CONSTRAINT CK_Emp_EmployeeExperience_Dates CHECK(EndDate IS NULL OR EndDate>=StartDate)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_EmployeeSkills', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeeSkills
 (
  SkillID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeeSkills PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, SkillName NVARCHAR(200) NOT NULL,
  SkillLevel TINYINT NULL, YearsExperience DECIMAL(5,2) NULL, Notes NVARCHAR(500) NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeeSkills_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeeSkills_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_EmployeeSkills_Cmp_ID UNIQUE(CmpID,SkillID),
  CONSTRAINT CK_Emp_EmployeeSkills_Level CHECK(SkillLevel IS NULL OR SkillLevel BETWEEN 1 AND 5),
  CONSTRAINT CK_Emp_EmployeeSkills_Years CHECK(YearsExperience IS NULL OR YearsExperience>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_ServiceHistory', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_ServiceHistory
 (
  ServiceID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_ServiceHistory PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, EffectiveDate DATE NOT NULL,
  EventType TINYINT NOT NULL, OldPositionID BIGINT NULL, NewPositionID BIGINT NULL,
  OldDepartmentID BIGINT NULL, NewDepartmentID BIGINT NULL, OldSalary DECIMAL(15,3) NULL,
  NewSalary DECIMAL(15,3) NULL, CurrencyID BIGINT NULL, ReferenceNo NVARCHAR(100) NULL,
  Reason NVARCHAR(1000) NULL, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_ServiceHistory_Created DEFAULT(SYSDATETIME()),
  CreatedBy BIGINT NOT NULL, RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_ServiceHistory_State DEFAULT(0),
  CONSTRAINT UQ_Emp_ServiceHistory_Cmp_ID UNIQUE(CmpID,ServiceID)
 );
END;
GO

/* ================================================================
   2. RECRUITMENT
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_Candidates', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_Candidates
 (
  CandidateID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_Candidates PRIMARY KEY,
  CmpID INT NOT NULL, CandidateNo NVARCHAR(40) NULL, FullName NVARCHAR(200) NOT NULL,
  Phone NVARCHAR(40) NULL, Email NVARCHAR(254) NULL, NationalityID BIGINT NULL,
  BirthDate DATE NULL, SourceName NVARCHAR(150) NULL, CVPath NVARCHAR(1000) NULL,
  Notes NVARCHAR(1000) NULL, CandidateState TINYINT NOT NULL CONSTRAINT DF_Emp_Candidates_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_Candidates_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_Candidates_Cmp_ID UNIQUE(CmpID,CandidateID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_JobApplications', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_JobApplications
 (
  ApplicationID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_JobApplications PRIMARY KEY,
  CmpID INT NOT NULL, CandidateID BIGINT NOT NULL, PositionID BIGINT NULL,
  AppliedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_JobApplications_Applied DEFAULT(SYSDATETIME()),
  InterviewAt DATETIME2(0) NULL, InterviewResult TINYINT NULL, OfferDate DATE NULL,
  OfferAmount DECIMAL(15,3) NULL, OfferCurrencyID BIGINT NULL, OfferExpiry DATE NULL,
  ApplicationState TINYINT NOT NULL CONSTRAINT DF_Emp_JobApplications_State DEFAULT(0),
  Notes NVARCHAR(1000) NULL, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_JobApplications_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_JobApplications_Cmp_ID UNIQUE(CmpID,ApplicationID),
  CONSTRAINT FK_Emp_JobApplications_Candidate FOREIGN KEY(CmpID,CandidateID) REFERENCES dbo.Emp_Candidates(CmpID,CandidateID),
  CONSTRAINT CK_Emp_JobApplications_Offer CHECK(OfferAmount IS NULL OR OfferAmount>=0)
 );
END;
GO

/* ================================================================
   3. LEAVE MANAGEMENT
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_LeaveTypes', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeaveTypes
 (
  LeaveTypeID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeaveTypes PRIMARY KEY,
  CmpID INT NOT NULL, LeaveTypeName NVARCHAR(150) NOT NULL, IsPaid BIT NOT NULL,
  RequiresDocument BIT NOT NULL CONSTRAINT DF_Emp_LeaveTypes_Doc DEFAULT(0),
  AllowHourly BIT NOT NULL CONSTRAINT DF_Emp_LeaveTypes_Hourly DEFAULT(0), BalanceUnit TINYINT NOT NULL CONSTRAINT DF_Emp_LeaveTypes_Unit DEFAULT(1),
  MaxCarryForward DECIMAL(9,2) NULL, RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_LeaveTypes_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeaveTypes_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_LeaveTypes_Cmp_ID UNIQUE(CmpID,LeaveTypeID),
  CONSTRAINT UQ_Emp_LeaveTypes_Name UNIQUE(CmpID,LeaveTypeName),
  CONSTRAINT CK_Emp_LeaveTypes_Unit CHECK(BalanceUnit IN(1,2)),
  CONSTRAINT CK_Emp_LeaveTypes_Carry CHECK(MaxCarryForward IS NULL OR MaxCarryForward>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LeavePolicies', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeavePolicies
 (
  PolicyID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeavePolicies PRIMARY KEY,
  CmpID INT NOT NULL, PolicyName NVARCHAR(150) NOT NULL, EffectiveFrom DATE NOT NULL,
  EffectiveTo DATE NULL, AccrualFrequency TINYINT NOT NULL, ProrationMethod TINYINT NOT NULL,
  AllowNegative BIT NOT NULL CONSTRAINT DF_Emp_LeavePolicies_Neg DEFAULT(0),
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_LeavePolicies_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeavePolicies_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_LeavePolicies_Cmp_ID UNIQUE(CmpID,PolicyID),
  CONSTRAINT CK_Emp_LeavePolicies_Dates CHECK(EffectiveTo IS NULL OR EffectiveTo>=EffectiveFrom)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LeavePolicyTypes', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeavePolicyTypes
 (
  PolicyTypeID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeavePolicyTypes PRIMARY KEY,
  CmpID INT NOT NULL, PolicyID BIGINT NOT NULL, LeaveTypeID BIGINT NOT NULL,
  AnnualEntitlement DECIMAL(9,2) NOT NULL, MaxBalance DECIMAL(9,2) NULL,
  MinimumServiceMonths INT NOT NULL CONSTRAINT DF_Emp_LeavePolicyTypes_Service DEFAULT(0),
  CarryForwardLimit DECIMAL(9,2) NULL, RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_LeavePolicyTypes_State DEFAULT(0),
  CONSTRAINT UQ_Emp_LeavePolicyTypes_Cmp_ID UNIQUE(CmpID,PolicyTypeID),
  CONSTRAINT UQ_Emp_LeavePolicyTypes_Policy_Type UNIQUE(CmpID,PolicyID,LeaveTypeID),
  CONSTRAINT FK_Emp_LeavePolicyTypes_Policy FOREIGN KEY(CmpID,PolicyID) REFERENCES dbo.Emp_LeavePolicies(CmpID,PolicyID),
  CONSTRAINT FK_Emp_LeavePolicyTypes_Type FOREIGN KEY(CmpID,LeaveTypeID) REFERENCES dbo.Emp_LeaveTypes(CmpID,LeaveTypeID),
  CONSTRAINT CK_Emp_LeavePolicyTypes_Amounts CHECK(AnnualEntitlement>=0 AND (MaxBalance IS NULL OR MaxBalance>=0) AND MinimumServiceMonths>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LeaveBalances', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeaveBalances
 (
  BalanceID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeaveBalances PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, LeaveTypeID BIGINT NOT NULL,
  BalanceYear SMALLINT NOT NULL, OpeningBalance DECIMAL(9,2) NOT NULL CONSTRAINT DF_Emp_LeaveBalances_Opening DEFAULT(0),
  Earned DECIMAL(9,2) NOT NULL CONSTRAINT DF_Emp_LeaveBalances_Earned DEFAULT(0),
  Used DECIMAL(9,2) NOT NULL CONSTRAINT DF_Emp_LeaveBalances_Used DEFAULT(0),
  Adjusted DECIMAL(9,2) NOT NULL CONSTRAINT DF_Emp_LeaveBalances_Adjusted DEFAULT(0),
  ClosingBalance AS (OpeningBalance+Earned-Used+Adjusted) PERSISTED,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_LeaveBalances_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeaveBalances_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_LeaveBalances_Cmp_ID UNIQUE(CmpID,BalanceID),
  CONSTRAINT UQ_Emp_LeaveBalances_EmployeeYearType UNIQUE(CmpID,EmployeeID,LeaveTypeID,BalanceYear),
  CONSTRAINT FK_Emp_LeaveBalances_Type FOREIGN KEY(CmpID,LeaveTypeID) REFERENCES dbo.Emp_LeaveTypes(CmpID,LeaveTypeID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LeaveBalanceTransactions', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeaveBalanceTransactions
 (
  TransactionID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeaveBalanceTransactions PRIMARY KEY,
  CmpID INT NOT NULL, BalanceID BIGINT NOT NULL, TransactionDate DATE NOT NULL,
  TransactionType TINYINT NOT NULL, Quantity DECIMAL(9,2) NOT NULL,
  SourceType TINYINT NULL, SourceID BIGINT NULL, Description NVARCHAR(500) NULL,
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeaveBalanceTransactions_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT FK_Emp_LeaveBalanceTransactions_Balance FOREIGN KEY(CmpID,BalanceID) REFERENCES dbo.Emp_LeaveBalances(CmpID,BalanceID),
  CONSTRAINT CK_Emp_LeaveBalanceTransactions_Quantity CHECK(Quantity>0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LeaveRequests', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeaveRequests
 (
  RequestID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeaveRequests PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, LeaveTypeID BIGINT NOT NULL,
  StartAt DATETIME2(0) NOT NULL, EndAt DATETIME2(0) NOT NULL, Quantity DECIMAL(9,2) NOT NULL,
  IsHourly BIT NOT NULL CONSTRAINT DF_Emp_LeaveRequests_Hourly DEFAULT(0), Reason NVARCHAR(1000) NULL,
  AttachmentPath NVARCHAR(1000) NULL, RequestState TINYINT NOT NULL CONSTRAINT DF_Emp_LeaveRequests_State DEFAULT(0),
  SubmittedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeaveRequests_Submitted DEFAULT(SYSDATETIME()),
  CreatedBy BIGINT NOT NULL, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeaveRequests_Created DEFAULT(SYSDATETIME()),
  CONSTRAINT UQ_Emp_LeaveRequests_Cmp_ID UNIQUE(CmpID,RequestID),
  CONSTRAINT FK_Emp_LeaveRequests_Type FOREIGN KEY(CmpID,LeaveTypeID) REFERENCES dbo.Emp_LeaveTypes(CmpID,LeaveTypeID),
  CONSTRAINT CK_Emp_LeaveRequests_Dates CHECK(EndAt>StartAt AND Quantity>0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LeaveApprovals', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LeaveApprovals
 (
  ApprovalID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LeaveApprovals PRIMARY KEY,
  CmpID INT NOT NULL, RequestID BIGINT NOT NULL, StepNo SMALLINT NOT NULL,
  ApproverID BIGINT NOT NULL, Decision TINYINT NOT NULL, DecisionAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_LeaveApprovals_DecisionAt DEFAULT(SYSDATETIME()),
  Comments NVARCHAR(500) NULL,
  CONSTRAINT FK_Emp_LeaveApprovals_Request FOREIGN KEY(CmpID,RequestID) REFERENCES dbo.Emp_LeaveRequests(CmpID,RequestID),
  CONSTRAINT UQ_Emp_LeaveApprovals_Step UNIQUE(CmpID,RequestID,StepNo)
 );
END;
GO

IF OBJECT_ID(N'dbo.Emp_EmployeeLeavePolicies',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeeLeavePolicies
 (
  EmployeePolicyID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeeLeavePolicies PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, PolicyID BIGINT NOT NULL,
  EffectiveFrom DATE NOT NULL, EffectiveTo DATE NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeeLeavePolicies_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeeLeavePolicies_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_EmployeeLeavePolicies_Cmp_ID UNIQUE(CmpID,EmployeePolicyID),
  CONSTRAINT FK_Emp_EmployeeLeavePolicies_Policy FOREIGN KEY(CmpID,PolicyID) REFERENCES dbo.Emp_LeavePolicies(CmpID,PolicyID),
  CONSTRAINT CK_Emp_EmployeeLeavePolicies_Dates CHECK(EffectiveTo IS NULL OR EffectiveTo>=EffectiveFrom)
 );
END;
GO
/* ================================================================
   4. PAYROLL CONFIGURATION AND RUNS
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_PayComponents', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PayComponents
 (
  ComponentID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PayComponents PRIMARY KEY,
  CmpID INT NOT NULL, ComponentCode NVARCHAR(30) NOT NULL, ComponentName NVARCHAR(150) NOT NULL,
  ComponentKind TINYINT NOT NULL, CalculationMethod TINYINT NOT NULL,
  IsTaxable BIT NOT NULL CONSTRAINT DF_Emp_PayComponents_Tax DEFAULT(0),
  IsInsurable BIT NOT NULL CONSTRAINT DF_Emp_PayComponents_Ins DEFAULT(0),
  IsRecurring BIT NOT NULL CONSTRAINT DF_Emp_PayComponents_Recurring DEFAULT(1),
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_PayComponents_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PayComponents_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_PayComponents_Cmp_ID UNIQUE(CmpID,ComponentID),
  CONSTRAINT UQ_Emp_PayComponents_Code UNIQUE(CmpID,ComponentCode),
  CONSTRAINT CK_Emp_PayComponents_Kind CHECK(ComponentKind IN(1,2)),
  CONSTRAINT CK_Emp_PayComponents_Method CHECK(CalculationMethod IN(1,2))
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_PayPolicies', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PayPolicies
 (
  PayPolicyID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PayPolicies PRIMARY KEY,
  CmpID INT NOT NULL, PolicyName NVARCHAR(150) NOT NULL, EffectiveFrom DATE NOT NULL,
  EffectiveTo DATE NULL, StandardMonthlyHours DECIMAL(9,2) NULL,
  RoundingScale TINYINT NOT NULL CONSTRAINT DF_Emp_PayPolicies_Rounding DEFAULT(3),
  CurrencyID BIGINT NULL, RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_PayPolicies_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PayPolicies_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_PayPolicies_Cmp_ID UNIQUE(CmpID,PayPolicyID),
  CONSTRAINT CK_Emp_PayPolicies_Dates CHECK(EffectiveTo IS NULL OR EffectiveTo>=EffectiveFrom),
  CONSTRAINT CK_Emp_PayPolicies_Hours CHECK(StandardMonthlyHours IS NULL OR StandardMonthlyHours>0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_EmployeePayComponents', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_EmployeePayComponents
 (
  EmployeeComponentID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_EmployeePayComponents PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, ComponentID BIGINT NOT NULL,
  Amount DECIMAL(15,3) NOT NULL, StartDate DATE NOT NULL, EndDate DATE NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_EmployeePayComponents_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_EmployeePayComponents_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_EmployeePayComponents_Cmp_ID UNIQUE(CmpID,EmployeeComponentID),
  CONSTRAINT FK_Emp_EmployeePayComponents_Component FOREIGN KEY(CmpID,ComponentID) REFERENCES dbo.Emp_PayComponents(CmpID,ComponentID),
  CONSTRAINT CK_Emp_EmployeePayComponents_Dates CHECK(EndDate IS NULL OR EndDate>=StartDate),
  CONSTRAINT CK_Emp_EmployeePayComponents_Amount CHECK(Amount>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_PayPeriods', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PayPeriods
 (
  PeriodID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PayPeriods PRIMARY KEY,
  CmpID INT NOT NULL, PeriodName NVARCHAR(100) NOT NULL, DateFrom DATE NOT NULL, DateTo DATE NOT NULL,
  PeriodState TINYINT NOT NULL CONSTRAINT DF_Emp_PayPeriods_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PayPeriods_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_PayPeriods_Cmp_ID UNIQUE(CmpID,PeriodID),
  CONSTRAINT UQ_Emp_PayPeriods_Dates UNIQUE(CmpID,DateFrom,DateTo),
  CONSTRAINT CK_Emp_PayPeriods_Dates CHECK(DateTo>=DateFrom)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_PayRuns', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PayRuns
 (
  PayRunID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PayRuns PRIMARY KEY,
  CmpID INT NOT NULL, PeriodID BIGINT NOT NULL, RunNo INT NOT NULL, CurrencyID BIGINT NOT NULL,
  RunState TINYINT NOT NULL CONSTRAINT DF_Emp_PayRuns_State DEFAULT(0),
  GrossTotal DECIMAL(19,3) NOT NULL CONSTRAINT DF_Emp_PayRuns_Gross DEFAULT(0), DeductionTotal DECIMAL(19,3) NOT NULL CONSTRAINT DF_Emp_PayRuns_Ded DEFAULT(0),
  NetTotal DECIMAL(19,3) NOT NULL CONSTRAINT DF_Emp_PayRuns_Net DEFAULT(0),
  CalculatedAt DATETIME2(0) NULL, CalculatedBy BIGINT NULL, ApprovedAt DATETIME2(0) NULL, ApprovedBy BIGINT NULL,
  ClosedAt DATETIME2(0) NULL, ClosedBy BIGINT NULL, VoucherID BIGINT NULL,
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PayRuns_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_PayRuns_Cmp_ID UNIQUE(CmpID,PayRunID),
  CONSTRAINT UQ_Emp_PayRuns_PeriodRun UNIQUE(CmpID,PeriodID,RunNo),
  CONSTRAINT FK_Emp_PayRuns_Period FOREIGN KEY(CmpID,PeriodID) REFERENCES dbo.Emp_PayPeriods(CmpID,PeriodID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_PayrollDetails', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PayrollDetails
 (
  PayrollDetailID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PayrollDetails PRIMARY KEY,
  CmpID INT NOT NULL, PayRunID BIGINT NOT NULL, EmployeeID BIGINT NOT NULL,
  ComponentID BIGINT NULL, LineKind TINYINT NOT NULL, Description NVARCHAR(250) NOT NULL,
  Quantity DECIMAL(15,4) NULL, Rate DECIMAL(15,6) NULL, Amount DECIMAL(19,3) NOT NULL,
  SourceType TINYINT NULL, SourceID BIGINT NULL,
  CONSTRAINT FK_Emp_PayrollDetails_Run FOREIGN KEY(CmpID,PayRunID) REFERENCES dbo.Emp_PayRuns(CmpID,PayRunID),
  CONSTRAINT FK_Emp_PayrollDetails_Component FOREIGN KEY(CmpID,ComponentID) REFERENCES dbo.Emp_PayComponents(CmpID,ComponentID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_PayrollAccountMappings', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PayrollAccountMappings
 (
  MappingID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PayrollAccountMappings PRIMARY KEY,
  CmpID INT NOT NULL, ComponentID BIGINT NULL, AccountID BIGINT NOT NULL,
  CostCenterID BIGINT NULL, DebitCredit TINYINT NOT NULL, EffectiveFrom DATE NOT NULL, EffectiveTo DATE NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_PayrollAccountMappings_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PayrollAccountMappings_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT FK_Emp_PayrollAccountMappings_Component FOREIGN KEY(CmpID,ComponentID) REFERENCES dbo.Emp_PayComponents(CmpID,ComponentID),
  CONSTRAINT CK_Emp_PayrollAccountMappings_DC CHECK(DebitCredit IN(1,2)),
  CONSTRAINT CK_Emp_PayrollAccountMappings_Dates CHECK(EffectiveTo IS NULL OR EffectiveTo>=EffectiveFrom)
 );
END;
GO

/* ================================================================
   5. OVERTIME, DISCIPLINE, LOANS
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_OvertimeRequests', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_OvertimeRequests
 (
  OvertimeID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_OvertimeRequests PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, WorkDate DATE NOT NULL,
  StartAt DATETIME2(0) NOT NULL, EndAt DATETIME2(0) NOT NULL, Hours DECIMAL(8,2) NOT NULL,
  Reason NVARCHAR(500) NOT NULL, Multiplier DECIMAL(8,4) NULL,
  RequestState TINYINT NOT NULL CONSTRAINT DF_Emp_OvertimeRequests_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_OvertimeRequests_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  ApprovedAt DATETIME2(0) NULL, ApprovedBy BIGINT NULL,
  CONSTRAINT UQ_Emp_OvertimeRequests_Cmp_ID UNIQUE(CmpID,OvertimeID),
  CONSTRAINT CK_Emp_OvertimeRequests_Hours CHECK(EndAt>StartAt AND Hours>0 AND (Multiplier IS NULL OR Multiplier>0))
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_RewardsPenalties', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_RewardsPenalties
 (
  ActionID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_RewardsPenalties PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, ActionType TINYINT NOT NULL,
  ActionDate DATE NOT NULL, Description NVARCHAR(1000) NOT NULL, Amount DECIMAL(15,3) NULL,
  CurrencyID BIGINT NULL, PayrollComponentID BIGINT NULL, ActionState TINYINT NOT NULL CONSTRAINT DF_Emp_RewardsPenalties_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_RewardsPenalties_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_RewardsPenalties_Cmp_ID UNIQUE(CmpID,ActionID),
  CONSTRAINT CK_Emp_RewardsPenalties_Type CHECK(ActionType IN(1,2)),
  CONSTRAINT CK_Emp_RewardsPenalties_Amount CHECK(Amount IS NULL OR Amount>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_Loans', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_Loans
 (
  LoanID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_Loans PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, LoanNo NVARCHAR(40) NULL,
  Principal DECIMAL(15,3) NOT NULL, CurrencyID BIGINT NOT NULL, StartDate DATE NOT NULL,
  InstallmentCount SMALLINT NOT NULL, InstallmentAmount DECIMAL(15,3) NOT NULL, InstallmentIntervalDays SMALLINT NOT NULL,
  InterestAmount DECIMAL(15,3) NOT NULL CONSTRAINT DF_Emp_Loans_Interest DEFAULT(0),
  LoanState TINYINT NOT NULL CONSTRAINT DF_Emp_Loans_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_Loans_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  ApprovedAt DATETIME2(0) NULL, ApprovedBy BIGINT NULL,
  CONSTRAINT UQ_Emp_Loans_Cmp_ID UNIQUE(CmpID,LoanID),
  CONSTRAINT CK_Emp_Loans_Amounts CHECK(Principal>0 AND InstallmentCount>0 AND InstallmentAmount>0 AND InstallmentIntervalDays>0 AND InterestAmount>=0)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_LoanInstallments', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_LoanInstallments
 (
  InstallmentID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_LoanInstallments PRIMARY KEY,
  CmpID INT NOT NULL, LoanID BIGINT NOT NULL, InstallmentNo SMALLINT NOT NULL,
  DueDate DATE NOT NULL, Amount DECIMAL(15,3) NOT NULL,
  PaidAmount DECIMAL(15,3) NOT NULL CONSTRAINT DF_Emp_LoanInstallments_Paid DEFAULT(0),
  PaidAt DATETIME2(0) NULL, InstallmentState TINYINT NOT NULL CONSTRAINT DF_Emp_LoanInstallments_State DEFAULT(0),
  CONSTRAINT FK_Emp_LoanInstallments_Loan FOREIGN KEY(CmpID,LoanID) REFERENCES dbo.Emp_Loans(CmpID,LoanID),
  CONSTRAINT UQ_Emp_LoanInstallments_No UNIQUE(CmpID,LoanID,InstallmentNo),
  CONSTRAINT CK_Emp_LoanInstallments_Amounts CHECK(Amount>0 AND PaidAmount>=0 AND PaidAmount<=Amount)
 );
END;
GO

/* ================================================================
   6. PERFORMANCE, TRAINING, TERMINATION
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_PerformanceCycles', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PerformanceCycles
 (
  CycleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PerformanceCycles PRIMARY KEY,
  CmpID INT NOT NULL, CycleName NVARCHAR(150) NOT NULL, DateFrom DATE NOT NULL, DateTo DATE NOT NULL,
  CycleState TINYINT NOT NULL CONSTRAINT DF_Emp_PerformanceCycles_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PerformanceCycles_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_PerformanceCycles_Cmp_ID UNIQUE(CmpID,CycleID),
  CONSTRAINT CK_Emp_PerformanceCycles_Dates CHECK(DateTo>=DateFrom)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_PerformanceReviews', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_PerformanceReviews
 (
  ReviewID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_PerformanceReviews PRIMARY KEY,
  CmpID INT NOT NULL, CycleID BIGINT NOT NULL, EmployeeID BIGINT NOT NULL,
  ReviewerID BIGINT NOT NULL, Score DECIMAL(7,2) NULL, ReviewText NVARCHAR(MAX) NULL,
  ReviewState TINYINT NOT NULL CONSTRAINT DF_Emp_PerformanceReviews_State DEFAULT(0),
  ReviewedAt DATETIME2(0) NULL, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_PerformanceReviews_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_PerformanceReviews_Cmp_ID UNIQUE(CmpID,ReviewID),
  CONSTRAINT FK_Emp_PerformanceReviews_Cycle FOREIGN KEY(CmpID,CycleID) REFERENCES dbo.Emp_PerformanceCycles(CmpID,CycleID),
  CONSTRAINT UQ_Emp_PerformanceReviews_Employee UNIQUE(CmpID,CycleID,EmployeeID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_TrainingCourses', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_TrainingCourses
 (
  CourseID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_TrainingCourses PRIMARY KEY,
  CmpID INT NOT NULL, CourseName NVARCHAR(200) NOT NULL, Provider NVARCHAR(200) NULL,
  CourseHours DECIMAL(8,2) NULL, Cost DECIMAL(15,3) NULL, CurrencyID BIGINT NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_TrainingCourses_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_TrainingCourses_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_TrainingCourses_Cmp_ID UNIQUE(CmpID,CourseID),
  CONSTRAINT CK_Emp_TrainingCourses_Amounts CHECK((CourseHours IS NULL OR CourseHours>=0) AND (Cost IS NULL OR Cost>=0))
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_TrainingRecords', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_TrainingRecords
 (
  TrainingRecordID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_TrainingRecords PRIMARY KEY,
  CmpID INT NOT NULL, CourseID BIGINT NOT NULL, EmployeeID BIGINT NOT NULL,
  DateFrom DATE NOT NULL, DateTo DATE NOT NULL, Result NVARCHAR(250) NULL,
  Score DECIMAL(7,2) NULL, CertificatePath NVARCHAR(1000) NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_TrainingRecords_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_TrainingRecords_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_TrainingRecords_Cmp_ID UNIQUE(CmpID,TrainingRecordID),
  CONSTRAINT FK_Emp_TrainingRecords_Course FOREIGN KEY(CmpID,CourseID) REFERENCES dbo.Emp_TrainingCourses(CmpID,CourseID),
  CONSTRAINT CK_Emp_TrainingRecords_Dates CHECK(DateTo>=DateFrom)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_Terminations', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_Terminations
 (
  TerminationID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_Terminations PRIMARY KEY,
  CmpID INT NOT NULL, EmployeeID BIGINT NOT NULL, NoticeDate DATE NOT NULL,
  LastWorkingDate DATE NOT NULL, TerminationReason TINYINT NOT NULL, ReasonText NVARCHAR(1000) NULL,
  TerminationState TINYINT NOT NULL CONSTRAINT DF_Emp_Terminations_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_Terminations_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  ApprovedAt DATETIME2(0) NULL, ApprovedBy BIGINT NULL,
  CONSTRAINT UQ_Emp_Terminations_Cmp_ID UNIQUE(CmpID,TerminationID),
  CONSTRAINT CK_Emp_Terminations_Dates CHECK(LastWorkingDate>=NoticeDate)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_ClearanceItems', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_ClearanceItems
 (
  ClearanceID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_ClearanceItems PRIMARY KEY,
  CmpID INT NOT NULL, TerminationID BIGINT NOT NULL, ItemName NVARCHAR(200) NOT NULL,
  ResponsibleUser BIGINT NULL, ItemState TINYINT NOT NULL CONSTRAINT DF_Emp_ClearanceItems_State DEFAULT(0),
  CompletedAt DATETIME2(0) NULL, Notes NVARCHAR(500) NULL,
  CONSTRAINT FK_Emp_ClearanceItems_Termination FOREIGN KEY(CmpID,TerminationID) REFERENCES dbo.Emp_Terminations(CmpID,TerminationID)
 );
END;
GO
IF OBJECT_ID(N'dbo.Emp_FinalSettlements', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_FinalSettlements
 (
  SettlementID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_FinalSettlements PRIMARY KEY,
  CmpID INT NOT NULL, TerminationID BIGINT NOT NULL, CurrencyID BIGINT NOT NULL,
  GrossEntitlements DECIMAL(19,3) NOT NULL CONSTRAINT DF_Emp_FinalSettlements_Gross DEFAULT(0),
  Deductions DECIMAL(19,3) NOT NULL CONSTRAINT DF_Emp_FinalSettlements_Ded DEFAULT(0),
  NetAmount AS (GrossEntitlements-Deductions) PERSISTED,
  CalculationDetails NVARCHAR(MAX) NULL, SettlementState TINYINT NOT NULL CONSTRAINT DF_Emp_FinalSettlements_State DEFAULT(0),
  CalculatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_FinalSettlements_Calc DEFAULT(SYSDATETIME()), CalculatedBy BIGINT NOT NULL,
  ApprovedAt DATETIME2(0) NULL, ApprovedBy BIGINT NULL,
  CONSTRAINT UQ_Emp_FinalSettlements_Termination UNIQUE(CmpID,TerminationID),
  CONSTRAINT FK_Emp_FinalSettlements_Termination FOREIGN KEY(CmpID,TerminationID) REFERENCES dbo.Emp_Terminations(CmpID,TerminationID),
  CONSTRAINT CK_Emp_FinalSettlements_Amounts CHECK(GrossEntitlements>=0 AND Deductions>=0)
 );
END;
GO

/* ================================================================
   7. DEVICE CONNECTOR CONFIGURATION
   ================================================================ */
IF OBJECT_ID(N'dbo.Emp_AttendanceConnectorConfigs', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_AttendanceConnectorConfigs
 (
  ConnectorID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_AttendanceConnectorConfigs PRIMARY KEY,
  CmpID INT NOT NULL, DeviceID BIGINT NULL, ConnectorName NVARCHAR(150) NOT NULL,
  ConnectorKind TINYINT NOT NULL, TransportKind TINYINT NOT NULL,
  Endpoint NVARCHAR(1000) NULL, Port INT NULL, CredentialReference NVARCHAR(500) NULL,
  PollIntervalSeconds INT NULL, TimeoutSeconds INT NOT NULL CONSTRAINT DF_Emp_AttendanceConnectorConfigs_Timeout DEFAULT(30),
  ConfigurationJson NVARCHAR(MAX) NULL, IsEnabled BIT NOT NULL CONSTRAINT DF_Emp_AttendanceConnectorConfigs_Enabled DEFAULT(1),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_AttendanceConnectorConfigs_Created DEFAULT(SYSDATETIME()), CreatedBy BIGINT NOT NULL,
  CONSTRAINT UQ_Emp_AttendanceConnectorConfigs_Cmp_ID UNIQUE(CmpID,ConnectorID),
  CONSTRAINT CK_Emp_AttendanceConnectorConfigs_Kind CHECK(ConnectorKind IN(1,2,3,4,5)),
  CONSTRAINT CK_Emp_AttendanceConnectorConfigs_Transport CHECK(TransportKind IN(1,2,3,4,5,6)),
  CONSTRAINT CK_Emp_AttendanceConnectorConfigs_Timeout CHECK(TimeoutSeconds BETWEEN 1 AND 3600),
  CONSTRAINT CK_Emp_AttendanceConnectorConfigs_Json CHECK(ConfigurationJson IS NULL OR ISJSON(ConfigurationJson)=1)
 );
END;
GO

/* Parent candidate keys required for company-safe foreign keys to legacy tables. */
IF OBJECT_ID(N'dbo.Emp_DocumentTypes',N'U') IS NOT NULL
 AND NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_DocumentTypes') AND name=N'UX_Emp_DocumentTypes_Cmp_ID')
 CREATE UNIQUE INDEX UX_Emp_DocumentTypes_Cmp_ID ON dbo.Emp_DocumentTypes(DocTypeCmp,DocTypeID);
IF OBJECT_ID(N'dbo.Acc_Account',N'U') IS NOT NULL
 AND NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Acc_Account') AND name=N'UX_Acc_Account_Company_ID')
 CREATE UNIQUE INDEX UX_Acc_Account_Company_ID ON dbo.Acc_Account(AccCompany,AccID);
IF OBJECT_ID(N'dbo.Acc_CostCenter',N'U') IS NOT NULL
 AND NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Acc_CostCenter') AND name=N'UX_Acc_CostCenter_Company_ID')
 CREATE UNIQUE INDEX UX_Acc_CostCenter_Company_ID ON dbo.Acc_CostCenter(CsCCompany,CsCID);
GO
/* Attendance batch contract: normalized events from pull, push, file, API, SDK, or bridge adapters. */
IF TYPE_ID(N'dbo.Emp_AttendanceBatchType') IS NULL
 EXEC(N'CREATE TYPE dbo.Emp_AttendanceBatchType AS TABLE
 (
  EmployeeID BIGINT NOT NULL,
  PunchAt DATETIME2(0) NOT NULL,
  PunchType TINYINT NOT NULL,
  DeviceRecordID NVARCHAR(100) NULL
 );');
GO
IF OBJECT_ID(N'dbo.Emp_AttendanceTransactions',N'U') IS NOT NULL
BEGIN
 IF EXISTS(SELECT AttCmp,AttDedupHash FROM dbo.Emp_AttendanceTransactions WHERE AttDedupHash IS NOT NULL GROUP BY AttCmp,AttDedupHash HAVING COUNT(*)>1)
  THROW 54090,N'توجد بصمات تكرار مكررة مسبقاً في Emp_AttendanceTransactions؛ عالجها قبل تفعيل قيد منع التكرار.',1;
 IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_AttendanceTransactions') AND name=N'UX_Emp_AttendanceTransactions_Dedup')
  CREATE UNIQUE INDEX UX_Emp_AttendanceTransactions_Dedup ON dbo.Emp_AttendanceTransactions(AttCmp,AttDedupHash) WHERE AttDedupHash IS NOT NULL;
END;
GO
/* ================================================================
   8. COMMON COMPANY/EMPLOYEE FOREIGN KEYS (only when prerequisites exist)
   ================================================================ */
DECLARE @FkSql NVARCHAR(MAX)=N'';
DECLARE @Fk TABLE(ConstraintName SYSNAME, TableName SYSNAME, Definition NVARCHAR(MAX));
INSERT @Fk VALUES
(N'FK_Emp_EmployeeDocuments_Employee',N'Emp_EmployeeDocuments',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_EmployeeDocuments_User',N'Emp_EmployeeDocuments',N'FOREIGN KEY(CreatedBy) REFERENCES dbo.Mng_User(UsrID)'),
(N'FK_Emp_EmployeeDocuments_Type',N'Emp_EmployeeDocuments',N'FOREIGN KEY(CmpID,DocumentTypeID) REFERENCES dbo.Emp_DocumentTypes(DocTypeCmp,DocTypeID)'),
(N'FK_Emp_EmployeeContacts_Employee',N'Emp_EmployeeContacts',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_EmployeeAddresses_Employee',N'Emp_EmployeeAddresses',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_EmployeeExperience_Employee',N'Emp_EmployeeExperience',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_EmployeeSkills_Employee',N'Emp_EmployeeSkills',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_ServiceHistory_Employee',N'Emp_ServiceHistory',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_EmployeeLeavePolicies_Employee',N'Emp_EmployeeLeavePolicies',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_LeaveBalances_Employee',N'Emp_LeaveBalances',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_LeaveRequests_Employee',N'Emp_LeaveRequests',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_EmployeePayComponents_Employee',N'Emp_EmployeePayComponents',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_OvertimeRequests_Employee',N'Emp_OvertimeRequests',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_RewardsPenalties_Employee',N'Emp_RewardsPenalties',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_Loans_Employee',N'Emp_Loans',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_PerformanceReviews_Employee',N'Emp_PerformanceReviews',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_TrainingRecords_Employee',N'Emp_TrainingRecords',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_Terminations_Employee',N'Emp_Terminations',N'FOREIGN KEY(CmpID,EmployeeID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID)'),
(N'FK_Emp_PayrollAccountMappings_Account',N'Emp_PayrollAccountMappings',N'FOREIGN KEY(CmpID,AccountID) REFERENCES dbo.Acc_Account(AccCompany,AccID)'),
(N'FK_Emp_PayrollAccountMappings_CostCenter',N'Emp_PayrollAccountMappings',N'FOREIGN KEY(CmpID,CostCenterID) REFERENCES dbo.Acc_CostCenter(CsCCompany,CsCID)'),
(N'FK_Emp_Loans_Currency',N'Emp_Loans',N'FOREIGN KEY(CmpID,CurrencyID) REFERENCES dbo.Acc_Currency(CurCmp,CurID)'),
(N'FK_Emp_TrainingCourses_Currency',N'Emp_TrainingCourses',N'FOREIGN KEY(CmpID,CurrencyID) REFERENCES dbo.Acc_Currency(CurCmp,CurID)'),
(N'FK_Emp_FinalSettlements_Currency',N'Emp_FinalSettlements',N'FOREIGN KEY(CmpID,CurrencyID) REFERENCES dbo.Acc_Currency(CurCmp,CurID)'),
(N'FK_Emp_PayPolicies_Currency',N'Emp_PayPolicies',N'FOREIGN KEY(CmpID,CurrencyID) REFERENCES dbo.Acc_Currency(CurCmp,CurID)'),
(N'FK_Emp_PayRuns_Currency',N'Emp_PayRuns',N'FOREIGN KEY(CmpID,CurrencyID) REFERENCES dbo.Acc_Currency(CurCmp,CurID)'),
(N'FK_Emp_RewardsPenalties_Currency',N'Emp_RewardsPenalties',N'FOREIGN KEY(CmpID,CurrencyID) REFERENCES dbo.Acc_Currency(CurCmp,CurID)'),
(N'FK_Emp_AttendanceConnectorConfigs_Device',N'Emp_AttendanceConnectorConfigs',N'FOREIGN KEY(CmpID,DeviceID) REFERENCES dbo.Emp_AttendanceDevices(DeviceCmp,DeviceID)');
DECLARE fkcur CURSOR LOCAL FAST_FORWARD FOR SELECT ConstraintName,TableName,Definition FROM @Fk;
DECLARE @FkName SYSNAME,@FkTable SYSNAME,@FkDef NVARCHAR(MAX);
OPEN fkcur; FETCH NEXT FROM fkcur INTO @FkName,@FkTable,@FkDef;
WHILE @@FETCH_STATUS=0
BEGIN
 IF OBJECT_ID(N'dbo.'+@FkTable,N'U') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE name=@FkName AND parent_object_id=OBJECT_ID(N'dbo.'+@FkTable))
 BEGIN
  SET @FkSql=N'ALTER TABLE dbo.'+QUOTENAME(@FkTable)+N' WITH CHECK ADD CONSTRAINT '+QUOTENAME(@FkName)+N' '+@FkDef+N'; ALTER TABLE dbo.'+QUOTENAME(@FkTable)+N' CHECK CONSTRAINT '+QUOTENAME(@FkName)+N';';
  EXEC sys.sp_executesql @FkSql;
 END;
 FETCH NEXT FROM fkcur INTO @FkName,@FkTable,@FkDef;
END;
CLOSE fkcur; DEALLOCATE fkcur;
GO

/* ================================================================
   9. INDEXES
   ================================================================ */
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_Candidates') AND name=N'UX_Emp_Candidates_Cmp_No')
 CREATE UNIQUE INDEX UX_Emp_Candidates_Cmp_No ON dbo.Emp_Candidates(CmpID,CandidateNo) WHERE CandidateNo IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_Loans') AND name=N'UX_Emp_Loans_Cmp_No')
 CREATE UNIQUE INDEX UX_Emp_Loans_Cmp_No ON dbo.Emp_Loans(CmpID,LoanNo) WHERE LoanNo IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_EmployeeDocuments') AND name=N'IX_Emp_EmployeeDocuments_Employee_Expiry')
 CREATE INDEX IX_Emp_EmployeeDocuments_Employee_Expiry ON dbo.Emp_EmployeeDocuments(CmpID,EmployeeID,ExpiryDate) INCLUDE(DocumentTypeID,RecordState);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_LeaveRequests') AND name=N'IX_Emp_LeaveRequests_Employee_Dates')
 CREATE INDEX IX_Emp_LeaveRequests_Employee_Dates ON dbo.Emp_LeaveRequests(CmpID,EmployeeID,StartAt,EndAt) INCLUDE(LeaveTypeID,Quantity,RequestState);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_LeaveBalances') AND name=N'IX_Emp_LeaveBalances_Employee_Year')
 CREATE INDEX IX_Emp_LeaveBalances_Employee_Year ON dbo.Emp_LeaveBalances(CmpID,EmployeeID,BalanceYear) INCLUDE(LeaveTypeID,ClosingBalance);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_PayRuns') AND name=N'IX_Emp_PayRuns_State')
 CREATE INDEX IX_Emp_PayRuns_State ON dbo.Emp_PayRuns(CmpID,RunState,PeriodID);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_PayrollDetails') AND name=N'IX_Emp_PayrollDetails_Run_Employee')
 CREATE INDEX IX_Emp_PayrollDetails_Run_Employee ON dbo.Emp_PayrollDetails(CmpID,PayRunID,EmployeeID);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_LoanInstallments') AND name=N'IX_Emp_LoanInstallments_Due')
 CREATE INDEX IX_Emp_LoanInstallments_Due ON dbo.Emp_LoanInstallments(CmpID,DueDate,InstallmentState) INCLUDE(LoanID,Amount,PaidAmount);
GO

/* ================================================================
   10. VALIDATION HELPERS
   ================================================================ */
CREATE OR ALTER PROCEDURE dbo.Emp_HRValidateActor
 @CmpID INT, @UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON;
 IF ISNULL(@CmpID,0)<=0 OR NOT EXISTS(SELECT 1 FROM dbo.Mng_Company WHERE CmpID=@CmpID)
  THROW 54100,N'الشركة غير صحيحة أو غير موجودة.',1;
 IF ISNULL(@UserID,0)<=0 OR NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@UserID)
  THROW 54101,N'المستخدم غير صحيح أو غير موجود.',1;
END;
GO

/* ================================================================
   11. EMPLOYEE DOCUMENTS - SAVE/SELECT/STATE
   ================================================================ */
CREATE OR ALTER PROCEDURE dbo.Emp_SaveEmployeeDocument
 @CmpID INT,@DocumentID BIGINT=0,@EmployeeID BIGINT,@DocumentTypeID BIGINT,
 @DocumentNo NVARCHAR(100)=NULL,@IssueDate DATE=NULL,@ExpiryDate DATE=NULL,
 @Issuer NVARCHAR(255)=NULL,@FilePath NVARCHAR(1000)=NULL,@FileName NVARCHAR(260)=NULL,
 @MimeType NVARCHAR(150)=NULL,@FileSize BIGINT=NULL,@Notes NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54102,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_DocumentTypes WHERE DocTypeCmp=@CmpID AND DocTypeID=@DocumentTypeID AND DocTypeState=0) THROW 54103,N'نوع المستند غير صالح أو غير نشط.',1;
 IF @ExpiryDate IS NOT NULL AND @IssueDate IS NOT NULL AND @ExpiryDate<@IssueDate THROW 54104,N'تاريخ الانتهاء يسبق تاريخ الإصدار.',1;
 BEGIN TRAN;
 IF ISNULL(@DocumentID,0)=0
 BEGIN
  INSERT dbo.Emp_EmployeeDocuments(CmpID,EmployeeID,DocumentTypeID,DocumentNo,IssueDate,ExpiryDate,Issuer,FilePath,FileName,MimeType,FileSize,Notes,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@DocumentTypeID,@DocumentNo,@IssueDate,@ExpiryDate,@Issuer,@FilePath,@FileName,@MimeType,@FileSize,@Notes,@UserID);
  SET @DocumentID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_EmployeeDocuments WITH(UPDLOCK,HOLDLOCK)
   SET DocumentTypeID=@DocumentTypeID,DocumentNo=@DocumentNo,IssueDate=@IssueDate,ExpiryDate=@ExpiryDate,Issuer=@Issuer,
       FilePath=@FilePath,FileName=@FileName,MimeType=@MimeType,FileSize=@FileSize,Notes=@Notes
   WHERE CmpID=@CmpID AND DocumentID=@DocumentID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54105,N'المستند غير موجود أو غير قابل للتعديل.',1;
 END;
 COMMIT;
 SELECT @DocumentID AS DocumentID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SelectEmployeeDocuments
 @CmpID INT,@EmployeeID BIGINT=NULL,@DocumentID BIGINT=NULL,@State TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT d.*,t.DocTypeName FROM dbo.Emp_EmployeeDocuments d
 JOIN dbo.Emp_DocumentTypes t ON t.DocTypeCmp=d.CmpID AND t.DocTypeID=d.DocumentTypeID
 WHERE d.CmpID=@CmpID AND (@EmployeeID IS NULL OR d.EmployeeID=@EmployeeID)
 AND (@DocumentID IS NULL OR d.DocumentID=@DocumentID) AND (@State IS NULL OR d.RecordState=@State)
 ORDER BY d.ExpiryDate,d.DocumentID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_UpdateStateEmployeeDocument
 @CmpID INT,@DocumentID BIGINT,@State TINYINT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @State NOT IN(0,1,2) THROW 54106,N'حالة المستند غير صحيحة.',1;
 UPDATE dbo.Emp_EmployeeDocuments SET RecordState=@State WHERE CmpID=@CmpID AND DocumentID=@DocumentID AND RecordState<>2;
 IF @@ROWCOUNT=0 THROW 54107,N'المستند غير موجود أو مقفل.',1;
END;
GO

/* ================================================================
   12. LEAVE BALANCES AND REQUEST WORKFLOW
   ================================================================ */
CREATE OR ALTER PROCEDURE dbo.Emp_SaveLeaveBalance
 @CmpID INT,@EmployeeID BIGINT,@LeaveTypeID BIGINT,@BalanceYear SMALLINT,
 @OpeningBalance DECIMAL(9,2)=0,@Earned DECIMAL(9,2)=0,@Adjusted DECIMAL(9,2)=0,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @BalanceYear NOT BETWEEN 1900 AND 9999 OR @OpeningBalance<0 OR @Earned<0 THROW 54110,N'بيانات رصيد الإجازة غير صحيحة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54111,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_LeaveTypes WHERE CmpID=@CmpID AND LeaveTypeID=@LeaveTypeID AND RecordState=0) THROW 54112,N'نوع الإجازة غير صالح.',1;
 BEGIN TRAN;
 IF EXISTS(SELECT 1 FROM dbo.Emp_LeaveBalances WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@BalanceYear)
  UPDATE dbo.Emp_LeaveBalances SET OpeningBalance=@OpeningBalance,Earned=@Earned,Adjusted=@Adjusted,RecordState=0
  WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@BalanceYear;
 ELSE
  INSERT dbo.Emp_LeaveBalances(CmpID,EmployeeID,LeaveTypeID,BalanceYear,OpeningBalance,Earned,Adjusted,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@LeaveTypeID,@BalanceYear,@OpeningBalance,@Earned,@Adjusted,@UserID);
 COMMIT;
 SELECT BalanceID,ClosingBalance FROM dbo.Emp_LeaveBalances WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@BalanceYear;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveLeaveRequest
 @CmpID INT,@RequestID BIGINT=0,@EmployeeID BIGINT,@LeaveTypeID BIGINT,
 @StartAt DATETIME2(0),@EndAt DATETIME2(0),@Quantity DECIMAL(9,2),@IsHourly BIT=0,
 @Reason NVARCHAR(1000)=NULL,@AttachmentPath NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @EndAt<=@StartAt OR @Quantity<=0 THROW 54113,N'فترة أو كمية الإجازة غير صحيحة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54114,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_LeaveTypes WHERE CmpID=@CmpID AND LeaveTypeID=@LeaveTypeID AND RecordState=0 AND ((@IsHourly=0 AND BalanceUnit=1) OR (@IsHourly=1 AND AllowHourly=1 AND BalanceUnit=2))) THROW 54115,N'نوع الإجازة أو وحدة رصيده لا تتوافق مع طلب الإجازة.',1;
 IF YEAR(@StartAt)<>YEAR(@EndAt) THROW 54123,N'قسّم طلب الإجازة على السنوات المالية حتى يُخصم كل جزء من رصيده الصحيح.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_LeaveRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND RequestState IN(0,1,2) AND @StartAt<EndAt AND @EndAt>StartAt AND (@RequestID=0 OR RequestID<>@RequestID))
  THROW 54116,N'توجد إجازة أخرى متداخلة للموظف.',1;
 IF @RequestID=0
 BEGIN
  INSERT dbo.Emp_LeaveRequests(CmpID,EmployeeID,LeaveTypeID,StartAt,EndAt,Quantity,IsHourly,Reason,AttachmentPath,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@LeaveTypeID,@StartAt,@EndAt,@Quantity,@IsHourly,@Reason,@AttachmentPath,@UserID);
  SET @RequestID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_LeaveRequests SET LeaveTypeID=@LeaveTypeID,StartAt=@StartAt,EndAt=@EndAt,Quantity=@Quantity,IsHourly=@IsHourly,Reason=@Reason,AttachmentPath=@AttachmentPath
  WHERE CmpID=@CmpID AND RequestID=@RequestID AND EmployeeID=@EmployeeID AND RequestState=0;
  IF @@ROWCOUNT=0 THROW 54117,N'الطلب غير موجود أو لم يعد في حالة المسودة.',1;
 END;
 SELECT @RequestID AS RequestID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_DecideLeaveRequest
 @CmpID INT,@RequestID BIGINT,@ApproverID BIGINT,@Decision TINYINT,@StepNo SMALLINT=1,@Comments NVARCHAR(500)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @Decision NOT IN(1,2) OR @StepNo<=0 THROW 54118,N'قرار الموافقة غير صحيح.',1;
 EXEC dbo.Emp_HRValidateActor @CmpID,@ApproverID;
 BEGIN TRAN;
 DECLARE @EmpID BIGINT,@CreatorID BIGINT,@LeaveTypeID BIGINT,@Qty DECIMAL(9,2),@Start DATE,@Year SMALLINT,@State TINYINT;
 SELECT @EmpID=EmployeeID,@CreatorID=CreatedBy,@LeaveTypeID=LeaveTypeID,@Qty=Quantity,@Start=CONVERT(date,StartAt),@State=RequestState
 FROM dbo.Emp_LeaveRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND RequestID=@RequestID;
 IF @EmpID IS NULL OR @State<>0 THROW 54119,N'الطلب غير موجود أو سبق اتخاذ قرار بشأنه.',1;
 IF @CreatorID=@ApproverID THROW 54120,N'لا يجوز لمنشئ الطلب اعتماده.',1;
 INSERT dbo.Emp_LeaveApprovals(CmpID,RequestID,StepNo,ApproverID,Decision,Comments) VALUES(@CmpID,@RequestID,@StepNo,@ApproverID,@Decision,@Comments);
 IF @Decision=2 UPDATE dbo.Emp_LeaveRequests SET RequestState=3 WHERE CmpID=@CmpID AND RequestID=@RequestID;
 ELSE
 BEGIN
  SET @Year=YEAR(@Start);
  IF NOT EXISTS(SELECT 1 FROM dbo.Emp_LeaveBalances WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmpID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@Year)
   THROW 54121,N'لا يوجد رصيد إجازة للسنة المطلوبة.',1;
  IF (SELECT ClosingBalance FROM dbo.Emp_LeaveBalances WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmpID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@Year)<@Qty
   THROW 54122,N'رصيد الإجازة غير كافٍ.',1;
  UPDATE dbo.Emp_LeaveRequests SET RequestState=2 WHERE CmpID=@CmpID AND RequestID=@RequestID;
  UPDATE dbo.Emp_LeaveBalances SET Used=Used+@Qty WHERE CmpID=@CmpID AND EmployeeID=@EmpID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@Year;
  INSERT dbo.Emp_LeaveBalanceTransactions(CmpID,BalanceID,TransactionDate,TransactionType,Quantity,SourceType,SourceID,Description,CreatedBy)
  SELECT @CmpID,BalanceID,@Start,2,@Qty,2,@RequestID,N'اعتماد طلب إجازة',@ApproverID
  FROM dbo.Emp_LeaveBalances WHERE CmpID=@CmpID AND EmployeeID=@EmpID AND LeaveTypeID=@LeaveTypeID AND BalanceYear=@Year;
 END;
 COMMIT;
 SELECT RequestID,RequestState FROM dbo.Emp_LeaveRequests WHERE CmpID=@CmpID AND RequestID=@RequestID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SelectLeaveRequests
 @CmpID INT,@EmployeeID BIGINT=NULL,@RequestID BIGINT=NULL,@State TINYINT=NULL,@DateFrom DATE=NULL,@DateTo DATE=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.*,t.LeaveTypeName FROM dbo.Emp_LeaveRequests r JOIN dbo.Emp_LeaveTypes t ON t.CmpID=r.CmpID AND t.LeaveTypeID=r.LeaveTypeID
 WHERE r.CmpID=@CmpID AND (@EmployeeID IS NULL OR r.EmployeeID=@EmployeeID) AND (@RequestID IS NULL OR r.RequestID=@RequestID)
 AND (@State IS NULL OR r.RequestState=@State) AND (@DateFrom IS NULL OR CONVERT(date,r.StartAt)>=@DateFrom) AND (@DateTo IS NULL OR CONVERT(date,r.EndAt)<=@DateTo)
 ORDER BY r.SubmittedAt DESC;
END;
GO

/* ================================================================
   13. PAYROLL PERIOD AND RUN CONTROL
   ================================================================ */
CREATE OR ALTER PROCEDURE dbo.Emp_SavePayPeriod
 @CmpID INT,@PeriodID BIGINT=0,@PeriodName NVARCHAR(100),@DateFrom DATE,@DateTo DATE,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @DateTo<@DateFrom THROW 54130,N'نطاق فترة الرواتب غير صحيح.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_PayPeriods WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND PeriodState IN(1,2,3) AND DateFrom<=@DateTo AND DateTo>=@DateFrom AND (@PeriodID=0 OR PeriodID<>@PeriodID))
  THROW 54131,N'تتداخل الفترة مع فترة رواتب قائمة أو مقفلة.',1;
 IF @PeriodID=0
 BEGIN
  INSERT dbo.Emp_PayPeriods(CmpID,PeriodName,DateFrom,DateTo,CreatedBy) VALUES(@CmpID,@PeriodName,@DateFrom,@DateTo,@UserID);
  SET @PeriodID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_PayPeriods SET PeriodName=@PeriodName,DateFrom=@DateFrom,DateTo=@DateTo WHERE CmpID=@CmpID AND PeriodID=@PeriodID AND PeriodState=0;
  IF @@ROWCOUNT=0 THROW 54132,N'الفترة غير موجودة أو غير قابلة للتعديل.',1;
 END;
 SELECT @PeriodID AS PeriodID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_CreatePayRun
 @CmpID INT,@PeriodID BIGINT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 BEGIN TRAN;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_PayPeriods WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND PeriodID=@PeriodID AND PeriodState=0)
  THROW 54133,N'فترة الرواتب غير موجودة أو غير مفتوحة.',1;
 DECLARE @CurrencyID BIGINT;
 IF (SELECT COUNT(*) FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurIsBase=1 AND CurState=0)<>1
  THROW 54133,N'يجب ضبط عملة أساسية واحدة ونشطة للشركة قبل إنشاء مسير الرواتب.',1;
 SELECT @CurrencyID=CurID FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurIsBase=1 AND CurState=0;
 DECLARE @RunNo INT=(SELECT ISNULL(MAX(RunNo),0)+1 FROM dbo.Emp_PayRuns WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND PeriodID=@PeriodID);
 INSERT dbo.Emp_PayRuns(CmpID,PeriodID,RunNo,CurrencyID,CreatedBy) VALUES(@CmpID,@PeriodID,@RunNo,@CurrencyID,@UserID);
 DECLARE @PayRunID BIGINT=SCOPE_IDENTITY();
 COMMIT;
 SELECT @PayRunID AS PayRunID,@RunNo AS RunNo;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_CalculatePayRun
 @CmpID INT,@PayRunID BIGINT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 BEGIN TRAN;
 DECLARE @From DATE,@To DATE,@State TINYINT,@RunCurrencyID BIGINT;
 SELECT @From=p.DateFrom,@To=p.DateTo,@State=r.RunState,@RunCurrencyID=r.CurrencyID
 FROM dbo.Emp_PayRuns r WITH(UPDLOCK,HOLDLOCK) JOIN dbo.Emp_PayPeriods p ON p.CmpID=r.CmpID AND p.PeriodID=r.PeriodID
 WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID;
 IF @From IS NULL OR @State<>0 THROW 54134,N'مسير الرواتب غير موجود أو غير قابل لإعادة الاحتساب.',1;
 IF EXISTS(SELECT EmpID FROM dbo.Emp_Salary WHERE EmpCompany=@CmpID AND SalStartDate<=@To AND (SalEndDate IS NULL OR SalEndDate>=@From) GROUP BY EmpID HAVING COUNT(*)>1)
  THROW 54137,N'توجد فترات راتب أساسي متداخلة لبعض الموظفين؛ صححها قبل احتساب المسير.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_Employee e WHERE e.EmpCompany=@CmpID AND e.EmpState=0 AND NOT EXISTS(SELECT 1 FROM dbo.Emp_Salary s WHERE s.EmpCompany=@CmpID AND s.EmpID=e.EmpID AND s.SalStartDate<=@To AND (s.SalEndDate IS NULL OR s.SalEndDate>=@From)))
  THROW 54159,N'يوجد موظفون نشطون بلا راتب أساسي سارٍ خلال فترة المسير.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_Salary s JOIN dbo.Emp_Employee e ON e.EmpCompany=s.EmpCompany AND e.EmpID=s.EmpID WHERE s.EmpCompany=@CmpID AND e.EmpState=0 AND s.SalStartDate<=@To AND (s.SalEndDate IS NULL OR s.SalEndDate>=@From) AND s.SalCurrencyID<>@RunCurrencyID)
  THROW 54160,N'توجد رواتب بعملة تختلف عن العملة الأساسية للمسير؛ يلزم ضبط تحويل العملة قبل الاحتساب.',1;
 DELETE dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID;
 ;WITH ActiveEmployees AS
 (
  SELECT e.EmpID FROM dbo.Emp_Employee e
  WHERE e.EmpCompany=@CmpID AND e.EmpState=0
 ), BaseSalary AS
 (
  SELECT s.EmpID,s.SalAmount FROM dbo.Emp_Salary s
  JOIN ActiveEmployees e ON e.EmpID=s.EmpID
  WHERE s.EmpCompany=@CmpID AND s.SalStartDate<=@To AND (s.SalEndDate IS NULL OR s.SalEndDate>=@From)
 ), Lines AS
 (
  SELECT b.EmpID,CAST(NULL AS BIGINT) ComponentID,CAST(1 AS TINYINT) LineKind,N'الراتب الأساسي' Description,b.SalAmount Amount
  FROM BaseSalary b
  UNION ALL
  SELECT ec.EmployeeID,ec.ComponentID,pc.ComponentKind,pc.ComponentName,
    CASE pc.CalculationMethod WHEN 1 THEN ec.Amount WHEN 2 THEN b.SalAmount*ec.Amount/100.0 END
  FROM dbo.Emp_EmployeePayComponents ec
  JOIN dbo.Emp_PayComponents pc ON pc.CmpID=ec.CmpID AND pc.ComponentID=ec.ComponentID AND pc.RecordState=0
  JOIN BaseSalary b ON b.EmpID=ec.EmployeeID
  WHERE ec.CmpID=@CmpID AND ec.RecordState=0 AND ec.StartDate<=@To AND (ec.EndDate IS NULL OR ec.EndDate>=@From)
 )
 INSERT dbo.Emp_PayrollDetails(CmpID,PayRunID,EmployeeID,ComponentID,LineKind,Description,Amount)
 SELECT @CmpID,@PayRunID,EmpID,ComponentID,LineKind,Description,ROUND(Amount,3)
 FROM Lines WHERE Amount IS NOT NULL AND Amount>=0;
 DECLARE @Gross DECIMAL(19,3),@Ded DECIMAL(19,3);
 SELECT @Gross=ISNULL(SUM(CASE WHEN LineKind=1 THEN Amount ELSE 0 END),0),
        @Ded=ISNULL(SUM(CASE WHEN LineKind=2 THEN Amount ELSE 0 END),0)
 FROM dbo.Emp_PayrollDetails WHERE CmpID=@CmpID AND PayRunID=@PayRunID;
 UPDATE dbo.Emp_PayRuns SET GrossTotal=@Gross,DeductionTotal=@Ded,NetTotal=@Gross-@Ded,
  CalculatedAt=SYSDATETIME(),CalculatedBy=@UserID,RunState=1
 WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND RunState=0;
 COMMIT;
 SELECT @PayRunID PayRunID,@Gross GrossTotal,@Ded DeductionTotal,@Gross-@Ded NetTotal;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_ChangePayRunState
 @CmpID INT,@PayRunID BIGINT,@UserID BIGINT,@Decision TINYINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @Decision NOT IN(2,3) THROW 54135,N'الحالة المطلوبة غير صحيحة.',1;
 BEGIN TRAN;
 UPDATE dbo.Emp_PayRuns WITH(UPDLOCK,HOLDLOCK)
 SET RunState=@Decision,
     ApprovedAt=CASE WHEN @Decision=2 THEN SYSDATETIME() ELSE ApprovedAt END,
     ApprovedBy=CASE WHEN @Decision=2 THEN @UserID ELSE ApprovedBy END,
     ClosedAt=CASE WHEN @Decision=3 THEN SYSDATETIME() ELSE ClosedAt END,
     ClosedBy=CASE WHEN @Decision=3 THEN @UserID ELSE ClosedBy END
 WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND ((@Decision=2 AND RunState=1) OR (@Decision=3 AND RunState=2 AND VoucherID IS NOT NULL));
 IF @@ROWCOUNT=0 THROW 54136,N'انتقال حالة المسير غير مسموح أو المسير غير موجود أو لم يُربط القيد المحاسبي قبل الإقفال.',1;
 COMMIT;
 SELECT PayRunID,RunState,NetTotal FROM dbo.Emp_PayRuns WHERE CmpID=@CmpID AND PayRunID=@PayRunID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SelectPayRun
 @CmpID INT,@PayRunID BIGINT=NULL,@PeriodID BIGINT=NULL,@State TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.*,p.PeriodName,p.DateFrom,p.DateTo FROM dbo.Emp_PayRuns r
 JOIN dbo.Emp_PayPeriods p ON p.CmpID=r.CmpID AND p.PeriodID=r.PeriodID
 WHERE r.CmpID=@CmpID AND (@PayRunID IS NULL OR r.PayRunID=@PayRunID) AND (@PeriodID IS NULL OR r.PeriodID=@PeriodID) AND (@State IS NULL OR r.RunState=@State)
 ORDER BY p.DateFrom DESC,r.RunNo DESC;
END;
GO

/* ================================================================
   14. LOAN SCHEDULE AND PAYROLL-POSTING READINESS
   ================================================================ */
CREATE OR ALTER PROCEDURE dbo.Emp_ApproveLoanAndGenerateSchedule
 @CmpID INT,@LoanID BIGINT,@ApproverID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@ApproverID;
 BEGIN TRAN;
 DECLARE @Principal DECIMAL(15,3),@Interest DECIMAL(15,3),@Count SMALLINT,@InstallmentAmount DECIMAL(15,3),@IntervalDays SMALLINT,@Start DATE,@State TINYINT;
 SELECT @Principal=Principal,@Interest=InterestAmount,@Count=InstallmentCount,@InstallmentAmount=InstallmentAmount,@IntervalDays=InstallmentIntervalDays,@Start=StartDate,@State=LoanState
 FROM dbo.Emp_Loans WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND LoanID=@LoanID;
 IF @Principal IS NULL OR @State<>0 THROW 54140,N'طلب السلفة غير موجود أو سبق اعتماده.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_LoanInstallments WHERE CmpID=@CmpID AND LoanID=@LoanID) THROW 54141,N'جدول الأقساط موجود مسبقاً.',1;
 DECLARE @Total DECIMAL(15,3)=@Principal+@Interest,@i INT=1,@Sum DECIMAL(15,3)=0;
 IF @Total<=@InstallmentAmount*(@Count-1) OR @Total>@InstallmentAmount*@Count THROW 54142,N'مبلغ القسط وعدد الأقساط لا يغطيان إجمالي السلفة.',1;
 WHILE @i<=@Count
 BEGIN
  DECLARE @Amount DECIMAL(15,3)=CASE WHEN @i=@Count THEN @Total-@Sum ELSE @InstallmentAmount END;
  INSERT dbo.Emp_LoanInstallments(CmpID,LoanID,InstallmentNo,DueDate,Amount)
  VALUES(@CmpID,@LoanID,@i,DATEADD(DAY,@IntervalDays*(@i-1),@Start),@Amount);
  SET @Sum+=@Amount; SET @i+=1;
 END;
 UPDATE dbo.Emp_Loans SET LoanState=1,ApprovedAt=SYSDATETIME(),ApprovedBy=@ApproverID WHERE CmpID=@CmpID AND LoanID=@LoanID;
 COMMIT;
 SELECT * FROM dbo.Emp_LoanInstallments WHERE CmpID=@CmpID AND LoanID=@LoanID ORDER BY InstallmentNo;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SelectLeaveBalances
 @CmpID INT,@EmployeeID BIGINT=NULL,@BalanceYear SMALLINT=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT b.*,t.LeaveTypeName FROM dbo.Emp_LeaveBalances b JOIN dbo.Emp_LeaveTypes t ON t.CmpID=b.CmpID AND t.LeaveTypeID=b.LeaveTypeID
 WHERE b.CmpID=@CmpID AND (@EmployeeID IS NULL OR b.EmployeeID=@EmployeeID) AND (@BalanceYear IS NULL OR b.BalanceYear=@BalanceYear)
 ORDER BY b.EmployeeID,b.BalanceYear,t.LeaveTypeName;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Emp_SavePayComponent
 @CmpID INT,@ComponentID BIGINT=0,@ComponentCode NVARCHAR(30),@ComponentName NVARCHAR(150),
 @ComponentKind TINYINT,@CalculationMethod TINYINT,@IsTaxable BIT=0,@IsInsurable BIT=0,@IsRecurring BIT=1,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @ComponentKind NOT IN(1,2) OR @CalculationMethod NOT IN(1,2) THROW 54138,N'نوع أو طريقة احتساب مكون الراتب غير صحيحة.',1;
 IF @ComponentID=0
 BEGIN
  INSERT dbo.Emp_PayComponents(CmpID,ComponentCode,ComponentName,ComponentKind,CalculationMethod,IsTaxable,IsInsurable,IsRecurring,CreatedBy)
  VALUES(@CmpID,@ComponentCode,@ComponentName,@ComponentKind,@CalculationMethod,@IsTaxable,@IsInsurable,@IsRecurring,@UserID);
  SET @ComponentID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_PayComponents SET ComponentCode=@ComponentCode,ComponentName=@ComponentName,ComponentKind=@ComponentKind,CalculationMethod=@CalculationMethod,
   IsTaxable=@IsTaxable,IsInsurable=@IsInsurable,IsRecurring=@IsRecurring WHERE CmpID=@CmpID AND ComponentID=@ComponentID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54139,N'مكون الراتب غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @ComponentID ComponentID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SavePayrollAccountMapping
 @CmpID INT,@MappingID BIGINT=0,@ComponentID BIGINT=NULL,@AccountID BIGINT,@CostCenterID BIGINT=NULL,
 @DebitCredit TINYINT,@EffectiveFrom DATE,@EffectiveTo DATE=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @DebitCredit NOT IN(1,2) OR (@EffectiveTo IS NOT NULL AND @EffectiveTo<@EffectiveFrom) THROW 54142,N'بيانات ربط الحساب غير صحيحة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Acc_Account WHERE AccCompany=@CmpID AND AccID=@AccountID AND AccState=0 AND AccChid=0) THROW 54143,N'الحساب غير موجود أو غير نشط أو غير تحليلي للشركة.',1;
 IF @CostCenterID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCCompany=@CmpID AND CsCID=@CostCenterID AND CsCState=0 AND CsCChid=0) THROW 54144,N'مركز التكلفة غير موجود أو غير نشط أو غير تحليلي للشركة.',1;
 IF @ComponentID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Emp_PayComponents WHERE CmpID=@CmpID AND ComponentID=@ComponentID) THROW 54145,N'مكون الراتب لا يتبع للشركة.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_PayrollAccountMappings WHERE CmpID=@CmpID AND ISNULL(ComponentID,0)=ISNULL(@ComponentID,0) AND DebitCredit=@DebitCredit AND RecordState=0
  AND EffectiveFrom<=ISNULL(@EffectiveTo,'99991231') AND ISNULL(EffectiveTo,'99991231')>=@EffectiveFrom AND (@MappingID=0 OR MappingID<>@MappingID))
  THROW 54146,N'يوجد ربط حسابي متداخل لنفس المكون والجهة.',1;
 IF @MappingID=0
 BEGIN
  INSERT dbo.Emp_PayrollAccountMappings(CmpID,ComponentID,AccountID,CostCenterID,DebitCredit,EffectiveFrom,EffectiveTo,CreatedBy)
  VALUES(@CmpID,@ComponentID,@AccountID,@CostCenterID,@DebitCredit,@EffectiveFrom,@EffectiveTo,@UserID);
  SET @MappingID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_PayrollAccountMappings SET ComponentID=@ComponentID,AccountID=@AccountID,CostCenterID=@CostCenterID,DebitCredit=@DebitCredit,
   EffectiveFrom=@EffectiveFrom,EffectiveTo=@EffectiveTo WHERE CmpID=@CmpID AND MappingID=@MappingID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54147,N'ربط الحساب غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @MappingID MappingID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SelectPayrollAccountMappings
 @CmpID INT,@ComponentID BIGINT=NULL,@Date DATE=NULL,@State TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT m.*,p.ComponentCode,p.ComponentName,a.AccCode,a.AccName,c.CsCCode,c.CsCName
 FROM dbo.Emp_PayrollAccountMappings m
 LEFT JOIN dbo.Emp_PayComponents p ON p.CmpID=m.CmpID AND p.ComponentID=m.ComponentID
 JOIN dbo.Acc_Account a ON a.AccCompany=m.CmpID AND a.AccID=m.AccountID
 LEFT JOIN dbo.Acc_CostCenter c ON c.CsCCompany=m.CmpID AND c.CsCID=m.CostCenterID
 WHERE m.CmpID=@CmpID AND (@ComponentID IS NULL OR m.ComponentID=@ComponentID)
 AND (@Date IS NULL OR (m.EffectiveFrom<=@Date AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@Date)))
 AND (@State IS NULL OR m.RecordState=@State) ORDER BY m.ComponentID,m.DebitCredit,m.EffectiveFrom DESC;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_PostPayRun
 @CmpID INT,@PayRunID BIGINT,@UserID BIGINT,@Description NVARCHAR(500)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF TYPE_ID(N'dbo.Acc_DayLineType') IS NULL THROW 54148,N'نوع بنود القيد المحاسبي غير موجود.',1;
 DECLARE @PeriodID BIGINT,@PeriodFrom DATE,@PeriodTo DATE,@RunState TINYINT,@ExistingVoucher BIGINT;
 SELECT @PeriodID=r.PeriodID,@PeriodFrom=p.DateFrom,@PeriodTo=p.DateTo,@RunState=r.RunState,@ExistingVoucher=r.VoucherID
 FROM dbo.Emp_PayRuns r JOIN dbo.Emp_PayPeriods p ON p.CmpID=r.CmpID AND p.PeriodID=r.PeriodID
 WHERE r.CmpID=@CmpID AND r.PayRunID=@PayRunID;
 IF @PeriodID IS NULL OR @RunState<>2 OR @ExistingVoucher IS NOT NULL THROW 54149,N'المسير غير معتمد أو غير موجود أو سبق ربطه بقيد.',1;
 IF EXISTS
 (
  SELECT d.PayrollDetailID FROM dbo.Emp_PayrollDetails d
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.Amount<>0
    AND (SELECT COUNT(*) FROM dbo.Emp_PayrollAccountMappings m
         WHERE m.CmpID=d.CmpID AND (m.ComponentID=d.ComponentID OR (m.ComponentID IS NULL AND d.ComponentID IS NULL))
           AND m.RecordState=0 AND m.EffectiveFrom<=@PeriodTo AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@PeriodFrom))<>2
 ) THROW 54154,N'يجب تعريف ربط مدين وربط دائن فعال لكل مكون راتب مستخدم في المسير.',1;
 IF EXISTS
 (
  SELECT 1 FROM dbo.Emp_PayrollAccountMappings m
  JOIN dbo.Emp_PayrollDetails d ON d.CmpID=m.CmpID AND d.PayRunID=@PayRunID AND (d.ComponentID=m.ComponentID OR (d.ComponentID IS NULL AND m.ComponentID IS NULL))
  JOIN dbo.Acc_Account a ON a.AccCompany=m.CmpID AND a.AccID=m.AccountID
  WHERE m.CmpID=@CmpID AND m.RecordState=0 AND m.EffectiveFrom<=@PeriodTo AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@PeriodFrom)
    AND (a.AccState<>0 OR a.AccChid<>0 OR (m.CostCenterID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Acc_CostCenter c WHERE c.CsCCompany=@CmpID AND c.CsCID=m.CostCenterID AND c.CsCState=0 AND c.CsCChid=0)))
 ) THROW 54155,N'يوجد حساب أو مركز تكلفة غير صالح ضمن خرائط الترحيل.',1;
 DECLARE @Lines dbo.Acc_DayLineType;
 ;WITH Mapped AS
 (
  SELECT d.PayrollDetailID,d.Amount,m.AccountID,m.CostCenterID,m.DebitCredit,d.Description
  FROM dbo.Emp_PayrollDetails d
  JOIN dbo.Emp_PayrollAccountMappings m ON m.CmpID=d.CmpID AND (m.ComponentID=d.ComponentID OR (m.ComponentID IS NULL AND d.ComponentID IS NULL))
   AND m.RecordState=0 AND m.EffectiveFrom<=@PeriodTo AND (m.EffectiveTo IS NULL OR m.EffectiveTo>=@PeriodFrom)
  WHERE d.CmpID=@CmpID AND d.PayRunID=@PayRunID AND d.Amount<>0
 ), Grouped AS
 (
  SELECT AccountID,CostCenterID,DebitCredit,SUM(Amount) Amount,MAX(Description) Description
  FROM Mapped GROUP BY AccountID,CostCenterID,DebitCredit
 )
 INSERT @Lines(SeqNo,DayDAccID,DayDDeb,DayDCrd,DayDCsCID,DayDNum,DayDDescription)
 SELECT ROW_NUMBER() OVER(ORDER BY AccountID,CostCenterID,DebitCredit),AccountID,
        CASE WHEN DebitCredit=1 THEN Amount ELSE 0 END,
        CASE WHEN DebitCredit=2 THEN Amount ELSE 0 END,
        CostCenterID,NULL,CONCAT(N'مسير رواتب: ',ISNULL(@Description,N''),N' - ',Description)
 FROM Grouped WHERE Amount>0;
 IF NOT EXISTS(SELECT 1 FROM @Lines) THROW 54156,N'لا توجد بنود قابلة للترحيل.',1;
 IF (SELECT SUM(DayDDeb)-SUM(DayDCrd) FROM @Lines)<>0 THROW 54157,N'خرائط الرواتب لا تنتج قيداً متوازناً.',1;
 DECLARE @Result TABLE(DayMID BIGINT,DayMNo INT,DayMState TINYINT,VoucherNo NVARCHAR(40));
 BEGIN TRY
  BEGIN TRAN;
  EXEC sys.sp_set_session_context @key=N'Acc.SystemOperation',@value=1;
  INSERT @Result EXEC dbo.Acc_SaveDayVoucher @Cmp=@CmpID,@Year=YEAR(@PeriodTo),@User=@UserID,@DayMID=0,@Date=@PeriodTo,
   @Info=COALESCE(NULLIF(LTRIM(RTRIM(@Description)),N''),N'قيد مسير الرواتب'),@Post=0,@Lines=@Lines;
  IF (SELECT COUNT(*) FROM @Result)<>1 THROW 54158,N'لم يُرجع إجراء القيد المحاسبي معرف القيد المتوقع.',1;
  UPDATE dbo.Emp_PayRuns SET VoucherID=(SELECT TOP(1) DayMID FROM @Result) WHERE CmpID=@CmpID AND PayRunID=@PayRunID AND RunState=2 AND VoucherID IS NULL;
  IF @@ROWCOUNT=0 THROW 54158,N'تعذر ربط القيد بالمسير؛ تحقق من حالة المسير.',1;
  EXEC sys.sp_set_session_context @key=N'Acc.SystemOperation',@value=NULL;
  COMMIT;
 END TRY
 BEGIN CATCH
  EXEC sys.sp_set_session_context @key=N'Acc.SystemOperation',@value=NULL;
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
 SELECT * FROM @Result;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveLeavePolicyType
 @CmpID INT,@PolicyTypeID BIGINT=0,@PolicyID BIGINT,@LeaveTypeID BIGINT,@AnnualEntitlement DECIMAL(9,2),
 @MaxBalance DECIMAL(9,2)=NULL,@MinimumServiceMonths INT=0,@CarryForwardLimit DECIMAL(9,2)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @AnnualEntitlement<0 OR @MaxBalance<0 OR @MinimumServiceMonths<0 OR @CarryForwardLimit<0 THROW 54157,N'قيم استحقاق الإجازة غير صحيحة.',1;
 IF @PolicyTypeID=0
 BEGIN
  INSERT dbo.Emp_LeavePolicyTypes(CmpID,PolicyID,LeaveTypeID,AnnualEntitlement,MaxBalance,MinimumServiceMonths,CarryForwardLimit)
  VALUES(@CmpID,@PolicyID,@LeaveTypeID,@AnnualEntitlement,@MaxBalance,@MinimumServiceMonths,@CarryForwardLimit);
  SET @PolicyTypeID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_LeavePolicyTypes SET PolicyID=@PolicyID,LeaveTypeID=@LeaveTypeID,AnnualEntitlement=@AnnualEntitlement,MaxBalance=@MaxBalance,
   MinimumServiceMonths=@MinimumServiceMonths,CarryForwardLimit=@CarryForwardLimit
  WHERE CmpID=@CmpID AND PolicyTypeID=@PolicyTypeID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54158,N'تفصيل سياسة الإجازة غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @PolicyTypeID PolicyTypeID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveEmployeePayComponent
 @CmpID INT,@EmployeeComponentID BIGINT=0,@EmployeeID BIGINT,@ComponentID BIGINT,@Amount DECIMAL(15,3),
 @StartDate DATE,@EndDate DATE=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @Amount<0 OR (@EndDate IS NOT NULL AND @EndDate<@StartDate) THROW 54161,N'قيمة أو فترة مكون الراتب غير صحيحة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54162,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_PayComponents WHERE CmpID=@CmpID AND ComponentID=@ComponentID AND RecordState=0) THROW 54163,N'مكون الراتب غير نشط أو غير موجود.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_EmployeePayComponents WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND ComponentID=@ComponentID AND RecordState=0
  AND StartDate<=ISNULL(@EndDate,'99991231') AND ISNULL(EndDate,'99991231')>=@StartDate AND (@EmployeeComponentID=0 OR EmployeeComponentID<>@EmployeeComponentID))
  THROW 54164,N'تتداخل فترة مكون الراتب مع فترة أخرى للموظف.',1;
 IF @EmployeeComponentID=0
 BEGIN
  INSERT dbo.Emp_EmployeePayComponents(CmpID,EmployeeID,ComponentID,Amount,StartDate,EndDate,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@ComponentID,@Amount,@StartDate,@EndDate,@UserID);
  SET @EmployeeComponentID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_EmployeePayComponents SET Amount=@Amount,StartDate=@StartDate,EndDate=@EndDate
  WHERE CmpID=@CmpID AND EmployeeComponentID=@EmployeeComponentID AND EmployeeID=@EmployeeID AND ComponentID=@ComponentID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54165,N'مكون الموظف غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @EmployeeComponentID EmployeeComponentID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveCandidate
 @CmpID INT,@CandidateID BIGINT=0,@CandidateNo NVARCHAR(40)=NULL,@FullName NVARCHAR(200),@Phone NVARCHAR(40)=NULL,
 @Email NVARCHAR(254)=NULL,@NationalityID BIGINT=NULL,@BirthDate DATE=NULL,@SourceName NVARCHAR(150)=NULL,
 @CVPath NVARCHAR(1000)=NULL,@Notes NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NULLIF(LTRIM(RTRIM(@FullName)),N'') IS NULL THROW 54166,N'اسم المرشح مطلوب.',1;
 IF @CandidateID=0
 BEGIN
  INSERT dbo.Emp_Candidates(CmpID,CandidateNo,FullName,Phone,Email,NationalityID,BirthDate,SourceName,CVPath,Notes,CreatedBy)
  VALUES(@CmpID,@CandidateNo,@FullName,@Phone,@Email,@NationalityID,@BirthDate,@SourceName,@CVPath,@Notes,@UserID);
  SET @CandidateID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_Candidates SET CandidateNo=@CandidateNo,FullName=@FullName,Phone=@Phone,Email=@Email,NationalityID=@NationalityID,BirthDate=@BirthDate,SourceName=@SourceName,CVPath=@CVPath,Notes=@Notes
  WHERE CmpID=@CmpID AND CandidateID=@CandidateID AND CandidateState=0;
  IF @@ROWCOUNT=0 THROW 54167,N'المرشح غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @CandidateID CandidateID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveJobApplication
 @CmpID INT,@ApplicationID BIGINT=0,@CandidateID BIGINT,@PositionID BIGINT=NULL,@InterviewAt DATETIME2(0)=NULL,
 @InterviewResult TINYINT=NULL,@OfferDate DATE=NULL,@OfferAmount DECIMAL(15,3)=NULL,@OfferCurrencyID BIGINT=NULL,
 @OfferExpiry DATE=NULL,@ApplicationState TINYINT=0,@Notes NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Candidates WHERE CmpID=@CmpID AND CandidateID=@CandidateID AND CandidateState=0) THROW 54168,N'المرشح غير نشط أو لا يتبع للشركة.',1;
 IF @OfferAmount<0 OR (@OfferExpiry IS NOT NULL AND @OfferDate IS NOT NULL AND @OfferExpiry<@OfferDate) THROW 54169,N'بيانات عرض العمل غير صحيحة.',1;
 IF @OfferCurrencyID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurID=@OfferCurrencyID AND CurState=0) THROW 54170,N'عملة العرض غير صالحة للشركة.',1;
 IF @ApplicationID=0
 BEGIN
  INSERT dbo.Emp_JobApplications(CmpID,CandidateID,PositionID,InterviewAt,InterviewResult,OfferDate,OfferAmount,OfferCurrencyID,OfferExpiry,ApplicationState,Notes,CreatedBy)
  VALUES(@CmpID,@CandidateID,@PositionID,@InterviewAt,@InterviewResult,@OfferDate,@OfferAmount,@OfferCurrencyID,@OfferExpiry,@ApplicationState,@Notes,@UserID);
  SET @ApplicationID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_JobApplications SET PositionID=@PositionID,InterviewAt=@InterviewAt,InterviewResult=@InterviewResult,OfferDate=@OfferDate,
   OfferAmount=@OfferAmount,OfferCurrencyID=@OfferCurrencyID,OfferExpiry=@OfferExpiry,ApplicationState=@ApplicationState,Notes=@Notes
  WHERE CmpID=@CmpID AND ApplicationID=@ApplicationID AND ApplicationState=0;
  IF @@ROWCOUNT=0 THROW 54171,N'طلب التوظيف غير موجود أو نهائي.',1;
 END;
 SELECT @ApplicationID ApplicationID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SavePayPolicy
 @CmpID INT,@PayPolicyID BIGINT=0,@PolicyName NVARCHAR(150),@EffectiveFrom DATE,@EffectiveTo DATE=NULL,
 @StandardMonthlyHours DECIMAL(9,2)=NULL,@RoundingScale TINYINT=3,@CurrencyID BIGINT=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @EffectiveTo IS NOT NULL AND @EffectiveTo<@EffectiveFrom OR @StandardMonthlyHours<=0 OR @RoundingScale>6 THROW 54172,N'إعدادات سياسة الرواتب غير صحيحة.',1;
 IF @CurrencyID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurID=@CurrencyID AND CurState=0) THROW 54173,N'عملة سياسة الرواتب غير صالحة.',1;
 IF @PayPolicyID=0
 BEGIN
  INSERT dbo.Emp_PayPolicies(CmpID,PolicyName,EffectiveFrom,EffectiveTo,StandardMonthlyHours,RoundingScale,CurrencyID,CreatedBy)
  VALUES(@CmpID,@PolicyName,@EffectiveFrom,@EffectiveTo,@StandardMonthlyHours,@RoundingScale,@CurrencyID,@UserID);
  SET @PayPolicyID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_PayPolicies SET PolicyName=@PolicyName,EffectiveFrom=@EffectiveFrom,EffectiveTo=@EffectiveTo,StandardMonthlyHours=@StandardMonthlyHours,RoundingScale=@RoundingScale,CurrencyID=@CurrencyID
  WHERE CmpID=@CmpID AND PayPolicyID=@PayPolicyID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54174,N'سياسة الرواتب غير موجودة أو غير قابلة للتعديل.',1;
 END;
 SELECT @PayPolicyID PayPolicyID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveLeaveType
 @CmpID INT,@LeaveTypeID BIGINT=0,@LeaveTypeName NVARCHAR(150),@IsPaid BIT,@RequiresDocument BIT=0,@AllowHourly BIT=0,@BalanceUnit TINYINT=1,@MaxCarryForward DECIMAL(9,2)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @MaxCarryForward<0 OR @BalanceUnit NOT IN(1,2) OR (@BalanceUnit=2 AND @AllowHourly=0) THROW 54160,N'وحدة رصيد الإجازة أو حد الترحيل غير صحيح.',1;
 IF @LeaveTypeID=0
 BEGIN
  INSERT dbo.Emp_LeaveTypes(CmpID,LeaveTypeName,IsPaid,RequiresDocument,AllowHourly,BalanceUnit,MaxCarryForward,CreatedBy)
  VALUES(@CmpID,@LeaveTypeName,@IsPaid,@RequiresDocument,@AllowHourly,@BalanceUnit,@MaxCarryForward,@UserID);
  SET @LeaveTypeID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_LeaveTypes SET LeaveTypeName=@LeaveTypeName,IsPaid=@IsPaid,RequiresDocument=@RequiresDocument,AllowHourly=@AllowHourly,BalanceUnit=@BalanceUnit,MaxCarryForward=@MaxCarryForward
  WHERE CmpID=@CmpID AND LeaveTypeID=@LeaveTypeID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54161,N'نوع الإجازة غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @LeaveTypeID LeaveTypeID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveLeavePolicy
 @CmpID INT,@PolicyID BIGINT=0,@PolicyName NVARCHAR(150),@EffectiveFrom DATE,@EffectiveTo DATE=NULL,
 @AccrualFrequency TINYINT,@ProrationMethod TINYINT,@AllowNegative BIT=0,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @EffectiveTo IS NOT NULL AND @EffectiveTo<@EffectiveFrom THROW 54162,N'فترة سياسة الإجازات غير صحيحة.',1;
 IF @PolicyID=0
 BEGIN
  INSERT dbo.Emp_LeavePolicies(CmpID,PolicyName,EffectiveFrom,EffectiveTo,AccrualFrequency,ProrationMethod,AllowNegative,CreatedBy)
  VALUES(@CmpID,@PolicyName,@EffectiveFrom,@EffectiveTo,@AccrualFrequency,@ProrationMethod,@AllowNegative,@UserID);
  SET @PolicyID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_LeavePolicies SET PolicyName=@PolicyName,EffectiveFrom=@EffectiveFrom,EffectiveTo=@EffectiveTo,AccrualFrequency=@AccrualFrequency,ProrationMethod=@ProrationMethod,AllowNegative=@AllowNegative
  WHERE CmpID=@CmpID AND PolicyID=@PolicyID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54163,N'سياسة الإجازات غير موجودة أو غير قابلة للتعديل.',1;
 END;
 SELECT @PolicyID PolicyID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_AssignEmployeeLeavePolicy
 @CmpID INT,@EmployeeID BIGINT,@PolicyID BIGINT,@EffectiveFrom DATE,@EffectiveTo DATE=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54164,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_LeavePolicies WHERE CmpID=@CmpID AND PolicyID=@PolicyID AND RecordState=0) THROW 54165,N'سياسة الإجازات غير نشطة أو غير موجودة.',1;
 IF @EffectiveTo IS NOT NULL AND @EffectiveTo<@EffectiveFrom THROW 54166,N'فترة الإسناد غير صحيحة.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_EmployeeLeavePolicies WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND RecordState=0
  AND EffectiveFrom<=ISNULL(@EffectiveTo,'99991231') AND ISNULL(EffectiveTo,'99991231')>=@EffectiveFrom)
  THROW 54167,N'تتداخل سياسة الإجازات مع إسناد قائم للموظف.',1;
 INSERT dbo.Emp_EmployeeLeavePolicies(CmpID,EmployeeID,PolicyID,EffectiveFrom,EffectiveTo,CreatedBy)
 VALUES(@CmpID,@EmployeeID,@PolicyID,@EffectiveFrom,@EffectiveTo,@UserID);
 SELECT SCOPE_IDENTITY() EmployeePolicyID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveOvertimeRequest
 @CmpID INT,@OvertimeID BIGINT=0,@EmployeeID BIGINT,@WorkDate DATE,@StartAt DATETIME2(0),@EndAt DATETIME2(0),
 @Hours DECIMAL(8,2),@Reason NVARCHAR(500),@Multiplier DECIMAL(8,4)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54170,N'الموظف لا يتبع للشركة.',1;
 IF @EndAt<=@StartAt OR @Hours<=0 OR (@Multiplier IS NOT NULL AND @Multiplier<=0) THROW 54171,N'بيانات العمل الإضافي غير صحيحة.',1;
 IF @OvertimeID=0
 BEGIN
  INSERT dbo.Emp_OvertimeRequests(CmpID,EmployeeID,WorkDate,StartAt,EndAt,Hours,Reason,Multiplier,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@WorkDate,@StartAt,@EndAt,@Hours,@Reason,@Multiplier,@UserID);
  SET @OvertimeID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_OvertimeRequests SET WorkDate=@WorkDate,StartAt=@StartAt,EndAt=@EndAt,Hours=@Hours,Reason=@Reason,Multiplier=@Multiplier
  WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID AND EmployeeID=@EmployeeID AND RequestState=0;
  IF @@ROWCOUNT=0 THROW 54172,N'طلب الإضافي غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @OvertimeID OvertimeID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_DecideOvertimeRequest
 @CmpID INT,@OvertimeID BIGINT,@ApproverID BIGINT,@Approve BIT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@ApproverID;
 IF @Approve IS NULL THROW 54169,N'قرار اعتماد الإضافي مطلوب.',1;
 UPDATE dbo.Emp_OvertimeRequests SET RequestState=CASE WHEN @Approve=1 THEN 1 ELSE 2 END,ApprovedAt=SYSDATETIME(),ApprovedBy=@ApproverID
 WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID AND RequestState=0 AND CreatedBy<>@ApproverID;
 IF @@ROWCOUNT=0 THROW 54173,N'طلب الإضافي غير موجود أو لا يسمح للمستخدم باعتماده.',1;
 SELECT OvertimeID,RequestState FROM dbo.Emp_OvertimeRequests WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveLoan
 @CmpID INT,@LoanID BIGINT=0,@EmployeeID BIGINT,@LoanNo NVARCHAR(40)=NULL,@Principal DECIMAL(15,3),@CurrencyID BIGINT,
 @StartDate DATE,@InstallmentCount SMALLINT,@InstallmentAmount DECIMAL(15,3),@InstallmentIntervalDays SMALLINT,@InterestAmount DECIMAL(15,3)=0,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54174,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurID=@CurrencyID AND CurState=0) THROW 54175,N'عملة السلفة غير صالحة للشركة.',1;
 IF @Principal<=0 OR @InstallmentCount<=0 OR @InstallmentAmount<=0 OR @InstallmentIntervalDays<=0 OR @InterestAmount<0 THROW 54176,N'قيم السلفة أو الأقساط غير صحيحة.',1;
 IF @LoanID=0
 BEGIN
  INSERT dbo.Emp_Loans(CmpID,EmployeeID,LoanNo,Principal,CurrencyID,StartDate,InstallmentCount,InstallmentAmount,InstallmentIntervalDays,InterestAmount,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@LoanNo,@Principal,@CurrencyID,@StartDate,@InstallmentCount,@InstallmentAmount,@InstallmentIntervalDays,@InterestAmount,@UserID);
  SET @LoanID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_Loans SET LoanNo=@LoanNo,Principal=@Principal,CurrencyID=@CurrencyID,StartDate=@StartDate,InstallmentCount=@InstallmentCount,InstallmentAmount=@InstallmentAmount,InstallmentIntervalDays=@InstallmentIntervalDays,InterestAmount=@InterestAmount
  WHERE CmpID=@CmpID AND LoanID=@LoanID AND EmployeeID=@EmployeeID AND LoanState=0;
  IF @@ROWCOUNT=0 THROW 54177,N'طلب السلفة غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @LoanID LoanID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_RegisterLoanPayment
 @CmpID INT,@InstallmentID BIGINT,@Amount DECIMAL(15,3),@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @Amount<=0 THROW 54178,N'مبلغ السداد يجب أن يكون أكبر من صفر.',1;
 BEGIN TRAN;
 UPDATE dbo.Emp_LoanInstallments WITH(UPDLOCK,HOLDLOCK)
 SET PaidAmount=PaidAmount+@Amount,InstallmentState=CASE WHEN PaidAmount+@Amount=Amount THEN 1 ELSE 0 END,
     PaidAt=CASE WHEN PaidAmount+@Amount=Amount THEN SYSDATETIME() ELSE NULL END
 WHERE CmpID=@CmpID AND InstallmentID=@InstallmentID AND InstallmentState=0 AND PaidAmount+@Amount<=Amount;
 IF @@ROWCOUNT=0 THROW 54179,N'القسط غير موجود أو أن مبلغ السداد يتجاوز المتبقي.',1;
 COMMIT;
 SELECT * FROM dbo.Emp_LoanInstallments WHERE CmpID=@CmpID AND InstallmentID=@InstallmentID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SavePerformanceReview
 @CmpID INT,@ReviewID BIGINT=0,@CycleID BIGINT,@EmployeeID BIGINT,@ReviewerID BIGINT,@Score DECIMAL(7,2)=NULL,@ReviewText NVARCHAR(MAX)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54180,N'الموظف لا يتبع للشركة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@ReviewerID) THROW 54181,N'المقيّم غير موجود.',1;
 IF @ReviewID=0
 BEGIN
  INSERT dbo.Emp_PerformanceReviews(CmpID,CycleID,EmployeeID,ReviewerID,Score,ReviewText,CreatedBy)
  VALUES(@CmpID,@CycleID,@EmployeeID,@ReviewerID,@Score,@ReviewText,@UserID);
  SET @ReviewID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_PerformanceReviews SET Score=@Score,ReviewText=@ReviewText,ReviewerID=@ReviewerID
  WHERE CmpID=@CmpID AND ReviewID=@ReviewID AND ReviewState=0;
  IF @@ROWCOUNT=0 THROW 54182,N'التقييم غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @ReviewID ReviewID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveTrainingRecord
 @CmpID INT,@TrainingRecordID BIGINT=0,@CourseID BIGINT,@EmployeeID BIGINT,@DateFrom DATE,@DateTo DATE,
 @Result NVARCHAR(250)=NULL,@Score DECIMAL(7,2)=NULL,@CertificatePath NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54183,N'الموظف لا يتبع للشركة.',1;
 IF @DateTo<@DateFrom THROW 54184,N'فترة التدريب غير صحيحة.',1;
 IF @TrainingRecordID=0
 BEGIN
  INSERT dbo.Emp_TrainingRecords(CmpID,CourseID,EmployeeID,DateFrom,DateTo,Result,Score,CertificatePath,CreatedBy)
  VALUES(@CmpID,@CourseID,@EmployeeID,@DateFrom,@DateTo,@Result,@Score,@CertificatePath,@UserID);
  SET @TrainingRecordID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_TrainingRecords SET CourseID=@CourseID,DateFrom=@DateFrom,DateTo=@DateTo,Result=@Result,Score=@Score,CertificatePath=@CertificatePath
  WHERE CmpID=@CmpID AND TrainingRecordID=@TrainingRecordID AND RecordState=0;
  IF @@ROWCOUNT=0 THROW 54185,N'سجل التدريب غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @TrainingRecordID TrainingRecordID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveTermination
 @CmpID INT,@TerminationID BIGINT=0,@EmployeeID BIGINT,@NoticeDate DATE,@LastWorkingDate DATE,
 @TerminationReason TINYINT,@ReasonText NVARCHAR(1000)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID) THROW 54186,N'الموظف لا يتبع للشركة.',1;
 IF @LastWorkingDate<@NoticeDate THROW 54187,N'تاريخ آخر يوم عمل يسبق تاريخ الإشعار.',1;
 IF @TerminationID=0
 BEGIN
  INSERT dbo.Emp_Terminations(CmpID,EmployeeID,NoticeDate,LastWorkingDate,TerminationReason,ReasonText,CreatedBy)
  VALUES(@CmpID,@EmployeeID,@NoticeDate,@LastWorkingDate,@TerminationReason,@ReasonText,@UserID);
  SET @TerminationID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_Terminations SET NoticeDate=@NoticeDate,LastWorkingDate=@LastWorkingDate,TerminationReason=@TerminationReason,ReasonText=@ReasonText
  WHERE CmpID=@CmpID AND TerminationID=@TerminationID AND TerminationState=0;
  IF @@ROWCOUNT=0 THROW 54188,N'طلب إنهاء الخدمة غير موجود أو غير قابل للتعديل.',1;
 END;
 SELECT @TerminationID TerminationID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveClearanceItem
 @CmpID INT,@ClearanceID BIGINT=0,@TerminationID BIGINT,@ItemName NVARCHAR(200),@ResponsibleUser BIGINT=NULL,
 @ItemState TINYINT=0,@Notes NVARCHAR(500)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @ItemState NOT IN(0,1,2) THROW 54189,N'حالة إخلاء الطرف غير صحيحة.',1;
 IF @ClearanceID=0
 BEGIN
  INSERT dbo.Emp_ClearanceItems(CmpID,TerminationID,ItemName,ResponsibleUser,ItemState,CompletedAt,Notes)
  VALUES(@CmpID,@TerminationID,@ItemName,@ResponsibleUser,@ItemState,CASE WHEN @ItemState=1 THEN SYSDATETIME() END,@Notes);
  SET @ClearanceID=SCOPE_IDENTITY();
 END
 ELSE
 BEGIN
  UPDATE dbo.Emp_ClearanceItems SET ItemName=@ItemName,ResponsibleUser=@ResponsibleUser,ItemState=@ItemState,
   CompletedAt=CASE WHEN @ItemState=1 THEN SYSDATETIME() ELSE NULL END,Notes=@Notes
  WHERE CmpID=@CmpID AND ClearanceID=@ClearanceID;
  IF @@ROWCOUNT=0 THROW 54190,N'بند إخلاء الطرف غير موجود.',1;
 END;
 SELECT @ClearanceID ClearanceID;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveFinalSettlement
 @CmpID INT,@TerminationID BIGINT,@CurrencyID BIGINT,@GrossEntitlements DECIMAL(19,3),@Deductions DECIMAL(19,3),
 @CalculationDetails NVARCHAR(MAX)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @GrossEntitlements<0 OR @Deductions<0 THROW 54191,N'مبالغ التسوية لا يمكن أن تكون سالبة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Acc_Currency WHERE CurCmp=@CmpID AND CurID=@CurrencyID AND CurState=0) THROW 54194,N'عملة التسوية غير صالحة للشركة.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_ClearanceItems WHERE CmpID=@CmpID AND TerminationID=@TerminationID AND ItemState<>1)
  THROW 54192,N'لا يمكن حفظ التسوية قبل اكتمال جميع بنود إخلاء الطرف.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_FinalSettlements WHERE CmpID=@CmpID AND TerminationID=@TerminationID AND SettlementState<>0)
  THROW 54193,N'التسوية ليست في حالة مسودة ولا تقبل التعديل.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_FinalSettlements WHERE CmpID=@CmpID AND TerminationID=@TerminationID)
  UPDATE dbo.Emp_FinalSettlements SET CurrencyID=@CurrencyID,GrossEntitlements=@GrossEntitlements,Deductions=@Deductions,CalculationDetails=@CalculationDetails,CalculatedAt=SYSDATETIME(),CalculatedBy=@UserID
  WHERE CmpID=@CmpID AND TerminationID=@TerminationID AND SettlementState=0;
 ELSE
  INSERT dbo.Emp_FinalSettlements(CmpID,TerminationID,CurrencyID,GrossEntitlements,Deductions,CalculationDetails,CalculatedBy)
  VALUES(@CmpID,@TerminationID,@CurrencyID,@GrossEntitlements,@Deductions,@CalculationDetails,@UserID);
 SELECT SettlementID,NetAmount FROM dbo.Emp_FinalSettlements WHERE CmpID=@CmpID AND TerminationID=@TerminationID;
END;
GO
/* ================================================================
   14B. UNIFIED ATTENDANCE INGESTION
   ================================================================ */
CREATE OR ALTER PROCEDURE dbo.Emp_ReceiveAttendanceBatch
 @CmpID INT,@UserID BIGINT,@Source TINYINT,@Rows dbo.Emp_AttendanceBatchType READONLY,
 @DeviceID BIGINT=NULL,@SyncID BIGINT=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @Source NOT IN(1,2,3) THROW 54150,N'مصدر الحضور يجب أن يكون Pull أو Push أو File Import.',1;
 IF @Source IN(1,2) AND @DeviceID IS NULL THROW 54151,N'يجب تحديد الجهاز لمصدر Pull أو Push.',1;
 IF @DeviceID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Emp_AttendanceDevices WHERE DeviceCmp=@CmpID AND DeviceID=@DeviceID AND DeviceState=0)
  THROW 54152,N'الجهاز غير موجود أو غير نشط في الشركة.',1;
 IF @SyncID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Emp_AttendanceDeviceSyncLog WHERE SyncCmp=@CmpID AND SyncID=@SyncID AND SyncDeviceID=@DeviceID AND SyncSource=@Source)
  THROW 54153,N'سجل المزامنة لا يطابق الشركة والجهاز والمصدر.',1;
 DECLARE @Received INT=(SELECT COUNT(*) FROM @Rows),@Rejected INT=0,@Inserted INT=0,@Duplicates INT=0,@ValidCount INT=0;
 SELECT @Rejected=COUNT(*) FROM @Rows r
 WHERE r.PunchType NOT IN(1,2)
    OR (@Source=1 AND NULLIF(r.DeviceRecordID,N'') IS NULL)
    OR NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee e WHERE e.EmpCompany=@CmpID AND e.EmpID=r.EmployeeID);
 DECLARE @Valid TABLE(EmployeeID BIGINT,PunchAt DATETIME2(0),PunchType TINYINT,DeviceRecordID NVARCHAR(100),DedupHash VARBINARY(32));
 INSERT @Valid(EmployeeID,PunchAt,PunchType,DeviceRecordID,DedupHash)
 SELECT r.EmployeeID,r.PunchAt,r.PunchType,r.DeviceRecordID,
        HASHBYTES('SHA2_256',CONVERT(VARBINARY(MAX),CONCAT(@CmpID,N'|',ISNULL(CONVERT(NVARCHAR(30),@DeviceID),N''),N'|',
          CASE WHEN NULLIF(r.DeviceRecordID,N'') IS NOT NULL THEN N'ID:'+r.DeviceRecordID
               ELSE N'TS:'+CONVERT(NVARCHAR(30),r.PunchAt,126)+N'|'+CONVERT(NVARCHAR(20),r.EmployeeID)+N'|'+CONVERT(NVARCHAR(2),r.PunchType) END)))
 FROM @Rows r
 WHERE r.PunchType IN(1,2) AND (@Source<>1 OR NULLIF(r.DeviceRecordID,N'') IS NOT NULL)
   AND EXISTS(SELECT 1 FROM dbo.Emp_Employee e WHERE e.EmpCompany=@CmpID AND e.EmpID=r.EmployeeID);
 SELECT @ValidCount=COUNT(*) FROM @Valid;
 BEGIN TRAN;
 ;WITH Ranked AS
 (SELECT v.*,ROW_NUMBER() OVER(PARTITION BY v.DedupHash ORDER BY v.EmployeeID,v.PunchAt) AS rn FROM @Valid v)
 INSERT dbo.Emp_AttendanceTransactions(AttCmp,AttEmpID,AttDateTime,AttType,AttSource,AttDeviceID,AttDeviceRecordID,AttState,AttDateTimeCreated,AttUser,AttSyncID,AttDedupHash)
 SELECT @CmpID,v.EmployeeID,v.PunchAt,v.PunchType,@Source,@DeviceID,v.DeviceRecordID,0,SYSDATETIME(),@UserID,@SyncID,v.DedupHash
 FROM Ranked v
 WHERE v.rn=1 AND NOT EXISTS(SELECT 1 FROM dbo.Emp_AttendanceTransactions t WITH(UPDLOCK,HOLDLOCK) WHERE t.AttCmp=@CmpID AND t.AttDedupHash=v.DedupHash);
 SET @Inserted=@@ROWCOUNT;
 SET @Duplicates=@ValidCount-@Inserted;
 IF @SyncID IS NOT NULL
  UPDATE dbo.Emp_AttendanceDeviceSyncLog
   SET SyncReceivedCount=@Received,SyncInsertedCount=@Inserted,SyncDuplicateCount=@Duplicates,SyncRejectedCount=@Rejected,
       SyncFinishedAt=SYSDATETIME(),SyncStatus=CASE WHEN @Rejected>0 THEN 2 ELSE 1 END,SyncUser=@UserID
   WHERE SyncCmp=@CmpID AND SyncID=@SyncID;
 COMMIT;
 SELECT @Received ReceivedCount,@Inserted InsertedCount,@Duplicates DuplicateCount,@Rejected RejectedCount;
 SELECT r.* FROM @Rows r WHERE r.PunchType NOT IN(1,2)
    OR (@Source=1 AND NULLIF(r.DeviceRecordID,N'') IS NULL)
    OR NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee e WHERE e.EmpCompany=@CmpID AND e.EmpID=r.EmployeeID);
END;
GO
/* ================================================================
   15. SECURITY / INTEGRITY / COVERAGE CHECKS
   ================================================================ */
-- Guard against multiple active base salary rows for one employee/date.
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_Salary') AND name=N'UX_Emp_Salary_OneActiveStart')
 AND OBJECT_ID(N'dbo.Emp_Salary',N'U') IS NOT NULL
BEGIN
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Salary GROUP BY EmpCompany,EmpID HAVING SUM(CASE WHEN SalEndDate IS NULL THEN 1 ELSE 0 END)>1)
  CREATE UNIQUE INDEX UX_Emp_Salary_OneActiveStart ON dbo.Emp_Salary(EmpCompany,EmpID) WHERE SalEndDate IS NULL;
END;
GO
-- Ensure all added company-scoped tables point to an existing company.
DECLARE @CompanyTables TABLE(T SYSNAME);
INSERT @CompanyTables VALUES
(N'Emp_EmployeeDocuments'),(N'Emp_EmployeeContacts'),(N'Emp_EmployeeAddresses'),(N'Emp_EmployeeExperience'),(N'Emp_EmployeeSkills'),(N'Emp_ServiceHistory'),
(N'Emp_Candidates'),(N'Emp_JobApplications'),(N'Emp_LeaveTypes'),(N'Emp_LeavePolicies'),(N'Emp_LeavePolicyTypes'),(N'Emp_EmployeeLeavePolicies'),(N'Emp_LeaveBalances'),(N'Emp_LeaveBalanceTransactions'),(N'Emp_LeaveRequests'),(N'Emp_LeaveApprovals'),
(N'Emp_PayComponents'),(N'Emp_PayPolicies'),(N'Emp_EmployeePayComponents'),(N'Emp_PayPeriods'),(N'Emp_PayRuns'),(N'Emp_PayrollDetails'),(N'Emp_PayrollAccountMappings'),
(N'Emp_OvertimeRequests'),(N'Emp_RewardsPenalties'),(N'Emp_Loans'),(N'Emp_LoanInstallments'),(N'Emp_PerformanceCycles'),(N'Emp_PerformanceReviews'),(N'Emp_TrainingCourses'),(N'Emp_TrainingRecords'),
(N'Emp_Terminations'),(N'Emp_ClearanceItems'),(N'Emp_FinalSettlements'),(N'Emp_AttendanceConnectorConfigs');
DECLARE @T SYSNAME,@sql NVARCHAR(MAX);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT T FROM @CompanyTables;
OPEN c; FETCH NEXT FROM c INTO @T;
WHILE @@FETCH_STATUS=0
BEGIN
 IF OBJECT_ID(N'dbo.'+@T,N'U') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id=OBJECT_ID(N'dbo.'+@T) AND name=N'FK_'+@T+N'_Company')
 BEGIN
  SET @sql=N'ALTER TABLE dbo.'+QUOTENAME(@T)+N' WITH CHECK ADD CONSTRAINT '+QUOTENAME(N'FK_'+@T+N'_Company')+N' FOREIGN KEY(CmpID) REFERENCES dbo.Mng_Company(CmpID); ALTER TABLE dbo.'+QUOTENAME(@T)+N' CHECK CONSTRAINT '+QUOTENAME(N'FK_'+@T+N'_Company')+N';';
  EXEC sys.sp_executesql @sql;
 END;
 FETCH NEXT FROM c INTO @T;
END;
CLOSE c; DEALLOCATE c;
GO

/* ================================================================
   16. INSTALLATION REPORT
   ================================================================ */
SELECT N'HR extension objects' AS ReportSection,
       (SELECT COUNT(*) FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo') AND name LIKE N'Emp[_]%') AS TotalHRTables,
       (SELECT COUNT(*) FROM sys.procedures WHERE schema_id=SCHEMA_ID(N'dbo') AND name LIKE N'Emp[_]%') AS TotalHRProcedures,
       (SELECT COUNT(*) FROM sys.foreign_keys WHERE parent_object_id IN(SELECT object_id FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo') AND name LIKE N'Emp[_]%')) AS HRForeignKeys,
       (SELECT COUNT(*) FROM sys.check_constraints WHERE parent_object_id IN(SELECT object_id FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo') AND name LIKE N'Emp[_]%')) AS HRCheckConstraints,
       (SELECT COUNT(*) FROM sys.indexes WHERE object_id IN(SELECT object_id FROM sys.tables WHERE schema_id=SCHEMA_ID(N'dbo') AND name LIKE N'Emp[_]%') AND index_id>0) AS HRIndexes;
GO

/* =====================================================================
   MADAR ERP - تعديلات مقترحة (فهارس + مفاتيح أجنبية لـ Wrh_Layer)
   - لم يُنفَّذ هذا السكريبت ولم يُختبر؛ جرّبه على نسخة قبل الإنتاج.
   - قابل لإعادة التشغيل (يتحقق من وجود الفهرس/المفتاح قبل الإنشاء).
   - ONLINE = ON يتطلب Enterprise (متوفر في إصدارك).
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON; SET QUOTED_IDENTIFIER ON; SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON; SET ARITHABORT ON; SET CONCAT_NULL_YIELDS_NULL ON; SET NUMERIC_ROUNDABORT OFF;
GO

/* ---------------------------------------------------------------------
   1) فهارس ناقصة (مرتبة حسب الأهمية)
   --------------------------------------------------------------------- */

-- Wrh_Doc: قوائم المستندات (Wrh_SelectDocs) حسب النوع والتاريخ
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_Type_Date' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Doc_Type_Date
        ON dbo.Wrh_Doc (DocCmpID, DocType, DocDate DESC)
        INCLUDE (DocStatus, DocWhID, DocPartyID, DocNo)
        WITH (ONLINE = ON);
GO
-- Wrh_Doc: المخزن (طلبات المواد، الجرد، الصرف)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_Wh' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Doc_Wh
        ON dbo.Wrh_Doc (DocWhID, DocType)
        WHERE DocWhID IS NOT NULL
        WITH (ONLINE = ON);
GO
-- Wrh_Doc: الجهة (مورد/عهدة)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_Party' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Doc_Party
        ON dbo.Wrh_Doc (DocPartyID)
        WHERE DocPartyID IS NOT NULL
        WITH (ONLINE = ON);
GO
-- Wrh_Doc: المستند المرجعي (يُستعمل أيضًا عند الحذف للتحقق من المفتاح الأجنبي)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_RefDoc' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Doc_RefDoc
        ON dbo.Wrh_Doc (DocRefDocID)
        WHERE DocRefDocID IS NOT NULL
        WITH (ONLINE = ON);
GO
-- Wrh_Doc: مركز التكلفة (Wrh_SuggestReturnCostCore)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_CostCenter' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Doc_CostCenter
        ON dbo.Wrh_Doc (DocCostCID, DocType, DocDate DESC)
        WHERE DocCostCID IS NOT NULL
        WITH (ONLINE = ON);
GO
-- Wrh_Doc: المخزن المقابل في التحويلات
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_Wh2' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Doc_Wh2
        ON dbo.Wrh_Doc (DocWh2ID)
        WHERE DocWh2ID IS NOT NULL
        WITH (ONLINE = ON);
GO

-- Wrh_DocLine: حركة الصنف
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_DocLine_Item' AND object_id = OBJECT_ID(N'dbo.Wrh_DocLine'))
    CREATE NONCLUSTERED INDEX IX_Wrh_DocLine_Item
        ON dbo.Wrh_DocLine (ItemID)
        INCLUDE (DocID, BaseQty, QtyReferred, QtyCancelled)
        WITH (ONLINE = ON);
GO

-- Wrh_Stock: أرصدة الصنف عبر المخازن (المفتاح الأساسي يبدأ بالمخزن)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Stock_Item' AND object_id = OBJECT_ID(N'dbo.Wrh_Stock'))
    CREATE NONCLUSTERED INDEX IX_Wrh_Stock_Item
        ON dbo.Wrh_Stock (StkItemID, StkWhID)
        INCLUDE (StkQty, StkReserved)
        WITH (ONLINE = ON);
GO

-- Wrh_CostAdjLayer: البحث بالطبقة (المفتاح الأساسي يبدأ بـ AdjID)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_CostAdjLayer_Layer' AND object_id = OBJECT_ID(N'dbo.Wrh_CostAdjLayer'))
    CREATE NONCLUSTERED INDEX IX_Wrh_CostAdjLayer_Layer
        ON dbo.Wrh_CostAdjLayer (LayerID)
        WITH (ONLINE = ON);
GO

-- Acc_AutoVoucherLine: ربط البند بسطر القيد (FK بـ ON DELETE SET NULL يحتاج هذا الفهرس)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Acc_AutoVoucherLine_DayD' AND object_id = OBJECT_ID(N'dbo.Acc_AutoVoucherLine'))
    CREATE NONCLUSTERED INDEX IX_Acc_AutoVoucherLine_DayD
        ON dbo.Acc_AutoVoucherLine (DayDID)
        WHERE DayDID IS NOT NULL
        WITH (ONLINE = ON);
GO

-- Acc_DayDetailsHistory: البحث بالحساب ومركز التكلفة
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Acc_DayDetailsHistory_Acc' AND object_id = OBJECT_ID(N'dbo.Acc_DayDetailsHistory'))
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetailsHistory_Acc
        ON dbo.Acc_DayDetailsHistory (DayDHAccID)
        WITH (ONLINE = ON);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Acc_DayDetailsHistory_CsC' AND object_id = OBJECT_ID(N'dbo.Acc_DayDetailsHistory'))
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetailsHistory_CsC
        ON dbo.Acc_DayDetailsHistory (DayDHCsCID)
        WHERE DayDHCsCID IS NOT NULL
        WITH (ONLINE = ON);
GO

-- Msg_MessageAttachment: مرفقات الرسالة
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Msg_MessageAttachment_Message' AND object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    CREATE NONCLUSTERED INDEX IX_Msg_MessageAttachment_Message
        ON dbo.Msg_MessageAttachment (MessageID, State)
        INCLUDE (FileName, ContentType, FileSize, UploadedAt)
        WITH (ONLINE = ON);
GO

-- Msg_ConversationMember: محادثات المستخدم (Msg_GetConversations)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Msg_ConversationMember_User' AND object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    CREATE NONCLUSTERED INDEX IX_Msg_ConversationMember_User
        ON dbo.Msg_ConversationMember (UserID, State, LeftAt)
        INCLUDE (ConversationID)
        WITH (ONLINE = ON);
GO

-- Msg_MessageReceipt: غير المقروء للمستخدم
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Msg_MessageReceipt_User' AND object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt'))
    CREATE NONCLUSTERED INDEX IX_Msg_MessageReceipt_User
        ON dbo.Msg_MessageReceipt (UserID, State, ReadAt)
        INCLUDE (MessageID, DeliveredAt)
        WITH (ONLINE = ON);
GO

/* ---------------------------------------------------------------------
   2) مفاتيح أجنبية لـ Wrh_Layer
      ملاحظة: LyRootID و LySrcLineID بلا مفتاح أجنبي عمدًا:
        - LyRootID يُدرج بالقيمة 0 ثم يُحدَّث إلى LayerID.
        - LySrcLineID يحمل قيمًا سالبة (-CntLineID) لطبقات الجرد.
   --------------------------------------------------------------------- */

-- فحص مسبق: يجب أن تُرجع الاستعلامات التالية 0 قبل إضافة المفاتيح
SELECT 'Layer->Company'   AS Chk, COUNT(*) AS Orphans FROM dbo.Wrh_Layer l WHERE NOT EXISTS (SELECT 1 FROM dbo.Mng_Company  c WHERE c.CmpID  = l.LyCmpID)
UNION ALL
SELECT 'Layer->Warehouse', COUNT(*) FROM dbo.Wrh_Layer l WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse w WHERE w.WhID   = l.LyWhID)
UNION ALL
SELECT 'Layer->Item',      COUNT(*) FROM dbo.Wrh_Layer l WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Item      i WHERE i.ItemID = l.LyItemID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Wrh_Layer_Company')
    ALTER TABLE dbo.Wrh_Layer WITH CHECK
        ADD CONSTRAINT FK_Wrh_Layer_Company FOREIGN KEY (LyCmpID) REFERENCES dbo.Mng_Company (CmpID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Wrh_Layer_Warehouse')
    ALTER TABLE dbo.Wrh_Layer WITH CHECK
        ADD CONSTRAINT FK_Wrh_Layer_Warehouse FOREIGN KEY (LyWhID) REFERENCES dbo.Wrh_Warehouse (WhID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Wrh_Layer_Item')
    ALTER TABLE dbo.Wrh_Layer WITH CHECK
        ADD CONSTRAINT FK_Wrh_Layer_Item FOREIGN KEY (LyItemID) REFERENCES dbo.Wrh_Item (ItemID);
GO

/* ---------------------------------------------------------------------
   3) نسخ سجل المعاملات (RECOMPUTE: عدّل المسار والجدولة حسب بيئتك)
      القاعدة بوضع RECOVERY FULL؛ بدون نسخ دوري للسجل سيتضخم الملف.
      الأفضل جدولته عبر SQL Server Agent كل 15-60 دقيقة.
   --------------------------------------------------------------------- */
/*
BACKUP LOG [MADARERPDataBase]
TO DISK = N'D:\Backups\MADARERPDataBase_log.trn'
WITH COMPRESSION, CHECKSUM, INIT;
*/

/* ---------------------------------------------------------------------
   4) بعد التنفيذ: تحقق من عدم وجود فهارس غير مستعملة بعد أسبوعين
   --------------------------------------------------------------------- */
/*
SELECT OBJECT_NAME(i.object_id) AS TableName, i.name AS IndexName,
       s.user_seeks, s.user_scans, s.user_lookups, s.user_updates
FROM sys.indexes i
LEFT JOIN sys.dm_db_index_usage_stats s
       ON s.object_id = i.object_id AND s.index_id = i.index_id AND s.database_id = DB_ID()
WHERE i.name LIKE N'IX[_]Wrh[_]%' OR i.name LIKE N'IX[_]Msg[_]%' OR i.name LIKE N'IX[_]Acc[_]%'
ORDER BY ISNULL(s.user_seeks, 0) + ISNULL(s.user_scans, 0);
*/

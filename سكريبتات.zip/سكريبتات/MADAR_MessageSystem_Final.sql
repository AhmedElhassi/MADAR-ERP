﻿USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/*
    MADAR Message System - company-separated conversations

    Identity:
      Mng_User.UsrID = Emp_Employee.EmpID (BIGINT).

    Business rules:
      - The active company selected at login defines the conversation scope.
      - A user may access multiple companies; UsrCompany and EmpCompany are
        NOT used to authorize or filter message conversations.
      - The application must pass @CompanyID from trusted server-side session
        context and validate that the company is active and accessible to
        the logged-in user before calling these procedures.
      - ConversationCompanyID is the only company ownership field.
      - Messages, receipts and attachments inherit scope through ConversationID.
      - Conversation access requires active membership.
      - No Mng_UserSystem table is used.

    Migration:
      ConversationCompanyID remains NULL for legacy rows until a verified
      company mapping is available. Do not guess company ownership.
*/

-------------------------------------------------------------------------------
-- 1. TABLES
-------------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_Conversation
    (
        ConversationID BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_Msg_Conversation PRIMARY KEY CLUSTERED,
        ConversationType TINYINT NOT NULL,
        ConversationTitle NVARCHAR(200) NULL,
        CreatedByUserID BIGINT NOT NULL,
        DirectUser1ID BIGINT NULL,
        DirectUser2ID BIGINT NULL,
        ConversationCompanyID INT NULL,
        CreatedAt DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_Conversation_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        State TINYINT NOT NULL
            CONSTRAINT DF_Msg_Conversation_State DEFAULT ((0))
    );
END;
GO

IF COL_LENGTH(N'dbo.Msg_Conversation', N'ConversationCompanyID') IS NULL
    ALTER TABLE dbo.Msg_Conversation ADD ConversationCompanyID INT NULL;
GO

IF OBJECT_ID(N'dbo.Msg_ConversationMember', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_ConversationMember
    (
        ConversationMemberID BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_Msg_ConversationMember PRIMARY KEY CLUSTERED,
        ConversationID BIGINT NOT NULL,
        UserID BIGINT NOT NULL,
        MemberRole TINYINT NOT NULL
            CONSTRAINT DF_Msg_ConversationMember_Role DEFAULT ((0)),
        JoinedAt DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_ConversationMember_JoinedAt DEFAULT (SYSDATETIME()),
        LeftAt DATETIME2(0) NULL,
        State TINYINT NOT NULL
            CONSTRAINT DF_Msg_ConversationMember_State DEFAULT ((0)),
        CONSTRAINT UQ_Msg_ConversationMember_Conversation_User
            UNIQUE (ConversationID, UserID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_Message', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_Message
    (
        MessageID BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_Msg_Message PRIMARY KEY CLUSTERED,
        ConversationID BIGINT NOT NULL,
        SenderUserID BIGINT NOT NULL,
        MessageText NVARCHAR(MAX) NULL,
        SentAt DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_Message_SentAt DEFAULT (SYSDATETIME()),
        EditedAt DATETIME2(0) NULL,
        IsDeleted BIT NOT NULL
            CONSTRAINT DF_Msg_Message_IsDeleted DEFAULT ((0)),
        DeletedAt DATETIME2(0) NULL,
        State TINYINT NOT NULL
            CONSTRAINT DF_Msg_Message_State DEFAULT ((0))
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_MessageAttachment', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_MessageAttachment
    (
        AttachmentID BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_Msg_MessageAttachment PRIMARY KEY CLUSTERED,
        MessageID BIGINT NOT NULL,
        FileName NVARCHAR(260) NOT NULL,
        ContentType NVARCHAR(150) NULL,
        FileSize BIGINT NOT NULL,
        FileData VARBINARY(MAX) NOT NULL,
        UploadedAt DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_MessageAttachment_UploadedAt DEFAULT (SYSDATETIME()),
        State TINYINT NOT NULL
            CONSTRAINT DF_Msg_MessageAttachment_State DEFAULT ((0))
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_MessageReceipt', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_MessageReceipt
    (
        ReceiptID BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_Msg_MessageReceipt PRIMARY KEY CLUSTERED,
        MessageID BIGINT NOT NULL,
        UserID BIGINT NOT NULL,
        DeliveredAt DATETIME2(0) NULL,
        ReadAt DATETIME2(0) NULL,
        State TINYINT NOT NULL
            CONSTRAINT DF_Msg_MessageReceipt_State DEFAULT ((0)),
        CONSTRAINT UQ_Msg_MessageReceipt_Message_User UNIQUE (MessageID, UserID)
    );
END;
GO

-------------------------------------------------------------------------------
-- 2. FOREIGN KEYS AND CHECK CONSTRAINTS
-- Constraint existence is checked against the owning object as well as name.
-------------------------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Conversation')
                 AND name=N'FK_Msg_Conversation_Creator')
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
    ADD CONSTRAINT FK_Msg_Conversation_Creator
    FOREIGN KEY (CreatedByUserID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Conversation')
                 AND name=N'FK_Msg_Conversation_DirectUser1')
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
    ADD CONSTRAINT FK_Msg_Conversation_DirectUser1
    FOREIGN KEY (DirectUser1ID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Conversation')
                 AND name=N'FK_Msg_Conversation_DirectUser2')
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
    ADD CONSTRAINT FK_Msg_Conversation_DirectUser2
    FOREIGN KEY (DirectUser2ID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_ConversationMember')
                 AND name=N'FK_Msg_ConversationMember_Conversation')
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK
    ADD CONSTRAINT FK_Msg_ConversationMember_Conversation
    FOREIGN KEY (ConversationID) REFERENCES dbo.Msg_Conversation(ConversationID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_ConversationMember')
                 AND name=N'FK_Msg_ConversationMember_User')
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK
    ADD CONSTRAINT FK_Msg_ConversationMember_User
    FOREIGN KEY (UserID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Message')
                 AND name=N'FK_Msg_Message_Conversation')
    ALTER TABLE dbo.Msg_Message WITH CHECK
    ADD CONSTRAINT FK_Msg_Message_Conversation
    FOREIGN KEY (ConversationID) REFERENCES dbo.Msg_Conversation(ConversationID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Message')
                 AND name=N'FK_Msg_Message_Sender')
    ALTER TABLE dbo.Msg_Message WITH CHECK
    ADD CONSTRAINT FK_Msg_Message_Sender
    FOREIGN KEY (SenderUserID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_MessageAttachment')
                 AND name=N'FK_Msg_MessageAttachment_Message')
    ALTER TABLE dbo.Msg_MessageAttachment WITH CHECK
    ADD CONSTRAINT FK_Msg_MessageAttachment_Message
    FOREIGN KEY (MessageID) REFERENCES dbo.Msg_Message(MessageID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_MessageReceipt')
                 AND name=N'FK_Msg_MessageReceipt_Message')
    ALTER TABLE dbo.Msg_MessageReceipt WITH CHECK
    ADD CONSTRAINT FK_Msg_MessageReceipt_Message
    FOREIGN KEY (MessageID) REFERENCES dbo.Msg_Message(MessageID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_MessageReceipt')
                 AND name=N'FK_Msg_MessageReceipt_User')
    ALTER TABLE dbo.Msg_MessageReceipt WITH CHECK
    ADD CONSTRAINT FK_Msg_MessageReceipt_User
    FOREIGN KEY (UserID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Conversation')
                 AND name=N'CK_Msg_Conversation_Structure')
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
    ADD CONSTRAINT CK_Msg_Conversation_Structure CHECK
    (
       (ConversationType=0 AND DirectUser1ID IS NOT NULL
        AND DirectUser2ID IS NOT NULL AND DirectUser1ID<DirectUser2ID
        AND ConversationTitle IS NULL)
       OR
       (ConversationType=1 AND DirectUser1ID IS NULL
        AND DirectUser2ID IS NULL
        AND NULLIF(LTRIM(RTRIM(ConversationTitle)),N'') IS NOT NULL)
    );
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_Conversation')
                 AND name=N'CK_Msg_Conversation_Type')
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
    ADD CONSTRAINT CK_Msg_Conversation_Type CHECK (ConversationType IN (0,1));
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_ConversationMember')
                 AND name=N'CK_Msg_ConversationMember_Role')
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK
    ADD CONSTRAINT CK_Msg_ConversationMember_Role CHECK (MemberRole IN (0,1));
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE parent_object_id=OBJECT_ID(N'dbo.Msg_MessageAttachment')
                 AND name=N'CK_Msg_MessageAttachment_FileSize')
    ALTER TABLE dbo.Msg_MessageAttachment WITH CHECK
    ADD CONSTRAINT CK_Msg_MessageAttachment_FileSize CHECK (FileSize>0);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id=OBJECT_ID(N'dbo.Msg_Conversation')
                 AND name=N'IX_Msg_Conversation_Company_State_Updated')
    CREATE INDEX IX_Msg_Conversation_Company_State_Updated
    ON dbo.Msg_Conversation
       (ConversationCompanyID, State, UpdatedAt DESC, ConversationID DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id=OBJECT_ID(N'dbo.Msg_Message')
                 AND name=N'IX_Msg_Message_Conversation_Message')
    CREATE INDEX IX_Msg_Message_Conversation_Message
    ON dbo.Msg_Message(ConversationID, State, MessageID DESC);
GO

-------------------------------------------------------------------------------
-- 3. STORED PROCEDURES
-------------------------------------------------------------------------------

CREATE OR ALTER PROCEDURE dbo.Msg_CreateConversation
    @ConversationType TINYINT,
    @CreatedByUserID BIGINT,
    @ConversationID BIGINT OUTPUT,
    @CompanyID INT,
    @OtherUserID BIGINT = NULL,
    @ConversationTitle NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @ConversationID=NULL;

    IF @CompanyID IS NULL
        THROW 51000,N'يجب تحديد الشركة الحالية.',1;
    IF @ConversationType NOT IN (0,1)
        THROW 51002,N'نوع المحادثة غير صحيح.',1;

    -- User account must be active. Company authorization is validated by the
    -- application using its trusted multi-company access context.
    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User
        WHERE UsrID=@CreatedByUserID AND UsrState=0
    )
        THROW 51001,N'منشئ المحادثة غير موجود أو حسابه غير فعال.',1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF @ConversationType=0
        BEGIN
            IF @OtherUserID IS NULL OR @OtherUserID=@CreatedByUserID
                THROW 51003,N'حدد مستخدماً آخر للمحادثة الفردية.',1;

            IF NOT EXISTS
            (
                SELECT 1 FROM dbo.Mng_User
                WHERE UsrID=@OtherUserID AND UsrState=0
            )
                THROW 51004,N'المستخدم الآخر غير موجود أو حسابه غير فعال.',1;

            DECLARE @U1 BIGINT =
                CASE WHEN @CreatedByUserID<@OtherUserID
                     THEN @CreatedByUserID ELSE @OtherUserID END;
            DECLARE @U2 BIGINT =
                CASE WHEN @CreatedByUserID<@OtherUserID
                     THEN @OtherUserID ELSE @CreatedByUserID END;

            SET @ConversationID=NULL;

            SELECT TOP(1) @ConversationID=ConversationID
            FROM dbo.Msg_Conversation WITH(UPDLOCK,HOLDLOCK)
            WHERE ConversationType=0 AND State=0
              AND ConversationCompanyID=@CompanyID
              AND DirectUser1ID=@U1 AND DirectUser2ID=@U2
            ORDER BY ConversationID DESC;

            IF @ConversationID IS NULL
            BEGIN
                INSERT dbo.Msg_Conversation
                    (ConversationType,CreatedByUserID,DirectUser1ID,
                     DirectUser2ID,ConversationCompanyID,State)
                VALUES
                    (0,@CreatedByUserID,@U1,@U2,@CompanyID,0);

                SET @ConversationID=CONVERT(BIGINT,SCOPE_IDENTITY());
            END;

            -- Avoid MERGE. Reactivate existing memberships, then insert missing.
            UPDATE CM
               SET State=0, LeftAt=NULL, JoinedAt=SYSDATETIME()
            FROM dbo.Msg_ConversationMember CM
            WHERE CM.ConversationID=@ConversationID
              AND CM.UserID IN (@U1,@U2)
              AND (CM.State<>0 OR CM.LeftAt IS NOT NULL);

            INSERT dbo.Msg_ConversationMember
                (ConversationID,UserID,MemberRole,State)
            SELECT @ConversationID,V.UserID,0,0
            FROM (VALUES(@U1),(@U2)) V(UserID)
            WHERE NOT EXISTS
            (
                SELECT 1 FROM dbo.Msg_ConversationMember CM
                WHERE CM.ConversationID=@ConversationID
                  AND CM.UserID=V.UserID
            );
        END
        ELSE
        BEGIN
            SET @ConversationTitle=LTRIM(RTRIM(@ConversationTitle));
            IF NULLIF(@ConversationTitle,N'') IS NULL
                THROW 51005,N'اسم المجموعة مطلوب.',1;

            INSERT dbo.Msg_Conversation
                (ConversationType,ConversationTitle,CreatedByUserID,
                 ConversationCompanyID,State)
            VALUES
                (1,@ConversationTitle,@CreatedByUserID,@CompanyID,0);

            SET @ConversationID=CONVERT(BIGINT,SCOPE_IDENTITY());

            INSERT dbo.Msg_ConversationMember
                (ConversationID,UserID,MemberRole,State)
            VALUES(@ConversationID,@CreatedByUserID,1,0);
        END;

        UPDATE dbo.Msg_Conversation
           SET UpdatedAt=SYSDATETIME()
        WHERE ConversationID=@ConversationID
          AND ConversationCompanyID=@CompanyID;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        SET @ConversationID=NULL;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetConversations
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51090,N'يجب تحديد الشركة الحالية.',1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User
        WHERE UsrID=@UserID AND UsrState=0
    )
        THROW 51091,N'المستخدم غير موجود أو حسابه غير فعال.',1;

    SELECT
        C.ConversationID,
        C.ConversationType,
        C.ConversationTitle,
        C.CreatedAt,
        C.UpdatedAt,
        CASE
          WHEN C.ConversationType=1 THEN C.ConversationTitle
          ELSE COALESCE
          (
            NULLIF
            (
              LTRIM(RTRIM(CONCAT
              (
                COALESCE(EO.EmpNum,N''),
                CASE WHEN NULLIF(EO.EmpNum,N'') IS NOT NULL
                           AND NULLIF(EO.EmpName,N'') IS NOT NULL
                     THEN N' - ' ELSE N'' END,
                COALESCE(NULLIF(EO.EmpName,N''),
                         NULLIF(OU.UsrLogIn,N''),N'مستخدم')
              ))),N''),
            N'محادثة فردية'
          )
        END AS DisplayName,
        LM.MessageID AS LastMessageID,
        CASE WHEN LM.IsDeleted=1
             THEN N'تم حذف الرسالة' ELSE LM.MessageText END AS LastMessageText,
        LM.SentAt AS LastMessageAt,
        LM.SenderUserID AS LastSenderUserID,
        (
            SELECT COUNT_BIG(*)
            FROM dbo.Msg_MessageReceipt R
            JOIN dbo.Msg_Message M2 ON M2.MessageID=R.MessageID
            WHERE M2.ConversationID=C.ConversationID
              AND R.UserID=@UserID
              AND R.ReadAt IS NULL AND R.State=0
              AND M2.SenderUserID<>@UserID
              AND M2.IsDeleted=0 AND M2.State=0
        ) AS UnreadCount,
        C.CreatedByUserID
    FROM dbo.Msg_Conversation C
    JOIN dbo.Msg_ConversationMember Mine
      ON Mine.ConversationID=C.ConversationID
     AND Mine.UserID=@UserID
     AND Mine.State=0 AND Mine.LeftAt IS NULL
    LEFT JOIN dbo.Mng_User OU
      ON OU.UsrID=
         CASE WHEN C.DirectUser1ID=@UserID
              THEN C.DirectUser2ID ELSE C.DirectUser1ID END
     AND C.ConversationType=0 AND OU.UsrState=0
    LEFT JOIN dbo.Emp_Employee EO
      ON EO.EmpID=OU.UsrID AND EO.EmpState=0
    OUTER APPLY
    (
        SELECT TOP(1)
            M.MessageID,M.MessageText,M.SentAt,M.SenderUserID,M.IsDeleted
        FROM dbo.Msg_Message M
        WHERE M.ConversationID=C.ConversationID AND M.State=0
        ORDER BY M.MessageID DESC
    ) LM
    WHERE C.State=0
      AND C.ConversationCompanyID=@CompanyID
    ORDER BY COALESCE(C.UpdatedAt,C.CreatedAt) DESC,
             C.ConversationID DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_SendMessage
    @ConversationID BIGINT,
    @SenderUserID BIGINT,
    @MessageText NVARCHAR(MAX),
    @MessageID BIGINT OUTPUT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @MessageID=NULL;
    SET @MessageText=LTRIM(RTRIM(@MessageText));

    IF @CompanyID IS NULL
        THROW 51020,N'يجب تحديد الشركة الحالية.',1;
    IF NULLIF(@MessageText,N'') IS NULL
        THROW 51021,N'نص الرسالة مطلوب.',1;
    IF DATALENGTH(@MessageText)>20000
        THROW 51022,N'الحد الأقصى للرسالة 10000 حرف.',1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User
        WHERE UsrID=@SenderUserID AND UsrState=0
    )
        THROW 51024,N'حساب المرسل غير موجود أو غير فعال.',1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_Conversation C WITH(UPDLOCK,HOLDLOCK)
            JOIN dbo.Msg_ConversationMember CM
              ON CM.ConversationID=C.ConversationID
            WHERE C.ConversationID=@ConversationID
              AND C.ConversationCompanyID=@CompanyID
              AND C.State=0
              AND CM.UserID=@SenderUserID
              AND CM.State=0 AND CM.LeftAt IS NULL
        )
            THROW 51023,N'المحادثة لا تتبع الشركة الحالية أو لا تملك صلاحية الإرسال إليها.',1;

        INSERT dbo.Msg_Message
            (ConversationID,SenderUserID,MessageText,State)
        VALUES(@ConversationID,@SenderUserID,@MessageText,0);

        SET @MessageID=CONVERT(BIGINT,SCOPE_IDENTITY());

        INSERT dbo.Msg_MessageReceipt
            (MessageID,UserID,DeliveredAt,ReadAt,State)
        SELECT
            @MessageID,CM.UserID,
            CASE WHEN CM.UserID=@SenderUserID THEN SYSDATETIME() END,
            CASE WHEN CM.UserID=@SenderUserID THEN SYSDATETIME() END,
            0
        FROM dbo.Msg_ConversationMember CM
        WHERE CM.ConversationID=@ConversationID
          AND CM.State=0 AND CM.LeftAt IS NULL;

        UPDATE dbo.Msg_Conversation
           SET UpdatedAt=SYSDATETIME()
        WHERE ConversationID=@ConversationID
          AND ConversationCompanyID=@CompanyID;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        SET @MessageID=NULL;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_EditMessage
    @MessageID BIGINT,
    @UserID BIGINT,
    @MessageText NVARCHAR(MAX),
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @MessageText=LTRIM(RTRIM(@MessageText));

    IF @CompanyID IS NULL
        THROW 51230,N'يجب تحديد الشركة الحالية.',1;
    IF NULLIF(@MessageText,N'') IS NULL
        THROW 51231,N'نص الرسالة مطلوب.',1;
    IF DATALENGTH(@MessageText)>20000
        THROW 51232,N'تجاوز نص الرسالة الحد المسموح (10000 حرف).',1;

    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE M
           SET MessageText=@MessageText,
               EditedAt=SYSDATETIME()
        FROM dbo.Msg_Message M
        JOIN dbo.Msg_Conversation C
          ON C.ConversationID=M.ConversationID
        JOIN dbo.Msg_ConversationMember CM
          ON CM.ConversationID=C.ConversationID
        WHERE M.MessageID=@MessageID
          AND M.SenderUserID=@UserID
          AND M.IsDeleted=0 AND M.State=0
          AND C.State=0
          AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID
          AND CM.State=0 AND CM.LeftAt IS NULL;

        IF @@ROWCOUNT=0
            THROW 51233,N'لا يمكن تعديل الرسالة أو أنها لم تعد متاحة.',1;

        -- Editing message text does not reset other members' read receipts.
        UPDATE C
           SET UpdatedAt=SYSDATETIME()
        FROM dbo.Msg_Conversation C
        JOIN dbo.Msg_Message M ON M.ConversationID=C.ConversationID
        WHERE M.MessageID=@MessageID
          AND C.ConversationCompanyID=@CompanyID;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_DeleteMessage
    @MessageID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @ConversationID BIGINT;

        SELECT @ConversationID=M.ConversationID
        FROM dbo.Msg_Message M WITH(UPDLOCK,HOLDLOCK)
        JOIN dbo.Msg_Conversation C
          ON C.ConversationID=M.ConversationID
        JOIN dbo.Msg_ConversationMember CM
          ON CM.ConversationID=C.ConversationID
        WHERE M.MessageID=@MessageID
          AND M.SenderUserID=@UserID
          AND M.IsDeleted=0 AND M.State=0
          AND C.State=0
          AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID
          AND CM.State=0 AND CM.LeftAt IS NULL;

        IF @ConversationID IS NULL
            THROW 51234,N'لا يمكن حذف الرسالة أو أنها لم تعد متاحة.',1;

        UPDATE dbo.Msg_Message
           SET IsDeleted=1,DeletedAt=SYSDATETIME()
        WHERE MessageID=@MessageID
          AND ConversationID=@ConversationID
          AND IsDeleted=0;

        IF @@ROWCOUNT=0
            THROW 51235,N'تعذر حذف الرسالة.',1;

        UPDATE dbo.Msg_Conversation
           SET UpdatedAt=SYSDATETIME()
        WHERE ConversationID=@ConversationID
          AND ConversationCompanyID=@CompanyID;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_AddConversationMember
    @ConversationID BIGINT,
    @UserID BIGINT,
    @AddedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CompanyID IS NULL
        THROW 51010,N'يجب تحديد الشركة الحالية.',1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User
        WHERE UsrID=@UserID AND UsrState=0
    )
        THROW 51011,N'العضو غير موجود أو حسابه غير فعال.',1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User
        WHERE UsrID=@AddedByUserID AND UsrState=0
    )
        THROW 51016,N'حساب منفذ الإضافة غير موجود أو غير فعال.',1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_Conversation WITH(UPDLOCK,HOLDLOCK)
            WHERE ConversationID=@ConversationID
              AND ConversationType=1
              AND ConversationCompanyID=@CompanyID
              AND CreatedByUserID=@AddedByUserID
              AND State=0
        )
            THROW 51012,N'إضافة الأعضاء متاحة لمنشئ المجموعة داخل الشركة المالكة فقط.',1;

        IF NOT EXISTS
        (
            SELECT 1 FROM dbo.Msg_ConversationMember
            WHERE ConversationID=@ConversationID
              AND UserID=@AddedByUserID
              AND State=0 AND LeftAt IS NULL
        )
            THROW 51013,N'منشئ المجموعة ليس عضوًا نشطًا فيها.',1;

        IF @UserID=@AddedByUserID
            THROW 51014,N'منشئ المجموعة عضو فيها بالفعل.',1;

        IF EXISTS
        (
            SELECT 1 FROM dbo.Msg_ConversationMember
            WHERE ConversationID=@ConversationID
              AND UserID=@UserID
              AND State=0 AND LeftAt IS NULL
        )
            THROW 51015,N'المستخدم عضو بالفعل في هذه المجموعة.',1;

        IF EXISTS
        (
            SELECT 1 FROM dbo.Msg_ConversationMember
            WHERE ConversationID=@ConversationID AND UserID=@UserID
        )
        BEGIN
            UPDATE dbo.Msg_ConversationMember
               SET State=0,LeftAt=NULL,JoinedAt=SYSDATETIME()
            WHERE ConversationID=@ConversationID AND UserID=@UserID;
        END
        ELSE
        BEGIN
            INSERT dbo.Msg_ConversationMember
                (ConversationID,UserID,MemberRole,State)
            VALUES(@ConversationID,@UserID,0,0);
        END;

        UPDATE dbo.Msg_Conversation
           SET UpdatedAt=SYSDATETIME()
        WHERE ConversationID=@ConversationID
          AND ConversationCompanyID=@CompanyID;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_RemoveConversationMember
    @ConversationID BIGINT,
    @UserID BIGINT,
    @RemovedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CompanyID IS NULL
        THROW 51110,N'يجب تحديد الشركة الحالية.',1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_Conversation WITH(UPDLOCK,HOLDLOCK)
            WHERE ConversationID=@ConversationID
              AND ConversationType=1
              AND ConversationCompanyID=@CompanyID
              AND CreatedByUserID=@RemovedByUserID
              AND State=0
        )
            THROW 51112,N'حذف الأعضاء متاح لمنشئ المجموعة داخل الشركة المالكة فقط.',1;

        IF NOT EXISTS
        (
            SELECT 1 FROM dbo.Msg_ConversationMember
            WHERE ConversationID=@ConversationID
              AND UserID=@RemovedByUserID
              AND State=0 AND LeftAt IS NULL
        )
            THROW 51115,N'منفذ الحذف ليس عضوًا نشطًا في المجموعة.',1;

        IF @UserID=@RemovedByUserID
            THROW 51113,N'لا يمكن لمنشئ المجموعة حذف عضويته بنفسه.',1;

        UPDATE dbo.Msg_ConversationMember
           SET State=1,LeftAt=COALESCE(LeftAt,SYSDATETIME())
        WHERE ConversationID=@ConversationID
          AND UserID=@UserID
          AND State=0 AND LeftAt IS NULL;

        IF @@ROWCOUNT=0
            THROW 51114,N'العضو غير موجود أو أن عضويته غير نشطة.',1;

        UPDATE dbo.Msg_Conversation
           SET UpdatedAt=SYSDATETIME()
        WHERE ConversationID=@ConversationID
          AND ConversationCompanyID=@CompanyID;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetMessages
    @ConversationID BIGINT,
    @UserID BIGINT,
    @CompanyID INT,
    @BeforeMessageID BIGINT=NULL,
    @PageSize INT=50
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51100,N'يجب تحديد الشركة الحالية.',1;

    IF @PageSize IS NULL OR @PageSize<1 SET @PageSize=50;
    IF @PageSize>100 SET @PageSize=100;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation C
        JOIN dbo.Msg_ConversationMember CM
          ON CM.ConversationID=C.ConversationID
        WHERE C.ConversationID=@ConversationID
          AND C.State=0
          AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID
          AND CM.State=0 AND CM.LeftAt IS NULL
    )
        THROW 51101,N'المحادثة لا تتبع الشركة الحالية أو لا تملك صلاحية عرضها.',1;

    SELECT TOP(@PageSize)
        M.MessageID,
        M.ConversationID,
        M.SenderUserID,
        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(CONCAT
                (
                    COALESCE(NULLIF(E.EmpNum,N''),N''),
                    CASE WHEN NULLIF(E.EmpNum,N'') IS NOT NULL
                               AND NULLIF(E.EmpName,N'') IS NOT NULL
                         THEN N' - ' ELSE N'' END,
                    COALESCE(NULLIF(E.EmpName,N''),
                             NULLIF(U.UsrLogIn,N''),N'مستخدم')
                ))),N''),
            N'مستخدم'
        ) AS SenderName,
        E.EmpNum AS SenderEmpNum,
        E.EmpName AS SenderEmpName,
        CASE WHEN M.IsDeleted=1
             THEN N'تم حذف الرسالة' ELSE M.MessageText END AS MessageText,
        M.SentAt,
        M.EditedAt,
        M.IsDeleted,
        R.DeliveredAt,
        R.ReadAt,
        (
            SELECT COUNT_BIG(*)
            FROM dbo.Msg_MessageAttachment A
            WHERE A.MessageID=M.MessageID
              AND A.State=0 AND M.IsDeleted=0
        ) AS AttachmentCount
    FROM dbo.Msg_Message M
    LEFT JOIN dbo.Mng_User U ON U.UsrID=M.SenderUserID
    LEFT JOIN dbo.Emp_Employee E ON E.EmpID=U.UsrID
    LEFT JOIN dbo.Msg_MessageReceipt R
      ON R.MessageID=M.MessageID
     AND R.UserID=@UserID
     AND R.State=0
    WHERE M.ConversationID=@ConversationID
      AND M.State=0
      AND (@BeforeMessageID IS NULL OR M.MessageID<@BeforeMessageID)
    ORDER BY M.MessageID DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_MarkConversationRead
    @ConversationID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51110,N'يجب تحديد الشركة الحالية.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation C
        JOIN dbo.Msg_ConversationMember CM
          ON CM.ConversationID=C.ConversationID
        WHERE C.ConversationID=@ConversationID
          AND C.State=0
          AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID
          AND CM.State=0 AND CM.LeftAt IS NULL
    )
        THROW 51111,N'المحادثة لا تتبع الشركة الحالية أو لا تملك صلاحية الوصول إليها.',1;

    UPDATE R
       SET DeliveredAt=COALESCE(R.DeliveredAt,SYSDATETIME()),
           ReadAt=COALESCE(R.ReadAt,SYSDATETIME())
    FROM dbo.Msg_MessageReceipt R
    JOIN dbo.Msg_Message M ON M.MessageID=R.MessageID
    WHERE M.ConversationID=@ConversationID
      AND M.SenderUserID<>@UserID
      AND R.UserID=@UserID
      AND R.State=0
      AND M.State=0 AND M.IsDeleted=0;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetConversationMembers
    @ConversationID BIGINT,
    @RequestedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51080,N'يجب تحديد الشركة الحالية.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation C
        JOIN dbo.Msg_ConversationMember CM
          ON CM.ConversationID=C.ConversationID
        WHERE C.ConversationID=@ConversationID
          AND C.State=0
          AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@RequestedByUserID
          AND CM.State=0 AND CM.LeftAt IS NULL
    )
        THROW 51081,N'المحادثة لا تتبع الشركة الحالية أو لا تملك صلاحية عرض أعضائها.',1;

    SELECT
        CM.UserID,
        CM.MemberRole,
        CM.JoinedAt,
        E.EmpNum,
        E.EmpName,
        COALESCE
        (
            NULLIF(LTRIM(RTRIM(CONCAT(E.EmpNum,N' - ',E.EmpName))),N''),
            NULLIF(U.UsrLogIn,N''),
            N'مستخدم'
        ) AS EmployeeDisplayName
    FROM dbo.Msg_ConversationMember CM
    JOIN dbo.Mng_User U
      ON U.UsrID=CM.UserID AND U.UsrState=0
    LEFT JOIN dbo.Emp_Employee E
      ON E.EmpID=U.UsrID AND E.EmpState=0
    WHERE CM.ConversationID=@ConversationID
      AND CM.State=0 AND CM.LeftAt IS NULL
    ORDER BY CM.JoinedAt,E.EmpName;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_AddAttachment
    @MessageID BIGINT,
    @UserID BIGINT,
    @FileName NVARCHAR(260),
    @FileData VARBINARY(MAX),
    @CompanyID INT,
    @ContentType NVARCHAR(150)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @FileName=LTRIM(RTRIM(@FileName));

    IF @CompanyID IS NULL
        THROW 51053,N'يجب تحديد الشركة الحالية.',1;
    IF NULLIF(@FileName,N'') IS NULL
        THROW 51050,N'اسم الملف مطلوب.',1;
    IF @FileData IS NULL OR DATALENGTH(@FileData)=0
        THROW 51051,N'محتوى الملف فارغ.',1;
    IF DATALENGTH(@FileData)>10485760
        THROW 51052,N'حجم المرفق يتجاوز 10 ميبيبايت.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Message M
        JOIN dbo.Msg_Conversation C ON C.ConversationID=M.ConversationID
        JOIN dbo.Msg_ConversationMember CM ON CM.ConversationID=C.ConversationID
        WHERE M.MessageID=@MessageID
          AND M.SenderUserID=@UserID
          AND M.IsDeleted=0 AND M.State=0
          AND C.State=0 AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID AND CM.State=0 AND CM.LeftAt IS NULL
    )
        THROW 51054,N'يمكن إرفاق الملفات برسالتك فقط داخل محادثة الشركة الحالية.',1;

    INSERT dbo.Msg_MessageAttachment
        (MessageID,FileName,ContentType,FileSize,FileData,State)
    VALUES
        (@MessageID,@FileName,@ContentType,DATALENGTH(@FileData),@FileData,0);

    SELECT CONVERT(BIGINT,SCOPE_IDENTITY()) AS AttachmentID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_DeleteAttachment
    @AttachmentID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51060,N'يجب تحديد الشركة الحالية.',1;

    UPDATE A
       SET State=1
    FROM dbo.Msg_MessageAttachment A
    JOIN dbo.Msg_Message M ON M.MessageID=A.MessageID
    JOIN dbo.Msg_Conversation C ON C.ConversationID=M.ConversationID
    JOIN dbo.Msg_ConversationMember CM ON CM.ConversationID=C.ConversationID
    WHERE A.AttachmentID=@AttachmentID
      AND A.State=0
      AND M.State=0 AND M.IsDeleted=0
      AND M.SenderUserID=@UserID
      AND C.State=0 AND C.ConversationCompanyID=@CompanyID
      AND CM.UserID=@UserID AND CM.State=0 AND CM.LeftAt IS NULL;

    IF @@ROWCOUNT=0
        THROW 51061,N'المرفق غير موجود أو لا تملك صلاحية حذفه.',1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetAttachments
    @MessageID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51070,N'يجب تحديد الشركة الحالية.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Message M
        JOIN dbo.Msg_Conversation C ON C.ConversationID=M.ConversationID
        JOIN dbo.Msg_ConversationMember CM ON CM.ConversationID=C.ConversationID
        WHERE M.MessageID=@MessageID
          AND M.State=0 AND M.IsDeleted=0
          AND C.State=0 AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID AND CM.State=0 AND CM.LeftAt IS NULL
    )
        THROW 51071,N'لا تملك صلاحية عرض مرفقات هذه الرسالة.',1;

    SELECT
        A.AttachmentID,A.MessageID,A.FileName,A.ContentType,
        A.FileSize,A.UploadedAt
    FROM dbo.Msg_MessageAttachment A
    WHERE A.MessageID=@MessageID AND A.State=0
    ORDER BY A.AttachmentID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetAttachmentData
    @AttachmentID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @CompanyID IS NULL
        THROW 51072,N'يجب تحديد الشركة الحالية.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_MessageAttachment A
        JOIN dbo.Msg_Message M ON M.MessageID=A.MessageID
        JOIN dbo.Msg_Conversation C ON C.ConversationID=M.ConversationID
        JOIN dbo.Msg_ConversationMember CM ON CM.ConversationID=C.ConversationID
        WHERE A.AttachmentID=@AttachmentID
          AND A.State=0
          AND M.State=0 AND M.IsDeleted=0
          AND C.State=0 AND C.ConversationCompanyID=@CompanyID
          AND CM.UserID=@UserID AND CM.State=0 AND CM.LeftAt IS NULL
    )
        THROW 51073,N'المرفق غير موجود أو لا تملك صلاحية الوصول إليه.',1;

    SELECT
        A.AttachmentID,A.MessageID,A.FileName,A.ContentType,
        A.FileSize,A.FileData,A.UploadedAt
    FROM dbo.Msg_MessageAttachment A
    WHERE A.AttachmentID=@AttachmentID AND A.State=0;
END;
GO

-------------------------------------------------------------------------------
-- 4. MIGRATION STATUS
-------------------------------------------------------------------------------
SELECT
    COUNT_BIG(*) AS TotalConversations,
    SUM(CASE WHEN ConversationCompanyID IS NULL THEN 1 ELSE 0 END)
        AS ConversationsNeedingCompanyAssignment
FROM dbo.Msg_Conversation;
GO

PRINT N'MADAR Message System schema and procedures deployed. Assign verified company IDs to legacy conversations before enforcing NOT NULL.';
GO

USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
SET XACT_ABORT ON;
GO

/*
  MADAR Message System - company-isolated version

  Identity:
      Mng_User.UsrID = Emp_Employee.EmpID (BIGINT)

  Company membership:
      dbo.Mng_UserSystem(USUserID, USCompanyID, USState)
  Mng_UserSystem is the authority for multi-company access. Do NOT use
  Mng_User.UsrCompany or Emp_Employee.EmpCompany to decide access to a
  selected company; those columns do not represent multi-company membership.

  Each conversation stores ConversationCompanyID. A direct conversation is
  unique by (company, ordered pair of users), so the same two users have a
  separate conversation in each company.

  Legacy migration:
      Existing conversations are assigned a company only when the active
      participants have exactly ONE common active company in Mng_UserSystem.
      Ambiguous legacy conversations remain NULL and are listed at the end.
      They must be assigned manually after reviewing their real history.
      The script never guesses a company for an ambiguous old conversation.

  This script preserves existing message data. It adds/updates schema,
  triggers, indexes and stored procedures. Review the unresolved legacy list
  before using old conversations.
*/

/*==============================================================
  0. REQUIRED DEPENDENCIES
==============================================================*/
IF OBJECT_ID(N'dbo.Mng_User', N'U') IS NULL
    THROW 52000, N'الجدول dbo.Mng_User غير موجود.', 1;
IF OBJECT_ID(N'dbo.Emp_Employee', N'U') IS NULL
    THROW 52001, N'الجدول dbo.Emp_Employee غير موجود.', 1;
IF OBJECT_ID(N'dbo.Mng_UserSystem', N'U') IS NULL
    THROW 52002, N'الجدول dbo.Mng_UserSystem غير موجود. يلزم وجوده للتحقق من عضوية المستخدم في الشركات.', 1;
IF OBJECT_ID(N'dbo.Mng_Company', N'U') IS NULL
    THROW 52003, N'الجدول dbo.Mng_Company غير موجود.', 1;

IF COL_LENGTH(N'dbo.Mng_User', N'UsrID') IS NULL
   OR COL_LENGTH(N'dbo.Mng_User', N'UsrState') IS NULL
    THROW 52004, N'بنية dbo.Mng_User لا تطابق الأعمدة المتوقعة (UsrID, UsrState).', 1;
IF COL_LENGTH(N'dbo.Emp_Employee', N'EmpID') IS NULL
   OR COL_LENGTH(N'dbo.Emp_Employee', N'EmpState') IS NULL
   OR COL_LENGTH(N'dbo.Emp_Employee', N'EmpName') IS NULL
   OR COL_LENGTH(N'dbo.Emp_Employee', N'EmpNum') IS NULL
    THROW 52005, N'بنية dbo.Emp_Employee لا تطابق الأعمدة المتوقعة.', 1;
IF COL_LENGTH(N'dbo.Mng_UserSystem', N'USUserID') IS NULL
   OR COL_LENGTH(N'dbo.Mng_UserSystem', N'USCompanyID') IS NULL
   OR COL_LENGTH(N'dbo.Mng_UserSystem', N'USState') IS NULL
    THROW 52006, N'بنية dbo.Mng_UserSystem لا تطابق الأعمدة المتوقعة (USUserID, USCompanyID, USState).', 1;
IF COL_LENGTH(N'dbo.Mng_Company', N'CmpID') IS NULL
    THROW 52007, N'بنية dbo.Mng_Company لا تحتوي على CmpID.', 1;
GO

/*==============================================================
  1. TABLES
==============================================================*/
IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_Conversation
    (
        ConversationID BIGINT IDENTITY(1,1) NOT NULL,
        ConversationType TINYINT NOT NULL,
        ConversationTitle NVARCHAR(200) NULL,
        CreatedByUserID BIGINT NOT NULL,
        DirectUser1ID BIGINT NULL,
        DirectUser2ID BIGINT NULL,
        ConversationCompanyID INT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Msg_Conversation_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        State TINYINT NOT NULL CONSTRAINT DF_Msg_Conversation_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_Conversation PRIMARY KEY CLUSTERED (ConversationID)
    );
END;
GO

IF COL_LENGTH(N'dbo.Msg_Conversation', N'ConversationCompanyID') IS NULL
    ALTER TABLE dbo.Msg_Conversation ADD ConversationCompanyID INT NULL;
GO

IF OBJECT_ID(N'dbo.Msg_ConversationMember', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_ConversationMember
    (
        ConversationMemberID BIGINT IDENTITY(1,1) NOT NULL,
        ConversationID BIGINT NOT NULL,
        UserID BIGINT NOT NULL,
        MemberRole TINYINT NOT NULL CONSTRAINT DF_Msg_ConversationMember_Role DEFAULT ((0)),
        JoinedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Msg_ConversationMember_JoinedAt DEFAULT (SYSDATETIME()),
        LeftAt DATETIME2(0) NULL,
        State TINYINT NOT NULL CONSTRAINT DF_Msg_ConversationMember_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_ConversationMember PRIMARY KEY CLUSTERED (ConversationMemberID),
        CONSTRAINT UQ_Msg_ConversationMember_Conversation_User UNIQUE (ConversationID, UserID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_Message', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_Message
    (
        MessageID BIGINT IDENTITY(1,1) NOT NULL,
        ConversationID BIGINT NOT NULL,
        SenderUserID BIGINT NOT NULL,
        MessageText NVARCHAR(MAX) NULL,
        SentAt DATETIME2(0) NOT NULL CONSTRAINT DF_Msg_Message_SentAt DEFAULT (SYSDATETIME()),
        EditedAt DATETIME2(0) NULL,
        IsDeleted BIT NOT NULL CONSTRAINT DF_Msg_Message_IsDeleted DEFAULT ((0)),
        DeletedAt DATETIME2(0) NULL,
        State TINYINT NOT NULL CONSTRAINT DF_Msg_Message_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_Message PRIMARY KEY CLUSTERED (MessageID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_MessageAttachment', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_MessageAttachment
    (
        AttachmentID BIGINT IDENTITY(1,1) NOT NULL,
        MessageID BIGINT NOT NULL,
        FileName NVARCHAR(260) NOT NULL,
        ContentType NVARCHAR(150) NULL,
        FileSize BIGINT NOT NULL,
        FileData VARBINARY(MAX) NOT NULL,
        UploadedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Msg_MessageAttachment_UploadedAt DEFAULT (SYSDATETIME()),
        State TINYINT NOT NULL CONSTRAINT DF_Msg_MessageAttachment_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_MessageAttachment PRIMARY KEY CLUSTERED (AttachmentID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_MessageReceipt', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_MessageReceipt
    (
        ReceiptID BIGINT IDENTITY(1,1) NOT NULL,
        MessageID BIGINT NOT NULL,
        UserID BIGINT NOT NULL,
        DeliveredAt DATETIME2(0) NULL,
        ReadAt DATETIME2(0) NULL,
        State TINYINT NOT NULL CONSTRAINT DF_Msg_MessageReceipt_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_MessageReceipt PRIMARY KEY CLUSTERED (ReceiptID),
        CONSTRAINT UQ_Msg_MessageReceipt_Message_User UNIQUE (MessageID, UserID)
    );
END;
GO

/* Ensure required columns exist before the migration continues. */
IF COL_LENGTH(N'dbo.Msg_Conversation', N'CreatedByUserID') IS NULL
 OR COL_LENGTH(N'dbo.Msg_Conversation', N'ConversationType') IS NULL
 OR COL_LENGTH(N'dbo.Msg_Conversation', N'DirectUser1ID') IS NULL
 OR COL_LENGTH(N'dbo.Msg_Conversation', N'DirectUser2ID') IS NULL
 OR COL_LENGTH(N'dbo.Msg_Conversation', N'State') IS NULL
    THROW 52010, N'بنية Msg_Conversation لا تطابق الأعمدة المطلوبة.', 1;
IF COL_LENGTH(N'dbo.Msg_ConversationMember', N'ConversationID') IS NULL
 OR COL_LENGTH(N'dbo.Msg_ConversationMember', N'UserID') IS NULL
 OR COL_LENGTH(N'dbo.Msg_ConversationMember', N'LeftAt') IS NULL
 OR COL_LENGTH(N'dbo.Msg_ConversationMember', N'State') IS NULL
    THROW 52011, N'بنية Msg_ConversationMember لا تطابق الأعمدة المطلوبة.', 1;
GO

/*==============================================================
  2. SAFE LEGACY COMPANY BACKFILL
==============================================================*/
/*
  For each old conversation, collect its creator, direct participants and
  active group members. Assign a company only if exactly one company is
  common to every participant. This uses Mng_UserSystem, not UsrCompany.
*/
;WITH Participants AS
(
    SELECT C.ConversationID, C.CreatedByUserID AS UserID
    FROM dbo.Msg_Conversation AS C
    WHERE C.ConversationCompanyID IS NULL

    UNION

    SELECT C.ConversationID, C.DirectUser1ID
    FROM dbo.Msg_Conversation AS C
    WHERE C.ConversationCompanyID IS NULL AND C.DirectUser1ID IS NOT NULL

    UNION

    SELECT C.ConversationID, C.DirectUser2ID
    FROM dbo.Msg_Conversation AS C
    WHERE C.ConversationCompanyID IS NULL AND C.DirectUser2ID IS NOT NULL

    UNION

    SELECT CM.ConversationID, CM.UserID
    FROM dbo.Msg_ConversationMember AS CM
    INNER JOIN dbo.Msg_Conversation AS C
        ON C.ConversationID = CM.ConversationID
    WHERE C.ConversationCompanyID IS NULL
      AND CM.State = 0
      AND CM.LeftAt IS NULL
),
CandidateCompanies AS
(
    SELECT DISTINCT P.ConversationID, US.USCompanyID
    FROM Participants AS P
    INNER JOIN dbo.Mng_User AS U
        ON U.UsrID = P.UserID
       AND U.UsrState = 0
    INNER JOIN dbo.Emp_Employee AS E
        ON E.EmpID = U.UsrID
       AND E.EmpState = 0
    INNER JOIN dbo.Mng_UserSystem AS US
        ON US.USUserID = U.UsrID
       AND US.USState = 0
    INNER JOIN dbo.Mng_Company AS MC
        ON MC.CmpID = US.USCompanyID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM Participants AS P2
        WHERE P2.ConversationID = P.ConversationID
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Mng_User AS U2
              INNER JOIN dbo.Emp_Employee AS E2
                  ON E2.EmpID = U2.UsrID
                 AND E2.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US2
                  ON US2.USUserID = U2.UsrID
                 AND US2.USCompanyID = US.USCompanyID
                 AND US2.USState = 0
              WHERE U2.UsrID = P2.UserID
                AND U2.UsrState = 0
          )
    )
),
UniqueCompany AS
(
    SELECT ConversationID, MIN(USCompanyID) AS CompanyID
    FROM CandidateCompanies
    GROUP BY ConversationID
    HAVING COUNT(*) = 1
)
UPDATE C
SET C.ConversationCompanyID = U.CompanyID
FROM dbo.Msg_Conversation AS C
INNER JOIN UniqueCompany AS U
    ON U.ConversationID = C.ConversationID
WHERE C.ConversationCompanyID IS NULL;
GO

/* Add a company FK. NULL is temporarily allowed for ambiguous legacy rows. */
IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_Msg_Conversation_Company'
      AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation')
)
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
        ADD CONSTRAINT FK_Msg_Conversation_Company
        FOREIGN KEY (ConversationCompanyID) REFERENCES dbo.Mng_Company(CmpID);
GO

/*==============================================================
  3. REDUNDANT LEGACY CONSTRAINT CLEANUP + CORE RELATIONSHIPS
==============================================================*/
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_User1' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation DROP CONSTRAINT FK_Msg_Conversation_User1;
GO
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_User2' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation DROP CONSTRAINT FK_Msg_Conversation_User2;
GO
IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_Conversation_DirectPair' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation DROP CONSTRAINT CK_Msg_Conversation_DirectPair;
GO
IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_MessageAttachment_Size' AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    ALTER TABLE dbo.Msg_MessageAttachment DROP CONSTRAINT CK_Msg_MessageAttachment_Size;
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_Creator' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK ADD CONSTRAINT FK_Msg_Conversation_Creator
        FOREIGN KEY (CreatedByUserID) REFERENCES dbo.Mng_User(UsrID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_DirectUser1' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK ADD CONSTRAINT FK_Msg_Conversation_DirectUser1
        FOREIGN KEY (DirectUser1ID) REFERENCES dbo.Mng_User(UsrID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_DirectUser2' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK ADD CONSTRAINT FK_Msg_Conversation_DirectUser2
        FOREIGN KEY (DirectUser2ID) REFERENCES dbo.Mng_User(UsrID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_ConversationMember_Conversation' AND parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK ADD CONSTRAINT FK_Msg_ConversationMember_Conversation
        FOREIGN KEY (ConversationID) REFERENCES dbo.Msg_Conversation(ConversationID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_ConversationMember_User' AND parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK ADD CONSTRAINT FK_Msg_ConversationMember_User
        FOREIGN KEY (UserID) REFERENCES dbo.Mng_User(UsrID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Message_Conversation' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Message'))
    ALTER TABLE dbo.Msg_Message WITH CHECK ADD CONSTRAINT FK_Msg_Message_Conversation
        FOREIGN KEY (ConversationID) REFERENCES dbo.Msg_Conversation(ConversationID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Message_Sender' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Message'))
    ALTER TABLE dbo.Msg_Message WITH CHECK ADD CONSTRAINT FK_Msg_Message_Sender
        FOREIGN KEY (SenderUserID) REFERENCES dbo.Mng_User(UsrID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_MessageAttachment_Message' AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    ALTER TABLE dbo.Msg_MessageAttachment WITH CHECK ADD CONSTRAINT FK_Msg_MessageAttachment_Message
        FOREIGN KEY (MessageID) REFERENCES dbo.Msg_Message(MessageID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_MessageReceipt_Message' AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt'))
    ALTER TABLE dbo.Msg_MessageReceipt WITH CHECK ADD CONSTRAINT FK_Msg_MessageReceipt_Message
        FOREIGN KEY (MessageID) REFERENCES dbo.Msg_Message(MessageID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_MessageReceipt_User' AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt'))
    ALTER TABLE dbo.Msg_MessageReceipt WITH CHECK ADD CONSTRAINT FK_Msg_MessageReceipt_User
        FOREIGN KEY (UserID) REFERENCES dbo.Mng_User(UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_Conversation_Structure' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK ADD CONSTRAINT CK_Msg_Conversation_Structure CHECK
    (
        (ConversationType = 0 AND DirectUser1ID IS NOT NULL AND DirectUser2ID IS NOT NULL
         AND DirectUser1ID < DirectUser2ID AND ConversationTitle IS NULL)
        OR
        (ConversationType = 1 AND DirectUser1ID IS NULL AND DirectUser2ID IS NULL
         AND NULLIF(LTRIM(RTRIM(ConversationTitle)), N'') IS NOT NULL)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_Conversation_Type' AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK ADD CONSTRAINT CK_Msg_Conversation_Type CHECK (ConversationType IN (0,1));
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_ConversationMember_Role' AND parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK ADD CONSTRAINT CK_Msg_ConversationMember_Role CHECK (MemberRole IN (0,1));
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_MessageAttachment_FileSize' AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    ALTER TABLE dbo.Msg_MessageAttachment WITH CHECK ADD CONSTRAINT CK_Msg_MessageAttachment_FileSize CHECK (FileSize > 0);
GO

/* Supporting indexes. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Msg_ConversationMember') AND name = N'IX_Msg_ConversationMember_User_State')
    CREATE INDEX IX_Msg_ConversationMember_User_State
        ON dbo.Msg_ConversationMember(UserID, State, LeftAt)
        INCLUDE (ConversationID, MemberRole, JoinedAt);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Msg_Conversation') AND name = N'IX_Msg_Conversation_Company_State_Updated')
    CREATE INDEX IX_Msg_Conversation_Company_State_Updated
        ON dbo.Msg_Conversation(ConversationCompanyID, State, UpdatedAt DESC)
        INCLUDE (ConversationID, ConversationType, ConversationTitle, CreatedAt, CreatedByUserID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Msg_Message') AND name = N'IX_Msg_Message_Conversation_Message')
    CREATE INDEX IX_Msg_Message_Conversation_Message
        ON dbo.Msg_Message(ConversationID, MessageID DESC)
        INCLUDE (SenderUserID, SentAt, State, IsDeleted);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt') AND name = N'IX_Msg_MessageReceipt_User_Read')
    CREATE INDEX IX_Msg_MessageReceipt_User_Read
        ON dbo.Msg_MessageReceipt(UserID, State, ReadAt)
        INCLUDE (MessageID, DeliveredAt);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment') AND name = N'IX_Msg_MessageAttachment_Message_State')
    CREATE INDEX IX_Msg_MessageAttachment_Message_State
        ON dbo.Msg_MessageAttachment(MessageID, State)
        INCLUDE (AttachmentID, FileName, ContentType, FileSize, UploadedAt);
GO

/* Unique active direct conversation per company and user pair. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Msg_Conversation') AND name = N'UX_Msg_Conversation_DirectPair_Company')
AND NOT EXISTS
(
    SELECT 1
    FROM dbo.Msg_Conversation
    WHERE ConversationType = 0 AND State = 0 AND ConversationCompanyID IS NOT NULL
    GROUP BY ConversationCompanyID, DirectUser1ID, DirectUser2ID
    HAVING COUNT_BIG(*) > 1
)
    CREATE UNIQUE INDEX UX_Msg_Conversation_DirectPair_Company
        ON dbo.Msg_Conversation(ConversationCompanyID, DirectUser1ID, DirectUser2ID)
        WHERE ConversationType = 0 AND State = 0 AND ConversationCompanyID IS NOT NULL;
GO

/*==============================================================
  4. COMPANY ISOLATION TRIGGERS
==============================================================*/
CREATE OR ALTER TRIGGER dbo.TR_Msg_Conversation_CompanyGuard
ON dbo.Msg_Conversation
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted WHERE ConversationCompanyID IS NULL)
        THROW 52100, N'يجب تحديد الشركة المالكة للمحادثة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS I
        CROSS APPLY (VALUES (I.CreatedByUserID), (I.DirectUser1ID), (I.DirectUser2ID)) AS P(UserID)
        WHERE P.UserID IS NOT NULL
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E
                  ON E.EmpID = U.UsrID AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US
                  ON US.USUserID = U.UsrID
                 AND US.USCompanyID = I.ConversationCompanyID
                 AND US.USState = 0
              WHERE U.UsrID = P.UserID AND U.UsrState = 0
          )
    )
        THROW 52101, N'أحد أطراف المحادثة لا يملك عضوية فعالة في شركة المحادثة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS I
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = I.ConversationID
           AND CM.State = 0 AND CM.LeftAt IS NULL
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM dbo.Mng_User AS U
            INNER JOIN dbo.Emp_Employee AS E
                ON E.EmpID = U.UsrID AND E.EmpState = 0
            INNER JOIN dbo.Mng_UserSystem AS US
                ON US.USUserID = U.UsrID
               AND US.USCompanyID = I.ConversationCompanyID
               AND US.USState = 0
            WHERE U.UsrID = CM.UserID AND U.UsrState = 0
        )
    )
        THROW 52102, N'لا يمكن تغيير شركة المحادثة إلى شركة لا ينتمي إليها جميع أعضائها النشطين.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_Msg_ConversationMember_CompanyGuard
ON dbo.Msg_ConversationMember
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS I
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = I.ConversationID
        WHERE I.State = 0 AND I.LeftAt IS NULL
          AND
          (
              C.ConversationCompanyID IS NULL
              OR NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS U
                  INNER JOIN dbo.Emp_Employee AS E
                      ON E.EmpID = U.UsrID AND E.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS US
                      ON US.USUserID = U.UsrID
                     AND US.USCompanyID = C.ConversationCompanyID
                     AND US.USState = 0
                  WHERE U.UsrID = I.UserID AND U.UsrState = 0
              )
          )
    )
        THROW 52110, N'عضو المحادثة غير مرتبط بالشركة المحددة للمحادثة.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_Msg_Message_CompanyGuard
ON dbo.Msg_Message
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS I
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = I.ConversationID
        WHERE C.ConversationCompanyID IS NULL
           OR NOT EXISTS
           (
               SELECT 1
               FROM dbo.Msg_ConversationMember AS CM
               INNER JOIN dbo.Mng_User AS U
                   ON U.UsrID = CM.UserID AND U.UsrState = 0
               INNER JOIN dbo.Emp_Employee AS E
                   ON E.EmpID = U.UsrID AND E.EmpState = 0
               INNER JOIN dbo.Mng_UserSystem AS US
                   ON US.USUserID = U.UsrID
                  AND US.USCompanyID = C.ConversationCompanyID
                  AND US.USState = 0
               WHERE CM.ConversationID = I.ConversationID
                 AND CM.UserID = I.SenderUserID
                 AND CM.State = 0 AND CM.LeftAt IS NULL
           )
    )
        THROW 52120, N'مرسل الرسالة ليس عضوًا فعالًا في شركة المحادثة.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_Msg_MessageReceipt_CompanyGuard
ON dbo.Msg_MessageReceipt
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS I
        INNER JOIN dbo.Msg_Message AS M ON M.MessageID = I.MessageID
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
        WHERE C.ConversationCompanyID IS NULL
           OR NOT EXISTS
           (
               SELECT 1
               FROM dbo.Msg_ConversationMember AS CM
               INNER JOIN dbo.Mng_User AS U
                   ON U.UsrID = CM.UserID AND U.UsrState = 0
               INNER JOIN dbo.Emp_Employee AS E
                   ON E.EmpID = U.UsrID AND E.EmpState = 0
               INNER JOIN dbo.Mng_UserSystem AS US
                   ON US.USUserID = U.UsrID
                  AND US.USCompanyID = C.ConversationCompanyID
                  AND US.USState = 0
               WHERE CM.ConversationID = M.ConversationID
                 AND CM.UserID = I.UserID
                 AND CM.State = 0 AND CM.LeftAt IS NULL
           )
    )
        THROW 52130, N'مستلم الرسالة ليس عضوًا فعالًا في شركة المحادثة.', 1;
END;
GO

/*==============================================================
  5. STORED PROCEDURES
==============================================================*/

CREATE OR ALTER PROCEDURE dbo.Msg_GetCompanyUsers
    @CompanyID INT,
    @RequestedByUserID BIGINT,
    @ExcludeCurrentUser BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @RequestedByUserID AND U.UsrState = 0
    )
        THROW 52200, N'المستخدم الحالي لا يملك عضوية فعالة في الشركة المحددة.', 1;

    SELECT DISTINCT
        U.UsrID AS UserID,
        U.UsrLogIn,
        E.EmpNum,
        E.EmpName,
        CONCAT(COALESCE(E.EmpNum, N''), CASE WHEN E.EmpNum IS NOT NULL AND E.EmpName IS NOT NULL THEN N' - ' ELSE N'' END,
               COALESCE(E.EmpName, U.UsrLogIn)) AS DisplayName
    FROM dbo.Mng_User AS U
    INNER JOIN dbo.Emp_Employee AS E
        ON E.EmpID = U.UsrID AND E.EmpState = 0
    INNER JOIN dbo.Mng_UserSystem AS US
        ON US.USUserID = U.UsrID
       AND US.USCompanyID = @CompanyID
       AND US.USState = 0
    WHERE U.UsrState = 0
      AND (@ExcludeCurrentUser = 0 OR U.UsrID <> @RequestedByUserID)
    ORDER BY DisplayName, U.UsrID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_CreateConversation
    @ConversationType TINYINT,
    @CreatedByUserID BIGINT,
    @ConversationID BIGINT OUTPUT,
    @CompanyID INT,
    @OtherUserID BIGINT = NULL,
    @ConversationTitle NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @ConversationID = NULL;

    IF @ConversationType IS NULL OR @ConversationType NOT IN (0,1)
        THROW 51002, N'نوع المحادثة غير صحيح.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @CreatedByUserID AND U.UsrState = 0
    )
        THROW 51001, N'المستخدم المنشئ غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF @ConversationType = 0
        BEGIN
            IF @OtherUserID IS NULL OR @OtherUserID = @CreatedByUserID
                THROW 51003, N'حدد مستخدمًا آخر للمحادثة الفردية.', 1;

            IF NOT EXISTS
            (
                SELECT 1
                FROM dbo.Mng_User AS U
                INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
                INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
                WHERE U.UsrID = @OtherUserID AND U.UsrState = 0
            )
                THROW 51004, N'المستخدم الآخر غير فعال أو لا ينتمي إلى الشركة الحالية.', 1;

            DECLARE @U1 BIGINT = CASE WHEN @CreatedByUserID < @OtherUserID THEN @CreatedByUserID ELSE @OtherUserID END;
            DECLARE @U2 BIGINT = CASE WHEN @CreatedByUserID < @OtherUserID THEN @OtherUserID ELSE @CreatedByUserID END;

            SELECT TOP (1) @ConversationID = C.ConversationID
            FROM dbo.Msg_Conversation AS C WITH (UPDLOCK, HOLDLOCK)
            WHERE C.ConversationType = 0
              AND C.State = 0
              AND C.ConversationCompanyID = @CompanyID
              AND C.DirectUser1ID = @U1
              AND C.DirectUser2ID = @U2
            ORDER BY C.ConversationID DESC;

            IF @ConversationID IS NULL
            BEGIN
                INSERT INTO dbo.Msg_Conversation
                (ConversationType, CreatedByUserID, DirectUser1ID, DirectUser2ID, ConversationCompanyID, State)
                VALUES
                (0, @CreatedByUserID, @U1, @U2, @CompanyID, 0);

                SET @ConversationID = CONVERT(BIGINT, SCOPE_IDENTITY());
            END;

            IF NOT EXISTS (SELECT 1 FROM dbo.Msg_ConversationMember WHERE ConversationID = @ConversationID AND UserID = @U1)
                INSERT INTO dbo.Msg_ConversationMember(ConversationID, UserID, MemberRole, State) VALUES(@ConversationID, @U1, 0, 0);
            ELSE
                UPDATE dbo.Msg_ConversationMember SET State = 0, LeftAt = NULL, JoinedAt = CASE WHEN State <> 0 OR LeftAt IS NOT NULL THEN SYSDATETIME() ELSE JoinedAt END
                WHERE ConversationID = @ConversationID AND UserID = @U1;

            IF NOT EXISTS (SELECT 1 FROM dbo.Msg_ConversationMember WHERE ConversationID = @ConversationID AND UserID = @U2)
                INSERT INTO dbo.Msg_ConversationMember(ConversationID, UserID, MemberRole, State) VALUES(@ConversationID, @U2, 0, 0);
            ELSE
                UPDATE dbo.Msg_ConversationMember SET State = 0, LeftAt = NULL, JoinedAt = CASE WHEN State <> 0 OR LeftAt IS NOT NULL THEN SYSDATETIME() ELSE JoinedAt END
                WHERE ConversationID = @ConversationID AND UserID = @U2;
        END
        ELSE
        BEGIN
            SET @ConversationTitle = LTRIM(RTRIM(@ConversationTitle));
            IF NULLIF(@ConversationTitle, N'') IS NULL
                THROW 51005, N'اسم المجموعة مطلوب.', 1;

            INSERT INTO dbo.Msg_Conversation(ConversationType, ConversationTitle, CreatedByUserID, ConversationCompanyID, State)
            VALUES(1, @ConversationTitle, @CreatedByUserID, @CompanyID, 0);
            SET @ConversationID = CONVERT(BIGINT, SCOPE_IDENTITY());

            INSERT INTO dbo.Msg_ConversationMember(ConversationID, UserID, MemberRole, State)
            VALUES(@ConversationID, @CreatedByUserID, 1, 0);
        END;

        UPDATE dbo.Msg_Conversation SET UpdatedAt = SYSDATETIME() WHERE ConversationID = @ConversationID;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        SET @ConversationID = NULL;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_AddConversationMember
    @ConversationID BIGINT,
    @UserID BIGINT,
    @AddedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @AddedByUserID AND U.UsrState = 0
    )
        THROW 51010, N'المستخدم المنفذ غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @UserID AND U.UsrState = 0
    )
        THROW 51011, N'العضو المراد إضافته لا يملك عضوية فعالة في الشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Conversation
        WHERE ConversationID = @ConversationID
          AND ConversationType = 1
          AND ConversationCompanyID = @CompanyID
          AND State = 0
          AND CreatedByUserID = @AddedByUserID
    )
        THROW 51112, N'إضافة الأعضاء متاحة لمنشئ المجموعة داخل الشركة نفسها فقط.', 1;

    IF @UserID = @AddedByUserID
        THROW 51013, N'منشئ المجموعة عضو فيها بالفعل.', 1;

    IF EXISTS (SELECT 1 FROM dbo.Msg_ConversationMember WHERE ConversationID = @ConversationID AND UserID = @UserID AND State = 0 AND LeftAt IS NULL)
        THROW 51014, N'المستخدم عضو بالفعل في هذه المجموعة.', 1;

    IF EXISTS (SELECT 1 FROM dbo.Msg_ConversationMember WHERE ConversationID = @ConversationID AND UserID = @UserID)
        UPDATE dbo.Msg_ConversationMember SET State = 0, LeftAt = NULL, JoinedAt = SYSDATETIME()
        WHERE ConversationID = @ConversationID AND UserID = @UserID;
    ELSE
        INSERT INTO dbo.Msg_ConversationMember(ConversationID, UserID, MemberRole, State)
        VALUES(@ConversationID, @UserID, 0, 0);

    UPDATE dbo.Msg_Conversation SET UpdatedAt = SYSDATETIME() WHERE ConversationID = @ConversationID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetConversations
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @UserID AND U.UsrState = 0
    )
        THROW 51090, N'المستخدم لا يملك عضوية فعالة في الشركة الحالية.', 1;

    SELECT
        C.ConversationID,
        C.ConversationType,
        C.ConversationTitle,
        C.ConversationCompanyID,
        C.CreatedAt,
        C.UpdatedAt,
        CASE WHEN C.ConversationType = 1 THEN C.ConversationTitle
             ELSE COALESCE(NULLIF(EOther.EmpName, N''), UOther.UsrLogIn, N'محادثة فردية') END AS DisplayName,
        LM.MessageID AS LastMessageID,
        CASE WHEN LM.IsDeleted = 1 THEN N'تم حذف الرسالة' ELSE LM.MessageText END AS LastMessageText,
        LM.SentAt AS LastMessageAt,
        LM.SenderUserID AS LastSenderUserID,
        CASE WHEN LM.SenderUserID IS NULL THEN NULL
             ELSE COALESCE(NULLIF(ESender.EmpName, N''), USender.UsrLogIn, N'مستخدم') END AS LastSenderName,
        (
            SELECT COUNT_BIG(1)
            FROM dbo.Msg_MessageReceipt AS R
            INNER JOIN dbo.Msg_Message AS M2 ON M2.MessageID = R.MessageID
            WHERE M2.ConversationID = C.ConversationID
              AND R.UserID = @UserID AND R.ReadAt IS NULL AND R.State = 0
              AND M2.SenderUserID <> @UserID AND M2.IsDeleted = 0 AND M2.State = 0
        ) AS UnreadCount,
        C.CreatedByUserID
    FROM dbo.Msg_Conversation AS C
    INNER JOIN dbo.Msg_ConversationMember AS MyM
        ON MyM.ConversationID = C.ConversationID
       AND MyM.UserID = @UserID
       AND MyM.State = 0 AND MyM.LeftAt IS NULL
    LEFT JOIN dbo.Mng_User AS UOther
        ON UOther.UsrID = CASE WHEN C.DirectUser1ID = @UserID THEN C.DirectUser2ID ELSE C.DirectUser1ID END
       AND UOther.UsrState = 0
       AND EXISTS (SELECT 1 FROM dbo.Mng_UserSystem AS XUS WHERE XUS.USUserID = UOther.UsrID AND XUS.USCompanyID = @CompanyID AND XUS.USState = 0)
       AND C.ConversationType = 0
    LEFT JOIN dbo.Emp_Employee AS EOther ON EOther.EmpID = UOther.UsrID AND EOther.EmpState = 0
    OUTER APPLY
    (
        SELECT TOP (1) M.MessageID, M.MessageText, M.SentAt, M.SenderUserID, M.IsDeleted
        FROM dbo.Msg_Message AS M
        WHERE M.ConversationID = C.ConversationID AND M.State = 0
        ORDER BY M.MessageID DESC
    ) AS LM
    LEFT JOIN dbo.Mng_User AS USender
        ON USender.UsrID = LM.SenderUserID AND USender.UsrState = 0
    LEFT JOIN dbo.Emp_Employee AS ESender ON ESender.EmpID = USender.UsrID AND ESender.EmpState = 0
    WHERE C.State = 0
      AND C.ConversationCompanyID = @CompanyID
      AND EXISTS (SELECT 1 FROM dbo.Mng_UserSystem AS US WHERE US.USUserID = @UserID AND US.USCompanyID = @CompanyID AND US.USState = 0)
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Msg_ConversationMember AS CMX
          WHERE CMX.ConversationID = C.ConversationID AND CMX.State = 0 AND CMX.LeftAt IS NULL
            AND NOT EXISTS
            (
                SELECT 1 FROM dbo.Mng_User AS UX
                INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
            )
      )
    ORDER BY COALESCE(C.UpdatedAt, C.CreatedAt) DESC, C.ConversationID DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetMessages
    @ConversationID BIGINT,
    @UserID BIGINT,
    @CompanyID INT,
    @BeforeMessageID BIGINT = NULL,
    @PageSize INT = 50
AS
BEGIN
    SET NOCOUNT ON;
    IF @PageSize IS NULL OR @PageSize < 1 SET @PageSize = 50;
    IF @PageSize > 100 SET @PageSize = 100;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @UserID AND U.UsrState = 0
    )
        THROW 51100, N'المستخدم لا يملك عضوية فعالة في الشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID AND C.ConversationCompanyID = @CompanyID AND C.State = 0
          AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
    )
        THROW 51101, N'لا تملك صلاحية عرض هذه المحادثة في الشركة الحالية.', 1;

    IF EXISTS
    (
        SELECT 1 FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1 FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
              WHERE U.UsrID = CM.UserID AND U.UsrState = 0
          )
    )
        THROW 51102, N'تحتوي المحادثة على عضو لا يملك عضوية فعالة في الشركة الحالية.', 1;

    SELECT TOP (@PageSize)
        M.MessageID, M.ConversationID, M.SenderUserID,
        COALESCE(NULLIF(E.EmpName, N''), U.UsrLogIn, N'مستخدم') AS SenderName,
        E.EmpNum AS SenderEmpNum, E.EmpName AS SenderEmpName,
        CASE WHEN M.IsDeleted = 1 THEN N'تم حذف الرسالة' ELSE M.MessageText END AS MessageText,
        M.SentAt, M.EditedAt, M.IsDeleted,
        CAST(NULL AS NVARCHAR(MAX)) AS RecipientName,
        R.DeliveredAt, R.ReadAt,
        (SELECT COUNT_BIG(1) FROM dbo.Msg_MessageAttachment AS A WHERE A.MessageID = M.MessageID AND A.State = 0 AND M.IsDeleted = 0) AS AttachmentCount
    FROM dbo.Msg_Message AS M
    LEFT JOIN dbo.Mng_User AS U ON U.UsrID = M.SenderUserID AND U.UsrState = 0
    LEFT JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
    LEFT JOIN dbo.Msg_MessageReceipt AS R ON R.MessageID = M.MessageID AND R.UserID = @UserID AND R.State = 0
    WHERE M.ConversationID = @ConversationID
      AND M.State = 0
      AND (@BeforeMessageID IS NULL OR M.MessageID < @BeforeMessageID)
    ORDER BY M.MessageID DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_MarkConversationRead
    @ConversationID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @UserID AND U.UsrState = 0
    )
        THROW 51110, N'المستخدم لا يملك عضوية فعالة في الشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID AND C.ConversationCompanyID = @CompanyID AND C.State = 0
          AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        )
    )
        THROW 51111, N'لا تملك صلاحية الوصول إلى هذه المحادثة في الشركة الحالية.', 1;

    UPDATE R
    SET DeliveredAt = COALESCE(R.DeliveredAt, SYSDATETIME()),
        ReadAt = COALESCE(R.ReadAt, SYSDATETIME())
    FROM dbo.Msg_MessageReceipt AS R
    INNER JOIN dbo.Msg_Message AS M ON M.MessageID = R.MessageID
    INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
    WHERE C.ConversationID = @ConversationID
      AND C.ConversationCompanyID = @CompanyID
      AND M.SenderUserID <> @UserID
      AND R.UserID = @UserID AND R.State = 0
      AND M.State = 0 AND M.IsDeleted = 0;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_SendMessage
    @ConversationID BIGINT,
    @SenderUserID BIGINT,
    @MessageText NVARCHAR(MAX),
    @MessageID BIGINT OUTPUT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @MessageID = NULL;
    SET @MessageText = LTRIM(RTRIM(@MessageText));

    IF NULLIF(@MessageText, N'') IS NULL THROW 51020, N'نص الرسالة مطلوب.', 1;
    IF DATALENGTH(@MessageText) > 20000 THROW 51021, N'الحد الأقصى للرسالة 10000 حرف.', 1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE U.UsrID = @SenderUserID AND U.UsrState = 0
    )
        THROW 51022, N'المرسل لا يملك عضوية فعالة في الشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID AND C.ConversationCompanyID = @CompanyID AND C.State = 0
          AND CM.UserID = @SenderUserID AND CM.State = 0 AND CM.LeftAt IS NULL
    )
        THROW 51023, N'لا تملك صلاحية إرسال رسالة إلى هذه المحادثة في الشركة الحالية.', 1;

    IF EXISTS
    (
        SELECT 1 FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1 FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
              WHERE U.UsrID = CM.UserID AND U.UsrState = 0
          )
    )
        THROW 51024, N'توجد عضوية في المحادثة لا تنتمي للشركة الحالية.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;
        INSERT INTO dbo.Msg_Message(ConversationID, SenderUserID, MessageText, State)
        VALUES(@ConversationID, @SenderUserID, @MessageText, 0);
        SET @MessageID = CONVERT(BIGINT, SCOPE_IDENTITY());

        INSERT INTO dbo.Msg_MessageReceipt(MessageID, UserID, DeliveredAt, ReadAt, State)
        SELECT @MessageID, CM.UserID,
               CASE WHEN CM.UserID = @SenderUserID THEN SYSDATETIME() END,
               CASE WHEN CM.UserID = @SenderUserID THEN SYSDATETIME() END,
               0
        FROM dbo.Msg_ConversationMember AS CM
        INNER JOIN dbo.Mng_User AS U ON U.UsrID = CM.UserID AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE CM.ConversationID = @ConversationID AND CM.State = 0 AND CM.LeftAt IS NULL;

        UPDATE dbo.Msg_Conversation SET UpdatedAt = SYSDATETIME() WHERE ConversationID = @ConversationID AND ConversationCompanyID = @CompanyID;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        SET @MessageID = NULL;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_AddAttachment
    @MessageID BIGINT,
    @UserID BIGINT,
    @FileName NVARCHAR(260),
    @FileData VARBINARY(MAX),
    @CompanyID INT,
    @ContentType NVARCHAR(150) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @FileName = LTRIM(RTRIM(@FileName));
    IF NULLIF(@FileName, N'') IS NULL THROW 51050, N'اسم الملف مطلوب.', 1;
    IF @FileData IS NULL OR DATALENGTH(@FileData) = 0 THROW 51051, N'محتوى الملف فارغ.', 1;
    IF DATALENGTH(@FileData) > 10485760 THROW 51052, N'حجم المرفق يتجاوز 10 ميبيبايت.', 1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Message AS M
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        INNER JOIN dbo.Mng_User AS U ON U.UsrID = @UserID AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE M.MessageID = @MessageID AND M.SenderUserID = @UserID AND M.State = 0 AND M.IsDeleted = 0
          AND C.State = 0 AND C.ConversationCompanyID = @CompanyID
          AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        )
    )
        THROW 51054, N'يمكن إرفاق الملفات برسالتك فقط داخل الشركة الحالية.', 1;

    INSERT INTO dbo.Msg_MessageAttachment(MessageID, FileName, ContentType, FileSize, FileData, State)
    VALUES(@MessageID, @FileName, @ContentType, DATALENGTH(@FileData), @FileData, 0);
    SELECT CONVERT(BIGINT, SCOPE_IDENTITY()) AS AttachmentID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_DeleteAttachment
    @AttachmentID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    UPDATE A SET State = 1
    FROM dbo.Msg_MessageAttachment AS A
    INNER JOIN dbo.Msg_Message AS M ON M.MessageID = A.MessageID
    INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
    INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
    INNER JOIN dbo.Mng_User AS U ON U.UsrID = @UserID AND U.UsrState = 0
    INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
    INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
    WHERE A.AttachmentID = @AttachmentID AND A.State = 0
      AND M.State = 0 AND M.IsDeleted = 0 AND M.SenderUserID = @UserID
      AND C.State = 0 AND C.ConversationCompanyID = @CompanyID
      AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
      AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        );
    IF @@ROWCOUNT = 0 THROW 51061, N'المرفق غير موجود أو لا تملك صلاحية حذفه في الشركة الحالية.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_DeleteMessage
    @MessageID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE M SET IsDeleted = 1, DeletedAt = SYSDATETIME()
    FROM dbo.Msg_Message AS M
    INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
    INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
    INNER JOIN dbo.Mng_User AS U ON U.UsrID = @UserID AND U.UsrState = 0
    INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
    INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
    WHERE M.MessageID = @MessageID AND M.SenderUserID = @UserID AND M.IsDeleted = 0 AND M.State = 0
      AND C.State = 0 AND C.ConversationCompanyID = @CompanyID
      AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
      AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        );
    IF @@ROWCOUNT = 0 THROW 51233, N'لا يمكن حذف الرسالة أو أنها غير تابعة للشركة الحالية.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_EditMessage
    @MessageID BIGINT,
    @UserID BIGINT,
    @MessageText NVARCHAR(MAX),
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @MessageText = LTRIM(RTRIM(@MessageText));
    IF NULLIF(@MessageText, N'') IS NULL THROW 51230, N'نص الرسالة مطلوب.', 1;
    IF LEN(@MessageText) > 10000 THROW 51231, N'تجاوز نص الرسالة الحد المسموح.', 1;

    DECLARE @Now DATETIME2(0) = SYSDATETIME();
    BEGIN TRY
        BEGIN TRANSACTION;
        UPDATE M SET MessageText = @MessageText, EditedAt = @Now
        FROM dbo.Msg_Message AS M
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        INNER JOIN dbo.Mng_User AS U ON U.UsrID = @UserID AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE M.MessageID = @MessageID AND M.SenderUserID = @UserID AND M.IsDeleted = 0 AND M.State = 0
          AND C.State = 0 AND C.ConversationCompanyID = @CompanyID
          AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        );
        IF @@ROWCOUNT = 0 THROW 51233, N'لا يمكن تعديل الرسالة أو أنها ليست ضمن الشركة الحالية.', 1;

        UPDATE R
        SET ReadAt = CASE WHEN R.UserID = @UserID THEN COALESCE(R.ReadAt, @Now) ELSE NULL END
        FROM dbo.Msg_MessageReceipt AS R
        INNER JOIN dbo.Msg_Message AS M ON M.MessageID = R.MessageID
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
           AND CM.UserID = R.UserID
           AND CM.State = 0
           AND CM.LeftAt IS NULL
        INNER JOIN dbo.Mng_User AS UR ON UR.UsrID = R.UserID AND UR.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS ER ON ER.EmpID = UR.UsrID AND ER.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS USR
            ON USR.USUserID = UR.UsrID
           AND USR.USCompanyID = @CompanyID
           AND USR.USState = 0
        WHERE R.MessageID = @MessageID
          AND R.State = 0
          AND C.ConversationCompanyID = @CompanyID;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetAttachmentData
    @AttachmentID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_MessageAttachment AS A
        INNER JOIN dbo.Msg_Message AS M ON M.MessageID = A.MessageID
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        INNER JOIN dbo.Mng_User AS U ON U.UsrID = @UserID AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE A.AttachmentID = @AttachmentID AND A.State = 0 AND M.State = 0 AND M.IsDeleted = 0
          AND C.State = 0 AND C.ConversationCompanyID = @CompanyID
          AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        )
    )
        THROW 51061, N'المرفق غير موجود أو لا تملك صلاحية الوصول إليه في الشركة الحالية.', 1;

    SELECT A.AttachmentID, A.MessageID, A.FileName, A.ContentType, A.FileSize, A.FileData, A.UploadedAt
    FROM dbo.Msg_MessageAttachment AS A WHERE A.AttachmentID = @AttachmentID AND A.State = 0;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetAttachments
    @MessageID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Message AS M
        INNER JOIN dbo.Msg_Conversation AS C ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        INNER JOIN dbo.Mng_User AS U ON U.UsrID = @UserID AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE M.MessageID = @MessageID AND M.State = 0 AND M.IsDeleted = 0
          AND C.State = 0 AND C.ConversationCompanyID = @CompanyID
          AND CM.UserID = @UserID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_ConversationMember AS CMX
            WHERE CMX.ConversationID = C.ConversationID
              AND CMX.State = 0 AND CMX.LeftAt IS NULL
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.Mng_User AS UX
                  INNER JOIN dbo.Emp_Employee AS EX ON EX.EmpID = UX.UsrID AND EX.EmpState = 0
                  INNER JOIN dbo.Mng_UserSystem AS USX ON USX.USUserID = UX.UsrID AND USX.USCompanyID = @CompanyID AND USX.USState = 0
                  WHERE UX.UsrID = CMX.UserID AND UX.UsrState = 0
              )
        )
    )
        THROW 51071, N'لا تملك صلاحية عرض مرفقات هذه الرسالة في الشركة الحالية.', 1;

    SELECT A.AttachmentID, A.MessageID, A.FileName, A.ContentType, A.FileSize, A.UploadedAt
    FROM dbo.Msg_MessageAttachment AS A
    WHERE A.MessageID = @MessageID AND A.State = 0
    ORDER BY A.AttachmentID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_GetConversationMembers
    @ConversationID BIGINT,
    @RequestedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM ON CM.ConversationID = C.ConversationID
        INNER JOIN dbo.Mng_User AS U ON U.UsrID = @RequestedByUserID AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
        WHERE C.ConversationID = @ConversationID AND C.ConversationCompanyID = @CompanyID AND C.State = 0
          AND CM.UserID = @RequestedByUserID AND CM.State = 0 AND CM.LeftAt IS NULL
    )
        THROW 51081, N'لا تملك صلاحية عرض أعضاء هذه المحادثة في الشركة الحالية.', 1;

    IF EXISTS
    (
        SELECT 1 FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID AND CM.State = 0 AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1 FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
              WHERE U.UsrID = CM.UserID AND U.UsrState = 0
          )
    )
        THROW 51082, N'تحتوي المحادثة على عضو لا ينتمي إلى الشركة المحددة.', 1;

    SELECT CM.UserID, CM.MemberRole, CM.JoinedAt, E.EmpNum, E.EmpName,
           CONCAT(COALESCE(E.EmpNum, N''), CASE WHEN E.EmpNum IS NOT NULL AND E.EmpName IS NOT NULL THEN N' - ' ELSE N'' END, COALESCE(E.EmpName, U.UsrLogIn)) AS EmployeeDisplayName
    FROM dbo.Msg_ConversationMember AS CM
    INNER JOIN dbo.Mng_User AS U ON U.UsrID = CM.UserID AND U.UsrState = 0
    INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
    INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
    WHERE CM.ConversationID = @ConversationID AND CM.State = 0 AND CM.LeftAt IS NULL
    ORDER BY CM.JoinedAt, E.EmpName;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Msg_RemoveConversationMember
    @ConversationID BIGINT,
    @UserID BIGINT,
    @RemovedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS
        (
            SELECT 1 FROM dbo.Msg_Conversation AS C WITH (UPDLOCK, HOLDLOCK)
            INNER JOIN dbo.Mng_User AS U ON U.UsrID = @RemovedByUserID AND U.UsrState = 0
            INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
            INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
            WHERE C.ConversationID = @ConversationID AND C.ConversationCompanyID = @CompanyID
              AND C.ConversationType = 1 AND C.CreatedByUserID = @RemovedByUserID AND C.State = 0
        )
            THROW 51112, N'حذف الأعضاء متاح لمنشئ المجموعة داخل الشركة نفسها فقط.', 1;
        IF @UserID = @RemovedByUserID THROW 51113, N'لا يمكن لمنشئ المجموعة حذف عضويته بنفسه.', 1;
        IF NOT EXISTS
        (
            SELECT 1 FROM dbo.Mng_User AS U
            INNER JOIN dbo.Emp_Employee AS E ON E.EmpID = U.UsrID AND E.EmpState = 0
            INNER JOIN dbo.Mng_UserSystem AS US ON US.USUserID = U.UsrID AND US.USCompanyID = @CompanyID AND US.USState = 0
            WHERE U.UsrID = @UserID AND U.UsrState = 0
        )
            THROW 51116, N'العضو لا يملك عضوية فعالة في الشركة الحالية.', 1;
        UPDATE dbo.Msg_ConversationMember
        SET State = 1, LeftAt = COALESCE(LeftAt, SYSDATETIME())
        WHERE ConversationID = @ConversationID AND UserID = @UserID AND State = 0 AND LeftAt IS NULL;
        IF @@ROWCOUNT = 0 THROW 51114, N'العضو غير موجود في المجموعة أو أن عضويته غير نشطة.', 1;
        UPDATE dbo.Msg_Conversation SET UpdatedAt = SYSDATETIME() WHERE ConversationID = @ConversationID AND ConversationCompanyID = @CompanyID;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/*==============================================================
  6. LEGACY REVIEW AND FINAL CHECKS
==============================================================*/
/* Show old conversations whose company could not be inferred safely. */
SELECT
    C.ConversationID,
    C.ConversationType,
    C.CreatedByUserID,
    C.DirectUser1ID,
    C.DirectUser2ID,
    C.CreatedAt,
    N'يلزم تحديد الشركة يدويًا بعد مراجعة المحادثة وأعضائها' AS MigrationNote
FROM dbo.Msg_Conversation AS C
WHERE C.ConversationCompanyID IS NULL
ORDER BY C.ConversationID;
GO

/* Company-scoped active direct duplicates are reported, not silently merged. */
SELECT
    ConversationCompanyID,
    DirectUser1ID,
    DirectUser2ID,
    COUNT_BIG(*) AS DuplicateCount
FROM dbo.Msg_Conversation
WHERE ConversationType = 0
  AND State = 0
  AND ConversationCompanyID IS NOT NULL
GROUP BY ConversationCompanyID, DirectUser1ID, DirectUser2ID
HAVING COUNT_BIG(*) > 1;
GO

PRINT N'MADAR Message System company-scoped schema and procedures have been applied.';
PRINT N'Important: assign ConversationCompanyID for every unresolved legacy conversation listed above before reopening those old conversations.';
GO

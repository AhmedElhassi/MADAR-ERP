﻿USE [MADARERPDataBase];
GO

/*
    MADAR Message System - corrected for the current MADAR user/employee model.

    Identity rule:
      dbo.Mng_User.UsrID = dbo.Emp_Employee.EmpID (BIGINT)

    User / employee validation therefore joins:
      Emp_Employee.EmpID = Mng_User.UsrID

    Company access is validated through dbo.Mng_UserSystem.

    Deployment notes:
      - Existing tables are preserved; missing tables/constraints are created.
      - Duplicate legacy constraints named below are removed.
      - Procedures are created or altered.
      - No message data is deleted by this script.
*/

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/*==============================================================
  1. TABLES
==============================================================*/

IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_Conversation
    (
        ConversationID      BIGINT IDENTITY(1,1) NOT NULL,
        ConversationType   TINYINT NOT NULL,
        ConversationTitle  NVARCHAR(200) NULL,
        CreatedByUserID    BIGINT NOT NULL,
        DirectUser1ID      BIGINT NULL,
        DirectUser2ID      BIGINT NULL,
        CreatedAt          DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_Conversation_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt          DATETIME2(0) NULL,
        State              TINYINT NOT NULL
            CONSTRAINT DF_Msg_Conversation_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_Conversation
            PRIMARY KEY CLUSTERED (ConversationID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_ConversationMember', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_ConversationMember
    (
        ConversationMemberID BIGINT IDENTITY(1,1) NOT NULL,
        ConversationID       BIGINT NOT NULL,
        UserID               BIGINT NOT NULL,
        MemberRole           TINYINT NOT NULL
            CONSTRAINT DF_Msg_ConversationMember_Role DEFAULT ((0)),
        JoinedAt             DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_ConversationMember_JoinedAt DEFAULT (SYSDATETIME()),
        LeftAt               DATETIME2(0) NULL,
        State                TINYINT NOT NULL
            CONSTRAINT DF_Msg_ConversationMember_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_ConversationMember
            PRIMARY KEY CLUSTERED (ConversationMemberID),
        CONSTRAINT UQ_Msg_ConversationMember_Conversation_User
            UNIQUE NONCLUSTERED (ConversationID, UserID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_Message', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_Message
    (
        MessageID       BIGINT IDENTITY(1,1) NOT NULL,
        ConversationID  BIGINT NOT NULL,
        SenderUserID    BIGINT NOT NULL,
        MessageText     NVARCHAR(MAX) NULL,
        SentAt          DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_Message_SentAt DEFAULT (SYSDATETIME()),
        EditedAt        DATETIME2(0) NULL,
        IsDeleted       BIT NOT NULL
            CONSTRAINT DF_Msg_Message_IsDeleted DEFAULT ((0)),
        DeletedAt       DATETIME2(0) NULL,
        State           TINYINT NOT NULL
            CONSTRAINT DF_Msg_Message_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_Message
            PRIMARY KEY CLUSTERED (MessageID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_MessageAttachment', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_MessageAttachment
    (
        AttachmentID BIGINT IDENTITY(1,1) NOT NULL,
        MessageID    BIGINT NOT NULL,
        FileName     NVARCHAR(260) NOT NULL,
        ContentType  NVARCHAR(150) NULL,
        FileSize     BIGINT NOT NULL,
        FileData     VARBINARY(MAX) NOT NULL,
        UploadedAt   DATETIME2(0) NOT NULL
            CONSTRAINT DF_Msg_MessageAttachment_UploadedAt DEFAULT (SYSDATETIME()),
        State        TINYINT NOT NULL
            CONSTRAINT DF_Msg_MessageAttachment_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_MessageAttachment
            PRIMARY KEY CLUSTERED (AttachmentID)
    );
END;
GO

IF OBJECT_ID(N'dbo.Msg_MessageReceipt', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Msg_MessageReceipt
    (
        ReceiptID   BIGINT IDENTITY(1,1) NOT NULL,
        MessageID   BIGINT NOT NULL,
        UserID      BIGINT NOT NULL,
        DeliveredAt DATETIME2(0) NULL,
        ReadAt      DATETIME2(0) NULL,
        State       TINYINT NOT NULL
            CONSTRAINT DF_Msg_MessageReceipt_State DEFAULT ((0)),
        CONSTRAINT PK_Msg_MessageReceipt
            PRIMARY KEY CLUSTERED (ReceiptID),
        CONSTRAINT UQ_Msg_MessageReceipt_Message_User
            UNIQUE NONCLUSTERED (MessageID, UserID)
    );
END;
GO

/* Ensure defaults also exist when a table was already present. */
IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_Conversation'), N'CreatedAt', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_Conversation ADD CONSTRAINT DF_Msg_Conversation_CreatedAt
        DEFAULT (SYSDATETIME()) FOR CreatedAt;
GO

IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_Conversation'), N'State', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_Conversation ADD CONSTRAINT DF_Msg_Conversation_State
        DEFAULT ((0)) FOR State;
GO

IF OBJECT_ID(N'dbo.Msg_ConversationMember', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_ConversationMember'), N'MemberRole', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_ConversationMember ADD CONSTRAINT DF_Msg_ConversationMember_Role
        DEFAULT ((0)) FOR MemberRole;
GO

IF OBJECT_ID(N'dbo.Msg_ConversationMember', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_ConversationMember'), N'JoinedAt', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_ConversationMember ADD CONSTRAINT DF_Msg_ConversationMember_JoinedAt
        DEFAULT (SYSDATETIME()) FOR JoinedAt;
GO

IF OBJECT_ID(N'dbo.Msg_ConversationMember', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_ConversationMember'), N'State', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_ConversationMember ADD CONSTRAINT DF_Msg_ConversationMember_State
        DEFAULT ((0)) FOR State;
GO

IF OBJECT_ID(N'dbo.Msg_Message', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_Message')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_Message'), N'SentAt', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_Message ADD CONSTRAINT DF_Msg_Message_SentAt
        DEFAULT (SYSDATETIME()) FOR SentAt;
GO

IF OBJECT_ID(N'dbo.Msg_Message', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_Message')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_Message'), N'IsDeleted', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_Message ADD CONSTRAINT DF_Msg_Message_IsDeleted
        DEFAULT ((0)) FOR IsDeleted;
GO

IF OBJECT_ID(N'dbo.Msg_Message', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_Message')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_Message'), N'State', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_Message ADD CONSTRAINT DF_Msg_Message_State
        DEFAULT ((0)) FOR State;
GO

IF OBJECT_ID(N'dbo.Msg_MessageAttachment', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_MessageAttachment'), N'UploadedAt', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_MessageAttachment ADD CONSTRAINT DF_Msg_MessageAttachment_UploadedAt
        DEFAULT (SYSDATETIME()) FOR UploadedAt;
GO

IF OBJECT_ID(N'dbo.Msg_MessageAttachment', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_MessageAttachment'), N'State', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_MessageAttachment ADD CONSTRAINT DF_Msg_MessageAttachment_State
        DEFAULT ((0)) FOR State;
GO

IF OBJECT_ID(N'dbo.Msg_MessageReceipt', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.default_constraints
       WHERE parent_object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt')
         AND parent_column_id = COLUMNPROPERTY(OBJECT_ID(N'dbo.Msg_MessageReceipt'), N'State', 'ColumnId')
   )
    ALTER TABLE dbo.Msg_MessageReceipt ADD CONSTRAINT DF_Msg_MessageReceipt_State
        DEFAULT ((0)) FOR State;
GO

/* Remove redundant legacy constraints from the supplied migration. */
IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NOT NULL
   AND EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_User1'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation DROP CONSTRAINT FK_Msg_Conversation_User1;
GO

IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NOT NULL
   AND EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_User2'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation DROP CONSTRAINT FK_Msg_Conversation_User2;
GO

IF OBJECT_ID(N'dbo.Msg_Conversation', N'U') IS NOT NULL
   AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_Conversation_DirectPair'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation DROP CONSTRAINT CK_Msg_Conversation_DirectPair;
GO

IF OBJECT_ID(N'dbo.Msg_MessageAttachment', N'U') IS NOT NULL
   AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_MessageAttachment_Size'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    ALTER TABLE dbo.Msg_MessageAttachment DROP CONSTRAINT CK_Msg_MessageAttachment_Size;
GO

/* Foreign keys: every message user key points to Mng_User.UsrID (BIGINT). */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_Creator'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
        ADD CONSTRAINT FK_Msg_Conversation_Creator
        FOREIGN KEY (CreatedByUserID) REFERENCES dbo.Mng_User (UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_DirectUser1'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
        ADD CONSTRAINT FK_Msg_Conversation_DirectUser1
        FOREIGN KEY (DirectUser1ID) REFERENCES dbo.Mng_User (UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Conversation_DirectUser2'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
        ADD CONSTRAINT FK_Msg_Conversation_DirectUser2
        FOREIGN KEY (DirectUser2ID) REFERENCES dbo.Mng_User (UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_ConversationMember_Conversation'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK
        ADD CONSTRAINT FK_Msg_ConversationMember_Conversation
        FOREIGN KEY (ConversationID) REFERENCES dbo.Msg_Conversation (ConversationID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_ConversationMember_User'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK
        ADD CONSTRAINT FK_Msg_ConversationMember_User
        FOREIGN KEY (UserID) REFERENCES dbo.Mng_User (UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Message_Conversation'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Message'))
    ALTER TABLE dbo.Msg_Message WITH CHECK
        ADD CONSTRAINT FK_Msg_Message_Conversation
        FOREIGN KEY (ConversationID) REFERENCES dbo.Msg_Conversation (ConversationID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_Message_Sender'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Message'))
    ALTER TABLE dbo.Msg_Message WITH CHECK
        ADD CONSTRAINT FK_Msg_Message_Sender
        FOREIGN KEY (SenderUserID) REFERENCES dbo.Mng_User (UsrID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_MessageAttachment_Message'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    ALTER TABLE dbo.Msg_MessageAttachment WITH CHECK
        ADD CONSTRAINT FK_Msg_MessageAttachment_Message
        FOREIGN KEY (MessageID) REFERENCES dbo.Msg_Message (MessageID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_MessageReceipt_Message'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt'))
    ALTER TABLE dbo.Msg_MessageReceipt WITH CHECK
        ADD CONSTRAINT FK_Msg_MessageReceipt_Message
        FOREIGN KEY (MessageID) REFERENCES dbo.Msg_Message (MessageID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Msg_MessageReceipt_User'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageReceipt'))
    ALTER TABLE dbo.Msg_MessageReceipt WITH CHECK
        ADD CONSTRAINT FK_Msg_MessageReceipt_User
        FOREIGN KEY (UserID) REFERENCES dbo.Mng_User (UsrID);
GO

/* Check constraints: one authoritative definition for each rule. */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_Conversation_Structure'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
        ADD CONSTRAINT CK_Msg_Conversation_Structure CHECK
        (
            (ConversationType = 0
             AND DirectUser1ID IS NOT NULL
             AND DirectUser2ID IS NOT NULL
             AND DirectUser1ID < DirectUser2ID
             AND ConversationTitle IS NULL)
            OR
            (ConversationType = 1
             AND DirectUser1ID IS NULL
             AND DirectUser2ID IS NULL
             AND NULLIF(LTRIM(RTRIM(ConversationTitle)), N'') IS NOT NULL)
        );
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_Conversation_Type'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_Conversation'))
    ALTER TABLE dbo.Msg_Conversation WITH CHECK
        ADD CONSTRAINT CK_Msg_Conversation_Type CHECK (ConversationType IN (0, 1));
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_ConversationMember_Role'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_ConversationMember'))
    ALTER TABLE dbo.Msg_ConversationMember WITH CHECK
        ADD CONSTRAINT CK_Msg_ConversationMember_Role CHECK (MemberRole IN (0, 1));
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Msg_MessageAttachment_FileSize'
               AND parent_object_id = OBJECT_ID(N'dbo.Msg_MessageAttachment'))
    ALTER TABLE dbo.Msg_MessageAttachment WITH CHECK
        ADD CONSTRAINT CK_Msg_MessageAttachment_FileSize CHECK (FileSize > 0);
GO

/* Verify the identity columns supplied for this deployment are BIGINT. */
IF EXISTS
(
    SELECT 1
    FROM
    (
        VALUES
            (N'dbo.Msg_Conversation', N'CreatedByUserID'),
            (N'dbo.Msg_Conversation', N'DirectUser1ID'),
            (N'dbo.Msg_Conversation', N'DirectUser2ID'),
            (N'dbo.Msg_ConversationMember', N'UserID'),
            (N'dbo.Msg_Message', N'SenderUserID'),
            (N'dbo.Msg_MessageReceipt', N'UserID')
    ) AS RequiredColumns(TableName, ColumnName)
    INNER JOIN sys.tables T ON T.object_id = OBJECT_ID(RequiredColumns.TableName)
    LEFT JOIN sys.columns C
        ON C.object_id = T.object_id
       AND C.name = RequiredColumns.ColumnName
    WHERE C.column_id IS NULL OR C.system_type_id <> TYPE_ID(N'bigint')
)
    THROW 51990, N'يوجد عمود مستخدم في جداول الرسائل غير موجود أو ليس من النوع BIGINT. راجع بنية الجداول قبل متابعة الإجراءات.', 1;
GO

/*==============================================================
  2. PROCEDURES
==============================================================*/

/*--------------------------------------------------------------
  Msg_AddAttachment
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_AddAttachment
    @MessageID BIGINT,
    @UserID BIGINT,
    @FileName NVARCHAR(260),
    @FileData VARBINARY(MAX),
    @CompanyID INT,
    @ContentType NVARCHAR(150) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @FileName = LTRIM(RTRIM(@FileName));

    IF NULLIF(@FileName, N'') IS NULL
        THROW 51050, N'اسم الملف مطلوب.', 1;

    IF @FileData IS NULL OR DATALENGTH(@FileData) = 0
        THROW 51051, N'محتوى الملف فارغ.', 1;

    IF DATALENGTH(@FileData) > 10485760
        THROW 51052, N'حجم المرفق يتجاوز 10 ميبيبايت.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51053, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Message AS M
        INNER JOIN dbo.Msg_Conversation AS C
            ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE M.MessageID = @MessageID
          AND M.SenderUserID = @UserID
          AND M.IsDeleted = 0
          AND M.State = 0
          AND C.State = 0
          AND CM.UserID = @UserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Mng_UserSystem AS US
              WHERE US.USUserID = @UserID
                AND US.USCompanyID = @CompanyID
                AND US.USState = 0
          )
    )
        THROW 51054, N'يمكن إرفاق الملفات برسالتك فقط، مع ضرورة امتلاك صلاحية الوصول إليها.', 1;

    INSERT INTO dbo.Msg_MessageAttachment
    (
        MessageID, FileName, ContentType, FileSize, FileData, State
    )
    VALUES
    (
        @MessageID, @FileName, @ContentType,
        DATALENGTH(@FileData), @FileData, 0
    );

    SELECT CONVERT(BIGINT, SCOPE_IDENTITY()) AS AttachmentID;
END;
GO

/*--------------------------------------------------------------
  Msg_AddConversationMember
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_AddConversationMember
    @ConversationID BIGINT,
    @UserID BIGINT,
    @AddedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @AddedByUserID
          AND U.UsrState = 0
    )
        THROW 51010, N'المستخدم المنفذ غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51011, N'العضو المراد إضافته غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation AS C
        WHERE C.ConversationID = @ConversationID
          AND C.ConversationType = 1
          AND C.State = 0
          AND C.CreatedByUserID = @AddedByUserID
    )
        THROW 51112, N'إضافة الأعضاء متاحة لمنشئ المجموعة فقط.', 1;

    IF @UserID = @AddedByUserID
        THROW 51013, N'منشئ المجموعة عضو فيها بالفعل.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID
          AND CM.UserID = @UserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
    )
        THROW 51014, N'المستخدم عضو بالفعل في هذه المجموعة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID
          AND CM.UserID = @UserID
    )
    BEGIN
        UPDATE dbo.Msg_ConversationMember
        SET State = 0,
            LeftAt = NULL,
            JoinedAt = SYSDATETIME()
        WHERE ConversationID = @ConversationID
          AND UserID = @UserID;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.Msg_ConversationMember
        (
            ConversationID, UserID, MemberRole, State
        )
        VALUES
        (
            @ConversationID, @UserID, 0, 0
        );
    END;

    UPDATE dbo.Msg_Conversation
    SET UpdatedAt = SYSDATETIME()
    WHERE ConversationID = @ConversationID;
END;
GO

/*--------------------------------------------------------------
  Msg_CreateConversation
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_CreateConversation
    @ConversationType TINYINT,
    @CreatedByUserID BIGINT,
    @ConversationID BIGINT OUTPUT,
    @CompanyID INT,
    @OtherUserID BIGINT = NULL,
    @ConversationTitle NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        SET @ConversationID = NULL;

        IF @CompanyID IS NULL
            THROW 51000, N'يجب تحديد الشركة الحالية.', 1;

        IF @ConversationType IS NULL OR @ConversationType NOT IN (0, 1)
            THROW 51002, N'نوع المحادثة غير صحيح.', 1;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Mng_User AS U
            INNER JOIN dbo.Emp_Employee AS E
                ON E.EmpID = U.UsrID
               AND E.EmpState = 0
            INNER JOIN dbo.Mng_UserSystem AS US
                ON US.USUserID = U.UsrID
               AND US.USCompanyID = @CompanyID
               AND US.USState = 0
            WHERE U.UsrID = @CreatedByUserID
              AND U.UsrState = 0
        )
            THROW 51001, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

        BEGIN TRANSACTION;

        IF @ConversationType = 0
        BEGIN
            IF @OtherUserID IS NULL OR @OtherUserID = @CreatedByUserID
                THROW 51003, N'حدد مستخدماً آخر للمحادثة الفردية.', 1;

            IF NOT EXISTS
            (
                SELECT 1
                FROM dbo.Mng_User AS U
                INNER JOIN dbo.Emp_Employee AS E
                    ON E.EmpID = U.UsrID
                   AND E.EmpState = 0
                INNER JOIN dbo.Mng_UserSystem AS US
                    ON US.USUserID = U.UsrID
                   AND US.USCompanyID = @CompanyID
                   AND US.USState = 0
                WHERE U.UsrID = @OtherUserID
                  AND U.UsrState = 0
            )
                THROW 51004, N'المستخدم الآخر غير فعال أو غير مرتبط بالشركة الحالية.', 1;

            DECLARE @U1 BIGINT =
                CASE WHEN @CreatedByUserID < @OtherUserID
                     THEN @CreatedByUserID ELSE @OtherUserID END;

            DECLARE @U2 BIGINT =
                CASE WHEN @CreatedByUserID < @OtherUserID
                     THEN @OtherUserID ELSE @CreatedByUserID END;

            SELECT TOP (1)
                @ConversationID = C.ConversationID
            FROM dbo.Msg_Conversation AS C WITH (UPDLOCK, HOLDLOCK)
            WHERE C.ConversationType = 0
              AND C.State = 0
              AND C.DirectUser1ID = @U1
              AND C.DirectUser2ID = @U2
            ORDER BY C.ConversationID DESC;

            IF @ConversationID IS NULL
            BEGIN
                INSERT INTO dbo.Msg_Conversation
                (
                    ConversationType,
                    CreatedByUserID,
                    DirectUser1ID,
                    DirectUser2ID,
                    State
                )
                VALUES
                (
                    0,
                    @CreatedByUserID,
                    @U1,
                    @U2,
                    0
                );

                SET @ConversationID = CONVERT(BIGINT, SCOPE_IDENTITY());
            END;

            /* Ensure both direct participants have an active membership. */
            IF EXISTS
            (
                SELECT 1
                FROM dbo.Msg_ConversationMember
                WHERE ConversationID = @ConversationID
                  AND UserID = @U1
            )
            BEGIN
                UPDATE dbo.Msg_ConversationMember
                SET State = 0,
                    LeftAt = NULL,
                    JoinedAt = CASE
                        WHEN State <> 0 OR LeftAt IS NOT NULL
                            THEN SYSDATETIME()
                        ELSE JoinedAt
                    END
                WHERE ConversationID = @ConversationID
                  AND UserID = @U1;
            END
            ELSE
            BEGIN
                INSERT INTO dbo.Msg_ConversationMember
                    (ConversationID, UserID, MemberRole, State)
                VALUES
                    (@ConversationID, @U1, 0, 0);
            END;

            IF EXISTS
            (
                SELECT 1
                FROM dbo.Msg_ConversationMember
                WHERE ConversationID = @ConversationID
                  AND UserID = @U2
            )
            BEGIN
                UPDATE dbo.Msg_ConversationMember
                SET State = 0,
                    LeftAt = NULL,
                    JoinedAt = CASE
                        WHEN State <> 0 OR LeftAt IS NOT NULL
                            THEN SYSDATETIME()
                        ELSE JoinedAt
                    END
                WHERE ConversationID = @ConversationID
                  AND UserID = @U2;
            END
            ELSE
            BEGIN
                INSERT INTO dbo.Msg_ConversationMember
                    (ConversationID, UserID, MemberRole, State)
                VALUES
                    (@ConversationID, @U2, 0, 0);
            END;

            UPDATE dbo.Msg_Conversation
            SET UpdatedAt = SYSDATETIME()
            WHERE ConversationID = @ConversationID;
        END
        ELSE
        BEGIN
            SET @ConversationTitle = LTRIM(RTRIM(@ConversationTitle));

            IF NULLIF(@ConversationTitle, N'') IS NULL
                THROW 51005, N'اسم المجموعة مطلوب.', 1;

            INSERT INTO dbo.Msg_Conversation
            (
                ConversationType,
                ConversationTitle,
                CreatedByUserID,
                State
            )
            VALUES
            (
                1,
                @ConversationTitle,
                @CreatedByUserID,
                0
            );

            SET @ConversationID = CONVERT(BIGINT, SCOPE_IDENTITY());

            INSERT INTO dbo.Msg_ConversationMember
            (
                ConversationID, UserID, MemberRole, State
            )
            VALUES
            (
                @ConversationID, @CreatedByUserID, 1, 0
            );
        END;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        SET @ConversationID = NULL;
        THROW;
    END CATCH;
END;
GO

/*--------------------------------------------------------------
  Msg_DeleteAttachment
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_DeleteAttachment
    @AttachmentID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51060, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    BEGIN TRANSACTION;

    UPDATE A
    SET A.State = 1
    FROM dbo.Msg_MessageAttachment AS A
    INNER JOIN dbo.Msg_Message AS M
        ON M.MessageID = A.MessageID
    INNER JOIN dbo.Msg_Conversation AS C
        ON C.ConversationID = M.ConversationID
    WHERE A.AttachmentID = @AttachmentID
      AND A.State = 0
      AND M.State = 0
      AND M.IsDeleted = 0
      AND M.SenderUserID = @UserID
      AND C.State = 0
      AND EXISTS
      (
          SELECT 1
          FROM dbo.Msg_ConversationMember AS CM
          WHERE CM.ConversationID = C.ConversationID
            AND CM.UserID = @UserID
            AND CM.State = 0
            AND CM.LeftAt IS NULL
      )
      AND EXISTS
      (
          SELECT 1
          FROM dbo.Mng_UserSystem AS US
          WHERE US.USUserID = @UserID
            AND US.USCompanyID = @CompanyID
            AND US.USState = 0
      );

    IF @@ROWCOUNT = 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 51061, N'المرفق غير موجود أو لا تملك صلاحية حذفه.', 1;
    END;

    COMMIT TRANSACTION;
END;
GO

/*--------------------------------------------------------------
  Msg_DeleteMessage
  Soft deletion; DeletedAt is populated and the row remains in history.
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_DeleteMessage
    @MessageID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51232, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    UPDATE M
    SET M.IsDeleted = 1,
        M.DeletedAt = SYSDATETIME()
    FROM dbo.Msg_Message AS M
    INNER JOIN dbo.Msg_Conversation AS C
        ON C.ConversationID = M.ConversationID
    WHERE M.MessageID = @MessageID
      AND M.SenderUserID = @UserID
      AND M.IsDeleted = 0
      AND M.State = 0
      AND C.State = 0
      AND EXISTS
      (
          SELECT 1
          FROM dbo.Msg_ConversationMember AS CM
          WHERE CM.ConversationID = M.ConversationID
            AND CM.UserID = @UserID
            AND CM.State = 0
            AND CM.LeftAt IS NULL
      );

    IF @@ROWCOUNT = 0
        THROW 51233, N'لا يمكن حذف الرسالة أو أنها لم تعد متاحة.', 1;
END;
GO

/*--------------------------------------------------------------
  Msg_EditMessage
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_EditMessage
    @MessageID BIGINT,
    @UserID BIGINT,
    @MessageText NVARCHAR(MAX),
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @MessageText = LTRIM(RTRIM(@MessageText));

    IF NULLIF(@MessageText, N'') IS NULL
        THROW 51230, N'نص الرسالة مطلوب.', 1;

    IF LEN(@MessageText) > 10000
        THROW 51231, N'تجاوز نص الرسالة الحد المسموح.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51232, N'المستخدم غير فعال أو غير مرتبط بالشركة.', 1;

    DECLARE @Now DATETIME2(0) = SYSDATETIME();

    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE M
        SET M.MessageText = @MessageText,
            M.EditedAt = @Now
        FROM dbo.Msg_Message AS M
        INNER JOIN dbo.Msg_Conversation AS C
            ON C.ConversationID = M.ConversationID
        WHERE M.MessageID = @MessageID
          AND M.SenderUserID = @UserID
          AND M.IsDeleted = 0
          AND M.State = 0
          AND C.State = 0
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Msg_ConversationMember AS CM
              WHERE CM.ConversationID = M.ConversationID
                AND CM.UserID = @UserID
                AND CM.State = 0
                AND CM.LeftAt IS NULL
          )
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Mng_UserSystem AS US
              WHERE US.USUserID = @UserID
                AND US.USCompanyID = @CompanyID
                AND US.USState = 0
          );

        IF @@ROWCOUNT = 0
            THROW 51233, N'لا يمكن تعديل الرسالة أو أنها لم تعد متاحة.', 1;

        /* Edited message becomes unread for other active recipients. */
        UPDATE R
        SET R.ReadAt =
            CASE
                WHEN R.UserID = @UserID THEN COALESCE(R.ReadAt, @Now)
                ELSE NULL
            END
        FROM dbo.Msg_MessageReceipt AS R
        WHERE R.MessageID = @MessageID
          AND R.State = 0;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

/*--------------------------------------------------------------
  Msg_GetAttachmentData
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_GetAttachmentData
    @AttachmentID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51060, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_MessageAttachment AS A
        INNER JOIN dbo.Msg_Message AS M
            ON M.MessageID = A.MessageID
        INNER JOIN dbo.Msg_Conversation AS C
            ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE A.AttachmentID = @AttachmentID
          AND A.State = 0
          AND M.State = 0
          AND M.IsDeleted = 0
          AND C.State = 0
          AND CM.UserID = @UserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Mng_UserSystem AS US
              WHERE US.USUserID = @UserID
                AND US.USCompanyID = @CompanyID
                AND US.USState = 0
          )
    )
        THROW 51061, N'المرفق غير موجود أو لا تملك صلاحية الوصول إليه.', 1;

    SELECT
        A.AttachmentID,
        A.MessageID,
        A.FileName,
        A.ContentType,
        A.FileSize,
        A.FileData,
        A.UploadedAt
    FROM dbo.Msg_MessageAttachment AS A
    WHERE A.AttachmentID = @AttachmentID
      AND A.State = 0;
END;
GO

/*--------------------------------------------------------------
  Msg_GetAttachments
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_GetAttachments
    @MessageID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51070, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Message AS M
        INNER JOIN dbo.Msg_Conversation AS C
            ON C.ConversationID = M.ConversationID
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE M.MessageID = @MessageID
          AND M.State = 0
          AND M.IsDeleted = 0
          AND C.State = 0
          AND CM.UserID = @UserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Mng_UserSystem AS US
              WHERE US.USUserID = @UserID
                AND US.USCompanyID = @CompanyID
                AND US.USState = 0
          )
    )
        THROW 51071, N'لا تملك صلاحية عرض مرفقات هذه الرسالة.', 1;

    SELECT
        A.AttachmentID,
        A.MessageID,
        A.FileName,
        A.ContentType,
        A.FileSize,
        A.UploadedAt
    FROM dbo.Msg_MessageAttachment AS A
    WHERE A.MessageID = @MessageID
      AND A.State = 0
    ORDER BY A.AttachmentID;
END;
GO

/*--------------------------------------------------------------
  Msg_GetConversationMembers
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_GetConversationMembers
    @ConversationID BIGINT,
    @RequestedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @RequestedByUserID
          AND U.UsrState = 0
    )
        THROW 51080, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID
          AND C.State = 0
          AND CM.UserID = @RequestedByUserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
    )
        THROW 51081, N'لا تملك صلاحية عرض أعضاء هذه المحادثة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E
                  ON E.EmpID = U.UsrID
                 AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US
                  ON US.USUserID = U.UsrID
                 AND US.USCompanyID = @CompanyID
                 AND US.USState = 0
              WHERE U.UsrID = CM.UserID
                AND U.UsrState = 0
          )
    )
        THROW 51082, N'المحادثة ليست ضمن نطاق الشركة الحالية.', 1;

    SELECT
        CM.UserID,
        CM.MemberRole,
        CM.JoinedAt,
        E.EmpNum,
        E.EmpName,
        CONCAT(E.EmpNum, N' - ', E.EmpName) AS EmployeeDisplayName
    FROM dbo.Msg_ConversationMember AS CM
    INNER JOIN dbo.Mng_User AS U
        ON U.UsrID = CM.UserID
       AND U.UsrState = 0
    INNER JOIN dbo.Emp_Employee AS E
        ON E.EmpID = U.UsrID
       AND E.EmpState = 0
    WHERE CM.ConversationID = @ConversationID
      AND CM.State = 0
      AND CM.LeftAt IS NULL
      AND EXISTS
      (
          SELECT 1
          FROM dbo.Mng_UserSystem AS US
          WHERE US.USUserID = U.UsrID
            AND US.USCompanyID = @CompanyID
            AND US.USState = 0
      )
    ORDER BY CM.JoinedAt, E.EmpName;
END;
GO

/*--------------------------------------------------------------
  Msg_GetConversations
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_GetConversations
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51090, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    SELECT
        C.ConversationID,
        C.ConversationType,
        C.ConversationTitle,
        C.CreatedAt,
        C.UpdatedAt,

        CASE
            WHEN C.ConversationType = 1 THEN C.ConversationTitle
            ELSE COALESCE
            (
                NULLIF
                (
                    LTRIM(RTRIM(CONCAT
                    (
                        COALESCE(NULLIF(EO.EmpNum, N''), N''),
                        CASE
                            WHEN NULLIF(EO.EmpNum, N'') IS NOT NULL
                             AND NULLIF(EO.EmpName, N'') IS NOT NULL
                                THEN N' - '
                            ELSE N''
                        END,
                        COALESCE(NULLIF(EO.EmpName, N''), NULLIF(OtherU.UsrLogIn, N''), N'مستخدم')
                    ))),
                    N''
                ),
                N'محادثة فردية'
            )
        END AS DisplayName,

        LM.MessageID AS LastMessageID,

        CASE
            WHEN LM.IsDeleted = 1 THEN N'تم حذف الرسالة'
            ELSE LM.MessageText
        END AS LastMessageText,

        LM.SentAt AS LastMessageAt,
        LM.SenderUserID AS LastSenderUserID,

        CASE
            WHEN LM.SenderUserID IS NULL THEN NULL
            ELSE COALESCE
            (
                NULLIF
                (
                    LTRIM(RTRIM(CONCAT
                    (
                        COALESCE(NULLIF(ES.EmpNum, N''), N''),
                        CASE
                            WHEN NULLIF(ES.EmpNum, N'') IS NOT NULL
                             AND NULLIF(ES.EmpName, N'') IS NOT NULL
                                THEN N' - '
                            ELSE N''
                        END,
                        COALESCE(NULLIF(ES.EmpName, N''), NULLIF(SenderU.UsrLogIn, N''), N'مستخدم')
                    ))),
                    N''
                ),
                N'مستخدم'
            )
        END AS LastSenderName,

        (
            SELECT COUNT_BIG(1)
            FROM dbo.Msg_MessageReceipt AS R
            INNER JOIN dbo.Msg_Message AS M2
                ON M2.MessageID = R.MessageID
            WHERE M2.ConversationID = C.ConversationID
              AND R.UserID = @UserID
              AND R.ReadAt IS NULL
              AND R.State = 0
              AND M2.SenderUserID <> @UserID
              AND M2.IsDeleted = 0
              AND M2.State = 0
        ) AS UnreadCount,

        C.CreatedByUserID

    FROM dbo.Msg_Conversation AS C

    INNER JOIN dbo.Msg_ConversationMember AS MyM
        ON MyM.ConversationID = C.ConversationID
       AND MyM.UserID = @UserID
       AND MyM.State = 0
       AND MyM.LeftAt IS NULL

    LEFT JOIN dbo.Mng_User AS OtherU
        ON OtherU.UsrID =
            CASE
                WHEN C.DirectUser1ID = @UserID THEN C.DirectUser2ID
                ELSE C.DirectUser1ID
            END
       AND C.ConversationType = 0
       AND OtherU.UsrState = 0

    LEFT JOIN dbo.Emp_Employee AS EO
        ON EO.EmpID = OtherU.UsrID
       AND EO.EmpState = 0

    OUTER APPLY
    (
        SELECT TOP (1)
            M.MessageID,
            M.MessageText,
            M.SentAt,
            M.SenderUserID,
            M.IsDeleted
        FROM dbo.Msg_Message AS M
        WHERE M.ConversationID = C.ConversationID
          AND M.State = 0
        ORDER BY M.MessageID DESC
    ) AS LM

    LEFT JOIN dbo.Mng_User AS SenderU
        ON SenderU.UsrID = LM.SenderUserID

    LEFT JOIN dbo.Emp_Employee AS ES
        ON ES.EmpID = SenderU.UsrID

    WHERE C.State = 0
      AND EXISTS
      (
          SELECT 1
          FROM dbo.Mng_UserSystem AS US
          WHERE US.USUserID = @UserID
            AND US.USCompanyID = @CompanyID
            AND US.USState = 0
      )
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.Msg_ConversationMember AS X
          WHERE X.ConversationID = C.ConversationID
            AND X.State = 0
            AND X.LeftAt IS NULL
            AND NOT EXISTS
            (
                SELECT 1
                FROM dbo.Mng_User AS UX
                INNER JOIN dbo.Emp_Employee AS EX
                    ON EX.EmpID = UX.UsrID
                   AND EX.EmpState = 0
                INNER JOIN dbo.Mng_UserSystem AS USX
                    ON USX.USUserID = UX.UsrID
                   AND USX.USCompanyID = @CompanyID
                   AND USX.USState = 0
                WHERE UX.UsrID = X.UserID
                  AND UX.UsrState = 0
            )
      )

    ORDER BY
        COALESCE(C.UpdatedAt, C.CreatedAt) DESC,
        C.ConversationID DESC;
END;
GO

/*--------------------------------------------------------------
  Msg_GetMessages
  Deleted messages remain in the conversation as a tombstone row.
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_GetMessages
    @ConversationID BIGINT,
    @UserID BIGINT,
    @CompanyID INT,
    @BeforeMessageID BIGINT = NULL,
    @PageSize INT = 50
AS
BEGIN
    SET NOCOUNT ON;

    IF @PageSize IS NULL OR @PageSize < 1
        SET @PageSize = 50;

    IF @PageSize > 100
        SET @PageSize = 100;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51100, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID
          AND C.State = 0
          AND CM.UserID = @UserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
    )
        THROW 51101, N'لا تملك صلاحية عرض هذه المحادثة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E
                  ON E.EmpID = U.UsrID
                 AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US
                  ON US.USUserID = U.UsrID
                 AND US.USCompanyID = @CompanyID
                 AND US.USState = 0
              WHERE U.UsrID = CM.UserID
                AND U.UsrState = 0
          )
    )
        THROW 51102, N'المحادثة ليست ضمن نطاق الشركة الحالية.', 1;

    SELECT TOP (@PageSize)
        M.MessageID,
        M.ConversationID,
        M.SenderUserID,

        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(CONCAT
                (
                    COALESCE(NULLIF(E.EmpNum, N''), N''),
                    CASE
                        WHEN NULLIF(E.EmpNum, N'') IS NOT NULL
                         AND NULLIF(E.EmpName, N'') IS NOT NULL
                            THEN N' - '
                        ELSE N''
                    END,
                    COALESCE(NULLIF(E.EmpName, N''), NULLIF(U.UsrLogIn, N''), N'مستخدم')
                ))),
                N''
            ),
            N'مستخدم'
        ) AS SenderName,

        E.EmpNum AS SenderEmpNum,
        E.EmpName AS SenderEmpName,

        CASE
            WHEN M.IsDeleted = 1 THEN N'تم حذف الرسالة'
            ELSE M.MessageText
        END AS MessageText,

        M.SentAt,
        M.EditedAt,
        M.IsDeleted,
        CAST(NULL AS NVARCHAR(MAX)) AS RecipientName,
        R.DeliveredAt,
        R.ReadAt,

        (
            SELECT COUNT_BIG(1)
            FROM dbo.Msg_MessageAttachment AS A
            WHERE A.MessageID = M.MessageID
              AND A.State = 0
              AND M.IsDeleted = 0
        ) AS AttachmentCount

    FROM dbo.Msg_Message AS M

    LEFT JOIN dbo.Mng_User AS U
        ON U.UsrID = M.SenderUserID

    LEFT JOIN dbo.Emp_Employee AS E
        ON E.EmpID = U.UsrID

    LEFT JOIN dbo.Msg_MessageReceipt AS R
        ON R.MessageID = M.MessageID
       AND R.UserID = @UserID
       AND R.State = 0

    WHERE M.ConversationID = @ConversationID
      AND M.State = 0
      AND (@BeforeMessageID IS NULL OR M.MessageID < @BeforeMessageID)

    ORDER BY M.MessageID DESC;
END;
GO

/*--------------------------------------------------------------
  Msg_MarkConversationRead
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_MarkConversationRead
    @ConversationID BIGINT,
    @UserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @UserID
          AND U.UsrState = 0
    )
        THROW 51110, N'المستخدم غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID
          AND C.State = 0
          AND CM.UserID = @UserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
    )
        THROW 51111, N'لا تملك صلاحية الوصول إلى هذه المحادثة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E
                  ON E.EmpID = U.UsrID
                 AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US
                  ON US.USUserID = U.UsrID
                 AND US.USCompanyID = @CompanyID
                 AND US.USState = 0
              WHERE U.UsrID = CM.UserID
                AND U.UsrState = 0
          )
    )
        THROW 51112, N'المحادثة ليست ضمن نطاق الشركة الحالية.', 1;

    UPDATE R
    SET R.DeliveredAt = COALESCE(R.DeliveredAt, SYSDATETIME()),
        R.ReadAt = COALESCE(R.ReadAt, SYSDATETIME())
    FROM dbo.Msg_MessageReceipt AS R
    INNER JOIN dbo.Msg_Message AS M
        ON M.MessageID = R.MessageID
    WHERE M.ConversationID = @ConversationID
      AND M.SenderUserID <> @UserID
      AND R.UserID = @UserID
      AND R.State = 0
      AND M.State = 0
      AND M.IsDeleted = 0;
END;
GO

/*--------------------------------------------------------------
  Msg_RemoveConversationMember
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_RemoveConversationMember
    @ConversationID BIGINT,
    @UserID BIGINT,
    @RemovedByUserID BIGINT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Mng_User AS U
            INNER JOIN dbo.Emp_Employee AS E
                ON E.EmpID = U.UsrID
               AND E.EmpState = 0
            INNER JOIN dbo.Mng_UserSystem AS US
                ON US.USUserID = U.UsrID
               AND US.USCompanyID = @CompanyID
               AND US.USState = 0
            WHERE U.UsrID = @RemovedByUserID
              AND U.UsrState = 0
        )
            THROW 51115, N'المستخدم المنفذ غير فعال أو غير مرتبط بالشركة الحالية.', 1;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.Msg_Conversation WITH (UPDLOCK, HOLDLOCK)
            WHERE ConversationID = @ConversationID
              AND ConversationType = 1
              AND CreatedByUserID = @RemovedByUserID
              AND State = 0
        )
            THROW 51112, N'حذف الأعضاء متاح لمنشئ المجموعة فقط.', 1;

        IF @UserID = @RemovedByUserID
            THROW 51113, N'لا يمكن لمنشئ المجموعة حذف عضويته بنفسه.', 1;

        UPDATE dbo.Msg_ConversationMember
        SET State = 1,
            LeftAt = COALESCE(LeftAt, SYSDATETIME())
        WHERE ConversationID = @ConversationID
          AND UserID = @UserID
          AND State = 0
          AND LeftAt IS NULL;

        IF @@ROWCOUNT = 0
            THROW 51114, N'العضو غير موجود في المجموعة أو أن عضويته غير نشطة.', 1;

        UPDATE dbo.Msg_Conversation
        SET UpdatedAt = SYSDATETIME()
        WHERE ConversationID = @ConversationID;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

/*--------------------------------------------------------------
  Msg_SendMessage
--------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.Msg_SendMessage
    @ConversationID BIGINT,
    @SenderUserID BIGINT,
    @MessageText NVARCHAR(MAX),
    @MessageID BIGINT OUTPUT,
    @CompanyID INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @MessageID = NULL;
    SET @MessageText = LTRIM(RTRIM(@MessageText));

    IF NULLIF(@MessageText, N'') IS NULL
        THROW 51020, N'نص الرسالة مطلوب.', 1;

    IF DATALENGTH(@MessageText) > 20000
        THROW 51021, N'الحد الأقصى للرسالة 10000 حرف.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Mng_User AS U
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        INNER JOIN dbo.Mng_UserSystem AS US
            ON US.USUserID = U.UsrID
           AND US.USCompanyID = @CompanyID
           AND US.USState = 0
        WHERE U.UsrID = @SenderUserID
          AND U.UsrState = 0
    )
        THROW 51022, N'المرسل غير فعال أو غير مرتبط بالشركة الحالية.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Msg_Conversation AS C
        INNER JOIN dbo.Msg_ConversationMember AS CM
            ON CM.ConversationID = C.ConversationID
        WHERE C.ConversationID = @ConversationID
          AND C.State = 0
          AND CM.UserID = @SenderUserID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
    )
        THROW 51023, N'لا تملك صلاحية إرسال رسالة إلى هذه المحادثة.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.Msg_ConversationMember AS CM
        WHERE CM.ConversationID = @ConversationID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.Mng_User AS U
              INNER JOIN dbo.Emp_Employee AS E
                  ON E.EmpID = U.UsrID
                 AND E.EmpState = 0
              INNER JOIN dbo.Mng_UserSystem AS US
                  ON US.USUserID = U.UsrID
                 AND US.USCompanyID = @CompanyID
                 AND US.USState = 0
              WHERE U.UsrID = CM.UserID
                AND U.UsrState = 0
          )
    )
        THROW 51024, N'توجد عضوية في المحادثة خارج نطاق الشركة الحالية أو غير فعالة.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO dbo.Msg_Message
        (
            ConversationID,
            SenderUserID,
            MessageText,
            State
        )
        VALUES
        (
            @ConversationID,
            @SenderUserID,
            @MessageText,
            0
        );

        SET @MessageID = CONVERT(BIGINT, SCOPE_IDENTITY());

        INSERT INTO dbo.Msg_MessageReceipt
        (
            MessageID,
            UserID,
            DeliveredAt,
            ReadAt,
            State
        )
        SELECT
            @MessageID,
            CM.UserID,
            CASE WHEN CM.UserID = @SenderUserID THEN SYSDATETIME() ELSE NULL END,
            CASE WHEN CM.UserID = @SenderUserID THEN SYSDATETIME() ELSE NULL END,
            0
        FROM dbo.Msg_ConversationMember AS CM
        INNER JOIN dbo.Mng_User AS U
            ON U.UsrID = CM.UserID
           AND U.UsrState = 0
        INNER JOIN dbo.Emp_Employee AS E
            ON E.EmpID = U.UsrID
           AND E.EmpState = 0
        WHERE CM.ConversationID = @ConversationID
          AND CM.State = 0
          AND CM.LeftAt IS NULL
          AND EXISTS
          (
              SELECT 1
              FROM dbo.Mng_UserSystem AS US
              WHERE US.USUserID = U.UsrID
                AND US.USCompanyID = @CompanyID
                AND US.USState = 0
          );

        UPDATE dbo.Msg_Conversation
        SET UpdatedAt = SYSDATETIME()
        WHERE ConversationID = @ConversationID;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        SET @MessageID = NULL;
        THROW;
    END CATCH;
END;
GO

/*==============================================================
  3. FINAL STRUCTURE CHECKS
==============================================================*/

IF EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE parent_object_id IN
    (
        OBJECT_ID(N'dbo.Msg_Conversation'),
        OBJECT_ID(N'dbo.Msg_ConversationMember'),
        OBJECT_ID(N'dbo.Msg_Message'),
        OBJECT_ID(N'dbo.Msg_MessageReceipt')
    )
      AND is_disabled = 1
)
    THROW 51991, N'يوجد مفتاح أجنبي معطل في جداول الرسائل. راجع قيود العلاقات.', 1;
GO

PRINT N'MADAR Message System: corrected tables and procedures have been applied.';
GO

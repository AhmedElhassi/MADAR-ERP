﻿/* MADAR patch: Acc_SaveCurrency referenced the non-existent table Emp_ContractSalary; salary currency lives in Emp_Salary. */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[Acc_SaveCurrency]
    @CurID          BIGINT = NULL OUTPUT,
    @CurCmp         INT,
    @CurCode        NVARCHAR(3),
    @CurName        NVARCHAR(100),
    @CurSymbol      NVARCHAR(10) = NULL,
    @CurDecimals    TINYINT = 3,
    @CurIsBase      BIT = 0,
    @CurState       TINYINT = 0,
    @CurUser        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF XACT_STATE() = -1
        THROW 50119, N'المعاملة الحالية غير قابلة للاستمرار، لا يمكن متابعة الحفظ.', 1;

    SET @CurCode   = UPPER(NULLIF(LTRIM(RTRIM(@CurCode)), N''));
    SET @CurName   = NULLIF(LTRIM(RTRIM(@CurName)), N'');
    SET @CurSymbol = NULLIF(LTRIM(RTRIM(@CurSymbol)), N'');

    IF @CurID IS NOT NULL AND @CurID < 0
        THROW 50101, N'معرف العملة غير صالح.', 1;
    IF @CurCmp IS NULL OR @CurCmp <= 0
        THROW 50102, N'معرف الشركة غير صالح.', 1;
    IF @CurCode IS NULL OR LEN(@CurCode) <> 3 OR @CurCode LIKE N'%[^A-Z]%' COLLATE Latin1_General_BIN
        THROW 50103, N'رمز العملة يجب أن يكون ثلاثة أحرف إنجليزية (مثل USD).', 1;
    IF @CurName IS NULL
        THROW 50104, N'اسم العملة إلزامي.', 1;
    IF @CurDecimals IS NULL OR @CurDecimals > 6
        THROW 50105, N'عدد الخانات العشرية يجب أن يكون بين 0 و6.', 1;
    IF @CurState IS NULL OR @CurState NOT IN (0, 1)
        THROW 50106, N'حالة العملة غير صالحة.', 1;
    IF @CurIsBase IS NULL
        SET @CurIsBase = 0;
    IF @CurUser IS NULL OR @CurUser <= 0
        THROW 50107, N'معرف المستخدم غير صالح.', 1;
    IF @CurIsBase = 1 AND @CurState = 1
        THROW 50108, N'لا يمكن تعطيل العملة الأساسية.', 1;

    DECLARE @TranStarted INT = 0;
    DECLARE @OldCode NVARCHAR(3), @OldBase BIT;

    BEGIN TRY
        IF @@TRANCOUNT = 0
        BEGIN
            BEGIN TRANSACTION;
            SET @TranStarted = 1;
        END
        ELSE
            SAVE TRANSACTION SavePoint_SaveCurrency;

        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WITH (UPDLOCK, HOLDLOCK) WHERE CmpID = @CurCmp)
            THROW 50109, N'الشركة غير مسجلة.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @CurUser)
            THROW 50110, N'مستخدم النظام غير مسجل.', 1;

        -- رمز العملة غير مكرر داخل الشركة
        IF EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                   WHERE CurCmp = @CurCmp AND CurCode = @CurCode
                     AND (@CurID IS NULL OR @CurID = 0 OR CurID <> @CurID))
            THROW 50111, N'رمز العملة مستخدم لعملة أخرى في هذه الشركة.', 1;

        IF @CurID IS NOT NULL AND @CurID > 0
        BEGIN
            -- تعديل
            SELECT @OldCode = CurCode, @OldBase = CurIsBase
            FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
            WHERE CurID = @CurID AND CurCmp = @CurCmp;

            IF @@ROWCOUNT = 0
                THROW 50112, N'العملة غير موجودة في نطاق هذه الشركة.', 1;

            IF @OldBase <> @CurIsBase
                THROW 50113, N'لا يمكن تغيير وضع العملة الأساسية بعد إنشائها.', 1;

            IF @OldCode <> @CurCode
               AND (EXISTS (SELECT 1 FROM dbo.Emp_Salary WHERE EmpCompany = @CurCmp AND SalCurrencyID = @CurID)
                 OR EXISTS (SELECT 1 FROM dbo.Acc_ExchangeRate WHERE RateCmp = @CurCmp AND RateCurID = @CurID))
                THROW 50114, N'لا يمكن تغيير رمز عملة مستخدمة في عقود أو أسعار صرف.', 1;

            -- لا تعطيل لعملة مستخدمة في عقد ساري
            IF @CurState = 1
               AND EXISTS (SELECT 1 FROM dbo.Emp_Salary
                           WHERE EmpCompany = @CurCmp AND SalCurrencyID = @CurID AND SalEndDate IS NULL)
                THROW 50115, N'لا يمكن تعطيل عملة مستخدمة في عقد ساري.', 1;

            UPDATE dbo.Acc_Currency
            SET CurCode = @CurCode, CurName = @CurName, CurSymbol = @CurSymbol,
                CurDecimals = @CurDecimals, CurState = @CurState,
                CurDate = SYSDATETIME(), CurUser = @CurUser
            WHERE CurID = @CurID AND CurCmp = @CurCmp;
        END
        ELSE
        BEGIN
            -- إدراج: العملة الأساسية أولاً
            IF @CurIsBase = 1 AND EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                                          WHERE CurCmp = @CurCmp AND CurIsBase = 1)
                THROW 50116, N'للشركة عملة أساسية بالفعل.', 1;

            IF @CurIsBase = 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Currency WITH (UPDLOCK, HOLDLOCK)
                                              WHERE CurCmp = @CurCmp AND CurIsBase = 1)
                THROW 50117, N'أنشئ العملة الأساسية للشركة أولاً.', 1;

            INSERT dbo.Acc_Currency
                (CurCmp, CurCode, CurName, CurSymbol, CurDecimals, CurIsBase, CurState, CurDate, CurUser)
            VALUES
                (@CurCmp, @CurCode, @CurName, @CurSymbol, @CurDecimals, @CurIsBase, @CurState, SYSDATETIME(), @CurUser);

            SET @CurID = SCOPE_IDENTITY();
        END

        IF @TranStarted = 1
        BEGIN
            COMMIT TRANSACTION;
            SET @TranStarted = 0;
        END
    END TRY
    BEGIN CATCH
        IF @TranStarted = 1
        BEGIN
            IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION SavePoint_SaveCurrency;

        THROW;
    END CATCH
END
GO

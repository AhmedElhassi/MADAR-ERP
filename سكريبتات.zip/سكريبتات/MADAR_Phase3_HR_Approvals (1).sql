/* =====================================================================
   MADAR Enterprise ERP - HR & Payroll - Phase 3
   Approval engine v2, notifications, MSS inbox, ESS tracking, reports.

   Run AFTER MADARDATABASE_FIXED_v2.sql, on MADARERPDataBase.
   Idempotent: guarded DDL + CREATE OR ALTER. Safe to run twice.
   Existing signatures are kept; new parameters are optional and last.
   ===================================================================== */
USE [MADARERPDataBase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   PART 1 - SCHEMA
   (every ADD COLUMN is in its own batch: a column cannot be added and used
    in the same batch)
   ===================================================================== */

-- 1.1 route steps: approver can be a fixed user or resolved from the org chart
IF COL_LENGTH(N'dbo.Emp_ApprovalRouteSteps',N'ApproverMode') IS NULL
 ALTER TABLE dbo.Emp_ApprovalRouteSteps ADD ApproverMode TINYINT NOT NULL CONSTRAINT DF_Emp_ApprovalRouteSteps_Mode DEFAULT(0) WITH VALUES;
GO
IF EXISTS(SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.Emp_ApprovalRouteSteps') AND name=N'ApproverID' AND is_nullable=0)
 ALTER TABLE dbo.Emp_ApprovalRouteSteps ALTER COLUMN ApproverID BIGINT NULL;
GO
IF NOT EXISTS(SELECT 1 FROM sys.check_constraints WHERE name=N'CK_Emp_ApprovalRouteSteps_Mode' AND parent_object_id=OBJECT_ID(N'dbo.Emp_ApprovalRouteSteps'))
 ALTER TABLE dbo.Emp_ApprovalRouteSteps WITH CHECK ADD CONSTRAINT CK_Emp_ApprovalRouteSteps_Mode
  CHECK((ApproverMode=0 AND ApproverID IS NOT NULL) OR (ApproverMode IN(1,2) AND ApproverID IS NULL));
GO

-- 1.2 requests: subject employee (whose manager approves) + "returned" state
IF COL_LENGTH(N'dbo.Emp_ApprovalRequests',N'SubjectEmployeeID') IS NULL
 ALTER TABLE dbo.Emp_ApprovalRequests ADD SubjectEmployeeID BIGINT NULL;
GO
IF EXISTS(SELECT 1 FROM sys.check_constraints WHERE name=N'CK_Emp_ApprovalRequests_Values' AND parent_object_id=OBJECT_ID(N'dbo.Emp_ApprovalRequests') AND definition NOT LIKE N'%3%')
 ALTER TABLE dbo.Emp_ApprovalRequests DROP CONSTRAINT CK_Emp_ApprovalRequests_Values;
GO
IF NOT EXISTS(SELECT 1 FROM sys.check_constraints WHERE name=N'CK_Emp_ApprovalRequests_Values' AND parent_object_id=OBJECT_ID(N'dbo.Emp_ApprovalRequests'))
 ALTER TABLE dbo.Emp_ApprovalRequests WITH CHECK ADD CONSTRAINT CK_Emp_ApprovalRequests_Values
  CHECK(ProcessType>0 AND EntityID>0 AND CurrentStep>0 AND ApprovalState IN(0,1,2,3));
GO

-- 1.3 events: acting-on-behalf + decision 3 (return for edit)
IF COL_LENGTH(N'dbo.Emp_ApprovalEvents',N'OnBehalfOf') IS NULL
 ALTER TABLE dbo.Emp_ApprovalEvents ADD OnBehalfOf BIGINT NULL;
GO
IF NOT EXISTS(SELECT 1 FROM sys.foreign_keys WHERE name=N'FK_Emp_ApprovalEvents_OnBehalfOf')
 ALTER TABLE dbo.Emp_ApprovalEvents WITH CHECK ADD CONSTRAINT FK_Emp_ApprovalEvents_OnBehalfOf FOREIGN KEY(OnBehalfOf) REFERENCES dbo.Mng_User(UsrID);
GO
IF EXISTS(SELECT 1 FROM sys.check_constraints WHERE name=N'CK_Emp_ApprovalEvents_Decision' AND parent_object_id=OBJECT_ID(N'dbo.Emp_ApprovalEvents') AND definition NOT LIKE N'%3%')
 ALTER TABLE dbo.Emp_ApprovalEvents DROP CONSTRAINT CK_Emp_ApprovalEvents_Decision;
GO
IF NOT EXISTS(SELECT 1 FROM sys.check_constraints WHERE name=N'CK_Emp_ApprovalEvents_Decision' AND parent_object_id=OBJECT_ID(N'dbo.Emp_ApprovalEvents'))
 ALTER TABLE dbo.Emp_ApprovalEvents WITH CHECK ADD CONSTRAINT CK_Emp_ApprovalEvents_Decision CHECK(Decision IN(1,2,3));
GO

-- 1.4 delegation
IF OBJECT_ID(N'dbo.Emp_ApprovalDelegations',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_ApprovalDelegations
 (
  DelegationID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_ApprovalDelegations PRIMARY KEY,
  CmpID INT NOT NULL,DelegatorID BIGINT NOT NULL,DelegateID BIGINT NOT NULL,ProcessType TINYINT NULL,
  DateFrom DATE NOT NULL,DateTo DATE NOT NULL,Reason NVARCHAR(500) NULL,
  RecordState TINYINT NOT NULL CONSTRAINT DF_Emp_ApprovalDelegations_State DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_ApprovalDelegations_Created DEFAULT(SYSDATETIME()),CreatedBy BIGINT NOT NULL,
  RevokedAt DATETIME2(0) NULL,RevokedBy BIGINT NULL,
  CONSTRAINT CK_Emp_ApprovalDelegations_Values CHECK(DateTo>=DateFrom AND DelegatorID<>DelegateID AND RecordState IN(0,1) AND (ProcessType IS NULL OR ProcessType>0)),
  CONSTRAINT FK_Emp_ApprovalDelegations_Company FOREIGN KEY(CmpID) REFERENCES dbo.Mng_Company(CmpID),
  CONSTRAINT FK_Emp_ApprovalDelegations_Delegator FOREIGN KEY(DelegatorID) REFERENCES dbo.Mng_User(UsrID),
  CONSTRAINT FK_Emp_ApprovalDelegations_Delegate FOREIGN KEY(DelegateID) REFERENCES dbo.Mng_User(UsrID),
  CONSTRAINT FK_Emp_ApprovalDelegations_Creator FOREIGN KEY(CreatedBy) REFERENCES dbo.Mng_User(UsrID),
  CONSTRAINT FK_Emp_ApprovalDelegations_Revoker FOREIGN KEY(RevokedBy) REFERENCES dbo.Mng_User(UsrID)
 );
 CREATE INDEX IX_Emp_ApprovalDelegations_Lookup ON dbo.Emp_ApprovalDelegations(CmpID,DelegatorID,RecordState,DateFrom,DateTo);
 CREATE INDEX IX_Emp_ApprovalDelegations_Delegate ON dbo.Emp_ApprovalDelegations(CmpID,DelegateID,RecordState);
END;
GO

-- 1.5 re-routing of a running request (per attempt + step)
IF OBJECT_ID(N'dbo.Emp_ApprovalReassignments',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_ApprovalReassignments
 (
  ReassignID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_ApprovalReassignments PRIMARY KEY,
  CmpID INT NOT NULL,ApprovalID BIGINT NOT NULL,AttemptNo SMALLINT NOT NULL,StepNo SMALLINT NOT NULL,
  FromApproverID BIGINT NOT NULL,ToApproverID BIGINT NOT NULL,Reason NVARCHAR(500) NOT NULL,
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_ApprovalReassignments_Created DEFAULT(SYSDATETIME()),CreatedBy BIGINT NOT NULL,
  CONSTRAINT CK_Emp_ApprovalReassignments_Values CHECK(FromApproverID<>ToApproverID AND StepNo>0 AND AttemptNo>0),
  CONSTRAINT FK_Emp_ApprovalReassignments_Request FOREIGN KEY(CmpID,ApprovalID) REFERENCES dbo.Emp_ApprovalRequests(CmpID,ApprovalID),
  CONSTRAINT FK_Emp_ApprovalReassignments_From FOREIGN KEY(FromApproverID) REFERENCES dbo.Mng_User(UsrID),
  CONSTRAINT FK_Emp_ApprovalReassignments_To FOREIGN KEY(ToApproverID) REFERENCES dbo.Mng_User(UsrID),
  CONSTRAINT FK_Emp_ApprovalReassignments_Creator FOREIGN KEY(CreatedBy) REFERENCES dbo.Mng_User(UsrID)
 );
 CREATE INDEX IX_Emp_ApprovalReassignments_Step ON dbo.Emp_ApprovalReassignments(CmpID,ApprovalID,AttemptNo,StepNo,ReassignID);
END;
GO

-- 1.6 per-user notifications
IF OBJECT_ID(N'dbo.Emp_Notifications',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Emp_Notifications
 (
  NotifID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Emp_Notifications PRIMARY KEY,
  CmpID INT NOT NULL,UserID BIGINT NOT NULL,
  NotifType TINYINT NOT NULL,           -- 1 submitted, 2 action required, 3 approved, 4 rejected, 5 returned, 6 advanced, 7 reassigned, 8 delegated
  ProcessType TINYINT NULL,EntityID BIGINT NULL,ApprovalID BIGINT NULL,
  Title NVARCHAR(200) NOT NULL,Body NVARCHAR(1000) NULL,
  IsRead BIT NOT NULL CONSTRAINT DF_Emp_Notifications_Read DEFAULT(0),
  CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Emp_Notifications_Created DEFAULT(SYSDATETIME()),ReadAt DATETIME2(0) NULL,
  CONSTRAINT CK_Emp_Notifications_Type CHECK(NotifType BETWEEN 1 AND 8),
  CONSTRAINT FK_Emp_Notifications_Company FOREIGN KEY(CmpID) REFERENCES dbo.Mng_Company(CmpID),
  CONSTRAINT FK_Emp_Notifications_User FOREIGN KEY(UserID) REFERENCES dbo.Mng_User(UsrID)
 );
 CREATE INDEX IX_Emp_Notifications_Inbox ON dbo.Emp_Notifications(CmpID,UserID,IsRead,NotifID DESC);
END;
GO

-- 1.7 protect the audit trail: approval events and re-assignments are append-only
CREATE OR ALTER TRIGGER dbo.TR_Emp_ApprovalEvents_AppendOnly ON dbo.Emp_ApprovalEvents INSTEAD OF UPDATE,DELETE
AS
BEGIN
 SET NOCOUNT ON;
 THROW 54720,N'سجل أحداث الموافقة للإضافة فقط ولا يجوز تعديله أو حذفه.',1;
END;
GO
CREATE OR ALTER TRIGGER dbo.TR_Emp_ApprovalReassignments_AppendOnly ON dbo.Emp_ApprovalReassignments INSTEAD OF UPDATE,DELETE
AS
BEGIN
 SET NOCOUNT ON;
 THROW 54721,N'سجل إعادة توجيه الموافقات للإضافة فقط ولا يجوز تعديله أو حذفه.',1;
END;
GO

/* =====================================================================
   PART 2 - FUNCTIONS
   ===================================================================== */
CREATE OR ALTER FUNCTION dbo.fn_Emp_ProcessTypeName(@ProcessType TINYINT)
RETURNS NVARCHAR(100) AS
BEGIN
 RETURN CASE @ProcessType
  WHEN 1 THEN N'طلب إجازة' WHEN 2 THEN N'طلب عمل إضافي' WHEN 3 THEN N'مكافأة أو جزاء' WHEN 4 THEN N'قرض'
  WHEN 5 THEN N'إنهاء خدمة' WHEN 6 THEN N'تسوية نهائية' WHEN 7 THEN N'عرض وظيفي' WHEN 8 THEN N'طلب احتياج وظيفي'
  WHEN 9 THEN N'مسير رواتب' WHEN 10 THEN N'تسوية حضور' WHEN 11 THEN N'سلفة راتب' WHEN 12 THEN N'استقطاع خارجي'
  WHEN 13 THEN N'تبديل وردية' ELSE N'طلب' END;
END;
GO
CREATE OR ALTER FUNCTION dbo.fn_Emp_ApprovalStateName(@State TINYINT)
RETURNS NVARCHAR(50) AS
BEGIN
 RETURN CASE @State WHEN 0 THEN N'قيد الاعتماد' WHEN 1 THEN N'معتمد' WHEN 2 THEN N'مرفوض' WHEN 3 THEN N'معاد للتعديل' ELSE N'غير معروف' END;
END;
GO
CREATE OR ALTER FUNCTION dbo.fn_Emp_IsDelegate(@CmpID INT,@Delegator BIGINT,@Delegate BIGINT,@ProcessType TINYINT,@AsOf DATE)
RETURNS BIT AS
BEGIN
 RETURN CASE WHEN EXISTS(SELECT 1 FROM dbo.Emp_ApprovalDelegations d
  WHERE d.CmpID=@CmpID AND d.DelegatorID=@Delegator AND d.DelegateID=@Delegate AND d.RecordState=0
    AND @AsOf BETWEEN d.DateFrom AND d.DateTo AND (d.ProcessType IS NULL OR d.ProcessType=@ProcessType)) THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END;
END;
GO
-- mode 0 = fixed user, 1 = direct manager of the subject, 2 = manager of the direct manager
CREATE OR ALTER FUNCTION dbo.fn_Emp_ResolveApprover(@CmpID INT,@ProcessType TINYINT,@StepNo SMALLINT,@SubjectEmployeeID BIGINT,@AsOf DATE)
RETURNS BIGINT AS
BEGIN
 DECLARE @Mode TINYINT,@Fixed BIGINT,@M BIGINT;
 SELECT @Mode=ApproverMode,@Fixed=ApproverID FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo AND RecordState=0;
 IF @Mode IS NULL RETURN NULL;
 IF @Mode=0 RETURN @Fixed;
 SET @M=dbo.fn_Emp_GetDirectManager(@CmpID,@SubjectEmployeeID,@AsOf);
 IF @Mode=2 AND @M IS NOT NULL SET @M=dbo.fn_Emp_GetDirectManager(@CmpID,@M,@AsOf);
 RETURN @M;
END;
GO
-- who must decide the request right now (re-assignment wins over the route)
CREATE OR ALTER FUNCTION dbo.fn_Emp_CurrentApprover(@CmpID INT,@ApprovalID BIGINT)
RETURNS BIGINT AS
BEGIN
 DECLARE @Proc TINYINT,@Step SMALLINT,@Att SMALLINT,@Subj BIGINT,@State TINYINT,@R BIGINT;
 SELECT @Proc=ProcessType,@Step=CurrentStep,@Att=AttemptNo,@Subj=ISNULL(SubjectEmployeeID,SubmittedBy),@State=ApprovalState
 FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
 IF @State IS NULL OR @State<>0 RETURN NULL;
 SELECT TOP(1) @R=ToApproverID FROM dbo.Emp_ApprovalReassignments WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID AND AttemptNo=@Att AND StepNo=@Step ORDER BY ReassignID DESC;
 IF @R IS NOT NULL RETURN @R;
 RETURN dbo.fn_Emp_ResolveApprover(@CmpID,@Proc,@Step,@Subj,CONVERT(date,SYSDATETIME()));
END;
GO

/* =====================================================================
   PART 3 - NOTIFICATION HELPERS (internal)
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Emp_NotifyUser
 @CmpID INT,@UserID BIGINT,@NotifType TINYINT,@ProcessType TINYINT=NULL,@EntityID BIGINT=NULL,@ApprovalID BIGINT=NULL,@Title NVARCHAR(200),@Body NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON;
 IF @UserID IS NULL RETURN;
 INSERT dbo.Emp_Notifications(CmpID,UserID,NotifType,ProcessType,EntityID,ApprovalID,Title,Body) VALUES(@CmpID,@UserID,@NotifType,@ProcessType,@EntityID,@ApprovalID,@Title,@Body);
END;
GO
-- tells the current approver (and active delegates) that a request is waiting
CREATE OR ALTER PROCEDURE dbo.Emp_NotifyStepApprover @CmpID INT,@ApprovalID BIGINT
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Proc TINYINT,@Entity BIGINT,@Cur BIGINT,@Submitter BIGINT,@Subject BIGINT,@Today DATE=CONVERT(date,SYSDATETIME()),@Title NVARCHAR(200),@Body NVARCHAR(1000);
 SELECT @Proc=ProcessType,@Entity=EntityID,@Submitter=SubmittedBy,@Subject=ISNULL(SubjectEmployeeID,SubmittedBy)
 FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID AND ApprovalState=0;
 IF @Proc IS NULL RETURN;
 SET @Cur=dbo.fn_Emp_CurrentApprover(@CmpID,@ApprovalID);
 IF @Cur IS NULL RETURN;
 SET @Title=CONCAT(N'طلب بانتظار اعتمادك: ',dbo.fn_Emp_ProcessTypeName(@Proc));
 SET @Body=CONCAT(N'رقم السجل: ',@Entity);
 INSERT dbo.Emp_Notifications(CmpID,UserID,NotifType,ProcessType,EntityID,ApprovalID,Title,Body)
 SELECT @CmpID,u.UserID,2,@Proc,@Entity,@ApprovalID,@Title,@Body
 FROM (SELECT @Cur AS UserID
       UNION
       SELECT d.DelegateID FROM dbo.Emp_ApprovalDelegations d
       WHERE d.CmpID=@CmpID AND d.DelegatorID=@Cur AND d.RecordState=0 AND @Today BETWEEN d.DateFrom AND d.DateTo AND (d.ProcessType IS NULL OR d.ProcessType=@Proc)) u
 WHERE u.UserID NOT IN(@Submitter,@Subject);
END;
GO

/* =====================================================================
   PART 4 - APPROVAL ENGINE v2
   Same signatures as before + optional trailing parameters.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Emp_SaveApprovalRouteStep
 @CmpID INT,@ProcessType TINYINT,@StepNo SMALLINT,@ApproverID BIGINT,@RecordState TINYINT=0,@UserID BIGINT,@ApproverMode TINYINT=0
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @ProcessType IS NULL OR @ProcessType=0 OR @StepNo IS NULL OR @StepNo<=0 OR @RecordState NOT IN(0,1) THROW 54700,N'نوع العملية أو مرحلة الموافقة غير صحيحة.',1;
 IF @ApproverMode IS NULL OR @ApproverMode NOT IN(0,1,2) THROW 54716,N'نمط تحديد المعتمد غير صحيح.',1;
 IF @ApproverMode=0 AND NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@ApproverID AND UsrCompany=@CmpID AND UsrState=0) THROW 54701,N'المعتمد غير نشط أو لا يتبع للشركة.',1;
 IF @ApproverMode IN(1,2) SET @ApproverID=NULL;
 BEGIN TRY
  BEGIN TRANSACTION;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND ApprovalState=0 AND CurrentStep>=@StepNo) THROW 54702,N'لا يمكن تغيير مرحلة مستخدمة في مسار موافقة جارٍ.',1;
  DECLARE @MaxActiveStep SMALLINT=(SELECT MAX(StepNo) FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0),@CurrentRouteState TINYINT;
  SELECT @CurrentRouteState=RecordState FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo;
  IF ISNULL(@CurrentRouteState,1)=1 AND @RecordState=0 AND @StepNo>ISNULL(@MaxActiveStep,0)+1 THROW 54711,N'أضف مراحل الموافقة بالتتابع دون فجوات.',1;
  IF @RecordState=1 AND EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0 AND StepNo>@StepNo) THROW 54712,N'عطّل المراحل من الأخيرة إلى الأولى للحفاظ على تسلسل المسار.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo)
   UPDATE dbo.Emp_ApprovalRouteSteps SET ApproverID=@ApproverID,ApproverMode=@ApproverMode,RecordState=@RecordState WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo;
  ELSE INSERT dbo.Emp_ApprovalRouteSteps(CmpID,ProcessType,StepNo,ApproverID,ApproverMode,RecordState,CreatedBy) VALUES(@CmpID,@ProcessType,@StepNo,@ApproverID,@ApproverMode,@RecordState,@UserID);
  COMMIT TRANSACTION;
  SELECT @ProcessType AS ProcessType,@StepNo AS StepNo;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SelectApprovalRoute @CmpID INT,@ProcessType TINYINT
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.ProcessType,r.StepNo,r.ApproverID,u.UsrLogIn,
        CASE r.ApproverMode WHEN 1 THEN N'المدير المباشر' WHEN 2 THEN N'مدير المدير المباشر' ELSE CONCAT(e.EmpName,N'') END AS ApproverName,
        r.RecordState,r.CreatedAt,r.CreatedBy,r.ApproverMode
 FROM dbo.Emp_ApprovalRouteSteps r LEFT JOIN dbo.Mng_User u ON u.UsrID=r.ApproverID LEFT JOIN dbo.Emp_Employee e ON e.EmpCompany=r.CmpID AND e.EmpID=r.ApproverID
 WHERE r.CmpID=@CmpID AND r.ProcessType=@ProcessType ORDER BY r.StepNo;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_StartApproval
 @CmpID INT,@ProcessType TINYINT,@EntityID BIGINT,@SubmittedBy BIGINT,@SuppressResult BIT=0,@SubjectEmployeeID BIGINT=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@SubmittedBy;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @FirstStep SMALLINT,@StepCount INT,@MaxStep SMALLINT,@ApprovalID BIGINT,@ExistingState TINYINT,@ExistingSubmitter BIGINT,
          @Subject BIGINT=ISNULL(@SubjectEmployeeID,@SubmittedBy),@Notify BIT=0,@FirstApprover BIGINT,@Title NVARCHAR(200),@Body NVARCHAR(1000);
  SELECT @FirstStep=MIN(StepNo),@MaxStep=MAX(StepNo),@StepCount=COUNT(*) FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0;
  IF @FirstStep IS NULL THROW 54703,N'مسار الموافقات غير مهيأ لهذه الشركة والعملية.',1;
  IF @FirstStep<>1 OR @StepCount<>@MaxStep THROW 54704,N'أرقام مراحل مسار الموافقة يجب أن تكون متصلة ابتداءً من المرحلة الأولى.',1;
  SELECT @ApprovalID=ApprovalID,@ExistingState=ApprovalState,@ExistingSubmitter=SubmittedBy FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID;
  IF @ApprovalID IS NULL
  BEGIN
   INSERT dbo.Emp_ApprovalRequests(CmpID,ProcessType,EntityID,CurrentStep,ApprovalState,SubmittedBy,SubjectEmployeeID) VALUES(@CmpID,@ProcessType,@EntityID,1,0,@SubmittedBy,@Subject);
   SET @ApprovalID=SCOPE_IDENTITY(); SET @Notify=1;
  END
  ELSE IF @ExistingState=2 OR (@ExistingState=3 AND @ExistingSubmitter=@SubmittedBy)
  BEGIN
   UPDATE dbo.Emp_ApprovalRequests SET CurrentStep=1,ApprovalState=0,AttemptNo=AttemptNo+1,SubmittedBy=@SubmittedBy,SubjectEmployeeID=@Subject,CreatedAt=SYSDATETIME(),CompletedAt=NULL,CompletedBy=NULL WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
   SET @Notify=1;
  END
  ELSE IF @ExistingState<>0 OR @ExistingSubmitter<>@SubmittedBy THROW 54705,N'طلب الموافقة قائم أو مكتمل مسبقاً أو لا يخص مقدم الطلب.',1;
  IF @Notify=1
  BEGIN
   SET @FirstApprover=dbo.fn_Emp_CurrentApprover(@CmpID,@ApprovalID);
   IF @FirstApprover IS NULL THROW 54713,N'تعذر تحديد المعتمد للمرحلة الأولى (لا يوجد مدير مباشر محدد للموظف).',1;
   SET @Title=CONCAT(N'تم تقديم طلبك: ',dbo.fn_Emp_ProcessTypeName(@ProcessType));
   SET @Body=CONCAT(N'رقم السجل: ',@EntityID);
   EXEC dbo.Emp_NotifyUser @CmpID,@SubmittedBy,1,@ProcessType,@EntityID,@ApprovalID,@Title,@Body;
   EXEC dbo.Emp_NotifyStepApprover @CmpID,@ApprovalID;
  END;
  COMMIT TRANSACTION;
  IF @SuppressResult=0 SELECT ApprovalID,CurrentStep,ApprovalState FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_DecideApprovalStep
 @CmpID INT,@ProcessType TINYINT,@EntityID BIGINT,@StepNo SMALLINT,@ApproverID BIGINT,@Decision TINYINT,@Comments NVARCHAR(1000)=NULL,
 @ApprovalState TINYINT OUTPUT,@NextStep SMALLINT OUTPUT,@SuppressResult BIT=0
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@ApproverID;
 IF @Decision NOT IN(1,2,3) OR @StepNo<=0 THROW 54706,N'قرار الموافقة أو المرحلة غير صحيح.',1;
 IF @Decision=3 AND NULLIF(LTRIM(RTRIM(ISNULL(@Comments,N''))),N'') IS NULL THROW 54714,N'يجب كتابة سبب الإرجاع للتعديل.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @ApprovalID BIGINT,@CurrentStep SMALLINT,@State TINYINT,@SubmittedBy BIGINT,@Subject BIGINT,@ExpectedApprover BIGINT,@Next SMALLINT,@AttemptNo SMALLINT,
          @OnBehalf BIGINT=NULL,@Today DATE=CONVERT(date,SYSDATETIME()),@PName NVARCHAR(100),@Title NVARCHAR(200),@Body NVARCHAR(1000),@NType TINYINT;
  SELECT @ApprovalID=ApprovalID,@CurrentStep=CurrentStep,@State=ApprovalState,@AttemptNo=AttemptNo,@SubmittedBy=SubmittedBy,@Subject=ISNULL(SubjectEmployeeID,SubmittedBy)
  FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID;
  IF @ApprovalID IS NULL OR @State<>0 OR @CurrentStep<>@StepNo THROW 54707,N'طلب الموافقة غير قائم أو المرحلة الحالية مختلفة.',1;
  IF @SubmittedBy=@ApproverID OR @Subject=@ApproverID THROW 54708,N'لا يجوز لمقدم الطلب اعتماد طلبه.',1;
  SET @ExpectedApprover=dbo.fn_Emp_CurrentApprover(@CmpID,@ApprovalID);
  IF @ExpectedApprover IS NULL THROW 54715,N'تعذر تحديد معتمد المرحلة الحالية.',1;
  IF @ExpectedApprover<>@ApproverID
  BEGIN
   IF dbo.fn_Emp_IsDelegate(@CmpID,@ExpectedApprover,@ApproverID,@ProcessType,@Today)=1 SET @OnBehalf=@ExpectedApprover;
   ELSE THROW 54709,N'المستخدم ليس المعتمد المحدد لهذه المرحلة.',1;
  END;
  INSERT dbo.Emp_ApprovalEvents(CmpID,ApprovalID,ProcessType,EntityID,StepNo,AttemptNo,ApproverID,Decision,Comments,OnBehalfOf) VALUES(@CmpID,@ApprovalID,@ProcessType,@EntityID,@StepNo,@AttemptNo,@ApproverID,@Decision,@Comments,@OnBehalf);
  IF @Decision=2
   UPDATE dbo.Emp_ApprovalRequests SET ApprovalState=2,CompletedAt=SYSDATETIME(),CompletedBy=@ApproverID WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  ELSE IF @Decision=3
   UPDATE dbo.Emp_ApprovalRequests SET ApprovalState=3,CompletedAt=SYSDATETIME(),CompletedBy=@ApproverID WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  ELSE
  BEGIN
   SELECT @Next=MIN(StepNo) FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0 AND StepNo>@StepNo;
   IF @Next IS NULL UPDATE dbo.Emp_ApprovalRequests SET ApprovalState=1,CompletedAt=SYSDATETIME(),CompletedBy=@ApproverID WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
   ELSE UPDATE dbo.Emp_ApprovalRequests SET CurrentStep=@Next WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  END;
  SELECT @ApprovalState=ApprovalState,@NextStep=CurrentStep FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  -- notifications
  SET @PName=dbo.fn_Emp_ProcessTypeName(@ProcessType);
  SET @Body=CONCAT(N'رقم السجل: ',@EntityID);
  IF @ApprovalState=0
  BEGIN
   SET @NType=6; SET @Title=CONCAT(N'انتقل طلبك إلى المرحلة ',@NextStep,N': ',@PName);
   EXEC dbo.Emp_NotifyStepApprover @CmpID,@ApprovalID;
  END
  ELSE
  BEGIN
   SET @NType=CASE @ApprovalState WHEN 1 THEN 3 WHEN 2 THEN 4 ELSE 5 END;
   SET @Title=CONCAT(CASE @ApprovalState WHEN 1 THEN N'تم اعتماد طلبك: ' WHEN 2 THEN N'تم رفض طلبك: ' ELSE N'أُعيد طلبك للتعديل: ' END,@PName);
   IF @Comments IS NOT NULL SET @Body=CONCAT(@Body,N' - ',@Comments);
  END;
  EXEC dbo.Emp_NotifyUser @CmpID,@SubmittedBy,@NType,@ProcessType,@EntityID,@ApprovalID,@Title,@Body;
  IF @Subject<>@SubmittedBy EXEC dbo.Emp_NotifyUser @CmpID,@Subject,@NType,@ProcessType,@EntityID,@ApprovalID,@Title,@Body;
  COMMIT TRANSACTION;
  IF @SuppressResult=0 SELECT @ApprovalID AS ApprovalID,@ApprovalState AS ApprovalState,@NextStep AS NextStep;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO
-- return for edit: the submitter changes the record and re-submits (a new attempt starts)
CREATE OR ALTER PROCEDURE dbo.Emp_ReturnApprovalForEdit
 @CmpID INT,@ProcessType TINYINT,@EntityID BIGINT,@ApproverID BIGINT,@Comments NVARCHAR(1000)
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @Step SMALLINT,@St TINYINT,@Nx SMALLINT;
 SELECT @Step=CurrentStep FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID AND ApprovalState=0;
 IF @Step IS NULL THROW 54707,N'طلب الموافقة غير قائم أو المرحلة الحالية مختلفة.',1;
 EXEC dbo.Emp_DecideApprovalStep @CmpID,@ProcessType,@EntityID,@Step,@ApproverID,3,@Comments,@St OUTPUT,@Nx OUTPUT,0;
END;
GO
-- the current approver (or an active delegate) hands the step to someone else
CREATE OR ALTER PROCEDURE dbo.Emp_ReassignApprovalStep
 @CmpID INT,@ProcessType TINYINT,@EntityID BIGINT,@UserID BIGINT,@NewApproverID BIGINT,@Reason NVARCHAR(500)
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF NULLIF(LTRIM(RTRIM(ISNULL(@Reason,N''))),N'') IS NULL THROW 54717,N'سبب إعادة التوجيه مطلوب.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@NewApproverID AND UsrCompany=@CmpID AND UsrState=0) THROW 54701,N'المعتمد غير نشط أو لا يتبع للشركة.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @ApprovalID BIGINT,@Step SMALLINT,@Att SMALLINT,@Sub BIGINT,@Subj BIGINT,@Cur BIGINT,@Title NVARCHAR(200),@Body NVARCHAR(1000);
  SELECT @ApprovalID=ApprovalID,@Step=CurrentStep,@Att=AttemptNo,@Sub=SubmittedBy,@Subj=ISNULL(SubjectEmployeeID,SubmittedBy)
  FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID AND ApprovalState=0;
  IF @ApprovalID IS NULL THROW 54707,N'طلب الموافقة غير قائم أو المرحلة الحالية مختلفة.',1;
  SET @Cur=dbo.fn_Emp_CurrentApprover(@CmpID,@ApprovalID);
  IF @Cur IS NULL THROW 54715,N'تعذر تحديد معتمد المرحلة الحالية.',1;
  IF @Cur<>@UserID AND dbo.fn_Emp_IsDelegate(@CmpID,@Cur,@UserID,@ProcessType,CONVERT(date,SYSDATETIME()))=0 THROW 54709,N'المستخدم ليس المعتمد المحدد لهذه المرحلة.',1;
  IF @NewApproverID=@Cur THROW 54718,N'المعتمد الجديد هو المعتمد الحالي نفسه.',1;
  IF @NewApproverID IN(@Sub,@Subj) THROW 54719,N'لا يجوز إسناد الطلب إلى مقدمه أو إلى صاحبه.',1;
  INSERT dbo.Emp_ApprovalReassignments(CmpID,ApprovalID,AttemptNo,StepNo,FromApproverID,ToApproverID,Reason,CreatedBy) VALUES(@CmpID,@ApprovalID,@Att,@Step,@Cur,@NewApproverID,@Reason,@UserID);
  SET @Title=CONCAT(N'أُعيد توجيه طلبك: ',dbo.fn_Emp_ProcessTypeName(@ProcessType));
  SET @Body=CONCAT(N'رقم السجل: ',@EntityID);
  EXEC dbo.Emp_NotifyUser @CmpID,@Sub,7,@ProcessType,@EntityID,@ApprovalID,@Title,@Body;
  EXEC dbo.Emp_NotifyStepApprover @CmpID,@ApprovalID;
  COMMIT TRANSACTION;
  SELECT @ApprovalID AS ApprovalID,@Step AS StepNo,@NewApproverID AS ToApproverID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* ---------- delegation ---------- */
CREATE OR ALTER PROCEDURE dbo.Emp_SaveApprovalDelegation
 @CmpID INT,@UserID BIGINT,@DelegateID BIGINT,@ProcessType TINYINT=NULL,@DateFrom DATE,@DateTo DATE,@Reason NVARCHAR(500)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @DelegateID=@UserID THROW 54722,N'لا يجوز تفويض النفس.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@DelegateID AND UsrCompany=@CmpID AND UsrState=0) THROW 54701,N'المعتمد غير نشط أو لا يتبع للشركة.',1;
 IF @DateFrom IS NULL OR @DateTo IS NULL OR @DateTo<@DateFrom OR @DateTo<CONVERT(date,SYSDATETIME()) THROW 54723,N'فترة التفويض غير صحيحة.',1;
 IF @ProcessType IS NOT NULL AND @ProcessType=0 THROW 54700,N'نوع العملية أو مرحلة الموافقة غير صحيحة.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalDelegations WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND DelegatorID=@UserID AND DelegateID=@DelegateID AND RecordState=0
            AND ISNULL(ProcessType,0)=ISNULL(@ProcessType,0) AND DateFrom<=@DateTo AND DateTo>=@DateFrom)
   THROW 54724,N'يوجد تفويض نشط متداخل لنفس المفوَّض ونفس العملية.',1;
  INSERT dbo.Emp_ApprovalDelegations(CmpID,DelegatorID,DelegateID,ProcessType,DateFrom,DateTo,Reason,CreatedBy) VALUES(@CmpID,@UserID,@DelegateID,@ProcessType,@DateFrom,@DateTo,@Reason,@UserID);
  DECLARE @ID BIGINT=SCOPE_IDENTITY(),@Title NVARCHAR(200)=N'تم تفويضك بصلاحيات اعتماد',@Body NVARCHAR(1000)=CONCAT(N'من ',CONVERT(nvarchar(10),@DateFrom,23),N' إلى ',CONVERT(nvarchar(10),@DateTo,23));
  EXEC dbo.Emp_NotifyUser @CmpID,@DelegateID,8,@ProcessType,NULL,NULL,@Title,@Body;
  COMMIT TRANSACTION;
  SELECT @ID AS DelegationID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_RevokeApprovalDelegation @CmpID INT,@UserID BIGINT,@DelegationID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 UPDATE dbo.Emp_ApprovalDelegations SET RecordState=1,RevokedAt=SYSDATETIME(),RevokedBy=@UserID WHERE CmpID=@CmpID AND DelegationID=@DelegationID AND DelegatorID=@UserID AND RecordState=0;
 IF @@ROWCOUNT<>1 THROW 54725,N'التفويض غير موجود أو أُلغي مسبقاً أو لا يخصك.',1;
 SELECT @DelegationID AS DelegationID;
END;
GO
-- @Mode 1 = delegations I gave, 2 = delegations I received
CREATE OR ALTER PROCEDURE dbo.Emp_SelectApprovalDelegations @CmpID INT,@UserID BIGINT,@Mode TINYINT=1,@ActiveOnly BIT=1
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT d.DelegationID,d.DelegatorID,CONCAT(er.EmpName,N'') AS DelegatorName,d.DelegateID,CONCAT(ee.EmpName,N'') AS DelegateName,
        d.ProcessType,CASE WHEN d.ProcessType IS NULL THEN N'كل العمليات' ELSE dbo.fn_Emp_ProcessTypeName(d.ProcessType) END AS ProcessName,
        d.DateFrom,d.DateTo,d.Reason,d.RecordState,
        CONVERT(bit,CASE WHEN d.RecordState=0 AND CONVERT(date,SYSDATETIME()) BETWEEN d.DateFrom AND d.DateTo THEN 1 ELSE 0 END) AS IsActiveNow
 FROM dbo.Emp_ApprovalDelegations d
 LEFT JOIN dbo.Emp_Employee er ON er.EmpCompany=d.CmpID AND er.EmpID=d.DelegatorID
 LEFT JOIN dbo.Emp_Employee ee ON ee.EmpCompany=d.CmpID AND ee.EmpID=d.DelegateID
 WHERE d.CmpID=@CmpID AND ((@Mode=1 AND d.DelegatorID=@UserID) OR (@Mode=2 AND d.DelegateID=@UserID))
   AND (@ActiveOnly=0 OR (d.RecordState=0 AND d.DateTo>=CONVERT(date,SYSDATETIME())))
 ORDER BY d.DateFrom DESC,d.DelegationID DESC;
END;
GO

/* ---------- notifications ---------- */
CREATE OR ALTER PROCEDURE dbo.Emp_SelectMyNotifications @CmpID INT,@UserID BIGINT,@UnreadOnly BIT=0,@Top INT=100
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT TOP(CASE WHEN @Top IS NULL OR @Top<=0 OR @Top>500 THEN 100 ELSE @Top END)
        NotifID,NotifType,ProcessType,EntityID,ApprovalID,Title,Body,IsRead,CreatedAt,ReadAt
 FROM dbo.Emp_Notifications WHERE CmpID=@CmpID AND UserID=@UserID AND (@UnreadOnly=0 OR IsRead=0) ORDER BY NotifID DESC;
END;
GO
-- @NotifID NULL = mark all as read
CREATE OR ALTER PROCEDURE dbo.Emp_MarkNotificationsRead @CmpID INT,@UserID BIGINT,@NotifID BIGINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 UPDATE dbo.Emp_Notifications SET IsRead=1,ReadAt=SYSDATETIME() WHERE CmpID=@CmpID AND UserID=@UserID AND IsRead=0 AND (@NotifID IS NULL OR NotifID=@NotifID);
 SELECT @@ROWCOUNT AS MarkedCount;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_CountMyNotifications @CmpID INT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT COUNT(*) AS UnreadCount FROM dbo.Emp_Notifications WHERE CmpID=@CmpID AND UserID=@UserID AND IsRead=0;
END;
GO

/* =====================================================================
   PART 5 - MSS (manager self-service)
   ===================================================================== */
-- approvals waiting for me (as approver or as active delegate)
CREATE OR ALTER PROCEDURE dbo.Emp_MSS_PendingApprovals @CmpID INT,@UserID BIGINT,@ProcessType TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT r.ApprovalID,r.ProcessType,dbo.fn_Emp_ProcessTypeName(r.ProcessType) AS ProcessName,r.EntityID,r.CurrentStep,r.AttemptNo,
        r.SubmittedBy,CONCAT(sb.EmpName,N'') AS SubmittedByName,
        ISNULL(r.SubjectEmployeeID,r.SubmittedBy) AS SubjectEmployeeID,CONCAT(sj.EmpName,N'') AS SubjectName,
        r.CreatedAt AS SubmittedAt,DATEDIFF(HOUR,r.CreatedAt,SYSDATETIME()) AS AgeHours,
        x.CurrentApprover,CONVERT(bit,CASE WHEN x.CurrentApprover=@UserID THEN 0 ELSE 1 END) AS IsDelegated
 FROM dbo.Emp_ApprovalRequests r
 CROSS APPLY(SELECT dbo.fn_Emp_CurrentApprover(r.CmpID,r.ApprovalID) AS CurrentApprover) x
 LEFT JOIN dbo.Emp_Employee sb ON sb.EmpCompany=r.CmpID AND sb.EmpID=r.SubmittedBy
 LEFT JOIN dbo.Emp_Employee sj ON sj.EmpCompany=r.CmpID AND sj.EmpID=ISNULL(r.SubjectEmployeeID,r.SubmittedBy)
 WHERE r.CmpID=@CmpID AND r.ApprovalState=0 AND (@ProcessType IS NULL OR r.ProcessType=@ProcessType)
   AND r.SubmittedBy<>@UserID AND ISNULL(r.SubjectEmployeeID,r.SubmittedBy)<>@UserID
   AND (x.CurrentApprover=@UserID OR dbo.fn_Emp_IsDelegate(@CmpID,x.CurrentApprover,@UserID,r.ProcessType,CONVERT(date,SYSDATETIME()))=1)
 ORDER BY r.CreatedAt,r.ApprovalID;
END;
GO
-- every request (any state) of my direct reports
CREATE OR ALTER PROCEDURE dbo.Emp_MSS_TeamRequests
 @CmpID INT,@UserID BIGINT,@ProcessType TINYINT=NULL,@State TINYINT=NULL,@DateFrom DATE=NULL,@DateTo DATE=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 SELECT r.ApprovalID,r.ProcessType,dbo.fn_Emp_ProcessTypeName(r.ProcessType) AS ProcessName,r.EntityID,r.CurrentStep,r.AttemptNo,
        r.ApprovalState,dbo.fn_Emp_ApprovalStateName(r.ApprovalState) AS StateName,
        ISNULL(r.SubjectEmployeeID,r.SubmittedBy) AS EmployeeID,CONCAT(e.EmpName,N'') AS EmployeeName,
        r.CreatedAt AS SubmittedAt,r.CompletedAt,x.CurrentApprover,CONCAT(ap.EmpName,N'') AS CurrentApproverName
 FROM dbo.fn_Emp_GetDirectReports(@CmpID,@UserID,CONVERT(date,SYSDATETIME())) t
 JOIN dbo.Emp_ApprovalRequests r ON r.CmpID=@CmpID AND ISNULL(r.SubjectEmployeeID,r.SubmittedBy)=t.EmployeeID
 CROSS APPLY(SELECT dbo.fn_Emp_CurrentApprover(r.CmpID,r.ApprovalID) AS CurrentApprover) x
 LEFT JOIN dbo.Emp_Employee e ON e.EmpCompany=r.CmpID AND e.EmpID=t.EmployeeID
 LEFT JOIN dbo.Emp_Employee ap ON ap.EmpCompany=r.CmpID AND ap.EmpID=x.CurrentApprover
 WHERE (@ProcessType IS NULL OR r.ProcessType=@ProcessType) AND (@State IS NULL OR r.ApprovalState=@State)
   AND (@DateFrom IS NULL OR CONVERT(date,r.CreatedAt)>=@DateFrom) AND (@DateTo IS NULL OR CONVERT(date,r.CreatedAt)<=@DateTo)
 ORDER BY r.CreatedAt DESC,r.ApprovalID DESC;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_MSS_TeamOvertimeRequests @CmpID INT,@UserID BIGINT,@State TINYINT=NULL,@DateFrom DATE=NULL,@DateTo DATE=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 SELECT o.OvertimeID,o.EmployeeID,CONCAT(e.EmpName,N'') AS EmployeeName,o.WorkDate,o.StartAt,o.EndAt,o.Hours,o.Reason,o.Multiplier,o.RequestState,o.CreatedAt,o.ApprovedAt,o.ApprovedBy
 FROM dbo.fn_Emp_GetDirectReports(@CmpID,@UserID,CONVERT(date,SYSDATETIME())) t
 JOIN dbo.Emp_OvertimeRequests o ON o.CmpID=@CmpID AND o.EmployeeID=t.EmployeeID
 LEFT JOIN dbo.Emp_Employee e ON e.EmpCompany=o.CmpID AND e.EmpID=o.EmployeeID
 WHERE (@State IS NULL OR o.RequestState=@State) AND (@DateFrom IS NULL OR o.WorkDate>=@DateFrom) AND (@DateTo IS NULL OR o.WorkDate<=@DateTo)
 ORDER BY o.WorkDate DESC,o.OvertimeID DESC;
END;
GO
-- single entry point for the manager's decision; forwards to the process-specific procedure
-- @Decision: 1 approve, 2 reject, 3 return for edit (comment required)
CREATE OR ALTER PROCEDURE dbo.Emp_MSS_DecideRequest
 @CmpID INT,@UserID BIGINT,@ProcessType TINYINT,@EntityID BIGINT,@Decision TINYINT,@Comments NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @Decision NOT IN(1,2,3) THROW 54706,N'قرار الموافقة أو المرحلة غير صحيح.',1;
 DECLARE @Step SMALLINT,@Ap BIT=CASE WHEN @Decision=1 THEN 1 ELSE 0 END,@C500 NVARCHAR(500)=LEFT(@Comments,500);
 SELECT @Step=CurrentStep FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID AND ApprovalState=0;
 IF @Step IS NULL THROW 54707,N'طلب الموافقة غير قائم أو المرحلة الحالية مختلفة.',1;
 IF @Decision=3
 BEGIN EXEC dbo.Emp_ReturnApprovalForEdit @CmpID,@ProcessType,@EntityID,@UserID,@Comments; RETURN; END;
 IF @ProcessType=1 EXEC dbo.Emp_DecideLeaveRequest @CmpID,@EntityID,@UserID,@Decision,@Step,@C500;
 ELSE IF @ProcessType=2 EXEC dbo.Emp_DecideOvertimeRequest @CmpID,@EntityID,@UserID,@Ap,@Step,@Comments;
 ELSE IF @ProcessType=3 EXEC dbo.Emp_DecideRewardPenalty @CmpID,@EntityID,@UserID,@Ap,@Step,@Comments;
 ELSE IF @ProcessType=4 AND @Decision=1 EXEC dbo.Emp_ApproveLoanAndGenerateSchedule @CmpID,@EntityID,@UserID,@Step,@Comments;
 ELSE IF @ProcessType=4 EXEC dbo.Emp_RejectLoan @CmpID,@EntityID,@UserID,@Step,@Comments;
 ELSE IF @ProcessType=5 EXEC dbo.Emp_DecideTermination @CmpID,@EntityID,@UserID,@Decision,@Step,@Comments;
 ELSE IF @ProcessType=6 AND @Decision=1 EXEC dbo.Emp_ApproveFinalSettlement @CmpID,@EntityID,@UserID,@Step,@Comments;
 ELSE IF @ProcessType=7 EXEC dbo.Emp_DecideJobOffer @CmpID,@EntityID,@UserID,@Decision,@Step,@Comments;
 ELSE IF @ProcessType=8 EXEC dbo.Emp_DecideWorkforceRequisition @CmpID,@EntityID,@UserID,@Decision,NULL,@Step,@Comments;
 ELSE IF @ProcessType=11 AND @Decision=1 EXEC dbo.Emp_ApproveSalaryAdvance @CmpID,@EntityID,@UserID,@Step,@Comments;
 ELSE IF @ProcessType=11 EXEC dbo.Emp_RejectSalaryAdvance @CmpID,@EntityID,@UserID,@Step,@Comments;
 ELSE IF @ProcessType=12 EXEC dbo.Emp_DecideEmployeeExternalDeduction @CmpID,@EntityID,@UserID,@Decision,@Step,@Comments;
 ELSE IF @ProcessType=13 EXEC dbo.Emp_DecideShiftSwapRequest @CmpID,@UserID,@EntityID,@Ap,@Comments;
 ELSE THROW 54726,N'هذا النوع من الطلبات يُعتمد من شاشته المخصصة (مسير الرواتب أو تسوية الحضور أو الرفض في التسوية النهائية).',1;
END;
GO

/* =====================================================================
   PART 6 - ESS (employee self-service)
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Emp_ESS_MyRequests @CmpID INT,@UserID BIGINT,@ProcessType TINYINT=NULL,@State TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 SELECT r.ApprovalID,r.ProcessType,dbo.fn_Emp_ProcessTypeName(r.ProcessType) AS ProcessName,r.EntityID,r.CurrentStep,r.AttemptNo,
        r.ApprovalState,dbo.fn_Emp_ApprovalStateName(r.ApprovalState) AS StateName,r.CreatedAt AS SubmittedAt,r.CompletedAt,
        x.CurrentApprover,CONCAT(ap.EmpName,N'') AS CurrentApproverName,
        (SELECT TOP(1) ev.Comments FROM dbo.Emp_ApprovalEvents ev WHERE ev.CmpID=r.CmpID AND ev.ApprovalID=r.ApprovalID ORDER BY ev.EventID DESC) AS LastComment
 FROM dbo.Emp_ApprovalRequests r
 CROSS APPLY(SELECT dbo.fn_Emp_CurrentApprover(r.CmpID,r.ApprovalID) AS CurrentApprover) x
 LEFT JOIN dbo.Emp_Employee ap ON ap.EmpCompany=r.CmpID AND ap.EmpID=x.CurrentApprover
 WHERE r.CmpID=@CmpID AND (r.SubmittedBy=@UserID OR ISNULL(r.SubjectEmployeeID,r.SubmittedBy)=@UserID)
   AND (@ProcessType IS NULL OR r.ProcessType=@ProcessType) AND (@State IS NULL OR r.ApprovalState=@State)
 ORDER BY r.CreatedAt DESC,r.ApprovalID DESC;
END;
GO
-- full history of one request: decisions + re-routings, oldest first
CREATE OR ALTER PROCEDURE dbo.Emp_ESS_MyApprovalTimeline @CmpID INT,@UserID BIGINT,@ApprovalID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID AND (SubmittedBy=@UserID OR ISNULL(SubjectEmployeeID,SubmittedBy)=@UserID))
  THROW 54727,N'طلب الموافقة غير موجود أو لا يخصك.',1;
 SELECT t.Kind,t.StepNo,t.AttemptNo,t.ActorID,CONCAT(a.EmpName,N'') AS ActorName,t.Detail,t.Comments,t.At
 FROM (
  SELECT N'قرار' AS Kind,ev.StepNo,ev.AttemptNo,ev.ApproverID AS ActorID,
         CASE ev.Decision WHEN 1 THEN N'موافقة' WHEN 2 THEN N'رفض' ELSE N'إرجاع للتعديل' END+CASE WHEN ev.OnBehalfOf IS NULL THEN N'' ELSE N' (بالتفويض)' END AS Detail,
         ev.Comments,ev.DecidedAt AS At,ev.EventID AS Seq
  FROM dbo.Emp_ApprovalEvents ev WHERE ev.CmpID=@CmpID AND ev.ApprovalID=@ApprovalID
  UNION ALL
  SELECT N'إعادة توجيه',ra.StepNo,ra.AttemptNo,ra.CreatedBy,N'إلى المستخدم '+CONVERT(nvarchar(20),ra.ToApproverID),ra.Reason,ra.CreatedAt,ra.ReassignID+1000000000
  FROM dbo.Emp_ApprovalReassignments ra WHERE ra.CmpID=@CmpID AND ra.ApprovalID=@ApprovalID
 ) t LEFT JOIN dbo.Emp_Employee a ON a.EmpCompany=@CmpID AND a.EmpID=t.ActorID
 ORDER BY t.At,t.Seq;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_ESS_MyLoans @CmpID INT,@UserID BIGINT,@State TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 SELECT l.LoanID,l.LoanNo,l.Principal,l.InterestAmount,l.CurrencyID,c.CurCode,l.StartDate,l.InstallmentCount,l.InstallmentAmount,l.LoanState,l.CreatedAt,l.ApprovedAt,
        ISNULL(i.PaidTotal,0) AS PaidTotal,ISNULL(i.RemainingTotal,0) AS RemainingTotal,i.NextDueDate
 FROM dbo.Emp_Loans l
 LEFT JOIN dbo.Acc_Currency c ON c.CurCmp=l.CmpID AND c.CurID=l.CurrencyID
 OUTER APPLY(SELECT SUM(x.PaidAmount) AS PaidTotal,SUM(x.Amount-x.PaidAmount) AS RemainingTotal,MIN(CASE WHEN x.PaidAmount<x.Amount THEN x.DueDate END) AS NextDueDate
             FROM dbo.Emp_LoanInstallments x WHERE x.CmpID=l.CmpID AND x.LoanID=l.LoanID) i
 WHERE l.CmpID=@CmpID AND l.EmployeeID=@UserID AND (@State IS NULL OR l.LoanState=@State)
 ORDER BY l.LoanID DESC;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_ESS_MyLoanInstallments @CmpID INT,@UserID BIGINT,@LoanID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Loans WHERE CmpID=@CmpID AND LoanID=@LoanID AND EmployeeID=@UserID) THROW 54728,N'القرض غير موجود أو لا يخصك.',1;
 SELECT InstallmentID,InstallmentNo,DueDate,Amount,PaidAmount,Amount-PaidAmount AS RemainingAmount,PaidAt,InstallmentState
 FROM dbo.Emp_LoanInstallments WHERE CmpID=@CmpID AND LoanID=@LoanID ORDER BY InstallmentNo;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_ESS_MySalaryAdvances @CmpID INT,@UserID BIGINT,@State TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 SELECT a.AdvanceID,a.AdvanceNo,a.Amount,a.CurrencyID,c.CurCode,a.IssueDate,a.FirstDeductionDate,a.InstallmentCount,a.InstallmentAmount,a.AdvanceState,a.CreatedAt,a.ApprovedAt,
        ISNULL(i.PaidTotal,0) AS PaidTotal,ISNULL(i.RemainingTotal,0) AS RemainingTotal,i.NextDueDate
 FROM dbo.Emp_SalaryAdvances a
 LEFT JOIN dbo.Acc_Currency c ON c.CurCmp=a.CmpID AND c.CurID=a.CurrencyID
 OUTER APPLY(SELECT SUM(x.PaidAmount) AS PaidTotal,SUM(x.Amount-x.PaidAmount) AS RemainingTotal,MIN(CASE WHEN x.PaidAmount<x.Amount THEN x.DueDate END) AS NextDueDate
             FROM dbo.Emp_SalaryAdvanceInstallments x WHERE x.CmpID=a.CmpID AND x.AdvanceID=a.AdvanceID) i
 WHERE a.CmpID=@CmpID AND a.EmployeeID=@UserID AND (@State IS NULL OR a.AdvanceState=@State)
 ORDER BY a.AdvanceID DESC;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_ESS_MySalaryAdvanceInstallments @CmpID INT,@UserID BIGINT,@AdvanceID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_ESS_RequireEmployee @CmpID,@UserID;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_SalaryAdvances WHERE CmpID=@CmpID AND AdvanceID=@AdvanceID AND EmployeeID=@UserID) THROW 54729,N'السلفة غير موجودة أو لا تخصك.',1;
 SELECT InstallmentID,InstallmentNo,DueDate,Amount,PaidAmount,Amount-PaidAmount AS RemainingAmount,PaidAt,InstallmentState
 FROM dbo.Emp_SalaryAdvanceInstallments WHERE CmpID=@CmpID AND AdvanceID=@AdvanceID ORDER BY InstallmentNo;
END;
GO

/* =====================================================================
   PART 7 - REPORTS & DASHBOARD
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.Emp_Rpt_ApprovalSummary @CmpID INT,@UserID BIGINT,@DateFrom DATE=NULL,@DateTo DATE=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT r.ProcessType,dbo.fn_Emp_ProcessTypeName(r.ProcessType) AS ProcessName,COUNT(*) AS TotalRequests,
        SUM(CASE WHEN r.ApprovalState=0 THEN 1 ELSE 0 END) AS Pending,
        SUM(CASE WHEN r.ApprovalState=1 THEN 1 ELSE 0 END) AS Approved,
        SUM(CASE WHEN r.ApprovalState=2 THEN 1 ELSE 0 END) AS Rejected,
        SUM(CASE WHEN r.ApprovalState=3 THEN 1 ELSE 0 END) AS ReturnedForEdit,
        AVG(CASE WHEN r.CompletedAt IS NOT NULL THEN CONVERT(decimal(18,2),DATEDIFF(MINUTE,r.CreatedAt,r.CompletedAt))/60.0 END) AS AvgTurnaroundHours,
        MAX(CASE WHEN r.ApprovalState=0 THEN DATEDIFF(HOUR,r.CreatedAt,SYSDATETIME()) END) AS OldestPendingHours
 FROM dbo.Emp_ApprovalRequests r
 WHERE r.CmpID=@CmpID AND (@DateFrom IS NULL OR CONVERT(date,r.CreatedAt)>=@DateFrom) AND (@DateTo IS NULL OR CONVERT(date,r.CreatedAt)<=@DateTo)
 GROUP BY r.ProcessType ORDER BY r.ProcessType;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_Rpt_PendingApprovalsByApprover @CmpID INT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT x.CurrentApprover AS ApproverID,CONCAT(e.EmpName,N'') AS ApproverName,COUNT(*) AS PendingCount,
        MIN(r.CreatedAt) AS OldestSubmittedAt,MAX(DATEDIFF(HOUR,r.CreatedAt,SYSDATETIME())) AS OldestAgeHours
 FROM dbo.Emp_ApprovalRequests r
 CROSS APPLY(SELECT dbo.fn_Emp_CurrentApprover(r.CmpID,r.ApprovalID) AS CurrentApprover) x
 LEFT JOIN dbo.Emp_Employee e ON e.EmpCompany=r.CmpID AND e.EmpID=x.CurrentApprover
 WHERE r.CmpID=@CmpID AND r.ApprovalState=0
 GROUP BY x.CurrentApprover,e.EmpName ORDER BY PendingCount DESC;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_Rpt_HeadcountSummary @CmpID INT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT p.EmpOrgStrID AS OrgUnitID,ISNULL(o.EmpOrgStrName,N'بدون وحدة تنظيمية') AS OrgUnitName,COUNT(*) AS ActiveEmployees
 FROM dbo.Emp_Employee e
 LEFT JOIN dbo.Emp_Position p ON p.PosCmp=e.EmpCompany AND p.PosID=e.PosID
 LEFT JOIN dbo.Emp_OrganigramStructure o ON o.EmpOrgStrCompany=e.EmpCompany AND o.EmpOrgStrID=p.EmpOrgStrID
 WHERE e.EmpCompany=@CmpID AND e.EmpState=0
 GROUP BY p.EmpOrgStrID,o.EmpOrgStrName ORDER BY ActiveEmployees DESC,OrgUnitName;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_Rpt_LeaveUtilization @CmpID INT,@UserID BIGINT,@Year SMALLINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 DECLARE @Y SMALLINT=ISNULL(@Year,CONVERT(smallint,YEAR(SYSDATETIME())));
 SELECT b.LeaveTypeID,t.LeaveTypeName,@Y AS BalanceYear,COUNT(DISTINCT b.EmployeeID) AS Employees,
        SUM(b.OpeningBalance) AS Opening,SUM(b.Earned) AS Earned,SUM(b.Used) AS Used,SUM(b.Adjusted) AS Adjusted,SUM(b.ClosingBalance) AS Closing
 FROM dbo.Emp_LeaveBalances b JOIN dbo.Emp_LeaveTypes t ON t.LeaveTypeCmp=b.CmpID AND t.LeaveTypeID=b.LeaveTypeID
 WHERE b.CmpID=@CmpID AND b.BalanceYear=@Y AND b.RecordState=0
 GROUP BY b.LeaveTypeID,t.LeaveTypeName ORDER BY t.LeaveTypeName;
END;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_Rpt_PayRunSummary @CmpID INT,@UserID BIGINT,@PeriodID BIGINT=NULL
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 SELECT r.PayRunID,r.PeriodID,p.PeriodName,r.RunNo,r.CurrencyID,c.CurCode,r.RunState,r.GrossTotal,r.DeductionTotal,r.NetTotal,
        (SELECT COUNT(DISTINCT d.EmployeeID) FROM dbo.Emp_PayrollDetails d WHERE d.CmpID=r.CmpID AND d.PayRunID=r.PayRunID) AS Employees,
        r.CalculatedAt,r.ApprovedAt,r.ClosedAt
 FROM dbo.Emp_PayRuns r
 JOIN dbo.Emp_PayPeriods p ON p.CmpID=r.CmpID AND p.PeriodID=r.PeriodID
 LEFT JOIN dbo.Acc_Currency c ON c.CurCmp=r.CmpID AND c.CurID=r.CurrencyID
 WHERE r.CmpID=@CmpID AND (@PeriodID IS NULL OR r.PeriodID=@PeriodID)
 ORDER BY p.DateFrom DESC,r.RunNo DESC;
END;
GO
-- headline numbers for the HR dashboard (one row)
CREATE OR ALTER PROCEDURE dbo.Emp_HR_Dashboard @CmpID INT,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 DECLARE @Today DATE=CONVERT(date,SYSDATETIME()),@MonthStart DATE=DATEFROMPARTS(YEAR(SYSDATETIME()),MONTH(SYSDATETIME()),1);
 SELECT
  (SELECT COUNT(*) FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpState=0) AS ActiveEmployees,
  (SELECT COUNT(*) FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpState=0 AND HireDate>=@MonthStart) AS NewHiresThisMonth,
  (SELECT COUNT(DISTINCT EmployeeID) FROM dbo.Emp_LeaveRequests WHERE CmpID=@CmpID AND RequestState=1 AND CONVERT(date,StartAt)<=@Today AND CONVERT(date,EndAt)>=@Today) AS OnLeaveToday,
  (SELECT COUNT(*) FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalState=0) AS PendingApprovalsAll,
  (SELECT COUNT(*) FROM dbo.Emp_ApprovalRequests r WHERE r.CmpID=@CmpID AND r.ApprovalState=0 AND dbo.fn_Emp_CurrentApprover(r.CmpID,r.ApprovalID)=@UserID) AS PendingForMe,
  (SELECT ISNULL(SUM(Hours),0) FROM dbo.Emp_OvertimeRequests WHERE CmpID=@CmpID AND RequestState=1 AND WorkDate>=@MonthStart AND WorkDate<=@Today) AS ApprovedOvertimeHoursThisMonth,
  (SELECT COUNT(*) FROM dbo.Emp_Notifications WHERE CmpID=@CmpID AND UserID=@UserID AND IsRead=0) AS UnreadNotifications,
  (SELECT COUNT(*) FROM dbo.Emp_ApprovalDelegations WHERE CmpID=@CmpID AND RecordState=0 AND @Today BETWEEN DateFrom AND DateTo) AS ActiveDelegations;
END;
GO
PRINT N'MADAR Phase 3 script finished.';
GO

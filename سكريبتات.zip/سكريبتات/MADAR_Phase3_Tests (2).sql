/* =====================================================================
   MADAR Phase 3 - functional tests for the approval engine v2
   Run AFTER MADAR_Phase3_HR_Approvals.sql (rebased on the 2026-11-18 7:32 PM schema: ApproverKind/LevelsUp/SubjectEmpID).

   WHAT YOU MUST SET (section "EDIT ME"): one company and four DIFFERENT
   active users of that company (submitter, approver1, approver2, delegate).

   The engine procedures roll the whole transaction back on error, so these
   tests cannot be wrapped in an outer transaction. They use the artificial
   process types 100 and 101 (never used by the application) and delete
   everything they created at the end (append-only triggers are disabled for
   that cleanup only and re-enabled afterwards).

   Result: one grid, Passed = 1 for each check that holds.
   ===================================================================== */
USE [MADARERPDataBase]
GO
SET NOCOUNT ON;
DECLARE
 /* ---------------- EDIT ME ---------------- */
 @Cmp INT = 1,            -- company id
 @Sub BIGINT = 0,         -- submitter (user id = employee id)
 @A1  BIGINT = 0,         -- approver of step 1
 @A2  BIGINT = 0,         -- approver of step 2
 @Del BIGINT = 0,         -- delegate / re-assignment target
 @EmpWithManager BIGINT = NULL;  -- OPTIONAL: an employee that has a direct manager in the org chart
 /* ----------------------------------------- */

DECLARE @R TABLE(Seq INT IDENTITY(1,1),Test NVARCHAR(120),Passed BIT,Detail NVARCHAR(400));
DECLARE @E INT,@St TINYINT,@Nx SMALLINT,@Ap BIGINT,@Ent BIGINT=900001,@Today DATE=CONVERT(date,SYSDATETIME()),@Start DATETIME2(0)=SYSDATETIME(),
        @Cur BIGINT,@Cnt INT,@Att SMALLINT,@Step SMALLINT,@DelID BIGINT,@Tmp BIGINT;
DECLARE @D TABLE(DelegationID BIGINT);

BEGIN TRY
 IF @Sub<=0 OR @A1<=0 OR @A2<=0 OR @Del<=0 OR @Sub IN(@A1,@A2,@Del) OR @A1 IN(@A2,@Del) OR @A2=@Del
  THROW 59000,N'EDIT ME: set @Cmp,@Sub,@A1,@A2,@Del to five different valid values first.',1;
 IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE ProcessType IN(100,101)) OR EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WHERE ProcessType IN(100,101))
  THROW 59001,N'Process types 100/101 are already in use - refusing to run (cleanup first).',1;

 /* ---- route: step1 -> A1, step2 -> A2 ---- */
 EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@Cmp,@ProcessType=100,@StepNo=1,@ApproverID=@A1,@RecordState=0,@UserID=@A1,@ApproverKind=0,@LevelsUp=NULL;
 EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@Cmp,@ProcessType=100,@StepNo=2,@ApproverID=@A2,@RecordState=0,@UserID=@A1,@ApproverKind=0,@LevelsUp=NULL;

 /* T01 start */
 EXEC dbo.Emp_StartApproval @CmpID=@Cmp,@ProcessType=100,@EntityID=@Ent,@SubmittedBy=@Sub,@SuppressResult=1;
 DECLARE @AID BIGINT=(SELECT ApprovalID FROM dbo.Emp_ApprovalRequests WHERE CmpID=@Cmp AND ProcessType=100 AND EntityID=@Ent);
 INSERT @R(Test,Passed,Detail) SELECT N'T01 start: pending at step 1',CASE WHEN ApprovalState=0 AND CurrentStep=1 AND AttemptNo=1 THEN 1 ELSE 0 END,CONCAT(N'state=',ApprovalState,N' step=',CurrentStep,N' attempt=',AttemptNo) FROM dbo.Emp_ApprovalRequests WHERE ApprovalID=@AID;

 /* T02 notifications */
 INSERT @R(Test,Passed,Detail) SELECT N'T02 notifications: submitter(1) + approver(2)',
   CASE WHEN EXISTS(SELECT 1 FROM dbo.Emp_Notifications WHERE ApprovalID=@AID AND UserID=@Sub AND NotifType=1)
         AND EXISTS(SELECT 1 FROM dbo.Emp_Notifications WHERE ApprovalID=@AID AND UserID=@A1 AND NotifType=2) THEN 1 ELSE 0 END,N'';

 /* T03 submitter cannot approve */
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_DecideApprovalStep @Cmp,100,@Ent,1,@Sub,1,NULL,@St OUTPUT,@Nx OUTPUT,1; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T03 submitter cannot approve own request',CASE WHEN @E=54708 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));

 /* T04 wrong approver */
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_DecideApprovalStep @Cmp,100,@Ent,1,@A2,1,NULL,@St OUTPUT,@Nx OUTPUT,1; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T04 non-approver is refused',CASE WHEN @E=54709 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));

 /* T05 delegation A1 -> Del */
 INSERT @D EXEC dbo.Emp_SaveApprovalDelegation @CmpID=@Cmp,@UserID=@A1,@DelegateID=@Del,@ProcessType=NULL,@DateFrom=@Today,@DateTo=@Today,@Reason=N'test';
 SELECT @DelID=DelegationID FROM @D;
 INSERT @R(Test,Passed,Detail) VALUES(N'T05 delegation created',CASE WHEN @DelID IS NOT NULL THEN 1 ELSE 0 END,CONCAT(N'id=',@DelID));

 /* T06 delegate approves step 1 on behalf of A1 */
 EXEC dbo.Emp_DecideApprovalStep @Cmp,100,@Ent,1,@Del,1,N'ok',@St OUTPUT,@Nx OUTPUT,1;
 INSERT @R(Test,Passed,Detail) VALUES(N'T06 delegate approves step 1 -> step 2 pending',CASE WHEN @St=0 AND @Nx=2 THEN 1 ELSE 0 END,CONCAT(N'state=',@St,N' next=',@Nx));
 INSERT @R(Test,Passed,Detail) SELECT N'T06b event records OnBehalfOf=A1',CASE WHEN OnBehalfOf=@A1 THEN 1 ELSE 0 END,CONCAT(N'onBehalf=',OnBehalfOf) FROM dbo.Emp_ApprovalEvents WHERE ApprovalID=@AID AND StepNo=1 AND AttemptNo=1;

 /* T07 current approver is A2 */
 SET @Cur=dbo.fn_Emp_CurrentApprover(@Cmp,@AID);
 INSERT @R(Test,Passed,Detail) VALUES(N'T07 current approver = A2',CASE WHEN @Cur=@A2 THEN 1 ELSE 0 END,CONCAT(N'current=',@Cur));

 /* T08 re-assign step 2 from A2 to Del */
 EXEC dbo.Emp_ReassignApprovalStep @CmpID=@Cmp,@ProcessType=100,@EntityID=@Ent,@UserID=@A2,@NewApproverID=@Del,@Reason=N'test';
 SET @Cur=dbo.fn_Emp_CurrentApprover(@Cmp,@AID);
 INSERT @R(Test,Passed,Detail) VALUES(N'T08 re-assignment changes current approver',CASE WHEN @Cur=@Del THEN 1 ELSE 0 END,CONCAT(N'current=',@Cur));

 /* T09 return needs a comment */
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_DecideApprovalStep @Cmp,100,@Ent,2,@Del,3,NULL,@St OUTPUT,@Nx OUTPUT,1; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T09 return without comment refused',CASE WHEN @E=54714 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));

 /* T10 return for edit */
 EXEC dbo.Emp_ReturnApprovalForEdit @CmpID=@Cmp,@ProcessType=100,@EntityID=@Ent,@ApproverID=@Del,@Comments=N'please fix';
 INSERT @R(Test,Passed,Detail) SELECT N'T10 return for edit -> state 3',CASE WHEN ApprovalState=3 THEN 1 ELSE 0 END,CONCAT(N'state=',ApprovalState) FROM dbo.Emp_ApprovalRequests WHERE ApprovalID=@AID;

 /* T11 cannot decide a returned request */
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_DecideApprovalStep @Cmp,100,@Ent,2,@Del,1,NULL,@St OUTPUT,@Nx OUTPUT,1; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T11 returned request cannot be decided',CASE WHEN @E=54707 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));

 /* T12 re-submit starts attempt 2 */
 EXEC dbo.Emp_StartApproval @CmpID=@Cmp,@ProcessType=100,@EntityID=@Ent,@SubmittedBy=@Sub,@SuppressResult=1;
 INSERT @R(Test,Passed,Detail) SELECT N'T12 re-submit -> attempt 2, step 1, pending',CASE WHEN ApprovalState=0 AND CurrentStep=1 AND AttemptNo=2 THEN 1 ELSE 0 END,CONCAT(N'state=',ApprovalState,N' step=',CurrentStep,N' attempt=',AttemptNo) FROM dbo.Emp_ApprovalRequests WHERE ApprovalID=@AID;

 /* T13 reject, T14 re-submit after reject */
 EXEC dbo.Emp_DecideApprovalStep @Cmp,100,@Ent,1,@A1,2,N'no',@St OUTPUT,@Nx OUTPUT,1;
 INSERT @R(Test,Passed,Detail) VALUES(N'T13 reject -> state 2',CASE WHEN @St=2 THEN 1 ELSE 0 END,CONCAT(N'state=',@St));
 EXEC dbo.Emp_StartApproval @CmpID=@Cmp,@ProcessType=100,@EntityID=@Ent,@SubmittedBy=@Sub,@SuppressResult=1;
 INSERT @R(Test,Passed,Detail) SELECT N'T14 re-submit after reject -> attempt 3',CASE WHEN ApprovalState=0 AND AttemptNo=3 THEN 1 ELSE 0 END,CONCAT(N'attempt=',AttemptNo) FROM dbo.Emp_ApprovalRequests WHERE ApprovalID=@AID;

 /* T15 append-only audit trail */
 SET @E=NULL; BEGIN TRY UPDATE dbo.Emp_ApprovalEvents SET Comments=N'x' WHERE ApprovalID=@AID; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T15a events cannot be updated',CASE WHEN @E=54720 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));
 SET @E=NULL; BEGIN TRY DELETE FROM dbo.Emp_ApprovalEvents WHERE ApprovalID=@AID; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T15b events cannot be deleted',CASE WHEN @E=54720 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));

 /* T16 history completeness: 3 decisions + 1 re-assignment */
 SELECT @Cnt=COUNT(*) FROM dbo.Emp_ApprovalEvents WHERE ApprovalID=@AID;
 INSERT @R(Test,Passed,Detail) VALUES(N'T16a three decision events recorded',CASE WHEN @Cnt=3 THEN 1 ELSE 0 END,CONCAT(N'events=',@Cnt));
 SELECT @Cnt=COUNT(*) FROM dbo.Emp_ApprovalReassignments WHERE ApprovalID=@AID;
 INSERT @R(Test,Passed,Detail) VALUES(N'T16b one re-assignment recorded',CASE WHEN @Cnt=1 THEN 1 ELSE 0 END,CONCAT(N'reassignments=',@Cnt));

 /* T17 inbox: A1 sees the pending request (as approver) */
 INSERT @R(Test,Passed,Detail) VALUES(N'T17 pending request belongs to A1 now',CASE WHEN dbo.fn_Emp_CurrentApprover(@Cmp,@AID)=@A1 THEN 1 ELSE 0 END,N'');
 -- and the delegate sees it too while the delegation is active
 INSERT @R(Test,Passed,Detail) VALUES(N'T17b delegate is recognised',CASE WHEN dbo.fn_Emp_IsDelegate(@Cmp,@A1,@Del,100,@Today)=1 THEN 1 ELSE 0 END,N'');

 /* T18 notifications read cycle */
 SELECT @Cnt=COUNT(*) FROM dbo.Emp_Notifications WHERE CmpID=@Cmp AND UserID=@A1 AND IsRead=0 AND ProcessType=100;
 INSERT @R(Test,Passed,Detail) VALUES(N'T18a A1 has unread notifications',CASE WHEN @Cnt>0 THEN 1 ELSE 0 END,CONCAT(N'unread=',@Cnt));
 SELECT TOP(1) @Tmp=NotifID FROM dbo.Emp_Notifications WHERE CmpID=@Cmp AND UserID=@A1 AND IsRead=0 AND ProcessType=100 ORDER BY NotifID;
 EXEC dbo.Emp_MarkNotificationsRead @CmpID=@Cmp,@UserID=@A1,@NotifID=@Tmp;
 INSERT @R(Test,Passed,Detail) SELECT N'T18b Emp_MarkNotificationsRead marks the chosen one',CASE WHEN IsRead=1 AND ReadAt IS NOT NULL THEN 1 ELSE 0 END,CONCAT(N'isRead=',IsRead) FROM dbo.Emp_Notifications WHERE NotifID=@Tmp;

 /* T19 route-step validation (Emp_SaveApprovalRouteStep) */
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@Cmp,@ProcessType=101,@StepNo=1,@ApproverID=@A1,@RecordState=0,@UserID=@A1,@ApproverKind=1,@LevelsUp=1; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T19a manager step with a fixed approver is refused (54752)',CASE WHEN @E=54752 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@Cmp,@ProcessType=101,@StepNo=1,@ApproverID=@A1,@RecordState=0,@UserID=@A1,@ApproverKind=0,@LevelsUp=2; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T19b fixed step with a level is refused (54751)',CASE WHEN @E=54751 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));
 SET @E=NULL; BEGIN TRY EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@Cmp,@ProcessType=101,@StepNo=1,@ApproverID=@A1,@RecordState=0,@UserID=@A1,@ApproverKind=7,@LevelsUp=NULL; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
 INSERT @R(Test,Passed,Detail) VALUES(N'T19c unknown approver kind is refused (54750)',CASE WHEN @E=54750 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));

 /* T20 snapshot: the approvers were fixed when request 100 started */
 SELECT @Cnt=COUNT(*) FROM dbo.Emp_ApprovalStepSnapshots WHERE CmpID=@Cmp AND ApprovalID=@AID;
 INSERT @R(Test,Passed,Detail) VALUES(N'T20 start wrote one snapshot row per active step (2)',CASE WHEN @Cnt=2 THEN 1 ELSE 0 END,CONCAT(N'rows=',@Cnt));

 /* T21 OPTIONAL: manager route (needs an employee that has a direct manager) */
 IF @EmpWithManager IS NOT NULL
 BEGIN
  DECLARE @Mgr BIGINT=dbo.fn_Emp_GetDirectManager(@Cmp,@EmpWithManager,@Today);
  EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@Cmp,@ProcessType=101,@StepNo=1,@ApproverID=NULL,@RecordState=0,@UserID=@A1,@ApproverKind=1,@LevelsUp=1;
  INSERT @R(Test,Passed,Detail) SELECT N'T21a manager step saved with Kind=1 / LevelsUp=1',CASE WHEN ApproverKind=1 AND LevelsUp=1 AND ApproverID IS NULL THEN 1 ELSE 0 END,N'' FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@Cmp AND ProcessType=101 AND StepNo=1;
  INSERT @R(Test,Passed,Detail) VALUES(N'T21b fn_Emp_ResolveRouteApprover = fn_Emp_GetDirectManager',CASE WHEN ISNULL(dbo.fn_Emp_ResolveRouteApprover(@Cmp,101,1,@EmpWithManager,@Today),0)=ISNULL(@Mgr,0) THEN 1 ELSE 0 END,CONCAT(N'manager=',@Mgr));
  /* process type 101 has no subject mapping in fn_Emp_ApprovalSubject, so the engine must refuse to start (54754) rather than guess */
  SET @E=NULL;
  BEGIN TRY EXEC dbo.Emp_StartApproval @CmpID=@Cmp,@ProcessType=101,@EntityID=@Ent,@SubmittedBy=@Sub,@SuppressResult=1; END TRY BEGIN CATCH SET @E=ERROR_NUMBER(); END CATCH;
  INSERT @R(Test,Passed,Detail) VALUES(N'T21c manager step without a resolvable subject is refused (54754)',CASE WHEN @E=54754 THEN 1 ELSE 0 END,CONCAT(N'error=',@E));
 END;
END TRY
BEGIN CATCH
 INSERT @R(Test,Passed,Detail) VALUES(N'ABORTED',0,CONCAT(N'error ',ERROR_NUMBER(),N': ',ERROR_MESSAGE()));
END CATCH;

/* ---------------- cleanup (only what the tests created) ---------------- */
IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
IF NOT EXISTS(SELECT 1 FROM @R WHERE Test=N'ABORTED' AND Detail LIKE N'error 5900%')
BEGIN
 BEGIN TRY
  ALTER TABLE dbo.Emp_ApprovalEvents DISABLE TRIGGER TR_Emp_ApprovalEvents_AppendOnly;
  ALTER TABLE dbo.Emp_ApprovalReassignments DISABLE TRIGGER TR_Emp_ApprovalReassignments_AppendOnly;
  DELETE FROM dbo.Emp_ApprovalReassignments WHERE ApprovalID IN(SELECT ApprovalID FROM dbo.Emp_ApprovalRequests WHERE ProcessType IN(100,101));
  DELETE FROM dbo.Emp_ApprovalStepSnapshots WHERE ApprovalID IN(SELECT ApprovalID FROM dbo.Emp_ApprovalRequests WHERE ProcessType IN(100,101));
  DELETE FROM dbo.Emp_ApprovalEvents WHERE ProcessType IN(100,101);
  DELETE FROM dbo.Emp_ApprovalRequests WHERE ProcessType IN(100,101);
  DELETE FROM dbo.Emp_ApprovalRouteSteps WHERE ProcessType IN(100,101);
  DELETE FROM dbo.Emp_Notifications WHERE ProcessType IN(100,101) OR (ProcessType IS NULL AND NotifType=8 AND UserID=@Del AND CreatedAt>=@Start AND Title=N'تم تفويضك بصلاحيات اعتماد');
  DELETE FROM dbo.Emp_ApprovalDelegations WHERE DelegationID IN(SELECT DelegationID FROM @D);
 END TRY
 BEGIN CATCH
  INSERT @R(Test,Passed,Detail) VALUES(N'CLEANUP FAILED',0,CONCAT(N'error ',ERROR_NUMBER(),N': ',ERROR_MESSAGE()));
 END CATCH;
 ALTER TABLE dbo.Emp_ApprovalEvents ENABLE TRIGGER TR_Emp_ApprovalEvents_AppendOnly;
 ALTER TABLE dbo.Emp_ApprovalReassignments ENABLE TRIGGER TR_Emp_ApprovalReassignments_AppendOnly;
END;

SELECT Seq,Test,Passed,Detail FROM @R ORDER BY Seq;
SELECT SUM(CASE WHEN Passed=1 THEN 1 ELSE 0 END) AS PassedCount,SUM(CASE WHEN Passed=0 THEN 1 ELSE 0 END) AS FailedCount FROM @R;
GO

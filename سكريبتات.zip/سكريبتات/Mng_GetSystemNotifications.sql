USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* 1) عمود جديد: هل يدخل هذا الإشعار في عدّاد الشارة (الجرس)؟
      الأصل: كل الحالات تدخل ما عدا المؤرشف (7). عدّل القيم من الجدول لاحقًا حسب رغبتك. */
IF COL_LENGTH(N'dbo.Mng_Notifications', N'NafBadge') IS NULL
BEGIN
    ALTER TABLE dbo.Mng_Notifications
        ADD NafBadge BIT NOT NULL
        CONSTRAINT DF_Mng_Notifications_NafBadge DEFAULT (1);
END;
GO
UPDATE dbo.Mng_Notifications SET NafBadge = 0 WHERE NafSystem = 1 AND NafStateID = 7;
GO

/* 2) الإجراء: نفس معاملاتك، مع إضافة NafStateID وNafBadge،
      وحصر المؤقت (0) في قيود المستخدم نفسه فقط. */
CREATE OR ALTER PROCEDURE [dbo].[Mng_GetSystemNotifications]
    @Company INT,
    @System  TINYINT,
    @User    BIGINT,
    @Year    INT
AS
BEGIN
    SET NOCOUNT ON;

    -- منظومة الحسابات
    IF @System = 1
    BEGIN
        DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
                @To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);

        ;WITH Counts AS
        (
            SELECT
                DayMState,
                COUNT(*) AS DayCount
            FROM dbo.Acc_DayMaster
            WHERE DayMCompany = @Company
              AND DayMDate >= @From
              AND DayMDate <  @To
              -- المسودات خاصة بصاحبها فقط
              AND (DayMState <> 0 OR DayMUser = @User)
            GROUP BY DayMState
        )
        SELECT
            N.NafStateID,
            N.NafName AS NafState,
            ISNULL(C.DayCount, 0) AS NafCount,
            N.NafPage,
            N.NafBadge
        FROM dbo.Mng_Notifications AS N
        LEFT JOIN Counts AS C
            ON C.DayMState = N.NafStateID
        WHERE N.NafSystem = @System
          AND N.NafActive = 1
        ORDER BY N.NafStateID;

        RETURN;
    END;

    -- باقي المنظومات: تُضاف هنا، وإلى ذلك يُعاد جدول فارغ بنفس الأعمدة
    SELECT
        CAST(NULL AS TINYINT)       AS NafStateID,
        CAST(NULL AS NVARCHAR(200)) AS NafState,
        CAST(0 AS INT)              AS NafCount,
        CAST(NULL AS NVARCHAR(260)) AS NafPage,
        CAST(0 AS BIT)              AS NafBadge
    WHERE 1 = 0;
END;
GO

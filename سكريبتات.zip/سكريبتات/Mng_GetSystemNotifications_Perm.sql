/* =====================================================================
   Mng_GetSystemNotifications — نسختك مع ربط العدّاد بصلاحيات القوائم
   ---------------------------------------------------------------------
   الجديد فقط: لا يظهر الإشعار إلا إذا كان المستخدم يملك قائمة تلك الحالة
   (نفس دالة Acc_UserCanAct التي تتحقق منها صفحة القائمة)، فلا يضغط أحد
   إشعارًا ثم يُرفض بالخطأ 50402. كل ما عدا ذلك كما كتبته أنت.
   يتطلب تنفيذ Acc_ChangeDayVoucherState.sql أولًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

ALTER PROCEDURE [dbo].[Mng_GetSystemNotifications]
    @Company INT,
    @System  TINYINT,
    @User    BIGINT,
    @Year    INT
AS
BEGIN
    SET NOCOUNT ON;

    -- منظومة الحسابات
    IF @System = 1
    BEGIN
        DECLARE @From DATE = DATEFROMPARTS(@Year, 1, 1),
                @To   DATE = DATEFROMPARTS(@Year + 1, 1, 1);

        ;WITH Counts AS
        (
            SELECT
                DayMState,
                COUNT(*) AS DayCount
            FROM dbo.Acc_DayMaster
            WHERE DayMCompany = @Company
              AND DayMDate >= @From
              AND DayMDate <  @To
              -- المسودات خاصة بصاحبها فقط
              AND (DayMState <> 0 OR DayMUser = @User)
            GROUP BY DayMState
        )
        SELECT
            N.NafStateID,
            N.NafName AS NafState,
            C.DayCount AS NafCount,
            N.NafPage,
            N.NafBadge
        FROM dbo.Mng_Notifications AS N
        JOIN Counts AS C
            ON C.DayMState = N.NafStateID
        CROSS APPLY dbo.Acc_UserCanAct(@Company, @User, N.NafStateID) AS U
        WHERE N.NafSystem = @System
          AND N.NafActive = 1
          AND C.DayCount > 0
          AND U.Allowed = 1          -- يملك قائمة الحالة
        ORDER BY N.NafStateID;

        RETURN;
    END;

    -- باقي المنظومات: تُضاف هنا، وإلى ذلك يُعاد جدول فارغ بنفس الأعمدة
    SELECT
        CAST(NULL AS TINYINT)       AS NafStateID,
        CAST(NULL AS NVARCHAR(200)) AS NafState,
        CAST(0 AS INT)              AS NafCount,
        CAST(NULL AS NVARCHAR(260)) AS NafPage,
        CAST(0 AS BIT)              AS NafBadge
    WHERE 1 = 0;
END;
GO

/* ---------------------------------------------------------------------
   رابط كل إشعار يفتح قائمته (يحدّث الصفوف الموجودة فقط ولا يضيف شيئًا) */
UPDATE dbo.Mng_Notifications
   SET NafPage = N'~/Accounting/Acc_DayReviewList.aspx?State=' + CONVERT(NVARCHAR(3), NafStateID)
 WHERE NafSystem = 1 AND NafStateID BETWEEN 0 AND 7;
GO

/* افحص الصفوف: يجب أن تظهر 8 حالات (0..7) بروابطها */
SELECT NafStateID, NafName, NafPage, NafActive, NafBadge
FROM dbo.Mng_Notifications WHERE NafSystem = 1 ORDER BY NafStateID;
GO

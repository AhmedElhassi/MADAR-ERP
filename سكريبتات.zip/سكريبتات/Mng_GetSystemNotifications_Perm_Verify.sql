/* اختبار للقراءة فقط (لا يكتب شيئًا): الإشعارات = الحالات التي يملك المستخدم قائمتها وفيها قيود.
   غيّر @Cmp/@Year/@U إن لزم. المستخدم الثاني يفضَّل أن يكون محدود الصلاحيات. */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @Cmp INT = 10, @Year INT = YEAR(GETDATE());

IF OBJECT_ID(N'dbo.Acc_UserCanAct') IS NULL THROW 50900, N'نفّذ Acc_ChangeDayVoucherState.sql أولًا', 1;

CREATE TABLE #R (Nm NVARCHAR(20), Res NVARCHAR(4000), Ok BIT);
DECLARE @U BIGINT;
DECLARE cu CURSOR LOCAL FAST_FORWARD FOR
    SELECT DISTINCT USPUserID FROM dbo.Mng_UserParmations WHERE USPCompanyID = @Cmp AND USPSystemID = 1 AND USPState = 0;
OPEN cu; FETCH NEXT FROM cu INTO @U;
WHILE @@FETCH_STATUS = 0
BEGIN
    CREATE TABLE #N (NafStateID TINYINT, NafState NVARCHAR(200), NafCount INT, NafPage NVARCHAR(260), NafBadge BIT);
    INSERT #N EXEC dbo.Mng_GetSystemNotifications @Cmp, 1, @U, @Year;

    DECLARE @From DATE = DATEFROMPARTS(@Year,1,1), @To DATE = DATEFROMPARTS(@Year+1,1,1);
    DECLARE @Bad INT = 0;

    -- 1) كل صف راجع: المستخدم يملك قائمته وعدّه صحيح
    SELECT @Bad = COUNT(*) FROM #N n
    WHERE (SELECT Allowed FROM dbo.Acc_UserCanAct(@Cmp, @U, n.NafStateID)) <> 1
       OR n.NafCount <> (SELECT COUNT(*) FROM dbo.Acc_DayMaster m
                         WHERE m.DayMCompany = @Cmp AND m.DayMState = n.NafStateID
                           AND m.DayMDate >= @From AND m.DayMDate < @To
                           AND (m.DayMState <> 0 OR m.DayMUser = @U));
    INSERT #R VALUES (CONCAT(N'U', @U, N'-A'), N'الصفوف صحيحة وبصلاحية', CASE WHEN @Bad = 0 THEN 1 ELSE 0 END);

    -- 2) لا حالة مسموحة وفيها قيود ولها إشعار فعّال غابت
    SELECT @Bad = COUNT(*)
    FROM dbo.Mng_Notifications nf
    WHERE nf.NafSystem = 1 AND nf.NafActive = 1
      AND (SELECT Allowed FROM dbo.Acc_UserCanAct(@Cmp, @U, nf.NafStateID)) = 1
      AND EXISTS (SELECT 1 FROM dbo.Acc_DayMaster m
                  WHERE m.DayMCompany = @Cmp AND m.DayMState = nf.NafStateID
                    AND m.DayMDate >= @From AND m.DayMDate < @To
                    AND (m.DayMState <> 0 OR m.DayMUser = @U))
      AND NOT EXISTS (SELECT 1 FROM #N n WHERE n.NafStateID = nf.NafStateID);
    INSERT #R VALUES (CONCAT(N'U', @U, N'-B'), N'لا إشعار ناقص', CASE WHEN @Bad = 0 THEN 1 ELSE 0 END);

    DROP TABLE #N;
    FETCH NEXT FROM cu INTO @U;
END
CLOSE cu; DEALLOCATE cu;

SELECT Nm, CASE Ok WHEN 1 THEN N'PASS' ELSE N'FAIL' END AS Result, Res FROM #R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM #R;
DROP TABLE #R;

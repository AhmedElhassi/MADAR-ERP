/* =====================================================================
   MADAR ERP - Phase 3 / Batch 1 : Dynamic approval route (direct manager chain)
   Reference : MADARDATABASE_FIXED.sql (MADARERPDataBase)
   Status    : STATIC REVIEW ONLY - not executed on SQL Server (none available in the authoring environment).

   WHY (gap proven from the reference definitions):
     * Emp_ApprovalRouteSteps.ApproverID is NOT NULL: every step is a fixed user.
     * Emp_ApprovalRequests has no subject-employee column, so the engine cannot know whose manager should approve.
     * Emp_DecideApprovalStep only checks ApproverID = the step's fixed user; no hierarchy validation.

   NEW OBJECTS
     Columns : Emp_ApprovalRouteSteps.ApproverKind, .LevelsUp ; Emp_ApprovalRequests.SubjectEmpID
     Constraints/Indexes : CK_Emp_ApprovalRouteSteps_Kind, FK_Emp_ApprovalRequests_Subject, IX_Emp_ApprovalRequests_Subject
     Functions : fn_Emp_ApprovalSubject, fn_Emp_GetManagerAtLevel, fn_Emp_ResolveRouteApprover
   MODIFIED (CREATE OR ALTER, same signatures; new params appended with defaults)
     Emp_SaveApprovalRouteStep  (+@ApproverKind,+@LevelsUp ; @ApproverID now defaults NULL)
     Emp_StartApproval          (+records subject, validates dynamic steps are resolvable)
     Emp_DecideApprovalStep     (+resolves approver dynamically, +blocks subject approving own request)
     Emp_SelectApprovalRoute    (INNER->LEFT JOIN on Mng_User; +ApproverKind, +LevelsUp appended last)
   UNCHANGED: all state codes, ProcessType numbers, Decision domain (1,2), THROW numbers already in use.
   Behavior change to note: a request's subject employee can no longer approve their own request
     (previously only SubmittedBy was blocked).
   New THROW numbers: 54750-54756 (unused in the reference).
   Dependencies order: this file requires only objects already in the reference file.
   ===================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* ---- 1. Route steps: approver kind ------------------------------------------------------- */
IF COL_LENGTH(N'dbo.Emp_ApprovalRouteSteps',N'ApproverKind') IS NULL
    ALTER TABLE dbo.Emp_ApprovalRouteSteps ADD ApproverKind TINYINT NOT NULL
        CONSTRAINT DF_Emp_ApprovalRouteSteps_Kind DEFAULT(0);   -- 0 = fixed user (existing behavior), 1 = manager N levels above the request's employee
IF COL_LENGTH(N'dbo.Emp_ApprovalRouteSteps',N'LevelsUp') IS NULL
    ALTER TABLE dbo.Emp_ApprovalRouteSteps ADD LevelsUp TINYINT NULL;
GO
IF EXISTS(SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.Emp_ApprovalRouteSteps') AND name=N'ApproverID' AND is_nullable=0)
    ALTER TABLE dbo.Emp_ApprovalRouteSteps ALTER COLUMN ApproverID BIGINT NULL;
GO
IF OBJECT_ID(N'dbo.CK_Emp_ApprovalRouteSteps_Kind',N'C') IS NULL
    ALTER TABLE dbo.Emp_ApprovalRouteSteps WITH CHECK ADD CONSTRAINT CK_Emp_ApprovalRouteSteps_Kind CHECK(
        (ApproverKind=0 AND ApproverID IS NOT NULL AND LevelsUp IS NULL)
     OR (ApproverKind=1 AND ApproverID IS NULL AND LevelsUp BETWEEN 1 AND 5 AND ProcessType NOT IN(7,8,9)));
GO

/* ---- 2. Requests: subject employee ------------------------------------------------------- */
IF COL_LENGTH(N'dbo.Emp_ApprovalRequests',N'SubjectEmpID') IS NULL
    ALTER TABLE dbo.Emp_ApprovalRequests ADD SubjectEmpID BIGINT NULL;
GO

/* ProcessType -> subject employee. 7 (offers), 8 (requisitions), 9 (pay runs) have no employee subject. */
CREATE OR ALTER FUNCTION dbo.fn_Emp_ApprovalSubject(@CmpID INT,@ProcessType TINYINT,@EntityID BIGINT)
RETURNS BIGINT
AS
BEGIN
    RETURN CASE @ProcessType
        WHEN 1  THEN (SELECT EmployeeID FROM dbo.Emp_LeaveRequests WHERE CmpID=@CmpID AND RequestID=@EntityID)
        WHEN 2  THEN (SELECT EmployeeID FROM dbo.Emp_OvertimeRequests WHERE CmpID=@CmpID AND OvertimeID=@EntityID)
        WHEN 3  THEN (SELECT EmployeeID FROM dbo.Emp_RewardsPenalties WHERE CmpID=@CmpID AND ActionID=@EntityID)
        WHEN 4  THEN (SELECT EmployeeID FROM dbo.Emp_Loans WHERE CmpID=@CmpID AND LoanID=@EntityID)
        WHEN 5  THEN (SELECT EmployeeID FROM dbo.Emp_Terminations WHERE CmpID=@CmpID AND TerminationID=@EntityID)
        WHEN 6  THEN (SELECT EmployeeID FROM dbo.Emp_Terminations WHERE CmpID=@CmpID AND TerminationID=@EntityID)   -- final settlement: EntityID = TerminationID
        WHEN 10 THEN (SELECT d.AttDayEmpID FROM dbo.Emp_AttendanceAdjustments a
                      JOIN dbo.Emp_AttendanceDaily d ON d.AttDayCmp=a.AttAdjCmp AND d.AttDayID=a.AttAdjAttDayID
                      WHERE a.AttAdjCmp=@CmpID AND a.AttAdjID=@EntityID)
        WHEN 11 THEN (SELECT EmployeeID FROM dbo.Emp_SalaryAdvances WHERE CmpID=@CmpID AND AdvanceID=@EntityID)
        WHEN 12 THEN (SELECT EmployeeID FROM dbo.Emp_EmployeeExternalDeductions WHERE CmpID=@CmpID AND DeductionID=@EntityID)
        WHEN 13 THEN (SELECT RequesterID FROM dbo.Emp_ShiftSwapRequests WHERE CmpID=@CmpID AND SwapID=@EntityID)
        ELSE NULL END;
END;
GO

/* Backfill subject for requests created before this change (no history is altered besides this new column). */
UPDATE r SET SubjectEmpID=dbo.fn_Emp_ApprovalSubject(r.CmpID,r.ProcessType,r.EntityID)
FROM dbo.Emp_ApprovalRequests r
WHERE r.SubjectEmpID IS NULL AND r.ProcessType NOT IN(7,8,9);
GO
IF OBJECT_ID(N'dbo.FK_Emp_ApprovalRequests_Subject',N'F') IS NULL
    ALTER TABLE dbo.Emp_ApprovalRequests WITH CHECK ADD CONSTRAINT FK_Emp_ApprovalRequests_Subject
        FOREIGN KEY(CmpID,SubjectEmpID) REFERENCES dbo.Emp_Employee(EmpCompany,EmpID);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.Emp_ApprovalRequests') AND name=N'IX_Emp_ApprovalRequests_Subject')
    CREATE INDEX IX_Emp_ApprovalRequests_Subject ON dbo.Emp_ApprovalRequests(CmpID,SubjectEmpID,ApprovalState) INCLUDE(ProcessType,EntityID,CurrentStep);
GO

/* ---- 3. Hierarchy resolution -------------------------------------------------------------- */
/* Manager N levels up using the existing fn_Emp_GetDirectManager (unit head, climbing to parent units). NULL if the chain ends or loops. */
CREATE OR ALTER FUNCTION dbo.fn_Emp_GetManagerAtLevel(@CmpID INT,@EmpID BIGINT,@Levels TINYINT,@AsOf DATE)
RETURNS BIGINT
AS
BEGIN
    DECLARE @Cur BIGINT=@EmpID,@I TINYINT=0;
    WHILE @I<@Levels
    BEGIN
        SET @Cur=dbo.fn_Emp_GetDirectManager(@CmpID,@Cur,@AsOf);
        IF @Cur IS NULL OR @Cur=@EmpID RETURN NULL;
        SET @I+=1;
    END;
    RETURN @Cur;
END;
GO

/* Approver expected for one route step. Kind 0: the fixed user. Kind 1: the manager chain of the request's employee; must be an active user of the company. */
CREATE OR ALTER FUNCTION dbo.fn_Emp_ResolveRouteApprover(@CmpID INT,@ProcessType TINYINT,@StepNo SMALLINT,@SubjectEmpID BIGINT,@AsOf DATE)
RETURNS BIGINT
AS
BEGIN
    DECLARE @Kind TINYINT,@Fixed BIGINT,@Lv TINYINT,@R BIGINT;
    SELECT @Kind=ApproverKind,@Fixed=ApproverID,@Lv=LevelsUp
    FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo AND RecordState=0;
    IF @Kind IS NULL RETURN NULL;
    IF @Kind=0 RETURN @Fixed;
    IF @SubjectEmpID IS NULL RETURN NULL;
    SET @R=dbo.fn_Emp_GetManagerAtLevel(@CmpID,@SubjectEmpID,@Lv,@AsOf);
    IF @R IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@R AND UsrCompany=@CmpID AND UsrState=0) SET @R=NULL;
    RETURN @R;
END;
GO

/* ---- 4. Route configuration (modified; backward compatible) ------------------------------- */
CREATE OR ALTER PROCEDURE dbo.Emp_SaveApprovalRouteStep
 @CmpID INT,@ProcessType TINYINT,@StepNo SMALLINT,@ApproverID BIGINT=NULL,@RecordState TINYINT=0,@UserID BIGINT,
 @ApproverKind TINYINT=0,@LevelsUp TINYINT=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @ProcessType IS NULL OR @ProcessType=0 OR @StepNo IS NULL OR @StepNo<=0 OR @RecordState NOT IN(0,1) THROW 54700,N'نوع العملية أو مرحلة الموافقة غير صحيحة.',1;
 IF @ApproverKind IS NULL OR @ApproverKind NOT IN(0,1) THROW 54750,N'نوع المعتمد غير صحيح.',1;
 IF @ApproverKind=0
 BEGIN
  IF @LevelsUp IS NOT NULL THROW 54752,N'عدد المستويات يخص المعتمد من التسلسل الإداري فقط.',1;
  IF NOT EXISTS(SELECT 1 FROM dbo.Mng_User WHERE UsrID=@ApproverID AND UsrCompany=@CmpID AND UsrState=0) THROW 54701,N'المعتمد غير نشط أو لا يتبع للشركة.',1;
 END
 ELSE
 BEGIN
  IF @ProcessType IN(7,8,9) THROW 54751,N'المعتمد من التسلسل الإداري غير مدعوم لهذه العملية لعدم ارتباطها بموظف محدد.',1;
  IF @LevelsUp IS NULL OR @LevelsUp NOT BETWEEN 1 AND 5 THROW 54752,N'عدد مستويات التسلسل الإداري يجب أن يكون بين 1 و5.',1;
  SET @ApproverID=NULL;
 END;
 BEGIN TRY
  BEGIN TRANSACTION;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND ApprovalState=0 AND CurrentStep>=@StepNo) THROW 54702,N'لا يمكن تغيير مرحلة مستخدمة في مسار موافقة جارٍ.',1;
  DECLARE @MaxActiveStep SMALLINT=(SELECT MAX(StepNo) FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0),@CurrentRouteState TINYINT;
  SELECT @CurrentRouteState=RecordState FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo;
  IF ISNULL(@CurrentRouteState,1)=1 AND @RecordState=0 AND @StepNo>ISNULL(@MaxActiveStep,0)+1 THROW 54711,N'أضف مراحل الموافقة بالتتابع دون فجوات.',1;
  IF @RecordState=1 AND EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0 AND StepNo>@StepNo) THROW 54712,N'عطّل المراحل من الأخيرة إلى الأولى للحفاظ على تسلسل المسار.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo)
   UPDATE dbo.Emp_ApprovalRouteSteps SET ApproverID=@ApproverID,ApproverKind=@ApproverKind,LevelsUp=@LevelsUp,RecordState=@RecordState WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND StepNo=@StepNo;
  ELSE INSERT dbo.Emp_ApprovalRouteSteps(CmpID,ProcessType,StepNo,ApproverID,ApproverKind,LevelsUp,RecordState,CreatedBy) VALUES(@CmpID,@ProcessType,@StepNo,@ApproverID,@ApproverKind,@LevelsUp,@RecordState,@UserID);
  COMMIT TRANSACTION;
  SELECT @ProcessType AS ProcessType,@StepNo AS StepNo;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* ---- 5. Start (modified: records subject; refuses a route that cannot be resolved) -------- */
CREATE OR ALTER PROCEDURE dbo.Emp_StartApproval
 @CmpID INT,@ProcessType TINYINT,@EntityID BIGINT,@SubmittedBy BIGINT,@SuppressResult BIT=0
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@SubmittedBy;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @FirstStep SMALLINT,@StepCount INT,@MaxStep SMALLINT,@ApprovalID BIGINT,@ExistingState TINYINT,@ExistingSubmitter BIGINT,
          @Subject BIGINT=dbo.fn_Emp_ApprovalSubject(@CmpID,@ProcessType,@EntityID),@Today DATE=CONVERT(date,SYSDATETIME());
  SELECT @FirstStep=MIN(StepNo),@MaxStep=MAX(StepNo),@StepCount=COUNT(*) FROM dbo.Emp_ApprovalRouteSteps WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0;
  IF @FirstStep IS NULL THROW 54703,N'مسار الموافقات غير مهيأ لهذه الشركة والعملية.',1;
  IF @FirstStep<>1 OR @StepCount<>@MaxStep THROW 54704,N'أرقام مراحل مسار الموافقة يجب أن تكون متصلة ابتداءً من المرحلة الأولى.',1;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0 AND ApproverKind=1)
  BEGIN
   IF @Subject IS NULL THROW 54754,N'تعذر تحديد الموظف صاحب الطلب لاشتقاق المعتمد من التسلسل الإداري.',1;
   IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps s WHERE s.CmpID=@CmpID AND s.ProcessType=@ProcessType AND s.RecordState=0 AND s.ApproverKind=1
             AND dbo.fn_Emp_ResolveRouteApprover(@CmpID,@ProcessType,s.StepNo,@Subject,@Today) IS NULL)
    THROW 54755,N'لا يوجد مدير نشط في التسلسل الإداري لإحدى مراحل الموافقة؛ حدّد رئيس الوحدة التنظيمية أو عدّل المسار.',1;
  END;
  SELECT @ApprovalID=ApprovalID,@ExistingState=ApprovalState,@ExistingSubmitter=SubmittedBy FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID;
  IF @ApprovalID IS NULL
  BEGIN
   INSERT dbo.Emp_ApprovalRequests(CmpID,ProcessType,EntityID,CurrentStep,ApprovalState,SubmittedBy,SubjectEmpID) VALUES(@CmpID,@ProcessType,@EntityID,1,0,@SubmittedBy,@Subject);
   SET @ApprovalID=SCOPE_IDENTITY();
  END
  ELSE IF @ExistingState=2
   UPDATE dbo.Emp_ApprovalRequests SET CurrentStep=1,ApprovalState=0,AttemptNo=AttemptNo+1,SubmittedBy=@SubmittedBy,SubjectEmpID=@Subject,CreatedAt=SYSDATETIME(),CompletedAt=NULL,CompletedBy=NULL WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  ELSE IF @ExistingState<>0 OR @ExistingSubmitter<>@SubmittedBy THROW 54705,N'طلب الموافقة قائم أو مكتمل مسبقاً أو لا يخص مقدم الطلب.',1;
  COMMIT TRANSACTION;
  IF @SuppressResult=0 SELECT ApprovalID,CurrentStep,ApprovalState FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* ---- 6. Decide (modified: dynamic approver + subject conflict-of-interest) ---------------- */
CREATE OR ALTER PROCEDURE dbo.Emp_DecideApprovalStep
 @CmpID INT,@ProcessType TINYINT,@EntityID BIGINT,@StepNo SMALLINT,@ApproverID BIGINT,@Decision TINYINT,@Comments NVARCHAR(1000)=NULL,
 @ApprovalState TINYINT OUTPUT,@NextStep SMALLINT OUTPUT,@SuppressResult BIT=0
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@ApproverID;
 IF @Decision NOT IN(1,2) OR @StepNo<=0 THROW 54706,N'قرار الموافقة أو المرحلة غير صحيح.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @ApprovalID BIGINT,@CurrentStep SMALLINT,@State TINYINT,@SubmittedBy BIGINT,@Subject BIGINT,@ExpectedApprover BIGINT,@Next SMALLINT,@AttemptNo SMALLINT;
  SELECT @ApprovalID=ApprovalID,@CurrentStep=CurrentStep,@State=ApprovalState,@AttemptNo=AttemptNo,@SubmittedBy=SubmittedBy,@Subject=SubjectEmpID FROM dbo.Emp_ApprovalRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND EntityID=@EntityID;
  IF @ApprovalID IS NULL OR @State<>0 OR @CurrentStep<>@StepNo THROW 54707,N'طلب الموافقة غير قائم أو المرحلة الحالية مختلفة.',1;
  IF @SubmittedBy=@ApproverID THROW 54708,N'لا يجوز لمقدم الطلب اعتماد طلبه.',1;
  IF @Subject IS NULL AND @ProcessType NOT IN(7,8,9) SET @Subject=dbo.fn_Emp_ApprovalSubject(@CmpID,@ProcessType,@EntityID);
  IF @Subject IS NOT NULL AND @Subject=@ApproverID THROW 54756,N'لا يجوز لصاحب الطلب اعتماد طلبه.',1;
  SET @ExpectedApprover=dbo.fn_Emp_ResolveRouteApprover(@CmpID,@ProcessType,@StepNo,@Subject,CONVERT(date,SYSDATETIME()));
  IF @ExpectedApprover IS NULL THROW 54753,N'تعذر تحديد المعتمد لهذه المرحلة من التسلسل الإداري الحالي.',1;
  IF @ExpectedApprover<>@ApproverID THROW 54709,N'المستخدم ليس المعتمد المحدد لهذه المرحلة.',1;
  INSERT dbo.Emp_ApprovalEvents(CmpID,ApprovalID,ProcessType,EntityID,StepNo,AttemptNo,ApproverID,Decision,Comments) VALUES(@CmpID,@ApprovalID,@ProcessType,@EntityID,@StepNo,@AttemptNo,@ApproverID,@Decision,@Comments);
  IF @Decision=2
   UPDATE dbo.Emp_ApprovalRequests SET ApprovalState=2,CompletedAt=SYSDATETIME(),CompletedBy=@ApproverID WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  ELSE
  BEGIN
   SELECT @Next=MIN(StepNo) FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=@ProcessType AND RecordState=0 AND StepNo>@StepNo;
   IF @Next IS NULL UPDATE dbo.Emp_ApprovalRequests SET ApprovalState=1,CompletedAt=SYSDATETIME(),CompletedBy=@ApproverID WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
   ELSE UPDATE dbo.Emp_ApprovalRequests SET CurrentStep=@Next WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  END;
  SELECT @ApprovalState=ApprovalState,@NextStep=CurrentStep FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ApprovalID=@ApprovalID;
  COMMIT TRANSACTION;
  IF @SuppressResult=0 SELECT @ApprovalID AS ApprovalID,@ApprovalState AS ApprovalState,@NextStep AS NextStep;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* ---- 7. Route display (modified: dynamic steps have no fixed user) ------------------------ */
CREATE OR ALTER PROCEDURE dbo.Emp_SelectApprovalRoute @CmpID INT,@ProcessType TINYINT
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.ProcessType,r.StepNo,r.ApproverID,u.UsrLogIn,CONCAT(e.EmpName,N'') AS ApproverName,r.RecordState,r.CreatedAt,r.CreatedBy,r.ApproverKind,r.LevelsUp
 FROM dbo.Emp_ApprovalRouteSteps r LEFT JOIN dbo.Mng_User u ON u.UsrID=r.ApproverID LEFT JOIN dbo.Emp_Employee e ON e.EmpCompany=r.CmpID AND e.EmpID=r.ApproverID
 WHERE r.CmpID=@CmpID AND r.ProcessType=@ProcessType ORDER BY r.StepNo;
END;
GO

/* =====================================================================
   MADAR ERP - Phase 3 / Batch 1b : Defect fix in an EXISTING procedure
   Object  : dbo.Emp_DecideOvertimeRequest  (reference file line 33821)
   Defect  : the procedure uses @RouteDecision (SET and as an argument of Emp_DecideApprovalStep) but never
             declares it. SQL Server rejects such a procedure at CREATE time (Msg 137), so on a database built
             from the reference file the older definition (reference line 18335, which bypasses the approval
             engine for overtime) would remain in force.
   Change  : ONLY the DECLARE line gains ",@RouteDecision TINYINT". Everything else is copied verbatim.
   Status  : static review only - not executed on SQL Server.
   Run after: P3_B1_01_DynamicApprovalRoute.sql (it calls Emp_DecideApprovalStep).
   ===================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_DecideOvertimeRequest
 @CmpID INT,@OvertimeID BIGINT,@ApproverID BIGINT,@Approve BIT,@StepNo SMALLINT=1,@Comments NVARCHAR(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@ApproverID;
 IF @Approve IS NULL THROW 54454,N'قرار اعتماد الإضافي مطلوب.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @EmployeeID BIGINT,@WorkDate DATE,@Hours DECIMAL(8,2),@CreatorID BIGINT,@ActualOvertime INT,@ApprovalResult TINYINT,@NextApproval SMALLINT,@RouteDecision TINYINT;
  SELECT @EmployeeID=EmployeeID,@WorkDate=WorkDate,@Hours=Hours,@CreatorID=CreatedBy
  FROM dbo.Emp_OvertimeRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID AND RequestState=0;
  IF @EmployeeID IS NULL THROW 54455,N'طلب الإضافي غير موجود أو سبق البت فيه.',1;
  IF @CreatorID=@ApproverID THROW 54456,N'لا يجوز لمنشئ طلب الإضافي اعتماده.',1;
  SET @RouteDecision=CASE WHEN @Approve=1 THEN 1 ELSE 2 END;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ProcessType=2 AND EntityID=@OvertimeID)
  BEGIN
   EXEC dbo.Emp_DecideApprovalStep @CmpID,2,@OvertimeID,@StepNo,@ApproverID,@RouteDecision,@Comments,@ApprovalResult OUTPUT,@NextApproval OUTPUT,1;
   IF @Approve=1 AND @ApprovalResult=0
   BEGIN
    COMMIT TRANSACTION;
    SELECT OvertimeID,RequestState,ApprovedAt,ApprovedBy FROM dbo.Emp_OvertimeRequests WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID;
    RETURN;
   END;
  END;  IF @Approve=1
  BEGIN
   SELECT @ActualOvertime=AttDayOvertimeMinutes FROM dbo.Emp_AttendanceDaily WITH(UPDLOCK,HOLDLOCK)
    WHERE AttDayCmp=@CmpID AND AttDayEmpID=@EmployeeID AND AttDayDate=@WorkDate;
   IF @ActualOvertime IS NULL THROW 54457,N'يجب معالجة الحضور لليوم قبل اعتماد الإضافي.',1;
   IF (SELECT ISNULL(SUM(Hours),0) FROM dbo.Emp_OvertimeRequests WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND WorkDate=@WorkDate AND RequestState IN(1,3) AND OvertimeID<>@OvertimeID)+@Hours>CONVERT(decimal(10,2),@ActualOvertime/60.0)
    THROW 54458,N'ساعات الإضافي المعتمدة تتجاوز الزيادة المسجلة في الحضور.',1;
  END;
  UPDATE dbo.Emp_OvertimeRequests SET RequestState=CASE WHEN @Approve=1 THEN 1 ELSE 2 END,ApprovedAt=SYSDATETIME(),ApprovedBy=@ApproverID
  WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID AND RequestState=0;
  IF @@ROWCOUNT<>1 THROW 54459,N'تغيرت حالة طلب الإضافي أثناء البت فيه.',1;
  COMMIT TRANSACTION;
  SELECT OvertimeID,RequestState,ApprovedAt,ApprovedBy FROM dbo.Emp_OvertimeRequests WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

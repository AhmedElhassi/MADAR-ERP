/* =====================================================================
   MADAR ERP - Phase 3 / Batch 1 : verification script for the dynamic approval route
   *** NOT EXECUTED by the author (no SQL Server available). Run ONLY on a TEST copy of the database. ***
   It creates test rows (route step, one overtime request, approval events) and does not delete them,
   because approval history must never be deleted by scripts. Set @CmpID before running.
   Preconditions: P3_B1_01, P3_B1_02 and P3_B1_04 applied (T3 uses Emp_SaveOvertimeRequest); no approval route exists yet for ProcessType 2 in @CmpID.
   Output: one PASS/FAIL line per check.
   ===================================================================== */
SET NOCOUNT ON;
DECLARE @CmpID INT = 1;            -- <== set to a test company
DECLARE @Today DATE = CONVERT(date,SYSDATETIME());
DECLARE @Emp BIGINT,@Mgr BIGINT,@Other BIGINT,@OT BIGINT,@Err INT;

IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=2)
BEGIN PRINT 'ABORT: route for ProcessType 2 already exists in this company; use a company without one.'; RETURN; END;

/* employee that has a resolvable manager (UsrID = EmpID convention: both must be active users of the company) */
SELECT TOP(1) @Emp=e.EmpID, @Mgr=dbo.fn_Emp_GetDirectManager(@CmpID,e.EmpID,@Today)
FROM dbo.Emp_Employee e
JOIN dbo.Mng_User ue ON ue.UsrID=e.EmpID AND ue.UsrCompany=@CmpID AND ue.UsrState=0
WHERE e.EmpCompany=@CmpID AND e.EmpState=0
  AND dbo.fn_Emp_GetDirectManager(@CmpID,e.EmpID,@Today) IS NOT NULL
  AND EXISTS(SELECT 1 FROM dbo.Mng_User um WHERE um.UsrID=dbo.fn_Emp_GetDirectManager(@CmpID,e.EmpID,@Today) AND um.UsrCompany=@CmpID AND um.UsrState=0)
ORDER BY e.EmpID;
IF @Emp IS NULL BEGIN PRINT 'ABORT: no active employee with an active direct manager found (define Emp_OrgUnitHeads first).'; RETURN; END;

SELECT TOP(1) @Other=u.UsrID FROM dbo.Mng_User u
WHERE u.UsrCompany=@CmpID AND u.UsrState=0 AND u.UsrID NOT IN(@Emp,@Mgr) ORDER BY u.UsrID;

/* T1 resolver returns the same manager as fn_Emp_GetDirectManager for level 1 */
IF dbo.fn_Emp_GetManagerAtLevel(@CmpID,@Emp,1,@Today)=@Mgr PRINT 'PASS T1 manager level 1'; ELSE PRINT 'FAIL T1 manager level 1';

/* T2 configure a dynamic step; a fixed step without approver must be refused (54701) */
BEGIN TRY
  EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@CmpID,@ProcessType=2,@StepNo=1,@ApproverID=NULL,@RecordState=0,@UserID=@Mgr,@ApproverKind=0,@LevelsUp=NULL;
  PRINT 'FAIL T2a fixed step without approver accepted';
END TRY BEGIN CATCH SET @Err=ERROR_NUMBER(); IF @Err=54701 PRINT 'PASS T2a'; ELSE PRINT CONCAT('FAIL T2a error ',@Err); END CATCH;
BEGIN TRY
  EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@CmpID,@ProcessType=7,@StepNo=1,@ApproverID=NULL,@RecordState=0,@UserID=@Mgr,@ApproverKind=1,@LevelsUp=1;
  PRINT 'FAIL T2b dynamic step accepted for ProcessType 7';
END TRY BEGIN CATCH SET @Err=ERROR_NUMBER(); IF @Err=54751 PRINT 'PASS T2b'; ELSE PRINT CONCAT('FAIL T2b error ',@Err); END CATCH;
EXEC dbo.Emp_SaveApprovalRouteStep @CmpID=@CmpID,@ProcessType=2,@StepNo=1,@ApproverID=NULL,@RecordState=0,@UserID=@Mgr,@ApproverKind=1,@LevelsUp=1;
IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=2 AND StepNo=1 AND ApproverKind=1 AND LevelsUp=1 AND ApproverID IS NULL) PRINT 'PASS T2c dynamic step stored'; ELSE PRINT 'FAIL T2c';

/* T3 overtime request by the employee starts the engine and records the subject */
DECLARE @R TABLE(OvertimeID BIGINT);
DECLARE @WD DATE=DATEADD(DAY,400,@Today);
INSERT @R EXEC dbo.Emp_SaveOvertimeRequest @CmpID=@CmpID,@OvertimeID=0,@EmployeeID=@Emp,@WorkDate=@WD,
     @StartAt=DATEADD(HOUR,18,CAST(@WD AS DATETIME2(0))),@EndAt=DATEADD(HOUR,20,CAST(@WD AS DATETIME2(0))),@Hours=2,@Reason=N'اختبار المسار الديناميكي',@UserID=@Emp;
SELECT @OT=OvertimeID FROM @R;
IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRequests WHERE CmpID=@CmpID AND ProcessType=2 AND EntityID=@OT AND SubjectEmpID=@Emp AND ApprovalState=0 AND CurrentStep=1) PRINT 'PASS T3 request started with subject'; ELSE PRINT 'FAIL T3';

DECLARE @S TINYINT,@N SMALLINT;
/* T4 a user who is not the manager is refused (54709) */
IF @Other IS NOT NULL
BEGIN TRY
  EXEC dbo.Emp_DecideApprovalStep @CmpID,2,@OT,1,@Other,1,N'test',@S OUTPUT,@N OUTPUT,1; PRINT 'FAIL T4 non-manager accepted';
END TRY BEGIN CATCH SET @Err=ERROR_NUMBER(); IF @Err=54709 PRINT 'PASS T4'; ELSE PRINT CONCAT('FAIL T4 error ',@Err); END CATCH;

/* T5 the employee cannot approve own request (54708 because submitter, otherwise 54756) */
BEGIN TRY
  EXEC dbo.Emp_DecideApprovalStep @CmpID,2,@OT,1,@Emp,1,N'test',@S OUTPUT,@N OUTPUT,1; PRINT 'FAIL T5 self approval accepted';
END TRY BEGIN CATCH SET @Err=ERROR_NUMBER(); IF @Err IN(54708,54756) PRINT 'PASS T5'; ELSE PRINT CONCAT('FAIL T5 error ',@Err); END CATCH;

/* T6 the direct manager approves; the single-step route completes */
EXEC dbo.Emp_DecideApprovalStep @CmpID,2,@OT,1,@Mgr,1,N'test',@S OUTPUT,@N OUTPUT,1;
IF @S=1 AND EXISTS(SELECT 1 FROM dbo.Emp_ApprovalEvents WHERE CmpID=@CmpID AND ProcessType=2 AND EntityID=@OT AND ApproverID=@Mgr AND Decision=1) PRINT 'PASS T6 manager approval'; ELSE PRINT 'FAIL T6';

/* T7 deciding again is refused (54707) */
BEGIN TRY
  EXEC dbo.Emp_DecideApprovalStep @CmpID,2,@OT,1,@Mgr,1,N'test',@S OUTPUT,@N OUTPUT,1; PRINT 'FAIL T7 duplicate decision accepted';
END TRY BEGIN CATCH SET @Err=ERROR_NUMBER(); IF @Err=54707 PRINT 'PASS T7'; ELSE PRINT CONCAT('FAIL T7 error ',@Err); END CATCH;

PRINT 'Not covered here: concurrency (two simultaneous decisions), multi-level routes, company isolation across two companies.';

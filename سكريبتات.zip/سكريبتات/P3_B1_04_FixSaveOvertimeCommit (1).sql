/* =====================================================================
   MADAR ERP - Phase 3 / Batch 1c : Defect fix in an EXISTING procedure
   Object  : dbo.Emp_SaveOvertimeRequest  (reference file line 33785)
   Defect  : the procedure runs BEGIN TRANSACTION and never COMMITs on the success path. The caller returns with an
             open transaction (SQL Server error 266 for nested callers; for a plain client the insert is rolled
             back when the connection is released), so overtime requests are not reliably persisted.
   Change  : ONLY one line is added: "COMMIT TRANSACTION;" just before the final SELECT. Everything else is verbatim.
   Status  : static review only - not executed on SQL Server.
   ===================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.Emp_SaveOvertimeRequest
 @CmpID INT,@OvertimeID BIGINT=0,@EmployeeID BIGINT,@WorkDate DATE,@StartAt DATETIME2(0),@EndAt DATETIME2(0),
 @Hours DECIMAL(8,2),@Reason NVARCHAR(500),@Multiplier DECIMAL(8,4)=NULL,@UserID BIGINT
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON; EXEC dbo.Emp_HRValidateActor @CmpID,@UserID;
 IF @WorkDate IS NULL OR @StartAt IS NULL OR @EndAt IS NULL OR CONVERT(date,@StartAt)<>@WorkDate OR CONVERT(date,@EndAt)<@WorkDate
  OR @EndAt<=@StartAt OR @Hours<=0 OR @Hours>CONVERT(decimal(8,2),DATEDIFF(MINUTE,@StartAt,@EndAt)/60.0)
  OR (@Multiplier IS NOT NULL AND @Multiplier<=0) OR NULLIF(LTRIM(RTRIM(@Reason)),N'') IS NULL
  THROW 54450,N'بيانات فترة العمل الإضافي أو مدتها غير صحيحة.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.Emp_Employee WHERE EmpCompany=@CmpID AND EmpID=@EmployeeID AND EmpState=0) THROW 54451,N'الموظف غير نشط أو لا يتبع للشركة.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  IF EXISTS(SELECT 1 FROM dbo.Emp_OvertimeRequests WITH(UPDLOCK,HOLDLOCK) WHERE CmpID=@CmpID AND EmployeeID=@EmployeeID AND RequestState<>2 AND (@OvertimeID=0 OR OvertimeID<>@OvertimeID) AND @StartAt<EndAt AND @EndAt>StartAt)
   THROW 54452,N'تتداخل فترة الإضافي مع طلب آخر للموظف.',1;
  IF ISNULL(@OvertimeID,0)=0
  BEGIN
   INSERT dbo.Emp_OvertimeRequests(CmpID,EmployeeID,WorkDate,StartAt,EndAt,Hours,Reason,Multiplier,CreatedBy)
   VALUES(@CmpID,@EmployeeID,@WorkDate,@StartAt,@EndAt,@Hours,LTRIM(RTRIM(@Reason)),@Multiplier,@UserID);
   SET @OvertimeID=SCOPE_IDENTITY();
  END
  ELSE
  BEGIN
   UPDATE dbo.Emp_OvertimeRequests SET WorkDate=@WorkDate,StartAt=@StartAt,EndAt=@EndAt,Hours=@Hours,Reason=@Reason,Multiplier=@Multiplier
   WHERE CmpID=@CmpID AND OvertimeID=@OvertimeID AND EmployeeID=@EmployeeID AND RequestState=0;
   IF @@ROWCOUNT<>1 THROW 54453,N'طلب الإضافي غير موجود أو غير قابل للتعديل.',1;
  END;
  IF EXISTS(SELECT 1 FROM dbo.Emp_ApprovalRouteSteps WHERE CmpID=@CmpID AND ProcessType=2 AND RecordState=0) EXEC dbo.Emp_StartApproval @CmpID,2,@OvertimeID,@UserID,1;
  COMMIT TRANSACTION;
  SELECT @OvertimeID AS OvertimeID;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* إنشاء منظومة المشتريات والتوريد (SysID 3) بنسخ صف منظومة المخازن (SysID 2) وتغيير الاسمين */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = 2) THROW 52950, N'منظومة المخازن (SysID 2) غير موجودة.', 1;
IF EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = 3) BEGIN PRINT N'SysID 3 موجودة مسبقًا — لا تغيير.'; SELECT * FROM dbo.Mng_System WHERE SysID = 3; RETURN; END

DECLARE @Cols NVARCHAR(MAX), @Sel NVARCHAR(MAX), @Sql NVARCHAR(MAX);
DECLARE @Ident BIT = COLUMNPROPERTY(OBJECT_ID(N'dbo.Mng_System'), N'SysID', 'IsIdentity');

SELECT @Cols = STRING_AGG(CAST(QUOTENAME(c.name) AS NVARCHAR(MAX)), N',') WITHIN GROUP (ORDER BY c.column_id),
       @Sel  = STRING_AGG(CAST(CASE c.name WHEN N'SysID' THEN N'3'
                                           WHEN N'SysName' THEN N'N''منظومة المشتريات والتوريد'''
                                           WHEN N'SysEName' THEN N'N''ProcurementSupply'''
                                           ELSE QUOTENAME(c.name) END AS NVARCHAR(MAX)), N',') WITHIN GROUP (ORDER BY c.column_id)
FROM sys.columns AS c
WHERE c.object_id = OBJECT_ID(N'dbo.Mng_System') AND c.is_computed = 0 AND c.system_type_id <> 189; -- بلا timestamp

SET @Sql = CASE WHEN @Ident = 1 THEN N'SET IDENTITY_INSERT dbo.Mng_System ON; ' ELSE N'' END
         + N'INSERT dbo.Mng_System (' + @Cols + N') SELECT ' + @Sel + N' FROM dbo.Mng_System WHERE SysID = 2; '
         + CASE WHEN @Ident = 1 THEN N'SET IDENTITY_INSERT dbo.Mng_System OFF;' ELSE N'' END;
EXEC sys.sp_executesql @Sql;
SELECT * FROM dbo.Mng_System WHERE SysID IN (2, 3) ORDER BY SysID;

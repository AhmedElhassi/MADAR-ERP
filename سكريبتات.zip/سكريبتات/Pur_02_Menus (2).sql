/* نقل قوائم المشتريات من منظومة المخازن (2) إلى منظومة المشتريات (3) بترقيم متسلسل من 1، مع الصلاحيات — معاملة واحدة */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = 3) THROW 52951, N'نفّذ Pur_01_System.sql أولًا.', 1;
IF EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3) THROW 52952, N'قوائم المنظومة 3 موجودة مسبقًا — لا تغيير.', 1;
IF COLUMNPROPERTY(OBJECT_ID(N'dbo.Mng_SystemMenu'), N'SysMID', 'IsIdentity') = 1 THROW 52954, N'SysMID عمود آلي — أرسل لي ذلك لأعدّل السكربت.', 1;

-- الترقيم الجديد في المنظومة 3: 1 البيانات الأساسية، 2 المشتريات، ثم القوائم
DECLARE @Map TABLE (OldId INT PRIMARY KEY, NewId INT, NewParent INT);
INSERT @Map VALUES (8,3,1),(14,4,2),(15,5,2),(17,6,2),(18,7,2),(19,8,2),(20,9,2),(21,10,2);
IF (SELECT COUNT(*) FROM dbo.Mng_SystemMenu WHERE SysMSysID = 2 AND SysMID IN (SELECT OldId FROM @Map)) <> 8
    THROW 52953, N'قوائم المخازن الحالية لا تطابق المتوقع (8 قوائم للنقل).', 1;

BEGIN TRY
BEGIN TRAN;
    INSERT dbo.Mng_SystemMenu (SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime)
    VALUES (1, 3, 0, N'البيانات الأساسية', N'PurMaster',     N'fa-solid fa-database',     N'', 0, GETDATE()),
           (2, 3, 0, N'المشتريات',         N'PurPurchasing', N'fa-solid fa-cart-shopping', N'', 0, GETDATE());

    -- نسخ القوائم المنقولة بأرقامها الجديدة ثم حذفها من المخازن
    INSERT dbo.Mng_SystemMenu (SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime)
    SELECT m.NewId, 3, m.NewParent, s.SysMName, s.SysMEName, s.SysMLogo, s.SysMMap, s.SysMState, s.SysMDateTime
    FROM dbo.Mng_SystemMenu AS s JOIN @Map AS m ON m.OldId = s.SysMID WHERE s.SysMSysID = 2;

    DELETE FROM dbo.Mng_SystemMenu WHERE SysMSysID = 2 AND SysMID IN (SELECT OldId FROM @Map);
    -- الجذر القديم "المشتريات" في المخازن صار للطلب والاستلام فقط
    UPDATE dbo.Mng_SystemMenu SET SysMName = N'الطلب والاستلام' WHERE SysMID = 2 AND SysMSysID = 2;

    -- قائمتا النظامين النصيتان
    UPDATE dbo.Mng_System SET SysMenu = N'1, 2, 3, 4, 5, 6, 7, 8, 9, 10' WHERE SysID = 3;
    UPDATE dbo.Mng_System
       SET SysMenu = (SELECT STRING_AGG(CAST(v AS NVARCHAR(20)), N', ') WITHIN GROUP (ORDER BY v)
                      FROM (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(SysMenu, N',')) AS t
                      WHERE v IS NOT NULL AND v NOT IN (SELECT OldId FROM @Map))
     WHERE SysID = 2;

    -- صلاحيات المستخدمين: من يملك أيًّا من القوائم المنقولة يأخذ صلاحيتها في المنظومة 3 بالأرقام الجديدة
    DECLARE @P TABLE (U BIGINT, C INT, Has8 BIT, HasOther BIT, St INT, UsrBy BIGINT);
    INSERT @P
    SELECT p.USPUserID, p.USPCompanyID,
           MAX(CASE WHEN s.v = 8 THEN 1 ELSE 0 END),
           MAX(CASE WHEN s.v <> 8 THEN 1 ELSE 0 END),
           MAX(p.USPState), MAX(p.USPUser)
    FROM dbo.Mng_UserParmations AS p
    CROSS APPLY (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(p.USPParmations, N',')) AS s
    WHERE p.USPSystemID = 2 AND s.v IN (SELECT OldId FROM @Map)
    GROUP BY p.USPUserID, p.USPCompanyID;

    INSERT dbo.Mng_UserParmations (USPUserID, USPCompanyID, USPSystemID, USPParmations, USPState, USPDateTime, USPUser)
    SELECT q.U, q.C, 3, x.L, q.St, GETDATE(), q.UsrBy
    FROM @P AS q
    CROSS APPLY (SELECT STRING_AGG(CAST(v AS NVARCHAR(10)), N', ') WITHIN GROUP (ORDER BY v) AS L
                 FROM (VALUES (1, q.Has8), (3, q.Has8), (2, q.HasOther), (4, q.HasOther), (5, q.HasOther), (6, q.HasOther),
                              (7, q.HasOther), (8, q.HasOther), (9, q.HasOther), (10, q.HasOther)) AS z(v, f)
                 WHERE f = 1) AS x;
    -- ملاحظة: من يملك أيًّا من قوائم المشتريات يُمنح كل قوائمها (يُضبط لاحقًا من شاشة الصلاحيات)

    UPDATE p SET USPParmations = ISNULL((SELECT STRING_AGG(CAST(v AS NVARCHAR(20)), N', ') WITHIN GROUP (ORDER BY v)
                      FROM (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(p.USPParmations, N',')) AS t
                      WHERE v IS NOT NULL AND v NOT IN (SELECT OldId FROM @Map)), N'')
    FROM dbo.Mng_UserParmations AS p WHERE p.USPSystemID = 2;
COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH

SELECT SysMID, SysMSysID, SysMParent, SysMName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3 ORDER BY SysMID;
SELECT SysID, SysMenu FROM dbo.Mng_System WHERE SysID IN (2,3);
SELECT USPUserID, USPCompanyID, USPSystemID, USPParmations FROM dbo.Mng_UserParmations ORDER BY USPUserID, USPSystemID;

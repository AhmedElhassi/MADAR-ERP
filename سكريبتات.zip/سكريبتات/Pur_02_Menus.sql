/* نقل قوائم المشتريات من منظومة المخازن (2) إلى منظومة المشتريات (3) مع صلاحيات المستخدمين — داخل معاملة */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = 3) THROW 52951, N'نفّذ Pur_01_System.sql أولًا.', 1;
IF EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3) THROW 52952, N'قوائم المنظومة 3 موجودة مسبقًا — لا تغيير.', 1;

DECLARE @Move TABLE (Id INT PRIMARY KEY);
INSERT @Move VALUES (8),(14),(15),(17),(18),(19),(20),(21);   -- موردون، طلب شراء، فاتورة شراء، ترجيعان، إشعار دائن، تكلفة إضافية، تسوية تكلفة
IF (SELECT COUNT(*) FROM dbo.Mng_SystemMenu WHERE SysMSysID = 2 AND SysMID IN (SELECT Id FROM @Move)) <> 8
    THROW 52953, N'قوائم المخازن الحالية لا تطابق المتوقع (8 قوائم للنقل).', 1;

DECLARE @Ident BIT = COLUMNPROPERTY(OBJECT_ID(N'dbo.Mng_SystemMenu'), N'SysMID', 'IsIdentity');
DECLARE @R1 INT, @R2 INT;

BEGIN TRY
BEGIN TRAN;
    -- جذران جديدان في المنظومة 3
    IF @Ident = 1
    BEGIN
        INSERT dbo.Mng_SystemMenu (SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime)
        VALUES (3, 0, N'البيانات الأساسية', N'PurMaster', N'fa-solid fa-database', N'', 0, GETDATE());
        SET @R1 = SCOPE_IDENTITY();
        INSERT dbo.Mng_SystemMenu (SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime)
        VALUES (3, 0, N'المشتريات', N'PurPurchasing', N'fa-solid fa-cart-shopping', N'', 0, GETDATE());
        SET @R2 = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        SELECT @R1 = ISNULL(MAX(SysMID), 0) + 1 FROM dbo.Mng_SystemMenu; SET @R2 = @R1 + 1;
        INSERT dbo.Mng_SystemMenu (SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime)
        VALUES (@R1, 3, 0, N'البيانات الأساسية', N'PurMaster', N'fa-solid fa-database', N'', 0, GETDATE()),
               (@R2, 3, 0, N'المشتريات', N'PurPurchasing', N'fa-solid fa-cart-shopping', N'', 0, GETDATE());
    END

    -- نقل القوائم وربطها بالجذرين
    UPDATE dbo.Mng_SystemMenu SET SysMSysID = 3, SysMParent = @R1 WHERE SysMID = 8;
    UPDATE dbo.Mng_SystemMenu SET SysMSysID = 3, SysMParent = @R2 WHERE SysMID IN (14,15,17,18,19,20,21);
    -- الجذر القديم "المشتريات" في المخازن صار للطلب والاستلام فقط
    UPDATE dbo.Mng_SystemMenu SET SysMName = N'الطلب والاستلام' WHERE SysMID = 2 AND SysMSysID = 2;

    -- قوائم النظامين النصية
    DECLARE @New3 NVARCHAR(MAX) = CONCAT(@R1, N', ', @R2, N', 8, 14, 15, 17, 18, 19, 20, 21');
    UPDATE dbo.Mng_System SET SysMenu = @New3 WHERE SysID = 3;
    UPDATE dbo.Mng_System
       SET SysMenu = (SELECT STRING_AGG(CAST(v AS NVARCHAR(20)), N', ') WITHIN GROUP (ORDER BY v)
                      FROM (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(SysMenu, N',')) AS t
                      WHERE v IS NOT NULL AND v NOT IN (SELECT Id FROM @Move))
     WHERE SysID = 2;

    -- صلاحيات المستخدمين: من يملك أيًّا من القوائم المنقولة يأخذ صلاحيتها في المنظومة 3
    DECLARE @P TABLE (U BIGINT, C INT, Has8 BIT, HasOther BIT, St INT, UsrBy BIGINT);
    INSERT @P
    SELECT p.USPUserID, p.USPCompanyID,
           MAX(CASE WHEN s.v = 8 THEN 1 ELSE 0 END),
           MAX(CASE WHEN s.v IN (14,15,17,18,19,20,21) THEN 1 ELSE 0 END),
           MAX(p.USPState), MAX(p.USPUser)
    FROM dbo.Mng_UserParmations AS p
    CROSS APPLY (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(p.USPParmations, N',')) AS s
    WHERE p.USPSystemID = 2 AND s.v IN (SELECT Id FROM @Move)
    GROUP BY p.USPUserID, p.USPCompanyID;

    INSERT dbo.Mng_UserParmations (USPUserID, USPCompanyID, USPSystemID, USPParmations, USPState, USPDateTime, USPUser)
    SELECT U, C, 3,
           CONCAT(CASE WHEN Has8 = 1 THEN CONCAT(@R1, N', 8') ELSE N'' END,
                  CASE WHEN Has8 = 1 AND HasOther = 1 THEN N', ' ELSE N'' END,
                  CASE WHEN HasOther = 1 THEN CONCAT(@R2, N', 14, 15, 17, 18, 19, 20, 21') ELSE N'' END),
           St, GETDATE(), UsrBy
    FROM @P;
    -- ملاحظة: يُمنح من يملك أيًّا من قوائم المشتريات كل قوائمها الفرعية (يُضبط لاحقًا من شاشة الصلاحيات)

    -- حذف القوائم المنقولة من صلاحيات المنظومة 2
    UPDATE p SET USPParmations = ISNULL((SELECT STRING_AGG(CAST(v AS NVARCHAR(20)), N', ') WITHIN GROUP (ORDER BY v)
                      FROM (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(p.USPParmations, N',')) AS t
                      WHERE v IS NOT NULL AND v NOT IN (SELECT Id FROM @Move)), N'')
    FROM dbo.Mng_UserParmations AS p WHERE p.USPSystemID = 2;
COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH

SELECT SysMID, SysMSysID, SysMParent, SysMName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3 OR SysMID = 2 ORDER BY SysMSysID, SysMParent, SysMID;
SELECT SysID, SysMenu FROM dbo.Mng_System WHERE SysID IN (2,3);
SELECT USPUserID, USPCompanyID, USPSystemID, USPParmations FROM dbo.Mng_UserParmations ORDER BY USPUserID, USPSystemID;

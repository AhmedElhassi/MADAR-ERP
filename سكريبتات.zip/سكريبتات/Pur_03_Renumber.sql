/* إعادة ترقيم قوائم المنظومة 3 لتصبح متسلسلة 1..10 (وتحديث SysMenu والصلاحيات) — معاملة واحدة */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @Map TABLE (OldId INT PRIMARY KEY, NewId INT);
INSERT @Map VALUES (8,3),(14,4),(15,5),(17,6),(18,7),(19,8),(20,9),(21,10);
IF (SELECT COUNT(*) FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3) <> 10 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3 AND SysMID = 21)
    THROW 52955, N'قوائم المنظومة 3 ليست بالشكل المتوقع (10 صفوف بأرقام 1,2,8,14,...,21) — ربما نُفّذ سابقًا.', 1;
BEGIN TRY
BEGIN TRAN;
    -- بالترتيب التصاعدي حتى لا يصطدم رقم جديد بقديم لم يُنقل بعد
    UPDATE dbo.Mng_SystemMenu SET SysMID = 3  WHERE SysMSysID = 3 AND SysMID = 8;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 4  WHERE SysMSysID = 3 AND SysMID = 14;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 5  WHERE SysMSysID = 3 AND SysMID = 15;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 6  WHERE SysMSysID = 3 AND SysMID = 17;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 7  WHERE SysMSysID = 3 AND SysMID = 18;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 8  WHERE SysMSysID = 3 AND SysMID = 19;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 9  WHERE SysMSysID = 3 AND SysMID = 20;
    UPDATE dbo.Mng_SystemMenu SET SysMID = 10 WHERE SysMSysID = 3 AND SysMID = 21;
    -- الأب: ملف الموردين تحت 1 والباقي تحت 2 (لم يتغيّر)

    UPDATE dbo.Mng_System SET SysMenu = N'1, 2, 3, 4, 5, 6, 7, 8, 9, 10' WHERE SysID = 3;

    UPDATE p SET USPParmations = (SELECT STRING_AGG(CAST(n AS NVARCHAR(10)), N', ') WITHIN GROUP (ORDER BY n)
                                  FROM (SELECT DISTINCT ISNULL(m.NewId, t.v) AS n
                                        FROM (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(p.USPParmations, N',')) AS t
                                        LEFT JOIN @Map AS m ON m.OldId = t.v WHERE t.v IS NOT NULL) AS d)
    FROM dbo.Mng_UserParmations AS p WHERE p.USPSystemID = 3;
COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH

SELECT SysMID, SysMSysID, SysMParent, SysMName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3 ORDER BY SysMID;
SELECT SysID, SysMenu FROM dbo.Mng_System WHERE SysID = 3;
SELECT USPUserID, USPCompanyID, USPSystemID, USPParmations FROM dbo.Mng_UserParmations WHERE USPSystemID = 3;

/* إعادة ترقيم قوائم منظومة المخازن (2) لتصبح متسلسلة من 1 (وتحديث SysMenu والصلاحيات) — معاملة واحدة */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @Map TABLE (OldId INT PRIMARY KEY, NewId INT);
INSERT @Map
SELECT SysMID, ROW_NUMBER() OVER (ORDER BY SysMID) FROM dbo.Mng_SystemMenu WHERE SysMSysID = 2;
IF NOT EXISTS (SELECT 1 FROM @Map WHERE OldId <> NewId) BEGIN PRINT N'قوائم المنظومة 2 متسلسلة أصلًا — لا تغيير.'; RETURN; END
-- الأرقام التي تُستعمل كآباء (الجذور) يجب ألا تتغير أو تُحدَّث أبناؤها معها
DECLARE @Old INT, @New INT;
BEGIN TRY
BEGIN TRAN;
    -- 1) تحديث الآباء أولًا في الصفوف (بلا تصادم لأن SysMParent ليس جزءًا من المفتاح)
    UPDATE c SET SysMParent = m.NewId
    FROM dbo.Mng_SystemMenu AS c JOIN @Map AS m ON m.OldId = c.SysMParent
    WHERE c.SysMSysID = 2 AND c.SysMParent <> 0 AND m.OldId <> m.NewId;
    -- 2) تحديث الأرقام بالترتيب التصاعدي (كل رقم جديد أصغر من القديم وقد فُرّغ)
    DECLARE cur CURSOR LOCAL STATIC FOR SELECT OldId, NewId FROM @Map WHERE OldId <> NewId ORDER BY OldId;
    OPEN cur; FETCH NEXT FROM cur INTO @Old, @New;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE dbo.Mng_SystemMenu SET SysMID = @New WHERE SysMSysID = 2 AND SysMID = @Old;
        FETCH NEXT FROM cur INTO @Old, @New;
    END
    CLOSE cur; DEALLOCATE cur;

    UPDATE dbo.Mng_System SET SysMenu = (SELECT STRING_AGG(CAST(NewId AS NVARCHAR(10)), N', ') WITHIN GROUP (ORDER BY NewId) FROM @Map) WHERE SysID = 2;

    UPDATE p SET USPParmations = ISNULL((SELECT STRING_AGG(CAST(n AS NVARCHAR(10)), N', ') WITHIN GROUP (ORDER BY n)
                                  FROM (SELECT DISTINCT ISNULL(m.NewId, t.v) AS n
                                        FROM (SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS v FROM STRING_SPLIT(p.USPParmations, N',')) AS t
                                        LEFT JOIN @Map AS m ON m.OldId = t.v WHERE t.v IS NOT NULL) AS d), N'')
    FROM dbo.Mng_UserParmations AS p WHERE p.USPSystemID = 2;
COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH

SELECT SysMID, SysMParent, SysMName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = 2 ORDER BY SysMID;
SELECT SysID, SysMenu FROM dbo.Mng_System WHERE SysID = 2;
SELECT USPUserID, USPCompanyID, USPSystemID, USPParmations FROM dbo.Mng_UserParmations WHERE USPSystemID = 2;

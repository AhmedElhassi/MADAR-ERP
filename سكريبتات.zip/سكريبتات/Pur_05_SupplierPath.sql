/* مسار ملف الموردين الجديد في منظومة المشتريات */
USE [MADARERPDataBase];
UPDATE dbo.Mng_SystemMenu SET SysMMap = N'~/Purchasing/Pur_Parties.aspx' WHERE SysMSysID = 3 AND SysMID = 3 AND SysMMap = N'~/Warehouses/Wrh_Parties.aspx';
SELECT SysMID, SysMName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = 3 AND SysMID = 3;

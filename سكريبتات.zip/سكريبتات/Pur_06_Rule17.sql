/* قاعدة ربط العملية 17 (الدائنون المتنوعون): الحساب الأب 32 بحالة 3 (أب آلي) — بنسخ بنية قاعدة العملية 2 الموجودة */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE OpID = 17) BEGIN PRINT N'توجد قاعدة للعملية 17 — لا تغيير.'; SELECT * FROM dbo.Acc_PostingRule WHERE OpID = 17; RETURN; END
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = 32) THROW 52970, N'الحساب 32 غير موجود.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE RuleID = 42 AND OpID = 2) THROW 52971, N'قاعدة العملية 2 (RuleID 42) غير موجودة لنسخ بنيتها.', 1;

DECLARE @Cols NVARCHAR(MAX), @Sel NVARCHAR(MAX), @Sql NVARCHAR(MAX);
SELECT @Cols = STRING_AGG(CAST(QUOTENAME(c.name) AS NVARCHAR(MAX)), N',') WITHIN GROUP (ORDER BY c.column_id),
       @Sel  = STRING_AGG(CAST(CASE c.name WHEN N'OpID' THEN N'17' WHEN N'AccID' THEN N'32' WHEN N'StateID' THEN N'3' ELSE QUOTENAME(c.name) END AS NVARCHAR(MAX)), N',') WITHIN GROUP (ORDER BY c.column_id)
FROM sys.columns AS c
WHERE c.object_id = OBJECT_ID(N'dbo.Acc_PostingRule') AND c.is_identity = 0 AND c.is_computed = 0 AND c.system_type_id <> 189;

SET @Sql = N'INSERT dbo.Acc_PostingRule (' + @Cols + N') SELECT ' + @Sel + N' FROM dbo.Acc_PostingRule WHERE RuleID = 42;';
EXEC sys.sp_executesql @Sql;
SELECT * FROM dbo.Acc_PostingRule WHERE OpID IN (2, 15, 17) ORDER BY OpID, RuleID;

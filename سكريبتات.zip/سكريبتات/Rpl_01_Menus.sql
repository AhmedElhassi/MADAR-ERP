/* قوائم منظومة تخطيط الموارد (SysID 4) بترقيم متسلسل 1..7 + صلاحيات من يملك قائمة "طلبات المواد" في المخازن — معاملة واحدة */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = 4 AND SysEName = N'ResourcePlanning') THROW 52980, N'منظومة تخطيط الموارد (SysID 4) غير موجودة.', 1;
IF EXISTS (SELECT 1 FROM dbo.Mng_SystemMenu WHERE SysMSysID = 4) THROW 52981, N'قوائم المنظومة 4 موجودة مسبقًا — لا تغيير.', 1;
IF COLUMNPROPERTY(OBJECT_ID(N'dbo.Mng_SystemMenu'), N'SysMID', 'IsIdentity') = 1 THROW 52954, N'SysMID عمود آلي — أرسل لي ذلك لأعدّل السكربت.', 1;

BEGIN TRY
BEGIN TRAN;
    INSERT dbo.Mng_SystemMenu (SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState, SysMDateTime)
    VALUES (1, 4, 0, N'الطلبات',              N'RplRequests',      N'fa-solid fa-clipboard-list', N'', 0, GETDATE()),
           (2, 4, 1, N'إنشاء طلب مواد',        N'RplNewRequest',    N'fa-solid fa-file-circle-plus', N'~/ResourcePlanning/Rpl_MaterialRequest.aspx', 0, GETDATE()),
           (3, 4, 1, N'طلبات لم تُرسل',        N'RplDrafts',        N'fa-solid fa-file-pen', N'~/ResourcePlanning/Rpl_Drafts.aspx', 0, GETDATE()),
           (4, 4, 1, N'الطلبات المعادة',       N'RplReturned',      N'fa-solid fa-rotate-left', N'~/ResourcePlanning/Rpl_Returned.aspx', 0, GETDATE()),
           (5, 4, 0, N'الاستفسار والتقارير',   N'RplReports',       N'fa-solid fa-chart-line', N'', 0, GETDATE()),
           (6, 4, 5, N'استفسار عن الطلبات',    N'RplInquiry',       N'fa-solid fa-magnifying-glass', N'~/ResourcePlanning/Rpl_Inquiry.aspx', 0, GETDATE()),
           (7, 4, 0, N'لوحة المتابعة',         N'RplDashboard',     N'fa-solid fa-gauge-high', N'~/ResourcePlanning/Rpl_Dashboard.aspx', 0, GETDATE());

    UPDATE dbo.Mng_System SET SysMenu = N'1, 2, 3, 4, 5, 6, 7' WHERE SysID = 4;

    -- صلاحيات: من يملك قائمة "طلبات المواد" في المخازن يأخذ كل قوائم المنظومة 4 (يُضبط لاحقًا من شاشة الصلاحيات)
    DECLARE @Old INT = (SELECT TOP 1 SysMID FROM dbo.Mng_SystemMenu WHERE SysMSysID = 2 AND SysMName = N'طلبات المواد');
    IF @Old IS NOT NULL
        INSERT dbo.Mng_UserParmations (USPUserID, USPCompanyID, USPSystemID, USPParmations, USPState, USPDateTime, USPUser)
        SELECT p.USPUserID, p.USPCompanyID, 4, N'1, 2, 3, 4, 5, 6, 7', p.USPState, GETDATE(), p.USPUser
        FROM dbo.Mng_UserParmations AS p
        WHERE p.USPSystemID = 2
          AND EXISTS (SELECT 1 FROM STRING_SPLIT(p.USPParmations, N',') AS s WHERE TRY_CAST(LTRIM(RTRIM(s.value)) AS INT) = @Old)
          AND NOT EXISTS (SELECT 1 FROM dbo.Mng_UserParmations AS x WHERE x.USPUserID = p.USPUserID AND x.USPCompanyID = p.USPCompanyID AND x.USPSystemID = 4);
COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH

SELECT SysMID, SysMParent, SysMName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = 4 ORDER BY SysMID;
SELECT SysID, SysMenu FROM dbo.Mng_System WHERE SysID = 4;
SELECT USPUserID, USPCompanyID, USPSystemID, USPParmations FROM dbo.Mng_UserParmations WHERE USPSystemID = 4;

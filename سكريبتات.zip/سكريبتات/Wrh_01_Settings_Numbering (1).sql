/* =====================================================================
   المرحلة 1: إعدادات المشتريات والمخازن + ترقيم المستندات
   ---------------------------------------------------------------------
   Wrh_Settings   : إعداد واحد لكل شركة (القيم الافتراضية في الجدول نفسه)
   Wrh_DocSeq     : آخر رقم لكل (شركة، سنة، نوع مستند)
   Wrh_NextDocNo  : يعطي الرقم التالي بصيغة YY + 8 خانات (NVARCHAR(10)) مثل 2600000001
   Wrh_SelectSettings / Wrh_SaveSettings

   الأخطاء: 52001 طريقة التكلفة   52002 أساس التوزيع   52003 حد القيد الآلي
            52004 حالة القيد الآلي  52005 مستخدم غير موجود   52006 شركة غير صحيحة
            52101 معاملات الترقيم غير صحيحة   52102 تجاوز التسلسل (99999999)

   ملاحظة: منع تغيير طريقة التكلفة بعد أول عملية يُضاف في مرحلة محرك المستندات
   (حين يوجد جدول المستندات)، ولا يُفترض اسمه هنا.
   نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF OBJECT_ID(N'dbo.Wrh_Settings', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Settings
    (
        WsCmpID             INT      NOT NULL CONSTRAINT PK_Wrh_Settings PRIMARY KEY,
        WsCostMethod        TINYINT  NOT NULL CONSTRAINT DF_Wrh_Settings_Cost   DEFAULT (1),  -- 1 FIFO  2 متوسط مرجح
        WsAllocBasis        TINYINT  NOT NULL CONSTRAINT DF_Wrh_Settings_Alloc  DEFAULT (1),  -- 1 قيمة  2 كمية  3 وزن
        WsAllowPartialIssue BIT      NOT NULL CONSTRAINT DF_Wrh_Settings_Part   DEFAULT (1),
        WsAllowNegative     BIT      NOT NULL CONSTRAINT DF_Wrh_Settings_Neg    DEFAULT (0),
        WsReserveOnRequest  BIT      NOT NULL CONSTRAINT DF_Wrh_Settings_Rsv    DEFAULT (1),
        WsSeparateDuties    BIT      NOT NULL CONSTRAINT DF_Wrh_Settings_Sep    DEFAULT (1),
        WsMaxAutoVoucherDocs INT     NOT NULL CONSTRAINT DF_Wrh_Settings_Max    DEFAULT (500),
        WsAutoVoucherState  TINYINT  NOT NULL CONSTRAINT DF_Wrh_Settings_AvSt   DEFAULT (1),  -- 0 مؤقت  1 مُرحّل
        WsDiffAccID         BIGINT   NULL,                                                     -- حساب فروق التكلفة
        WsUpdatedBy         BIGINT   NULL,
        WsUpdatedAt         DATETIME2(0) NULL,
        CONSTRAINT CK_Wrh_Settings_Cost  CHECK (WsCostMethod IN (1, 2)),
        CONSTRAINT CK_Wrh_Settings_Alloc CHECK (WsAllocBasis IN (1, 2, 3)),
        CONSTRAINT CK_Wrh_Settings_Max   CHECK (WsMaxAutoVoucherDocs BETWEEN 1 AND 5000),
        CONSTRAINT CK_Wrh_Settings_AvSt  CHECK (WsAutoVoucherState IN (0, 1))
    );
GO

IF OBJECT_ID(N'dbo.Wrh_DocSeq', N'U') IS NULL
    CREATE TABLE dbo.Wrh_DocSeq
    (
        DsCmpID   INT     NOT NULL,
        DsYear    SMALLINT NOT NULL,
        DsDocType TINYINT NOT NULL,
        DsLastNo  INT     NOT NULL CONSTRAINT DF_Wrh_DocSeq_Last DEFAULT (0),
        CONSTRAINT PK_Wrh_DocSeq PRIMARY KEY (DsCmpID, DsYear, DsDocType),
        CONSTRAINT CK_Wrh_DocSeq_Last CHECK (DsLastNo BETWEEN 0 AND 99999999)
    );
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_NextDocNo
    @Cmp     INT,
    @Year    INT,
    @DocType TINYINT,
    @DocNo   NVARCHAR(10) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Year NOT BETWEEN 2000 AND 2099 OR ISNULL(@DocType, 0) = 0
        THROW 52101, N'معاملات ترقيم المستند غير صحيحة.', 1;

    DECLARE @n INT;

    UPDATE dbo.Wrh_DocSeq WITH (UPDLOCK, HOLDLOCK)
       SET @n = DsLastNo = DsLastNo + 1
     WHERE DsCmpID = @Cmp AND DsYear = @Year AND DsDocType = @DocType
       AND DsLastNo < 99999999;

    IF @@ROWCOUNT = 0
    BEGIN
        IF EXISTS (SELECT 1 FROM dbo.Wrh_DocSeq WITH (UPDLOCK, HOLDLOCK)
                   WHERE DsCmpID = @Cmp AND DsYear = @Year AND DsDocType = @DocType)
            THROW 52102, N'تجاوز تسلسل ترقيم هذا النوع في هذه السنة (99999999).', 1;

        INSERT dbo.Wrh_DocSeq (DsCmpID, DsYear, DsDocType, DsLastNo) VALUES (@Cmp, @Year, @DocType, 1);
        SET @n = 1;
    END

    SET @DocNo = RIGHT(CONVERT(NVARCHAR(4), @Year), 2) + RIGHT(N'00000000' + CONVERT(NVARCHAR(8), @n), 8);
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectSettings
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0
        THROW 52006, N'الشركة غير صحيحة.', 1;

    IF EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp)
        SELECT s.WsCmpID, s.WsCostMethod, s.WsAllocBasis, s.WsAllowPartialIssue, s.WsAllowNegative,
               s.WsReserveOnRequest, s.WsSeparateDuties, s.WsMaxAutoVoucherDocs, s.WsAutoVoucherState,
               s.WsDiffAccID, CAST(0 AS BIT) AS IsDefault
        FROM dbo.Wrh_Settings AS s
        WHERE s.WsCmpID = @Cmp;
    ELSE
        -- لا صف بعد: القيم الافتراضية كما في تعريف الجدول (دون كتابة شيء)
        SELECT @Cmp AS WsCmpID,
               CAST(1 AS TINYINT) AS WsCostMethod, CAST(1 AS TINYINT) AS WsAllocBasis,
               CAST(1 AS BIT) AS WsAllowPartialIssue, CAST(0 AS BIT) AS WsAllowNegative,
               CAST(1 AS BIT) AS WsReserveOnRequest, CAST(1 AS BIT) AS WsSeparateDuties,
               CAST(500 AS INT) AS WsMaxAutoVoucherDocs, CAST(1 AS TINYINT) AS WsAutoVoucherState,
               CAST(NULL AS BIGINT) AS WsDiffAccID, CAST(1 AS BIT) AS IsDefault;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveSettings
    @Cmp                  INT,
    @User                 BIGINT,
    @CostMethod           TINYINT,
    @AllocBasis           TINYINT,
    @AllowPartialIssue    BIT,
    @AllowNegative        BIT,
    @ReserveOnRequest     BIT,
    @SeparateDuties       BIT,
    @MaxAutoVoucherDocs   INT,
    @AutoVoucherState     TINYINT,
    @DiffAccID            BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0
        THROW 52006, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52005, N'المستخدم غير موجود.', 1;
    IF @CostMethod IS NULL OR @CostMethod NOT IN (1, 2)
        THROW 52001, N'طريقة التكلفة غير صحيحة (1 = FIFO، 2 = متوسط مرجح).', 1;
    IF @AllocBasis IS NULL OR @AllocBasis NOT IN (1, 2, 3)
        THROW 52002, N'أساس توزيع التكاليف الإضافية غير صحيح (1 قيمة، 2 كمية، 3 وزن).', 1;
    IF @MaxAutoVoucherDocs IS NULL OR @MaxAutoVoucherDocs NOT BETWEEN 1 AND 5000
        THROW 52003, N'الحد الأقصى لمستندات القيد الآلي يجب أن يكون بين 1 و 5000.', 1;
    IF @AutoVoucherState IS NULL OR @AutoVoucherState NOT IN (0, 1)
        THROW 52004, N'حالة القيد الآلي الناتج يجب أن تكون 0 (مؤقت) أو 1 (مُرحّل).', 1;

    UPDATE dbo.Wrh_Settings WITH (UPDLOCK, HOLDLOCK)
       SET WsCostMethod = @CostMethod, WsAllocBasis = @AllocBasis,
           WsAllowPartialIssue = ISNULL(@AllowPartialIssue, 1), WsAllowNegative = ISNULL(@AllowNegative, 0),
           WsReserveOnRequest = ISNULL(@ReserveOnRequest, 1), WsSeparateDuties = ISNULL(@SeparateDuties, 1),
           WsMaxAutoVoucherDocs = @MaxAutoVoucherDocs, WsAutoVoucherState = @AutoVoucherState,
           WsDiffAccID = @DiffAccID, WsUpdatedBy = @User, WsUpdatedAt = SYSUTCDATETIME()
     WHERE WsCmpID = @Cmp;

    IF @@ROWCOUNT = 0
        INSERT dbo.Wrh_Settings
            (WsCmpID, WsCostMethod, WsAllocBasis, WsAllowPartialIssue, WsAllowNegative, WsReserveOnRequest,
             WsSeparateDuties, WsMaxAutoVoucherDocs, WsAutoVoucherState, WsDiffAccID, WsUpdatedBy, WsUpdatedAt)
        VALUES
            (@Cmp, @CostMethod, @AllocBasis, ISNULL(@AllowPartialIssue, 1), ISNULL(@AllowNegative, 0),
             ISNULL(@ReserveOnRequest, 1), ISNULL(@SeparateDuties, 1), @MaxAutoVoucherDocs, @AutoVoucherState,
             @DiffAccID, @User, SYSUTCDATETIME());
END;
GO

/* اختبار المرحلة 1 — يعمل داخل معاملة ويُرجَع (لا يترك أثرًا). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_NextDocNo') IS NULL THROW 52900, N'نفّذ Wrh_01_Settings_Numbering.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(60), Ok BIT, Info NVARCHAR(400));  -- متغير جدولي: لا يتأثر بالتراجع
CREATE TABLE #S (WsCmpID INT, WsCostMethod TINYINT, WsAllocBasis TINYINT, WsAllowPartialIssue BIT, WsAllowNegative BIT,
                 WsReserveOnRequest BIT, WsSeparateDuties BIT, WsMaxAutoVoucherDocs INT, WsAutoVoucherState TINYINT,
                 WsDiffAccID BIGINT, IsDefault BIT);

DECLARE @C1 INT = 99991, @C2 INT = 99992, @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @e INT, @no NVARCHAR(10), @no2 NVARCHAR(10);

IF @U IS NULL
BEGIN
    INSERT @R VALUES (N'مستخدم', 0, N'لا يوجد مستخدم في Mng_User');
END
ELSE
BEGIN
    BEGIN TRAN;

    -- 1) افتراضي بلا صف
    INSERT #S EXEC dbo.Wrh_SelectSettings @C1;
    INSERT @R SELECT N'S1 افتراضي', CASE WHEN WsCostMethod = 1 AND WsMaxAutoVoucherDocs = 500 AND IsDefault = 1 THEN 1 ELSE 0 END, N'' FROM #S;
    DELETE #S;

    -- 2) حفظ ثم قراءة
    EXEC dbo.Wrh_SaveSettings @C1, @U, 2, 2, 0, 1, 0, 0, 300, 0, NULL;
    INSERT #S EXEC dbo.Wrh_SelectSettings @C1;
    INSERT @R SELECT N'S2 حفظ/قراءة',
        CASE WHEN WsCostMethod = 2 AND WsAllocBasis = 2 AND WsAllowPartialIssue = 0 AND WsAllowNegative = 1
              AND WsReserveOnRequest = 0 AND WsSeparateDuties = 0 AND WsMaxAutoVoucherDocs = 300
              AND WsAutoVoucherState = 0 AND IsDefault = 0 THEN 1 ELSE 0 END, N'' FROM #S;
    DELETE #S;

    -- 3) تحديث ثانٍ لا يكرر الصف
    EXEC dbo.Wrh_SaveSettings @C1, @U, 1, 1, 1, 0, 1, 1, 500, 1, NULL;
    INSERT @R SELECT N'S3 صف واحد', CASE WHEN COUNT(*) = 1 THEN 1 ELSE 0 END, N'' FROM dbo.Wrh_Settings WHERE WsCmpID = @C1;

    -- 4) أخطاء الحفظ
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveSettings @C1, @U, 3, 1, 1, 0, 1, 1, 500, 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52001', CASE WHEN @e = 52001 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveSettings @C1, @U, 1, 9, 1, 0, 1, 1, 500, 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52002', CASE WHEN @e = 52002 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveSettings @C1, @U, 1, 1, 1, 0, 1, 1, 0, 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52003', CASE WHEN @e = 52003 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveSettings @C1, @U, 1, 1, 1, 0, 1, 1, 500, 5; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52004', CASE WHEN @e = 52004 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveSettings @C1, -5, 1, 1, 1, 0, 1, 1, 500, 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52005', CASE WHEN @e = 52005 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveSettings 0, @U, 1, 1, 1, 0, 1, 1, 500, 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52006', CASE WHEN @e = 52006 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- 5) الترقيم
    EXEC dbo.Wrh_NextDocNo @C1, 2026, 1, @no OUTPUT;
    INSERT @R VALUES (N'N1 أول رقم', CASE WHEN @no = N'2600000001' THEN 1 ELSE 0 END, @no);
    EXEC dbo.Wrh_NextDocNo @C1, 2026, 1, @no OUTPUT;
    INSERT @R VALUES (N'N2 التالي', CASE WHEN @no = N'2600000002' THEN 1 ELSE 0 END, @no);
    INSERT @R VALUES (N'N3 الطول 10', CASE WHEN LEN(@no) = 10 THEN 1 ELSE 0 END, @no);
    EXEC dbo.Wrh_NextDocNo @C1, 2026, 2, @no OUTPUT;
    INSERT @R VALUES (N'N4 نوع آخر يبدأ من 1', CASE WHEN @no = N'2600000001' THEN 1 ELSE 0 END, @no);
    EXEC dbo.Wrh_NextDocNo @C1, 2027, 1, @no OUTPUT;
    INSERT @R VALUES (N'N5 سنة أخرى', CASE WHEN @no = N'2700000001' THEN 1 ELSE 0 END, @no);
    EXEC dbo.Wrh_NextDocNo @C2, 2026, 1, @no OUTPUT;
    INSERT @R VALUES (N'N6 شركة أخرى', CASE WHEN @no = N'2600000001' THEN 1 ELSE 0 END, @no);

    -- 6) تجاوز التسلسل
    UPDATE dbo.Wrh_DocSeq SET DsLastNo = 99999999 WHERE DsCmpID = @C1 AND DsYear = 2026 AND DsDocType = 1;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_NextDocNo @C1, 2026, 1, @no OUTPUT; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52102 تجاوز', CASE WHEN @e = 52102 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- 7) أخطاء الترقيم
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_NextDocNo @C1, 1999, 1, @no OUTPUT; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52101', CASE WHEN @e = 52101 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #S;

/* =====================================================================
   المرحلة 2: الأطراف والمخازن ومجموعات المواد والوحدات والأصناف
   ---------------------------------------------------------------------
   الجداول : Prt_Party  Wrh_Warehouse  Wrh_ItemGroup (هرمية)  Wrh_Unit  Wrh_Item  Wrh_ItemUnit
   الإجراءات (إدراج/تعديل: المعرّف 0 = جديد، ويعيد المعرّف):
      Prt_SaveParty  Wrh_SaveWarehouse  Wrh_SaveItemGroup  Wrh_SaveUnit  Wrh_SaveItem  Wrh_SaveItemUnit
   لا حذف: التعطيل بحقل الفعّالية.

   القواعد:
     - حساب الجهة يبقى فارغًا حتى أول قيد (يُنشأ عند التوليد). حساب المخزن إلزامي.
     - الحساب (للمخزن/المجموعة/الجهة) يجب أن يكون موجودًا وورقيًا (بلا أبناء).
     - المجموعة الأب: لا حلقات، ولا تكون مجموعة تحمل أصنافًا.
     - الصنف لا يُربط إلا بمجموعة ورقية (بلا أبناء) ولها حساب مصروف.
     - الوحدة الأساس معامل تحويلها 1 ضمنيًا؛ الوحدات الثانوية بمعامل ثابت > 0.
   الأخطاء: 52200 مستخدم غير موجود   52201 شركة غير صحيحة   52202 الكود/الاسم فارغ
            52203 نوع/قيمة غير صحيحة  52204 كود مكرر        52205 حساب غير صالح (غير موجود أو ليس ورقيًا)
            52206 السجل غير موجود أو ليس للشركة   52207 مجموعة أب غير صالحة
            52208 المجموعة لا تقبل أصنافًا (ليست ورقية أو بلا حساب)   52209 معامل التحويل غير صحيح
            52210 وحدة غير موجودة   52211 المجموعة تحمل أصنافًا فلا تُفرَّغ من حسابها
   ملاحظة: التحقق من انتماء الحساب لنفس الشركة غير مضمّن لأن بنية Acc_Account غير مرفقة،
           ويُضاف إن أرسلت عمود الشركة فيه.
   نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF OBJECT_ID(N'dbo.Prt_Party', N'U') IS NULL
    CREATE TABLE dbo.Prt_Party
    (
        PrtID     BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Prt_Party PRIMARY KEY,
        PrtCmpID  INT           NOT NULL,
        PrtCode   NVARCHAR(30)  NOT NULL,
        PrtName   NVARCHAR(200) NOT NULL,
        PrtRole   TINYINT       NOT NULL,                  -- 1 مورد  2 جهة خدمات (ناقل/جمارك)  3 موظف عهدة
        PrtAccID  BIGINT        NULL,                      -- فارغ حتى أول قيد (العهدة: حساب منشأ مسبقًا)
        PrtActive BIT           NOT NULL CONSTRAINT DF_Prt_Party_Active DEFAULT (1),
        PrtCreatedBy BIGINT NULL, PrtCreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Prt_Party_At DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT CK_Prt_Party_Role CHECK (PrtRole IN (1, 2, 3))
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Prt_Party_Code' AND object_id = OBJECT_ID(N'dbo.Prt_Party'))
    CREATE UNIQUE INDEX UX_Prt_Party_Code ON dbo.Prt_Party (PrtCmpID, PrtCode);
GO

IF OBJECT_ID(N'dbo.Wrh_Warehouse', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Warehouse
    (
        WhID      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_Warehouse PRIMARY KEY,
        WhCmpID   INT           NOT NULL,
        WhCode    NVARCHAR(30)  NOT NULL,
        WhName    NVARCHAR(200) NOT NULL,
        WhAccID   BIGINT        NOT NULL,                  -- حساب المخزن (محور القيود)
        WhKeeper  BIGINT        NULL,                      -- أمين المخزن (مستخدم)
        WhActive  BIT           NOT NULL CONSTRAINT DF_Wrh_Warehouse_Active DEFAULT (1)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Wrh_Warehouse_Code' AND object_id = OBJECT_ID(N'dbo.Wrh_Warehouse'))
    CREATE UNIQUE INDEX UX_Wrh_Warehouse_Code ON dbo.Wrh_Warehouse (WhCmpID, WhCode);
GO

IF OBJECT_ID(N'dbo.Wrh_ItemGroup', N'U') IS NULL
    CREATE TABLE dbo.Wrh_ItemGroup
    (
        GrpID       BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_ItemGroup PRIMARY KEY,
        GrpCmpID    INT           NOT NULL,
        GrpParentID BIGINT        NULL CONSTRAINT FK_Wrh_ItemGroup_Parent REFERENCES dbo.Wrh_ItemGroup (GrpID),
        GrpCode     NVARCHAR(30)  NOT NULL,
        GrpName     NVARCHAR(200) NOT NULL,
        GrpAccID    BIGINT        NULL,                    -- حساب المصروف (للمجموعات التي تحمل أصنافًا)
        GrpActive   BIT           NOT NULL CONSTRAINT DF_Wrh_ItemGroup_Active DEFAULT (1)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Wrh_ItemGroup_Code' AND object_id = OBJECT_ID(N'dbo.Wrh_ItemGroup'))
    CREATE UNIQUE INDEX UX_Wrh_ItemGroup_Code ON dbo.Wrh_ItemGroup (GrpCmpID, GrpCode);
GO

IF OBJECT_ID(N'dbo.Wrh_Unit', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Unit
    (
        UnitID    BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_Unit PRIMARY KEY,
        UnitCmpID INT           NOT NULL,
        UnitName  NVARCHAR(60)  NOT NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Wrh_Unit_Name' AND object_id = OBJECT_ID(N'dbo.Wrh_Unit'))
    CREATE UNIQUE INDEX UX_Wrh_Unit_Name ON dbo.Wrh_Unit (UnitCmpID, UnitName);
GO

IF OBJECT_ID(N'dbo.Wrh_Item', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Item
    (
        ItemID         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_Item PRIMARY KEY,
        ItemCmpID      INT           NOT NULL,
        ItemCode       NVARCHAR(30)  NOT NULL,
        ItemName       NVARCHAR(200) NOT NULL,
        ItemGrpID      BIGINT        NOT NULL CONSTRAINT FK_Wrh_Item_Grp  REFERENCES dbo.Wrh_ItemGroup (GrpID),
        ItemBaseUnitID BIGINT        NOT NULL CONSTRAINT FK_Wrh_Item_Unit REFERENCES dbo.Wrh_Unit (UnitID),
        ItemActive     BIT           NOT NULL CONSTRAINT DF_Wrh_Item_Active DEFAULT (1)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Wrh_Item_Code' AND object_id = OBJECT_ID(N'dbo.Wrh_Item'))
    CREATE UNIQUE INDEX UX_Wrh_Item_Code ON dbo.Wrh_Item (ItemCmpID, ItemCode);
GO

IF OBJECT_ID(N'dbo.Wrh_ItemUnit', N'U') IS NULL
    CREATE TABLE dbo.Wrh_ItemUnit
    (
        ItemID  BIGINT NOT NULL CONSTRAINT FK_Wrh_ItemUnit_Item REFERENCES dbo.Wrh_Item (ItemID),
        UnitID  BIGINT NOT NULL CONSTRAINT FK_Wrh_ItemUnit_Unit REFERENCES dbo.Wrh_Unit (UnitID),
        Factor  DECIMAL(18,6) NOT NULL,                    -- كم من الوحدة الأساس في هذه الوحدة
        CONSTRAINT PK_Wrh_ItemUnit PRIMARY KEY (ItemID, UnitID),
        CONSTRAINT CK_Wrh_ItemUnit_Factor CHECK (Factor > 0)
    );
GO

/* ------------------------------------------------------------------ الأطراف */
CREATE OR ALTER PROCEDURE dbo.Prt_SaveParty
    @Cmp INT, @User BIGINT, @PrtID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @Role TINYINT, @AccID BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Code, N'') = N'' OR ISNULL(@Name, N'') = N'' THROW 52202, N'الكود والاسم مطلوبان.', 1;
    IF @Role IS NULL OR @Role NOT IN (1, 2, 3) THROW 52203, N'نوع الجهة غير صحيح (1 مورد، 2 جهة خدمات، 3 موظف عهدة).', 1;
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب الجهة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp AND PrtCode = @Code AND PrtID <> ISNULL(@PrtID, 0))
        THROW 52204, N'كود الجهة مستخدم من قبل.', 1;

    IF ISNULL(@PrtID, 0) = 0
    BEGIN
        INSERT dbo.Prt_Party (PrtCmpID, PrtCode, PrtName, PrtRole, PrtAccID, PrtActive, PrtCreatedBy)
        VALUES (@Cmp, @Code, @Name, @Role, @AccID, ISNULL(@Active, 1), @User);
        SET @PrtID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.Prt_Party
           SET PrtCode = @Code, PrtName = @Name, PrtRole = @Role, PrtAccID = @AccID, PrtActive = ISNULL(@Active, 1)
         WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'الجهة غير موجودة أو لا تتبع الشركة.', 1;
    END
    SELECT @PrtID AS PrtID;
END;
GO

/* ------------------------------------------------------------------ المخازن */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveWarehouse
    @Cmp INT, @User BIGINT, @WhID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT, @Keeper BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Code, N'') = N'' OR ISNULL(@Name, N'') = N'' THROW 52202, N'الكود والاسم مطلوبان.', 1;
    IF @AccID IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
       OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID)
        THROW 52205, N'حساب المخزن مطلوب ويجب أن يكون حسابًا ورقيًا.', 1;
    IF @Keeper IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @Keeper)
        THROW 52200, N'أمين المخزن غير موجود.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhCmpID = @Cmp AND WhCode = @Code AND WhID <> ISNULL(@WhID, 0))
        THROW 52204, N'كود المخزن مستخدم من قبل.', 1;

    IF ISNULL(@WhID, 0) = 0
    BEGIN
        INSERT dbo.Wrh_Warehouse (WhCmpID, WhCode, WhName, WhAccID, WhKeeper, WhActive)
        VALUES (@Cmp, @Code, @Name, @AccID, @Keeper, ISNULL(@Active, 1));
        SET @WhID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.Wrh_Warehouse
           SET WhCode = @Code, WhName = @Name, WhAccID = @AccID, WhKeeper = @Keeper, WhActive = ISNULL(@Active, 1)
         WHERE WhID = @WhID AND WhCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'المخزن غير موجود أو لا يتبع الشركة.', 1;
    END
    SELECT @WhID AS WhID;
END;
GO

/* ------------------------------------------------------------------ المجموعات */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItemGroup
    @Cmp INT, @User BIGINT, @GrpID BIGINT, @ParentID BIGINT = NULL, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Code, N'') = N'' OR ISNULL(@Name, N'') = N'' THROW 52202, N'الكود والاسم مطلوبان.', 1;
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المجموعة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpCode = @Code AND GrpID <> ISNULL(@GrpID, 0))
        THROW 52204, N'كود المجموعة مستخدم من قبل.', 1;

    -- الأب: للشركة نفسها، لا يحمل أصنافًا، ولا حلقة
    IF @ParentID IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID AND GrpCmpID = @Cmp)
            THROW 52207, N'المجموعة الأب غير موجودة أو لا تتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemGrpID = @ParentID)
            THROW 52207, N'المجموعة الأب تحمل أصنافًا فلا تقبل مجموعات فرعية.', 1;
        IF ISNULL(@GrpID, 0) > 0
        BEGIN
            DECLARE @Cyc INT = 0;
            ;WITH D AS
            (
                SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID
                UNION ALL
                SELECT g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN D ON g.GrpParentID = D.GrpID
            )
            SELECT @Cyc = COUNT(*) FROM D WHERE GrpID = @ParentID;
            IF @Cyc > 0 THROW 52207, N'لا يجوز جعل المجموعة أبًا لنفسها أو لأحد فروعها.', 1;
        END
    END

    IF ISNULL(@GrpID, 0) = 0
    BEGIN
        INSERT dbo.Wrh_ItemGroup (GrpCmpID, GrpParentID, GrpCode, GrpName, GrpAccID, GrpActive)
        VALUES (@Cmp, @ParentID, @Code, @Name, @AccID, ISNULL(@Active, 1));
        SET @GrpID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp)
            THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
        IF @AccID IS NULL AND EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemGrpID = @GrpID)
            THROW 52211, N'المجموعة تحمل أصنافًا فلا يجوز إفراغها من حساب المصروف.', 1;
        UPDATE dbo.Wrh_ItemGroup
           SET GrpParentID = @ParentID, GrpCode = @Code, GrpName = @Name, GrpAccID = @AccID, GrpActive = ISNULL(@Active, 1)
         WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
    END
    SELECT @GrpID AS GrpID;
END;
GO

/* ------------------------------------------------------------------ الوحدات */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveUnit
    @Cmp INT, @User BIGINT, @UnitID BIGINT, @Name NVARCHAR(60)
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'اسم الوحدة مطلوب.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Unit WHERE UnitCmpID = @Cmp AND UnitName = @Name AND UnitID <> ISNULL(@UnitID, 0))
        THROW 52204, N'اسم الوحدة مستخدم من قبل.', 1;

    IF ISNULL(@UnitID, 0) = 0
    BEGIN
        INSERT dbo.Wrh_Unit (UnitCmpID, UnitName) VALUES (@Cmp, @Name);
        SET @UnitID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.Wrh_Unit SET UnitName = @Name WHERE UnitID = @UnitID AND UnitCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'الوحدة غير موجودة أو لا تتبع الشركة.', 1;
    END
    SELECT @UnitID AS UnitID;
END;
GO

/* ------------------------------------------------------------------ الأصناف */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItem
    @Cmp INT, @User BIGINT, @ItemID BIGINT, @GrpID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @BaseUnitID BIGINT, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Code, N'') = N'' OR ISNULL(@Name, N'') = N'' THROW 52202, N'الكود والاسم مطلوبان.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp)
        THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpParentID = @GrpID)
       OR EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpAccID IS NULL)
        THROW 52208, N'الصنف يُربط بمجموعة ورقية (بلا مجموعات فرعية) ولها حساب مصروف.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Unit WHERE UnitID = @BaseUnitID AND UnitCmpID = @Cmp)
        THROW 52210, N'الوحدة الأساس غير موجودة أو لا تتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemCmpID = @Cmp AND ItemCode = @Code AND ItemID <> ISNULL(@ItemID, 0))
        THROW 52204, N'كود الصنف مستخدم من قبل.', 1;

    IF ISNULL(@ItemID, 0) = 0
    BEGIN
        INSERT dbo.Wrh_Item (ItemCmpID, ItemCode, ItemName, ItemGrpID, ItemBaseUnitID, ItemActive)
        VALUES (@Cmp, @Code, @Name, @GrpID, @BaseUnitID, ISNULL(@Active, 1));
        SET @ItemID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.Wrh_Item
           SET ItemCode = @Code, ItemName = @Name, ItemGrpID = @GrpID, ItemBaseUnitID = @BaseUnitID, ItemActive = ISNULL(@Active, 1)
         WHERE ItemID = @ItemID AND ItemCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'الصنف غير موجود أو لا يتبع الشركة.', 1;
        -- لا يبقى للوحدة الأساس صف تحويل ثانوي
        DELETE dbo.Wrh_ItemUnit WHERE ItemID = @ItemID AND UnitID = @BaseUnitID;
    END
    SELECT @ItemID AS ItemID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItemUnit
    @Cmp INT, @User BIGINT, @ItemID BIGINT, @UnitID BIGINT, @Factor DECIMAL(18,6)
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    DECLARE @Base BIGINT;
    SELECT @Base = ItemBaseUnitID FROM dbo.Wrh_Item WHERE ItemID = @ItemID AND ItemCmpID = @Cmp;
    IF @Base IS NULL THROW 52206, N'الصنف غير موجود أو لا يتبع الشركة.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Unit WHERE UnitID = @UnitID AND UnitCmpID = @Cmp)
        THROW 52210, N'الوحدة غير موجودة أو لا تتبع الشركة.', 1;
    IF @UnitID = @Base OR @Factor IS NULL OR @Factor <= 0
        THROW 52209, N'معامل التحويل يجب أن يكون أكبر من صفر، والوحدة الأساس لا يُضاف لها معامل.', 1;

    UPDATE dbo.Wrh_ItemUnit SET Factor = @Factor WHERE ItemID = @ItemID AND UnitID = @UnitID;
    IF @@ROWCOUNT = 0
        INSERT dbo.Wrh_ItemUnit (ItemID, UnitID, Factor) VALUES (@ItemID, @UnitID, @Factor);
END;
GO

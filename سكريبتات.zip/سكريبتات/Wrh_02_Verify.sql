/* اختبار المرحلة 2 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_SaveItem') IS NULL THROW 52900, N'نفّذ Wrh_02_Masters.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(60), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);

DECLARE @C INT = 99993, @C2 INT = 99994;
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Leaf BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                        WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @Parent BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                          WHERE EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @e INT, @id BIGINT, @gA BIGINT, @gB BIGINT, @gC BIGINT, @un1 BIGINT, @un2 BIGINT, @it BIGINT, @cnt INT, @f DECIMAL(18,6);

IF @U IS NULL OR @Leaf IS NULL OR @Parent IS NULL
BEGIN
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وحساب ورقي وحساب أب في بيانات الشركة');
END
ELSE
BEGIN
    BEGIN TRAN;

    -- الأطراف
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'S1', N'مورد تجريبي', 1, NULL, 1; SELECT @id = Id FROM #I;
    INSERT @R SELECT N'P1 مورد بلا حساب', CASE WHEN EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @id AND PrtAccID IS NULL AND PrtRole = 1) THEN 1 ELSE 0 END, N'';
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, @id, N'S1', N'مورد معدَّل', 1, NULL, 0;
    INSERT @R SELECT N'P2 تعديل', CASE WHEN EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @id AND PrtName = N'مورد معدَّل' AND PrtActive = 0) THEN 1 ELSE 0 END, N'';
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'S1', N'مكرر', 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P3 كود مكرر', CASE WHEN @e = 52204 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C2, @U, 0, N'S1', N'نفس الكود شركة أخرى', 1;
    INSERT @R VALUES (N'P4 كود في شركة أخرى', 1, N'');
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'S9', N'x', 7; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P5 نوع خاطئ', CASE WHEN @e = 52203 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'S9', N'x', 1, @Parent; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P6 حساب غير ورقي', CASE WHEN @e = 52205 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C2, @U, @id, N'S7', N'x', 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P7 تعديل جهة شركة أخرى', CASE WHEN @e = 52206 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- المخازن
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W1', N'مخزن 1', @Leaf, NULL, 1; SELECT @id = Id FROM #I;
    INSERT @R SELECT N'W1 مخزن', CASE WHEN EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @id AND WhAccID = @Leaf) THEN 1 ELSE 0 END, N'';
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W2', N'بلا حساب', NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'W2 حساب إلزامي', CASE WHEN @e = 52205 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W2', N'حساب أب', @Parent; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'W3 حساب غير ورقي', CASE WHEN @e = 52205 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- المجموعات: A (رئيسية) ← B (ورقية بحساب)
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'GA', N'رئيسية', NULL, 1; SELECT @gA = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @gA, N'GB', N'فرعية', @Leaf, 1; SELECT @gB = Id FROM #I;
    INSERT @R SELECT N'G1 هرمية', CASE WHEN EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @gB AND GrpParentID = @gA) THEN 1 ELSE 0 END, N'';
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemGroup @C, @U, @gA, @gB, N'GA', N'حلقة', NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'G2 منع الحلقة', CASE WHEN @e = 52207 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemGroup @C, @U, @gA, @gA, N'GA', N'أب نفسها', NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'G3 أب نفسها', CASE WHEN @e = 52207 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- الوحدات والأصناف
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'م٣'; SELECT @un1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'كجم'; SELECT @un2 = Id FROM #I;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'كجم'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'U1 اسم وحدة مكرر', CASE WHEN @e = 52204 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItem @C, @U, 0, @gA, N'I0', N'على رئيسية', @un1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'I1 صنف على مجموعة غير ورقية', CASE WHEN @e = 52208 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'GN', N'ورقية بلا حساب', NULL, 1; SELECT @gC = Id FROM #I;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItem @C, @U, 0, @gC, N'I0', N'مجموعة بلا حساب', @un1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'I2 مجموعة بلا حساب', CASE WHEN @e = 52208 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @gB, N'I1', N'رمل', @un1; SELECT @it = Id FROM #I;
    INSERT @R SELECT N'I3 صنف', CASE WHEN EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemID = @it AND ItemGrpID = @gB AND ItemBaseUnitID = @un1) THEN 1 ELSE 0 END, N'';
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItem @C, @U, 0, @gB, N'I1', N'مكرر', @un1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'I4 كود صنف مكرر', CASE WHEN @e = 52204 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- بعد وجود صنف: المجموعة لا تقبل فروعًا ولا تفرَّغ من حسابها
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @gB, N'GX', N'فرع تحت مجموعة فيها أصناف', NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'G4 أب يحمل أصنافًا', CASE WHEN @e = 52207 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemGroup @C, @U, @gB, @gA, N'GB', N'فرعية', NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'G5 تفريغ الحساب', CASE WHEN @e = 52211 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    -- وبعد وجود فرع تحت مجموعة لا تقبل صنفًا جديدًا
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItem @C, @U, 0, @gA, N'I9', N'على أب', @un1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'I5 صنف على أب فيه فروع', CASE WHEN @e = 52208 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- وحدات الصنف
    EXEC dbo.Wrh_SaveItemUnit @C, @U, @it, @un2, 1600;
    SELECT @f = Factor FROM dbo.Wrh_ItemUnit WHERE ItemID = @it AND UnitID = @un2;
    INSERT @R VALUES (N'IU1 معامل', CASE WHEN @f = 1600 THEN 1 ELSE 0 END, CONCAT(N'got ', @f));
    EXEC dbo.Wrh_SaveItemUnit @C, @U, @it, @un2, 1500;
    SELECT @cnt = COUNT(*), @f = MAX(Factor) FROM dbo.Wrh_ItemUnit WHERE ItemID = @it AND UnitID = @un2;
    INSERT @R VALUES (N'IU2 تحديث بلا تكرار', CASE WHEN @cnt = 1 AND @f = 1500 THEN 1 ELSE 0 END, CONCAT(@cnt, N'/', @f));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemUnit @C, @U, @it, @un2, 0; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'IU3 معامل صفر', CASE WHEN @e = 52209 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemUnit @C, @U, @it, @un1, 2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'IU4 الوحدة الأساس', CASE WHEN @e = 52209 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemUnit @C2, @U, @it, @un2, 2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'IU5 صنف شركة أخرى', CASE WHEN @e = 52206 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- مستخدم/شركة
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveUnit @C, -1, 0, N'س'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52200', CASE WHEN @e = 52200 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveUnit 0, @U, 0, N'س'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52201', CASE WHEN @e = 52201 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I;

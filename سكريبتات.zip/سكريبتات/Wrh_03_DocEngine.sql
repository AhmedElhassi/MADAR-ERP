/* =====================================================================
   المرحلة 3: محرك المستندات (رأس + بنود + روابط + حالات + سجل أحداث)
   ---------------------------------------------------------------------
   Wrh_DocTypeDef  : تعريف الأنواع (الرقم والاسم ومتطلبات الرأس ونوع المرجع) — يُضبط بالبيانات
   Wrh_Doc / Wrh_DocLine / Wrh_DocEvent
   الإجراءات: Wrh_SaveDoc  Wrh_DeleteDoc  Wrh_CancelDoc  Wrh_RecalcDocStatus  Wrh_SelectDoc

   المبادئ (كما اعتُمدت):
     - الأنواع التجارية (تصنيف 1: طلب مواد، طلب شراء، فاتورة شراء، أمر تحويل) تبدأ «مفتوحة»،
       وحالتها تُحسب من البنود: 1 مفتوح  2 منفذ جزئيًا  3 منفذ كليًا  9 ملغى.
     - العمليات الفعلية والمالية (تصنيف 2 و 3) حالتها 3 دائمًا (تؤثر عند الحفظ).
     - البند المرجعي: QtyReferred = ما استُعمل منه في مستندات لاحقة. لا تتجاوز كمية الربط المتبقي.
     - لا يُعدَّل ولا يُحذف مستند استُعمل منه شيء أو أُلغي منه؛ والتعديل = حذف وإدخال في معاملة واحدة.
     - الإلغاء للتجاري فقط، بسبب إلزامي، ويلغي المتبقي (بند أو مستند).
     - الكمية بالوحدة المُدخلة، وتُحفظ بالوحدة الأساس BaseQty = Qty × Factor (3 خانات).
     - أثر المخزون والقيود الآلية في مراحل لاحقة (يُربط بنفس هذه البنود).
     - النوعان 14 و 15 (تكلفة إضافية وتسوية) لا يمرّان من هذا المحرك (DtEngine = 0)؛ لهما إجراءات خاصة لاحقًا.
   صيغة @Lines (JSON): [{"ItemID":1,"UnitID":2,"Qty":5,"Price":10.5,"RefLineID":null}, ...]

   الأخطاء: 52301 نوع غير صحيح/غير مدعوم   52302 بيانات الرأس ناقصة   52303 بنود غير صحيحة
            52304 وحدة غير معرّفة للصنف     52305 لا يُعدَّل/يُحذف (استُعمل أو أُلغي)
            52306 مرجع غير صحيح أو كمية تتجاوز المتبقي   52307 لا شيء يُلغى أو النوع لا يقبل الإلغاء
            52308 السبب مطلوب   52309 المستند غير موجود أو لا يتبع الشركة
            52310 مخزن/جهة/مركز تكلفة غير صالح   52312 لا يُغيَّر تاريخ المستند إلى سنة أخرى
   يتطلب تنفيذ Wrh_01 و Wrh_02 أولًا. نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF OBJECT_ID(N'dbo.Wrh_DocTypeDef', N'U') IS NULL
    CREATE TABLE dbo.Wrh_DocTypeDef
    (
        DtType      TINYINT       NOT NULL CONSTRAINT PK_Wrh_DocTypeDef PRIMARY KEY,
        DtName      NVARCHAR(60)  NOT NULL,
        DtClass     TINYINT       NOT NULL,        -- 1 تجاري  2 عملية فعلية  3 مالي
        DtNeedWh    BIT NOT NULL, DtNeedWh2 BIT NOT NULL, DtNeedParty BIT NOT NULL,
        DtNeedCost  BIT NOT NULL, DtNeedRef BIT NOT NULL,
        DtRefType   TINYINT       NULL,            -- نوع المستند المرجعي المسموح (فارغ = لا مرجع)
        DtEngine    BIT           NOT NULL,        -- يمرّ من Wrh_SaveDoc
        CONSTRAINT CK_Wrh_DocTypeDef_Class CHECK (DtClass IN (1, 2, 3))
    );
GO
IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_DocTypeDef)
    INSERT dbo.Wrh_DocTypeDef (DtType, DtName, DtClass, DtNeedWh, DtNeedWh2, DtNeedParty, DtNeedCost, DtNeedRef, DtRefType, DtEngine)
    VALUES
     (1,  N'طلب مواد',            1, 0,0,0,1,0, NULL, 1),
     (2,  N'طلب شراء',            1, 0,0,0,0,0, 1,    1),
     (3,  N'فاتورة شراء',         1, 1,0,1,0,0, 2,    1),
     (4,  N'استلام مخزني',        2, 1,0,1,0,1, 3,    1),
     (5,  N'صرف مخزني',           2, 1,0,0,1,0, 1,    1),
     (6,  N'صرف مباشر',           2, 0,0,1,1,1, 3,    1),
     (7,  N'أمر تحويل',           1, 1,1,0,0,0, NULL, 1),
     (8,  N'استلام تحويل',        2, 1,1,0,0,1, 7,    1),
     (9,  N'استرجاع من جهة',      2, 1,0,0,1,0, NULL, 1),
     (10, N'ترجيع مخزني للمورد',  2, 1,0,1,0,1, 4,    1),
     (11, N'ترجيع مباشر للمورد',  2, 0,0,1,1,1, 6,    1),
     (12, N'إشعار دائن',          3, 0,0,1,0,1, 3,    1),
     (13, N'جرد',                 2, 1,0,0,0,0, NULL, 1),
     (14, N'تكلفة إضافية',        3, 0,0,1,0,1, NULL, 0),
     (15, N'تسوية تكلفة',         3, 0,0,1,0,1, NULL, 0);
GO

IF OBJECT_ID(N'dbo.Wrh_Doc', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Doc
    (
        DocID        BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_Doc PRIMARY KEY,
        DocCmpID     INT           NOT NULL,
        DocType      TINYINT       NOT NULL CONSTRAINT FK_Wrh_Doc_Type REFERENCES dbo.Wrh_DocTypeDef (DtType),
        DocYear      SMALLINT      NOT NULL,
        DocNo        NVARCHAR(10)  NOT NULL,
        DocDate      DATE          NOT NULL,
        DocStatus    TINYINT       NOT NULL CONSTRAINT DF_Wrh_Doc_Status DEFAULT (1),
        DocWhID      BIGINT        NULL,
        DocWh2ID     BIGINT        NULL,
        DocPartyID   BIGINT        NULL,
        DocCostCID   BIGINT        NULL,
        DocRefDocID  BIGINT        NULL,
        DocNotes     NVARCHAR(500) NULL,
        DocCreatedBy BIGINT        NOT NULL,
        DocCreatedAt DATETIME2(0)  NOT NULL CONSTRAINT DF_Wrh_Doc_At DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT CK_Wrh_Doc_Status CHECK (DocStatus IN (1, 2, 3, 9))
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Wrh_Doc_No' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE UNIQUE INDEX UX_Wrh_Doc_No ON dbo.Wrh_Doc (DocCmpID, DocYear, DocType, DocNo);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Doc_Open' AND object_id = OBJECT_ID(N'dbo.Wrh_Doc'))
    CREATE INDEX IX_Wrh_Doc_Open ON dbo.Wrh_Doc (DocCmpID, DocType, DocWhID) WHERE DocStatus IN (1, 2);
GO

IF OBJECT_ID(N'dbo.Wrh_DocLine', N'U') IS NULL
    CREATE TABLE dbo.Wrh_DocLine
    (
        LineID       BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_DocLine PRIMARY KEY,
        DocID        BIGINT        NOT NULL CONSTRAINT FK_Wrh_DocLine_Doc REFERENCES dbo.Wrh_Doc (DocID),
        DocLineNo       INT           NOT NULL,
        ItemID       BIGINT        NOT NULL CONSTRAINT FK_Wrh_DocLine_Item REFERENCES dbo.Wrh_Item (ItemID),
        UnitID       BIGINT        NOT NULL CONSTRAINT FK_Wrh_DocLine_Unit REFERENCES dbo.Wrh_Unit (UnitID),
        Factor       DECIMAL(18,6) NOT NULL,
        Qty          DECIMAL(18,3) NOT NULL,
        BaseQty      DECIMAL(18,3) NOT NULL,
        UnitPrice    DECIMAL(18,6) NULL,
        Amount       DECIMAL(18,3) NOT NULL CONSTRAINT DF_Wrh_DocLine_Amt DEFAULT (0),
        RefLineID    BIGINT        NULL CONSTRAINT FK_Wrh_DocLine_Ref REFERENCES dbo.Wrh_DocLine (LineID),
        QtyReferred  DECIMAL(18,3) NOT NULL CONSTRAINT DF_Wrh_DocLine_Rf DEFAULT (0),
        QtyCancelled DECIMAL(18,3) NOT NULL CONSTRAINT DF_Wrh_DocLine_Cn DEFAULT (0),
        CONSTRAINT CK_Wrh_DocLine_Qty  CHECK (Qty > 0 AND BaseQty > 0),
        CONSTRAINT CK_Wrh_DocLine_Used CHECK (QtyReferred >= 0 AND QtyCancelled >= 0 AND QtyReferred + QtyCancelled <= BaseQty)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_DocLine_Doc' AND object_id = OBJECT_ID(N'dbo.Wrh_DocLine'))
    CREATE INDEX IX_Wrh_DocLine_Doc ON dbo.Wrh_DocLine (DocID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_DocLine_Ref' AND object_id = OBJECT_ID(N'dbo.Wrh_DocLine'))
    CREATE INDEX IX_Wrh_DocLine_Ref ON dbo.Wrh_DocLine (RefLineID) WHERE RefLineID IS NOT NULL;
GO

IF OBJECT_ID(N'dbo.Wrh_DocEvent', N'U') IS NULL
    CREATE TABLE dbo.Wrh_DocEvent
    (
        EvID      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_DocEvent PRIMARY KEY,
        EvCmpID   INT           NOT NULL,
        EvDocID   BIGINT        NOT NULL,           -- بلا مفتاح أجنبي: يبقى السجل بعد حذف المستند
        EvDocNo   NVARCHAR(10)  NOT NULL,
        EvDocType TINYINT       NOT NULL,
        EvKind    TINYINT       NOT NULL,           -- 1 إنشاء  2 تعديل  3 حذف  4 إلغاء
        EvLineID  BIGINT        NULL,
        EvUser    BIGINT        NOT NULL,
        EvAt      DATETIME2(0)  NOT NULL CONSTRAINT DF_Wrh_DocEvent_At DEFAULT (SYSUTCDATETIME()),
        EvReason  NVARCHAR(200) NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_DocEvent_Doc' AND object_id = OBJECT_ID(N'dbo.Wrh_DocEvent'))
    CREATE INDEX IX_Wrh_DocEvent_Doc ON dbo.Wrh_DocEvent (EvDocID);
GO

/* ------------------------------------------------------------------ حساب حالة التجاري من بنوده */
CREATE OR ALTER PROCEDURE dbo.Wrh_RecalcDocStatus
    @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF @DocID IS NULL RETURN;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc AS d JOIN dbo.Wrh_DocTypeDef AS t ON t.DtType = d.DocType
                   WHERE d.DocID = @DocID AND t.DtClass = 1)
        RETURN;

    UPDATE d
       SET DocStatus = x.St
      FROM dbo.Wrh_Doc AS d
      CROSS APPLY (SELECT CASE
                            WHEN MIN(CASE WHEN l.QtyCancelled >= l.BaseQty THEN 1 ELSE 0 END) = 1 THEN 9
                            WHEN MIN(CASE WHEN l.QtyReferred + l.QtyCancelled >= l.BaseQty THEN 1 ELSE 0 END) = 1 THEN 3
                            WHEN MAX(CASE WHEN l.QtyReferred + l.QtyCancelled > 0 THEN 1 ELSE 0 END) = 1 THEN 2
                            ELSE 1 END AS St
                   FROM dbo.Wrh_DocLine AS l WHERE l.DocID = d.DocID) AS x
     WHERE d.DocID = @DocID;
END;
GO

/* ------------------------------------------------------------------ حفظ مستند (جديد @DocID = 0 أو تعديل) */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE,
    @WhID BIGINT = NULL, @Wh2ID BIGINT = NULL, @PartyID BIGINT = NULL, @CostCID BIGINT = NULL,
    @RefDocID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52302, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Class TINYINT, @NW BIT, @NW2 BIT, @NP BIT, @NC BIT, @NR BIT, @RT TINYINT;
    SELECT @Class = DtClass, @NW = DtNeedWh, @NW2 = DtNeedWh2, @NP = DtNeedParty, @NC = DtNeedCost,
           @NR = DtNeedRef, @RT = DtRefType
    FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type AND DtEngine = 1;
    IF @Class IS NULL THROW 52301, N'نوع المستند غير صحيح أو غير مدعوم في هذا المحرك.', 1;

    -- متطلبات الرأس
    IF @NW = 1 AND @WhID IS NULL THROW 52302, N'المخزن مطلوب لهذا النوع.', 1;
    IF @NW2 = 1 AND @Wh2ID IS NULL THROW 52302, N'المخزن المقابل مطلوب لهذا النوع.', 1;
    IF @NP = 1 AND @PartyID IS NULL THROW 52302, N'الجهة (المورد/العهدة) مطلوبة لهذا النوع.', 1;
    IF @NC = 1 AND @CostCID IS NULL THROW 52302, N'الجهة الطالبة (مركز التكلفة) مطلوبة لهذا النوع.', 1;
    IF @NR = 1 AND @RefDocID IS NULL THROW 52302, N'المستند المرجعي مطلوب لهذا النوع.', 1;

    IF @WhID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Wh2ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @Wh2ID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن المقابل غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @WhID IS NOT NULL AND @Wh2ID IS NOT NULL AND @WhID = @Wh2ID
        THROW 52310, N'المخزنان في التحويل يجب أن يكونا مختلفين.', 1;
    IF @PartyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
        THROW 52310, N'الجهة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    IF @CostCID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CostCID)
        THROW 52310, N'مركز التكلفة غير موجود.', 1;

    -- المستند المرجعي
    IF @RefDocID IS NOT NULL
    BEGIN
        IF @RT IS NULL THROW 52306, N'هذا النوع لا يقبل مستندًا مرجعيًا.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp AND DocType = @RT AND DocStatus <> 9)
            THROW 52306, N'المستند المرجعي غير صحيح (غير موجود أو نوعه لا يناسب أو ملغى أو لا يتبع الشركة).', 1;
    END

    -- البنود
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52303, N'بنود المستند غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6),
                     RefLineID BIGINT, Factor DECIMAL(18,6), BaseQty DECIMAL(18,3));

    INSERT #L (Ord, ItemID, UnitID, Qty, Price, RefLineID)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price, j.RefLineID
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID',
                                          Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price',
                                          RefLineID BIGINT '$.RefLineID') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) THROW 52303, N'يجب أن يحتوي المستند على بند واحد على الأقل.', 1;
    IF EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty <= 0 OR Price < 0)
        THROW 52303, N'كل بند يحتاج صنفًا ووحدة وكمية أكبر من صفر وسعرًا غير سالب.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS
               (SELECT 1 FROM dbo.Wrh_Item AS i WHERE i.ItemID = l.ItemID AND i.ItemCmpID = @Cmp AND i.ItemActive = 1))
        THROW 52303, N'صنف غير موجود أو معطّل أو لا يتبع الشركة.', 1;

    UPDATE l
       SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l
      JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL)
        THROW 52304, N'وحدة غير معرّفة لهذا الصنف (ليست الأساس ولا ثانوية بمعامل تحويل).', 1;
    UPDATE #L SET BaseQty = ROUND(Qty * Factor, 3);
    IF EXISTS (SELECT 1 FROM #L WHERE BaseQty <= 0) THROW 52303, N'الكمية بالوحدة الأساس تساوي صفرًا.', 1;

    -- ربط البنود بالمرجع
    IF @RefDocID IS NOT NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM #L AS l WHERE l.RefLineID IS NULL OR NOT EXISTS
                   (SELECT 1 FROM dbo.Wrh_DocLine AS r WHERE r.LineID = l.RefLineID AND r.DocID = @RefDocID AND r.ItemID = l.ItemID))
            THROW 52306, N'كل بند يجب أن يرتبط ببند من المستند المرجعي ولنفس الصنف.', 1;
    END
    ELSE IF EXISTS (SELECT 1 FROM #L WHERE RefLineID IS NOT NULL)
        THROW 52306, N'لا يجوز ربط بند بمرجع دون تحديد المستند المرجعي.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveDoc;

    BEGIN TRY
        DECLARE @OldRef BIGINT = NULL, @DocNo NVARCHAR(10), @Year INT = YEAR(@Date), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo, @OldRef = DocRefDocID
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;

            IF @OType IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52301, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52312, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
                THROW 52305, N'لا يجوز تعديل مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

            -- تراجع أثر الربط القديم ثم حذف البنود القديمة
            UPDATE r SET QtyReferred = r.QtyReferred - s.q
              FROM dbo.Wrh_DocLine AS r
              JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;
            DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;

            UPDATE dbo.Wrh_Doc
               SET DocDate = @Date, DocWhID = @WhID, DocWh2ID = @Wh2ID, DocPartyID = @PartyID,
                   DocCostCID = @CostCID, DocRefDocID = @RefDocID, DocNotes = @Notes
             WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocWh2ID,
                                DocPartyID, DocCostCID, DocRefDocID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, CASE WHEN @Class = 1 THEN 1 ELSE 3 END, @WhID, @Wh2ID,
                    @PartyID, @CostCID, @RefDocID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_DocLine (DocID, DocLineNo, ItemID, UnitID, Factor, Qty, BaseQty, UnitPrice, Amount, RefLineID)
        SELECT @DocID, ROW_NUMBER() OVER (ORDER BY l.Ord), l.ItemID, l.UnitID, l.Factor, l.Qty, l.BaseQty, l.Price,
               CAST(ROUND(l.Qty * ISNULL(l.Price, 0), 3) AS DECIMAL(18,3)), l.RefLineID
        FROM #L AS l;

        -- أثر الربط الجديد (مع التحقق من المتبقي)
        IF EXISTS (SELECT 1
                   FROM (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
                   JOIN dbo.Wrh_DocLine AS r WITH (UPDLOCK) ON r.LineID = s.RefLineID
                   WHERE r.BaseQty - r.QtyReferred - r.QtyCancelled < s.q)
            THROW 52306, N'الكمية تتجاوز المتبقي في البند المرجعي.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred + s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
            ON s.RefLineID = r.LineID;

        EXEC dbo.Wrh_RecalcDocStatus @RefDocID;
        IF @OldRef IS NOT NULL AND ISNULL(@OldRef, 0) <> ISNULL(@RefDocID, 0)
            EXEC dbo.Wrh_RecalcDocStatus @OldRef;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo, d.DocStatus FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveDoc;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ حذف مستند */
CREATE OR ALTER PROCEDURE dbo.Wrh_DeleteDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_DeleteDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10), @Ref BIGINT;
        SELECT @Type = DocType, @No = DocNo, @Ref = DocRefDocID
        FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
        IF @Type IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
            THROW 52305, N'لا يجوز حذف مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred - s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;

        DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;
        DELETE dbo.Wrh_Doc WHERE DocID = @DocID;
        EXEC dbo.Wrh_RecalcDocStatus @Ref;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 3, @User, NULLIF(LTRIM(RTRIM(@Reason)), N''));

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_DeleteDoc;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ إلغاء المتبقي (مستند أو بند) — للتجاري فقط */
CREATE OR ALTER PROCEDURE dbo.Wrh_CancelDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @LineID BIGINT = NULL, @Reason NVARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;
    SET @Reason = LTRIM(RTRIM(@Reason));
    IF ISNULL(@Reason, N'') = N'' THROW 52308, N'سبب الإلغاء مطلوب.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_CancelDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10), @Class TINYINT;
        SELECT @Type = d.DocType, @No = d.DocNo, @Class = t.DtClass
        FROM dbo.Wrh_Doc AS d WITH (UPDLOCK, HOLDLOCK)
        JOIN dbo.Wrh_DocTypeDef AS t ON t.DtType = d.DocType
        WHERE d.DocID = @DocID AND d.DocCmpID = @Cmp;
        IF @Type IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
        IF @Class <> 1 THROW 52307, N'الإلغاء للمستندات التجارية فقط.', 1;

        UPDATE dbo.Wrh_DocLine
           SET QtyCancelled = BaseQty - QtyReferred
         WHERE DocID = @DocID AND (@LineID IS NULL OR LineID = @LineID)
           AND BaseQty - QtyReferred - QtyCancelled > 0;
        IF @@ROWCOUNT = 0 THROW 52307, N'لا يوجد متبقٍ ليُلغى.', 1;

        EXEC dbo.Wrh_RecalcDocStatus @DocID;
        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvLineID, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 4, @LineID, @User, @Reason);

        IF @Started = 1 COMMIT;
        SELECT DocStatus FROM dbo.Wrh_Doc WHERE DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_CancelDoc;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ قراءة مستند (مجموعتا نتائج: الرأس ثم البنود) */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectDoc
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocCmpID = @Cmp)
        THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;

    SELECT d.DocID, d.DocType, t.DtName AS DocTypeName, d.DocNo, d.DocDate, d.DocStatus,
           CASE d.DocStatus WHEN 1 THEN N'مفتوح' WHEN 2 THEN N'منفذ جزئيًا' WHEN 3 THEN N'منفذ كليًا' WHEN 9 THEN N'ملغى' END AS StatusName,
           d.DocWhID, w.WhName, d.DocWh2ID, w2.WhName AS Wh2Name, d.DocPartyID, p.PrtName,
           d.DocCostCID, d.DocRefDocID, r.DocNo AS RefDocNo, d.DocNotes, d.DocCreatedBy, d.DocCreatedAt
    FROM dbo.Wrh_Doc AS d
    JOIN dbo.Wrh_DocTypeDef AS t ON t.DtType = d.DocType
    LEFT JOIN dbo.Wrh_Warehouse AS w  ON w.WhID  = d.DocWhID
    LEFT JOIN dbo.Wrh_Warehouse AS w2 ON w2.WhID = d.DocWh2ID
    LEFT JOIN dbo.Prt_Party     AS p  ON p.PrtID = d.DocPartyID
    LEFT JOIN dbo.Wrh_Doc       AS r  ON r.DocID = d.DocRefDocID
    WHERE d.DocID = @DocID AND d.DocCmpID = @Cmp;

    SELECT l.LineID, l.DocLineNo, l.ItemID, i.ItemCode, i.ItemName, l.UnitID, u.UnitName, l.Factor, l.Qty, l.BaseQty,
           l.UnitPrice, l.Amount, l.RefLineID, l.QtyReferred, l.QtyCancelled,
           CAST(l.BaseQty - l.QtyReferred - l.QtyCancelled AS DECIMAL(18,3)) AS QtyRemaining
    FROM dbo.Wrh_DocLine AS l
    JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
    JOIN dbo.Wrh_Unit AS u ON u.UnitID = l.UnitID
    WHERE l.DocID = @DocID
    ORDER BY l.DocLineNo;
END;
GO

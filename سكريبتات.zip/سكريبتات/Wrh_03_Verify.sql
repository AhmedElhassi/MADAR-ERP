/* اختبار المرحلة 3 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_SaveDoc') IS NULL THROW 52900, N'نفّذ Wrh_03_DocEngine.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #D (DocID BIGINT, DocNo NVARCHAR(10), DocStatus TINYINT);

DECLARE @C INT = 99995, @C2 INT = 99996;
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Leaf BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                        WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);

DECLARE @e INT, @W1 BIGINT, @W2 BIGINT, @P BIGINT, @G BIGINT, @u1 BIGINT, @u2 BIGINT, @u3 BIGINT, @it BIGINT;
DECLARE @dA BIGINT, @dB BIGINT, @dC BIGINT, @dD BIGINT, @pr1 BIGINT, @pr2 BIGINT, @lA BIGINT, @lC BIGINT, @lB BIGINT;
DECLARE @no NVARCHAR(10), @st TINYINT, @q DECIMAL(18,3), @n INT, @L NVARCHAR(MAX), @d DATE = '2026-03-01';
DECLARE @s1 NVARCHAR(20), @s2 NVARCHAR(20), @s3 NVARCHAR(20), @sit NVARCHAR(20);

IF @U IS NULL OR @Leaf IS NULL OR @CC IS NULL
BEGIN
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وحساب ورقي ومركز تكلفة');
END
ELSE
BEGIN
    BEGIN TRAN;

    -- بيانات أساسية
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W1', N'مخزن 1', @Leaf; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W2', N'مخزن 2', @Leaf; SELECT @W2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'P1', N'مورد', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'G1', N'مجموعة', @Leaf; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'م٣'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'كجم'; SELECT @u2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'لتر'; SELECT @u3 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I1', N'رمل', @u1; SELECT @it = Id FROM #I;
    EXEC dbo.Wrh_SaveItemUnit @C, @U, @it, @u2, 1500;

    SET @s1 = CAST(@it AS NVARCHAR(20)); SET @s2 = CAST(@u1 AS NVARCHAR(20)); SET @s3 = CAST(@u2 AS NVARCHAR(20));

    -- T1: طلب مواد بوحدتين (بند 10 م٣ + بند 2 كجم؟ هنا 2 بالوحدة الثانوية = 3000 أساس)
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":10,"Price":5},{"ItemID":', @s1, N',"UnitID":', @s3, N',"Qty":2}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; SELECT @dB = DocID, @no = DocNo, @st = DocStatus FROM #D;
    INSERT @R VALUES (N'T1 طلب مواد مفتوح', CASE WHEN @st = 1 AND @no = N'2600000001' THEN 1 ELSE 0 END, CONCAT(@no, N'/', @st));
    SELECT @q = BaseQty FROM dbo.Wrh_DocLine WHERE DocID = @dB AND DocLineNo = 2;
    INSERT @R VALUES (N'T2 تحويل الوحدة الثانوية', CASE WHEN @q = 3000 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));
    SELECT @q = Amount FROM dbo.Wrh_DocLine WHERE DocID = @dB AND DocLineNo = 1;
    INSERT @R VALUES (N'T3 المبلغ', CASE WHEN @q = 50 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));

    -- مستند A: بند واحد 10 م٣
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":10,"Price":5}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; SELECT @dA = DocID, @no = DocNo FROM #D;
    INSERT @R VALUES (N'T4 تسلسل الأرقام', CASE WHEN @no = N'2600000002' THEN 1 ELSE 0 END, @no);
    SELECT @lA = LineID FROM dbo.Wrh_DocLine WHERE DocID = @dA; SET @sit = CAST(@lA AS NVARCHAR(20));

    -- طلب شراء 1 بكمية 3 مرتبط بـ A
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":3,"RefLineID":', @sit, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 2, @d, NULL, NULL, NULL, NULL, @dA, NULL, @L; SELECT @pr1 = DocID, @no = DocNo FROM #D;
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @dA; SELECT @q = QtyReferred FROM dbo.Wrh_DocLine WHERE LineID = @lA;
    INSERT @R VALUES (N'T5 منفذ جزئيًا', CASE WHEN @st = 2 AND @q = 3 THEN 1 ELSE 0 END, CONCAT(@st, N'/', @q));
    INSERT @R VALUES (N'T6 ترقيم نوع آخر', CASE WHEN @no = N'2600000001' THEN 1 ELSE 0 END, @no);

    -- طلب شراء 2 بكمية 7 (الباقي) => A منفذ كليًا
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":7,"RefLineID":', @sit, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 2, @d, NULL, NULL, NULL, NULL, @dA, NULL, @L; SELECT @pr2 = DocID FROM #D;
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @dA;
    INSERT @R VALUES (N'T7 منفذ كليًا', CASE WHEN @st = 3 THEN 1 ELSE 0 END, CONCAT(N'got ', @st));

    -- تجاوز الكمية
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":1,"RefLineID":', @sit, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 2, @d, NULL, NULL, NULL, NULL, @dA, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T8 تجاوز المتبقي', CASE WHEN @e = 52306 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- حذف طلب الشراء 2 يعيد A إلى جزئي
    EXEC dbo.Wrh_DeleteDoc @C, @U, @pr2, N'اختبار';
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @dA; SELECT @q = QtyReferred FROM dbo.Wrh_DocLine WHERE LineID = @lA;
    INSERT @R VALUES (N'T9 حذف يعيد الأثر', CASE WHEN @st = 2 AND @q = 3 THEN 1 ELSE 0 END, CONCAT(@st, N'/', @q));
    INSERT @R VALUES (N'T10 سجل الحذف', CASE WHEN EXISTS (SELECT 1 FROM dbo.Wrh_DocEvent WHERE EvDocID = @pr2 AND EvKind = 3 AND EvDocNo IS NOT NULL) THEN 1 ELSE 0 END, N'');

    -- تعديل طلب الشراء 1 إلى 4
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":4,"RefLineID":', @sit, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, @pr1, 2, @d, NULL, NULL, NULL, NULL, @dA, NULL, @L;
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @dA; SELECT @q = QtyReferred FROM dbo.Wrh_DocLine WHERE LineID = @lA;
    INSERT @R VALUES (N'T11 تعديل يحدّث الأثر', CASE WHEN @st = 2 AND @q = 4 THEN 1 ELSE 0 END, CONCAT(@st, N'/', @q));
    INSERT @R VALUES (N'T12 رقم المعدَّل ثابت', CASE WHEN (SELECT COUNT(*) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 2) = 1 THEN 1 ELSE 0 END, N'');

    -- قفل A بعد الاستعمال
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":10,"Price":5}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, @dA, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T13 منع تعديل المستعمَل', CASE WHEN @e = 52305 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C, @U, @dA; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T14 منع حذف المستعمَل', CASE WHEN @e = 52305 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- إلغاء
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":5}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; SELECT @dC = DocID FROM #D;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_CancelDoc @C, @U, @dC, NULL, N'  '; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T15 سبب الإلغاء إلزامي', CASE WHEN @e = 52308 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    DELETE #I; INSERT #I EXEC dbo.Wrh_CancelDoc @C, @U, @dC, NULL, N'لم تعد مطلوبة';
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @dC;
    INSERT @R VALUES (N'T16 ملغى', CASE WHEN @st = 9 THEN 1 ELSE 0 END, CONCAT(N'got ', @st));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_CancelDoc @C, @U, @dC, NULL, N'مرة ثانية'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T17 لا شيء يُلغى', CASE WHEN @e = 52307 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    INSERT @R VALUES (N'T18 سجل الإنشاء والإلغاء', CASE WHEN (SELECT COUNT(*) FROM dbo.Wrh_DocEvent WHERE EvDocID = @dC) = 2 THEN 1 ELSE 0 END, N'');

    -- إلغاء المتبقي بعد استعمال جزئي => منفذ كليًا
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":5}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; SELECT @dD = DocID FROM #D;
    SELECT @lB = LineID FROM dbo.Wrh_DocLine WHERE DocID = @dD;
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":2,"RefLineID":', CAST(@lB AS NVARCHAR(20)), N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 2, @d, NULL, NULL, NULL, NULL, @dD, NULL, @L;
    DELETE #I; INSERT #I EXEC dbo.Wrh_CancelDoc @C, @U, @dD, NULL, N'إلغاء الباقي';
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @dD; SELECT @q = QtyCancelled FROM dbo.Wrh_DocLine WHERE LineID = @lB;
    INSERT @R VALUES (N'T19 إلغاء المتبقي', CASE WHEN @st = 3 AND @q = 3 THEN 1 ELSE 0 END, CONCAT(@st, N'/', @q));

    -- عملية فعلية: صرف مخزني => حالة 3 ولا إلغاء
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":1}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @n = DocID, @st = DocStatus FROM #D;
    INSERT @R VALUES (N'T20 العملية الفعلية منفذة', CASE WHEN @st = 3 THEN 1 ELSE 0 END, CONCAT(N'got ', @st));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_CancelDoc @C, @U, @n, NULL, N'x'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T21 لا إلغاء للفعلية', CASE WHEN @e = 52307 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- أخطاء الرأس
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 14, @d, NULL, NULL, @P, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52301 نوع خارج المحرك', CASE WHEN @e = 52301 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52302 مركز تكلفة ناقص', CASE WHEN @e = 52302 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52302 مرجع الاستلام إلزامي', CASE WHEN @e = 52302 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @dA, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52306 نوع المرجع خاطئ', CASE WHEN @e = 52306 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @d, @W1, @W1, NULL, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52310 تحويل لنفس المخزن', CASE WHEN @e = 52310 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @d, @W1, @W2, NULL, NULL, NULL, NULL, @L; SELECT @st = DocStatus FROM #D;
    INSERT @R VALUES (N'T22 أمر تحويل مفتوح', CASE WHEN @st = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @st));

    -- أخطاء البنود
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, N'[]'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52303 بلا بنود', CASE WHEN @e = 52303 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, N'ليس json'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52303 JSON خاطئ', CASE WHEN @e = 52303 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":0}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52303 كمية صفر', CASE WHEN @e = 52303 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', CAST(@u3 AS NVARCHAR(20)), N',"Qty":1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @d, NULL, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52304 وحدة غير معرّفة', CASE WHEN @e = 52304 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- تغيير السنة عند التعديل، ومستند من شركة أخرى
    SET @L = CONCAT(N'[{"ItemID":', @s1, N',"UnitID":', @s2, N',"Qty":5}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, @n, 5, '2027-01-05', @W1, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52312 تغيير السنة', CASE WHEN @e = 52312 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C2, @U, 0, 2, @d, NULL, NULL, NULL, NULL, @dA, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52306 مرجع شركة أخرى', CASE WHEN @e = 52306 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C2, @U, @n; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'E 52309 حذف مستند شركة أخرى', CASE WHEN @e = 52309 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #D;

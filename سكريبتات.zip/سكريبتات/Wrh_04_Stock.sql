/* =====================================================================
   المرحلة 4: محرك المخزون (FIFO) — الأرصدة والطبقات والاستهلاك والحجز
   ---------------------------------------------------------------------
   الجداول : Wrh_Stock (رصيد وحجز لكل مخزن/صنف)   Wrh_Layer (طبقات بجذورها)   Wrh_LayerUse (استهلاك الطبقات)
   الإجراءات: Wrh_StockApply / Wrh_StockReverse (يُستدعيان من Wrh_SaveDoc/DeleteDoc داخل معاملة المستند)
              Wrh_ConsumeFifo   Wrh_SuggestReturnCost   Wrh_SelectStock
   ويُعاد في هذا الملف تعريف Wrh_SaveDoc و Wrh_DeleteDoc و Wrh_CancelDoc بإضافة ربط المخزون فقط.

   أثر الأنواع عند الحفظ:
     4 استلام مخزني     : تدخل طبقة بقيمة البند (القيمة هي الأصل)، جذرها نفسها.
     5 صرف مخزني        : يخرج من أقدم الطبقات؛ لا يتجاوز المتاح (الرصيد − المحجوز)؛ لا رصيد سالب.
     7 أمر تحويل        : يحجز الكمية في المخزن الصارف (المخزن الأول = الصارف، والثاني = المستلم).
     8 استلام تحويل     : (المخزن الأول = المستلم، والثاني = الصارف) يفرج الحجز، ويخرج بتكلفة الطبقات،
                          وتدخل المستلم طبقة لكل طبقة خرجت بنفس القيمة والجذر وتاريخ الطبقة الأصلية.
     9 استرجاع من جهة   : طبقة واحدة جذر نفسها. السعر: إن أُدخل فهو المعتمد، وإن تُرك (0/فارغ) فآخر صرف
                          للجهة ثم آخر طبقة في المخزن؛ وإن لم يوجد خطأ 52406 (يدخله المستخدم يدويًا).
     10 ترجيع مخزني     : يخرج من طبقة الاستلام الأصلية فقط وبحد متبقيها.
   التقريب: صرف جزء من طبقة = الكمية × تكلفة الوحدة (3 خانات)، وآخر ما يتبقى منها يأخذ باقي قيمتها كاملًا.
   التعديل/الحذف: يعكس الأثر ثم يعيده؛ ولا يُسمح إن كانت طبقة العملية قد استُهلك منها (52410).
   إلغاء أمر تحويل: يُفرج عن حجز متبقيه.

   الأخطاء: 52401 المتاح لا يكفي   52402 الحجز لا يكفي (استلام تحويل)
            52403 كمية الترجيع تتجاوز متبقي طبقة الاستلام   52404 اتجاه استلام التحويل لا يطابق الأمر
            52406 تعذّر تحديد تكلفة الاسترجاع   52410 لا يمكن عكس العملية (استُهلكت طبقتها أو حُجز رصيدها)
   ملاحظة: إعداد WsAllowNegative غير مفعّل بعد؛ الرصيد السالب ممنوع دائمًا في هذه المرحلة.
   يتطلب Wrh_01 و Wrh_02 و Wrh_03 أولًا. نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF OBJECT_ID(N'dbo.Wrh_Stock', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Stock
    (
        StkCmpID    INT NOT NULL,
        StkWhID     BIGINT NOT NULL CONSTRAINT FK_Wrh_Stock_Wh   REFERENCES dbo.Wrh_Warehouse (WhID),
        StkItemID   BIGINT NOT NULL CONSTRAINT FK_Wrh_Stock_Item REFERENCES dbo.Wrh_Item (ItemID),
        StkQty      DECIMAL(18,3) NOT NULL CONSTRAINT DF_Wrh_Stock_Qty DEFAULT (0),
        StkReserved DECIMAL(18,3) NOT NULL CONSTRAINT DF_Wrh_Stock_Rsv DEFAULT (0),
        CONSTRAINT PK_Wrh_Stock PRIMARY KEY (StkWhID, StkItemID),
        CONSTRAINT CK_Wrh_Stock_Qty CHECK (StkQty >= 0),
        CONSTRAINT CK_Wrh_Stock_Rsv CHECK (StkReserved >= 0 AND StkReserved <= StkQty)
    );
GO

IF OBJECT_ID(N'dbo.Wrh_Layer', N'U') IS NULL
    CREATE TABLE dbo.Wrh_Layer
    (
        LayerID     BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_Layer PRIMARY KEY,
        LyCmpID     INT NOT NULL,
        LyWhID      BIGINT NOT NULL,
        LyItemID    BIGINT NOT NULL,
        LyRootID    BIGINT NOT NULL CONSTRAINT DF_Wrh_Layer_Root DEFAULT (0),
        LyDate      DATE NOT NULL,
        LyQtyIn     DECIMAL(18,3) NOT NULL,
        LyQtyRem    DECIMAL(18,3) NOT NULL,
        LyValueIn   DECIMAL(18,3) NOT NULL,
        LyValueRem  DECIMAL(18,3) NOT NULL,
        LyUnitCost  DECIMAL(18,6) NOT NULL,
        LySrcLineID BIGINT NOT NULL,
        CONSTRAINT CK_Wrh_Layer_Qty CHECK (LyQtyIn > 0 AND LyQtyRem >= 0 AND LyQtyRem <= LyQtyIn),
        CONSTRAINT CK_Wrh_Layer_Val CHECK (LyValueIn >= 0 AND LyValueRem >= 0 AND LyValueRem <= LyValueIn)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Layer_Fifo' AND object_id = OBJECT_ID(N'dbo.Wrh_Layer'))
    CREATE INDEX IX_Wrh_Layer_Fifo ON dbo.Wrh_Layer (LyWhID, LyItemID, LyDate, LayerID) INCLUDE (LyQtyRem, LyValueRem, LyUnitCost) WHERE LyQtyRem > 0;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Layer_Src' AND object_id = OBJECT_ID(N'dbo.Wrh_Layer'))
    CREATE INDEX IX_Wrh_Layer_Src ON dbo.Wrh_Layer (LySrcLineID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_Layer_Root' AND object_id = OBJECT_ID(N'dbo.Wrh_Layer'))
    CREATE INDEX IX_Wrh_Layer_Root ON dbo.Wrh_Layer (LyRootID);
GO

IF OBJECT_ID(N'dbo.Wrh_LayerUse', N'U') IS NULL
    CREATE TABLE dbo.Wrh_LayerUse
    (
        UseID      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_LayerUse PRIMARY KEY,
        UseLineID  BIGINT NOT NULL,
        UseLayerID BIGINT NOT NULL CONSTRAINT FK_Wrh_LayerUse_Layer REFERENCES dbo.Wrh_Layer (LayerID),
        UseQty     DECIMAL(18,3) NOT NULL,
        UseValue   DECIMAL(18,3) NOT NULL,
        CONSTRAINT CK_Wrh_LayerUse CHECK (UseQty > 0 AND UseValue >= 0)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_LayerUse_Line' AND object_id = OBJECT_ID(N'dbo.Wrh_LayerUse'))
    CREATE INDEX IX_Wrh_LayerUse_Line ON dbo.Wrh_LayerUse (UseLineID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_LayerUse_Layer' AND object_id = OBJECT_ID(N'dbo.Wrh_LayerUse'))
    CREATE INDEX IX_Wrh_LayerUse_Layer ON dbo.Wrh_LayerUse (UseLayerID);
GO

/* ------------------------------------------------------------------ صف الرصيد */
CREATE OR ALTER PROCEDURE dbo.Wrh_StockEnsure
    @Cmp INT, @Wh BIGINT, @Item BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @Item)
        INSERT dbo.Wrh_Stock (StkCmpID, StkWhID, StkItemID) VALUES (@Cmp, @Wh, @Item);
END;
GO

/* ------------------------------------------------------------------ الصرف من الطبقات بترتيب FIFO */
CREATE OR ALTER PROCEDURE dbo.Wrh_ConsumeFifo
    @Wh BIGINT, @Item BIGINT, @Qty DECIMAL(18,3), @UseLineID BIGINT,
    @LayerOnly BIGINT = NULL, @Total DECIMAL(18,3) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @need DECIMAL(18,3) = @Qty, @lid BIGINT, @rem DECIMAL(18,3), @vrem DECIMAL(18,3),
            @cost DECIMAL(18,6), @take DECIMAL(18,3), @val DECIMAL(18,3);
    SET @Total = 0;

    DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
        SELECT LayerID, LyQtyRem, LyValueRem, LyUnitCost
        FROM dbo.Wrh_Layer WITH (UPDLOCK)
        WHERE LyWhID = @Wh AND LyItemID = @Item AND LyQtyRem > 0 AND (@LayerOnly IS NULL OR LayerID = @LayerOnly)
        ORDER BY LyDate, LayerID;
    OPEN cur;
    FETCH NEXT FROM cur INTO @lid, @rem, @vrem, @cost;
    WHILE @@FETCH_STATUS = 0 AND @need > 0
    BEGIN
        SET @take = CASE WHEN @need < @rem THEN @need ELSE @rem END;
        SET @val  = CASE WHEN @take = @rem THEN @vrem ELSE ROUND(@take * @cost, 3) END;   -- آخر ما يتبقى يأخذ الباقي كاملًا
        IF @val > @vrem SET @val = @vrem;

        UPDATE dbo.Wrh_Layer SET LyQtyRem = LyQtyRem - @take, LyValueRem = LyValueRem - @val WHERE LayerID = @lid;
        INSERT dbo.Wrh_LayerUse (UseLineID, UseLayerID, UseQty, UseValue) VALUES (@UseLineID, @lid, @take, @val);

        SET @need = @need - @take;
        SET @Total = @Total + @val;
        FETCH NEXT FROM cur INTO @lid, @rem, @vrem, @cost;
    END
    CLOSE cur; DEALLOCATE cur;

    IF @need > 0 THROW 52401, N'الكمية المتاحة في طبقات المخزن لا تكفي.', 1;
END;
GO

/* ------------------------------------------------------------------ تكلفة الاسترجاع المقترحة */
CREATE OR ALTER PROCEDURE dbo.Wrh_SuggestReturnCostCore
    @Cmp INT, @Wh BIGINT, @Item BIGINT, @CostCID BIGINT, @Cost DECIMAL(18,6) OUTPUT, @Src TINYINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @Cost = NULL; SET @Src = 0;

    DECLARE @LastDoc BIGINT, @sq DECIMAL(18,3), @sv DECIMAL(18,3);
    SELECT TOP 1 @LastDoc = d.DocID
    FROM dbo.Wrh_Doc AS d
    WHERE d.DocCmpID = @Cmp AND d.DocType = 5 AND d.DocCostCID = @CostCID
      AND EXISTS (SELECT 1 FROM dbo.Wrh_DocLine AS l WHERE l.DocID = d.DocID AND l.ItemID = @Item)
    ORDER BY d.DocDate DESC, d.DocID DESC;

    IF @LastDoc IS NOT NULL
    BEGIN
        SELECT @sq = SUM(u.UseQty), @sv = SUM(u.UseValue)
        FROM dbo.Wrh_DocLine AS l JOIN dbo.Wrh_LayerUse AS u ON u.UseLineID = l.LineID
        WHERE l.DocID = @LastDoc AND l.ItemID = @Item;
        IF ISNULL(@sq, 0) > 0
        BEGIN
            SET @Cost = ROUND(CAST(@sv AS DECIMAL(18,6)) / @sq, 6);
            SET @Src = 1;
            RETURN;
        END
    END

    SELECT TOP 1 @Cost = LyUnitCost
    FROM dbo.Wrh_Layer
    WHERE LyCmpID = @Cmp AND LyWhID = @Wh AND LyItemID = @Item
    ORDER BY LyDate DESC, LayerID DESC;
    IF @Cost IS NOT NULL SET @Src = 2;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SuggestReturnCost
    @Cmp INT, @Wh BIGINT, @Item BIGINT, @CostCID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @c DECIMAL(18,6), @s TINYINT;
    EXEC dbo.Wrh_SuggestReturnCostCore @Cmp, @Wh, @Item, @CostCID, @c OUTPUT, @s OUTPUT;
    SELECT @c AS UnitCostBase, @s AS CostSource;   -- 1 آخر صرف للجهة  2 آخر طبقة في المخزن  0 لا يوجد
END;
GO

/* ------------------------------------------------------------------ أثر المستند على المخزون */
CREATE OR ALTER PROCEDURE dbo.Wrh_StockApply
    @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Cmp INT, @Type TINYINT, @Wh BIGINT, @Wh2 BIGINT, @CC BIGINT, @Date DATE, @RefDoc BIGINT;
    SELECT @Cmp = DocCmpID, @Type = DocType, @Wh = DocWhID, @Wh2 = DocWh2ID, @CC = DocCostCID,
           @Date = DocDate, @RefDoc = DocRefDocID
    FROM dbo.Wrh_Doc WHERE DocID = @DocID;
    IF @Type IS NULL OR @Type NOT IN (4, 5, 7, 8, 9, 10) RETURN;

    IF @Type = 8
    BEGIN
        DECLARE @OW BIGINT, @OW2 BIGINT;
        SELECT @OW = DocWhID, @OW2 = DocWh2ID FROM dbo.Wrh_Doc WHERE DocID = @RefDoc;
        IF @OW <> @Wh2 OR @OW2 <> @Wh
            THROW 52404, N'اتجاه استلام التحويل لا يطابق أمر التحويل (المخزن الأول هو المستلم والثاني هو الصارف).', 1;
    END

    DECLARE @lid BIGINT, @item BIGINT, @q DECIMAL(18,3), @amt DECIMAL(18,3), @ref BIGINT,
            @avail DECIMAL(18,3), @tot DECIMAL(18,3), @v DECIMAL(18,3), @cost DECIMAL(18,6), @src TINYINT,
            @layer BIGINT, @lrem DECIMAL(18,3), @rsv DECIMAL(18,3);

    DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
        SELECT LineID, ItemID, BaseQty, Amount, RefLineID FROM dbo.Wrh_DocLine WHERE DocID = @DocID ORDER BY ItemID, DocLineNo;
    OPEN cur;
    FETCH NEXT FROM cur INTO @lid, @item, @q, @amt, @ref;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.Wrh_StockEnsure @Cmp, @Wh, @item;
        IF @Type = 8 EXEC dbo.Wrh_StockEnsure @Cmp, @Wh2, @item;

        IF @Type = 4   -- استلام
        BEGIN
            INSERT dbo.Wrh_Layer (LyCmpID, LyWhID, LyItemID, LyRootID, LyDate, LyQtyIn, LyQtyRem, LyValueIn, LyValueRem, LyUnitCost, LySrcLineID)
            VALUES (@Cmp, @Wh, @item, 0, @Date, @q, @q, @amt, @amt, ROUND(@amt / @q, 6), @lid);
            UPDATE dbo.Wrh_Layer SET LyRootID = LayerID WHERE LySrcLineID = @lid AND LyRootID = 0;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END
        ELSE IF @Type = 5   -- صرف
        BEGIN
            SELECT @avail = StkQty - StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            IF @avail < @q THROW 52401, N'الكمية المتاحة في المخزن (بعد المحجوز) لا تكفي لهذا الصرف.', 1;
            EXEC dbo.Wrh_ConsumeFifo @Wh, @item, @q, @lid, NULL, @tot OUTPUT;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END
        ELSE IF @Type = 7   -- أمر تحويل: حجز
        BEGIN
            SELECT @avail = StkQty - StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            IF @avail < @q THROW 52401, N'الكمية المتاحة في المخزن (بعد المحجوز) لا تكفي لحجز هذا التحويل.', 1;
            UPDATE dbo.Wrh_Stock SET StkReserved = StkReserved + @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END
        ELSE IF @Type = 8   -- استلام تحويل: الصارف = @Wh2
        BEGIN
            SELECT @rsv = StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh2 AND StkItemID = @item;
            IF @rsv < @q THROW 52402, N'الحجز في المخزن الصارف لا يغطي كمية هذا الاستلام.', 1;
            UPDATE dbo.Wrh_Stock SET StkReserved = StkReserved - @q WHERE StkWhID = @Wh2 AND StkItemID = @item;

            EXEC dbo.Wrh_ConsumeFifo @Wh2, @item, @q, @lid, NULL, @tot OUTPUT;

            INSERT dbo.Wrh_Layer (LyCmpID, LyWhID, LyItemID, LyRootID, LyDate, LyQtyIn, LyQtyRem, LyValueIn, LyValueRem, LyUnitCost, LySrcLineID)
            SELECT @Cmp, @Wh, @item, s.LyRootID, s.LyDate, u.UseQty, u.UseQty, u.UseValue, u.UseValue,
                   ROUND(u.UseValue / u.UseQty, 6), @lid
            FROM dbo.Wrh_LayerUse AS u JOIN dbo.Wrh_Layer AS s ON s.LayerID = u.UseLayerID
            WHERE u.UseLineID = @lid;

            UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @q WHERE StkWhID = @Wh2 AND StkItemID = @item;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q WHERE StkWhID = @Wh  AND StkItemID = @item;
        END
        ELSE IF @Type = 9   -- استرجاع من جهة
        BEGIN
            IF ISNULL(@amt, 0) > 0 SET @v = @amt;
            ELSE
            BEGIN
                EXEC dbo.Wrh_SuggestReturnCostCore @Cmp, @Wh, @item, @CC, @cost OUTPUT, @src OUTPUT;
                IF @cost IS NULL THROW 52406, N'تعذّر تحديد تكلفة الاسترجاع (لا صرف سابق للجهة ولا طبقة في المخزن)؛ أدخل السعر يدويًا.', 1;
                SET @v = ROUND(@q * @cost, 3);
            END
            INSERT dbo.Wrh_Layer (LyCmpID, LyWhID, LyItemID, LyRootID, LyDate, LyQtyIn, LyQtyRem, LyValueIn, LyValueRem, LyUnitCost, LySrcLineID)
            VALUES (@Cmp, @Wh, @item, 0, @Date, @q, @q, @v, @v, ROUND(@v / @q, 6), @lid);
            UPDATE dbo.Wrh_Layer SET LyRootID = LayerID WHERE LySrcLineID = @lid AND LyRootID = 0;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END
        ELSE IF @Type = 10   -- ترجيع مخزني للمورد: من طبقة الاستلام الأصلية فقط
        BEGIN
            SET @layer = NULL;
            SELECT @layer = LayerID, @lrem = LyQtyRem FROM dbo.Wrh_Layer WITH (UPDLOCK)
            WHERE LySrcLineID = @ref AND LyWhID = @Wh;
            IF @layer IS NULL THROW 52403, N'طبقة الاستلام الأصلية غير موجودة في هذا المخزن.', 1;
            IF @lrem < @q THROW 52403, N'كمية الترجيع تتجاوز المتبقي في طبقة الاستلام الأصلية.', 1;

            SELECT @avail = StkQty - StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            IF @avail < @q THROW 52401, N'الكمية المتاحة في المخزن (بعد المحجوز) لا تكفي لهذا الترجيع.', 1;

            EXEC dbo.Wrh_ConsumeFifo @Wh, @item, @q, @lid, @layer, @tot OUTPUT;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END

        FETCH NEXT FROM cur INTO @lid, @item, @q, @amt, @ref;
    END
    CLOSE cur; DEALLOCATE cur;
END;
GO

/* ------------------------------------------------------------------ عكس أثر المستند */
CREATE OR ALTER PROCEDURE dbo.Wrh_StockReverse
    @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Type TINYINT, @Wh BIGINT, @Wh2 BIGINT;
    SELECT @Type = DocType, @Wh = DocWhID, @Wh2 = DocWh2ID FROM dbo.Wrh_Doc WHERE DocID = @DocID;
    IF @Type IS NULL OR @Type NOT IN (4, 5, 7, 8, 9, 10) RETURN;

    DECLARE @lid BIGINT, @item BIGINT, @q DECIMAL(18,3), @avail DECIMAL(18,3);

    DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
        SELECT LineID, ItemID, BaseQty FROM dbo.Wrh_DocLine WHERE DocID = @DocID ORDER BY ItemID, DocLineNo;
    OPEN cur;
    FETCH NEXT FROM cur INTO @lid, @item, @q;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Type IN (4, 9, 8)   -- عمليات أنشأت طبقات في @Wh
        BEGIN
            IF EXISTS (SELECT 1 FROM dbo.Wrh_Layer WHERE LySrcLineID = @lid AND LyWhID = @Wh AND LyQtyRem <> LyQtyIn)
                THROW 52410, N'لا يمكن تعديل/حذف هذه العملية: استُهلك جزء من الطبقة التي أنشأتها.', 1;
            SELECT @avail = StkQty - StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            IF @avail < @q
                THROW 52410, N'لا يمكن تعديل/حذف هذه العملية: الرصيد الحالي (بعد المحجوز) لا يغطي كميتها.', 1;
            DELETE dbo.Wrh_Layer WHERE LySrcLineID = @lid AND LyWhID = @Wh;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END

        IF @Type IN (5, 10, 8)   -- عمليات استهلكت طبقات: تُعاد
        BEGIN
            UPDATE l SET LyQtyRem = l.LyQtyRem + u.q, LyValueRem = l.LyValueRem + u.v
              FROM dbo.Wrh_Layer AS l
              JOIN (SELECT UseLayerID, SUM(UseQty) AS q, SUM(UseValue) AS v FROM dbo.Wrh_LayerUse
                    WHERE UseLineID = @lid GROUP BY UseLayerID) AS u ON u.UseLayerID = l.LayerID;
            DELETE dbo.Wrh_LayerUse WHERE UseLineID = @lid;
            IF @Type IN (5, 10)
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q WHERE StkWhID = @Wh AND StkItemID = @item;
            ELSE
            BEGIN
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q, StkReserved = StkReserved + @q WHERE StkWhID = @Wh2 AND StkItemID = @item;
            END
        END

        IF @Type = 7
            UPDATE dbo.Wrh_Stock SET StkReserved = StkReserved - @q WHERE StkWhID = @Wh AND StkItemID = @item;

        FETCH NEXT FROM cur INTO @lid, @item, @q;
    END
    CLOSE cur; DEALLOCATE cur;
END;
GO

/* ------------------------------------------------------------------ عرض الأرصدة */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectStock
    @Cmp INT, @WhID BIGINT = NULL, @ItemID BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT s.StkWhID, w.WhName, s.StkItemID, i.ItemCode, i.ItemName,
           s.StkQty, s.StkReserved, CAST(s.StkQty - s.StkReserved AS DECIMAL(18,3)) AS StkAvailable,
           CAST(ISNULL(v.Val, 0) AS DECIMAL(18,3)) AS StkValue,
           CAST(CASE WHEN s.StkQty > 0 THEN ISNULL(v.Val, 0) / s.StkQty ELSE 0 END AS DECIMAL(18,6)) AS StkAvgCost
    FROM dbo.Wrh_Stock AS s
    JOIN dbo.Wrh_Warehouse AS w ON w.WhID = s.StkWhID
    JOIN dbo.Wrh_Item AS i ON i.ItemID = s.StkItemID
    OUTER APPLY (SELECT SUM(LyValueRem) AS Val FROM dbo.Wrh_Layer
                 WHERE LyWhID = s.StkWhID AND LyItemID = s.StkItemID AND LyQtyRem > 0) AS v
    WHERE s.StkCmpID = @Cmp AND (@WhID IS NULL OR s.StkWhID = @WhID) AND (@ItemID IS NULL OR s.StkItemID = @ItemID)
    ORDER BY w.WhName, i.ItemCode;
END;
GO

/* ===== إعادة تعريف الإجراءات الثلاثة بربط المخزون (التغيير فقط: استدعاء Wrh_StockApply / Wrh_StockReverse / تحرير حجز أمر التحويل الملغى) ===== */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE,
    @WhID BIGINT = NULL, @Wh2ID BIGINT = NULL, @PartyID BIGINT = NULL, @CostCID BIGINT = NULL,
    @RefDocID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52302, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Class TINYINT, @NW BIT, @NW2 BIT, @NP BIT, @NC BIT, @NR BIT, @RT TINYINT;
    SELECT @Class = DtClass, @NW = DtNeedWh, @NW2 = DtNeedWh2, @NP = DtNeedParty, @NC = DtNeedCost,
           @NR = DtNeedRef, @RT = DtRefType
    FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type AND DtEngine = 1;
    IF @Class IS NULL THROW 52301, N'نوع المستند غير صحيح أو غير مدعوم في هذا المحرك.', 1;

    -- متطلبات الرأس
    IF @NW = 1 AND @WhID IS NULL THROW 52302, N'المخزن مطلوب لهذا النوع.', 1;
    IF @NW2 = 1 AND @Wh2ID IS NULL THROW 52302, N'المخزن المقابل مطلوب لهذا النوع.', 1;
    IF @NP = 1 AND @PartyID IS NULL THROW 52302, N'الجهة (المورد/العهدة) مطلوبة لهذا النوع.', 1;
    IF @NC = 1 AND @CostCID IS NULL THROW 52302, N'الجهة الطالبة (مركز التكلفة) مطلوبة لهذا النوع.', 1;
    IF @NR = 1 AND @RefDocID IS NULL THROW 52302, N'المستند المرجعي مطلوب لهذا النوع.', 1;

    IF @WhID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Wh2ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @Wh2ID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن المقابل غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @WhID IS NOT NULL AND @Wh2ID IS NOT NULL AND @WhID = @Wh2ID
        THROW 52310, N'المخزنان في التحويل يجب أن يكونا مختلفين.', 1;
    IF @PartyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
        THROW 52310, N'الجهة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    IF @CostCID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CostCID)
        THROW 52310, N'مركز التكلفة غير موجود.', 1;

    -- المستند المرجعي
    IF @RefDocID IS NOT NULL
    BEGIN
        IF @RT IS NULL THROW 52306, N'هذا النوع لا يقبل مستندًا مرجعيًا.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp AND DocType = @RT AND DocStatus <> 9)
            THROW 52306, N'المستند المرجعي غير صحيح (غير موجود أو نوعه لا يناسب أو ملغى أو لا يتبع الشركة).', 1;
    END

    -- البنود
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52303, N'بنود المستند غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6),
                     RefLineID BIGINT, Factor DECIMAL(18,6), BaseQty DECIMAL(18,3));

    INSERT #L (Ord, ItemID, UnitID, Qty, Price, RefLineID)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price, j.RefLineID
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID',
                                          Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price',
                                          RefLineID BIGINT '$.RefLineID') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) THROW 52303, N'يجب أن يحتوي المستند على بند واحد على الأقل.', 1;
    IF EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty <= 0 OR Price < 0)
        THROW 52303, N'كل بند يحتاج صنفًا ووحدة وكمية أكبر من صفر وسعرًا غير سالب.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS
               (SELECT 1 FROM dbo.Wrh_Item AS i WHERE i.ItemID = l.ItemID AND i.ItemCmpID = @Cmp AND i.ItemActive = 1))
        THROW 52303, N'صنف غير موجود أو معطّل أو لا يتبع الشركة.', 1;

    UPDATE l
       SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l
      JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL)
        THROW 52304, N'وحدة غير معرّفة لهذا الصنف (ليست الأساس ولا ثانوية بمعامل تحويل).', 1;
    UPDATE #L SET BaseQty = ROUND(Qty * Factor, 3);
    IF EXISTS (SELECT 1 FROM #L WHERE BaseQty <= 0) THROW 52303, N'الكمية بالوحدة الأساس تساوي صفرًا.', 1;

    -- ربط البنود بالمرجع
    IF @RefDocID IS NOT NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM #L AS l WHERE l.RefLineID IS NULL OR NOT EXISTS
                   (SELECT 1 FROM dbo.Wrh_DocLine AS r WHERE r.LineID = l.RefLineID AND r.DocID = @RefDocID AND r.ItemID = l.ItemID))
            THROW 52306, N'كل بند يجب أن يرتبط ببند من المستند المرجعي ولنفس الصنف.', 1;
    END
    ELSE IF EXISTS (SELECT 1 FROM #L WHERE RefLineID IS NOT NULL)
        THROW 52306, N'لا يجوز ربط بند بمرجع دون تحديد المستند المرجعي.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveDoc;

    BEGIN TRY
        DECLARE @OldRef BIGINT = NULL, @DocNo NVARCHAR(10), @Year INT = YEAR(@Date), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo, @OldRef = DocRefDocID
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;

            IF @OType IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52301, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52312, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
                THROW 52305, N'لا يجوز تعديل مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

            EXEC dbo.Wrh_StockReverse @DocID;   -- يعكس أثر المخزون القديم
            -- تراجع أثر الربط القديم ثم حذف البنود القديمة
            UPDATE r SET QtyReferred = r.QtyReferred - s.q
              FROM dbo.Wrh_DocLine AS r
              JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;
            DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;

            UPDATE dbo.Wrh_Doc
               SET DocDate = @Date, DocWhID = @WhID, DocWh2ID = @Wh2ID, DocPartyID = @PartyID,
                   DocCostCID = @CostCID, DocRefDocID = @RefDocID, DocNotes = @Notes
             WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocWh2ID,
                                DocPartyID, DocCostCID, DocRefDocID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, CASE WHEN @Class = 1 THEN 1 ELSE 3 END, @WhID, @Wh2ID,
                    @PartyID, @CostCID, @RefDocID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_DocLine (DocID, DocLineNo, ItemID, UnitID, Factor, Qty, BaseQty, UnitPrice, Amount, RefLineID)
        SELECT @DocID, ROW_NUMBER() OVER (ORDER BY l.Ord), l.ItemID, l.UnitID, l.Factor, l.Qty, l.BaseQty, l.Price,
               CAST(ROUND(l.Qty * ISNULL(l.Price, 0), 3) AS DECIMAL(18,3)), l.RefLineID
        FROM #L AS l;

        -- أثر الربط الجديد (مع التحقق من المتبقي)
        IF EXISTS (SELECT 1
                   FROM (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
                   JOIN dbo.Wrh_DocLine AS r WITH (UPDLOCK) ON r.LineID = s.RefLineID
                   WHERE r.BaseQty - r.QtyReferred - r.QtyCancelled < s.q)
            THROW 52306, N'الكمية تتجاوز المتبقي في البند المرجعي.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred + s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
            ON s.RefLineID = r.LineID;

        EXEC dbo.Wrh_StockApply @DocID;     -- أثر المخزون الجديد

        EXEC dbo.Wrh_RecalcDocStatus @RefDocID;
        IF @OldRef IS NOT NULL AND ISNULL(@OldRef, 0) <> ISNULL(@RefDocID, 0)
            EXEC dbo.Wrh_RecalcDocStatus @OldRef;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo, d.DocStatus FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveDoc;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_DeleteDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_DeleteDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10), @Ref BIGINT;
        SELECT @Type = DocType, @No = DocNo, @Ref = DocRefDocID
        FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
        IF @Type IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
            THROW 52305, N'لا يجوز حذف مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

        EXEC dbo.Wrh_StockReverse @DocID;

        UPDATE r SET QtyReferred = r.QtyReferred - s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;

        DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;
        DELETE dbo.Wrh_Doc WHERE DocID = @DocID;
        EXEC dbo.Wrh_RecalcDocStatus @Ref;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 3, @User, NULLIF(LTRIM(RTRIM(@Reason)), N''));

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_DeleteDoc;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_CancelDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @LineID BIGINT = NULL, @Reason NVARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;
    SET @Reason = LTRIM(RTRIM(@Reason));
    IF ISNULL(@Reason, N'') = N'' THROW 52308, N'سبب الإلغاء مطلوب.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_CancelDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10), @Class TINYINT;
        SELECT @Type = d.DocType, @No = d.DocNo, @Class = t.DtClass
        FROM dbo.Wrh_Doc AS d WITH (UPDLOCK, HOLDLOCK)
        JOIN dbo.Wrh_DocTypeDef AS t ON t.DtType = d.DocType
        WHERE d.DocID = @DocID AND d.DocCmpID = @Cmp;
        IF @Type IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
        IF @Class <> 1 THROW 52307, N'الإلغاء للمستندات التجارية فقط.', 1;

        IF @Type = 7   -- أمر التحويل: يُفرَج عن حجز المتبقي الملغى
        BEGIN
            DECLARE @RWh BIGINT = (SELECT DocWhID FROM dbo.Wrh_Doc WHERE DocID = @DocID);
            UPDATE s SET StkReserved = s.StkReserved - x.q
              FROM dbo.Wrh_Stock AS s
              JOIN (SELECT ItemID, SUM(BaseQty - QtyReferred - QtyCancelled) AS q
                    FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND (@LineID IS NULL OR LineID = @LineID) AND BaseQty - QtyReferred - QtyCancelled > 0
                    GROUP BY ItemID) AS x ON x.ItemID = s.StkItemID
             WHERE s.StkWhID = @RWh;
        END

        UPDATE dbo.Wrh_DocLine
           SET QtyCancelled = BaseQty - QtyReferred
         WHERE DocID = @DocID AND (@LineID IS NULL OR LineID = @LineID)
           AND BaseQty - QtyReferred - QtyCancelled > 0;
        IF @@ROWCOUNT = 0 THROW 52307, N'لا يوجد متبقٍ ليُلغى.', 1;

        EXEC dbo.Wrh_RecalcDocStatus @DocID;
        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvLineID, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 4, @LineID, @User, @Reason);

        IF @Started = 1 COMMIT;
        SELECT DocStatus FROM dbo.Wrh_Doc WHERE DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_CancelDoc;
        THROW;
    END CATCH
END;
GO

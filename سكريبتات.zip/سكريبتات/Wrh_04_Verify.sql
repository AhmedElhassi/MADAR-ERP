/* اختبار المرحلة 4 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_StockApply') IS NULL THROW 52900, N'نفّذ Wrh_04_Stock.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #D (DocID BIGINT, DocNo NVARCHAR(10), DocStatus TINYINT);
CREATE TABLE #S (Cost DECIMAL(18,6), Src TINYINT);

DECLARE @C INT = 99997;
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Leaf BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                        WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @d DATE = '2026-03-01';

DECLARE @e INT, @W1 BIGINT, @W2 BIGINT, @P BIGINT, @G BIGINT, @u1 BIGINT, @I BIGINT, @I2 BIGINT, @I3 BIGINT, @I4 BIGINT;
DECLARE @sI NVARCHAR(20), @sI2 NVARCHAR(20), @sI3 NVARCHAR(20), @sI4 NVARCHAR(20), @sU NVARCHAR(20), @L NVARCHAR(MAX);
DECLARE @inv1 BIGINT, @inv2 BIGINT, @inv3 BIGINT, @inv4 BIGINT, @il1 BIGINT, @il2 BIGINT, @il3 BIGINT, @il4 BIGINT;
DECLARE @rc1 BIGINT, @rc2 BIGINT, @rc3 BIGINT, @rc4 BIGINT, @rl1 BIGINT, @rl2 BIGINT, @rl3 BIGINT, @rl4 BIGINT;
DECLARE @iss BIGINT, @ret BIGINT, @rtn BIGINT, @ord BIGINT, @ol BIGINT, @trf BIGINT, @x BIGINT;
DECLARE @ly1 BIGINT, @ly2 BIGINT, @ly3 BIGINT;
DECLARE @q DECIMAL(18,3), @v DECIMAL(18,3), @q2 DECIMAL(18,3), @n INT, @c6 DECIMAL(18,6), @sr TINYINT, @st TINYINT;

IF @U IS NULL OR @Leaf IS NULL OR @CC IS NULL
BEGIN
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وحساب ورقي ومركز تكلفة');
END
ELSE
BEGIN
    BEGIN TRAN;

    -- بيانات أساسية
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W1', N'مخزن 1', @Leaf; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W2', N'مخزن 2', @Leaf; SELECT @W2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'P1', N'مورد', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'G1', N'مجموعة', @Leaf; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I1', N'صنف 1', @u1; SELECT @I = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I2', N'صنف 2', @u1; SELECT @I2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I3', N'صنف 3', @u1; SELECT @I3 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I4', N'صنف 4', @u1; SELECT @I4 = Id FROM #I;
    SET @sI = CAST(@I AS NVARCHAR(20)); SET @sI2 = CAST(@I2 AS NVARCHAR(20)); SET @sI3 = CAST(@I3 AS NVARCHAR(20));
    SET @sI4 = CAST(@I4 AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20));

    -- فاتورة 1 (100 × 10) واستلام 1
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv1 = DocID FROM #D;
    SELECT @il1 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv1;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10,"RefLineID":', @il1, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv1, NULL, @L; SELECT @rc1 = DocID FROM #D;
    SELECT @rl1 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc1;
    SELECT @ly1 = LayerID FROM dbo.Wrh_Layer WHERE LySrcLineID = @rl1;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A1 رصيد بعد الاستلام 1', CASE WHEN @q = 100 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));
    INSERT @R SELECT N'A2 الطبقة 1: جذر نفسها وقيمتها', CASE WHEN LyRootID = LayerID AND LyValueIn = 1000 AND LyUnitCost = 10 THEN 1 ELSE 0 END, N'' FROM dbo.Wrh_Layer WHERE LayerID = @ly1;

    -- فاتورة 2 (50 × 12) واستلام 2
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":50,"Price":12}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv2 = DocID FROM #D;
    SELECT @il2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv2;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":50,"Price":12,"RefLineID":', @il2, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv2, NULL, @L; SELECT @rc2 = DocID FROM #D;
    SELECT @rl2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc2;
    SELECT @ly2 = LayerID FROM dbo.Wrh_Layer WHERE LySrcLineID = @rl2;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A3 رصيد بعد الاستلام 2', CASE WHEN @q = 150 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));

    -- صرف 120
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":120}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss = DocID FROM #D;
    SELECT @x = LineID FROM dbo.Wrh_DocLine WHERE DocID = @iss;
    SELECT @v = SUM(UseValue) FROM dbo.Wrh_LayerUse WHERE UseLineID = @x;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A4 قيمة الصرف FIFO ورصيده', CASE WHEN @v = 1240 AND @q = 30 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @q));
    SELECT @q = LyQtyRem FROM dbo.Wrh_Layer WHERE LayerID = @ly1; SELECT @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly2; SELECT @q2 = LyQtyRem FROM dbo.Wrh_Layer WHERE LayerID = @ly2;
    INSERT @R VALUES (N'A4b الطبقتان بعد الصرف', CASE WHEN @q = 0 AND @q2 = 30 AND @v = 360 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2, N'/', @v));

    -- صرف يتجاوز المتاح
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":31}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A5 منع الرصيد السالب', CASE WHEN @e = 52401 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @n = COUNT(*) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 5;
    INSERT @R VALUES (N'A5b لم يُحفظ مستند الفاشل', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- تعديل الصرف إلى 100 ثم إلى 120
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, @iss, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I; SELECT @q2 = LyQtyRem FROM dbo.Wrh_Layer WHERE LayerID = @ly2;
    INSERT @R VALUES (N'A6 تعديل الصرف إلى 100', CASE WHEN @q = 50 AND @q2 = 50 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":120}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, @iss, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I; SELECT @q2 = LyQtyRem, @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly2;
    INSERT @R VALUES (N'A7 العودة إلى 120', CASE WHEN @q = 30 AND @q2 = 30 AND @v = 360 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2, N'/', @v));

    -- ترجيع للمورد من استلام 2: 31 تتجاوز متبقي الطبقة (30)، ثم 10
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":31,"Price":12,"RefLineID":', @rl2, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 10, @d, @W1, NULL, @P, NULL, @rc2, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A8 ترجيع يتجاوز متبقي الطبقة', CASE WHEN @e = 52403 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":10,"Price":12,"RefLineID":', @rl2, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 10, @d, @W1, NULL, @P, NULL, @rc2, NULL, @L; SELECT @rtn = DocID FROM #D;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I; SELECT @q2 = LyQtyRem, @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly2;
    INSERT @R VALUES (N'A9 الترجيع من طبقته', CASE WHEN @q = 20 AND @q2 = 20 AND @v = 240 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2, N'/', @v));

    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C, @U, @rc2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A10 منع حذف استلام رُجِّع منه', CASE WHEN @e = 52305 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C, @U, @rc1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A11 منع حذف استلام استُهلكت طبقته', CASE WHEN @e = 52410 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A11b الرصيد لم يتغير بعد الرفض', CASE WHEN @q = 20 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));

    -- استرجاع من جهة بلا سعر: من آخر صرف (1240 / 120 = 10.333333)
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":20}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 9, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @ret = DocID FROM #D;
    SELECT @x = LineID FROM dbo.Wrh_DocLine WHERE DocID = @ret;
    SELECT @ly3 = LayerID FROM dbo.Wrh_Layer WHERE LySrcLineID = @x;
    SELECT @v = LyValueIn FROM dbo.Wrh_Layer WHERE LayerID = @ly3;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A12 قيمة الاسترجاع من آخر صرف', CASE WHEN @v = 206.667 AND @q = 40 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @q));
    INSERT @R SELECT N'A12b الاسترجاع جذر نفسه', CASE WHEN LyRootID = LayerID THEN 1 ELSE 0 END, N'' FROM dbo.Wrh_Layer WHERE LayerID = @ly3;

    -- اقتراح التكلفة
    DELETE #S; INSERT #S EXEC dbo.Wrh_SuggestReturnCost @C, @W1, @I, @CC;
    INSERT @R SELECT N'A13 اقتراح من آخر صرف', CASE WHEN Cost = 10.333333 AND Src = 1 THEN 1 ELSE 0 END, CONCAT(Cost, N'/', Src) FROM #S;

    SET @L = CONCAT(N'[{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":10,"Price":7}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv3 = DocID FROM #D;
    SELECT @il3 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv3;
    SET @L = CONCAT(N'[{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":10,"Price":7,"RefLineID":', @il3, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv3, NULL, @L;
    DELETE #S; INSERT #S EXEC dbo.Wrh_SuggestReturnCost @C, @W1, @I3, @CC;
    INSERT @R SELECT N'A14 اقتراح من آخر طبقة', CASE WHEN Cost = 7 AND Src = 2 THEN 1 ELSE 0 END, CONCAT(Cost, N'/', Src) FROM #S;
    DELETE #S; INSERT #S EXEC dbo.Wrh_SuggestReturnCost @C, @W1, @I4, @CC;
    INSERT @R SELECT N'A15 لا اقتراح', CASE WHEN Cost IS NULL AND Src = 0 THEN 1 ELSE 0 END, N'' FROM #S;
    SET @L = CONCAT(N'[{"ItemID":', @sI4, N',"UnitID":', @sU, N',"Qty":1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 9, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A16 استرجاع بلا تكلفة', CASE WHEN @e = 52406 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @sI4, N',"UnitID":', @sU, N',"Qty":2,"Price":4}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 9, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SELECT @v = SUM(LyValueIn) FROM dbo.Wrh_Layer WHERE LyItemID = @I4 AND LyWhID = @W1;
    INSERT @R VALUES (N'A16b استرجاع بسعر يدوي', CASE WHEN @v = 8 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));

    -- أمر تحويل W1 → W2 بكمية 30 من الصنف I (الرصيد 40)
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":30}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @d, @W1, @W2, NULL, NULL, NULL, NULL, @L; SELECT @ord = DocID FROM #D;
    SELECT @ol = LineID FROM dbo.Wrh_DocLine WHERE DocID = @ord;
    SELECT @q = StkReserved, @q2 = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A17 الحجز عند أمر التحويل', CASE WHEN @q = 30 AND @q2 = 40 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":1000}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @d, @W1, @W2, NULL, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A18 حجز أكبر من المتاح', CASE WHEN @e = 52401 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":11}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A19 الصرف لا يمس المحجوز', CASE WHEN @e = 52401 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- استلام تحويل باتجاه خاطئ
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":30,"RefLineID":', @ol, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 8, @d, @W1, @W2, NULL, NULL, @ord, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A20 اتجاه الاستلام خاطئ', CASE WHEN @e = 52404 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- استلام التحويل الصحيح (المستلم W2 أولًا ثم الصارف W1)
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 8, @d, @W2, @W1, NULL, NULL, @ord, NULL, @L; SELECT @trf = DocID FROM #D;
    SELECT @q = StkQty, @q2 = StkReserved FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A21a الصارف بعد الاستلام', CASE WHEN @q = 10 AND @q2 = 0 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W2 AND StkItemID = @I;
    SELECT @n = COUNT(*), @v = SUM(LyValueIn) FROM dbo.Wrh_Layer WHERE LyWhID = @W2 AND LyItemID = @I;
    INSERT @R VALUES (N'A21b المستلم: رصيد وطبقات وقيمة', CASE WHEN @q = 30 AND @n = 2 AND @v = 343.334 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @n, N'/', @v));
    INSERT @R SELECT N'A22 جذر الطبقة المنقولة', CASE WHEN LyRootID = @ly2 THEN 1 ELSE 0 END, CONCAT(LyRootID, N' vs ', @ly2) FROM dbo.Wrh_Layer WHERE LyWhID = @W2 AND LyItemID = @I AND LyValueIn = 240;
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @ord;
    INSERT @R VALUES (N'A23 الأمر منفذ كليًا', CASE WHEN @st = 3 THEN 1 ELSE 0 END, CONCAT(N'got ', @st));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":1,"RefLineID":', @ol, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 8, @d, @W2, @W1, NULL, NULL, @ord, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'A24 استلام يتجاوز الأمر', CASE WHEN @e = 52306 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- حذف استلام التحويل يعيد كل شيء
    EXEC dbo.Wrh_DeleteDoc @C, @U, @trf;
    SELECT @q = StkQty, @q2 = StkReserved FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A25a الصارف بعد الحذف', CASE WHEN @q = 40 AND @q2 = 30 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W2 AND StkItemID = @I; SELECT @n = COUNT(*) FROM dbo.Wrh_Layer WHERE LyWhID = @W2 AND LyItemID = @I;
    INSERT @R VALUES (N'A25b المستلم بعد الحذف', CASE WHEN @q = 0 AND @n = 0 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @n));
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @ord;
    INSERT @R VALUES (N'A25c الأمر عاد مفتوحًا', CASE WHEN @st = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @st));
    SELECT @q = LyQtyRem, @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly3;
    INSERT @R VALUES (N'A25d طبقة الاسترجاع عادت كاملة', CASE WHEN @q = 20 AND @v = 206.667 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v));

    -- إلغاء أمر التحويل يفرج الحجز
    DELETE #I; INSERT #I EXEC dbo.Wrh_CancelDoc @C, @U, @ord, NULL, N'اختبار';
    SELECT @q2 = StkReserved FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'A26 إلغاء الأمر يفرج الحجز', CASE WHEN @q2 = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @q2));

    -- حذف الصرف الأول يعيد الطبقات
    EXEC dbo.Wrh_DeleteDoc @C, @U, @iss;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    SELECT @q2 = LyQtyRem, @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'A27 حذف الصرف يعيد الطبقة 1', CASE WHEN @q = 160 AND @q2 = 100 AND @v = 1000 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2, N'/', @v));
    SELECT @q2 = SUM(LyQtyRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'A28 مجموع الطبقات = الرصيد', CASE WHEN @q2 = @q THEN 1 ELSE 0 END, CONCAT(@q2, N' vs ', @q));

    -- التقريب: 3 × 3.333333 => قيمة 10، ثم ثلاثة صرفات بكمية 1 تمامًا
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":3,"Price":3.333333}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv4 = DocID FROM #D;
    SELECT @il4 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv4;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":3,"Price":3.333333,"RefLineID":', @il4, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv4, NULL, @L; SELECT @rc4 = DocID FROM #D;
    SELECT @rl4 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc4;
    SELECT @v = LyValueIn FROM dbo.Wrh_Layer WHERE LySrcLineID = @rl4;
    INSERT @R VALUES (N'A29 قيمة الطبقة المقرّبة', CASE WHEN @v = 10 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":1},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":1},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":1}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @x = DocID FROM #D;
    SELECT @v = SUM(u.UseValue), @n = COUNT(*), @q = MAX(u.UseValue)
    FROM dbo.Wrh_LayerUse u JOIN dbo.Wrh_DocLine l ON l.LineID = u.UseLineID WHERE l.DocID = @x;
    INSERT @R VALUES (N'A30 مجموع الصرفات = القيمة بالضبط', CASE WHEN @v = 10 AND @n = 3 AND @q = 3.334 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @n, N'/', @q));
    SELECT @v = LyValueRem, @q = LyQtyRem FROM dbo.Wrh_Layer WHERE LySrcLineID = @rl4;
    INSERT @R VALUES (N'A31 الطبقة تنتهي بصفر', CASE WHEN @v = 0 AND @q = 0 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @q));

    ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #D; DROP TABLE #S;

﻿/* =====================================================================
   المرحلة 5: التكاليف الإضافية (نوع 14) ومستند تسوية التكلفة (نوع 15) — على FIFO
   ---------------------------------------------------------------------
   الجداول  : Wrh_CostLine (بنود التكلفة على رأس المستند)  Wrh_CostAdj (أثر كل بند مرجعي)
              Wrh_CostAdjLayer (ما أُضيف لكل طبقة، للعكس)
   الإجراءات: Wrh_SaveCostDoc  Wrh_DeleteCostDoc  Wrh_SelectCostDoc  Wrh_CostReverse
              ويُعاد تعريف Wrh_StockReverse بإضافة منع حذف/تعديل استلام عليه تكاليف أو تسوية.

   القواعد (كما اعتُمدت):
     - نوع 14: بنود تكلفة على رأس المستند (جهة + نوع + مبلغ)، ترتبط باستلام مخزني (4) أو استلام تحويل (8)،
       وتُوزَّع على بنود المستند المرجعي (أو على بنود محددة) بأساس الإعدادات: 1 قيمة  2 كمية (3 وزن غير متاح بعد).
       آخر بند يأخذ الباقي فيطابق المجموع المبلغ.
     - نوع 15: تسوية سعر استلام مخزني (4) بمبلغ موجب أو سالب لكل بند، وسبب إلزامي، والجهة الدائنة (المورد) إلزامية.
     - الأثر على كل بند مرجعي: نصيب المتبقي (نسبة المتبقي إلى الأصل) يُضاف إلى قيمة الطبقات المتبقية
       بالتناسب مع كمياتها وتُحدَّث تكلفة وحدتها؛ والباقي (المستهلك سابقًا) فرق مسجَّل لحساب فروق التكلفة.
         • استلام مخزني: الطبقات ذات الجذر نفسه (تشمل ما نُقل منها بين المخازن).
         • استلام تحويل: الطبقات التي أنشأها ذلك الاستلام فقط (ما استُهلك أو نُقل منها يُعدّ مستهلكًا).
     - الحذف/التعديل: يعكس الأثر بشرط ألا تتغير كمية المتبقي في الطبقات منذ التطبيق (52510).
     - استلام (أو استلام تحويل) عليه تكاليف أو تسوية لا يُعدَّل ولا يُحذف قبل حذفها (52511).
     - الحساب المقابل والقيود تُبنى في مرحلة القيود الآلية من هذه الجداول: AmtRem للمخزن، و AmtCons لفروق التكلفة.

   الأخطاء: 52501 نوع/مرجع غير مناسب   52502 السبب أو الجهة مطلوبان   52503 التخفيض يتجاوز قيمة المتبقي
            52504 أساس التوزيع غير متاح   52505 مجموع أساس التوزيع صفر   52506 بنود التكلفة غير صحيحة
            52509 المستند غير موجود   52510 لا يمكن العكس (تغيّر المتبقي)   52511 عليه تكاليف أو تسوية
   يتطلب Wrh_01 .. Wrh_04. نفّذ الملف كاملًا على MADARERPDataBase.
   ===================================================================== */
USE [MADARERPDataBase];
GO

UPDATE dbo.Wrh_DocTypeDef SET DtNeedParty = 0 WHERE DtType = 14;   -- الجهات على بنود التكلفة لا على الرأس
GO

IF OBJECT_ID(N'dbo.Wrh_CostLine', N'U') IS NULL
    CREATE TABLE dbo.Wrh_CostLine
    (
        CostLineID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_CostLine PRIMARY KEY,
        CostDocID  BIGINT NOT NULL,
        CostPartyID BIGINT NOT NULL,
        CostKind   TINYINT NOT NULL,       -- 1 شحن 2 جمارك 3 تحميل 4 تفريغ 5 تعبئة 6 نقل 9 أخرى
        CostAmount DECIMAL(18,3) NOT NULL,
        CONSTRAINT CK_Wrh_CostLine CHECK (CostKind IN (1,2,3,4,5,6,9) AND CostAmount > 0)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_CostLine_Doc' AND object_id = OBJECT_ID(N'dbo.Wrh_CostLine'))
    CREATE INDEX IX_Wrh_CostLine_Doc ON dbo.Wrh_CostLine (CostDocID);
GO

IF OBJECT_ID(N'dbo.Wrh_CostAdj', N'U') IS NULL
    CREATE TABLE dbo.Wrh_CostAdj
    (
        AdjID        BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_CostAdj PRIMARY KEY,
        AdjDocID     BIGINT NOT NULL,
        AdjRefLineID BIGINT NOT NULL,           -- بند الاستلام المتأثر
        AdjAmount    DECIMAL(18,3) NOT NULL,    -- الإجمالي (موجب أو سالب)
        AdjRemPart   DECIMAL(18,3) NOT NULL,    -- يُضاف للمتبقي في المخزن
        AdjConsPart  DECIMAL(18,3) NOT NULL,    -- يذهب لحساب فروق التكلفة
        AdjBaseQty   DECIMAL(18,3) NOT NULL,
        AdjRemQty    DECIMAL(18,3) NOT NULL,
        CONSTRAINT CK_Wrh_CostAdj CHECK (AdjAmount = AdjRemPart + AdjConsPart)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_CostAdj_Doc' AND object_id = OBJECT_ID(N'dbo.Wrh_CostAdj'))
    CREATE INDEX IX_Wrh_CostAdj_Doc ON dbo.Wrh_CostAdj (AdjDocID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_CostAdj_Line' AND object_id = OBJECT_ID(N'dbo.Wrh_CostAdj'))
    CREATE INDEX IX_Wrh_CostAdj_Line ON dbo.Wrh_CostAdj (AdjRefLineID);
GO

IF OBJECT_ID(N'dbo.Wrh_CostAdjLayer', N'U') IS NULL
    CREATE TABLE dbo.Wrh_CostAdjLayer
    (
        AdjID    BIGINT NOT NULL CONSTRAINT FK_Wrh_CostAdjLayer_Adj REFERENCES dbo.Wrh_CostAdj (AdjID),
        LayerID  BIGINT NOT NULL CONSTRAINT FK_Wrh_CostAdjLayer_Ly  REFERENCES dbo.Wrh_Layer (LayerID),
        AddValue DECIMAL(18,3) NOT NULL,
        RemAtAdj DECIMAL(18,3) NOT NULL,
        CONSTRAINT PK_Wrh_CostAdjLayer PRIMARY KEY (AdjID, LayerID)
    );
GO

/* ------------------------------------------------------------------ عكس أثر مستند تكلفة/تسوية */
CREATE OR ALTER PROCEDURE dbo.Wrh_CostReverse
    @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM dbo.Wrh_CostAdjLayer AS x
               JOIN dbo.Wrh_CostAdj AS a ON a.AdjID = x.AdjID
               JOIN dbo.Wrh_Layer AS l WITH (UPDLOCK) ON l.LayerID = x.LayerID
               WHERE a.AdjDocID = @DocID AND l.LyQtyRem <> x.RemAtAdj)
        THROW 52510, N'لا يمكن عكس التكلفة/التسوية: تغيّر المتبقي في الطبقات بعد تطبيقها (استُهلك أو نُقل).', 1;

    UPDATE l
       SET LyUnitCost = CASE WHEN l.LyQtyRem > 0 THEN ROUND((l.LyValueRem - s.v) / l.LyQtyRem, 6) ELSE l.LyUnitCost END,
           LyValueIn  = l.LyValueIn  - s.v,
           LyValueRem = l.LyValueRem - s.v
      FROM dbo.Wrh_Layer AS l
      JOIN (SELECT x.LayerID, SUM(x.AddValue) AS v
            FROM dbo.Wrh_CostAdjLayer AS x JOIN dbo.Wrh_CostAdj AS a ON a.AdjID = x.AdjID
            WHERE a.AdjDocID = @DocID GROUP BY x.LayerID) AS s ON s.LayerID = l.LayerID;

    DELETE x FROM dbo.Wrh_CostAdjLayer AS x JOIN dbo.Wrh_CostAdj AS a ON a.AdjID = x.AdjID WHERE a.AdjDocID = @DocID;
    DELETE dbo.Wrh_CostAdj WHERE AdjDocID = @DocID;
END;
GO

/* ------------------------------------------------------------------ حفظ مستند تكلفة إضافية/تسوية
   @Items نوع 14: [{"PartyID":1,"Kind":1,"Amount":200}, ...]      نوع 15: [{"RefLineID":5,"Delta":-50}, ...]
   @OnlyLines (نوع 14 فقط، اختياري): [5,6]  أرقام بنود المستند المرجعي المقصودة. */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveCostDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE, @RefDocID BIGINT,
    @PartyID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Items NVARCHAR(MAX), @OnlyLines NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52506, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52506, N'المستخدم غير موجود.', 1;
    IF @Type IS NULL OR @Type NOT IN (14, 15) THROW 52501, N'هذا الإجراء لمستندات التكلفة الإضافية (14) والتسوية (15) فقط.', 1;

    DECLARE @RefType TINYINT, @RefWh BIGINT;
    SELECT @RefType = DocType, @RefWh = DocWhID FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp;
    IF @RefType IS NULL OR (@Type = 15 AND @RefType <> 4) OR (@Type = 14 AND @RefType NOT IN (4, 8))
        THROW 52501, N'المستند المرجعي غير مناسب (التكلفة: استلام مخزني أو استلام تحويل، والتسوية: استلام مخزني).', 1;

    SET @Notes = NULLIF(LTRIM(RTRIM(@Notes)), N'');
    IF @Type = 15
    BEGIN
        IF @Notes IS NULL THROW 52502, N'سبب التسوية مطلوب.', 1;
        IF @PartyID IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
            THROW 52502, N'الجهة الدائنة (المورد) مطلوبة وصالحة.', 1;
    END
    ELSE SET @PartyID = NULL;

    IF @Items IS NULL OR ISJSON(@Items) <> 1 THROW 52506, N'بنود التكلفة غير صحيحة.', 1;

    CREATE TABLE #C (Ord INT, PartyID BIGINT, Kind TINYINT, Amount DECIMAL(18,3));
    CREATE TABLE #S (Ord INT, RefLineID BIGINT, Delta DECIMAL(18,3));
    CREATE TABLE #T (LineID BIGINT, Ord INT, Weight DECIMAL(18,3), Delta DECIMAL(18,3));

    IF @Type = 14
    BEGIN
        INSERT #C (Ord, PartyID, Kind, Amount)
        SELECT CAST(x.[key] AS INT), j.PartyID, j.Kind, j.Amount
        FROM OPENJSON(@Items) AS x
        CROSS APPLY OPENJSON(x.[value]) WITH (PartyID BIGINT '$.PartyID', Kind TINYINT '$.Kind', Amount DECIMAL(18,3) '$.Amount') AS j;
        IF NOT EXISTS (SELECT 1 FROM #C) OR EXISTS (SELECT 1 FROM #C WHERE PartyID IS NULL OR Kind IS NULL OR Kind NOT IN (1,2,3,4,5,6,9) OR Amount IS NULL OR Amount <= 0)
            THROW 52506, N'كل بند تكلفة يحتاج جهة ونوعًا (1 شحن، 2 جمارك، 3 تحميل، 4 تفريغ، 5 تعبئة، 6 نقل، 9 أخرى) ومبلغًا أكبر من صفر.', 1;
        IF EXISTS (SELECT 1 FROM #C AS c WHERE NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = c.PartyID AND PrtCmpID = @Cmp AND PrtActive = 1))
            THROW 52506, N'جهة تكلفة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    END
    ELSE
    BEGIN
        INSERT #S (Ord, RefLineID, Delta)
        SELECT CAST(x.[key] AS INT), j.RefLineID, j.Delta
        FROM OPENJSON(@Items) AS x
        CROSS APPLY OPENJSON(x.[value]) WITH (RefLineID BIGINT '$.RefLineID', Delta DECIMAL(18,3) '$.Delta') AS j;
        IF NOT EXISTS (SELECT 1 FROM #S) OR EXISTS (SELECT 1 FROM #S WHERE RefLineID IS NULL OR Delta IS NULL OR Delta = 0)
            THROW 52506, N'كل بند تسوية يحتاج بندًا مرجعيًا ومبلغًا غير صفري.', 1;
        IF EXISTS (SELECT 1 FROM #S GROUP BY RefLineID HAVING COUNT(*) > 1)
            THROW 52506, N'بند مرجعي مكرر في التسوية.', 1;
        IF EXISTS (SELECT 1 FROM #S AS s WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE LineID = s.RefLineID AND DocID = @RefDocID))
            THROW 52506, N'بند مرجعي لا يتبع المستند المرجعي.', 1;
    END

    DECLARE @Basis TINYINT = ISNULL((SELECT WsAllocBasis FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1);
    IF @Type = 14
    BEGIN
        IF @Basis = 3 THROW 52504, N'أساس التوزيع بالوزن غير متاح بعد (لا وزن للأصناف).', 1;
        IF @OnlyLines IS NOT NULL
        BEGIN
            IF ISJSON(@OnlyLines) <> 1 THROW 52506, N'قائمة البنود المحددة غير صحيحة.', 1;
            INSERT #T (LineID, Ord, Weight)
            SELECT l.LineID, l.DocLineNo, CASE WHEN @Basis = 1 THEN l.Amount ELSE l.BaseQty END
            FROM dbo.Wrh_DocLine AS l
            WHERE l.DocID = @RefDocID AND l.LineID IN (SELECT CAST(o.[value] AS BIGINT) FROM OPENJSON(@OnlyLines) AS o);
            IF (SELECT COUNT(*) FROM #T) <> (SELECT COUNT(*) FROM OPENJSON(@OnlyLines))
                THROW 52506, N'بند محدد لا يتبع المستند المرجعي.', 1;
        END
        ELSE
            INSERT #T (LineID, Ord, Weight)
            SELECT l.LineID, l.DocLineNo, CASE WHEN @Basis = 1 THEN l.Amount ELSE l.BaseQty END
            FROM dbo.Wrh_DocLine AS l WHERE l.DocID = @RefDocID;

        IF @RefType = 8   -- أساس القيمة لاستلام التحويل = قيمة الطبقات الناتجة
            IF @Basis = 1
                UPDATE t SET Weight = ISNULL((SELECT SUM(LyValueIn) FROM dbo.Wrh_Layer WHERE LySrcLineID = t.LineID), 0) FROM #T AS t;

        DECLARE @Total DECIMAL(18,3) = (SELECT SUM(Amount) FROM #C), @WSum DECIMAL(18,3) = (SELECT SUM(Weight) FROM #T);
        IF ISNULL(@WSum, 0) <= 0 THROW 52505, N'مجموع أساس التوزيع صفر؛ جرّب التوزيع بالكمية أو حدّد بنودًا.', 1;

        UPDATE t SET Delta = ROUND(@Total * t.Weight / @WSum, 3) FROM #T AS t;
        DECLARE @LastLine BIGINT = (SELECT TOP 1 LineID FROM #T ORDER BY Ord DESC, LineID DESC);
        UPDATE #T SET Delta = @Total - ISNULL((SELECT SUM(Delta) FROM #T WHERE LineID <> @LastLine), 0) WHERE LineID = @LastLine;
    END
    ELSE
    BEGIN
        INSERT #T (LineID, Ord, Weight, Delta)
        SELECT s.RefLineID, s.Ord, 0, s.Delta FROM #S AS s;
    END

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveCostDoc;

    BEGIN TRY
        DECLARE @Year INT = YEAR(@Date), @DocNo NVARCHAR(10), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
            IF @OType IS NULL THROW 52509, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52501, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52506, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            EXEC dbo.Wrh_CostReverse @DocID;
            DELETE dbo.Wrh_CostLine WHERE CostDocID = @DocID;
            UPDATE dbo.Wrh_Doc SET DocDate = @Date, DocPartyID = @PartyID, DocRefDocID = @RefDocID, DocNotes = @Notes WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocPartyID, DocRefDocID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, 3, @PartyID, @RefDocID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        IF @Type = 14
            INSERT dbo.Wrh_CostLine (CostDocID, CostPartyID, CostKind, CostAmount)
            SELECT @DocID, PartyID, Kind, Amount FROM #C ORDER BY Ord;

        -- التطبيق على كل بند مرجعي
        DECLARE @Line BIGINT, @Delta DECIMAL(18,3), @Base DECIMAL(18,3), @Rem DECIMAL(18,3), @Root BIGINT,
                @RemPart DECIMAL(18,3), @AdjID BIGINT, @n INT, @i INT, @lyid BIGINT, @lyrem DECIMAL(18,3),
                @remSum DECIMAL(18,3), @share DECIMAL(18,3), @given DECIMAL(18,3);

        DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR SELECT LineID, Delta FROM #T ORDER BY Ord, LineID;
        OPEN cur; FETCH NEXT FROM cur INTO @Line, @Delta;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            CREATE TABLE #LY (Seq INT IDENTITY(1,1), LayerID BIGINT, Rem DECIMAL(18,3));

            IF @RefType = 4
            BEGIN
                SET @Root = NULL;
                SELECT @Root = LayerID, @Base = LyQtyIn FROM dbo.Wrh_Layer WHERE LySrcLineID = @Line AND LyWhID = @RefWh;
                IF @Root IS NULL THROW 52501, N'بند الاستلام بلا طبقة (غير صالح للتكلفة).', 1;
                INSERT #LY (LayerID, Rem) SELECT LayerID, LyQtyRem FROM dbo.Wrh_Layer WITH (UPDLOCK)
                    WHERE LyRootID = @Root AND LyQtyRem > 0 ORDER BY LayerID;
            END
            ELSE
            BEGIN
                SELECT @Base = SUM(LyQtyIn) FROM dbo.Wrh_Layer WHERE LySrcLineID = @Line;
                IF ISNULL(@Base, 0) <= 0 THROW 52501, N'بند الاستلام بلا طبقات (غير صالح للتكلفة).', 1;
                INSERT #LY (LayerID, Rem) SELECT LayerID, LyQtyRem FROM dbo.Wrh_Layer WITH (UPDLOCK)
                    WHERE LySrcLineID = @Line AND LyQtyRem > 0 ORDER BY LayerID;
            END

            SELECT @Rem = ISNULL(SUM(Rem), 0), @n = COUNT(*) FROM #LY;
            SET @RemPart = CASE WHEN @Rem = 0 THEN 0 ELSE ROUND(@Delta * CAST(@Rem AS DECIMAL(18,6)) / @Base, 3) END;

            INSERT dbo.Wrh_CostAdj (AdjDocID, AdjRefLineID, AdjAmount, AdjRemPart, AdjConsPart, AdjBaseQty, AdjRemQty)
            VALUES (@DocID, @Line, @Delta, @RemPart, @Delta - @RemPart, @Base, @Rem);
            SET @AdjID = SCOPE_IDENTITY();

            SET @i = 1; SET @given = 0; SET @remSum = @Rem;
            WHILE @i <= @n AND @RemPart <> 0
            BEGIN
                SELECT @lyid = LayerID, @lyrem = Rem FROM #LY WHERE Seq = @i;
                SET @share = CASE WHEN @i = @n THEN @RemPart - @given ELSE ROUND(@RemPart * CAST(@lyrem AS DECIMAL(18,6)) / @remSum, 3) END;
                IF @share <> 0
                BEGIN
                    IF EXISTS (SELECT 1 FROM dbo.Wrh_Layer WHERE LayerID = @lyid AND LyValueRem + @share < 0)
                        THROW 52503, N'التخفيض يتجاوز قيمة المتبقي في الطبقات.', 1;
                    UPDATE dbo.Wrh_Layer
                       SET LyValueIn = LyValueIn + @share, LyValueRem = LyValueRem + @share,
                           LyUnitCost = ROUND((LyValueRem + @share) / LyQtyRem, 6)
                     WHERE LayerID = @lyid;
                    INSERT dbo.Wrh_CostAdjLayer (AdjID, LayerID, AddValue, RemAtAdj) VALUES (@AdjID, @lyid, @share, @lyrem);
                    SET @given = @given + @share;
                END
                SET @i = @i + 1;
            END

            DROP TABLE #LY;
            FETCH NEXT FROM cur INTO @Line, @Delta;
        END
        CLOSE cur; DEALLOCATE cur;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User, @Notes);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveCostDoc;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ حذف مستند تكلفة/تسوية */
CREATE OR ALTER PROCEDURE dbo.Wrh_DeleteCostDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52506, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_DeleteCostDoc;

    BEGIN TRY
        DECLARE @Type TINYINT, @No NVARCHAR(10);
        SELECT @Type = DocType, @No = DocNo FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK)
        WHERE DocID = @DocID AND DocCmpID = @Cmp AND DocType IN (14, 15);
        IF @Type IS NULL THROW 52509, N'المستند غير موجود أو لا يتبع الشركة أو ليس تكلفة/تسوية.', 1;

        EXEC dbo.Wrh_CostReverse @DocID;
        DELETE dbo.Wrh_CostLine WHERE CostDocID = @DocID;
        DELETE dbo.Wrh_Doc WHERE DocID = @DocID;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, @Type, 3, @User, NULLIF(LTRIM(RTRIM(@Reason)), N''));

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_DeleteCostDoc;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ قراءة مستند تكلفة/تسوية: الرأس ثم بنود التكلفة ثم الأثر على البنود */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectCostDoc
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocCmpID = @Cmp AND DocType IN (14, 15))
        THROW 52509, N'المستند غير موجود أو لا يتبع الشركة أو ليس تكلفة/تسوية.', 1;

    SELECT d.DocID, d.DocType, t.DtName AS DocTypeName, d.DocNo, d.DocDate, d.DocRefDocID, r.DocNo AS RefDocNo,
           d.DocPartyID, p.PrtName, d.DocNotes, d.DocCreatedBy, d.DocCreatedAt
    FROM dbo.Wrh_Doc AS d
    JOIN dbo.Wrh_DocTypeDef AS t ON t.DtType = d.DocType
    LEFT JOIN dbo.Wrh_Doc AS r ON r.DocID = d.DocRefDocID
    LEFT JOIN dbo.Prt_Party AS p ON p.PrtID = d.DocPartyID
    WHERE d.DocID = @DocID;

    SELECT c.CostLineID, c.CostPartyID, p.PrtName, c.CostKind, c.CostAmount
    FROM dbo.Wrh_CostLine AS c JOIN dbo.Prt_Party AS p ON p.PrtID = c.CostPartyID
    WHERE c.CostDocID = @DocID ORDER BY c.CostLineID;

    SELECT a.AdjID, a.AdjRefLineID, l.ItemID, i.ItemCode, i.ItemName, a.AdjAmount, a.AdjRemPart, a.AdjConsPart, a.AdjBaseQty, a.AdjRemQty
    FROM dbo.Wrh_CostAdj AS a
    JOIN dbo.Wrh_DocLine AS l ON l.LineID = a.AdjRefLineID
    JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
    WHERE a.AdjDocID = @DocID ORDER BY a.AdjID;
END;
GO


/* ---- إعادة تعريف عكس المخزون بمنع 52511 ---- */
/* ------------------------------------------------------------------ عكس أثر المستند */
CREATE OR ALTER PROCEDURE dbo.Wrh_StockReverse
    @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Type TINYINT, @Wh BIGINT, @Wh2 BIGINT;
    SELECT @Type = DocType, @Wh = DocWhID, @Wh2 = DocWh2ID FROM dbo.Wrh_Doc WHERE DocID = @DocID;
    IF @Type IS NULL OR @Type NOT IN (4, 5, 7, 8, 9, 10) RETURN;

    DECLARE @lid BIGINT, @item BIGINT, @q DECIMAL(18,3), @avail DECIMAL(18,3);

    DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
        SELECT LineID, ItemID, BaseQty FROM dbo.Wrh_DocLine WHERE DocID = @DocID ORDER BY ItemID, DocLineNo;
    OPEN cur;
    FETCH NEXT FROM cur INTO @lid, @item, @q;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Type IN (4, 9, 8)   -- عمليات أنشأت طبقات في @Wh
        BEGIN
            IF @Type IN (4, 8) AND EXISTS (SELECT 1 FROM dbo.Wrh_CostAdj WHERE AdjRefLineID = @lid)
                THROW 52511, N'لا يمكن تعديل/حذف هذا الاستلام: عليه تكاليف إضافية أو تسوية؛ احذفها أولًا.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_Layer WHERE LySrcLineID = @lid AND LyWhID = @Wh AND LyQtyRem <> LyQtyIn)
                THROW 52410, N'لا يمكن تعديل/حذف هذه العملية: استُهلك جزء من الطبقة التي أنشأتها.', 1;
            SELECT @avail = StkQty - StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            IF @avail < @q
                THROW 52410, N'لا يمكن تعديل/حذف هذه العملية: الرصيد الحالي (بعد المحجوز) لا يغطي كميتها.', 1;
            DELETE dbo.Wrh_Layer WHERE LySrcLineID = @lid AND LyWhID = @Wh;
            UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @q WHERE StkWhID = @Wh AND StkItemID = @item;
        END

        IF @Type IN (5, 10, 8)   -- عمليات استهلكت طبقات: تُعاد
        BEGIN
            UPDATE l SET LyQtyRem = l.LyQtyRem + u.q, LyValueRem = l.LyValueRem + u.v
              FROM dbo.Wrh_Layer AS l
              JOIN (SELECT UseLayerID, SUM(UseQty) AS q, SUM(UseValue) AS v FROM dbo.Wrh_LayerUse
                    WHERE UseLineID = @lid GROUP BY UseLayerID) AS u ON u.UseLayerID = l.LayerID;
            DELETE dbo.Wrh_LayerUse WHERE UseLineID = @lid;
            IF @Type IN (5, 10)
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q WHERE StkWhID = @Wh AND StkItemID = @item;
            ELSE
            BEGIN
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @q, StkReserved = StkReserved + @q WHERE StkWhID = @Wh2 AND StkItemID = @item;
            END
        END

        IF @Type = 7
            UPDATE dbo.Wrh_Stock SET StkReserved = StkReserved - @q WHERE StkWhID = @Wh AND StkItemID = @item;

        FETCH NEXT FROM cur INTO @lid, @item, @q;
    END
    CLOSE cur; DEALLOCATE cur;
END;
GO



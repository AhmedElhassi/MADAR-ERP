/* اختبار المرحلة 5 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_SaveCostDoc') IS NULL THROW 52900, N'نفّذ Wrh_05_Costs.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #D (DocID BIGINT, DocNo NVARCHAR(10), DocStatus TINYINT);
CREATE TABLE #K (DocID BIGINT, DocNo NVARCHAR(10));

DECLARE @C INT = 99996;
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Leaf BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                        WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @d DATE = '2026-03-01';

DECLARE @e INT, @W1 BIGINT, @W2 BIGINT, @P BIGINT, @T BIGINT, @G BIGINT, @u1 BIGINT;
DECLARE @I BIGINT, @I2 BIGINT, @I3 BIGINT, @I4 BIGINT, @I5 BIGINT;
DECLARE @sI NVARCHAR(20), @sI2 NVARCHAR(20), @sI3 NVARCHAR(20), @sI4 NVARCHAR(20), @sI5 NVARCHAR(20), @sU NVARCHAR(20), @sT NVARCHAR(20), @L NVARCHAR(MAX);
DECLARE @inv1 BIGINT, @il1 BIGINT, @rc1 BIGINT, @rl1 BIGINT, @ly1 BIGINT;
DECLARE @inv2 BIGINT, @rc2 BIGINT, @a2 BIGINT, @a3 BIGINT, @a4 BIGINT, @r2 BIGINT, @r3 BIGINT, @r4 BIGINT;
DECLARE @inv3 BIGINT, @rc3 BIGINT, @b2 BIGINT, @b3 BIGINT, @s2 BIGINT, @s3 BIGINT;
DECLARE @inv5 BIGINT, @il5 BIGINT, @rc5 BIGINT, @rl5 BIGINT, @ord BIGINT, @ol BIGINT, @trf BIGINT;
DECLARE @iss1 BIGINT, @iss2 BIGINT, @x BIGINT, @cd1 BIGINT, @cd2 BIGINT, @cd3 BIGINT, @cd4 BIGINT, @cd5 BIGINT, @stt BIGINT, @cs BIGINT;
DECLARE @ol1 NVARCHAR(100), @ol2 NVARCHAR(100);
DECLARE @q DECIMAL(18,3), @v DECIMAL(18,3), @q2 DECIMAL(18,3), @v2 DECIMAL(18,3), @n INT, @c6 DECIMAL(18,6), @s DECIMAL(18,3), @mx DECIMAL(18,3), @mn DECIMAL(18,3);

IF @U IS NULL OR @Leaf IS NULL OR @CC IS NULL
BEGIN
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وحساب ورقي ومركز تكلفة');
END
ELSE
BEGIN
    BEGIN TRAN;

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W1', N'مخزن 1', @Leaf; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W2', N'مخزن 2', @Leaf; SELECT @W2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'P1', N'مورد', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'P2', N'ناقل', 2; SELECT @T = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'G1', N'مجموعة', @Leaf; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I1', N'صنف 1', @u1; SELECT @I = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I2', N'صنف 2', @u1; SELECT @I2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I3', N'صنف 3', @u1; SELECT @I3 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I4', N'صنف 4', @u1; SELECT @I4 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I5', N'صنف 5', @u1; SELECT @I5 = Id FROM #I;
    SET @sI = CAST(@I AS NVARCHAR(20)); SET @sI2 = CAST(@I2 AS NVARCHAR(20)); SET @sI3 = CAST(@I3 AS NVARCHAR(20));
    SET @sI4 = CAST(@I4 AS NVARCHAR(20)); SET @sI5 = CAST(@I5 AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20)); SET @sT = CAST(@T AS NVARCHAR(20));

    -- استلام 1: 100 × 10 من الصنف I
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv1 = DocID FROM #D;
    SELECT @il1 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv1;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10,"RefLineID":', @il1, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv1, NULL, @L; SELECT @rc1 = DocID FROM #D;
    SELECT @rl1 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc1;
    SELECT @ly1 = LayerID FROM dbo.Wrh_Layer WHERE LySrcLineID = @rl1;

    -- B1: تكلفة 200 قبل أي صرف
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":1,"Amount":200}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc1, NULL, NULL, @L, NULL; SELECT @cd1 = DocID FROM #K;
    SELECT @v = LyValueRem, @c6 = LyUnitCost, @v2 = LyValueIn FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B1 تكلفة 200 ترفع القيمة وتكلفة الوحدة', CASE WHEN @v = 1200 AND @v2 = 1200 AND @c6 = 12 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @c6));
    SELECT @q = AdjRemPart, @q2 = AdjConsPart FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd1;
    INSERT @R VALUES (N'B1b كلها للمتبقي', CASE WHEN @q = 200 AND @q2 = 0 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    SELECT @stt = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @cd1;
    INSERT @R VALUES (N'B1c حالة المستند 3', CASE WHEN @stt = 3 THEN 1 ELSE 0 END, CONCAT(N'got ', @stt));
    SELECT @n = COUNT(*) FROM dbo.Wrh_CostLine WHERE CostDocID = @cd1;
    INSERT @R VALUES (N'B1d بند التكلفة محفوظ', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- B2: صرف 40 بتكلفة 12 = 480 ثم تكلفة 100 (60 للمتبقي، 40 للمستهلك)
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":40}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss1 = DocID FROM #D;
    SELECT @x = LineID FROM dbo.Wrh_DocLine WHERE DocID = @iss1; SELECT @v = SUM(UseValue) FROM dbo.Wrh_LayerUse WHERE UseLineID = @x;
    INSERT @R VALUES (N'B2a قيمة الصرف بعد التكلفة', CASE WHEN @v = 480 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":2,"Amount":100}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc1, NULL, NULL, @L, NULL; SELECT @cd2 = DocID FROM #K;
    SELECT @v = LyValueRem, @c6 = LyUnitCost, @q = LyQtyRem FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B2b المتبقي بعد تكلفة متأخرة', CASE WHEN @v = 780 AND @c6 = 13 AND @q = 60 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @c6, N'/', @q));
    SELECT @q = AdjRemPart, @q2 = AdjConsPart FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd2;
    INSERT @R VALUES (N'B2c التقسيم 60 مخزن و40 فرق', CASE WHEN @q = 60 AND @q2 = 40 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));

    -- B3: حذف التكلفة الثانية يعكس
    EXEC dbo.Wrh_DeleteCostDoc @C, @U, @cd2, N'اختبار';
    SELECT @v = LyValueRem, @c6 = LyUnitCost, @v2 = LyValueIn FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B3 حذف التكلفة يعكس الأثر', CASE WHEN @v = 720 AND @c6 = 12 AND @v2 = 1200 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @c6, N'/', @v2));
    SELECT @n = COUNT(*) FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd2;
    INSERT @R VALUES (N'B3b سجل الأثر حُذف', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- B4: لا عكس بعد تغيّر المتبقي
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc1, NULL, NULL, @L, NULL; SELECT @cd2 = DocID FROM #K;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss2 = DocID FROM #D;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteCostDoc @C, @U, @cd2, N'اختبار'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B4 منع العكس بعد استهلاك', CASE WHEN @e = 52510 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B4b القيمة لم تتغير بعد الرفض', CASE WHEN @v = 650 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    EXEC dbo.Wrh_DeleteDoc @C, @U, @iss2;
    EXEC dbo.Wrh_DeleteCostDoc @C, @U, @cd2, N'اختبار';
    SELECT @v = LyValueRem, @q = LyQtyRem FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B4c بعد إعادة الصرف يمكن العكس', CASE WHEN @v = 720 AND @q = 60 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @q));

    -- B5: منع حذف الاستلام وعليه تكلفة
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C, @U, @rc1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B5 منع حذف استلام عليه تكلفة', CASE WHEN @e = 52511 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- B6: تسوية -50 (30 للمتبقي، 20 فرق)
    SET @L = CONCAT(N'[{"RefLineID":', @rl1, N',"Delta":-50}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @rc1, @P, N'خصم من المورد', @L, NULL; SELECT @cs = DocID FROM #K;
    SELECT @v = LyValueRem, @c6 = LyUnitCost FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B6 تسوية سالبة', CASE WHEN @v = 690 AND @c6 = 11.5 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @c6));
    SELECT @q = AdjRemPart, @q2 = AdjConsPart FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cs;
    INSERT @R VALUES (N'B6b تقسيم التسوية', CASE WHEN @q = -30 AND @q2 = -20 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));

    -- B7: تعديل التسوية إلى +50
    SET @L = CONCAT(N'[{"RefLineID":', @rl1, N',"Delta":50}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, @cs, 15, @d, @rc1, @P, N'زيادة من المورد', @L, NULL;
    SELECT @v = LyValueRem, @c6 = LyUnitCost FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B7 تعديل التسوية إلى موجبة', CASE WHEN @v = 750 AND @c6 = 12.5 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @c6));

    -- B8: أخطاء التسوية
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @rc1, @P, NULL, @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B8 التسوية بلا سبب', CASE WHEN @e = 52502 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @rc1, NULL, N'سبب', @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B8b التسوية بلا جهة', CASE WHEN @e = 52502 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"RefLineID":', @rl1, N',"Delta":-2000}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @rc1, @P, N'سبب', @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B8c تخفيض يتجاوز القيمة', CASE WHEN @e = 52503 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @v = LyValueRem FROM dbo.Wrh_Layer WHERE LayerID = @ly1;
    INSERT @R VALUES (N'B8d لا أثر بعد الفشل', CASE WHEN @v = 750 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    SET @L = CONCAT(N'[{"RefLineID":', @rl1, N',"Delta":5},{"RefLineID":', @rl1, N',"Delta":6}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @rc1, @P, N'سبب', @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B8e بند مكرر', CASE WHEN @e = 52506 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"RefLineID":', @il1, N',"Delta":5}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @inv1, @P, N'سبب', @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B8f تسوية على فاتورة (نوع خاطئ)', CASE WHEN @e = 52501 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- B9: أخطاء التكلفة
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":1,"Amount":10}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @inv1, NULL, NULL, @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B9 تكلفة على فاتورة (نوع خاطئ)', CASE WHEN @e = 52501 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc1, NULL, NULL, N'[]', NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B9b بنود فارغة', CASE WHEN @e = 52506 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":7,"Amount":10}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc1, NULL, NULL, @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B9c نوع تكلفة غير معروف', CASE WHEN @e = 52506 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = N'[{"PartyID":0,"Kind":1,"Amount":10}]';
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc1, NULL, NULL, @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B9d جهة غير موجودة', CASE WHEN @e = 52506 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteCostDoc @C, @U, @rc1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'B9e حذف مستند ليس تكلفة', CASE WHEN @e = 52509 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- C: استلام بثلاثة بنود (100 لكل بند) والتوزيع بالقيمة
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":10,"Price":10},{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":10,"Price":10},{"ItemID":', @sI4, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv2 = DocID FROM #D;
    SELECT @a2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv2 AND ItemID = @I2;
    SELECT @a3 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv2 AND ItemID = @I3;
    SELECT @a4 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv2 AND ItemID = @I4;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @a2, N'},{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @a3, N'},{"ItemID":', @sI4, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @a4, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv2, NULL, @L; SELECT @rc2 = DocID FROM #D;
    SELECT @r2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc2 AND ItemID = @I2;
    SELECT @r3 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc2 AND ItemID = @I3;
    SELECT @r4 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc2 AND ItemID = @I4;

    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":1,"Amount":60},{"PartyID":', @sT, N',"Kind":2,"Amount":40}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc2, NULL, NULL, @L, NULL; SELECT @cd3 = DocID FROM #K;
    SELECT @s = SUM(AdjAmount), @mx = MAX(AdjAmount), @mn = MIN(AdjAmount), @n = COUNT(*) FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd3;
    INSERT @R VALUES (N'C1 التوزيع على 3 بنود والتقريب', CASE WHEN @s = 100 AND @mx = 33.334 AND @mn = 33.333 AND @n = 3 THEN 1 ELSE 0 END, CONCAT(@s, N'/', @mx, N'/', @mn, N'/', @n));
    SELECT @v = SUM(LyValueIn) FROM dbo.Wrh_Layer WHERE LySrcLineID IN (@r2, @r3, @r4);
    INSERT @R VALUES (N'C1b مجموع قيم الطبقات 400', CASE WHEN @v = 400 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    SELECT @q = AdjAmount FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd3 AND AdjRefLineID = @r4;
    INSERT @R VALUES (N'C1c آخر بند يأخذ الباقي', CASE WHEN @q = 33.334 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));
    SELECT @n = COUNT(*) FROM dbo.Wrh_CostLine WHERE CostDocID = @cd3;
    INSERT @R VALUES (N'C1d بندان تكلفة', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- C2: تعديل إلى 200
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":1,"Amount":200}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, @cd3, 14, @d, @rc2, NULL, NULL, @L, NULL;
    SELECT @s = SUM(AdjAmount), @n = COUNT(*) FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd3;
    SELECT @v = SUM(LyValueIn) FROM dbo.Wrh_Layer WHERE LySrcLineID IN (@r2, @r3, @r4);
    INSERT @R VALUES (N'C2 تعديل مستند التكلفة', CASE WHEN @s = 200 AND @n = 3 AND @v = 500 THEN 1 ELSE 0 END, CONCAT(@s, N'/', @n, N'/', @v));
    SELECT @n = COUNT(*) FROM dbo.Wrh_CostLine WHERE CostDocID = @cd3;
    INSERT @R VALUES (N'C2b بنود التكلفة استُبدلت', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- C3: بند واحد محدد
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":6,"Amount":90}]');
    SET @x = @r2; SET @ol1 = CONCAT(N'[', @x, N']'); SET @ol2 = CONCAT(N'[', @il1, N']');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, @cd3, 14, @d, @rc2, NULL, NULL, @L, @ol1;
    SELECT @s = SUM(AdjAmount), @n = COUNT(*) FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd3;
    SELECT @v = LyValueIn FROM dbo.Wrh_Layer WHERE LySrcLineID = @r2; SELECT @v2 = LyValueIn FROM dbo.Wrh_Layer WHERE LySrcLineID = @r3;
    INSERT @R VALUES (N'C3 التحميل على بند محدد فقط', CASE WHEN @s = 90 AND @n = 1 AND @v = 190 AND @v2 = 100 THEN 1 ELSE 0 END, CONCAT(@s, N'/', @n, N'/', @v, N'/', @v2));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc2, NULL, NULL, @L, @ol2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'C3b بند محدد من مستند آخر', CASE WHEN @e = 52506 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- C4: التوزيع بالكمية (قيمتان 300/300 وكميتان 10/30)
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":10,"Price":30},{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":30,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv3 = DocID FROM #D;
    SELECT @b2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv3 AND ItemID = @I2;
    SELECT @b3 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv3 AND ItemID = @I3;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":10,"Price":30,"RefLineID":', @b2, N'},{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":30,"Price":10,"RefLineID":', @b3, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv3, NULL, @L; SELECT @rc3 = DocID FROM #D;
    SELECT @s2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc3 AND ItemID = @I2;
    SELECT @s3 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc3 AND ItemID = @I3;
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":1,"Amount":100}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc3, NULL, NULL, @L, NULL; SELECT @cd4 = DocID FROM #K;
    SELECT @q = AdjAmount FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd4 AND AdjRefLineID = @s2;
    SELECT @q2 = AdjAmount FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd4 AND AdjRefLineID = @s3;
    INSERT @R VALUES (N'C4 التوزيع بالقيمة 50/50', CASE WHEN @q = 50 AND @q2 = 50 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @C) INSERT dbo.Wrh_Settings (WsCmpID) VALUES (@C);
    UPDATE dbo.Wrh_Settings SET WsAllocBasis = 2 WHERE WsCmpID = @C;
    EXEC dbo.Wrh_DeleteCostDoc @C, @U, @cd4, N'اختبار';
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc3, NULL, NULL, @L, NULL; SELECT @cd4 = DocID FROM #K;
    SELECT @q = AdjAmount FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd4 AND AdjRefLineID = @s2;
    SELECT @q2 = AdjAmount FROM dbo.Wrh_CostAdj WHERE AdjDocID = @cd4 AND AdjRefLineID = @s3;
    INSERT @R VALUES (N'C4b التوزيع بالكمية 25/75', CASE WHEN @q = 25 AND @q2 = 75 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));
    UPDATE dbo.Wrh_Settings SET WsAllocBasis = 3 WHERE WsCmpID = @C;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc3, NULL, NULL, @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'C4c التوزيع بالوزن غير متاح', CASE WHEN @e = 52504 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    UPDATE dbo.Wrh_Settings SET WsAllocBasis = 1 WHERE WsCmpID = @C;

    -- D: التحويل بين المخازن
    SET @L = CONCAT(N'[{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":100,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv5 = DocID FROM #D;
    SELECT @il5 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv5;
    SET @L = CONCAT(N'[{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":100,"Price":10,"RefLineID":', @il5, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv5, NULL, @L; SELECT @rc5 = DocID FROM #D;
    SELECT @rl5 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @rc5;
    SET @L = CONCAT(N'[{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":30}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @d, @W1, @W2, NULL, NULL, NULL, NULL, @L; SELECT @ord = DocID FROM #D;
    SELECT @ol = LineID FROM dbo.Wrh_DocLine WHERE DocID = @ord;
    SET @L = CONCAT(N'[{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":30,"RefLineID":', @ol, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 8, @d, @W2, @W1, NULL, NULL, @ord, NULL, @L; SELECT @trf = DocID FROM #D;

    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":6,"Amount":60}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @trf, NULL, NULL, @L, NULL; SELECT @cd5 = DocID FROM #K;
    SELECT @v = LyValueIn, @c6 = LyUnitCost FROM dbo.Wrh_Layer WHERE LyWhID = @W2 AND LyItemID = @I5;
    SELECT @v2 = LyValueRem FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I5;
    INSERT @R VALUES (N'D1 تكلفة النقل تدخل طبقة المستلم فقط', CASE WHEN @v = 360 AND @c6 = 12 AND @v2 = 700 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @c6, N'/', @v2));

    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C, @U, @trf; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'D2 منع حذف استلام تحويل عليه تكلفة', CASE WHEN @e = 52511 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- تكلفة 100 على الاستلام الأصلي: تشمل الطبقة المنقولة (نفس الجذر)
    SET @L = CONCAT(N'[{"PartyID":', @sT, N',"Kind":1,"Amount":100}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @d, @rc5, NULL, NULL, @L, NULL;
    SELECT @v = LyValueRem FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I5;
    SELECT @v2 = LyValueIn FROM dbo.Wrh_Layer WHERE LyWhID = @W2 AND LyItemID = @I5;
    INSERT @R VALUES (N'D3 تكلفة الاستلام الأصلي توزَّع على الطبقة المنقولة', CASE WHEN @v = 770 AND @v2 = 390 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @v2));
    SELECT @q = AdjRemQty, @q2 = AdjBaseQty FROM dbo.Wrh_CostAdj WHERE AdjDocID = (SELECT MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 14);
    INSERT @R VALUES (N'D3b المتبقي = الأصل (100)', CASE WHEN @q = 100 AND @q2 = 100 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2));

    -- تسوية الاستلام التحويلي مرفوضة (النوع 15 للاستلام المخزني فقط)
    SET @L = CONCAT(N'[{"RefLineID":', (SELECT TOP 1 LineID FROM dbo.Wrh_DocLine WHERE DocID = @trf), N',"Delta":5}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @d, @trf, @P, N'سبب', @L, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'D4 تسوية على استلام تحويل مرفوضة', CASE WHEN @e = 52501 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- سجل الأحداث
    SELECT @n = COUNT(*) FROM dbo.Wrh_DocEvent WHERE EvCmpID = @C AND EvDocType IN (14, 15);
    INSERT @R VALUES (N'E1 أحداث التكلفة والتسوية مسجلة', CASE WHEN @n > 5 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #D; DROP TABLE #K;

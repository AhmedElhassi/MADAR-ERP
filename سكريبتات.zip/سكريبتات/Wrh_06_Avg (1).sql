﻿/* =====================================================================
   المرحلة 6: المتوسط المرجح (إعداد الشركة WsCostMethod = 2)
   ---------------------------------------------------------------------
   الفكرة: نُبقي الطبقات كما هي (للتتبّع والعكس)، وقبل أي صرف لشركة بالمتوسط
   نعيد توزيع القيمة المتبقية على طبقات المخزن/الصنف بنسبة كمياتها (مجموع القيمة ثابت)،
   فتتساوى تكلفة الوحدة في كل الطبقات ويخرج الصرف بالمتوسط تمامًا. آخر طبقة تأخذ باقي التقريب.
   - الصرف الموجَّه لطبقة محددة (ترجيع للمورد) لا يتأثر.
   - لأن القيمة المتبقية قد تتجاوز قيمة دخول الطبقة بعد التوحيد، يُستبدل قيد CK_Wrh_Layer_Val
     بقيد القيم غير السالبة فقط.
   - شركة FIFO: لا تغيير في السلوك إطلاقًا.
   يتطلب Wrh_01 .. Wrh_05. نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Wrh_Layer_Val' AND parent_object_id = OBJECT_ID(N'dbo.Wrh_Layer'))
    ALTER TABLE dbo.Wrh_Layer DROP CONSTRAINT CK_Wrh_Layer_Val;
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Wrh_Layer_Val2' AND parent_object_id = OBJECT_ID(N'dbo.Wrh_Layer'))
    ALTER TABLE dbo.Wrh_Layer ADD CONSTRAINT CK_Wrh_Layer_Val2 CHECK (LyValueIn >= 0 AND LyValueRem >= 0);
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_Rebalance
    @Wh BIGINT, @Item BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    CREATE TABLE #B (Seq INT IDENTITY(1,1), LayerID BIGINT, Q DECIMAL(18,3), V DECIMAL(18,3));
    INSERT #B (LayerID, Q, V)
    SELECT LayerID, LyQtyRem, LyValueRem FROM dbo.Wrh_Layer WITH (UPDLOCK)
    WHERE LyWhID = @Wh AND LyItemID = @Item AND LyQtyRem > 0 ORDER BY LyDate, LayerID;

    DECLARE @n INT = (SELECT COUNT(*) FROM #B), @tq DECIMAL(18,3), @tv DECIMAL(18,3), @i INT = 1, @given DECIMAL(18,3) = 0,
            @lid BIGINT, @q DECIMAL(18,3), @nv DECIMAL(18,3);
    IF @n >= 2
    BEGIN
        SELECT @tq = SUM(Q), @tv = SUM(V) FROM #B;
        WHILE @i <= @n
        BEGIN
            SELECT @lid = LayerID, @q = Q FROM #B WHERE Seq = @i;
            SET @nv = CASE WHEN @i = @n THEN @tv - @given ELSE ROUND(@tv * CAST(@q AS DECIMAL(18,6)) / @tq, 3) END;
            UPDATE dbo.Wrh_Layer SET LyValueRem = @nv, LyUnitCost = ROUND(@nv / @q, 6) WHERE LayerID = @lid;
            SET @given = @given + @nv;
            SET @i = @i + 1;
        END
    END
    DROP TABLE #B;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_ConsumeFifo
    @Wh BIGINT, @Item BIGINT, @Qty DECIMAL(18,3), @UseLineID BIGINT,
    @LayerOnly BIGINT = NULL, @Total DECIMAL(18,3) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @need DECIMAL(18,3) = @Qty, @lid BIGINT, @rem DECIMAL(18,3), @vrem DECIMAL(18,3),
            @cost DECIMAL(18,6), @take DECIMAL(18,3), @val DECIMAL(18,3);
    SET @Total = 0;

    -- المتوسط المرجح: نوحّد تكلفة طبقات المخزن/الصنف قبل الصرف فيخرج الصرف بالمتوسط تمامًا
    IF @LayerOnly IS NULL AND ISNULL((SELECT s.WsCostMethod FROM dbo.Wrh_Settings AS s
         WHERE s.WsCmpID = (SELECT TOP 1 LyCmpID FROM dbo.Wrh_Layer WHERE LyWhID = @Wh AND LyItemID = @Item)), 1) = 2
        EXEC dbo.Wrh_Rebalance @Wh, @Item;

    DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
        SELECT LayerID, LyQtyRem, LyValueRem, LyUnitCost
        FROM dbo.Wrh_Layer WITH (UPDLOCK)
        WHERE LyWhID = @Wh AND LyItemID = @Item AND LyQtyRem > 0 AND (@LayerOnly IS NULL OR LayerID = @LayerOnly)
        ORDER BY LyDate, LayerID;
    OPEN cur;
    FETCH NEXT FROM cur INTO @lid, @rem, @vrem, @cost;
    WHILE @@FETCH_STATUS = 0 AND @need > 0
    BEGIN
        SET @take = CASE WHEN @need < @rem THEN @need ELSE @rem END;
        SET @val  = CASE WHEN @take = @rem THEN @vrem ELSE ROUND(@take * @cost, 3) END;   -- آخر ما يتبقى يأخذ الباقي كاملًا
        IF @val > @vrem SET @val = @vrem;

        UPDATE dbo.Wrh_Layer SET LyQtyRem = LyQtyRem - @take, LyValueRem = LyValueRem - @val WHERE LayerID = @lid;
        INSERT dbo.Wrh_LayerUse (UseLineID, UseLayerID, UseQty, UseValue) VALUES (@UseLineID, @lid, @take, @val);

        SET @need = @need - @take;
        SET @Total = @Total + @val;
        FETCH NEXT FROM cur INTO @lid, @rem, @vrem, @cost;
    END
    CLOSE cur; DEALLOCATE cur;

    IF @need > 0 THROW 52401, N'الكمية المتاحة في طبقات المخزن لا تكفي.', 1;
END;
GO

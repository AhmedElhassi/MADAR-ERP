/* اختبار المرحلة 6 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_Rebalance') IS NULL THROW 52900, N'نفّذ Wrh_06_Avg.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #D (DocID BIGINT, DocNo NVARCHAR(10), DocStatus TINYINT);

DECLARE @C INT = 99995;
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Leaf BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                        WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @d DATE = '2026-03-01';

DECLARE @W1 BIGINT, @P BIGINT, @G BIGINT, @u1 BIGINT, @I BIGINT, @sI NVARCHAR(20), @sU NVARCHAR(20), @L NVARCHAR(MAX);
DECLARE @inv BIGINT, @il BIGINT, @rl1 BIGINT, @rl2 BIGINT, @rl3 BIGINT, @iss1 BIGINT, @iss2 BIGINT, @iss3 BIGINT, @x BIGINT, @e INT;
DECLARE @q DECIMAL(18,3), @v DECIMAL(18,3), @q2 DECIMAL(18,3), @v2 DECIMAL(18,3), @n INT;

IF @U IS NULL OR @Leaf IS NULL OR @CC IS NULL
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وحساب ورقي ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;

    INSERT dbo.Wrh_Settings (WsCmpID, WsCostMethod) VALUES (@C, 2);

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W1', N'مخزن 1', @Leaf; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'P1', N'مورد', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'G1', N'مجموعة', @Leaf; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I1', N'صنف 1', @u1; SELECT @I = Id FROM #I;
    SET @sI = CAST(@I AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20));

    -- استلام 100 × 10
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv = DocID FROM #D;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10,"RefLineID":', @il, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv, NULL, @L;
    -- استلام 50 × 12
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":50,"Price":12}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv = DocID FROM #D;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":50,"Price":12,"RefLineID":', @il, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv, NULL, @L;

    -- M1: صرف 60 بالمتوسط 1600/150 = 10.666667 → 640
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":60}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss1 = DocID FROM #D;
    SELECT @v = SUM(u.UseValue) FROM dbo.Wrh_LayerUse u JOIN dbo.Wrh_DocLine l ON l.LineID = u.UseLineID WHERE l.DocID = @iss1;
    SELECT @q = SUM(LyQtyRem), @v2 = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'M1 قيمة الصرف بالمتوسط', CASE WHEN @v = 640 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    INSERT @R VALUES (N'M1b المتبقي 90 بقيمة 960', CASE WHEN @q = 90 AND @v2 = 960 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v2));

    -- M2: استلام 30 × 14 ثم صرف 20 بالمتوسط 1380/120 = 11.5 → 230
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":30,"Price":14}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv = DocID FROM #D;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":30,"Price":14,"RefLineID":', @il, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv, NULL, @L;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":20}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss2 = DocID FROM #D;
    SELECT @v = SUM(u.UseValue) FROM dbo.Wrh_LayerUse u JOIN dbo.Wrh_DocLine l ON l.LineID = u.UseLineID WHERE l.DocID = @iss2;
    INSERT @R VALUES (N'M2 المتوسط بعد استلام بسعر جديد', CASE WHEN @v = 230 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));
    SELECT @q = SUM(LyQtyRem), @v2 = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'M2b المتبقي 100 بقيمة 1150', CASE WHEN @q = 100 AND @v2 = 1150 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v2));

    -- M3: حذف الصرف يعيد المجموع
    EXEC dbo.Wrh_DeleteDoc @C, @U, @iss2;
    SELECT @q = SUM(LyQtyRem), @v2 = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'M3 حذف الصرف يعيد الكمية والقيمة', CASE WHEN @q = 120 AND @v2 = 1380 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v2));

    -- M4: صرف كل الرصيد 120 = 1380 بالضبط وتصفير الطبقات
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":120}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss3 = DocID FROM #D;
    SELECT @v = SUM(u.UseValue) FROM dbo.Wrh_LayerUse u JOIN dbo.Wrh_DocLine l ON l.LineID = u.UseLineID WHERE l.DocID = @iss3;
    SELECT @q = SUM(LyQtyRem), @v2 = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'M4 صرف الكل يستهلك القيمة كاملة', CASE WHEN @v = 1380 AND @q = 0 AND @v2 = 0 THEN 1 ELSE 0 END, CONCAT(@v, N'/', @q, N'/', @v2));

    -- M5: التعديل (صرف 120 → 100) ثم العودة
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, @iss3, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SELECT @q = SUM(LyQtyRem), @v2 = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    SELECT @v = SUM(u.UseValue) FROM dbo.Wrh_LayerUse u JOIN dbo.Wrh_DocLine l ON l.LineID = u.UseLineID WHERE l.DocID = @iss3;
    INSERT @R VALUES (N'M5 تعديل الصرف إلى 100', CASE WHEN @q = 20 AND @v = 1150 AND @v2 = 230 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v, N'/', @v2));
    INSERT @R VALUES (N'M5b المجموع محفوظ', CASE WHEN @v + @v2 = 1380 THEN 1 ELSE 0 END, CONCAT(@v + @v2));

    -- M6: شركة FIFO لا تتأثر
    DELETE dbo.Wrh_Settings WHERE WsCmpID = @C;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @x = DocID FROM #D;
    SELECT @v = SUM(u.UseValue) FROM dbo.Wrh_LayerUse u JOIN dbo.Wrh_DocLine l ON l.LineID = u.UseLineID WHERE l.DocID = @x;
    INSERT @R VALUES (N'M6 بالإعداد FIFO يُصرف من أقدم طبقة بقيمتها', CASE WHEN @v > 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));

    ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #D;

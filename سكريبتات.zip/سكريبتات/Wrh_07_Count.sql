﻿/* =====================================================================
   المرحلة 7: الجرد (نوع 13) + إقفال السنة والأرشفة
   ---------------------------------------------------------------------
   الجرد: يُحفظ مسودة (حالة 1) بلا أثر على المخزون، ثم يُعتمد (حالة 3) بخطوة واحدة.
     - الفرق يُحسب عند الاعتماد = الكمية الفعلية − رصيد اللحظة.
     - عجز: يُصرف من الطبقات حسب إعداد الشركة (FIFO / متوسط).
     - زيادة: طبقة جديدة بتاريخ الجرد؛ تكلفتها سعر البند إن أُدخل، وإلا آخر طبقة (FIFO) أو المتوسط (متوسط مرجح).
     - الصنف غير المدرج في الجرد لا يُمس؛ والمعدوم فعليًا يُدخَل بكمية 0.
     - فصل المهام: المعتمِد غير المنشئ إذا كان WsSeparateDuties = 1.
     - الجرد المعتمد لا يُعدَّل ولا يُحذف؛ التصحيح بجرد جديد.
     - مفاتيح استهلاك/إنشاء الطبقات للجرد سالبة (−CntLineID) لتمييزها عن بنود المستندات.
   الإقفال: Wrh_CloseYear يحدد تاريخ إقفال فتُنقل الطبقات المستهلكة كليًا (وعائلتها كلها مستهلكة)
     مع استهلاكاتها إلى جداول أرشيف، ويُمنع أي إنشاء/تعديل/حذف لمستند بتاريخ ≤ تاريخ الإقفال (trigger).
   الأخطاء: 52701 المحجوز أكبر من الكمية الفعلية   52702 المعتمِد هو المنشئ   52703 الجرد ليس مسودة
            52704 بنود الجرد غير صحيحة   52705 لا تكلفة للزيادة   52706 المستند غير موجود/ليس جردًا
            52707 مخزن/مستخدم/تاريخ غير صحيح   52710 مستندات مفتوحة   52711 مسودات جرد   52712 تاريخ إقفال غير صالح
            52720 الفترة مقفلة
   يتطلب Wrh_01 .. Wrh_06. نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF COL_LENGTH(N'dbo.Wrh_Settings', N'WsClosedUpTo') IS NULL
    ALTER TABLE dbo.Wrh_Settings ADD WsClosedUpTo DATE NULL;
GO

IF OBJECT_ID(N'dbo.Wrh_CountLine', N'U') IS NULL
    CREATE TABLE dbo.Wrh_CountLine
    (
        CntLineID  BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_CountLine PRIMARY KEY,
        CntDocID   BIGINT NOT NULL CONSTRAINT FK_Wrh_CountLine_Doc  REFERENCES dbo.Wrh_Doc (DocID),
        ItemID     BIGINT NOT NULL CONSTRAINT FK_Wrh_CountLine_Item REFERENCES dbo.Wrh_Item (ItemID),
        UnitID     BIGINT NOT NULL,
        Factor     DECIMAL(18,6) NOT NULL,
        Qty        DECIMAL(18,3) NOT NULL,            -- الكمية الفعلية بوحدة الإدخال
        CountedQty DECIMAL(18,3) NOT NULL,            -- بالوحدة الأساس
        Price      DECIMAL(18,6) NULL,                -- تكلفة وحدة الأساس للزيادة (اختياري)
        SysQty     DECIMAL(18,3) NULL,                -- رصيد لحظة الاعتماد
        DiffQty    DECIMAL(18,3) NULL,                -- موجب زيادة، سالب عجز
        UnitCost   DECIMAL(18,6) NULL,
        DiffValue  DECIMAL(18,3) NULL,                -- موجب زيادة، سالب عجز
        CONSTRAINT CK_Wrh_CountLine CHECK (Qty >= 0 AND CountedQty >= 0)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_CountLine_Doc' AND object_id = OBJECT_ID(N'dbo.Wrh_CountLine'))
    CREATE UNIQUE INDEX IX_Wrh_CountLine_Doc ON dbo.Wrh_CountLine (CntDocID, ItemID);
GO

IF OBJECT_ID(N'dbo.Wrh_YearClose', N'U') IS NULL
    CREATE TABLE dbo.Wrh_YearClose
    (
        CloseID     BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Wrh_YearClose PRIMARY KEY,
        CloseCmpID  INT NOT NULL,
        CloseDate   DATE NOT NULL,
        CloseBy     BIGINT NOT NULL,
        CloseAt     DATETIME2(0) NOT NULL CONSTRAINT DF_Wrh_YearClose_At DEFAULT (SYSUTCDATETIME()),
        LayersMoved INT NOT NULL,
        UsesMoved   INT NOT NULL
    );
GO
IF OBJECT_ID(N'dbo.Wrh_LayerArchive', N'U') IS NULL
    CREATE TABLE dbo.Wrh_LayerArchive
    (
        LayerID BIGINT NOT NULL CONSTRAINT PK_Wrh_LayerArchive PRIMARY KEY,
        LyCmpID INT NOT NULL, LyWhID BIGINT NOT NULL, LyItemID BIGINT NOT NULL, LyRootID BIGINT NOT NULL, LyDate DATE NOT NULL,
        LyQtyIn DECIMAL(18,3) NOT NULL, LyQtyRem DECIMAL(18,3) NOT NULL, LyValueIn DECIMAL(18,3) NOT NULL, LyValueRem DECIMAL(18,3) NOT NULL,
        LyUnitCost DECIMAL(18,6) NOT NULL, LySrcLineID BIGINT NOT NULL,
        ArchCloseID BIGINT NOT NULL
    );
GO
IF OBJECT_ID(N'dbo.Wrh_LayerUseArchive', N'U') IS NULL
    CREATE TABLE dbo.Wrh_LayerUseArchive
    (
        UseID BIGINT NOT NULL CONSTRAINT PK_Wrh_LayerUseArchive PRIMARY KEY,
        UseLineID BIGINT NOT NULL, UseLayerID BIGINT NOT NULL, UseQty DECIMAL(18,3) NOT NULL, UseValue DECIMAL(18,3) NOT NULL,
        ArchCloseID BIGINT NOT NULL
    );
GO

/* ------------------------------------------------------------------ قفل الفترة المقفلة */
CREATE OR ALTER TRIGGER dbo.TR_Wrh_Doc_Closed ON dbo.Wrh_Doc
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1
               FROM (SELECT DocCmpID, DocDate FROM inserted UNION ALL SELECT DocCmpID, DocDate FROM deleted) AS x
               JOIN dbo.Wrh_Settings AS s ON s.WsCmpID = x.DocCmpID
               WHERE s.WsClosedUpTo IS NOT NULL AND x.DocDate <= s.WsClosedUpTo)
        THROW 52720, N'الفترة مقفلة: لا يجوز إنشاء أو تعديل أو حذف مستند بتاريخ ضمن الفترة المقفلة.', 1;
END;
GO

/* ------------------------------------------------------------------ حفظ مسودة جرد
   @Lines: [{"ItemID":1,"UnitID":1,"Qty":95,"Price":null}, ...]   Qty = 0 للمعدوم فعليًا */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveCount
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Date DATE, @WhID BIGINT, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52707, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52707, N'المستخدم غير موجود.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52707, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52704, N'بنود الجرد غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6), Factor DECIMAL(18,6), Base DECIMAL(18,3));
    INSERT #L (Ord, ItemID, UnitID, Qty, Price)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID', Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) OR EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty < 0 OR (Price IS NOT NULL AND Price < 0))
        THROW 52704, N'كل بند جرد يحتاج صنفًا ووحدة وكمية (صفر فأكثر).', 1;
    IF EXISTS (SELECT 1 FROM #L GROUP BY ItemID HAVING COUNT(*) > 1) THROW 52704, N'صنف مكرر في الجرد.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemID = l.ItemID AND ItemCmpID = @Cmp))
        THROW 52704, N'صنف غير موجود أو لا يتبع الشركة.', 1;

    UPDATE l SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL) THROW 52704, N'وحدة غير معرّفة لأحد الأصناف.', 1;
    UPDATE #L SET Base = ROUND(Qty * Factor, 3);

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveCount;

    BEGIN TRY
        DECLARE @Year INT = YEAR(@Date), @DocNo NVARCHAR(10), @Kind TINYINT = 1;
        SET @Notes = NULLIF(LTRIM(RTRIM(@Notes)), N'');

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OSt TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OSt = DocStatus, @OYear = DocYear, @DocNo = DocNo
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
            IF @OType IS NULL OR @OType <> 13 THROW 52706, N'المستند غير موجود أو ليس جردًا.', 1;
            IF @OSt <> 1 THROW 52703, N'الجرد المعتمد لا يُعدَّل.', 1;
            IF @OYear <> @Year THROW 52707, N'لا يجوز تغيير تاريخ الجرد إلى سنة أخرى.', 1;
            DELETE dbo.Wrh_CountLine WHERE CntDocID = @DocID;
            UPDATE dbo.Wrh_Doc SET DocDate = @Date, DocWhID = @WhID, DocNotes = @Notes WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, 13, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, 13, @Year, @DocNo, @Date, 1, @WhID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_CountLine (CntDocID, ItemID, UnitID, Factor, Qty, CountedQty, Price)
        SELECT @DocID, ItemID, UnitID, Factor, Qty, Base, Price FROM #L ORDER BY Ord;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, 13, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveCount;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ اعتماد الجرد */
CREATE OR ALTER PROCEDURE dbo.Wrh_ApproveCount
    @Cmp INT, @User BIGINT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52707, N'المستخدم غير موجود.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_ApproveCount;

    BEGIN TRY
        DECLARE @Type TINYINT, @St TINYINT, @Wh BIGINT, @Date DATE, @By BIGINT, @No NVARCHAR(10);
        SELECT @Type = DocType, @St = DocStatus, @Wh = DocWhID, @Date = DocDate, @By = DocCreatedBy, @No = DocNo
        FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
        IF @Type IS NULL OR @Type <> 13 THROW 52706, N'المستند غير موجود أو ليس جردًا.', 1;
        IF @St <> 1 THROW 52703, N'الجرد ليس مسودة.', 1;
        IF @By = @User AND ISNULL((SELECT WsSeparateDuties FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1) = 1
            THROW 52702, N'فصل المهام: لا يعتمد الجرد من أنشأه.', 1;

        DECLARE @Method TINYINT = ISNULL((SELECT WsCostMethod FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1);
        DECLARE @cl BIGINT, @neg BIGINT, @item BIGINT, @cq DECIMAL(18,3), @price DECIMAL(18,6), @cur DECIMAL(18,3), @rsv DECIMAL(18,3),
                @diff DECIMAL(18,3), @need DECIMAL(18,3), @tot DECIMAL(18,3), @cost DECIMAL(18,6), @val DECIMAL(18,3),
                @sq DECIMAL(18,3), @sv DECIMAL(18,3);

        DECLARE cur CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
            SELECT CntLineID, ItemID, CountedQty, Price FROM dbo.Wrh_CountLine WHERE CntDocID = @DocID ORDER BY ItemID;
        OPEN cur; FETCH NEXT FROM cur INTO @cl, @item, @cq, @price;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @neg = -@cl;
            EXEC dbo.Wrh_StockEnsure @Cmp, @Wh, @item;
            SELECT @cur = StkQty, @rsv = StkReserved FROM dbo.Wrh_Stock WITH (UPDLOCK, HOLDLOCK) WHERE StkWhID = @Wh AND StkItemID = @item;
            SET @diff = @cq - @cur;

            IF @diff < 0
            BEGIN
                IF @cq < @rsv THROW 52701, N'الكمية الفعلية أقل من المحجوز لأوامر تحويل مفتوحة؛ عالجها أولًا.', 1;
                SET @need = -@diff;
                EXEC dbo.Wrh_ConsumeFifo @Wh, @item, @need, @neg, NULL, @tot OUTPUT;
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty - @need WHERE StkWhID = @Wh AND StkItemID = @item;
                UPDATE dbo.Wrh_CountLine SET SysQty = @cur, DiffQty = @diff, UnitCost = ROUND(@tot / @need, 6), DiffValue = -@tot WHERE CntLineID = @cl;
            END
            ELSE IF @diff > 0
            BEGIN
                SET @cost = @price;
                IF @cost IS NULL AND @Method = 2
                BEGIN
                    SELECT @sq = SUM(LyQtyRem), @sv = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @Wh AND LyItemID = @item AND LyQtyRem > 0;
                    IF ISNULL(@sq, 0) > 0 SET @cost = ROUND(@sv / @sq, 6);
                END
                IF @cost IS NULL
                    SELECT TOP 1 @cost = LyUnitCost FROM dbo.Wrh_Layer WHERE LyWhID = @Wh AND LyItemID = @item ORDER BY LyDate DESC, LayerID DESC;
                IF @cost IS NULL THROW 52705, N'لا توجد تكلفة لزيادة الجرد: أدخل سعر الوحدة في البند.', 1;
                SET @val = ROUND(@diff * @cost, 3);
                INSERT dbo.Wrh_Layer (LyCmpID, LyWhID, LyItemID, LyRootID, LyDate, LyQtyIn, LyQtyRem, LyValueIn, LyValueRem, LyUnitCost, LySrcLineID)
                VALUES (@Cmp, @Wh, @item, 0, @Date, @diff, @diff, @val, @val, @cost, @neg);
                UPDATE dbo.Wrh_Layer SET LyRootID = LayerID WHERE LySrcLineID = @neg AND LyRootID = 0;
                UPDATE dbo.Wrh_Stock SET StkQty = StkQty + @diff WHERE StkWhID = @Wh AND StkItemID = @item;
                UPDATE dbo.Wrh_CountLine SET SysQty = @cur, DiffQty = @diff, UnitCost = @cost, DiffValue = @val WHERE CntLineID = @cl;
            END
            ELSE
                UPDATE dbo.Wrh_CountLine SET SysQty = @cur, DiffQty = 0, UnitCost = NULL, DiffValue = 0 WHERE CntLineID = @cl;

            FETCH NEXT FROM cur INTO @cl, @item, @cq, @price;
        END
        CLOSE cur; DEALLOCATE cur;

        UPDATE dbo.Wrh_Doc SET DocStatus = 3 WHERE DocID = @DocID;
        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser) VALUES (@Cmp, @DocID, @No, 13, 5, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @No AS DocNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_ApproveCount;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ حذف مسودة جرد */
CREATE OR ALTER PROCEDURE dbo.Wrh_DeleteCount
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52707, N'المستخدم غير موجود.', 1;
    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_DeleteCount;
    BEGIN TRY
        DECLARE @Type TINYINT, @St TINYINT, @No NVARCHAR(10);
        SELECT @Type = DocType, @St = DocStatus, @No = DocNo FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;
        IF @Type IS NULL OR @Type <> 13 THROW 52706, N'المستند غير موجود أو ليس جردًا.', 1;
        IF @St <> 1 THROW 52703, N'الجرد المعتمد لا يُحذف؛ صحّحه بجرد جديد.', 1;
        DELETE dbo.Wrh_CountLine WHERE CntDocID = @DocID;
        DELETE dbo.Wrh_Doc WHERE DocID = @DocID;
        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        VALUES (@Cmp, @DocID, @No, 13, 3, @User, NULLIF(LTRIM(RTRIM(@Reason)), N''));
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_DeleteCount;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ قراءة جرد: الرأس ثم البنود (الرصيد الحالي للمسودة) */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectCount
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocCmpID = @Cmp AND DocType = 13)
        THROW 52706, N'المستند غير موجود أو ليس جردًا.', 1;
    SELECT d.DocID, d.DocNo, d.DocDate, d.DocStatus, d.DocWhID, w.WhName, d.DocNotes, d.DocCreatedBy, d.DocCreatedAt
    FROM dbo.Wrh_Doc AS d JOIN dbo.Wrh_Warehouse AS w ON w.WhID = d.DocWhID WHERE d.DocID = @DocID;
    SELECT c.CntLineID, c.ItemID, i.ItemCode, i.ItemName, c.UnitID, c.Qty, c.CountedQty,
           CASE WHEN d.DocStatus = 1 THEN ISNULL(s.StkQty, 0) ELSE c.SysQty END AS SysQty,
           CASE WHEN d.DocStatus = 1 THEN c.CountedQty - ISNULL(s.StkQty, 0) ELSE c.DiffQty END AS DiffQty,
           c.Price, c.UnitCost, c.DiffValue
    FROM dbo.Wrh_CountLine AS c
    JOIN dbo.Wrh_Doc AS d ON d.DocID = c.CntDocID
    JOIN dbo.Wrh_Item AS i ON i.ItemID = c.ItemID
    LEFT JOIN dbo.Wrh_Stock AS s ON s.StkWhID = d.DocWhID AND s.StkItemID = c.ItemID
    WHERE c.CntDocID = @DocID ORDER BY i.ItemCode;
END;
GO

/* ------------------------------------------------------------------ إقفال السنة والأرشفة */
CREATE OR ALTER PROCEDURE dbo.Wrh_CloseYear
    @Cmp INT, @User BIGINT, @CloseDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR @CloseDate IS NULL THROW 52712, N'الشركة وتاريخ الإقفال مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52707, N'المستخدم غير موجود.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp AND WsClosedUpTo IS NOT NULL AND WsClosedUpTo >= @CloseDate)
        THROW 52712, N'تاريخ الإقفال يجب أن يكون بعد تاريخ آخر إقفال.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocCmpID = @Cmp AND DocType = 13 AND DocStatus = 1 AND DocDate <= @CloseDate)
        THROW 52711, N'توجد مسودات جرد غير معتمدة حتى تاريخ الإقفال.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocCmpID = @Cmp AND DocStatus IN (1, 2) AND DocDate <= @CloseDate)
        THROW 52710, N'توجد مستندات مفتوحة حتى تاريخ الإقفال؛ أنهِها أو ألغِها أولًا.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_CloseYear;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp) INSERT dbo.Wrh_Settings (WsCmpID) VALUES (@Cmp);

        INSERT dbo.Wrh_YearClose (CloseCmpID, CloseDate, CloseBy, LayersMoved, UsesMoved) VALUES (@Cmp, @CloseDate, @User, 0, 0);
        DECLARE @CloseID BIGINT = SCOPE_IDENTITY(), @nl INT, @nu INT;

        CREATE TABLE #A (LayerID BIGINT PRIMARY KEY);
        INSERT #A (LayerID)
        SELECT l.LayerID FROM dbo.Wrh_Layer AS l WITH (UPDLOCK)
        WHERE l.LyCmpID = @Cmp AND l.LyQtyRem = 0 AND l.LyDate <= @CloseDate
          AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Layer AS y WHERE y.LyRootID = l.LyRootID AND y.LyQtyRem > 0);

        INSERT dbo.Wrh_LayerUseArchive (UseID, UseLineID, UseLayerID, UseQty, UseValue, ArchCloseID)
        SELECT u.UseID, u.UseLineID, u.UseLayerID, u.UseQty, u.UseValue, @CloseID FROM dbo.Wrh_LayerUse AS u JOIN #A AS a ON a.LayerID = u.UseLayerID;
        SET @nu = @@ROWCOUNT;
        DELETE u FROM dbo.Wrh_LayerUse AS u JOIN #A AS a ON a.LayerID = u.UseLayerID;
        DELETE x FROM dbo.Wrh_CostAdjLayer AS x JOIN #A AS a ON a.LayerID = x.LayerID;

        INSERT dbo.Wrh_LayerArchive (LayerID, LyCmpID, LyWhID, LyItemID, LyRootID, LyDate, LyQtyIn, LyQtyRem, LyValueIn, LyValueRem, LyUnitCost, LySrcLineID, ArchCloseID)
        SELECT l.LayerID, l.LyCmpID, l.LyWhID, l.LyItemID, l.LyRootID, l.LyDate, l.LyQtyIn, l.LyQtyRem, l.LyValueIn, l.LyValueRem, l.LyUnitCost, l.LySrcLineID, @CloseID
        FROM dbo.Wrh_Layer AS l JOIN #A AS a ON a.LayerID = l.LayerID;
        SET @nl = @@ROWCOUNT;
        DELETE l FROM dbo.Wrh_Layer AS l JOIN #A AS a ON a.LayerID = l.LayerID;
        DROP TABLE #A;

        UPDATE dbo.Wrh_YearClose SET LayersMoved = @nl, UsesMoved = @nu WHERE CloseID = @CloseID;
        UPDATE dbo.Wrh_Settings SET WsClosedUpTo = @CloseDate WHERE WsCmpID = @Cmp;

        IF @Started = 1 COMMIT;
        SELECT @CloseID AS CloseID, @nl AS LayersMoved, @nu AS UsesMoved;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_CloseYear;
        THROW;
    END CATCH
END;
GO

/* اختبار المرحلة 7 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_CloseYear') IS NULL THROW 52900, N'نفّذ Wrh_07_Count.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #D (DocID BIGINT, DocNo NVARCHAR(10), DocStatus TINYINT);
CREATE TABLE #K (DocID BIGINT, DocNo NVARCHAR(10));

DECLARE @C INT = 99994;
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Leaf BIGINT = (SELECT TOP 1 a.AccID FROM dbo.Acc_Account a
                        WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account b WHERE b.AccParentID = a.AccID) ORDER BY a.AccID);
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @d DATE = '2026-03-01';

DECLARE @W1 BIGINT, @W2 BIGINT, @P BIGINT, @G BIGINT, @u1 BIGINT, @I BIGINT, @I2 BIGINT, @I3 BIGINT, @I4 BIGINT, @I5 BIGINT;
DECLARE @sI NVARCHAR(20), @sI2 NVARCHAR(20), @sI3 NVARCHAR(20), @sI4 NVARCHAR(20), @sI5 NVARCHAR(20), @sU NVARCHAR(20), @L NVARCHAR(MAX);
DECLARE @inv BIGINT, @il BIGINT, @cnt1 BIGINT, @cnt2 BIGINT, @cnt3 BIGINT, @ord BIGINT, @x BIGINT, @e INT, @stx TINYINT;
DECLARE @q DECIMAL(18,3), @v DECIMAL(18,3), @q2 DECIMAL(18,3), @v2 DECIMAL(18,3), @n INT, @n2 INT;

IF @U IS NULL OR @Leaf IS NULL OR @CC IS NULL
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وحساب ورقي ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W1', N'مخزن 1', @Leaf; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'W2', N'مخزن 2', @Leaf; SELECT @W2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'P1', N'مورد', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'G1', N'مجموعة', @Leaf; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I1', N'صنف 1', @u1; SELECT @I = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I2', N'صنف 2', @u1; SELECT @I2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I3', N'صنف 3', @u1; SELECT @I3 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I4', N'صنف 4', @u1; SELECT @I4 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'I5', N'صنف 5', @u1; SELECT @I5 = Id FROM #I;
    SET @sI = CAST(@I AS NVARCHAR(20)); SET @sI2 = CAST(@I2 AS NVARCHAR(20)); SET @sI3 = CAST(@I3 AS NVARCHAR(20));
    SET @sI4 = CAST(@I4 AS NVARCHAR(20)); SET @sI5 = CAST(@I5 AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20));

    -- أرصدة أولية: I 100×10 ، I2 50×8 ، I5 10×10
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":50,"Price":8},{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @d, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv = DocID FROM #D;
    DECLARE @la BIGINT, @lb BIGINT, @lc BIGINT;
    SELECT @la = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv AND ItemID = @I;
    SELECT @lb = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv AND ItemID = @I2;
    SELECT @lc = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv AND ItemID = @I5;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100,"Price":10,"RefLineID":', @la, N'},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":50,"Price":8,"RefLineID":', @lb, N'},{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @lc, N'}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @d, @W1, NULL, @P, NULL, @inv, NULL, @L;

    -- N1: مسودة جرد: I=95 ، I2=50 (بلا فرق) ، I3=4 بسعر 5 (زيادة صنف بلا رصيد)
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":95},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":50},{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":4,"Price":5}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, N'جرد', @L; SELECT @cnt1 = DocID FROM #K;
    SELECT @stx = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @cnt1;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    SELECT @n = COUNT(*) FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt1;
    INSERT @R VALUES (N'N1 المسودة بلا أثر على المخزون', CASE WHEN @stx = 1 AND @q = 100 AND @n = 3 THEN 1 ELSE 0 END, CONCAT(@stx, N'/', @q, N'/', @n));

    -- N2: تعديل المسودة I=90
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":90},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":50},{"ItemID":', @sI3, N',"UnitID":', @sU, N',"Qty":4,"Price":5}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCount @C, @U, @cnt1, @d, @W1, N'جرد', @L;
    SELECT @q = CountedQty FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt1 AND ItemID = @I;
    SELECT @n = COUNT(*) FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt1;
    INSERT @R VALUES (N'N2 تعديل المسودة', CASE WHEN @q = 90 AND @n = 3 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @n));

    -- N3: فصل المهام (الافتراضي مفعّل)
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_ApproveCount @C, @U, @cnt1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N3 المنشئ لا يعتمد (فصل المهام)', CASE WHEN @e = 52702 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- N4: تعطيل فصل المهام ثم الاعتماد
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @C) INSERT dbo.Wrh_Settings (WsCmpID) VALUES (@C);
    UPDATE dbo.Wrh_Settings SET WsSeparateDuties = 0 WHERE WsCmpID = @C;
    EXEC dbo.Wrh_ApproveCount @C, @U, @cnt1;
    SELECT @stx = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @cnt1;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    SELECT @q2 = DiffQty, @v = DiffValue, @v2 = SysQty FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt1 AND ItemID = @I;
    INSERT @R VALUES (N'N4 عجز 10 يُصرف بقيمة 100', CASE WHEN @stx = 3 AND @q = 90 AND @q2 = -10 AND @v = -100 AND @v2 = 100 THEN 1 ELSE 0 END, CONCAT(@stx, N'/', @q, N'/', @q2, N'/', @v, N'/', @v2));
    SELECT @q = SUM(LyQtyRem), @v = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'N4b طبقات الصنف بعد العجز', CASE WHEN @q = 90 AND @v = 900 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v));
    SELECT @q2 = DiffQty, @v = DiffValue FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt1 AND ItemID = @I2;
    INSERT @R VALUES (N'N4c بلا فرق', CASE WHEN @q2 = 0 AND @v = 0 THEN 1 ELSE 0 END, CONCAT(@q2, N'/', @v));
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I3;
    SELECT @v = LyValueIn, @n = CASE WHEN LyRootID = LayerID THEN 1 ELSE 0 END FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I3;
    INSERT @R VALUES (N'N4d زيادة بسعر البند: طبقة جديدة', CASE WHEN @q = 4 AND @v = 20 AND @n = 1 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v, N'/', @n));

    -- N5: المعتمد لا يُعدَّل ولا يُحذف
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCount @C, @U, @cnt1, @d, @W1, N'جرد', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N5 منع تعديل جرد معتمد', CASE WHEN @e = 52703 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteCount @C, @U, @cnt1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N5b منع حذف جرد معتمد', CASE WHEN @e = 52703 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_ApproveCount @C, @U, @cnt1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N5c منع اعتماد جرد معتمد', CASE WHEN @e = 52703 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- N6: زيادة على صنف له طبقات بلا سعر: بآخر طبقة (10) → +10 = 100
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":100}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, NULL, @L; SELECT @cnt2 = DocID FROM #K;
    EXEC dbo.Wrh_ApproveCount @C, @U, @cnt2;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    SELECT @q2 = DiffQty, @v = DiffValue FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt2;
    INSERT @R VALUES (N'N6 زيادة بتكلفة آخر طبقة', CASE WHEN @q = 100 AND @q2 = 10 AND @v = 100 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @q2, N'/', @v));
    SELECT @q = SUM(LyQtyRem), @v = SUM(LyValueRem) FROM dbo.Wrh_Layer WHERE LyWhID = @W1 AND LyItemID = @I;
    INSERT @R VALUES (N'N6b مجموع الطبقات = الرصيد', CASE WHEN @q = 100 AND @v = 1000 THEN 1 ELSE 0 END, CONCAT(@q, N'/', @v));

    -- N7: زيادة بلا أي تكلفة
    SET @L = CONCAT(N'[{"ItemID":', @sI4, N',"UnitID":', @sU, N',"Qty":5}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, NULL, @L; SELECT @cnt3 = DocID FROM #K;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_ApproveCount @C, @U, @cnt3; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N7 زيادة بلا تكلفة', CASE WHEN @e = 52705 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @stx = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @cnt3;
    INSERT @R VALUES (N'N7b الجرد بقي مسودة', CASE WHEN @stx = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @stx));
    EXEC dbo.Wrh_DeleteCount @C, @U, @cnt3, N'اختبار';
    SELECT @n = COUNT(*) FROM dbo.Wrh_Doc WHERE DocID = @cnt3; SELECT @n2 = COUNT(*) FROM dbo.Wrh_CountLine WHERE CntDocID = @cnt3;
    INSERT @R VALUES (N'N7c حذف المسودة', CASE WHEN @n = 0 AND @n2 = 0 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @n2));

    -- N8: بنود غير صحيحة
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":1},{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":2}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N8 صنف مكرر', CASE WHEN @e = 52704 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":-1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N8b كمية سالبة', CASE WHEN @e = 52704 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, NULL, N'[]'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N8c بنود فارغة', CASE WHEN @e = 52704 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, 0, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N8d مخزن غير موجود', CASE WHEN @e = 52707 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_ApproveCount @C, @U, @inv; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N8e اعتماد مستند ليس جردًا', CASE WHEN @e = 52706 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- N9: المحجوز لأمر تحويل مفتوح يمنع جردًا أقل منه
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":30}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @d, @W1, @W2, NULL, NULL, NULL, NULL, @L; SELECT @ord = DocID FROM #D;
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":20}]');
    DELETE #K; INSERT #K EXEC dbo.Wrh_SaveCount @C, @U, 0, @d, @W1, NULL, @L; SELECT @cnt3 = DocID FROM #K;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_ApproveCount @C, @U, @cnt3; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N9 الجرد أقل من المحجوز', CASE WHEN @e = 52701 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'N9b الرصيد لم يتغير بعد الرفض', CASE WHEN @q = 100 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));

    -- N10: مسودة جرد قبل الإقفال تمنعه
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_CloseYear @C, @U, '2026-03-31'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N10 مسودة جرد تمنع الإقفال', CASE WHEN @e = 52711 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    EXEC dbo.Wrh_DeleteCount @C, @U, @cnt3, N'اختبار';

    -- N11: أمر تحويل مفتوح يمنع الإقفال
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_CloseYear @C, @U, '2026-03-31'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N11 مستند مفتوح يمنع الإقفال', CASE WHEN @e = 52710 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    DELETE #I; INSERT #I EXEC dbo.Wrh_CancelDoc @C, @U, @ord, NULL, N'اختبار';

    -- N12: صرف كل I5 (الطبقة تُستهلك كليًا) ثم الإقفال
    SET @L = CONCAT(N'[{"ItemID":', @sI5, N',"UnitID":', @sU, N',"Qty":10}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @d, @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SELECT @n = COUNT(*) FROM dbo.Wrh_Layer WHERE LyCmpID = @C;
    EXEC dbo.Wrh_CloseYear @C, @U, '2026-03-31';
    SELECT @n2 = COUNT(*) FROM dbo.Wrh_Layer WHERE LyCmpID = @C;
    INSERT @R VALUES (N'N12 نُقلت الطبقة المستهلكة فقط', CASE WHEN @n - @n2 = 1 THEN 1 ELSE 0 END, CONCAT(@n, N'->', @n2));
    SELECT @n = COUNT(*) FROM dbo.Wrh_LayerArchive WHERE LyCmpID = @C AND LyItemID = @I5;
    SELECT @n2 = COUNT(*) FROM dbo.Wrh_LayerUseArchive;
    INSERT @R VALUES (N'N12b الأرشيف يحوي الطبقة واستهلاكها', CASE WHEN @n = 1 AND @n2 >= 1 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @n2));
    SELECT @q = SUM(LyQtyRem) FROM dbo.Wrh_Layer WHERE LyCmpID = @C AND LyItemID = @I;
    INSERT @R VALUES (N'N12c الطبقات الحيّة باقية', CASE WHEN @q = 100 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));
    SELECT @n = COUNT(*) FROM dbo.Wrh_YearClose WHERE CloseCmpID = @C AND LayersMoved = 1;
    INSERT @R VALUES (N'N12d سجل الإقفال', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- N13: بعد التاريخ المقفل يعمل
    SET @L = CONCAT(N'[{"ItemID":', @sI, N',"UnitID":', @sU, N',"Qty":1}]');
    DELETE #D; INSERT #D EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, '2026-04-01', @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SELECT @q = StkQty FROM dbo.Wrh_Stock WHERE StkWhID = @W1 AND StkItemID = @I;
    INSERT @R VALUES (N'N13d بعد التاريخ المقفل يعمل', CASE WHEN @q = 99 THEN 1 ELSE 0 END, CONCAT(N'got ', @q));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_CloseYear @C, @U, '2026-03-31'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N13e إقفال بتاريخ غير لاحق', CASE WHEN @e = 52712 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- N14: الجرد بالمتوسط المرجح للعجز
    SELECT @n = COUNT(*) FROM dbo.Wrh_DocEvent WHERE EvCmpID = @C AND EvDocType = 13 AND EvKind = 5;
    INSERT @R VALUES (N'N14 أحداث الاعتماد مسجلة', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- N15: القفل (آخر اختبار: خطأ الـ trigger يُفسد المعاملة الخارجية في الاختبار فقط)
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, '2026-03-15', @W1, NULL, NULL, @CC, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N15 منع مستند في فترة مقفلة', CASE WHEN @e = 52720 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    IF @@TRANCOUNT > 0 ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #D; DROP TABLE #K;

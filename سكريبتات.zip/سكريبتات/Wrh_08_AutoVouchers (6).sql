﻿/* =====================================================================
   المرحلة 8: القيود الآلية للمخازن والمشتريات
   ---------------------------------------------------------------------
   - توليد يدوي بيد المحاسب على دفعات: Wrh_GenerateAutoVouchers (@Preview = 1 للمعاينة بلا كتابة).
   - لكل نوع عملية مصدر مستقل (SourceID = 1000 + نوع المستند)، ولكل (مصدر، وحدة، تاريخ) قيد أو أكثر
     (حد المستندات في القيد = WsMaxAutoVoucherDocs). المخزن وحدة للأنواع 4 5 8 9 10 13 فقط.
   - في القيد: سطر إجمالي واحد للطرف المشترك (مثل حساب المخزن)، وسطر (أو أكثر) لكل مستند للطرف الآخر.
   - المستند الناقص حسابه أو الفاسد يبقى معلّقًا مع سبب، ولا يوقف بقية المستندات.
   - حالة القيد حسب WsAutoVoucherState (0 مؤقت، 1 مُرحَّل). الشركة بلا حساب إشعار دائن تبقى إشعاراتها معلّقة.
   - القفل: لا يُعدَّل مستند له قيد ولا يُحذف (52801)، ولا تُعدَّل بنود القيد الآلي (52802).
     لتعديل المستند: Wrh_UnlinkAutoVoucher (القيد مؤقت أو مُعاد فقط) يحلّ القيد كله فيعود كل مستنداته معلّقة.
   - إعداد الحسابات: Wrh_SetAccounts (فروق التكلفة، مقابل إشعار الدائن، فروق الجرد).
   الأخطاء: 52801 مستند مقفل بقيده  52802 بنود قيد آلي مقفلة  52803 حالة القيد لا تسمح  52804 المستند بلا قيد
            52805 حساب غير صالح  52807 معطيات غير صحيحة
   يتطلب Wrh_01 .. Wrh_07 وإجراءات القيود اليومية. نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF COL_LENGTH(N'dbo.Wrh_Settings', N'WsCreditNoteAccID') IS NULL ALTER TABLE dbo.Wrh_Settings ADD WsCreditNoteAccID BIGINT NULL;
IF COL_LENGTH(N'dbo.Wrh_Settings', N'WsCountAccID')      IS NULL ALTER TABLE dbo.Wrh_Settings ADD WsCountAccID      BIGINT NULL;
GO

IF OBJECT_ID(N'dbo.Acc_AutoSource', N'U') IS NULL
    CREATE TABLE dbo.Acc_AutoSource
    (
        SourceID     INT           NOT NULL CONSTRAINT PK_Acc_AutoSource PRIMARY KEY,
        SourceName   NVARCHAR(100) NOT NULL,
        SourceSystem NVARCHAR(20)  NOT NULL,
        UnitKind     TINYINT       NOT NULL CONSTRAINT DF_Acc_AutoSource_Unit DEFAULT (0)   -- 0 بلا وحدة  1 مخزن  2 خزينة
    );
GO
MERGE dbo.Acc_AutoSource AS t
USING (SELECT 1000 + d.DtType AS SourceID, d.DtName AS SourceName,
              CASE WHEN d.DtType IN (4, 5, 8, 9, 10, 13) THEN 1 ELSE 0 END AS UnitKind
       FROM dbo.Wrh_DocTypeDef AS d WHERE d.DtType IN (4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15)) AS s
ON t.SourceID = s.SourceID
WHEN NOT MATCHED THEN INSERT (SourceID, SourceName, SourceSystem, UnitKind) VALUES (s.SourceID, s.SourceName, N'Wrh', s.UnitKind);
GO

IF OBJECT_ID(N'dbo.Acc_AutoVoucher', N'U') IS NULL
    CREATE TABLE dbo.Acc_AutoVoucher
    (
        AvID         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_AutoVoucher PRIMARY KEY,
        AvCompany    INT    NOT NULL,
        AvDayMID     BIGINT NOT NULL CONSTRAINT FK_Acc_AutoVoucher_Day REFERENCES dbo.Acc_DayMaster (DayMID),
        AvSource     INT    NOT NULL CONSTRAINT FK_Acc_AutoVoucher_Src REFERENCES dbo.Acc_AutoSource (SourceID),
        AvSourceUnit BIGINT NULL,
        AvDate       DATE   NOT NULL,
        AvSeq        INT    NOT NULL,
        AvCreatedAt  DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_AutoVoucher_At DEFAULT (SYSUTCDATETIME()),
        AvCreatedBy  BIGINT NOT NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Acc_AutoVoucher_Day' AND object_id = OBJECT_ID(N'dbo.Acc_AutoVoucher'))
    CREATE UNIQUE INDEX UX_Acc_AutoVoucher_Day ON dbo.Acc_AutoVoucher (AvDayMID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Acc_AutoVoucher_Key' AND object_id = OBJECT_ID(N'dbo.Acc_AutoVoucher'))
    CREATE UNIQUE INDEX UX_Acc_AutoVoucher_Key ON dbo.Acc_AutoVoucher (AvCompany, AvSource, AvSourceUnit, AvDate, AvSeq);
GO

IF OBJECT_ID(N'dbo.Acc_AutoVoucherLine', N'U') IS NULL
    CREATE TABLE dbo.Acc_AutoVoucherLine
    (
        AvID        BIGINT NOT NULL CONSTRAINT FK_Acc_AutoVoucherLine_Av REFERENCES dbo.Acc_AutoVoucher (AvID),
        SourceDocID BIGINT NOT NULL,
        LineSource  INT    NOT NULL,
        DayDID      BIGINT NULL,
        CONSTRAINT PK_Acc_AutoVoucherLine PRIMARY KEY (AvID, SourceDocID)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Acc_AutoVoucherLine_Doc' AND object_id = OBJECT_ID(N'dbo.Acc_AutoVoucherLine'))
    CREATE UNIQUE INDEX UX_Acc_AutoVoucherLine_Doc ON dbo.Acc_AutoVoucherLine (LineSource, SourceDocID);
GO

/* ------------------------------------------------------------------ أقفال */
CREATE OR ALTER TRIGGER dbo.TR_Acc_DayDetails_AutoLock ON dbo.Acc_DayDetails
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) = 1 RETURN;
    IF EXISTS (SELECT 1 FROM (SELECT DayDMID FROM inserted UNION SELECT DayDMID FROM deleted) AS x
               JOIN dbo.Acc_AutoVoucher AS a ON a.AvDayMID = x.DayDMID)
        THROW 52802, N'هذا قيد آلي: لا تُعدَّل بنوده. أرجِع مستنده بـ Wrh_UnlinkAutoVoucher ثم عدّل المستند وأعد التوليد.', 1;
END;
GO
CREATE OR ALTER TRIGGER dbo.TR_Acc_DayMaster_AutoLock ON dbo.Acc_DayMaster
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) = 1 RETURN;
    IF EXISTS (SELECT 1 FROM deleted AS d
               JOIN dbo.Acc_AutoVoucher AS a ON a.AvDayMID = d.DayMID
               LEFT JOIN inserted AS i ON i.DayMID = d.DayMID
               WHERE i.DayMID IS NULL OR i.DayMDate <> d.DayMDate OR ISNULL(i.DayMDescription, N'') <> ISNULL(d.DayMDescription, N''))
        THROW 52802, N'هذا قيد آلي: لا يُعدَّل تاريخه أو شرحه ولا يُحذف.', 1;
END;
GO
CREATE OR ALTER TRIGGER dbo.TR_Wrh_Doc_AutoLock ON dbo.Wrh_Doc
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) = 1 RETURN;
    IF EXISTS (SELECT 1 FROM deleted AS d
               JOIN dbo.Acc_AutoVoucherLine AS l ON l.SourceDocID = d.DocID AND l.LineSource = 1000 + d.DocType
               LEFT JOIN inserted AS i ON i.DocID = d.DocID
               WHERE i.DocID IS NULL OR i.DocDate <> d.DocDate OR ISNULL(i.DocWhID, 0) <> ISNULL(d.DocWhID, 0)
                  OR ISNULL(i.DocWh2ID, 0) <> ISNULL(d.DocWh2ID, 0) OR ISNULL(i.DocPartyID, 0) <> ISNULL(d.DocPartyID, 0)
                  OR ISNULL(i.DocCostCID, 0) <> ISNULL(d.DocCostCID, 0))
        THROW 52801, N'لهذا المستند قيد آلي: لا يُعدَّل ولا يُحذف. أرجِعه من القيد بـ Wrh_UnlinkAutoVoucher أولًا.', 1;
END;
GO
CREATE OR ALTER TRIGGER dbo.TR_Wrh_DocLine_AutoLock ON dbo.Wrh_DocLine
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) = 1 RETURN;
    IF EXISTS (SELECT 1
               FROM (SELECT DocID FROM inserted UNION SELECT DocID FROM deleted) AS x
               JOIN dbo.Wrh_Doc AS h ON h.DocID = x.DocID
               JOIN dbo.Acc_AutoVoucherLine AS l ON l.SourceDocID = h.DocID AND l.LineSource = 1000 + h.DocType)
       AND (   NOT EXISTS (SELECT 1 FROM inserted) OR NOT EXISTS (SELECT 1 FROM deleted)
            OR EXISTS (SELECT 1 FROM inserted AS i JOIN deleted AS d ON d.LineID = i.LineID
                       WHERE i.ItemID <> d.ItemID OR i.UnitID <> d.UnitID OR i.Qty <> d.Qty OR i.BaseQty <> d.BaseQty
                          OR i.Amount <> d.Amount OR i.DocLineNo <> d.DocLineNo))
        THROW 52801, N'لهذا المستند قيد آلي: لا تُعدَّل بنوده. أرجِعه من القيد بـ Wrh_UnlinkAutoVoucher أولًا.', 1;
END;
GO

/* ------------------------------------------------------------------ حسابات الإعدادات (NULL = بلا تغيير، 0 = مسح) */
CREATE OR ALTER PROCEDURE dbo.Wrh_SetAccounts
    @Cmp INT, @User BIGINT, @DiffAccID BIGINT = NULL, @CreditNoteAccID BIGINT = NULL, @CountAccID BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52807, N'الشركة أو المستخدم غير صحيح.', 1;
    IF EXISTS (SELECT 1 FROM (VALUES (@DiffAccID), (@CreditNoteAccID), (@CountAccID)) AS v(a)
               WHERE v.a > 0 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS a
                   WHERE a.AccID = v.a AND a.AccCompany = @Cmp
                     AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
                     AND ((a.AccEnd = 1 AND a.AccType IN (0, 1, 2)) OR (a.AccEnd = 2 AND a.AccType IN (0, 1)))))
        THROW 52805, N'حساب غير موجود أو لا يتبع الشركة أو ليس تحليليًا صالحًا للقيد.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp) INSERT dbo.Wrh_Settings (WsCmpID) VALUES (@Cmp);
    UPDATE dbo.Wrh_Settings
       SET WsDiffAccID       = CASE WHEN @DiffAccID       IS NULL THEN WsDiffAccID       WHEN @DiffAccID       = 0 THEN NULL ELSE @DiffAccID       END,
           WsCreditNoteAccID = CASE WHEN @CreditNoteAccID IS NULL THEN WsCreditNoteAccID WHEN @CreditNoteAccID = 0 THEN NULL ELSE @CreditNoteAccID END,
           WsCountAccID      = CASE WHEN @CountAccID      IS NULL THEN WsCountAccID      WHEN @CountAccID      = 0 THEN NULL ELSE @CountAccID      END,
           WsUpdatedBy = @User, WsUpdatedAt = SYSUTCDATETIME()
     WHERE WsCmpID = @Cmp;
END;
GO

/* ------------------------------------------------------------------ بناء الأسطر الخام لمستندات #AD
   يتوقع المستدعي إنشاء: #AD(DocID) ، #L(DocID,Kind,AccID,CcID,Deb,Crd,Tag) ، #Bad(DocID,Reason)
   Kind 1 = طرف مشترك يُجمَّع في القيد، Kind 2 = أسطر المستند نفسه */
CREATE OR ALTER PROCEDURE dbo.Wrh_AutoBuild
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Diff BIGINT, @CN BIGINT, @CA BIGINT;
    SELECT @Diff = WsDiffAccID, @CN = WsCreditNoteAccID, @CA = WsCountAccID FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp;

    CREATE TABLE #X (DocID BIGINT PRIMARY KEY, Typ TINYINT, Wh BIGINT, Wh2 BIGINT, Party BIGINT, CC BIGINT, RefDoc BIGINT,
                     WhAcc BIGINT, Wh2Acc BIGINT, PartyAcc BIGINT);
    INSERT #X (DocID, Typ, Wh, Wh2, Party, CC, RefDoc, WhAcc, Wh2Acc, PartyAcc)
    SELECT d.DocID, d.DocType, d.DocWhID, d.DocWh2ID, d.DocPartyID, d.DocCostCID, d.DocRefDocID, w.WhAccID, w2.WhAccID, p.PrtAccID
    FROM #AD AS a JOIN dbo.Wrh_Doc AS d ON d.DocID = a.DocID
    LEFT JOIN dbo.Wrh_Warehouse AS w ON w.WhID = d.DocWhID
    LEFT JOIN dbo.Wrh_Warehouse AS w2 ON w2.WhID = d.DocWh2ID
    LEFT JOIN dbo.Prt_Party AS p ON p.PrtID = d.DocPartyID;

    -- قيم البنود
    CREATE TABLE #LV (DocID BIGINT, LineID BIGINT, GrpAcc BIGINT, Amount DECIMAL(18,3), UseVal DECIMAL(18,3), LayerVal DECIMAL(18,3));
    INSERT #LV (DocID, LineID, GrpAcc, Amount, UseVal, LayerVal)
    SELECT l.DocID, l.LineID, g.GrpAccID, l.Amount,
           ISNULL((SELECT SUM(u.UseValue) FROM dbo.Wrh_LayerUse AS u WHERE u.UseLineID = l.LineID), 0),
           ISNULL((SELECT SUM(y.LyValueIn) FROM dbo.Wrh_Layer AS y WHERE y.LySrcLineID = l.LineID AND y.LyWhID = x.Wh), 0)
    FROM #X AS x JOIN dbo.Wrh_DocLine AS l ON l.DocID = x.DocID
    JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID JOIN dbo.Wrh_ItemGroup AS g ON g.GrpID = i.ItemGrpID;

    -- 4 استلام مخزني: من المخزن ← إلى الجهة
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, s.v, 0, N'حساب المخزن' FROM #X x JOIN (SELECT DocID, SUM(Amount) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 4;
    INSERT #L SELECT x.DocID, 2, x.PartyAcc, NULL, 0, s.v, N'حساب الجهة' FROM #X x JOIN (SELECT DocID, SUM(Amount) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 4;
    -- 5 صرف مخزني: من مجموعة المواد (مركز الجهة) ← إلى المخزن
    INSERT #L SELECT x.DocID, 2, s.GrpAcc, x.CC, s.v, 0, N'حساب مجموعة المواد' FROM #X x JOIN (SELECT DocID, GrpAcc, SUM(UseVal) v FROM #LV GROUP BY DocID, GrpAcc) s ON s.DocID = x.DocID WHERE x.Typ = 5;
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, 0, s.v, N'حساب المخزن' FROM #X x JOIN (SELECT DocID, SUM(UseVal) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 5;
    -- 6 صرف مباشر: من مجموعة المواد (مركز الجهة) ← إلى الجهة
    INSERT #L SELECT x.DocID, 2, s.GrpAcc, x.CC, s.v, 0, N'حساب مجموعة المواد' FROM #X x JOIN (SELECT DocID, GrpAcc, SUM(Amount) v FROM #LV GROUP BY DocID, GrpAcc) s ON s.DocID = x.DocID WHERE x.Typ = 6;
    INSERT #L SELECT x.DocID, 2, x.PartyAcc, NULL, 0, s.v, N'حساب الجهة' FROM #X x JOIN (SELECT DocID, SUM(Amount) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 6;
    -- 8 استلام تحويل: من المخزن المستلم ← إلى المخزن الصارف
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, s.v, 0, N'حساب المخزن' FROM #X x JOIN (SELECT DocID, SUM(UseVal) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 8;
    INSERT #L SELECT x.DocID, 2, x.Wh2Acc, NULL, 0, s.v, N'حساب المخزن الصارف' FROM #X x JOIN (SELECT DocID, SUM(UseVal) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 8;
    -- 9 استرجاع من جهة: من المخزن ← إلى مجموعة المواد (مركز الجهة)
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, s.v, 0, N'حساب المخزن' FROM #X x JOIN (SELECT DocID, SUM(LayerVal) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 9;
    INSERT #L SELECT x.DocID, 2, s.GrpAcc, x.CC, 0, s.v, N'حساب مجموعة المواد' FROM #X x JOIN (SELECT DocID, GrpAcc, SUM(LayerVal) v FROM #LV GROUP BY DocID, GrpAcc) s ON s.DocID = x.DocID WHERE x.Typ = 9;
    -- 10 ترجيع مخزني للمورد: من الجهة ← إلى المخزن
    INSERT #L SELECT x.DocID, 2, x.PartyAcc, NULL, s.v, 0, N'حساب الجهة' FROM #X x JOIN (SELECT DocID, SUM(UseVal) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 10;
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, 0, s.v, N'حساب المخزن' FROM #X x JOIN (SELECT DocID, SUM(UseVal) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 10;
    -- 11 ترجيع مباشر للمورد: من الجهة ← إلى مجموعة المواد (مركز الجهة)
    INSERT #L SELECT x.DocID, 2, x.PartyAcc, NULL, s.v, 0, N'حساب الجهة' FROM #X x JOIN (SELECT DocID, SUM(Amount) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 11;
    INSERT #L SELECT x.DocID, 2, s.GrpAcc, x.CC, 0, s.v, N'حساب مجموعة المواد' FROM #X x JOIN (SELECT DocID, GrpAcc, SUM(Amount) v FROM #LV GROUP BY DocID, GrpAcc) s ON s.DocID = x.DocID WHERE x.Typ = 11;
    -- 12 إشعار دائن: من الجهة ← إلى حساب الإعدادات
    INSERT #L SELECT x.DocID, 2, x.PartyAcc, NULL, s.v, 0, N'حساب الجهة' FROM #X x JOIN (SELECT DocID, SUM(Amount) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 12;
    INSERT #L SELECT x.DocID, 2, @CN, NULL, 0, s.v, N'حساب مقابل إشعار الدائن (الإعدادات)' FROM #X x JOIN (SELECT DocID, SUM(Amount) v FROM #LV GROUP BY DocID) s ON s.DocID = x.DocID WHERE x.Typ = 12;
    -- 13 جرد: الزيادة من المخزن ← إلى فروق الجرد، والعجز بالعكس
    CREATE TABLE #CV (DocID BIGINT PRIMARY KEY, S DECIMAL(18,3), D DECIMAL(18,3));
    INSERT #CV SELECT c.CntDocID, SUM(CASE WHEN c.DiffValue > 0 THEN c.DiffValue ELSE 0 END), SUM(CASE WHEN c.DiffValue < 0 THEN -c.DiffValue ELSE 0 END)
    FROM dbo.Wrh_CountLine AS c JOIN #X x ON x.DocID = c.CntDocID WHERE x.Typ = 13 GROUP BY c.CntDocID;
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, v.S, 0, N'حساب المخزن' FROM #X x JOIN #CV v ON v.DocID = x.DocID WHERE v.S > 0;
    INSERT #L SELECT x.DocID, 1, x.WhAcc, NULL, 0, v.D, N'حساب المخزن' FROM #X x JOIN #CV v ON v.DocID = x.DocID WHERE v.D > 0;
    INSERT #L SELECT x.DocID, 2, @CA, NULL, 0, v.S, N'حساب فروق الجرد (الإعدادات)' FROM #X x JOIN #CV v ON v.DocID = x.DocID WHERE v.S > 0;
    INSERT #L SELECT x.DocID, 2, @CA, NULL, v.D, 0, N'حساب فروق الجرد (الإعدادات)' FROM #X x JOIN #CV v ON v.DocID = x.DocID WHERE v.D > 0;
    -- 14 تكلفة إضافية: من المخزن (وفروق التكلفة) ← إلى الجهات؛ 15 تسوية: بالإشارة
    CREATE TABLE #WV (DocID BIGINT, Wh BIGINT, Val DECIMAL(18,3));
    INSERT #WV (DocID, Wh, Val)
    SELECT a.AdjDocID, ly.LyWhID, SUM(y.AddValue)
    FROM dbo.Wrh_CostAdj AS a JOIN #X x ON x.DocID = a.AdjDocID AND x.Typ IN (14, 15)
    JOIN dbo.Wrh_CostAdjLayer AS y ON y.AdjID = a.AdjID JOIN dbo.Wrh_Layer AS ly ON ly.LayerID = y.LayerID
    GROUP BY a.AdjDocID, ly.LyWhID;
    INSERT #WV (DocID, Wh, Val)   -- ما لم تغطّه طبقات حيّة (مؤرشفة مثلًا) يُنسب لمخزن المستند المرجعي
    SELECT x.DocID, r.DocWhID, t.Rem - ISNULL(w.V, 0)
    FROM #X x JOIN dbo.Wrh_Doc AS r ON r.DocID = x.RefDoc
    JOIN (SELECT AdjDocID, SUM(AdjRemPart) AS Rem FROM dbo.Wrh_CostAdj GROUP BY AdjDocID) AS t ON t.AdjDocID = x.DocID
    LEFT JOIN (SELECT DocID, SUM(Val) AS V FROM #WV GROUP BY DocID) AS w ON w.DocID = x.DocID
    WHERE x.Typ IN (14, 15) AND t.Rem - ISNULL(w.V, 0) <> 0;
    INSERT #L SELECT w.DocID, 1, wh.WhAccID, NULL, CASE WHEN w.Val > 0 THEN w.Val ELSE 0 END, CASE WHEN w.Val < 0 THEN -w.Val ELSE 0 END, N'حساب المخزن'
    FROM #WV w JOIN dbo.Wrh_Warehouse wh ON wh.WhID = w.Wh WHERE w.Val <> 0;
    INSERT #L SELECT x.DocID, 1, @Diff, NULL, CASE WHEN s.v > 0 THEN s.v ELSE 0 END, CASE WHEN s.v < 0 THEN -s.v ELSE 0 END, N'حساب فروق التكلفة (الإعدادات)'
    FROM #X x JOIN (SELECT AdjDocID, SUM(AdjConsPart) v FROM dbo.Wrh_CostAdj GROUP BY AdjDocID) s ON s.AdjDocID = x.DocID WHERE x.Typ IN (14, 15) AND s.v <> 0;
    INSERT #L SELECT x.DocID, 2, p.PrtAccID, NULL, 0, c.CostAmount, N'حساب الجهة'
    FROM #X x JOIN dbo.Wrh_CostLine c ON c.CostDocID = x.DocID JOIN dbo.Prt_Party p ON p.PrtID = c.CostPartyID WHERE x.Typ = 14;
    INSERT #L SELECT x.DocID, 2, x.PartyAcc, NULL, CASE WHEN s.v < 0 THEN -s.v ELSE 0 END, CASE WHEN s.v > 0 THEN s.v ELSE 0 END, N'حساب الجهة'
    FROM #X x JOIN (SELECT AdjDocID, SUM(AdjAmount) v FROM dbo.Wrh_CostAdj GROUP BY AdjDocID) s ON s.AdjDocID = x.DocID WHERE x.Typ = 15 AND s.v <> 0;

    DELETE #L WHERE Deb = 0 AND Crd = 0;

    -- أسباب التعليق
    INSERT #Bad (DocID, Reason)
    SELECT t.DocID, N'حساب غير محدد: ' + STUFF((SELECT DISTINCT N'، ' + l2.Tag FROM #L l2 WHERE l2.DocID = t.DocID AND l2.AccID IS NULL FOR XML PATH(N'')), 1, 2, N'')
    FROM (SELECT DISTINCT DocID FROM #L WHERE AccID IS NULL) t;
    INSERT #Bad (DocID, Reason)
    SELECT DISTINCT l.DocID, N'حساب غير صالح للقيد (غير موجود أو لشركة أخرى أو غير تحليلي): ' + l.Tag
    FROM #L l WHERE l.AccID IS NOT NULL AND l.DocID NOT IN (SELECT DocID FROM #Bad)
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account a WHERE a.AccID = l.AccID AND a.AccCompany = @Cmp
                      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account c WHERE c.AccParentID = a.AccID)
                      AND ((a.AccEnd = 1 AND a.AccType IN (0, 1, 2)) OR (a.AccEnd = 2 AND a.AccType IN (0, 1))));
    INSERT #Bad (DocID, Reason)
    SELECT l.DocID, N'قيد غير متوازن لهذا المستند (راجع طبقاته أو تكاليفه)'
    FROM #L l WHERE l.DocID NOT IN (SELECT DocID FROM #Bad) GROUP BY l.DocID HAVING SUM(l.Deb) <> SUM(l.Crd);
    INSERT #Bad (DocID, Reason)
    SELECT a.DocID, N'قيمته صفر: لا قيد له'
    FROM #AD a WHERE a.DocID NOT IN (SELECT DocID FROM #L) AND a.DocID NOT IN (SELECT DocID FROM #Bad);

    DELETE #L WHERE DocID IN (SELECT DocID FROM #Bad);
END;
GO

/* ------------------------------------------------------------------ توليد القيود
   @Type NULL = كل الأنواع. @Preview = 1 يعرض ما سيُولَّد ويُعلَّق بلا كتابة. @Quiet = 1 بلا نتائج (للاختبار). */
CREATE OR ALTER PROCEDURE dbo.Wrh_GenerateAutoVouchers
    @Cmp INT, @User BIGINT, @Type TINYINT = NULL, @FromDate DATE = NULL, @ToDate DATE = NULL,
    @Preview BIT = 0, @Quiet BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52807, N'الشركة أو المستخدم غير صحيح.', 1;
    IF @Type IS NOT NULL AND @Type NOT IN (4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15) THROW 52807, N'نوع مستند لا يُولَّد له قيد.', 1;

    DECLARE @Max INT = ISNULL((SELECT WsMaxAutoVoucherDocs FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 500);
    DECLARE @Post BIT = ISNULL((SELECT WsAutoVoucherState FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1);

    CREATE TABLE #AD (DocID BIGINT PRIMARY KEY);
    CREATE TABLE #L (DocID BIGINT, Kind TINYINT, AccID BIGINT, CcID BIGINT, Deb DECIMAL(18,3), Crd DECIMAL(18,3), Tag NVARCHAR(60));
    CREATE TABLE #Bad (DocID BIGINT, Reason NVARCHAR(300));

    INSERT #AD (DocID)
    SELECT d.DocID FROM dbo.Wrh_Doc AS d
    WHERE d.DocCmpID = @Cmp AND d.DocStatus = 3 AND d.DocType IN (4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15)
      AND (@Type IS NULL OR d.DocType = @Type) AND (@FromDate IS NULL OR d.DocDate >= @FromDate) AND (@ToDate IS NULL OR d.DocDate <= @ToDate)
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucherLine AS l WHERE l.SourceDocID = d.DocID AND l.LineSource = 1000 + d.DocType);

    EXEC dbo.Wrh_AutoBuild @Cmp;

    CREATE TABLE #G (DocID BIGINT PRIMARY KEY, Src INT, Unit BIGINT, Dt DATE, Seq INT);
    INSERT #G (DocID, Src, Unit, Dt, Seq)
    SELECT d.DocID, 1000 + d.DocType, CASE WHEN d.DocType IN (4, 5, 8, 9, 10, 13) THEN d.DocWhID END, d.DocDate, 0
    FROM dbo.Wrh_Doc d WHERE d.DocID IN (SELECT DocID FROM #L);

    UPDATE g SET Seq = b.Base + (g2.rn - 1) / @Max + 1
    FROM #G g
    JOIN (SELECT DocID, ROW_NUMBER() OVER (PARTITION BY Src, Unit, Dt ORDER BY DocID) AS rn FROM #G) g2 ON g2.DocID = g.DocID
    CROSS APPLY (SELECT ISNULL(MAX(v.AvSeq), 0) AS Base FROM dbo.Acc_AutoVoucher v
                 WHERE v.AvCompany = @Cmp AND v.AvSource = g.Src AND ISNULL(v.AvSourceUnit, 0) = ISNULL(g.Unit, 0) AND v.AvDate = g.Dt) b;

    CREATE TABLE #Made (AvID BIGINT, DayMID BIGINT, VoucherNo NVARCHAR(20), Src INT, Unit BIGINT, Dt DATE, Seq INT, Docs INT, Total DECIMAL(18,3));

    IF @Preview = 0 AND EXISTS (SELECT 1 FROM #G)
    BEGIN
        DECLARE @Started BIT = 0;
        IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
        ELSE SAVE TRANSACTION Sp_Wrh_GenerateAutoVouchers;

        BEGIN TRY
            EXEC sp_set_session_context N'Acc.SystemOperation', 1;
            EXEC sp_set_session_context N'Wrh.AutoGen', 1;

            DECLARE @Src INT, @Unit BIGINT, @Dt DATE, @Seq INT, @n INT, @dm BIGINT, @av BIGINT, @info NVARCHAR(400), @sname NVARCHAR(100), @tot DECIMAL(18,3), @vno NVARCHAR(20), @Yr INT;
            DECLARE vc CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
                SELECT Src, Unit, Dt, Seq, COUNT(*) FROM #G GROUP BY Src, Unit, Dt, Seq ORDER BY Src, Unit, Dt, Seq;
            OPEN vc; FETCH NEXT FROM vc INTO @Src, @Unit, @Dt, @Seq, @n;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                SELECT @sname = SourceName FROM dbo.Acc_AutoSource WHERE SourceID = @Src;
                CREATE TABLE #VL (SeqNo INT IDENTITY(1,1), DocID BIGINT NULL, AccID BIGINT, CcID BIGINT, Deb DECIMAL(18,3), Crd DECIMAL(18,3), Num NVARCHAR(50), Txt NVARCHAR(200));
                INSERT #VL (DocID, AccID, CcID, Deb, Crd, Num, Txt)
                SELECT l.DocID, l.AccID, l.CcID, l.Deb, l.Crd, d.DocNo, CONCAT(@sname, N' رقم ', d.DocNo)
                FROM #L l JOIN #G g ON g.DocID = l.DocID JOIN dbo.Wrh_Doc d ON d.DocID = l.DocID
                WHERE l.Kind = 2 AND g.Src = @Src AND ISNULL(g.Unit, 0) = ISNULL(@Unit, 0) AND g.Dt = @Dt AND g.Seq = @Seq
                ORDER BY l.DocID, l.Deb DESC;
                INSERT #VL (DocID, AccID, CcID, Deb, Crd, Num, Txt)
                SELECT NULL, x.AccID, x.CcID, CASE WHEN x.Net > 0 THEN x.Net ELSE 0 END, CASE WHEN x.Net < 0 THEN -x.Net ELSE 0 END, NULL, CONCAT(N'إجمالي ', @sname)
                FROM (SELECT l.AccID, l.CcID, SUM(l.Deb) - SUM(l.Crd) AS Net FROM #L l JOIN #G g ON g.DocID = l.DocID
                      WHERE l.Kind = 1 AND g.Src = @Src AND ISNULL(g.Unit, 0) = ISNULL(@Unit, 0) AND g.Dt = @Dt AND g.Seq = @Seq
                      GROUP BY l.AccID, l.CcID HAVING SUM(l.Deb) <> SUM(l.Crd)) x;

                DECLARE @Lines dbo.Acc_DayLineType;
                DELETE @Lines;
                INSERT @Lines (SeqNo, DayDAccID, DayDDeb, DayDCrd, DayDCsCID, DayDNum, DayDDescription)
                SELECT SeqNo, AccID, Deb, Crd, CcID, Num, Txt FROM #VL;
                SELECT @tot = SUM(Deb) FROM #VL;
                SET @info = CONCAT(N'قيد آلي - ', @sname, N' - ', CONVERT(NVARCHAR(10), @Dt, 23), N' (', @n, N' مستند)');

                CREATE TABLE #SR (DayMID BIGINT, DayMNo INT, DayMState TINYINT, VoucherNo NVARCHAR(20));
                SET @Yr = YEAR(@Dt);
                INSERT #SR EXEC dbo.Acc_SaveDayVoucher @Cmp, @Yr, @User, 0, @Dt, @info, @Post, @Lines;
                SELECT @dm = DayMID, @vno = VoucherNo FROM #SR; DROP TABLE #SR;

                INSERT dbo.Acc_AutoVoucher (AvCompany, AvDayMID, AvSource, AvSourceUnit, AvDate, AvSeq, AvCreatedBy)
                VALUES (@Cmp, @dm, @Src, @Unit, @Dt, @Seq, @User);
                SET @av = SCOPE_IDENTITY();

                INSERT dbo.Acc_AutoVoucherLine (AvID, SourceDocID, LineSource, DayDID)
                SELECT @av, g.DocID, @Src,
                       (SELECT MIN(m.DayDID) FROM (SELECT DayDID, ROW_NUMBER() OVER (ORDER BY DayDID) AS rn FROM dbo.Acc_DayDetails WHERE DayDMID = @dm) m
                        JOIN #VL v ON v.SeqNo = m.rn WHERE v.DocID = g.DocID)
                FROM #G g WHERE g.Src = @Src AND ISNULL(g.Unit, 0) = ISNULL(@Unit, 0) AND g.Dt = @Dt AND g.Seq = @Seq;

                INSERT #Made VALUES (@av, @dm, @vno, @Src, @Unit, @Dt, @Seq, @n, @tot);
                DROP TABLE #VL;
                FETCH NEXT FROM vc INTO @Src, @Unit, @Dt, @Seq, @n;
            END
            CLOSE vc; DEALLOCATE vc;

            EXEC sp_set_session_context N'Wrh.AutoGen', 0;
            EXEC sp_set_session_context N'Acc.SystemOperation', 0;
            IF @Started = 1 COMMIT;
        END TRY
        BEGIN CATCH
            EXEC sp_set_session_context N'Wrh.AutoGen', 0;
            EXEC sp_set_session_context N'Acc.SystemOperation', 0;
            IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
            ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_GenerateAutoVouchers;
            THROW;
        END CATCH
    END

    IF OBJECT_ID(N'tempdb..#PendingOut') IS NOT NULL
        INSERT #PendingOut (DocID, DocType, Reason)
        SELECT b.DocID, d.DocType, b.Reason FROM #Bad b JOIN dbo.Wrh_Doc d ON d.DocID = b.DocID;

    IF @Quiet = 0
    BEGIN
        IF @Preview = 1
            SELECT g.Src AS SourceID, s.SourceName, COUNT(*) AS ReadyDocs
            FROM #G g JOIN dbo.Acc_AutoSource s ON s.SourceID = g.Src GROUP BY g.Src, s.SourceName ORDER BY g.Src;
        ELSE
            SELECT m.AvID, m.DayMID, m.VoucherNo, s.SourceName, m.Unit AS WarehouseID, m.Dt AS VoucherDate, m.Seq, m.Docs, m.Total
            FROM #Made m JOIN dbo.Acc_AutoSource s ON s.SourceID = m.Src ORDER BY m.Src, m.Dt, m.Seq;
        SELECT b.DocID, d.DocType, t.DtName AS DocTypeName, d.DocNo, d.DocDate, b.Reason
        FROM #Bad b JOIN dbo.Wrh_Doc d ON d.DocID = b.DocID JOIN dbo.Wrh_DocTypeDef t ON t.DtType = d.DocType ORDER BY d.DocType, d.DocDate, d.DocNo;
    END
END;
GO

/* ------------------------------------------------------------------ إرجاع مستند من القيد (يحلّ القيد كله) */
CREATE OR ALTER PROCEDURE dbo.Wrh_UnlinkAutoVoucher
    @Cmp INT, @User BIGINT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52807, N'المستخدم غير موجود.', 1;

    DECLARE @Type TINYINT, @No NVARCHAR(10), @av BIGINT, @dm BIGINT, @st TINYINT, @n INT, @rsn NVARCHAR(500), @msg NVARCHAR(200);
    SELECT @Type = DocType, @No = DocNo FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocCmpID = @Cmp;
    IF @Type IS NULL THROW 52807, N'المستند غير موجود أو لا يتبع الشركة.', 1;
    SELECT @av = v.AvID, @dm = v.AvDayMID, @st = m.DayMState
    FROM dbo.Acc_AutoVoucherLine l JOIN dbo.Acc_AutoVoucher v ON v.AvID = l.AvID JOIN dbo.Acc_DayMaster m ON m.DayMID = v.AvDayMID
    WHERE l.SourceDocID = @DocID AND l.LineSource = 1000 + @Type AND v.AvCompany = @Cmp;
    IF @av IS NULL THROW 52804, N'هذا المستند ليس في قيد آلي.', 1;
    IF @st NOT IN (0, 2) THROW 52803, N'القيد في حالة لا تسمح بالإرجاع؛ أرجِعه أولًا إلى المحاسب (مؤقت أو معاد).', 1;

    -- آخر سبب رفض يُحفظ في أحداث كل مستند يعود إلى المعلّقة
    SELECT TOP (1) @rsn = DayMSReason FROM dbo.Acc_DayMasterState
    WHERE DayMSDayMID = @dm AND DayMSState IN (2, 4, 6) ORDER BY DayMSID DESC;
    SET @msg = LEFT(CONCAT(N'إرجاع من القيد الآلي', CASE WHEN @rsn IS NULL THEN N'' ELSE CONCAT(N' - سبب الرفض: ', @rsn) END), 200);

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_UnlinkAutoVoucher;
    BEGIN TRY
        EXEC sp_set_session_context N'Wrh.AutoGen', 1;
        EXEC sp_set_session_context N'Acc.SystemOperation', 1;
        SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucherLine WHERE AvID = @av;
        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
        SELECT @Cmp, d.DocID, d.DocNo, d.DocType, 6, @User, @msg
        FROM dbo.Acc_AutoVoucherLine l JOIN dbo.Wrh_Doc d ON d.DocID = l.SourceDocID AND l.LineSource = 1000 + d.DocType
        WHERE l.AvID = @av;
        DELETE dbo.Acc_AutoVoucherLine WHERE AvID = @av;
        DELETE dbo.Acc_AutoVoucher WHERE AvID = @av;
        UPDATE dbo.Acc_DayMaster SET DayMState = 0 WHERE DayMID = @dm;
        DELETE dbo.Acc_DayMasterState WHERE DayMSDayMID = @dm;
        EXEC dbo.Acc_DeleteDayVoucher @Cmp, @dm;
        EXEC sp_set_session_context N'Wrh.AutoGen', 0;
        EXEC sp_set_session_context N'Acc.SystemOperation', 0;
        IF @Started = 1 COMMIT;
        SELECT @n AS DocsReturnedToPending;
    END TRY
    BEGIN CATCH
        EXEC sp_set_session_context N'Wrh.AutoGen', 0;
        EXEC sp_set_session_context N'Acc.SystemOperation', 0;
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_UnlinkAutoVoucher;
        THROW;
    END CATCH
END;
GO

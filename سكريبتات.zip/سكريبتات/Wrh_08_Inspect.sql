/* فحص للقراءة فقط (لا يغيّر شيئًا): يعرض هيكل جداول القيود الآلية الحالية قبل بناء المرحلة 8.
   شغّله وأرسل لي كل النتائج (نصًا أو لقطة). */
USE [MADARERPDataBase];
SET NOCOUNT ON;

-- 1) أعمدة الجداول
SELECT t.name AS TableName, c.column_id AS Ord, c.name AS ColumnName,
       ty.name + CASE WHEN ty.name IN (N'nvarchar', N'varchar') THEN N'(' + CASE WHEN c.max_length = -1 THEN N'MAX' ELSE CAST(c.max_length / CASE WHEN ty.name = N'nvarchar' THEN 2 ELSE 1 END AS NVARCHAR(10)) END + N')'
                           WHEN ty.name IN (N'decimal', N'numeric') THEN N'(' + CAST(c.precision AS NVARCHAR(5)) + N',' + CAST(c.scale AS NVARCHAR(5)) + N')' ELSE N'' END AS DataType,
       c.is_nullable AS Nullable, c.is_identity AS IsIdentity
FROM sys.tables AS t
JOIN sys.columns AS c ON c.object_id = t.object_id
JOIN sys.types AS ty ON ty.user_type_id = c.user_type_id
WHERE t.name IN (N'Acc_AutoSource', N'Acc_AutoVoucher', N'Acc_AutoVoucherLine', N'Acc_DayMaster', N'Acc_DayDetails')
ORDER BY t.name, c.column_id;

-- 2) الفهارس والقيود
SELECT t.name AS TableName, i.name AS IndexName, i.is_unique AS IsUnique, i.is_primary_key AS IsPK,
       STUFF((SELECT N', ' + c.name FROM sys.index_columns AS ic JOIN sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
              WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0 ORDER BY ic.key_ordinal FOR XML PATH(N'')), 1, 2, N'') AS KeyColumns
FROM sys.tables AS t JOIN sys.indexes AS i ON i.object_id = t.object_id
WHERE t.name IN (N'Acc_AutoSource', N'Acc_AutoVoucher', N'Acc_AutoVoucherLine') AND i.type > 0
ORDER BY t.name, i.name;

SELECT OBJECT_NAME(parent_object_id) AS TableName, name AS ConstraintName, definition AS Def FROM sys.check_constraints
WHERE OBJECT_NAME(parent_object_id) IN (N'Acc_AutoSource', N'Acc_AutoVoucher', N'Acc_AutoVoucherLine');

SELECT OBJECT_NAME(parent_object_id) AS TableName, name AS FKName, OBJECT_NAME(referenced_object_id) AS RefTable FROM sys.foreign_keys
WHERE OBJECT_NAME(parent_object_id) IN (N'Acc_AutoSource', N'Acc_AutoVoucher', N'Acc_AutoVoucherLine');

-- 3) محتوى المصادر الحالية وعدد القيود الآلية
SELECT * FROM dbo.Acc_AutoSource;
SELECT COUNT(*) AS AutoVouchers FROM dbo.Acc_AutoVoucher;

-- 4) نوع أسطر القيد
SELECT c.column_id AS Ord, c.name AS ColumnName, ty.name AS DataType, c.max_length, c.precision, c.scale, c.is_nullable
FROM sys.table_types AS tt JOIN sys.columns AS c ON c.object_id = tt.type_table_object_id JOIN sys.types AS ty ON ty.user_type_id = c.user_type_id
WHERE tt.name = N'Acc_DayLineType' ORDER BY c.column_id;

-- 5) أعمدة حسابات جداول المخازن (للتأكد من الأسماء)
SELECT t.name AS TableName, c.name AS ColumnName FROM sys.tables AS t JOIN sys.columns AS c ON c.object_id = t.object_id
WHERE t.name IN (N'Wrh_ItemGroup', N'Wrh_Warehouse', N'Prt_Party') AND (c.name LIKE N'%Acc%' OR c.name LIKE N'%Cost%') ORDER BY t.name, c.column_id;

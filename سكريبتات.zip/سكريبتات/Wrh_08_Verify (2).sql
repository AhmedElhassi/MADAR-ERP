/* اختبار المرحلة 8 — داخل معاملة تُرجَع (لا أثر). يطبع FAIL فقط + سطر إجمالي.
   يستعمل شركة مركز التكلفة الموجود، وتواريخ سنة 2031 لعزل بياناته عن أي بيانات حقيقية. */
USE [MADARERPDataBase];
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Wrh_GenerateAutoVouchers') IS NULL THROW 52900, N'نفّذ Wrh_08_AutoVouchers.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
DECLARE @T TABLE (Src INT, Unit BIGINT, Acc BIGINT, Deb DECIMAL(18,3), Crd DECIMAL(18,3), Cnt INT);
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #D (DocID BIGINT, DocNo NVARCHAR(10), DocStatus TINYINT);
CREATE TABLE #K (DocID BIGINT, DocNo NVARCHAR(10));
CREATE TABLE #U (N INT);

DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @D1 DATE = '2031-03-01', @D2 DATE = '2031-03-02';

DECLARE @W1 BIGINT, @W2 BIGINT, @P BIGINT, @P0 BIGINT, @PT BIGINT, @G BIGINT, @u1 BIGINT, @I1 BIGINT, @I2 BIGINT;
DECLARE @A1 BIGINT, @A2 BIGINT, @AS BIGINT, @AT BIGINT, @AG BIGINT, @AD BIGINT, @AN BIGINT, @AC BIGINT;
DECLARE @sI1 NVARCHAR(20), @sI2 NVARCHAR(20), @sU NVARCHAR(20), @L NVARCHAR(MAX), @e INT;
DECLARE @inv1 BIGINT, @inv2 BIGINT, @inv5 BIGINT, @inv6 BIGINT, @il BIGINT, @R1 BIGINT, @R2 BIGINT, @R3 BIGINT, @R4 BIGINT, @rl1 BIGINT, @rl2 BIGINT;
DECLARE @iss BIGINT, @ord BIGINT, @ol BIGINT, @trf BIGINT, @cnt BIGINT, @dr6 BIGINT, @dr6l BIGINT, @ret11 BIGINT, @cn12 BIGINT, @cn12l BIGINT, @x BIGINT;
DECLARE @n INT, @q DECIMAL(18,3), @v DECIMAL(18,3), @dm BIGINT;

IF @CC IS NULL OR @U IS NULL
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;

    -- حسابات الاختبار (أوراق تحليلية)
    DECLARE @k INT = 0, @id BIGINT;
    DECLARE @ids TABLE (K INT, Id BIGINT);
    WHILE @k < 9
    BEGIN
        SET @k += 1;
        INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
        VALUES (1, 1, NULL, @k, 1, 0, CONCAT(N'ZZ8', @k), CONCAT(N'اختبار قيود ', @k), @U, @C);
        INSERT @ids VALUES (@k, CONVERT(BIGINT, SCOPE_IDENTITY()));
    END
    SELECT @A1 = Id FROM @ids WHERE K = 1; SELECT @A2 = Id FROM @ids WHERE K = 2; SELECT @AS = Id FROM @ids WHERE K = 3;
    SELECT @AT = Id FROM @ids WHERE K = 4; SELECT @AG = Id FROM @ids WHERE K = 5; SELECT @AD = Id FROM @ids WHERE K = 6;
    SELECT @AN = Id FROM @ids WHERE K = 7; SELECT @AC = Id FROM @ids WHERE K = 8;
    DECLARE @AE BIGINT; SELECT @AE = Id FROM @ids WHERE K = 9;

    EXEC dbo.Wrh_SetAccounts @C, @U, @AD, @AN, @AC;
    UPDATE dbo.Wrh_Settings SET WsSeparateDuties = 0 WHERE WsCmpID = @C;

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'ZW1', N'مخزن 1', @A1; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'ZW2', N'مخزن 2', @A2; SELECT @W2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'ZP1', N'مورد', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'ZP0', N'مورد بلا حساب', 1; SELECT @P0 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'ZP2', N'ناقل', 2; SELECT @PT = Id FROM #I;
    UPDATE dbo.Prt_Party SET PrtAccID = @AS WHERE PrtID = @P;
    UPDATE dbo.Prt_Party SET PrtAccID = @AT WHERE PrtID = @PT;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'ZG1', N'مجموعة', @AG; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة اختبار'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'ZI1', N'صنف 1', @u1; SELECT @I1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'ZI2', N'صنف 2', @u1; SELECT @I2 = Id FROM #I;
    SET @sI1 = CAST(@I1 AS NVARCHAR(20)); SET @sI2 = CAST(@I2 AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20));

    -- فاتورة + استلام (R1: I1 100×10 في W1)
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":100,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv1 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv1;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":100,"Price":10,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D1, @W1, NULL, @P, NULL, @inv1, NULL, @L; SELECT @R1 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 4;
    SELECT @rl1 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @R1;
    -- R2: I2 50×8 في W1
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":50,"Price":8}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv2 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv2;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":50,"Price":8,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D1, @W1, NULL, @P, NULL, @inv2, NULL, @L; SELECT @R2 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 4;
    SELECT @rl2 = LineID FROM dbo.Wrh_DocLine WHERE DocID = @R2;
    -- R3: I1 10×10 في W2
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W2, NULL, @P, NULL, NULL, NULL, @L; SELECT @x = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @x;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D1, @W2, NULL, @P, NULL, @x, NULL, @L; SELECT @R3 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 4;
    -- R4: استلام من مورد بلا حساب (يبقى معلّقًا)
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":5,"Price":8}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P0, NULL, NULL, NULL, @L; SELECT @x = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @x;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":5,"Price":8,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D1, @W1, NULL, @P0, NULL, @x, NULL, @L; SELECT @R4 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 4;

    -- صرف 30 (300) ، استرجاع من جهة 5 (50) ، ترجيع مخزني للمورد 5 (50)
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":30}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @D1, @W1, NULL, NULL, @CC, NULL, NULL, @L; SELECT @iss = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 5;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":5}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 9, @D1, @W1, NULL, NULL, @CC, NULL, NULL, @L;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":5,"Price":10,"RefLineID":', @rl1, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 10, @D1, @W1, NULL, @P, NULL, @R1, NULL, @L;
    -- تحويل I2 بكمية 10 من W1 إلى W2 (80)
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 7, @D1, @W1, @W2, NULL, NULL, NULL, NULL, @L; SELECT @ord = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 7;
    SELECT @ol = LineID FROM dbo.Wrh_DocLine WHERE DocID = @ord;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":10,"RefLineID":', @ol, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 8, @D1, @W2, @W1, NULL, NULL, @ord, NULL, @L; SELECT @trf = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 8;
    -- جرد W2: I1 فعلي 8 (عجز 2 = 20) و I2 فعلي 11 (زيادة 1 = 8)
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":8},{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":11}]');
    EXEC dbo.Wrh_SaveCount @C, @U, 0, @D1, @W2, NULL, @L; SELECT @cnt = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 13;
    EXEC dbo.Wrh_ApproveCount @C, @U, @cnt;
    -- تكلفة 200 على R1 (130 للمتبقي و70 فرق) وتسوية -40 على R2
    SET @L = CONCAT(N'[{"PartyID":', @PT, N',"Kind":1,"Amount":200}]');
    EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 14, @D1, @R1, NULL, NULL, @L, NULL;
    SET @L = CONCAT(N'[{"RefLineID":', @rl2, N',"Delta":-40}]');
    EXEC dbo.Wrh_SaveCostDoc @C, @U, 0, 15, @D1, @R2, @P, N'خصم', @L, NULL;
    -- إشعار دائن (فاتورة 20×10، إشعار 4×10 = 40)
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":20,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv5 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv5;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":4,"Price":10,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 12, @D1, NULL, NULL, @P, NULL, @inv5, NULL, @L; SELECT @cn12 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 12;
    -- صرف مباشر (فاتورة 10×10) ثم ترجيع مباشر 3
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv6 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv6;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 6, @D1, NULL, NULL, @P, @CC, @inv6, NULL, @L; SELECT @dr6 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 6;
    SELECT @dr6l = LineID FROM dbo.Wrh_DocLine WHERE DocID = @dr6;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":3,"Price":10,"RefLineID":', @dr6l, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 11, @D1, NULL, NULL, @P, @CC, @dr6, NULL, @L; SELECT @ret11 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 11;

    -- المعاينة لا تكتب
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, NULL, @D1, @D2, 1, 1;
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher WHERE AvCompany = @C;
    INSERT @R VALUES (N'G0 المعاينة بلا كتابة', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- التوليد الأول
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, NULL, @D1, @D2, 0, 1;
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher WHERE AvCompany = @C AND AvDate = @D1;
    INSERT @R VALUES (N'G1 عدد القيود المولَّدة 12', CASE WHEN @n = 12 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID = @R4;
    INSERT @R VALUES (N'G2 المستند بلا حساب جهة بقي معلّقًا', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID IN (@R1, @R2, @R3, @iss, @trf, @cnt, @cn12, @dr6, @ret11);
    INSERT @R VALUES (N'G3 ارتبطت مستندات الاختبار بقيودها', CASE WHEN @n = 9 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucherLine WHERE DayDID IS NULL AND AvID IN (SELECT AvID FROM dbo.Acc_AutoVoucher WHERE AvCompany = @C);
    INSERT @R VALUES (N'G4 كل مستند مربوط ببند قيد', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM (SELECT m.DayMID FROM dbo.Acc_DayMaster m JOIN dbo.Acc_AutoVoucher a ON a.AvDayMID = m.DayMID
        JOIN dbo.Acc_DayDetails d ON d.DayDMID = m.DayMID WHERE a.AvCompany = @C GROUP BY m.DayMID HAVING SUM(d.DayDDeb) <> SUM(d.DayDCrd)) z;
    INSERT @R VALUES (N'G5 كل القيود متوازنة', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher a JOIN dbo.Acc_DayMaster m ON m.DayMID = a.AvDayMID WHERE a.AvCompany = @C AND m.DayMState = 1;
    INSERT @R VALUES (N'G6 القيود مُرحّلة حسب الإعداد', CASE WHEN @n = 12 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    INSERT @T
    SELECT a.AvSource, ISNULL(a.AvSourceUnit, 0), d.DayDAccID, SUM(d.DayDDeb), SUM(d.DayDCrd), COUNT(*)
    FROM dbo.Acc_AutoVoucher a JOIN dbo.Acc_DayDetails d ON d.DayDMID = a.AvDayMID WHERE a.AvCompany = @C
    GROUP BY a.AvSource, ISNULL(a.AvSourceUnit, 0), d.DayDAccID;

    INSERT @R VALUES (N'V1 استلام W1: المخزن 1400 مجمّع والجهة سطران', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1004 AND Unit = @W1 AND Acc = @A1 AND Deb = 1400 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1004 AND Unit = @W1 AND Acc = @AS AND Deb = 0 AND Crd = 1400 AND Cnt = 2) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V2 استلام W2 قيد مستقل', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1004 AND Unit = @W2 AND Acc = @A2 AND Deb = 100 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1004 AND Unit = @W2 AND Acc = @AS AND Deb = 0 AND Crd = 100 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V3 الصرف: مجموعة المواد 300 / المخزن', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1005 AND Unit = @W1 AND Acc = @AG AND Deb = 300 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1005 AND Unit = @W1 AND Acc = @A1 AND Deb = 0 AND Crd = 300 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V4 استرجاع من جهة', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1009 AND Unit = @W1 AND Acc = @A1 AND Deb = 50 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1009 AND Unit = @W1 AND Acc = @AG AND Deb = 0 AND Crd = 50 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V5 ترجيع مخزني للمورد', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1010 AND Unit = @W1 AND Acc = @AS AND Deb = 50 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1010 AND Unit = @W1 AND Acc = @A1 AND Deb = 0 AND Crd = 50 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V6 استلام تحويل', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1008 AND Unit = @W2 AND Acc = @A2 AND Deb = 80 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1008 AND Unit = @W2 AND Acc = @A1 AND Deb = 0 AND Crd = 80 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V7 الجرد: زيادة 8 وعجز 20', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1013 AND Unit = @W2 AND Acc = @A2 AND Deb = 0 AND Crd = 12 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1013 AND Unit = @W2 AND Acc = @AC AND Deb = 20 AND Crd = 8 AND Cnt = 2) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V8 تكلفة: مخزن 130 وفروق 70 للناقل 200', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1014 AND Unit = 0 AND Acc = @A1 AND Deb = 130 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1014 AND Unit = 0 AND Acc = @AD AND Deb = 70 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1014 AND Unit = 0 AND Acc = @AT AND Deb = 0 AND Crd = 200 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V9 تسوية سالبة موزعة على المخزنين', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1015 AND Unit = 0 AND Acc = @AS AND Deb = 40 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1015 AND Unit = 0 AND Acc = @A1 AND Deb = 0 AND Crd = 32 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1015 AND Unit = 0 AND Acc = @A2 AND Deb = 0 AND Crd = 8 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V10 إشعار دائن', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1012 AND Unit = 0 AND Acc = @AS AND Deb = 40 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1012 AND Unit = 0 AND Acc = @AN AND Deb = 0 AND Crd = 40 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V11 صرف مباشر', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1006 AND Unit = 0 AND Acc = @AG AND Deb = 100 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1006 AND Unit = 0 AND Acc = @AS AND Deb = 0 AND Crd = 100 AND Cnt = 1) THEN 1 ELSE 0 END, N'');
    INSERT @R VALUES (N'V12 ترجيع مباشر', CASE WHEN EXISTS (SELECT 1 FROM @T WHERE Src = 1011 AND Unit = 0 AND Acc = @AS AND Deb = 30 AND Crd = 0 AND Cnt = 1) AND EXISTS (SELECT 1 FROM @T WHERE Src = 1011 AND Unit = 0 AND Acc = @AG AND Deb = 0 AND Crd = 30 AND Cnt = 1) THEN 1 ELSE 0 END, N'');

    -- مركز التكلفة على سطر الصرف
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher a JOIN dbo.Acc_DayDetails d ON d.DayDMID = a.AvDayMID
    WHERE a.AvCompany = @C AND a.AvSource = 1005 AND d.DayDAccID = @AG AND d.DayDCsCID = @CC;
    INSERT @R VALUES (N'V13 مركز تكلفة الجهة على سطر الصرف', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    -- بند القيد المرتبط بالمستند هو سطر جهته
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucherLine l JOIN dbo.Acc_DayDetails d ON d.DayDID = l.DayDID
    WHERE l.SourceDocID = @R1 AND d.DayDAccID = @AS AND d.DayDCrd = 1000;
    INSERT @R VALUES (N'V14 ربط المستند ببند جهته', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- بعد تحديد حساب الجهة يُولَّد المعلّق بتسلسل جديد
    UPDATE dbo.Prt_Party SET PrtAccID = @AS WHERE PrtID = @P0;
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, NULL, @D1, @D2, 0, 1;
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher WHERE AvCompany = @C AND AvSource = 1004 AND AvSourceUnit = @W1 AND AvSeq = 2;
    INSERT @R VALUES (N'G7 المعلّق يُولَّد بعد معالجة السبب بتسلسل 2', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, NULL, @D1, @D2, 0, 1;
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher WHERE AvCompany = @C;
    INSERT @R VALUES (N'G8 إعادة التوليد لا تكرّر شيئًا', CASE WHEN @n = 13 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- حد المستندات في القيد
    UPDATE dbo.Wrh_Settings SET WsMaxAutoVoucherDocs = 1 WHERE WsCmpID = @C;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":4,"Price":8}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D2, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @x = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @x;
    SET @L = CONCAT(N'[{"ItemID":', @sI2, N',"UnitID":', @sU, N',"Qty":2,"Price":8,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D2, @W1, NULL, @P, NULL, @x, NULL, @L;
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D2, @W1, NULL, @P, NULL, @x, NULL, @L;
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, 4, @D2, @D2, 0, 1;
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucher WHERE AvCompany = @C AND AvSource = 1004 AND AvDate = @D2;
    INSERT @R VALUES (N'G9 حد مستند لكل قيد يقسم القيود', CASE WHEN @n IN (1, 2) THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- حسابات الإعدادات
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SetAccounts @C, @U, 999999999, NULL, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S1 حساب إعدادات غير صالح', CASE WHEN @e = 52805 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- إرجاع مستند من قيده
    SELECT @dm = v.AvDayMID FROM dbo.Acc_AutoVoucherLine l JOIN dbo.Acc_AutoVoucher v ON v.AvID = l.AvID WHERE l.SourceDocID = @cn12;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_UnlinkAutoVoucher @C, @U, @cn12; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'U1 القيد المُرحَّل لا يُحلّ', CASE WHEN @e = 52803 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    UPDATE dbo.Acc_DayMaster SET DayMState = 2 WHERE DayMID = @dm;
    EXEC dbo.Wrh_UnlinkAutoVoucher @C, @U, @cn12;
    SELECT @n = COUNT(*) FROM dbo.Acc_AutoVoucherLine WHERE SourceDocID = @cn12;
    SELECT @q = COUNT(*) FROM dbo.Acc_DayMaster WHERE DayMID = @dm;
    INSERT @R VALUES (N'U2 إرجاع المستند يحلّ قيده', CASE WHEN @n = 0 AND @q = 0 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @q));
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":5,"Price":10,"RefLineID":', (SELECT TOP 1 LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv5), N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, @cn12, 12, @D1, NULL, NULL, @P, NULL, @inv5, NULL, @L;
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, 12, @D1, @D2, 0, 1;
    SELECT @v = SUM(d.DayDDeb) FROM dbo.Acc_AutoVoucher a JOIN dbo.Acc_DayDetails d ON d.DayDMID = a.AvDayMID
    WHERE a.AvCompany = @C AND a.AvSource = 1012 AND d.DayDAccID = @AS;
    INSERT @R VALUES (N'U3 بعد التعديل وإعادة التوليد القيمة 50', CASE WHEN @v = 50 THEN 1 ELSE 0 END, CONCAT(N'got ', @v));

    -- آخر اختبار: قفل مستند له قيد (خطأ الـ trigger يُفسد المعاملة الخارجية في الاختبار فقط)
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDoc @C, @U, @ret11; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'L1 مستند له قيد لا يُحذف', CASE WHEN @e = 52801 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    IF @@TRANCOUNT > 0 ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #D; DROP TABLE #K; DROP TABLE #U;

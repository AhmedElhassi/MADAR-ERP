﻿/* =====================================================================
   المرحلة 9 — دور الجهة، إشعار القيود المعلّقة، تاريخ المستند
   - خيار الشركة WsEnforcePartyRole (الافتراض 1 = صارم) وإجراء ضبطه Wrh_SetEnforcePartyRole.
   - Wrh_SaveDoc: الأنواع 3 4 6 تقبل مورّدًا أو عهدة؛ والأنواع 10 11 12 تُفرض فيها جهة المستند الأصلي.
   - Wrh_SelectAutoPending: المستندات العالقة بسببها (للإشعار الذي يصل للمحاسب فقط).
   - Wrh_SelectAutoVoucherHistory: تاريخ المستند كاملًا (أحداثه وحالات قيده) متتابعًا زمنيًا.
   - (في ملف المرحلة 8) إرجاع المستند من قيده ينسخ آخر سبب رفض إلى أحداث المستند.
   الأخطاء: 52901 دور الجهة غير مقبول  52902 الجهة تخالف المستند الأصلي
   يتطلب Wrh_01 .. Wrh_08 (أعد تنفيذ Wrh_08_AutoVouchers.sql أولًا) . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF COL_LENGTH(N'dbo.Wrh_Settings', N'WsEnforcePartyRole') IS NULL
    ALTER TABLE dbo.Wrh_Settings ADD WsEnforcePartyRole BIT NOT NULL CONSTRAINT DF_Wrh_Settings_PartyRole DEFAULT (1);
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SetEnforcePartyRole
    @Cmp INT, @User BIGINT, @Enforce BIT
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) OR @Enforce IS NULL
        THROW 52807, N'الشركة أو المستخدم أو القيمة غير صحيحة.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp) INSERT dbo.Wrh_Settings (WsCmpID) VALUES (@Cmp);
    UPDATE dbo.Wrh_Settings SET WsEnforcePartyRole = @Enforce WHERE WsCmpID = @Cmp;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE,
    @WhID BIGINT = NULL, @Wh2ID BIGINT = NULL, @PartyID BIGINT = NULL, @CostCID BIGINT = NULL,
    @RefDocID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52302, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Class TINYINT, @NW BIT, @NW2 BIT, @NP BIT, @NC BIT, @NR BIT, @RT TINYINT;
    SELECT @Class = DtClass, @NW = DtNeedWh, @NW2 = DtNeedWh2, @NP = DtNeedParty, @NC = DtNeedCost,
           @NR = DtNeedRef, @RT = DtRefType
    FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type AND DtEngine = 1;
    IF @Class IS NULL THROW 52301, N'نوع المستند غير صحيح أو غير مدعوم في هذا المحرك.', 1;

    -- متطلبات الرأس
    IF @NW = 1 AND @WhID IS NULL THROW 52302, N'المخزن مطلوب لهذا النوع.', 1;
    IF @NW2 = 1 AND @Wh2ID IS NULL THROW 52302, N'المخزن المقابل مطلوب لهذا النوع.', 1;
    IF @NP = 1 AND @PartyID IS NULL THROW 52302, N'الجهة (المورد/العهدة) مطلوبة لهذا النوع.', 1;
    IF @NC = 1 AND @CostCID IS NULL THROW 52302, N'الجهة الطالبة (مركز التكلفة) مطلوبة لهذا النوع.', 1;
    IF @NR = 1 AND @RefDocID IS NULL THROW 52302, N'المستند المرجعي مطلوب لهذا النوع.', 1;

    IF @WhID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Wh2ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @Wh2ID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن المقابل غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @WhID IS NOT NULL AND @Wh2ID IS NOT NULL AND @WhID = @Wh2ID
        THROW 52310, N'المخزنان في التحويل يجب أن يكونا مختلفين.', 1;
    IF @PartyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
        THROW 52310, N'الجهة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    IF @CostCID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CostCID)
        THROW 52310, N'مركز التكلفة غير موجود.', 1;

    -- المستند المرجعي
    IF @RefDocID IS NOT NULL
    BEGIN
        IF @RT IS NULL THROW 52306, N'هذا النوع لا يقبل مستندًا مرجعيًا.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp AND DocType = @RT AND DocStatus <> 9)
            THROW 52306, N'المستند المرجعي غير صحيح (غير موجود أو نوعه لا يناسب أو ملغى أو لا يتبع الشركة).', 1;
    END

    -- دور الجهة (خيار الشركة WsEnforcePartyRole)
    IF @PartyID IS NOT NULL AND ISNULL((SELECT WsEnforcePartyRole FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1) = 1
    BEGIN
        IF @Type IN (3, 4, 6) AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtRole IN (1, 3))
            THROW 52901, N'هذا النوع يقبل مورّدًا أو موظف عهدة فقط.', 1;
        IF @Type IN (10, 11, 12) AND @RefDocID IS NOT NULL
           AND ISNULL((SELECT DocPartyID FROM dbo.Wrh_Doc WHERE DocID = @RefDocID), 0) <> @PartyID
            THROW 52902, N'يجب أن تكون الجهة هي نفس جهة المستند الأصلي.', 1;
    END

    -- البنود
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52303, N'بنود المستند غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6),
                     RefLineID BIGINT, Factor DECIMAL(18,6), BaseQty DECIMAL(18,3));

    INSERT #L (Ord, ItemID, UnitID, Qty, Price, RefLineID)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price, j.RefLineID
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID',
                                          Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price',
                                          RefLineID BIGINT '$.RefLineID') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) THROW 52303, N'يجب أن يحتوي المستند على بند واحد على الأقل.', 1;
    IF EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty <= 0 OR Price < 0)
        THROW 52303, N'كل بند يحتاج صنفًا ووحدة وكمية أكبر من صفر وسعرًا غير سالب.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS
               (SELECT 1 FROM dbo.Wrh_Item AS i WHERE i.ItemID = l.ItemID AND i.ItemCmpID = @Cmp AND i.ItemActive = 1))
        THROW 52303, N'صنف غير موجود أو معطّل أو لا يتبع الشركة.', 1;

    UPDATE l
       SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l
      JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL)
        THROW 52304, N'وحدة غير معرّفة لهذا الصنف (ليست الأساس ولا ثانوية بمعامل تحويل).', 1;
    UPDATE #L SET BaseQty = ROUND(Qty * Factor, 3);
    IF EXISTS (SELECT 1 FROM #L WHERE BaseQty <= 0) THROW 52303, N'الكمية بالوحدة الأساس تساوي صفرًا.', 1;

    -- ربط البنود بالمرجع
    IF @RefDocID IS NOT NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM #L AS l WHERE l.RefLineID IS NULL OR NOT EXISTS
                   (SELECT 1 FROM dbo.Wrh_DocLine AS r WHERE r.LineID = l.RefLineID AND r.DocID = @RefDocID AND r.ItemID = l.ItemID))
            THROW 52306, N'كل بند يجب أن يرتبط ببند من المستند المرجعي ولنفس الصنف.', 1;
    END
    ELSE IF EXISTS (SELECT 1 FROM #L WHERE RefLineID IS NOT NULL)
        THROW 52306, N'لا يجوز ربط بند بمرجع دون تحديد المستند المرجعي.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveDoc;

    BEGIN TRY
        DECLARE @OldRef BIGINT = NULL, @DocNo NVARCHAR(10), @Year INT = YEAR(@Date), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo, @OldRef = DocRefDocID
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;

            IF @OType IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52301, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52312, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
                THROW 52305, N'لا يجوز تعديل مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

            EXEC dbo.Wrh_StockReverse @DocID;   -- يعكس أثر المخزون القديم
            -- تراجع أثر الربط القديم ثم حذف البنود القديمة
            UPDATE r SET QtyReferred = r.QtyReferred - s.q
              FROM dbo.Wrh_DocLine AS r
              JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;
            DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;

            UPDATE dbo.Wrh_Doc
               SET DocDate = @Date, DocWhID = @WhID, DocWh2ID = @Wh2ID, DocPartyID = @PartyID,
                   DocCostCID = @CostCID, DocRefDocID = @RefDocID, DocNotes = @Notes
             WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocWh2ID,
                                DocPartyID, DocCostCID, DocRefDocID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, CASE WHEN @Class = 1 THEN 1 ELSE 3 END, @WhID, @Wh2ID,
                    @PartyID, @CostCID, @RefDocID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_DocLine (DocID, DocLineNo, ItemID, UnitID, Factor, Qty, BaseQty, UnitPrice, Amount, RefLineID)
        SELECT @DocID, ROW_NUMBER() OVER (ORDER BY l.Ord), l.ItemID, l.UnitID, l.Factor, l.Qty, l.BaseQty, l.Price,
               CAST(ROUND(l.Qty * ISNULL(l.Price, 0), 3) AS DECIMAL(18,3)), l.RefLineID
        FROM #L AS l;

        -- أثر الربط الجديد (مع التحقق من المتبقي)
        IF EXISTS (SELECT 1
                   FROM (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
                   JOIN dbo.Wrh_DocLine AS r WITH (UPDLOCK) ON r.LineID = s.RefLineID
                   WHERE r.BaseQty - r.QtyReferred - r.QtyCancelled < s.q)
            THROW 52306, N'الكمية تتجاوز المتبقي في البند المرجعي.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred + s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
            ON s.RefLineID = r.LineID;

        EXEC dbo.Wrh_StockApply @DocID;     -- أثر المخزون الجديد

        EXEC dbo.Wrh_RecalcDocStatus @RefDocID;
        IF @OldRef IS NOT NULL AND ISNULL(@OldRef, 0) <> ISNULL(@RefDocID, 0)
            EXEC dbo.Wrh_RecalcDocStatus @OldRef;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo, d.DocStatus FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveDoc;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ المستندات العالقة (للإشعار) */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectAutoPending
    @Cmp INT, @User BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    CREATE TABLE #PendingOut (DocID BIGINT, DocType TINYINT, Reason NVARCHAR(300));
    EXEC dbo.Wrh_GenerateAutoVouchers @Cmp, @User, NULL, NULL, NULL, 1, 1;
    SELECT p.DocType, t.DtName AS DocTypeName, p.Reason, COUNT(*) AS Docs
    FROM #PendingOut p JOIN dbo.Wrh_DocTypeDef t ON t.DtType = p.DocType
    GROUP BY p.DocType, t.DtName, p.Reason ORDER BY p.DocType, p.Reason;
    SELECT COUNT(*) AS PendingDocs FROM #PendingOut;
END;
GO

/* ------------------------------------------------------------------ تاريخ المستند كاملًا */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectAutoVoucherHistory
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocCmpID = @Cmp)
       AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_DocEvent WHERE EvDocID = @DocID AND EvCmpID = @Cmp)
        THROW 52807, N'المستند غير موجود أو لا يتبع الشركة.', 1;

    SELECT x.Src, x.At, x.Code, x.Label, x.UserID, x.Reason
    FROM (
        SELECT N'doc' AS Src, e.EvAt AS At, CAST(e.EvKind AS INT) AS Code,
               CASE e.EvKind WHEN 1 THEN N'إنشاء' WHEN 2 THEN N'تعديل' WHEN 3 THEN N'حذف' WHEN 4 THEN N'إلغاء'
                             WHEN 5 THEN N'اعتماد جرد' WHEN 6 THEN N'إرجاع من القيد الآلي' ELSE N'حدث' END AS Label,
               e.EvUser AS UserID, e.EvReason AS Reason
        FROM dbo.Wrh_DocEvent e WHERE e.EvCmpID = @Cmp AND e.EvDocID = @DocID
        UNION ALL
        SELECT N'voucher', s.DayMSDateTime, CAST(s.DayMSState AS INT), CONCAT(N'حالة القيد ', s.DayMSState), s.DayMSUser, s.DayMSReason
        FROM dbo.Acc_AutoVoucherLine l
        JOIN dbo.Acc_AutoVoucher v ON v.AvID = l.AvID AND v.AvCompany = @Cmp
        JOIN dbo.Acc_DayMasterState s ON s.DayMSDayMID = v.AvDayMID
        WHERE l.SourceDocID = @DocID
    ) x
    ORDER BY x.At, x.Src;
END;
GO

/* اختبار المرحلة 9 — داخل معاملة تُرجَع. يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_SelectAutoVoucherHistory') IS NULL THROW 52900, N'نفّذ Wrh_09_PartyRole_History.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #H (Src NVARCHAR(10), At DATETIME2, Code INT, Label NVARCHAR(100), UserID BIGINT, Reason NVARCHAR(500));
CREATE TABLE #PendingOut (DocID BIGINT, DocType TINYINT, Reason NVARCHAR(300));

DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @D1 DATE = '2031-05-01', @D2 DATE = '2031-05-02';

DECLARE @W1 BIGINT, @P BIGINT, @P2 BIGINT, @PT BIGINT, @PC BIGINT, @P0 BIGINT, @G BIGINT, @u1 BIGINT, @I1 BIGINT;
DECLARE @A1 BIGINT, @AS BIGINT, @AG BIGINT, @AD BIGINT;
DECLARE @sI1 NVARCHAR(20), @sU NVARCHAR(20), @L NVARCHAR(MAX), @e INT, @n INT, @il BIGINT;
DECLARE @inv BIGINT, @rc BIGINT, @x BIGINT, @dm BIGINT, @rsn NVARCHAR(500);

IF @CC IS NULL OR @U IS NULL
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    DECLARE @k INT = 0;
    DECLARE @ids TABLE (K INT, Id BIGINT);
    WHILE @k < 4
    BEGIN
        SET @k += 1;
        INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
        VALUES (1, 1, NULL, @k, 1, 0, CONCAT(N'ZZ9', @k), CONCAT(N'اختبار م9 ', @k), @U, @C);
        INSERT @ids VALUES (@k, CONVERT(BIGINT, SCOPE_IDENTITY()));
    END
    SELECT @A1 = Id FROM @ids WHERE K = 1; SELECT @AS = Id FROM @ids WHERE K = 2;
    SELECT @AG = Id FROM @ids WHERE K = 3; SELECT @AD = Id FROM @ids WHERE K = 4;

    EXEC dbo.Wrh_SetAccounts @C, @U, @AD, NULL, NULL;
    UPDATE dbo.Wrh_Settings SET WsSeparateDuties = 0, WsAutoVoucherState = 0 WHERE WsCmpID = @C;

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'YW1', N'مخزن 1', @A1; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'YP1', N'مورد 1', 1; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'YP2', N'مورد 2', 1; SELECT @P2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'YPT', N'ناقل', 2; SELECT @PT = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'YPC', N'عهدة', 3; SELECT @PC = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'YP0', N'مورد بلا حساب', 1; SELECT @P0 = Id FROM #I;
    UPDATE dbo.Prt_Party SET PrtAccID = @AS WHERE PrtID IN (@P, @P2, @PT, @PC);
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'YG1', N'مجموعة', @AG; SELECT @G = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة م9'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'YI1', N'صنف م9', @u1; SELECT @I1 = Id FROM #I;
    SET @sI1 = CAST(@I1 AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20));
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');

    -- دور الجهة (صارم افتراضيًا)
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @PT, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P1 فاتورة بجهة خدمات مرفوضة', CASE WHEN @e = 52901 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @PC, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P2 فاتورة بموظف عهدة مقبولة', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    SELECT @inv = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    INSERT @R VALUES (N'P3 فاتورة بمورد مقبولة', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10,"RefLineID":', @il, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D1, @W1, NULL, @PT, NULL, @inv, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P4 استلام بجهة خدمات مرفوض', CASE WHEN @e = 52901 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D1, @W1, NULL, @P2, NULL, @inv, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P5 الاستلام بمورد مختلف عن الفاتورة مقبول', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @rc = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 4;

    -- إشعار الدائن: جهة المستند الأصلي
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":2,"Price":10,"RefLineID":', @il, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 12, @D1, NULL, NULL, @P2, NULL, @inv, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P6 إشعار دائن بجهة غير جهة الفاتورة مرفوض', CASE WHEN @e = 52902 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 12, @D1, NULL, NULL, @P, NULL, @inv, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P7 إشعار دائن بنفس الجهة مقبول', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- إيقاف الخيار
    EXEC dbo.Wrh_SetEnforcePartyRole @C, @U, 0;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @PT, NULL, NULL, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P8 بعد إيقاف الخيار تقبل أي جهة', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    EXEC dbo.Wrh_SetEnforcePartyRole @C, @U, 1;

    -- المستندات العالقة: استلام لمورد بلا حساب
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":3,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D2, @W1, NULL, @P0, NULL, NULL, NULL, @L; SELECT @x = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @x;
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":3,"Price":10,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D2, @W1, NULL, @P0, NULL, @x, NULL, @L; SELECT @x = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 4;
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, 4, @D2, @D2, 1, 1;
    SELECT @n = COUNT(*) FROM #PendingOut WHERE DocID = @x;
    INSERT @R VALUES (N'N1 المستند بلا حساب جهة يظهر في العالقة', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SelectAutoPending @C, @U; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N2 إجراء الإشعار يعمل', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- قيد للاستلام الأول ثم رفضه وإرجاعه
    EXEC dbo.Wrh_GenerateAutoVouchers @C, @U, 4, @D1, @D1, 0, 1;
    SELECT @dm = v.AvDayMID FROM dbo.Acc_AutoVoucherLine l JOIN dbo.Acc_AutoVoucher v ON v.AvID = l.AvID WHERE l.SourceDocID = @rc;
    INSERT @R VALUES (N'H0 وُلّد قيد للاستلام', CASE WHEN @dm IS NOT NULL THEN 1 ELSE 0 END, CONCAT(N'got ', @dm));
    DELETE #H; INSERT #H EXEC dbo.Wrh_SelectAutoVoucherHistory @C, @rc;
    SELECT @n = COUNT(*) FROM #H WHERE Src = N'doc' AND Code = 1;
    INSERT @R VALUES (N'H1 التاريخ يتضمن إنشاء المستند', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    UPDATE dbo.Acc_DayMaster SET DayMState = 2 WHERE DayMID = @dm;
    INSERT dbo.Acc_DayMasterState (DayMSDayMID, DayMSState, DayMSReason, DayMSUser) VALUES (@dm, 2, N'سبب رفض اختبار', @U);
    EXEC dbo.Wrh_UnlinkAutoVoucher @C, @U, @rc;
    SELECT @rsn = EvReason FROM dbo.Wrh_DocEvent WHERE EvDocID = @rc AND EvKind = 6;
    INSERT @R VALUES (N'H2 سبب الرفض حُفظ في أحداث المستند', CASE WHEN @rsn LIKE N'%سبب رفض اختبار%' THEN 1 ELSE 0 END, ISNULL(@rsn, N'null'));
    DELETE #H; INSERT #H EXEC dbo.Wrh_SelectAutoVoucherHistory @C, @rc;
    SELECT @n = COUNT(*) FROM #H WHERE Src = N'doc' AND Code = 6 AND Reason LIKE N'%سبب رفض اختبار%';
    INSERT @R VALUES (N'H3 التاريخ يعرض الإرجاع وسببه', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SelectAutoVoucherHistory @C, 999999999; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'H4 مستند غير موجود', CASE WHEN @e = 52807 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    IF @@TRANCOUNT > 0 ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #H; DROP TABLE #PendingOut;

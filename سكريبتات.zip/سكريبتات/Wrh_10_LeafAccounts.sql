/* الحسابات الصالحة لربطها (أوراق تحليلية صالحة للقيد) للشركة — قراءة فقط */
USE [MADARERPDataBase];
GO
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectLeafAccounts
    @Cmp INT, @Search NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @Search = NULLIF(LTRIM(RTRIM(@Search)), N'');
    SELECT a.AccID, a.AccCode, a.AccName, CONCAT(a.AccCode, N' - ', a.AccName) AS AccDisplay
    FROM dbo.Acc_Account AS a
    WHERE a.AccCompany = @Cmp
      AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = a.AccID)
      AND ((a.AccEnd = 1 AND a.AccType IN (0, 1, 2)) OR (a.AccEnd = 2 AND a.AccType IN (0, 1)))
      AND (@Search IS NULL OR a.AccCode LIKE N'%' + @Search + N'%' OR a.AccName LIKE N'%' + @Search + N'%')
    ORDER BY a.AccCode;
END;
GO

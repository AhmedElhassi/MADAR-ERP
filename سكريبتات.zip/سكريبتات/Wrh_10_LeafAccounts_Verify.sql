USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_SelectLeafAccounts') IS NULL THROW 52900, N'نفّذ Wrh_10_LeafAccounts.sql أولًا', 1;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #X (AccID BIGINT, AccCode NVARCHAR(100), AccName NVARCHAR(300), AccDisplay NVARCHAR(500));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @P BIGINT, @L BIGINT, @n INT;
IF @C IS NULL OR @U IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
    VALUES (1, 1, NULL, 1, 1, 0, N'ZQ1', N'حساب اختبار أب', @U, @C);
    SET @P = CONVERT(BIGINT, SCOPE_IDENTITY());
    INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
    VALUES (1, 1, @P, 1, 2, 0, N'ZQ11', N'حساب اختبار ورقة', @U, @C);
    SET @L = CONVERT(BIGINT, SCOPE_IDENTITY());
    INSERT #X EXEC dbo.Wrh_SelectLeafAccounts @C, N'ZQ1';
    SELECT @n = COUNT(*) FROM #X WHERE AccID = @L;
    INSERT @R VALUES (N'A1 الورقة تظهر', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM #X WHERE AccID = @P;
    INSERT @R VALUES (N'A2 الحساب الأب لا يظهر', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #X; INSERT #X EXEC dbo.Wrh_SelectLeafAccounts @C, N'ورقة';
    SELECT @n = COUNT(*) FROM #X WHERE AccID = @L;
    INSERT @R VALUES (N'A3 البحث بالاسم', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #X; INSERT #X EXEC dbo.Wrh_SelectLeafAccounts @C, NULL;
    SELECT @n = COUNT(*) FROM #X WHERE AccDisplay = N'ZQ11 - حساب اختبار ورقة';
    INSERT @R VALUES (N'A4 نص العرض', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #X;

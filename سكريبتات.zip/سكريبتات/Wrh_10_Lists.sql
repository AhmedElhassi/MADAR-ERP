/* =====================================================================
   المرحلة 10 — إجراءات القوائم للواجهات (قراءة فقط، لا تغيّر أي بيانات)
   Wrh_SelectParties  Wrh_SelectWarehouses  Wrh_SelectItemGroups  Wrh_SelectUnits
   Wrh_SelectItems    Wrh_SelectItemUnits   Wrh_SelectDocs (فهرس المستندات بالصفحات)
   يتطلب Wrh_01 .. Wrh_09 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectParties
    @Cmp INT, @Role TINYINT = NULL, @ActiveOnly BIT = 0, @Search NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @Search = NULLIF(LTRIM(RTRIM(@Search)), N'');
    SELECT p.PrtID, p.PrtCode, p.PrtName, p.PrtRole, p.PrtAccID, a.AccName, p.PrtActive
    FROM dbo.Prt_Party AS p LEFT JOIN dbo.Acc_Account AS a ON a.AccID = p.PrtAccID
    WHERE p.PrtCmpID = @Cmp AND (@Role IS NULL OR p.PrtRole = @Role) AND (@ActiveOnly = 0 OR p.PrtActive = 1)
      AND (@Search IS NULL OR p.PrtCode LIKE N'%' + @Search + N'%' OR p.PrtName LIKE N'%' + @Search + N'%')
    ORDER BY p.PrtCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectWarehouses
    @Cmp INT, @ActiveOnly BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT w.WhID, w.WhCode, w.WhName, w.WhAccID, a.AccName, w.WhKeeper, w.WhActive
    FROM dbo.Wrh_Warehouse AS w LEFT JOIN dbo.Acc_Account AS a ON a.AccID = w.WhAccID
    WHERE w.WhCmpID = @Cmp AND (@ActiveOnly = 0 OR w.WhActive = 1)
    ORDER BY w.WhCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectItemGroups
    @Cmp INT, @ActiveOnly BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT g.GrpID, g.GrpParentID, g.GrpCode, g.GrpName, g.GrpAccID, a.AccName, g.GrpActive,
           CAST(CASE WHEN EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup c WHERE c.GrpParentID = g.GrpID) THEN 1 ELSE 0 END AS BIT) AS HasChildren,
           (SELECT COUNT(*) FROM dbo.Wrh_Item i WHERE i.ItemGrpID = g.GrpID) AS ItemsCount
    FROM dbo.Wrh_ItemGroup AS g LEFT JOIN dbo.Acc_Account AS a ON a.AccID = g.GrpAccID
    WHERE g.GrpCmpID = @Cmp AND (@ActiveOnly = 0 OR g.GrpActive = 1)
    ORDER BY g.GrpCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectUnits
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT UnitID, UnitName FROM dbo.Wrh_Unit WHERE UnitCmpID = @Cmp ORDER BY UnitName;
END;
GO

/* الأصناف: @GrpID يشمل أبناء المجموعة */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectItems
    @Cmp INT, @GrpID BIGINT = NULL, @ActiveOnly BIT = 0, @Search NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @Search = NULLIF(LTRIM(RTRIM(@Search)), N'');
    ;WITH G AS (
        SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp
        UNION ALL
        SELECT c.GrpID FROM dbo.Wrh_ItemGroup c JOIN G ON c.GrpParentID = G.GrpID
    )
    SELECT i.ItemID, i.ItemCode, i.ItemName, i.ItemGrpID, g.GrpName, i.ItemBaseUnitID, u.UnitName AS BaseUnitName, i.ItemActive
    FROM dbo.Wrh_Item AS i
    JOIN dbo.Wrh_ItemGroup AS g ON g.GrpID = i.ItemGrpID
    JOIN dbo.Wrh_Unit AS u ON u.UnitID = i.ItemBaseUnitID
    WHERE i.ItemCmpID = @Cmp AND (@ActiveOnly = 0 OR i.ItemActive = 1)
      AND (@GrpID IS NULL OR i.ItemGrpID IN (SELECT GrpID FROM G))
      AND (@Search IS NULL OR i.ItemCode LIKE N'%' + @Search + N'%' OR i.ItemName LIKE N'%' + @Search + N'%')
    ORDER BY i.ItemCode
    OPTION (MAXRECURSION 100);
END;
GO

/* وحدات الصنف: الأساس (معامل 1) ثم الثانوية */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectItemUnits
    @Cmp INT, @ItemID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT x.UnitID, x.UnitName, x.Factor, x.IsBase
    FROM (
        SELECT u.UnitID, u.UnitName, CAST(1 AS DECIMAL(18,6)) AS Factor, CAST(1 AS BIT) AS IsBase
        FROM dbo.Wrh_Item i JOIN dbo.Wrh_Unit u ON u.UnitID = i.ItemBaseUnitID
        WHERE i.ItemID = @ItemID AND i.ItemCmpID = @Cmp
        UNION ALL
        SELECT u.UnitID, u.UnitName, iu.Factor, CAST(0 AS BIT)
        FROM dbo.Wrh_ItemUnit iu JOIN dbo.Wrh_Item i ON i.ItemID = iu.ItemID JOIN dbo.Wrh_Unit u ON u.UnitID = iu.UnitID
        WHERE iu.ItemID = @ItemID AND i.ItemCmpID = @Cmp
    ) x
    ORDER BY x.IsBase DESC, x.UnitName;
END;
GO

/* فهرس المستندات (كل الأنواع) بالصفحات. الحالة: 1 مفتوح 2 جزئي 3 منفَّذ 9 ملغى */
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectDocs
    @Cmp INT, @Type TINYINT = NULL, @FromDate DATE = NULL, @ToDate DATE = NULL, @Status TINYINT = NULL,
    @Search NVARCHAR(100) = NULL, @PageNo INT = 1, @PageSize INT = 50
AS
BEGIN
    SET NOCOUNT ON;
    SET @Search = NULLIF(LTRIM(RTRIM(@Search)), N'');
    IF @PageNo IS NULL OR @PageNo < 1 SET @PageNo = 1;
    IF @PageSize IS NULL OR @PageSize < 1 SET @PageSize = 50;
    IF @PageSize > 500 SET @PageSize = 500;

    SELECT d.DocID, d.DocType, t.DtName AS DocTypeName, d.DocNo, d.DocDate, d.DocStatus,
           d.DocWhID, w.WhName, d.DocWh2ID, w2.WhName AS Wh2Name, d.DocPartyID, p.PrtName,
           d.DocCostCID, cc.CsCName AS CostCenterName, d.DocRefDocID, r.DocNo AS RefDocNo, d.DocNotes,
           (SELECT SUM(l.Amount) FROM dbo.Wrh_DocLine l WHERE l.DocID = d.DocID) AS TotalAmount,
           COUNT(*) OVER () AS TotalRows
    FROM dbo.Wrh_Doc AS d
    JOIN dbo.Wrh_DocTypeDef AS t ON t.DtType = d.DocType
    LEFT JOIN dbo.Wrh_Warehouse AS w ON w.WhID = d.DocWhID
    LEFT JOIN dbo.Wrh_Warehouse AS w2 ON w2.WhID = d.DocWh2ID
    LEFT JOIN dbo.Prt_Party AS p ON p.PrtID = d.DocPartyID
    LEFT JOIN dbo.Acc_CostCenter AS cc ON cc.CsCID = d.DocCostCID
    LEFT JOIN dbo.Wrh_Doc AS r ON r.DocID = d.DocRefDocID
    WHERE d.DocCmpID = @Cmp AND (@Type IS NULL OR d.DocType = @Type)
      AND (@FromDate IS NULL OR d.DocDate >= @FromDate) AND (@ToDate IS NULL OR d.DocDate <= @ToDate)
      AND (@Status IS NULL OR d.DocStatus = @Status)
      AND (@Search IS NULL OR d.DocNo LIKE N'%' + @Search + N'%' OR d.DocNotes LIKE N'%' + @Search + N'%' OR p.PrtName LIKE N'%' + @Search + N'%')
    ORDER BY d.DocDate DESC, d.DocID DESC
    OFFSET (@PageNo - 1) * @PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO

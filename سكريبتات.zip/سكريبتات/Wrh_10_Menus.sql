﻿/* =====================================================================
   قوائم نظام المخازن (SysID = 2) في Mng_SystemMenu — آمن لإعادة التشغيل (MERGE).
   المفتاح (SysMSysID, SysMID). الأب 0 = قائمة رئيسية. SysMState = 0 فعّال.
   الصفحات المشار إليها تُبنى لاحقًا. تحديث عمود قائمة الأرقام في Mng_System يتم ديناميكيًا
   عن طريق اكتشاف العمود الذي يحمل نص "1, 2, 3 ..." لنظام الحسابات.
   ===================================================================== */
USE [MADARERPDataBase];
GO
SET NOCOUNT ON;
DECLARE @Sys TINYINT = 2;
IF NOT EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = @Sys) THROW 52950, N'النظام 2 غير موجود في Mng_System', 1;

MERGE dbo.Mng_SystemMenu AS t
USING (VALUES
        (1, 0, N'البيانات الأساسية', N'WrhMaster', N'fas fa-database', N''),
        (2, 0, N'المشتريات', N'WrhPurchasing', N'fas fa-shopping-cart', N''),
        (3, 0, N'الصرف والتحويل', N'WrhIssues', N'fas fa-dolly', N''),
        (4, 0, N'جرد المخازن', N'WrhCount', N'fas fa-clipboard-list', N'~/Warehouses/Wrh_Count.aspx'),
        (5, 0, N'القيود الآلية', N'WrhAutoVouchers', N'fas fa-cogs', N''),
        (6, 0, N'التقارير', N'WrhReports', N'fas fa-chart-line', N''),
        (7, 0, N'الإعدادات', N'WrhSettings', N'fas fa-sliders-h', N''),
        (8, 1, N'الأطراف (موردون وعهد وجهات خدمات)', N'WrhParties', N'fas fa-users', N'~/Warehouses/Wrh_Parties.aspx'),
        (9, 1, N'المخازن', N'WrhWarehouses', N'fas fa-warehouse', N'~/Warehouses/Wrh_Warehouses.aspx'),
        (10, 1, N'مجموعات المواد', N'WrhItemGroups', N'fas fa-sitemap', N'~/Warehouses/Wrh_ItemGroups.aspx'),
        (11, 1, N'الوحدات', N'WrhUnits', N'fas fa-balance-scale', N'~/Warehouses/Wrh_Units.aspx'),
        (12, 1, N'الأصناف', N'WrhItems', N'fas fa-boxes', N'~/Warehouses/Wrh_Items.aspx'),
        (13, 2, N'طلب مواد', N'WrhMaterialRequest', N'fas fa-clipboard-list', N'~/Warehouses/Wrh_Doc.aspx?Type=1'),
        (14, 2, N'طلب شراء', N'WrhPurchaseRequest', N'fas fa-file-alt', N'~/Warehouses/Wrh_Doc.aspx?Type=2'),
        (15, 2, N'فاتورة شراء', N'WrhPurchaseInvoice', N'fas fa-file-invoice', N'~/Warehouses/Wrh_Doc.aspx?Type=3'),
        (16, 2, N'استلام مخزني', N'WrhReceipt', N'fas fa-truck-loading', N'~/Warehouses/Wrh_Doc.aspx?Type=4'),
        (17, 2, N'ترجيع مخزني للمورد', N'WrhSupplierReturn', N'fas fa-undo', N'~/Warehouses/Wrh_Doc.aspx?Type=10'),
        (18, 2, N'ترجيع مباشر للمورد', N'WrhDirectReturn', N'fas fa-undo-alt', N'~/Warehouses/Wrh_Doc.aspx?Type=11'),
        (19, 2, N'إشعار دائن للمورد', N'WrhCreditNote', N'fas fa-file-invoice-dollar', N'~/Warehouses/Wrh_Doc.aspx?Type=12'),
        (20, 2, N'تكلفة إضافية', N'WrhExtraCost', N'fas fa-truck', N'~/Warehouses/Wrh_CostDoc.aspx?Type=14'),
        (21, 2, N'تسوية تكلفة', N'WrhCostAdjust', N'fas fa-balance-scale-right', N'~/Warehouses/Wrh_CostDoc.aspx?Type=15'),
        (22, 3, N'صرف مخزني', N'WrhIssue', N'fas fa-dolly-flatbed', N'~/Warehouses/Wrh_Doc.aspx?Type=5'),
        (23, 3, N'صرف مباشر', N'WrhDirectIssue', N'fas fa-shipping-fast', N'~/Warehouses/Wrh_Doc.aspx?Type=6'),
        (24, 3, N'استرجاع من جهة', N'WrhReturnFromParty', N'fas fa-reply', N'~/Warehouses/Wrh_Doc.aspx?Type=9'),
        (25, 3, N'أمر تحويل', N'WrhTransferOrder', N'fas fa-exchange-alt', N'~/Warehouses/Wrh_Doc.aspx?Type=7'),
        (26, 3, N'استلام تحويل', N'WrhTransferReceipt', N'fas fa-check-double', N'~/Warehouses/Wrh_Doc.aspx?Type=8'),
        (27, 5, N'توليد القيود', N'WrhAutoGenerate', N'fas fa-magic', N'~/Warehouses/Wrh_AutoGenerate.aspx'),
        (28, 5, N'المستندات المعلّقة', N'WrhAutoPending', N'fas fa-exclamation-triangle', N'~/Warehouses/Wrh_AutoPending.aspx'),
        (29, 6, N'أرصدة المخزون', N'WrhStockReport', N'fas fa-boxes', N'~/Warehouses/Wrh_StockReport.aspx'),
        (30, 6, N'فهرس المستندات', N'WrhDocList', N'fas fa-list-alt', N'~/Warehouses/Wrh_DocList.aspx'),
        (31, 7, N'إعدادات المخازن', N'WrhSystemSettings', N'fas fa-cogs', N'~/Warehouses/Wrh_Settings.aspx'),
        (32, 7, N'إقفال السنة', N'WrhCloseYear', N'fas fa-lock', N'~/Warehouses/Wrh_CloseYear.aspx')
) AS s (SysMID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap)
ON t.SysMSysID = @Sys AND t.SysMID = s.SysMID
WHEN MATCHED THEN UPDATE SET SysMParent = s.SysMParent, SysMName = s.SysMName, SysMEName = s.SysMEName, SysMLogo = s.SysMLogo, SysMMap = s.SysMMap
WHEN NOT MATCHED THEN INSERT (SysMID, SysMSysID, SysMParent, SysMName, SysMEName, SysMLogo, SysMMap, SysMState)
     VALUES (s.SysMID, @Sys, s.SysMParent, s.SysMName, s.SysMEName, s.SysMLogo, s.SysMMap, 0);

-- قائمة أرقام القوائم في Mng_System
DECLARE @List NVARCHAR(400) = STUFF((SELECT N', ' + CAST(SysMID AS NVARCHAR(5)) FROM dbo.Mng_SystemMenu WHERE SysMSysID = @Sys ORDER BY SysMID FOR XML PATH(N'')), 1, 2, N'');
DECLARE @Col SYSNAME, @Sql NVARCHAR(MAX), @Found BIT;
DECLARE cc CURSOR LOCAL STATIC FOR
    SELECT c.name FROM sys.columns c JOIN sys.types ty ON ty.user_type_id = c.user_type_id
    WHERE c.object_id = OBJECT_ID(N'dbo.Mng_System') AND ty.name IN (N'nvarchar', N'varchar');
OPEN cc; FETCH NEXT FROM cc INTO @Col;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Found = 0;
    SET @Sql = N'SELECT @f = CASE WHEN EXISTS (SELECT 1 FROM dbo.Mng_System WHERE SysID = 1 AND ' + QUOTENAME(@Col) + N' LIKE N''1, 2, 3%'') THEN 1 ELSE 0 END';
    EXEC sp_executesql @Sql, N'@f BIT OUTPUT', @f = @Found OUTPUT;
    IF @Found = 1
    BEGIN
        SET @Sql = N'UPDATE dbo.Mng_System SET ' + QUOTENAME(@Col) + N' = @l WHERE SysID = @s';
        EXEC sp_executesql @Sql, N'@l NVARCHAR(400), @s TINYINT', @l = @List, @s = @Sys;
        PRINT CONCAT(N'عمود القائمة: ', @Col, N' = ', @List);
        BREAK;
    END
    FETCH NEXT FROM cc INTO @Col;
END
CLOSE cc; DEALLOCATE cc;

SELECT SysMSysID, SysMID, SysMParent, SysMName, SysMEName, SysMMap FROM dbo.Mng_SystemMenu WHERE SysMSysID = @Sys ORDER BY SysMID;
GO

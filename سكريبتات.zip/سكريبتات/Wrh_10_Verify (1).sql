/* اختبار المرحلة 10 — داخل معاملة تُرجَع. يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_SelectDocs') IS NULL THROW 52900, N'نفّذ Wrh_10_Lists.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #X (A BIGINT, B NVARCHAR(200), C NVARCHAR(200), D NVARCHAR(200), E NVARCHAR(200), F NVARCHAR(200), G NVARCHAR(200), H NVARCHAR(200));

DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @D1 DATE = '2031-07-01', @D2 DATE = '2031-07-05';
DECLARE @G3 BIGINT, @A1 BIGINT, @AS BIGINT, @AG BIGINT, @W1 BIGINT, @P BIGINT, @PT BIGINT, @PX BIGINT, @G1 BIGINT, @G2 BIGINT, @u1 BIGINT, @u2 BIGINT, @I1 BIGINT, @I2 BIGINT;
DECLARE @sI1 NVARCHAR(20), @sU NVARCHAR(20), @L NVARCHAR(MAX), @n INT, @x BIGINT;

IF @CC IS NULL OR @U IS NULL
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    DECLARE @k INT = 0;
    DECLARE @ids TABLE (K INT, Id BIGINT);
    WHILE @k < 3
    BEGIN
        SET @k += 1;
        INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccUser, AccCompany)
        VALUES (1, 1, NULL, @k, 1, 0, CONCAT(N'ZL', @k), CONCAT(N'اختبار قوائم ', @k), @U, @C);
        INSERT @ids VALUES (@k, CONVERT(BIGINT, SCOPE_IDENTITY()));
    END
    SELECT @A1 = Id FROM @ids WHERE K = 1; SELECT @AS = Id FROM @ids WHERE K = 2; SELECT @AG = Id FROM @ids WHERE K = 3;

    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'LW1', N'مخزن قوائم', @A1; SELECT @W1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'LP1', N'مورد قوائم', 1, @AS; SELECT @P = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'LP2', N'ناقل قوائم', 2, @AS; SELECT @PT = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'LP3', N'مورد معطل قوائم', 1, @AS, 0; SELECT @PX = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'LG1', N'مجموعة أب', NULL; SELECT @G1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @G1, N'LG2', N'مجموعة ابن', @AG; SELECT @G2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @G1, N'LG3', N'مجموعة ابن 2', @AG; SELECT @G3 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'قطعة قوائم'; SELECT @u1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'كرتون قوائم'; SELECT @u2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G2, N'LI1', N'صنف قوائم 1', @u1; SELECT @I1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveItem @C, @U, 0, @G3, N'LI2', N'صنف قوائم 2', @u1; SELECT @I2 = Id FROM #I;
    EXEC dbo.Wrh_SaveItemUnit @C, @U, @I1, @u2, 12;

    -- الأطراف
    DELETE #X; INSERT #X (A, B, C, D, E, F) EXEC dbo.Wrh_SelectParties @C, 2, 0, N'LP';
    SELECT @n = COUNT(*) FROM #X;
    INSERT @R VALUES (N'L1 تصفية الدور', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #X; INSERT #X (A, B, C, D, E, F, G) EXEC dbo.Wrh_SelectParties @C, NULL, 1, N'LP';
    SELECT @n = COUNT(*) FROM #X;
    INSERT @R VALUES (N'L2 الفعّالون فقط', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #X; INSERT #X (A, B, C, D, E, F, G) EXEC dbo.Wrh_SelectParties @C, NULL, 0, N'مورد معطل';
    SELECT @n = COUNT(*) FROM #X;
    INSERT @R VALUES (N'L3 البحث بالاسم يشمل المعطّل عند الطلب', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- المخازن
    DELETE #X; INSERT #X (A, B, C, D, E, F, G) EXEC dbo.Wrh_SelectWarehouses @C, 0;
    SELECT @n = COUNT(*) FROM #X WHERE B = N'LW1' AND E = N'اختبار قوائم 1';
    INSERT @R VALUES (N'L4 المخزن مع اسم حسابه', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- المجموعات
    DELETE #X; INSERT #X (A, B, C, D, E, F, G, H) EXEC dbo.Wrh_SelectItemGroups @C, 0;
    SELECT @n = COUNT(*) FROM #X WHERE C = N'LG1' AND B IS NULL;
    INSERT @R VALUES (N'L5 المجموعة الأب بلا أب', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- الأصناف
    DELETE #X; INSERT #X (A, B, C, D, E, F, G, H) EXEC dbo.Wrh_SelectItems @C, @G1, 0, N'قوائم';
    SELECT @n = COUNT(*) FROM #X;
    INSERT @R VALUES (N'L6 أصناف المجموعة تشمل أبناءها', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #X; INSERT #X (A, B, C, D, E, F, G, H) EXEC dbo.Wrh_SelectItems @C, @G2, 0, NULL;
    SELECT @n = COUNT(*) FROM #X;
    INSERT @R VALUES (N'L7 أصناف المجموعة الابن فقط', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- وحدات الصنف
    DELETE #X; INSERT #X (A, B, C, D) EXEC dbo.Wrh_SelectItemUnits @C, @I1;
    SELECT @n = COUNT(*) FROM #X;
    INSERT @R VALUES (N'L8 وحدات الصنف الأساس والثانوية', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- فهرس المستندات
    SET @sI1 = CAST(@I1 AS NVARCHAR(20)); SET @sU = CAST(@u1 AS NVARCHAR(20));
    SET @L = CONCAT(N'[{"ItemID":', @sI1, N',"UnitID":', @sU, N',"Qty":10,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D1, @W1, NULL, @P, NULL, NULL, N'ملاحظة قوائم', @L;
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D2, @W1, NULL, @P, NULL, NULL, NULL, @L;
    CREATE TABLE #Q (DocID BIGINT, DocType TINYINT, DocTypeName NVARCHAR(60), DocNo NVARCHAR(10), DocDate DATE, DocStatus TINYINT,
        DocWhID BIGINT, WhName NVARCHAR(200), DocWh2ID BIGINT, Wh2Name NVARCHAR(200), DocPartyID BIGINT, PrtName NVARCHAR(200),
        DocCostCID BIGINT, CostCenterName NVARCHAR(200), DocRefDocID BIGINT, RefDocNo NVARCHAR(10), DocNotes NVARCHAR(500),
        TotalAmount DECIMAL(18,3), TotalRows INT);
    INSERT #Q EXEC dbo.Wrh_SelectDocs @C, 3, @D1, @D2, NULL, NULL, 1, 50;
    SELECT @n = COUNT(*) FROM #Q;
    INSERT @R VALUES (N'L9 فهرس المستندات بالنوع والتاريخ', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM #Q WHERE TotalAmount = 100 AND PrtName = N'مورد قوائم' AND WhName = N'مخزن قوائم';
    INSERT @R VALUES (N'L10 الإجمالي والجهة والمخزن', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #Q; INSERT #Q EXEC dbo.Wrh_SelectDocs @C, 3, @D1, @D2, NULL, NULL, 2, 1;
    SELECT @n = COUNT(*), @x = MAX(TotalRows) FROM #Q;
    INSERT @R VALUES (N'L11 الصفحات', CASE WHEN @n = 1 AND @x = 2 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @x));
    DELETE #Q; INSERT #Q EXEC dbo.Wrh_SelectDocs @C, NULL, @D1, @D2, NULL, N'ملاحظة قوائم', 1, 50;
    SELECT @n = COUNT(*) FROM #Q;
    INSERT @R VALUES (N'L12 البحث بالملاحظات', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #Q; INSERT #Q EXEC dbo.Wrh_SelectDocs @C, 4, @D1, @D2, NULL, NULL, 1, 50;
    SELECT @n = COUNT(*) FROM #Q;
    INSERT @R VALUES (N'L13 تصفية النوع تستبعد غيره', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DROP TABLE #Q;

    IF @@TRANCOUNT > 0 ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #X;

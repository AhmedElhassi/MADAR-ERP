﻿/* =====================================================================
   المرحلة 11 — إنشاء الحسابات آليًا (ربط الحسابات Acc_PostingRule)
   - Wrh_CreateSystemAccount: ينشئ حسابًا ابنًا تحت الحساب الأب المسجَّل لعملية (OpID) بحالة 3 أو 4،
     بنفس خطوات Acc_InsertAccounting (وراثة النوع، الكود، تنسيق الأكواد، سجل التاريخ)، ثم يسجّل له
     قاعدة ربط (نفس العملية، الحالة 1 = حساب نظام ابن لا يُمس).
     الأخطاء: 52960 لا توجد قاعدة للعملية  52961 أكثر من قاعدة  52962 الأب غير فعّال أو ممتلئ.
   - العمليات: المخزن = 1 (المخازن)، المورد = 2 (الموردين)، جهة الخدمات = 17 (الدائنون المتنوعون).
   - Prt_SaveParty و Wrh_SaveWarehouse: التوقيع كما هو و @AccID اختياري؛ إن لم يُمرَّر يُنشأ الحساب آليًا
     (وعند التعديل يبقى الحساب الحالي). موظف العهدة (دور 3) لا يُنشأ له حساب هنا.
   - Wrh_EnsurePartyAccounts: يعالج الأطراف الموجودة بلا حساب (أدوار 1 و 2).
   - الكود: إن تُرك فارغًا عند الإضافة يُولَّد رقمًا متسلسلًا للشركة (أربع خانات على الأقل).
   يتطلب Wrh_01 .. Wrh_10 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_CreateSystemAccount
    @Cmp INT, @User BIGINT, @Op SMALLINT, @Name NVARCHAR(500), @AccID BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @Name = LEFT(LTRIM(RTRIM(@Name)), 500);
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'اسم الحساب مطلوب.', 1;

    DECLARE @Parent BIGINT, @n INT, @OpName NVARCHAR(100), @m NVARCHAR(500);
    SELECT @n = COUNT(*), @Parent = MIN(r.AccID)
    FROM dbo.Acc_PostingRule AS r JOIN dbo.Acc_Account AS a ON a.AccID = r.AccID
    WHERE r.OpID = @Op AND r.StateID IN (3, 4) AND a.AccCompany = @Cmp;
    SELECT @OpName = OpName FROM dbo.Acc_Operation WHERE OpID = @Op;

    IF @n = 0
    BEGIN
        SET @m = CONCAT(N'لا توجد قاعدة ربط حسابات لعملية (', ISNULL(@OpName, CAST(@Op AS NVARCHAR(10))), N') في هذه الشركة؛ أنشئها من شاشة ربط الحسابات.');
        THROW 52960, @m, 1;
    END
    IF @n > 1
    BEGIN
        SET @m = CONCAT(N'يوجد أكثر من حساب أب مسجَّل لعملية (', ISNULL(@OpName, CAST(@Op AS NVARCHAR(10))), N') في هذه الشركة.');
        THROW 52961, @m, 1;
    END

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_CreateSystemAccount;
    BEGIN TRY
        EXEC sp_set_session_context N'Acc.SystemOperation', 1;

        DECLARE @ParentChid SMALLINT, @ParentCode NVARCHAR(60), @Ord INT;
        SELECT @ParentChid = AccChid, @ParentCode = AccCode
        FROM dbo.Acc_Account WITH (UPDLOCK, HOLDLOCK)
        WHERE AccID = @Parent AND AccCompany = @Cmp AND AccState = 0;
        IF @@ROWCOUNT = 0 THROW 52962, N'الحساب الأب المسجَّل للعملية غير فعّال أو لا يتبع الشركة.', 1;
        IF @ParentChid = 32767 THROW 52962, N'تم تجاوز الحد الأقصى لعدد أبناء الحساب الأب.', 1;
        SET @Ord = CONVERT(INT, @ParentChid) + 1;
        IF LEN(@ParentCode) + LEN(CONVERT(NVARCHAR(10), @Ord)) > 60 THROW 52962, N'رمز الحساب الجديد يتجاوز الحد المسموح.', 1;

        UPDATE dbo.Acc_Account SET AccChid = AccChid + 1 WHERE AccID = @Parent;

        INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccState, AccDateTime, AccUser, AccCompany)
        SELECT AccEnd, AccType, AccID, @Ord, AccLevel + 1, 0, @ParentCode + CONVERT(NVARCHAR(10), @Ord), @Name, 0, SYSUTCDATETIME(), @User, AccCompany
        FROM dbo.Acc_Account WHERE AccID = @Parent;
        SET @AccID = CONVERT(BIGINT, SCOPE_IDENTITY());

        EXEC dbo.Acc_UpdateAccountCode @AccCompany = @Cmp;

        INSERT dbo.Acc_AccountHistory (AccHOpration, AccHAccID, AccHEnd, AccHType, AccHParentID, AccHOrder, AccHLevel, AccHChid, AccHCode, AccHName, AccHState, AccHDateTime, AccHUser, AccHCompany)
        SELECT 1, AccID, AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccState, AccDateTime, AccUser, AccCompany
        FROM dbo.Acc_Account WHERE AccID = @AccID;

        INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (@Op, @AccID, 1);

        EXEC sp_set_session_context N'Acc.SystemOperation', 0;
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        EXEC sp_set_session_context N'Acc.SystemOperation', 0;
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_CreateSystemAccount;
        THROW;
    END CATCH
END;
GO

/* ------------------------------------------------------------------ الأطراف */
CREATE OR ALTER PROCEDURE dbo.Prt_SaveParty
    @Cmp INT, @User BIGINT, @PrtID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @Role TINYINT, @AccID BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@PrtID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @pn INT = ISNULL((SELECT MAX(TRY_CAST(PrtCode AS INT)) FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @pn), CASE WHEN LEN(CAST(@pn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@pn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @Role IS NULL OR @Role NOT IN (1, 2, 3) THROW 52203, N'نوع الجهة غير صحيح (1 مورد، 2 جهة خدمات، 3 موظف عهدة).', 1;
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب الجهة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp AND PrtCode = @Code AND PrtID <> ISNULL(@PrtID, 0))
        THROW 52204, N'كود الجهة مستخدم من قبل.', 1;

    DECLARE @Op SMALLINT = CASE @Role WHEN 1 THEN 2 WHEN 2 THEN 17 END;   -- 2 الموردين ، 17 الدائنون المتنوعون
    DECLARE @Started BIT = 0, @Cur BIGINT, @New BIGINT;
    IF ISNULL(@PrtID, 0) <> 0
    BEGIN
        SELECT @Cur = PrtAccID FROM dbo.Prt_Party WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'الجهة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Prt_SaveParty;
    BEGIN TRY
        IF @AccID IS NULL AND @Cur IS NULL AND @Op IS NOT NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, @Op, @Name, @New OUTPUT;
            SET @AccID = @New;
        END

        IF ISNULL(@PrtID, 0) = 0
        BEGIN
            INSERT dbo.Prt_Party (PrtCmpID, PrtCode, PrtName, PrtRole, PrtAccID, PrtActive, PrtCreatedBy)
            VALUES (@Cmp, @Code, @Name, @Role, @AccID, ISNULL(@Active, 1), @User);
            SET @PrtID = SCOPE_IDENTITY();
        END
        ELSE
            UPDATE dbo.Prt_Party
               SET PrtCode = @Code, PrtName = @Name, PrtRole = @Role, PrtAccID = COALESCE(@AccID, PrtAccID), PrtActive = ISNULL(@Active, 1)
             WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;

        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Prt_SaveParty;
        THROW;
    END CATCH
    SELECT @PrtID AS PrtID;
END;
GO

/* ------------------------------------------------------------------ المخازن */
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveWarehouse
    @Cmp INT, @User BIGINT, @WhID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Keeper BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@WhID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @wn INT = ISNULL((SELECT MAX(TRY_CAST(WhCode AS INT)) FROM dbo.Wrh_Warehouse WHERE WhCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @wn), CASE WHEN LEN(CAST(@wn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@wn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المخزن غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF @Keeper IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @Keeper)
        THROW 52200, N'أمين المخزن غير موجود.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhCmpID = @Cmp AND WhCode = @Code AND WhID <> ISNULL(@WhID, 0))
        THROW 52204, N'كود المخزن مستخدم من قبل.', 1;

    DECLARE @Started BIT = 0, @New BIGINT;
    IF ISNULL(@WhID, 0) <> 0 AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp)
        THROW 52206, N'المخزن غير موجود أو لا يتبع الشركة.', 1;

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveWarehouse;
    BEGIN TRY
        IF ISNULL(@WhID, 0) = 0
        BEGIN
            IF @AccID IS NULL
            BEGIN
                EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 1, @Name, @New OUTPUT;   -- 1 المخازن
                SET @AccID = @New;
            END
            INSERT dbo.Wrh_Warehouse (WhCmpID, WhCode, WhName, WhAccID, WhKeeper, WhActive)
            VALUES (@Cmp, @Code, @Name, @AccID, @Keeper, ISNULL(@Active, 1));
            SET @WhID = SCOPE_IDENTITY();
        END
        ELSE
            UPDATE dbo.Wrh_Warehouse
               SET WhCode = @Code, WhName = @Name, WhAccID = COALESCE(@AccID, WhAccID), WhKeeper = @Keeper, WhActive = ISNULL(@Active, 1)
             WHERE WhID = @WhID AND WhCmpID = @Cmp;
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveWarehouse;
        THROW;
    END CATCH
    SELECT @WhID AS WhID;
END;
GO

/* ------------------------------------------------------------------ معالجة الأطراف بلا حساب */
CREATE OR ALTER PROCEDURE dbo.Wrh_EnsurePartyAccounts
    @Cmp INT, @User BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52807, N'الشركة أو المستخدم غير صحيح.', 1;
    DECLARE @id BIGINT, @name NVARCHAR(500), @role TINYINT, @op SMALLINT, @acc BIGINT, @n INT = 0;
    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_EnsurePartyAccounts;
    BEGIN TRY
        DECLARE pc CURSOR LOCAL STATIC FOR
            SELECT PrtID, PrtName, PrtRole FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp AND PrtAccID IS NULL AND PrtRole IN (1, 2) ORDER BY PrtID;
        OPEN pc; FETCH NEXT FROM pc INTO @id, @name, @role;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @op = CASE @role WHEN 1 THEN 2 ELSE 17 END;
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, @op, @name, @acc OUTPUT;
            UPDATE dbo.Prt_Party SET PrtAccID = @acc WHERE PrtID = @id;
            SET @n += 1;
            FETCH NEXT FROM pc INTO @id, @name, @role;
        END
        CLOSE pc; DEALLOCATE pc;
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'pc') >= 0 BEGIN CLOSE pc; DEALLOCATE pc; END
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_EnsurePartyAccounts;
        THROW;
    END CATCH
    SELECT @n AS PartiesFixed;
END;
GO

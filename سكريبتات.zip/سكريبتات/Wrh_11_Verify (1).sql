/* اختبار المرحلة 11 — داخل معاملة تُرجَع. يطبع FAIL فقط + سطر إجمالي. */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_CreateSystemAccount') IS NULL THROW 52900, N'نفّذ Wrh_11_AutoAccounts.sql أولًا', 1;

DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #I (Id BIGINT);
CREATE TABLE #CP (Problem NVARCHAR(200), AccID BIGINT, AccCode NVARCHAR(100), AccName NVARCHAR(500));

DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @PW BIGINT, @PS BIGINT, @PV BIGINT, @PV2 BIGINT, @LF BIGINT;
DECLARE @p1 BIGINT, @p2 BIGINT, @p3 BIGINT, @w1 BIGINT, @a1 BIGINT, @a2 BIGINT, @a3 BIGINT, @a4 BIGINT, @a5 BIGINT;
DECLARE @n INT, @e INT, @x BIGINT, @chid INT;

IF @C IS NULL OR @U IS NULL
    INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    -- حسابات أب للاختبار (فعّالة) وورقة
    DECLARE @k INT = 0;
    DECLARE @ids TABLE (K INT, Id BIGINT);
    WHILE @k < 5
    BEGIN
        SET @k += 1;
        INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccState, AccUser, AccCompany)
        VALUES (1, 1, NULL, @k, 1, 0, CONCAT(N'ZY', @k), CONCAT(N'أب اختبار ', @k), 0, @U, @C);
        INSERT @ids VALUES (@k, CONVERT(BIGINT, SCOPE_IDENTITY()));
    END
    SELECT @PW = Id FROM @ids WHERE K = 1; SELECT @PS = Id FROM @ids WHERE K = 2; SELECT @PV = Id FROM @ids WHERE K = 3;
    SELECT @PV2 = Id FROM @ids WHERE K = 4; SELECT @LF = Id FROM @ids WHERE K = 5;

    -- قواعد الاختبار فقط (تُحذف القواعد القائمة لهذه العمليات في الشركة ضمن المعاملة)
    EXEC sp_set_session_context N'Acc.SystemOperation', 1;
    DELETE r FROM dbo.Acc_PostingRule r JOIN dbo.Acc_Account a ON a.AccID = r.AccID
    WHERE a.AccCompany = @C AND r.OpID IN (1, 2, 17) AND r.StateID IN (3, 4);
    INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (1, @PW, 3), (2, @PS, 3), (17, @PV, 3);
    EXEC sp_set_session_context N'Acc.SystemOperation', 0;

    -- مورد وجهة خدمات ومخزن بلا حساب
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'AP1', N'مورد آلي', 1; SELECT @p1 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'AP2', N'ناقل آلي', 2; SELECT @p2 = Id FROM #I;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'AW1', N'مخزن آلي', NULL; SELECT @w1 = Id FROM #I;
    SELECT @a1 = PrtAccID FROM dbo.Prt_Party WHERE PrtID = @p1;
    SELECT @a2 = PrtAccID FROM dbo.Prt_Party WHERE PrtID = @p2;
    SELECT @a3 = WhAccID FROM dbo.Wrh_Warehouse WHERE WhID = @w1;

    INSERT @R VALUES (N'A1 المورد أُنشئ له حساب', CASE WHEN @a1 IS NOT NULL THEN 1 ELSE 0 END, CONCAT(N'got ', @a1));
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccID = @a1 AND AccParentID = @PS AND AccName = N'مورد آلي' AND AccCompany = @C;
    INSERT @R VALUES (N'A2 تحت أب الموردين وباسمه', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_PostingRule WHERE AccID = @a1 AND OpID = 2 AND StateID = 1;
    INSERT @R VALUES (N'A3 قاعدة الحساب الابن (حالة 1)', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccID = @a2 AND AccParentID = @PV;
    INSERT @R VALUES (N'A4 جهة الخدمات تحت أب العملية 17', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccID = @a3 AND AccParentID = @PW;
    INSERT @R VALUES (N'A5 حساب المخزن تحت أب المخازن', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_AccountHistory WHERE AccHAccID = @a1;
    INSERT @R VALUES (N'A6 سجل تاريخ الحساب', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @chid = AccChid FROM dbo.Acc_Account WHERE AccID = @PS;
    INSERT @R VALUES (N'A7 عدّاد أبناء الأب', CASE WHEN @chid = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @chid));

    -- تعديل لا يغيّر الحساب
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, @p1, N'AP1', N'مورد آلي معدّل', 1;
    DELETE #I; INSERT #I EXEC dbo.Wrh_SaveWarehouse @C, @U, @w1, N'AW1', N'مخزن آلي معدّل', NULL;
    SELECT @n = COUNT(*) FROM dbo.Prt_Party WHERE PrtID = @p1 AND PrtAccID = @a1 AND PrtName = N'مورد آلي معدّل';
    INSERT @R VALUES (N'B1 تعديل الجهة يُبقي حسابها', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Wrh_Warehouse WHERE WhID = @w1 AND WhAccID = @a3;
    INSERT @R VALUES (N'B2 تعديل المخزن يُبقي حسابه', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccParentID = @PS;
    INSERT @R VALUES (N'B3 لم يُنشأ حساب جديد عند التعديل', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- حساب صريح (توافق مع الاستعمال القديم) والعهدة
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'AP3', N'مورد بحساب صريح', 1, @LF; SELECT @x = Id FROM #I;
    SELECT @n = COUNT(*) FROM dbo.Prt_Party WHERE PrtID = @x AND PrtAccID = @LF;
    INSERT @R VALUES (N'C1 الحساب الصريح يُحترم', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccParentID = @PS;
    INSERT @R VALUES (N'C2 لا حساب آلي مع الصريح', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #I; INSERT #I EXEC dbo.Prt_SaveParty @C, @U, 0, N'AP4', N'موظف عهدة', 3; SELECT @x = Id FROM #I;
    SELECT @n = COUNT(*) FROM dbo.Prt_Party WHERE PrtID = @x AND PrtAccID IS NULL;
    INSERT @R VALUES (N'C3 العهدة لا يُنشأ لها حساب هنا', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- فحص حماية الحسابات
    INSERT #CP EXEC dbo.Acc_CheckProtectedAccounts @C;
    SELECT @n = COUNT(*) FROM #CP WHERE AccID IN (@a1, @a2, @a3);
    INSERT @R VALUES (N'D1 فحص الحسابات المحمية نظيف للحسابات الجديدة', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- معالجة الأطراف بلا حساب
    INSERT dbo.Prt_Party (PrtCmpID, PrtCode, PrtName, PrtRole, PrtAccID, PrtActive, PrtCreatedBy) VALUES (@C, N'AP5', N'مورد قديم بلا حساب', 1, NULL, 1, @U);
    SET @x = CONVERT(BIGINT, SCOPE_IDENTITY());
    EXEC dbo.Wrh_EnsurePartyAccounts @C, @U;
    SELECT @n = COUNT(*) FROM dbo.Prt_Party WHERE PrtID = @x AND PrtAccID IS NOT NULL;
    INSERT @R VALUES (N'E1 المعالجة تنشئ حسابًا للطرف القديم', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- أخطاء
    EXEC sp_set_session_context N'Acc.SystemOperation', 1;
    DELETE FROM dbo.Acc_PostingRule WHERE OpID = 2 AND AccID = @PS;
    EXEC sp_set_session_context N'Acc.SystemOperation', 0;
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'AP6', N'بلا قاعدة', 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'F1 لا قاعدة للعملية', CASE WHEN @e = 52960 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @n = COUNT(*) FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtCode = N'AP6';
    INSERT @R VALUES (N'F2 لم تُحفظ الجهة عند فشل الحساب', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    EXEC sp_set_session_context N'Acc.SystemOperation', 1;
    INSERT dbo.Acc_PostingRule (OpID, AccID, StateID) VALUES (17, @PV2, 3);
    EXEC sp_set_session_context N'Acc.SystemOperation', 0;
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'AP7', N'قاعدتان', 2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'F3 أكثر من أب للعملية', CASE WHEN @e = 52961 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    IF @@TRANCOUNT > 0 ROLLBACK;
END

SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;
DROP TABLE #I; DROP TABLE #CP;

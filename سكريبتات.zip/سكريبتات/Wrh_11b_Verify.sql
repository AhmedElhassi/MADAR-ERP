/* اختبار الكود الآلي (المرحلة 11ب) — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @LF BIGINT, @m INT, @c1 INT, @c2 INT, @p1 BIGINT, @e INT, @w1 INT, @w2 INT;
IF @C IS NULL OR @U IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccState, AccUser, AccCompany)
    VALUES (1, 1, NULL, 1, 1, 0, N'ZY9', N'ورقة اختبار', 0, @U, @C);
    SET @LF = CONVERT(BIGINT, SCOPE_IDENTITY());

    SELECT @m = ISNULL(MAX(TRY_CAST(PrtCode AS INT)), 0) FROM dbo.Prt_Party WHERE PrtCmpID = @C;
    EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد كود آلي 1', 1, @LF;
    EXEC dbo.Prt_SaveParty @C, @U, 0, NULL, N'مورد كود آلي 2', 1, @LF;
    SELECT @c1 = TRY_CAST(PrtCode AS INT), @p1 = PrtID FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد كود آلي 1';
    SELECT @c2 = TRY_CAST(PrtCode AS INT) FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد كود آلي 2';
    INSERT @R VALUES (N'K1 كود الجهة الأول متسلسل', CASE WHEN @c1 = @m + 1 THEN 1 ELSE 0 END, CONCAT(@c1, N' / ', @m));
    INSERT @R VALUES (N'K2 كود الجهة الثاني التالي', CASE WHEN @c2 = @m + 2 THEN 1 ELSE 0 END, CONCAT(@c2, N' / ', @m));
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, @p1, N'', N'تعديل بلا كود', 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'K3 الكود مطلوب عند التعديل', CASE WHEN @e = 52202 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    SELECT @m = ISNULL(MAX(TRY_CAST(WhCode AS INT)), 0) FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C;
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن كود آلي 1', @LF;
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, NULL, N'مخزن كود آلي 2', @LF;
    SELECT @w1 = TRY_CAST(WhCode AS INT) FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن كود آلي 1';
    SELECT @w2 = TRY_CAST(WhCode AS INT) FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن كود آلي 2';
    INSERT @R VALUES (N'K4 أكواد المخازن متسلسلة', CASE WHEN @w1 = @m + 1 AND @w2 = @m + 2 THEN 1 ELSE 0 END, CONCAT(@w1, N',', @w2, N' / ', @m));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

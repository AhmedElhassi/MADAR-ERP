﻿/* =====================================================================
   المرحلة 12: حساب المجموعة والكود آليان
   - Wrh_SaveItemGroup: التوقيع كما هو. عند الإضافة بلا @AccID يُنشأ حساب المصروف آليًا تحت الأب
     المسجَّل لعملية 15 (مواد تشغيل) في Acc_PostingRule، والكود الفارغ يُولَّد رقمًا متسلسلًا.
   - عند التعديل: يبقى الحساب الحالي، فإن لم يكن للمجموعة حساب أُنشئ، ويتبع اسم الحساب اسم المجموعة.
   يتطلب Wrh_11 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItemGroup
    @Cmp INT, @User BIGINT, @GrpID BIGINT, @ParentID BIGINT = NULL, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@GrpID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @gn INT = ISNULL((SELECT MAX(TRY_CAST(GrpCode AS INT)) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @gn), CASE WHEN LEN(CAST(@gn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@gn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المجموعة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpCode = @Code AND GrpID <> ISNULL(@GrpID, 0))
        THROW 52204, N'كود المجموعة مستخدم من قبل.', 1;

    -- الأب: للشركة نفسها، لا يحمل أصنافًا، ولا حلقة
    IF @ParentID IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID AND GrpCmpID = @Cmp)
            THROW 52207, N'المجموعة الأب غير موجودة أو لا تتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemGrpID = @ParentID)
            THROW 52207, N'المجموعة الأب تحمل أصنافًا فلا تقبل مجموعات فرعية.', 1;
        IF ISNULL(@GrpID, 0) > 0
        BEGIN
            DECLARE @Cyc INT = 0;
            ;WITH D AS
            (
                SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID
                UNION ALL
                SELECT g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN D ON g.GrpParentID = D.GrpID
            )
            SELECT @Cyc = COUNT(*) FROM D WHERE GrpID = @ParentID;
            IF @Cyc > 0 THROW 52207, N'لا يجوز جعل المجموعة أبًا لنفسها أو لأحد فروعها.', 1;
        END
    END

    DECLARE @Started BIT = 0, @New BIGINT, @Cur BIGINT;
    IF ISNULL(@GrpID, 0) <> 0
    BEGIN
        SELECT @Cur = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveItemGroup;
    BEGIN TRY
        -- حساب المصروف آلي (عملية 15 مواد تشغيل) إن لم يُمرَّر ولم يكن للمجموعة حساب
        IF @AccID IS NULL AND @Cur IS NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 15, @Name, @New OUTPUT;
            SET @AccID = @New;
        END
        IF ISNULL(@GrpID, 0) = 0
        BEGIN
            INSERT dbo.Wrh_ItemGroup (GrpCmpID, GrpParentID, GrpCode, GrpName, GrpAccID, GrpActive)
            VALUES (@Cmp, @ParentID, @Code, @Name, @AccID, ISNULL(@Active, 1));
            SET @GrpID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE dbo.Wrh_ItemGroup
               SET GrpParentID = @ParentID, GrpCode = @Code, GrpName = @Name, GrpAccID = COALESCE(@AccID, GrpAccID), GrpActive = ISNULL(@Active, 1)
             WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
            -- مزامنة اسم حساب النظام مع اسم المجموعة
            IF @Cur IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @Cur AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @Cur AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @Cur, @User, @Cmp;
        END
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveItemGroup;
        THROW;
    END CATCH
    SELECT @GrpID AS GrpID;
END;
GO

/* اختبار المرحلة 12: حساب المجموعة والكود آليان — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Par BIGINT, @g1 BIGINT, @g2 BIGINT, @a1 BIGINT, @n INT, @m INT, @c1 INT, @c2 INT, @LF BIGINT;
SELECT @Par = MIN(r.AccID) FROM dbo.Acc_PostingRule r JOIN dbo.Acc_Account a ON a.AccID = r.AccID WHERE r.OpID = 15 AND r.StateID IN (3,4) AND a.AccCompany = @C;
IF @C IS NULL OR @U IS NULL OR @Par IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم وقاعدة ربط للعملية 15');
ELSE
BEGIN
    BEGIN TRAN;
    SELECT @m = ISNULL(MAX(TRY_CAST(GrpCode AS INT)), 0) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C;
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة آلية 1';
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, NULL, N'مجموعة آلية 2';
    SELECT @g1 = GrpID, @a1 = GrpAccID, @c1 = TRY_CAST(GrpCode AS INT) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة آلية 1';
    SELECT @g2 = GrpID, @c2 = TRY_CAST(GrpCode AS INT) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة آلية 2';
    INSERT @R VALUES (N'M1 كود المجموعة آلي متسلسل', CASE WHEN @c1 = @m + 1 AND @c2 = @m + 2 THEN 1 ELSE 0 END, CONCAT(@c1, N',', @c2, N' / ', @m));
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccID = @a1 AND AccParentID = @Par AND AccName = N'مجموعة آلية 1';
    INSERT @R VALUES (N'M2 حساب المجموعة تحت أب عملية 15', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Acc_PostingRule WHERE AccID = @a1 AND OpID = 15 AND StateID = 1;
    INSERT @R VALUES (N'M3 قاعدة ربط لحساب المجموعة', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Wrh_ItemGroup WHERE GrpID IN (@g1, @g2) AND GrpAccID IS NOT NULL;
    INSERT @R VALUES (N'M4 لكل مجموعة حساب', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    EXEC dbo.Wrh_SaveItemGroup @C, @U, @g1, NULL, N'0001x', N'مجموعة آلية معدّلة';
    SELECT @n = COUNT(*) FROM dbo.Acc_Account WHERE AccID = @a1 AND AccName = N'مجموعة آلية معدّلة';
    INSERT @R VALUES (N'M5 تعديل الاسم يعدّل اسم الحساب', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM dbo.Wrh_ItemGroup WHERE GrpID = @g1 AND GrpAccID = @a1;
    INSERT @R VALUES (N'M6 الحساب يبقى بعد التعديل', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- مجموعة قديمة بلا حساب: يُنشأ لها عند التعديل
    UPDATE dbo.Wrh_ItemGroup SET GrpAccID = NULL WHERE GrpID = @g2;
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @g2, NULL, N'0099', N'مجموعة قديمة';
    SELECT @n = COUNT(*) FROM dbo.Wrh_ItemGroup WHERE GrpID = @g2 AND GrpAccID IS NOT NULL;
    INSERT @R VALUES (N'M7 مجموعة بلا حساب يُنشأ لها عند التعديل', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- حساب صريح يُحترم
    INSERT dbo.Acc_Account (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName, AccState, AccUser, AccCompany)
    VALUES (1, 1, NULL, 1, 1, 0, N'ZY9', N'ورقة اختبار', 0, @U, @C);
    SET @LF = CONVERT(BIGINT, SCOPE_IDENTITY());
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة بحساب صريح', @LF;
    SELECT @n = COUNT(*) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة بحساب صريح' AND GrpAccID = @LF;
    INSERT @R VALUES (N'M8 الحساب الصريح يُحترم', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

/* =====================================================================
   المرحلة 13: الأصناف — كود آلي، حماية الوحدة الأساس، حذف وحدة ثانوية
   - Wrh_SaveItem: التوقيع كما هو. الكود الفارغ عند الإضافة يُولَّد رقمًا متسلسلًا للشركة (أربع خانات
     على الأقل)، وعند التعديل الكود مطلوب. تغيير الوحدة الأساس ممنوع بعد ورود الصنف في أي مستند (52213).
   - Wrh_DeleteItemUnit(@Cmp,@User,@ItemID,@UnitID): يحذف وحدة ثانوية ما لم تُستعمل في بند (52212).
   يتطلب Wrh_02 .. Wrh_12 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItem
    @Cmp INT, @User BIGINT, @ItemID BIGINT, @GrpID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @BaseUnitID BIGINT, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@ItemID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @n INT = ISNULL((SELECT MAX(TRY_CAST(ItemCode AS INT)) FROM dbo.Wrh_Item WHERE ItemCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @n), CASE WHEN LEN(CAST(@n AS NVARCHAR(10))) > 4 THEN LEN(CAST(@n AS NVARCHAR(10))) ELSE 4 END);
    END

    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp)
        THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpParentID = @GrpID)
       OR EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpAccID IS NULL)
        THROW 52208, N'الصنف يُربط بمجموعة ورقية (بلا مجموعات فرعية) ولها حساب مصروف.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Unit WHERE UnitID = @BaseUnitID AND UnitCmpID = @Cmp)
        THROW 52210, N'الوحدة الأساس غير موجودة أو لا تتبع الشركة.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemCmpID = @Cmp AND ItemCode = @Code AND ItemID <> ISNULL(@ItemID, 0))
        THROW 52204, N'كود الصنف مستخدم من قبل.', 1;

    IF ISNULL(@ItemID, 0) = 0
    BEGIN
        INSERT dbo.Wrh_Item (ItemCmpID, ItemCode, ItemName, ItemGrpID, ItemBaseUnitID, ItemActive)
        VALUES (@Cmp, @Code, @Name, @GrpID, @BaseUnitID, ISNULL(@Active, 1));
        SET @ItemID = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemID = @ItemID AND ItemCmpID = @Cmp)
            THROW 52206, N'الصنف غير موجود أو لا يتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemID = @ItemID AND ItemBaseUnitID <> @BaseUnitID)
           AND EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE ItemID = @ItemID)
            THROW 52213, N'لا يجوز تغيير الوحدة الأساس لصنف ورد في مستندات.', 1;
        UPDATE dbo.Wrh_Item
           SET ItemCode = @Code, ItemName = @Name, ItemGrpID = @GrpID, ItemBaseUnitID = @BaseUnitID, ItemActive = ISNULL(@Active, 1)
         WHERE ItemID = @ItemID AND ItemCmpID = @Cmp;
        -- لا يبقى للوحدة الأساس صف تحويل ثانوي
        DELETE dbo.Wrh_ItemUnit WHERE ItemID = @ItemID AND UnitID = @BaseUnitID;
    END
    SELECT @ItemID AS ItemID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_DeleteItemUnit
    @Cmp INT, @User BIGINT, @ItemID BIGINT, @UnitID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemID = @ItemID AND ItemCmpID = @Cmp)
        THROW 52206, N'الصنف غير موجود أو لا يتبع الشركة.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemUnit WHERE ItemID = @ItemID AND UnitID = @UnitID)
        THROW 52210, N'الوحدة الثانوية غير موجودة لهذا الصنف.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE ItemID = @ItemID AND UnitID = @UnitID)
        THROW 52212, N'الوحدة مستعملة في بنود مستندات فلا تُحذف.', 1;
    DELETE dbo.Wrh_ItemUnit WHERE ItemID = @ItemID AND UnitID = @UnitID;
END;
GO

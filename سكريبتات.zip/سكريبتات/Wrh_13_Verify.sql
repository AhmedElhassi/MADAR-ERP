/* اختبار المرحلة 13: كود الصنف الآلي وحذف الوحدة الثانوية — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @g BIGINT, @u1 BIGINT, @u2 BIGINT, @i1 BIGINT, @n INT, @m INT, @c1 INT, @c2 INT, @e INT;
IF @C IS NULL OR @U IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة اختبار أصناف';
    SELECT @g = GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة اختبار أصناف';
    EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة اختبار أ';
    EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة اختبار ب';
    SELECT @u1 = UnitID FROM dbo.Wrh_Unit WHERE UnitCmpID = @C AND UnitName = N'وحدة اختبار أ';
    SELECT @u2 = UnitID FROM dbo.Wrh_Unit WHERE UnitCmpID = @C AND UnitName = N'وحدة اختبار ب';

    SELECT @m = ISNULL(MAX(TRY_CAST(ItemCode AS INT)), 0) FROM dbo.Wrh_Item WHERE ItemCmpID = @C;
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @g, N'', N'صنف آلي 1', @u1;
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @g, NULL, N'صنف آلي 2', @u1;
    SELECT @i1 = ItemID, @c1 = TRY_CAST(ItemCode AS INT) FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف آلي 1';
    SELECT @c2 = TRY_CAST(ItemCode AS INT) FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف آلي 2';
    INSERT @R VALUES (N'N1 كود الصنف آلي متسلسل', CASE WHEN @c1 = @m + 1 AND @c2 = @m + 2 THEN 1 ELSE 0 END, CONCAT(@c1, N',', @c2, N' / ', @m));

    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItem @C, @U, @i1, @g, N'', N'تعديل بلا كود', @u1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N2 الكود مطلوب عند التعديل', CASE WHEN @e = 52202 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    EXEC dbo.Wrh_SaveItemUnit @C, @U, @i1, @u2, 12;
    SELECT @n = COUNT(*) FROM dbo.Wrh_ItemUnit WHERE ItemID = @i1 AND UnitID = @u2;
    INSERT @R VALUES (N'N3 وحدة ثانوية أُضيفت', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    EXEC dbo.Wrh_DeleteItemUnit @C, @U, @i1, @u2;
    SELECT @n = COUNT(*) FROM dbo.Wrh_ItemUnit WHERE ItemID = @i1 AND UnitID = @u2;
    INSERT @R VALUES (N'N4 حذف الوحدة الثانوية', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteItemUnit @C, @U, @i1, @u2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'N5 حذف وحدة غير موجودة', CASE WHEN @e = 52210 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- لا بنود بعد: تغيير الوحدة الأساس مسموح
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItem @C, @U, @i1, @g, N'9999', N'صنف آلي 1', @u2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    SELECT @n = COUNT(*) FROM dbo.Wrh_Item WHERE ItemID = @i1 AND ItemBaseUnitID = @u2;
    INSERT @R VALUES (N'N6 تغيير الأساس مسموح بلا مستندات', CASE WHEN @e = 0 AND @n = 1 THEN 1 ELSE 0 END, CONCAT(N'err ', @e, N' n ', @n));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

/* =====================================================================
   المرحلة 14: إجراءات شاشة إدخال المستند (Wrh_DocEdit)
   - Wrh_SelectDocTypes: تعريف الأنواع (متطلبات الرأس ونوع المرجع) ليقرأها النموذج من البيانات.
   - Wrh_SelectRefDocs(@Cmp,@Type,@PartyID): المستندات التي يجوز الإحالة إليها من نوع @Type
     (نوع المرجع من التعريف، غير الملغاة، ولها متبقٍ > 0)، مع تصفية بالجهة إن مُرّرت.
   - Wrh_SelectCostCenters(@Cmp): مراكز التكلفة للشركة (الجهة الطالبة).
   يتطلب Wrh_03 .. Wrh_13 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectDocTypes
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DtType, DtName, DtClass, DtNeedWh, DtNeedWh2, DtNeedParty, DtNeedCost, DtNeedRef, DtRefType, DtEngine
    FROM dbo.Wrh_DocTypeDef ORDER BY DtType;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectRefDocs
    @Cmp INT, @Type TINYINT, @PartyID BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @RT TINYINT;
    SELECT @RT = DtRefType FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type;
    IF @RT IS NULL THROW 52301, N'هذا النوع لا يقبل مرجعًا.', 1;

    SELECT d.DocID, d.DocNo, d.DocDate, d.DocPartyID, p.PrtName, d.DocWhID, w.WhName,
           CAST(SUM(l.BaseQty - l.QtyReferred - l.QtyCancelled) AS DECIMAL(18,3)) AS RemainingQty,
           CONCAT(d.DocNo, N' - ', CONVERT(NVARCHAR(10), d.DocDate, 23), ISNULL(CONCAT(N' - ', p.PrtName), N'')) AS DocDisplay
    FROM dbo.Wrh_Doc AS d
    JOIN dbo.Wrh_DocLine AS l ON l.DocID = d.DocID
    LEFT JOIN dbo.Prt_Party AS p ON p.PrtID = d.DocPartyID
    LEFT JOIN dbo.Wrh_Warehouse AS w ON w.WhID = d.DocWhID
    WHERE d.DocCmpID = @Cmp AND d.DocType = @RT AND d.DocStatus <> 9
      AND (@PartyID IS NULL OR d.DocPartyID = @PartyID)
    GROUP BY d.DocID, d.DocNo, d.DocDate, d.DocPartyID, p.PrtName, d.DocWhID, w.WhName
    HAVING SUM(l.BaseQty - l.QtyReferred - l.QtyCancelled) > 0
    ORDER BY d.DocDate DESC, d.DocID DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectCostCenters
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CsCID, CsCName FROM dbo.Acc_CostCenter WHERE CsCCompany = @Cmp ORDER BY CsCName;
END;
GO

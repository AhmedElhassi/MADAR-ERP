/* اختبار المرحلة 14 — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_SelectRefDocs') IS NULL THROW 52900, N'نفّذ Wrh_14_DocForm.sql أولًا', 1;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #T (A TINYINT, B NVARCHAR(60), C TINYINT, D BIT, E BIT, F BIT, G BIT, H BIT, I TINYINT, J BIT);
CREATE TABLE #F (DocID BIGINT, DocNo NVARCHAR(50), DocDate DATE, PartyID BIGINT, PrtName NVARCHAR(200), WhID BIGINT, WhName NVARCHAR(200), Rem DECIMAL(18,3), Disp NVARCHAR(400));
CREATE TABLE #K (A BIGINT, B NVARCHAR(200));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @G BIGINT, @u1 BIGINT, @I1 BIGINT, @W1 BIGINT, @P BIGINT, @P2 BIGINT, @inv BIGINT, @n INT, @e INT, @L NVARCHAR(MAX);
IF @C IS NULL OR @U IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    INSERT #T EXEC dbo.Wrh_SelectDocTypes;
    SELECT @n = COUNT(*) FROM #T;
    INSERT @R VALUES (N'F1 أنواع المستندات', CASE WHEN @n >= 15 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SELECT @n = COUNT(*) FROM #T WHERE A = 4 AND I = 3 AND H = 1;
    INSERT @R VALUES (N'F2 الاستلام يحيل إلى فاتورة الشراء', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن نموذج';
    SELECT @W1 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن نموذج';
    EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد نموذج 1', 1;
    EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد نموذج 2', 1;
    SELECT @P = PrtID FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد نموذج 1';
    SELECT @P2 = PrtID FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد نموذج 2';
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة نموذج';
    SELECT @G = GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة نموذج';
    EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة نموذج';
    SELECT @u1 = UnitID FROM dbo.Wrh_Unit WHERE UnitCmpID = @C AND UnitName = N'وحدة نموذج';
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @G, N'', N'صنف نموذج', @u1;
    SELECT @I1 = ItemID FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف نموذج';

    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":10,"Price":5}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, '2031-08-01', @W1, NULL, @P, NULL, NULL, N'فاتورة نموذج', @L;
    SELECT @inv = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3 AND DocNotes = N'فاتورة نموذج';

    DELETE #F; INSERT #F EXEC dbo.Wrh_SelectRefDocs @C, 4, NULL;
    SELECT @n = COUNT(*) FROM #F WHERE DocID = @inv AND Rem = 10;
    INSERT @R VALUES (N'F3 الفاتورة مرجع صالح للاستلام بمتبقي 10', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #F; INSERT #F EXEC dbo.Wrh_SelectRefDocs @C, 4, @P;
    SELECT @n = COUNT(*) FROM #F WHERE DocID = @inv;
    INSERT @R VALUES (N'F4 التصفية بنفس الجهة', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #F; INSERT #F EXEC dbo.Wrh_SelectRefDocs @C, 4, @P2;
    SELECT @n = COUNT(*) FROM #F WHERE DocID = @inv;
    INSERT @R VALUES (N'F5 جهة أخرى لا ترى الفاتورة', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SET @e = 0; BEGIN TRY DELETE #F; INSERT #F EXEC dbo.Wrh_SelectRefDocs @C, 1, NULL; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'F6 نوع بلا مرجع', CASE WHEN @e = 52301 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    INSERT #K EXEC dbo.Wrh_SelectCostCenters @C;
    SELECT @n = COUNT(*) FROM #K WHERE A = @CC;
    INSERT @R VALUES (N'F7 مراكز التكلفة', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

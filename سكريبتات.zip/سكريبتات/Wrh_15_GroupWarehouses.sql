﻿/* =====================================================================
   المرحلة 15: ربط مجموعات الأصناف بالمخازن
   - Wrh_GroupWarehouse: المجموعة <-> المخزن (كثير لكثير). الصنف يتبع المخزن عبر مجموعته.
   - Wrh_SaveItemGroup: معامل اختياري جديد @Whs (قائمة معرّفات مفصولة بفواصل):
       NULL = لا يُمسّ الربط | غير ذلك = استبدال الربط، ويلزم مخزن صحيح واحد على الأقل (52230).
   - Wrh_SelectGroupWarehouses(@Cmp)               : لكل مجموعة WhIDs و WhNames (لصفحة المجموعات)
   - Wrh_SelectWhMainGroups(@Cmp,@WhID)            : الرئيسيات المرتبطة بالمخزن أو لأحد فروعها ربط به
   - Wrh_SelectWhSubGroups(@Cmp,@WhID,@ParentID)   : الفروع المباشرة (المرتبطة أو لأحد فروعها ربط)
   - Wrh_SelectWhItems(@Cmp,@WhID,@MainID,@SubID,@Search): أصناف المخزن حسب المجموعة (تشمل الفروع)
   - Wrh_SaveDoc: طلب المواد وطلب الشراء يرفضان صنفًا خارج مجموعات المخزن (52231)،
     وذلك للمخزن الذي له ربط واحد على الأقل (الذي لا ربط له بعد يبقى بلا قيد).
   يتطلب Wrh_12 و Wrh_09 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
GO

IF OBJECT_ID(N'dbo.Wrh_GroupWarehouse', N'U') IS NULL
    CREATE TABLE dbo.Wrh_GroupWarehouse
    (
        GwGrpID BIGINT NOT NULL CONSTRAINT FK_Wrh_GroupWarehouse_Grp REFERENCES dbo.Wrh_ItemGroup (GrpID),
        GwWhID  BIGINT NOT NULL CONSTRAINT FK_Wrh_GroupWarehouse_Wh  REFERENCES dbo.Wrh_Warehouse (WhID),
        CONSTRAINT PK_Wrh_GroupWarehouse PRIMARY KEY (GwGrpID, GwWhID)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Wrh_GroupWarehouse_Wh' AND object_id = OBJECT_ID(N'dbo.Wrh_GroupWarehouse'))
    CREATE INDEX IX_Wrh_GroupWarehouse_Wh ON dbo.Wrh_GroupWarehouse (GwWhID, GwGrpID);
GO


CREATE OR ALTER PROCEDURE dbo.Wrh_SelectGroupWarehouses
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT g.GrpID,
           ISNULL(STUFF((SELECT N',' + CAST(w.GwWhID AS NVARCHAR(20)) FROM dbo.Wrh_GroupWarehouse AS w
                         WHERE w.GwGrpID = g.GrpID ORDER BY w.GwWhID FOR XML PATH(N''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, N''), N'') AS WhIDs,
           ISNULL(STUFF((SELECT N'، ' + h.WhName FROM dbo.Wrh_GroupWarehouse AS w JOIN dbo.Wrh_Warehouse AS h ON h.WhID = w.GwWhID
                         WHERE w.GwGrpID = g.GrpID ORDER BY h.WhName FOR XML PATH(N''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, N''), N'') AS WhNames
    FROM dbo.Wrh_ItemGroup AS g
    WHERE g.GrpCmpID = @Cmp;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectWhMainGroups
    @Cmp INT, @WhID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    ;WITH T AS
    (
        SELECT GrpID AS RootID, GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpParentID IS NULL AND GrpActive = 1
        UNION ALL
        SELECT T.RootID, g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN T ON g.GrpParentID = T.GrpID WHERE g.GrpActive = 1
    )
    SELECT g.GrpID, g.GrpCode, g.GrpName
    FROM dbo.Wrh_ItemGroup AS g
    WHERE g.GrpID IN (SELECT T.RootID FROM T JOIN dbo.Wrh_GroupWarehouse AS w ON w.GwGrpID = T.GrpID AND w.GwWhID = @WhID)
    ORDER BY g.GrpName;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectWhSubGroups
    @Cmp INT, @WhID BIGINT, @ParentID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    ;WITH T AS
    (
        SELECT GrpID AS RootID, GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpParentID = @ParentID AND GrpActive = 1
        UNION ALL
        SELECT T.RootID, g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN T ON g.GrpParentID = T.GrpID WHERE g.GrpActive = 1
    )
    SELECT g.GrpID, g.GrpCode, g.GrpName
    FROM dbo.Wrh_ItemGroup AS g
    WHERE g.GrpID IN (SELECT T.RootID FROM T JOIN dbo.Wrh_GroupWarehouse AS w ON w.GwGrpID = T.GrpID AND w.GwWhID = @WhID)
    ORDER BY g.GrpName;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SelectWhItems
    @Cmp INT, @WhID BIGINT, @MainID BIGINT = NULL, @SubID BIGINT = NULL, @Search NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Scope BIGINT = ISNULL(@SubID, @MainID);
    ;WITH D AS
    (
        SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @Scope AND GrpCmpID = @Cmp
        UNION ALL
        SELECT g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN D ON g.GrpParentID = D.GrpID
    )
    SELECT i.ItemID, i.ItemCode, i.ItemName, i.ItemBaseUnitID, u.UnitName AS BaseUnitName, g.GrpID, g.GrpName
    FROM dbo.Wrh_Item AS i
    JOIN dbo.Wrh_ItemGroup AS g ON g.GrpID = i.ItemGrpID
    JOIN dbo.Wrh_Unit AS u ON u.UnitID = i.ItemBaseUnitID
    WHERE i.ItemCmpID = @Cmp AND i.ItemActive = 1
      AND EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse AS w WHERE w.GwGrpID = i.ItemGrpID AND w.GwWhID = @WhID)
      AND (@Scope IS NULL OR i.ItemGrpID IN (SELECT GrpID FROM D))
      AND (@Search IS NULL OR @Search = N'' OR i.ItemCode LIKE N'%' + @Search + N'%' OR i.ItemName LIKE N'%' + @Search + N'%')
    ORDER BY i.ItemName;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItemGroup
    @Cmp INT, @User BIGINT, @GrpID BIGINT, @ParentID BIGINT = NULL, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Active BIT = 1, @Whs NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@GrpID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @gn INT = ISNULL((SELECT MAX(TRY_CAST(GrpCode AS INT)) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @gn), CASE WHEN LEN(CAST(@gn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@gn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المجموعة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpCode = @Code AND GrpID <> ISNULL(@GrpID, 0))
        THROW 52204, N'كود المجموعة مستخدم من قبل.', 1;

    -- الأب: للشركة نفسها، لا يحمل أصنافًا، ولا حلقة
    IF @ParentID IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID AND GrpCmpID = @Cmp)
            THROW 52207, N'المجموعة الأب غير موجودة أو لا تتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemGrpID = @ParentID)
            THROW 52207, N'المجموعة الأب تحمل أصنافًا فلا تقبل مجموعات فرعية.', 1;
        IF ISNULL(@GrpID, 0) > 0
        BEGIN
            DECLARE @Cyc INT = 0;
            ;WITH D AS
            (
                SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID
                UNION ALL
                SELECT g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN D ON g.GrpParentID = D.GrpID
            )
            SELECT @Cyc = COUNT(*) FROM D WHERE GrpID = @ParentID;
            IF @Cyc > 0 THROW 52207, N'لا يجوز جعل المجموعة أبًا لنفسها أو لأحد فروعها.', 1;
        END
    END

    -- مخازن المجموعة: NULL = لا يُمسّ الربط؛ وإن مُرّرت فيجب أن يوجد مخزن واحد صحيح على الأقل
    DECLARE @W TABLE (WhID BIGINT PRIMARY KEY);
    IF @Whs IS NOT NULL
    BEGIN
        INSERT @W SELECT DISTINCT TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) FROM STRING_SPLIT(@Whs, N',')
                  WHERE TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) IS NOT NULL;
        IF NOT EXISTS (SELECT 1 FROM @W) THROW 52230, N'مخزن واحد على الأقل مطلوب للمجموعة.', 1;
        IF EXISTS (SELECT 1 FROM @W AS x WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = x.WhID AND WhCmpID = @Cmp))
            THROW 52230, N'مخزن غير موجود أو لا يتبع الشركة.', 1;
    END

    DECLARE @Started BIT = 0, @New BIGINT, @Cur BIGINT;
    IF ISNULL(@GrpID, 0) <> 0
    BEGIN
        SELECT @Cur = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveItemGroup;
    BEGIN TRY
        -- حساب المصروف آلي (عملية 15 مواد تشغيل) إن لم يُمرَّر ولم يكن للمجموعة حساب
        IF @AccID IS NULL AND @Cur IS NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 15, @Name, @New OUTPUT;
            SET @AccID = @New;
        END
        IF ISNULL(@GrpID, 0) = 0
        BEGIN
            INSERT dbo.Wrh_ItemGroup (GrpCmpID, GrpParentID, GrpCode, GrpName, GrpAccID, GrpActive)
            VALUES (@Cmp, @ParentID, @Code, @Name, @AccID, ISNULL(@Active, 1));
            SET @GrpID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE dbo.Wrh_ItemGroup
               SET GrpParentID = @ParentID, GrpCode = @Code, GrpName = @Name, GrpAccID = COALESCE(@AccID, GrpAccID), GrpActive = ISNULL(@Active, 1)
             WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
            -- مزامنة اسم حساب النظام مع اسم المجموعة
            IF @Cur IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @Cur AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @Cur AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @Cur, @User, @Cmp;
        END
        IF @Whs IS NOT NULL
        BEGIN
            DELETE dbo.Wrh_GroupWarehouse WHERE GwGrpID = @GrpID AND GwWhID NOT IN (SELECT WhID FROM @W);
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT @GrpID, WhID FROM @W AS x
            WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @GrpID AND GwWhID = x.WhID);
        END
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveItemGroup;
        THROW;
    END CATCH
    SELECT @GrpID AS GrpID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE,
    @WhID BIGINT = NULL, @Wh2ID BIGINT = NULL, @PartyID BIGINT = NULL, @CostCID BIGINT = NULL,
    @RefDocID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52302, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Class TINYINT, @NW BIT, @NW2 BIT, @NP BIT, @NC BIT, @NR BIT, @RT TINYINT;
    SELECT @Class = DtClass, @NW = DtNeedWh, @NW2 = DtNeedWh2, @NP = DtNeedParty, @NC = DtNeedCost,
           @NR = DtNeedRef, @RT = DtRefType
    FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type AND DtEngine = 1;
    IF @Class IS NULL THROW 52301, N'نوع المستند غير صحيح أو غير مدعوم في هذا المحرك.', 1;

    -- متطلبات الرأس
    IF @NW = 1 AND @WhID IS NULL THROW 52302, N'المخزن مطلوب لهذا النوع.', 1;
    IF @NW2 = 1 AND @Wh2ID IS NULL THROW 52302, N'المخزن المقابل مطلوب لهذا النوع.', 1;
    IF @NP = 1 AND @PartyID IS NULL THROW 52302, N'الجهة (المورد/العهدة) مطلوبة لهذا النوع.', 1;
    IF @NC = 1 AND @CostCID IS NULL THROW 52302, N'الجهة الطالبة (مركز التكلفة) مطلوبة لهذا النوع.', 1;
    IF @NR = 1 AND @RefDocID IS NULL THROW 52302, N'المستند المرجعي مطلوب لهذا النوع.', 1;

    IF @WhID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Wh2ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @Wh2ID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن المقابل غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @WhID IS NOT NULL AND @Wh2ID IS NOT NULL AND @WhID = @Wh2ID
        THROW 52310, N'المخزنان في التحويل يجب أن يكونا مختلفين.', 1;
    IF @PartyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
        THROW 52310, N'الجهة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    IF @CostCID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CostCID)
        THROW 52310, N'مركز التكلفة غير موجود.', 1;

    -- المستند المرجعي
    IF @RefDocID IS NOT NULL
    BEGIN
        IF @RT IS NULL THROW 52306, N'هذا النوع لا يقبل مستندًا مرجعيًا.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp AND DocType = @RT AND DocStatus <> 9)
            THROW 52306, N'المستند المرجعي غير صحيح (غير موجود أو نوعه لا يناسب أو ملغى أو لا يتبع الشركة).', 1;
    END

    -- دور الجهة (خيار الشركة WsEnforcePartyRole)
    IF @PartyID IS NOT NULL AND ISNULL((SELECT WsEnforcePartyRole FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1) = 1
    BEGIN
        IF @Type IN (3, 4, 6) AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtRole IN (1, 3))
            THROW 52901, N'هذا النوع يقبل مورّدًا أو موظف عهدة فقط.', 1;
        IF @Type IN (10, 11, 12) AND @RefDocID IS NOT NULL
           AND ISNULL((SELECT DocPartyID FROM dbo.Wrh_Doc WHERE DocID = @RefDocID), 0) <> @PartyID
            THROW 52902, N'يجب أن تكون الجهة هي نفس جهة المستند الأصلي.', 1;
    END

    -- البنود
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52303, N'بنود المستند غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6),
                     RefLineID BIGINT, Factor DECIMAL(18,6), BaseQty DECIMAL(18,3));

    INSERT #L (Ord, ItemID, UnitID, Qty, Price, RefLineID)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price, j.RefLineID
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID',
                                          Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price',
                                          RefLineID BIGINT '$.RefLineID') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) THROW 52303, N'يجب أن يحتوي المستند على بند واحد على الأقل.', 1;
    IF EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty <= 0 OR Price < 0)
        THROW 52303, N'كل بند يحتاج صنفًا ووحدة وكمية أكبر من صفر وسعرًا غير سالب.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS
               (SELECT 1 FROM dbo.Wrh_Item AS i WHERE i.ItemID = l.ItemID AND i.ItemCmpID = @Cmp AND i.ItemActive = 1))
        THROW 52303, N'صنف غير موجود أو معطّل أو لا يتبع الشركة.', 1;

    -- أصناف الطلب (طلب مواد / طلب شراء) تخص مجموعات المخزن؛ والمخزن الذي لا ربط له بعد يبقى بلا قيد
    IF @Type IN (1, 2) AND @WhID IS NOT NULL
       AND EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwWhID = @WhID)
       AND EXISTS (SELECT 1 FROM #L AS l JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
                   WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse AS gw WHERE gw.GwGrpID = i.ItemGrpID AND gw.GwWhID = @WhID))
        THROW 52231, N'يوجد صنف لا يتبع مجموعات هذا المخزن.', 1;

    UPDATE l
       SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l
      JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL)
        THROW 52304, N'وحدة غير معرّفة لهذا الصنف (ليست الأساس ولا ثانوية بمعامل تحويل).', 1;
    UPDATE #L SET BaseQty = ROUND(Qty * Factor, 3);
    IF EXISTS (SELECT 1 FROM #L WHERE BaseQty <= 0) THROW 52303, N'الكمية بالوحدة الأساس تساوي صفرًا.', 1;

    -- ربط البنود بالمرجع
    IF @RefDocID IS NOT NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM #L AS l WHERE l.RefLineID IS NULL OR NOT EXISTS
                   (SELECT 1 FROM dbo.Wrh_DocLine AS r WHERE r.LineID = l.RefLineID AND r.DocID = @RefDocID AND r.ItemID = l.ItemID))
            THROW 52306, N'كل بند يجب أن يرتبط ببند من المستند المرجعي ولنفس الصنف.', 1;
    END
    ELSE IF EXISTS (SELECT 1 FROM #L WHERE RefLineID IS NOT NULL)
        THROW 52306, N'لا يجوز ربط بند بمرجع دون تحديد المستند المرجعي.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveDoc;

    BEGIN TRY
        DECLARE @OldRef BIGINT = NULL, @DocNo NVARCHAR(10), @Year INT = YEAR(@Date), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo, @OldRef = DocRefDocID
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;

            IF @OType IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52301, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52312, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
                THROW 52305, N'لا يجوز تعديل مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

            EXEC dbo.Wrh_StockReverse @DocID;   -- يعكس أثر المخزون القديم
            -- تراجع أثر الربط القديم ثم حذف البنود القديمة
            UPDATE r SET QtyReferred = r.QtyReferred - s.q
              FROM dbo.Wrh_DocLine AS r
              JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;
            DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;

            UPDATE dbo.Wrh_Doc
               SET DocDate = @Date, DocWhID = @WhID, DocWh2ID = @Wh2ID, DocPartyID = @PartyID,
                   DocCostCID = @CostCID, DocRefDocID = @RefDocID, DocNotes = @Notes
             WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocWh2ID,
                                DocPartyID, DocCostCID, DocRefDocID, DocNotes, DocCreatedBy)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, CASE WHEN @Class = 1 THEN 1 ELSE 3 END, @WhID, @Wh2ID,
                    @PartyID, @CostCID, @RefDocID, @Notes, @User);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_DocLine (DocID, DocLineNo, ItemID, UnitID, Factor, Qty, BaseQty, UnitPrice, Amount, RefLineID)
        SELECT @DocID, ROW_NUMBER() OVER (ORDER BY l.Ord), l.ItemID, l.UnitID, l.Factor, l.Qty, l.BaseQty, l.Price,
               CAST(ROUND(l.Qty * ISNULL(l.Price, 0), 3) AS DECIMAL(18,3)), l.RefLineID
        FROM #L AS l;

        -- أثر الربط الجديد (مع التحقق من المتبقي)
        IF EXISTS (SELECT 1
                   FROM (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
                   JOIN dbo.Wrh_DocLine AS r WITH (UPDLOCK) ON r.LineID = s.RefLineID
                   WHERE r.BaseQty - r.QtyReferred - r.QtyCancelled < s.q)
            THROW 52306, N'الكمية تتجاوز المتبقي في البند المرجعي.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred + s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
            ON s.RefLineID = r.LineID;

        EXEC dbo.Wrh_StockApply @DocID;     -- أثر المخزون الجديد

        EXEC dbo.Wrh_RecalcDocStatus @RefDocID;
        IF @OldRef IS NOT NULL AND ISNULL(@OldRef, 0) <> ISNULL(@RefDocID, 0)
            EXEC dbo.Wrh_RecalcDocStatus @OldRef;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo, d.DocStatus FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveDoc;
        THROW;
    END CATCH
END;
GO

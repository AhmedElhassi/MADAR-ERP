/* اختبار المرحلة 15: ربط المجموعات بالمخازن — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_SelectWhItems') IS NULL THROW 52900, N'نفّذ Wrh_15_GroupWarehouses.sql أولًا', 1;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #G (A BIGINT, B NVARCHAR(30), C NVARCHAR(200));
CREATE TABLE #I (A BIGINT, B NVARCHAR(30), C NVARCHAR(200), D BIGINT, E NVARCHAR(200), F BIGINT, G NVARCHAR(200));
CREATE TABLE #M (A BIGINT, B NVARCHAR(MAX), C NVARCHAR(MAX));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @W1 BIGINT, @W2 BIGINT, @W3 BIGINT, @A BIGINT, @A1 BIGINT, @A2 BIGINT, @B BIGINT, @u1 BIGINT, @I1 BIGINT, @I2 BIGINT, @I3 BIGINT;
DECLARE @n INT, @e INT, @s NVARCHAR(100), @L NVARCHAR(MAX), @cb NVARCHAR(30);
IF @C IS NULL OR @U IS NULL OR @CC IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ربط 1';
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ربط 2';
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ربط 3';
    SELECT @W1 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ربط 1';
    SELECT @W2 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ربط 2';
    SELECT @W3 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ربط 3';

    -- مجموعات: A رئيسية بفرعين A1 و A2، و B رئيسية بلا فروع
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة ربط A';
    SELECT @A = GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة ربط A';
    SET @s = CAST(@W1 AS NVARCHAR(20));
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @A, N'', N'فرع ربط A1', NULL, 1, @s;
    SET @s = CAST(@W2 AS NVARCHAR(20));
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @A, N'', N'فرع ربط A2', NULL, 1, @s;
    SET @s = CONCAT(@W1, N',', @W3);
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة ربط B', NULL, 1, @s;
    SELECT @A1 = GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'فرع ربط A1';
    SELECT @A2 = GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'فرع ربط A2';
    SELECT @B  = GrpID, @cb = GrpCode FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة ربط B';

    SELECT @n = COUNT(*) FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @B AND GwWhID IN (@W1, @W3);
    INSERT @R VALUES (N'P1 ربط المجموعة بمخزنين', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- تعديل: استبدال الربط
    SET @s = CAST(@W3 AS NVARCHAR(20));
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @B, NULL, @cb, N'مجموعة ربط B', NULL, 1, @s;
    SELECT @n = COUNT(*) FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @B;
    INSERT @R VALUES (N'P2 الاستبدال يحذف القديم', CASE WHEN @n = 1 AND EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @B AND GwWhID = @W3) THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SET @s = CONCAT(@W1, N',', @W3);
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @B, NULL, @cb, N'مجموعة ربط B', NULL, 1, @s;   -- أعدها إلى W1,W3

    -- NULL لا يمس الربط
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @B, NULL, @cb, N'مجموعة ربط B', NULL, 1;
    SELECT @n = COUNT(*) FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @B;
    INSERT @R VALUES (N'P3 NULL لا يمس الربط', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- أخطاء: فارغ، ومخزن غريب
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemGroup @C, @U, @B, NULL, @cb, N'مجموعة ربط B', NULL, 1, N''; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P4 قائمة مخازن فارغة مرفوضة', CASE WHEN @e = 52230 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveItemGroup @C, @U, @B, NULL, @cb, N'مجموعة ربط B', NULL, 1, N'999999999'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P5 مخزن غير موجود مرفوض', CASE WHEN @e = 52230 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SELECT @n = COUNT(*) FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @B;
    INSERT @R VALUES (N'P6 الخطأ لا يغيّر الربط', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- أصناف: I1 في A1، I2 في A2، I3 في B
    EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة ربط';
    SELECT @u1 = UnitID FROM dbo.Wrh_Unit WHERE UnitCmpID = @C AND UnitName = N'وحدة ربط';
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @A1, N'', N'صنف ربط 1', @u1;
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @A2, N'', N'صنف ربط 2', @u1;
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @B,  N'', N'صنف ربط 3', @u1;
    SELECT @I1 = ItemID FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف ربط 1';
    SELECT @I2 = ItemID FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف ربط 2';
    SELECT @I3 = ItemID FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف ربط 3';

    -- قوائم الكمبو
    DELETE #G; INSERT #G EXEC dbo.Wrh_SelectWhMainGroups @C, @W1;
    SELECT @n = COUNT(*) FROM #G WHERE A IN (@A, @B);
    INSERT @R VALUES (N'Q1 رئيسيات المخزن 1 (A بفرعها، B)', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #G; INSERT #G EXEC dbo.Wrh_SelectWhMainGroups @C, @W2;
    SELECT @n = COUNT(*) FROM #G WHERE A = @A; SELECT @e = COUNT(*) FROM #G WHERE A = @B;
    INSERT @R VALUES (N'Q2 رئيسيات المخزن 2 (A فقط)', CASE WHEN @n = 1 AND @e = 0 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @e));
    DELETE #G; INSERT #G EXEC dbo.Wrh_SelectWhSubGroups @C, @W1, @A;
    SELECT @n = COUNT(*) FROM #G WHERE A = @A1; SELECT @e = COUNT(*) FROM #G WHERE A = @A2;
    INSERT @R VALUES (N'Q3 فروع A في المخزن 1 (A1 فقط)', CASE WHEN @n = 1 AND @e = 0 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @e));

    DELETE #I; INSERT #I EXEC dbo.Wrh_SelectWhItems @C, @W1, NULL, NULL, NULL;
    SELECT @n = COUNT(*) FROM #I WHERE A IN (@I1, @I3); SELECT @e = COUNT(*) FROM #I WHERE A = @I2;
    INSERT @R VALUES (N'R1 أصناف المخزن 1 بلا تصفية', CASE WHEN @n = 2 AND @e = 0 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @e));
    DELETE #I; INSERT #I EXEC dbo.Wrh_SelectWhItems @C, @W1, @A, NULL, NULL;
    SELECT @n = COUNT(*) FROM #I WHERE A = @I1; SELECT @e = COUNT(*) FROM #I WHERE A = @I3;
    INSERT @R VALUES (N'R2 الرئيسية A تشمل فرعها فقط', CASE WHEN @n = 1 AND @e = 0 THEN 1 ELSE 0 END, CONCAT(@n, N'/', @e));
    DELETE #I; INSERT #I EXEC dbo.Wrh_SelectWhItems @C, @W1, @A, @A1, NULL;
    SELECT @n = COUNT(*) FROM #I WHERE A = @I1;
    INSERT @R VALUES (N'R3 الفرع المختار', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #I; INSERT #I EXEC dbo.Wrh_SelectWhItems @C, @W1, @A, @A2, NULL;
    SELECT @n = COUNT(*) FROM #I;
    INSERT @R VALUES (N'R4 فرع غير مرتبط بالمخزن فارغ', CASE WHEN @n = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #I; INSERT #I EXEC dbo.Wrh_SelectWhItems @C, @W3, @B, NULL, N'ربط 3';
    SELECT @n = COUNT(*) FROM #I WHERE A = @I3;
    INSERT @R VALUES (N'R5 مجموعة بلا فروع + بحث', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- صفحة المجموعات
    DELETE #M; INSERT #M EXEC dbo.Wrh_SelectGroupWarehouses @C;
    SELECT @n = COUNT(*) FROM #M WHERE A = @B AND B = CONCAT(@W1, N',', @W3) AND C LIKE N'%مخزن ربط 1%' AND C LIKE N'%مخزن ربط 3%';
    INSERT @R VALUES (N'S1 مخازن المجموعة (معرّفات وأسماء)', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- الطلبات: المخزن 1 له ربط، فصنف I2 (في فرع للمخزن 2) مرفوض
    SET @L = CONCAT(N'[{"ItemID":', @I2, N',"UnitID":', @u1, N',"Qty":1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, '2031-09-01', @W1, NULL, NULL, @CC, NULL, N'ط', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T1 طلب بصنف خارج مجموعات المخزن مرفوض', CASE WHEN @e = 52231 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, '2031-09-01', @W1, NULL, NULL, @CC, NULL, N'ط', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T2 طلب بصنف من مجموعات المخزن ينجح', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":1}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, '2031-09-01', @W2, NULL, NULL, @CC, NULL, N'ط', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'T3 المخزن 2 لا يقبل صنف المخزن 1', CASE WHEN @e = 52231 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

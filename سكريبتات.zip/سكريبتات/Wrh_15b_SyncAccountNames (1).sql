/* =====================================================================
   مطابقة أسماء الحسابات الآلية مع أسماء أصحابها (مرة واحدة).
   حسابات النظام فقط (لها قاعدة في Acc_PostingRule بحالة 1)، وبعدها تتولى الحفظات المزامنة.
   يعدّل عبر Acc_UpdaeAccounting فيُسجَّل في تاريخ الحساب باسم @User أدناه.
   غيّر @User إلى رقم المستخدم المطلوب تسجيل التعديل باسمه إن أردت.
   ===================================================================== */
USE [MADARERPDataBase];
SET NOCOUNT ON;
DECLARE @User BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @Cmp INT, @Acc BIGINT, @Name NVARCHAR(500), @Src NVARCHAR(20), @n INT = 0;

DECLARE c CURSOR LOCAL STATIC FOR
    SELECT N'مورد', p.PrtCmpID, p.PrtAccID, p.PrtName
    FROM dbo.Prt_Party AS p JOIN dbo.Acc_Account AS a ON a.AccID = p.PrtAccID
    WHERE a.AccName <> p.PrtName AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule r WHERE r.AccID = p.PrtAccID AND r.StateID = 1)
    UNION ALL
    SELECT N'مخزن', w.WhCmpID, w.WhAccID, w.WhName
    FROM dbo.Wrh_Warehouse AS w JOIN dbo.Acc_Account AS a ON a.AccID = w.WhAccID
    WHERE a.AccName <> w.WhName AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule r WHERE r.AccID = w.WhAccID AND r.StateID = 1)
    UNION ALL
    SELECT N'مجموعة', g.GrpCmpID, g.GrpAccID, g.GrpName
    FROM dbo.Wrh_ItemGroup AS g JOIN dbo.Acc_Account AS a ON a.AccID = g.GrpAccID
    WHERE a.AccName <> g.GrpName AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule r WHERE r.AccID = g.GrpAccID AND r.StateID = 1);
OPEN c; FETCH NEXT FROM c INTO @Src, @Cmp, @Acc, @Name;
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC dbo.Acc_UpdaeAccounting @Name, @Acc, @User, @Cmp;
    SET @n += 1;
    PRINT CONCAT(@Src, N' -> ', @Name);
    FETCH NEXT FROM c INTO @Src, @Cmp, @Acc, @Name;
END
CLOSE c; DEALLOCATE c;
SELECT @n AS AccountsRenamed;

﻿-- المرحلة 16: حساب المصروف للمجموعة الرئيسية فقط
SET NOCOUNT ON;
GO
CREATE OR ALTER PROCEDURE dbo.Wrh_SaveItemGroup
    @Cmp INT, @User BIGINT, @GrpID BIGINT, @ParentID BIGINT = NULL, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Active BIT = 1, @Whs NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@GrpID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @gn INT = ISNULL((SELECT MAX(TRY_CAST(GrpCode AS INT)) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @gn), CASE WHEN LEN(CAST(@gn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@gn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المجموعة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpCode = @Code AND GrpID <> ISNULL(@GrpID, 0))
        THROW 52204, N'كود المجموعة مستخدم من قبل.', 1;

    -- الأب: للشركة نفسها، لا يحمل أصنافًا، ولا حلقة
    IF @ParentID IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID AND GrpCmpID = @Cmp)
            THROW 52207, N'المجموعة الأب غير موجودة أو لا تتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemGrpID = @ParentID)
            THROW 52207, N'المجموعة الأب تحمل أصنافًا فلا تقبل مجموعات فرعية.', 1;
        IF ISNULL(@GrpID, 0) > 0
        BEGIN
            DECLARE @Cyc INT = 0;
            ;WITH D AS
            (
                SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID
                UNION ALL
                SELECT g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN D ON g.GrpParentID = D.GrpID
            )
            SELECT @Cyc = COUNT(*) FROM D WHERE GrpID = @ParentID;
            IF @Cyc > 0 THROW 52207, N'لا يجوز جعل المجموعة أبًا لنفسها أو لأحد فروعها.', 1;
        END
    END

    -- مخازن المجموعة: NULL = لا يُمسّ الربط؛ وإن مُرّرت فيجب أن يوجد مخزن واحد صحيح على الأقل
    DECLARE @W TABLE (WhID BIGINT PRIMARY KEY);
    IF @Whs IS NOT NULL
    BEGIN
        INSERT @W SELECT DISTINCT TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) FROM STRING_SPLIT(@Whs, N',')
                  WHERE TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) IS NOT NULL;
        IF NOT EXISTS (SELECT 1 FROM @W) THROW 52230, N'مخزن واحد على الأقل مطلوب للمجموعة.', 1;
        IF EXISTS (SELECT 1 FROM @W AS x WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = x.WhID AND WhCmpID = @Cmp))
            THROW 52230, N'مخزن غير موجود أو لا يتبع الشركة.', 1;
    END

    DECLARE @Started BIT = 0, @New BIGINT, @Cur BIGINT, @PAcc BIGINT, @PName NVARCHAR(200), @IsNew BIT = 0;
    IF ISNULL(@GrpID, 0) <> 0
    BEGIN
        SELECT @Cur = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveItemGroup;
    BEGIN TRY
        -- حساب المصروف آلي (عملية 15 مواد تشغيل) إن لم يُمرَّر ولم يكن للمجموعة حساب
        IF @ParentID IS NOT NULL
        BEGIN
            -- فرعية: تستعمل حساب الأب (يُنشأ للأب إن لم يوجد)
            SELECT @PAcc = GrpAccID, @PName = GrpName FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID;
            IF @PAcc IS NULL
            BEGIN
                EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 15, @PName, @New OUTPUT;
                UPDATE dbo.Wrh_ItemGroup SET GrpAccID = @New WHERE GrpID = @ParentID;
                SET @PAcc = @New;
            END
            SET @AccID = @PAcc;
        END
        ELSE IF @AccID IS NULL AND @Cur IS NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 15, @Name, @New OUTPUT;
            SET @AccID = @New;
        END
        IF ISNULL(@GrpID, 0) = 0
        BEGIN
            INSERT dbo.Wrh_ItemGroup (GrpCmpID, GrpParentID, GrpCode, GrpName, GrpAccID, GrpActive)
            VALUES (@Cmp, @ParentID, @Code, @Name, @AccID, ISNULL(@Active, 1));
            SET @GrpID = SCOPE_IDENTITY(); SET @IsNew = 1;
        END
        ELSE
        BEGIN
            UPDATE dbo.Wrh_ItemGroup
               SET GrpParentID = @ParentID, GrpCode = @Code, GrpName = @Name, GrpAccID = CASE WHEN @ParentID IS NOT NULL THEN @AccID ELSE COALESCE(@AccID, GrpAccID) END, GrpActive = ISNULL(@Active, 1)
             WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
            -- مزامنة اسم حساب النظام مع اسم المجموعة
            IF @ParentID IS NULL AND @Cur IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @Cur AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @Cur AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @Cur, @User, @Cmp;
        END
        IF @Whs IS NOT NULL
        BEGIN
            DELETE dbo.Wrh_GroupWarehouse WHERE GwGrpID = @GrpID AND GwWhID NOT IN (SELECT WhID FROM @W);
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT @GrpID, WhID FROM @W AS x
            WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @GrpID AND GwWhID = x.WhID);
        END
        -- تغيير مخازن الرئيسية يسري على فروعها (الفرع يتبع أباه)
        IF @Whs IS NOT NULL AND @ParentID IS NULL
        BEGIN
            DELETE l FROM dbo.Wrh_GroupWarehouse AS l JOIN dbo.Wrh_ItemGroup AS c ON c.GrpID = l.GwGrpID
             WHERE c.GrpParentID = @GrpID AND l.GwWhID NOT IN (SELECT WhID FROM @W);
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT c.GrpID, w.WhID FROM dbo.Wrh_ItemGroup AS c CROSS JOIN @W AS w
             WHERE c.GrpParentID = @GrpID
               AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = c.GrpID AND GwWhID = w.WhID);
        END
        -- فرعية جديدة بلا مخازن مُمرَّرة: تنسخ روابط الأب
        IF @Whs IS NULL AND @IsNew = 1 AND @ParentID IS NOT NULL
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT @GrpID, GwWhID FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @ParentID;
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveItemGroup;
        THROW;
    END CATCH
    SELECT @GrpID AS GrpID;
END;
GO
PRINT N'Wrh_16 تم';

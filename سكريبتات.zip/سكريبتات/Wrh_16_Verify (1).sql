﻿/* اختبار المرحلة 16: حساب المجموعة للرئيسية فقط — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM sys.sql_modules WHERE object_id = OBJECT_ID(N'dbo.Wrh_SaveItemGroup') AND definition LIKE N'%@PAcc%')
    THROW 52900, N'نفّذ Wrh_16_GroupAccounts.sql أولًا', 1;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @W1 BIGINT, @P BIGINT, @P2 BIGINT, @K BIGINT, @K2 BIGINT, @aP BIGINT, @aP2 BIGINT, @aK BIGINT, @cK NVARCHAR(30), @cP NVARCHAR(30), @n INT, @s NVARCHAR(50), @nm NVARCHAR(200);
IF @C IS NULL OR @U IS NULL OR @CC IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ح16';
    SELECT @W1 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ح16';
    SET @s = CAST(@W1 AS NVARCHAR(20));

    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'رئيسية ح16', NULL, 1, @s;
    SELECT @P = GrpID, @aP = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'رئيسية ح16';
    INSERT @R VALUES (N'Q1 الرئيسية لها حساب', CASE WHEN @aP IS NOT NULL THEN 1 ELSE 0 END, CONCAT(N'acc ', @aP));

    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @P, N'', N'فرعية ح16';
    SELECT @K = GrpID, @aK = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'فرعية ح16';
    INSERT @R VALUES (N'Q2 الفرعية تستعمل حساب الأب', CASE WHEN @aK = @aP THEN 1 ELSE 0 END, CONCAT(N'k ', @aK, N' p ', @aP));

    SELECT @n = COUNT(*) FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @K AND GwWhID = @W1;
    INSERT @R VALUES (N'Q3 الفرعية تنسخ مخازن الأب', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- تعديل اسم الفرعية لا يمس اسم حساب الأب
    SELECT @cK = GrpCode FROM dbo.Wrh_ItemGroup WHERE GrpID = @K;
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @K, @P, @cK, N'فرعية ح16 معدلة';
    SELECT @nm = AccName FROM dbo.Acc_Account WHERE AccID = @aP;
    INSERT @R VALUES (N'Q4 اسم حساب الأب لم يتغير', CASE WHEN @nm = N'رئيسية ح16' THEN 1 ELSE 0 END, CONCAT(N'name ', @nm));

    -- تعديل اسم الرئيسية يعدّل حسابها
    SELECT @cP = GrpCode FROM dbo.Wrh_ItemGroup WHERE GrpID = @P;
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @P, NULL, @cP, N'رئيسية ح16 معدلة';
    SELECT @nm = AccName FROM dbo.Acc_Account WHERE AccID = @aP;
    INSERT @R VALUES (N'Q5 اسم الرئيسية يزامن الحساب', CASE WHEN @nm = N'رئيسية ح16 معدلة' THEN 1 ELSE 0 END, CONCAT(N'name ', @nm));

    -- نقل الفرعية إلى أب آخر يغيّر حسابها
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'رئيسية ح16 ثانية', NULL, 1, @s;
    SELECT @P2 = GrpID, @aP2 = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'رئيسية ح16 ثانية';
    EXEC dbo.Wrh_SaveItemGroup @C, @U, @K, @P2, @cK, N'فرعية ح16 معدلة';
    SELECT @aK = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpID = @K;
    INSERT @R VALUES (N'Q6 النقل يغيّر الحساب لحساب الأب الجديد', CASE WHEN @aK = @aP2 AND @aP2 <> @aP THEN 1 ELSE 0 END, CONCAT(N'k ', @aK, N' p2 ', @aP2));

    -- أب بلا حساب (قديم): الفرعية تنشئ له حسابًا
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'رئيسية ح16 ثالثة', NULL, 1, @s;
    DECLARE @P3 BIGINT = (SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'رئيسية ح16 ثالثة');
    UPDATE dbo.Wrh_ItemGroup SET GrpAccID = NULL WHERE GrpID = @P3;
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, @P3, N'', N'فرعية ح16 ثالثة';
    SELECT @aP = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpID = @P3;
    SELECT @aK = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'فرعية ح16 ثالثة';
    INSERT @R VALUES (N'Q7 أب بلا حساب ينشأ له حساب', CASE WHEN @aP IS NOT NULL AND @aK = @aP THEN 1 ELSE 0 END, CONCAT(N'p ', @aP, N' k ', @aK));
    ROLLBACK;
END
SELECT Nm, Ok, Info FROM @R WHERE Ok = 0
UNION ALL SELECT N'المجموع', CASE WHEN SUM(CAST(Ok AS INT)) = COUNT(*) THEN 1 ELSE 0 END, CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*)) FROM @R;

﻿/* =====================================================================
   المرحلة 17: دورة طلب المواد (الحامل والإرجاع والإحالة) + قفل المخزن
   DocFlow (لطلب المواد فقط): 0 مسودة  1 عند المخزن  2 عند المشتريات  3 معاد للجهة الطالبة  4 معاد للمخزن بانتظار القبول
   الحالة المالية DocStatus تبقى 1/2/3/9 كما هي (منفذ جزئيًا/كليًا/ملغى)؛ المكان الحالي من DocFlow.
   Wrh_RequestAction(@Cmp,@User,@DocID,@Action,@Reason):
     1 إرسال (0←1)   2 إحالة المتبقي للمشتريات (1←2)   3 إرجاع للجهة الطالبة (1 أو 2 ←3، بسبب)
     4 إرجاع من المشتريات للمخزن (2←4، بسبب)   5 قبول المخزن (4←1)   6 رفض المخزن (4←2، بسبب)
     7 إعادة إرسال من الجهة الطالبة (3←1)   8 إلغاء المتبقي من الجهة الطالبة (3، بسبب)
   أخطاء جديدة: 52320 طلب مرسل لا يُعدَّل  52321 مخزن الطلب لا يتغير  52322 الصرف من طلب ليس عند المخزن
                52323 طلب الشراء من طلب ليس عند المشتريات  52324 إجراء غير مسموح في هذه المرحلة  52325 لا متبقٍ  52326 سبب مطلوب
   أحداث السجل EvKind: 11..17 = 10 + رقم الإجراء (الإلغاء 4 كما في Wrh_CancelDoc).
   ===================================================================== */
USE [MADARERPDataBase];
SET NOCOUNT ON;
GO
IF COL_LENGTH(N'dbo.Wrh_Doc', N'DocFlow') IS NULL
    ALTER TABLE dbo.Wrh_Doc ADD DocFlow TINYINT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Wrh_Doc_Flow')
    ALTER TABLE dbo.Wrh_Doc ADD CONSTRAINT CK_Wrh_Doc_Flow CHECK (DocFlow IS NULL OR DocFlow BETWEEN 0 AND 4);
GO
-- مخزن الطلب إلزامي، والطلبات الموجودة تُعتبر عند المخزن
UPDATE dbo.Wrh_DocTypeDef SET DtNeedWh = 1 WHERE DtType = 1;
GO
UPDATE dbo.Wrh_Doc SET DocFlow = 1 WHERE DocType = 1 AND DocFlow IS NULL;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_SaveDoc
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Type TINYINT, @Date DATE,
    @WhID BIGINT = NULL, @Wh2ID BIGINT = NULL, @PartyID BIGINT = NULL, @CostCID BIGINT = NULL,
    @RefDocID BIGINT = NULL, @Notes NVARCHAR(500) = NULL, @Lines NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    IF ISNULL(@Cmp, 0) <= 0 OR @Date IS NULL THROW 52302, N'الشركة والتاريخ مطلوبان.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;

    DECLARE @Class TINYINT, @NW BIT, @NW2 BIT, @NP BIT, @NC BIT, @NR BIT, @RT TINYINT;
    SELECT @Class = DtClass, @NW = DtNeedWh, @NW2 = DtNeedWh2, @NP = DtNeedParty, @NC = DtNeedCost,
           @NR = DtNeedRef, @RT = DtRefType
    FROM dbo.Wrh_DocTypeDef WHERE DtType = @Type AND DtEngine = 1;
    IF @Class IS NULL THROW 52301, N'نوع المستند غير صحيح أو غير مدعوم في هذا المحرك.', 1;

    -- متطلبات الرأس
    IF @NW = 1 AND @WhID IS NULL THROW 52302, N'المخزن مطلوب لهذا النوع.', 1;
    IF @NW2 = 1 AND @Wh2ID IS NULL THROW 52302, N'المخزن المقابل مطلوب لهذا النوع.', 1;
    IF @NP = 1 AND @PartyID IS NULL THROW 52302, N'الجهة (المورد/العهدة) مطلوبة لهذا النوع.', 1;
    IF @NC = 1 AND @CostCID IS NULL THROW 52302, N'الجهة الطالبة (مركز التكلفة) مطلوبة لهذا النوع.', 1;
    IF @NR = 1 AND @RefDocID IS NULL THROW 52302, N'المستند المرجعي مطلوب لهذا النوع.', 1;

    IF @WhID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @Wh2ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = @Wh2ID AND WhCmpID = @Cmp AND WhActive = 1)
        THROW 52310, N'المخزن المقابل غير موجود أو معطّل أو لا يتبع الشركة.', 1;
    IF @WhID IS NOT NULL AND @Wh2ID IS NOT NULL AND @WhID = @Wh2ID
        THROW 52310, N'المخزنان في التحويل يجب أن يكونا مختلفين.', 1;
    IF @PartyID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtCmpID = @Cmp AND PrtActive = 1)
        THROW 52310, N'الجهة غير موجودة أو معطّلة أو لا تتبع الشركة.', 1;
    IF @CostCID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter WHERE CsCID = @CostCID)
        THROW 52310, N'مركز التكلفة غير موجود.', 1;

    -- المستند المرجعي
    IF @RefDocID IS NOT NULL
    BEGIN
        IF @RT IS NULL THROW 52306, N'هذا النوع لا يقبل مستندًا مرجعيًا.', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocCmpID = @Cmp AND DocType = @RT AND DocStatus <> 9)
            THROW 52306, N'المستند المرجعي غير صحيح (غير موجود أو نوعه لا يناسب أو ملغى أو لا يتبع الشركة).', 1;
    END

    -- دورة طلب المواد: الصرف من الطلب وهو عند المخزن ومن مخزنه، وطلب الشراء منه وهو عند المشتريات (عند الإدخال فقط)
    IF ISNULL(@DocID, 0) = 0 AND @RefDocID IS NOT NULL
    BEGIN
        IF @Type = 5 AND EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocType = 1
                                 AND (ISNULL(DocFlow, 1) <> 1 OR ISNULL(DocWhID, 0) <> ISNULL(@WhID, 0)))
            THROW 52322, N'الصرف من الطلب يكون وهو عند المخزن وفي مخزن الطلب نفسه.', 1;
        IF @Type = 2 AND EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @RefDocID AND DocType = 1 AND ISNULL(DocFlow, 2) <> 2)
            THROW 52323, N'طلب الشراء من طلب المواد يكون وهو عند المشتريات.', 1;
    END

    -- دور الجهة (خيار الشركة WsEnforcePartyRole)
    IF @PartyID IS NOT NULL AND ISNULL((SELECT WsEnforcePartyRole FROM dbo.Wrh_Settings WHERE WsCmpID = @Cmp), 1) = 1
    BEGIN
        IF @Type IN (3, 4, 6) AND NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtID = @PartyID AND PrtRole IN (1, 3))
            THROW 52901, N'هذا النوع يقبل مورّدًا أو موظف عهدة فقط.', 1;
        IF @Type IN (10, 11, 12) AND @RefDocID IS NOT NULL
           AND ISNULL((SELECT DocPartyID FROM dbo.Wrh_Doc WHERE DocID = @RefDocID), 0) <> @PartyID
            THROW 52902, N'يجب أن تكون الجهة هي نفس جهة المستند الأصلي.', 1;
    END

    -- البنود
    IF @Lines IS NULL OR ISJSON(@Lines) <> 1 THROW 52303, N'بنود المستند غير صحيحة.', 1;

    CREATE TABLE #L (Ord INT, ItemID BIGINT, UnitID BIGINT, Qty DECIMAL(18,3), Price DECIMAL(18,6),
                     RefLineID BIGINT, Factor DECIMAL(18,6), BaseQty DECIMAL(18,3));

    INSERT #L (Ord, ItemID, UnitID, Qty, Price, RefLineID)
    SELECT CAST(x.[key] AS INT), j.ItemID, j.UnitID, j.Qty, j.Price, j.RefLineID
    FROM OPENJSON(@Lines) AS x
    CROSS APPLY OPENJSON(x.[value]) WITH (ItemID BIGINT '$.ItemID', UnitID BIGINT '$.UnitID',
                                          Qty DECIMAL(18,3) '$.Qty', Price DECIMAL(18,6) '$.Price',
                                          RefLineID BIGINT '$.RefLineID') AS j;

    IF NOT EXISTS (SELECT 1 FROM #L) THROW 52303, N'يجب أن يحتوي المستند على بند واحد على الأقل.', 1;
    IF EXISTS (SELECT 1 FROM #L WHERE ItemID IS NULL OR UnitID IS NULL OR Qty IS NULL OR Qty <= 0 OR Price < 0)
        THROW 52303, N'كل بند يحتاج صنفًا ووحدة وكمية أكبر من صفر وسعرًا غير سالب.', 1;
    IF EXISTS (SELECT 1 FROM #L AS l WHERE NOT EXISTS
               (SELECT 1 FROM dbo.Wrh_Item AS i WHERE i.ItemID = l.ItemID AND i.ItemCmpID = @Cmp AND i.ItemActive = 1))
        THROW 52303, N'صنف غير موجود أو معطّل أو لا يتبع الشركة.', 1;

    -- أصناف الطلب (طلب مواد / طلب شراء) تخص مجموعات المخزن؛ والمخزن الذي لا ربط له بعد يبقى بلا قيد
    IF @Type IN (1, 2) AND @WhID IS NOT NULL
       AND EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwWhID = @WhID)
       AND EXISTS (SELECT 1 FROM #L AS l JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
                   WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse AS gw WHERE gw.GwGrpID = i.ItemGrpID AND gw.GwWhID = @WhID))
        THROW 52231, N'يوجد صنف لا يتبع مجموعات هذا المخزن.', 1;

    UPDATE l
       SET Factor = CASE WHEN l.UnitID = i.ItemBaseUnitID THEN CAST(1 AS DECIMAL(18,6)) ELSE iu.Factor END
      FROM #L AS l
      JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
      LEFT JOIN dbo.Wrh_ItemUnit AS iu ON iu.ItemID = l.ItemID AND iu.UnitID = l.UnitID;
    IF EXISTS (SELECT 1 FROM #L WHERE Factor IS NULL)
        THROW 52304, N'وحدة غير معرّفة لهذا الصنف (ليست الأساس ولا ثانوية بمعامل تحويل).', 1;
    UPDATE #L SET BaseQty = ROUND(Qty * Factor, 3);
    IF EXISTS (SELECT 1 FROM #L WHERE BaseQty <= 0) THROW 52303, N'الكمية بالوحدة الأساس تساوي صفرًا.', 1;

    -- ربط البنود بالمرجع
    IF @RefDocID IS NOT NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM #L AS l WHERE l.RefLineID IS NULL OR NOT EXISTS
                   (SELECT 1 FROM dbo.Wrh_DocLine AS r WHERE r.LineID = l.RefLineID AND r.DocID = @RefDocID AND r.ItemID = l.ItemID))
            THROW 52306, N'كل بند يجب أن يرتبط ببند من المستند المرجعي ولنفس الصنف.', 1;
    END
    ELSE IF EXISTS (SELECT 1 FROM #L WHERE RefLineID IS NOT NULL)
        THROW 52306, N'لا يجوز ربط بند بمرجع دون تحديد المستند المرجعي.', 1;

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveDoc;

    BEGIN TRY
        DECLARE @OldRef BIGINT = NULL, @DocNo NVARCHAR(10), @Year INT = YEAR(@Date), @Kind TINYINT = 1;

        IF ISNULL(@DocID, 0) > 0
        BEGIN
            DECLARE @OType TINYINT, @OYear SMALLINT, @OWh BIGINT, @OFlow TINYINT;
            SELECT @OType = DocType, @OYear = DocYear, @DocNo = DocNo, @OldRef = DocRefDocID, @OWh = DocWhID, @OFlow = DocFlow
            FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp;

            IF @OType IS NULL THROW 52309, N'المستند غير موجود أو لا يتبع الشركة.', 1;
            IF @OType <> @Type THROW 52301, N'لا يُغيَّر نوع المستند.', 1;
            IF @OYear <> @Year THROW 52312, N'لا يجوز تغيير تاريخ المستند إلى سنة أخرى.', 1;
            IF @OType = 1 AND ISNULL(@OFlow, 1) <> 0 THROW 52320, N'الطلب المُرسَل لا يُعدَّل (ألغِه أو أعد إرساله كما هو).', 1;
            IF @OType = 1 AND ISNULL(@OWh, 0) <> ISNULL(@WhID, 0) THROW 52321, N'لا يُغيَّر مخزن الطلب بعد حفظه؛ احذف المسودة وأنشئ طلبًا جديدًا.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND (QtyReferred > 0 OR QtyCancelled > 0))
                THROW 52305, N'لا يجوز تعديل مستند استُعمل منه شيء في مستند لاحق أو أُلغي منه.', 1;

            EXEC dbo.Wrh_StockReverse @DocID;   -- يعكس أثر المخزون القديم
            -- تراجع أثر الربط القديم ثم حذف البنود القديمة
            UPDATE r SET QtyReferred = r.QtyReferred - s.q
              FROM dbo.Wrh_DocLine AS r
              JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM dbo.Wrh_DocLine
                    WHERE DocID = @DocID AND RefLineID IS NOT NULL GROUP BY RefLineID) AS s ON s.RefLineID = r.LineID;
            DELETE dbo.Wrh_DocLine WHERE DocID = @DocID;

            UPDATE dbo.Wrh_Doc
               SET DocDate = @Date, DocWhID = @WhID, DocWh2ID = @Wh2ID, DocPartyID = @PartyID,
                   DocCostCID = @CostCID, DocRefDocID = @RefDocID, DocNotes = @Notes
             WHERE DocID = @DocID;
            SET @Kind = 2;
        END
        ELSE
        BEGIN
            EXEC dbo.Wrh_NextDocNo @Cmp, @Year, @Type, @DocNo OUTPUT;
            INSERT dbo.Wrh_Doc (DocCmpID, DocType, DocYear, DocNo, DocDate, DocStatus, DocWhID, DocWh2ID,
                                DocPartyID, DocCostCID, DocRefDocID, DocNotes, DocCreatedBy, DocFlow)
            VALUES (@Cmp, @Type, @Year, @DocNo, @Date, CASE WHEN @Class = 1 THEN 1 ELSE 3 END, @WhID, @Wh2ID,
                    @PartyID, @CostCID, @RefDocID, @Notes, @User, CASE WHEN @Type = 1 THEN 0 END);
            SET @DocID = SCOPE_IDENTITY();
        END

        INSERT dbo.Wrh_DocLine (DocID, DocLineNo, ItemID, UnitID, Factor, Qty, BaseQty, UnitPrice, Amount, RefLineID)
        SELECT @DocID, ROW_NUMBER() OVER (ORDER BY l.Ord), l.ItemID, l.UnitID, l.Factor, l.Qty, l.BaseQty, l.Price,
               CAST(ROUND(l.Qty * ISNULL(l.Price, 0), 3) AS DECIMAL(18,3)), l.RefLineID
        FROM #L AS l;

        -- أثر الربط الجديد (مع التحقق من المتبقي)
        IF EXISTS (SELECT 1
                   FROM (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
                   JOIN dbo.Wrh_DocLine AS r WITH (UPDLOCK) ON r.LineID = s.RefLineID
                   WHERE r.BaseQty - r.QtyReferred - r.QtyCancelled < s.q)
            THROW 52306, N'الكمية تتجاوز المتبقي في البند المرجعي.', 1;

        UPDATE r SET QtyReferred = r.QtyReferred + s.q
          FROM dbo.Wrh_DocLine AS r
          JOIN (SELECT RefLineID, SUM(BaseQty) AS q FROM #L WHERE RefLineID IS NOT NULL GROUP BY RefLineID) AS s
            ON s.RefLineID = r.LineID;

        EXEC dbo.Wrh_StockApply @DocID;     -- أثر المخزون الجديد

        EXEC dbo.Wrh_RecalcDocStatus @RefDocID;
        IF @OldRef IS NOT NULL AND ISNULL(@OldRef, 0) <> ISNULL(@RefDocID, 0)
            EXEC dbo.Wrh_RecalcDocStatus @OldRef;

        INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser)
        VALUES (@Cmp, @DocID, @DocNo, @Type, @Kind, @User);

        IF @Started = 1 COMMIT;
        SELECT @DocID AS DocID, @DocNo AS DocNo, d.DocStatus FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveDoc;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.Wrh_RequestAction
    @Cmp INT, @User BIGINT, @DocID BIGINT, @Action TINYINT, @Reason NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 52302, N'المستخدم غير موجود.', 1;
    SET @Reason = NULLIF(LTRIM(RTRIM(@Reason)), N'');

    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_RequestAction;
    BEGIN TRY
        DECLARE @Flow TINYINT, @No NVARCHAR(10), @Status TINYINT, @To TINYINT, @NeedReason BIT, @NeedRem BIT, @Ok BIT = 0;
        SELECT @Flow = DocFlow, @No = DocNo, @Status = DocStatus
        FROM dbo.Wrh_Doc WITH (UPDLOCK, HOLDLOCK) WHERE DocID = @DocID AND DocCmpID = @Cmp AND DocType = 1;
        IF @No IS NULL THROW 52309, N'طلب المواد غير موجود أو لا يتبع الشركة.', 1;

        SELECT @Ok = 1, @To = t.ToFlow, @NeedReason = t.NeedReason, @NeedRem = t.NeedRem
        FROM (VALUES (1,0,1,0,0), (2,1,2,0,1), (3,1,3,1,1), (3,2,3,1,1), (4,2,4,1,1),
                     (5,4,1,0,0), (6,4,2,1,0), (7,3,1,0,1), (8,3,3,1,1)) AS t(Act, FromFlow, ToFlow, NeedReason, NeedRem)
        WHERE t.Act = @Action AND t.FromFlow = ISNULL(@Flow, 255);
        IF @Ok = 0 THROW 52324, N'هذا الإجراء غير مسموح في المرحلة الحالية للطلب.', 1;
        IF @NeedReason = 1 AND @Reason IS NULL THROW 52326, N'السبب مطلوب.', 1;
        IF @Status IN (3, 9) THROW 52325, N'الطلب منتهٍ (منفذ كليًا أو ملغى).', 1;
        IF @NeedRem = 1 AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_DocLine WHERE DocID = @DocID AND BaseQty - QtyReferred - QtyCancelled > 0)
            THROW 52325, N'لا يوجد متبقٍ في الطلب.', 1;

        IF @Action = 8
            EXEC dbo.Wrh_CancelDoc @Cmp, @User, @DocID, NULL, @Reason;   -- يسجّل حدث الإلغاء بنفسه
        ELSE
        BEGIN
            UPDATE dbo.Wrh_Doc SET DocFlow = @To WHERE DocID = @DocID;
            INSERT dbo.Wrh_DocEvent (EvCmpID, EvDocID, EvDocNo, EvDocType, EvKind, EvUser, EvReason)
            VALUES (@Cmp, @DocID, @No, 1, 10 + @Action, @User, @Reason);
        END

        IF @Started = 1 COMMIT;
        SELECT d.DocID, d.DocNo, d.DocStatus, d.DocFlow FROM dbo.Wrh_Doc AS d WHERE d.DocID = @DocID;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_RequestAction;
        THROW;
    END CATCH
END;
GO

-- حذف المسودة فقط (مع الإبقاء على Wrh_DeleteDoc للمحرك)
CREATE OR ALTER PROCEDURE dbo.Wrh_DeleteDraftRequest
    @Cmp INT, @User BIGINT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocCmpID = @Cmp AND DocType = 1)
        THROW 52309, N'طلب المواد غير موجود أو لا يتبع الشركة.', 1;
    IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @DocID AND DocFlow = 0)
        THROW 52324, N'يُحذف الطلب وهو مسودة فقط.', 1;
    EXEC dbo.Wrh_DeleteDoc @Cmp, @User, @DocID, N'حذف مسودة';
END;
GO

-- قوائم الطلبات (الاستفسار + قائمة المخزن/المشتريات/الجهة الطالبة بحسب @Flow)
-- الأعمدة: DocID, DocNo, DocDate, DocWhID, WhName, DocCostCID, CsCName, DocFlow, FlowName, DocStatus, QtyOrdered, QtyIssued(مرجع)، QtyCancelled, QtyRemaining, LastReason, LastAt, DocCreatedBy
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectRequests
    @Cmp INT, @WhID BIGINT = NULL, @Flow TINYINT = NULL, @Status TINYINT = NULL, @CostCID BIGINT = NULL,
    @From DATE = NULL, @To DATE = NULL, @ItemID BIGINT = NULL, @GrpID BIGINT = NULL, @DocNo NVARCHAR(10) = NULL,
    @OnlyRemaining BIT = 0, @CreatedBy BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT d.DocID, d.DocNo, d.DocDate, d.DocWhID, w.WhName, d.DocCostCID, c.CsCName, d.DocFlow,
           CASE d.DocFlow WHEN 0 THEN N'مسودة' WHEN 1 THEN N'عند المخزن' WHEN 2 THEN N'عند المشتريات'
                          WHEN 3 THEN N'معاد للجهة الطالبة' WHEN 4 THEN N'معاد للمخزن بانتظار القبول' END AS FlowName,
           d.DocStatus, q.QtyOrdered, q.QtyIssued, q.QtyCancelled, q.QtyRemaining,
           e.EvReason AS LastReason, e.EvAt AS LastAt, d.DocCreatedBy
    FROM dbo.Wrh_Doc AS d
    JOIN dbo.Wrh_Warehouse AS w ON w.WhID = d.DocWhID
    LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DocCostCID
    CROSS APPLY (SELECT SUM(l.BaseQty) AS QtyOrdered, SUM(l.QtyReferred) AS QtyIssued, SUM(l.QtyCancelled) AS QtyCancelled,
                        SUM(l.BaseQty - l.QtyReferred - l.QtyCancelled) AS QtyRemaining
                 FROM dbo.Wrh_DocLine AS l WHERE l.DocID = d.DocID) AS q
    OUTER APPLY (SELECT TOP 1 ev.EvReason, ev.EvAt FROM dbo.Wrh_DocEvent AS ev
                 WHERE ev.EvDocID = d.DocID AND ev.EvKind >= 11 ORDER BY ev.EvID DESC) AS e
    WHERE d.DocCmpID = @Cmp AND d.DocType = 1
      AND (@WhID IS NULL OR d.DocWhID = @WhID)
      AND (@Flow IS NULL OR d.DocFlow = @Flow)
      AND (@Status IS NULL OR d.DocStatus = @Status)
      AND (@CostCID IS NULL OR d.DocCostCID = @CostCID)
      AND (@From IS NULL OR d.DocDate >= @From) AND (@To IS NULL OR d.DocDate <= @To)
      AND (@DocNo IS NULL OR d.DocNo = @DocNo)
      AND (@CreatedBy IS NULL OR d.DocCreatedBy = @CreatedBy)
      AND (@OnlyRemaining = 0 OR (q.QtyRemaining > 0 AND d.DocStatus IN (1, 2)))
      AND (@ItemID IS NULL OR EXISTS (SELECT 1 FROM dbo.Wrh_DocLine AS l WHERE l.DocID = d.DocID AND l.ItemID = @ItemID))
      AND (@GrpID IS NULL OR EXISTS (SELECT 1 FROM dbo.Wrh_DocLine AS l JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
                                     JOIN dbo.Wrh_ItemGroup AS g ON g.GrpID = i.ItemGrpID
                                     WHERE l.DocID = d.DocID AND (g.GrpID = @GrpID OR g.GrpParentID = @GrpID)))
    ORDER BY d.DocDate DESC, d.DocID DESC;
END;
GO

-- بنود الطلب مع الكميات
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectRequestLines
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT l.LineID, l.DocLineNo, l.ItemID, i.ItemCode, i.ItemName, l.UnitID, u.UnitName, l.Qty, l.BaseQty,
           l.QtyReferred AS QtyIssued, l.QtyCancelled, l.BaseQty - l.QtyReferred - l.QtyCancelled AS QtyRemaining
    FROM dbo.Wrh_DocLine AS l
    JOIN dbo.Wrh_Doc AS d ON d.DocID = l.DocID AND d.DocCmpID = @Cmp AND d.DocType = 1
    JOIN dbo.Wrh_Item AS i ON i.ItemID = l.ItemID
    JOIN dbo.Wrh_Unit AS u ON u.UnitID = l.UnitID
    WHERE l.DocID = @DocID
    ORDER BY l.DocLineNo;
END;
GO

-- سجل مسار الطلب
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectRequestEvents
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT e.EvID, e.EvKind,
           CASE e.EvKind WHEN 1 THEN N'إنشاء مسودة' WHEN 2 THEN N'تعديل' WHEN 4 THEN N'إلغاء المتبقي'
                         WHEN 11 THEN N'إرسال للمخزن' WHEN 12 THEN N'إحالة للمشتريات' WHEN 13 THEN N'إرجاع للجهة الطالبة'
                         WHEN 14 THEN N'إرجاع للمخزن' WHEN 15 THEN N'قبول المخزن' WHEN 16 THEN N'رفض المخزن'
                         WHEN 17 THEN N'إعادة إرسال' ELSE N'حدث' END AS EvName,
           e.EvUser, e.EvAt, e.EvReason
    FROM dbo.Wrh_DocEvent AS e
    WHERE e.EvCmpID = @Cmp AND e.EvDocID = @DocID AND e.EvDocType = 1
    ORDER BY e.EvID;
END;
GO
PRINT N'Wrh_17 تم';

/* اختبار المرحلة 17: دورة طلب المواد — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Wrh_RequestAction') IS NULL THROW 52900, N'نفّذ Wrh_17_RequestFlow.sql أولًا', 1;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #X (A BIGINT, B NVARCHAR(10), C DATE, D BIGINT, E NVARCHAR(400), F BIGINT, G NVARCHAR(400), H TINYINT, I NVARCHAR(60), J TINYINT,
                 K DECIMAL(38,3), L DECIMAL(38,3), M DECIMAL(38,3), N DECIMAL(38,3), O NVARCHAR(400), P DATETIME2(0), Q BIGINT);
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @D DATE = '2031-10-01';
DECLARE @W1 BIGINT, @W2 BIGINT, @A BIGINT, @P BIGINT, @u1 BIGINT, @I1 BIGINT, @s NVARCHAR(50), @L NVARCHAR(MAX);
DECLARE @inv BIGINT, @il BIGINT, @q1 BIGINT, @q2 BIGINT, @q3 BIGINT, @ql BIGINT, @e INT, @n INT, @f TINYINT, @st TINYINT;
DECLARE @iss BIGINT, @pr BIGINT; DECLARE @c1 DECIMAL(18,3), @c2 DECIMAL(18,3);
IF @C IS NULL OR @U IS NULL OR @CC IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ح17 أ';
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ح17 ب';
    SELECT @W1 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ح17 أ';
    SELECT @W2 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ح17 ب';
    SET @s = CAST(@W1 AS NVARCHAR(20));
    EXEC dbo.Wrh_SaveItemGroup @C, @U, 0, NULL, N'', N'مجموعة ح17', NULL, 1, @s;
    SELECT @A = GrpID FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @C AND GrpName = N'مجموعة ح17';
    EXEC dbo.Wrh_SaveUnit @C, @U, 0, N'وحدة ح17';
    SELECT @u1 = UnitID FROM dbo.Wrh_Unit WHERE UnitCmpID = @C AND UnitName = N'وحدة ح17';
    EXEC dbo.Wrh_SaveItem @C, @U, 0, @A, N'', N'صنف ح17', @u1;
    SELECT @I1 = ItemID FROM dbo.Wrh_Item WHERE ItemCmpID = @C AND ItemName = N'صنف ح17';
    EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد ح17', 1;
    SELECT @P = PrtID FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد ح17';

    -- رصيد 100 في المخزن الأول (فاتورة + استلام)
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":100,"Price":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 3, @D, @W1, NULL, @P, NULL, NULL, NULL, @L; SELECT @inv = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 3;
    SELECT @il = LineID FROM dbo.Wrh_DocLine WHERE DocID = @inv;
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":100,"Price":10,"RefLineID":', @il, N'}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 4, @D, @W1, NULL, @P, NULL, @inv, NULL, @L;

    -- S1 إنشاء طلب = مسودة
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":10}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @D, @W1, NULL, NULL, @CC, NULL, N'ط1', @L; SELECT @q1 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 1;
    SELECT @f = DocFlow, @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S1 الطلب الجديد مسودة', CASE WHEN @f = 0 AND @st = 1 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f, N' st ', @st));

    -- S2 تعديل المسودة، S3 تغيير المخزن مرفوض
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":10}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, @q1, 1, @D, @W1, NULL, NULL, @CC, NULL, N'ط1 معدل', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S2 تعديل المسودة يعمل', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, @q1, 1, @D, @W2, NULL, NULL, @CC, NULL, N'ط1', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S3 تغيير المخزن مرفوض', CASE WHEN @e = 52321 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S4 الإرسال ثم S5 لا تعديل ثم S6 لا إرسال مرتين
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 1;
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S4 الإرسال ينقل للمخزن', CASE WHEN @f = 1 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, @q1, 1, @D, @W1, NULL, NULL, @CC, NULL, N'ط1', @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S5 الطلب المرسل لا يُعدَّل', CASE WHEN @e = 52320 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_RequestAction @C, @U, @q1, 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S6 لا إرسال مرتين', CASE WHEN @e = 52324 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S7 صرف جزئي 4 من الطلب وهو عند المخزن
    SELECT @ql = LineID FROM dbo.Wrh_DocLine WHERE DocID = @q1;
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":4,"RefLineID":', @ql, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @D, @W1, NULL, NULL, @CC, @q1, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S7 صرف جزئي من الطلب', CASE WHEN @e = 0 AND @st = 2 THEN 1 ELSE 0 END, CONCAT(N'err ', @e, N' st ', @st));

    -- S8 إحالة المتبقي للمشتريات، S9 لا صرف وهو عند المشتريات
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 2;
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S8 الإحالة للمشتريات', CASE WHEN @f = 2 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":1,"RefLineID":', @ql, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 5, @D, @W1, NULL, NULL, @CC, @q1, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S9 لا صرف من طلب عند المشتريات', CASE WHEN @e = 52322 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S10 طلب شراء من الطلب وهو عند المشتريات (3 من المتبقي 6)
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":3,"RefLineID":', @ql, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 2, @D, NULL, NULL, NULL, NULL, @q1, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S10 طلب شراء من الطلب عند المشتريات', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S11 إرجاع للجهة الطالبة بلا سبب مرفوض، وبسبب ينجح
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_RequestAction @C, @U, @q1, 3; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S11 الإرجاع بلا سبب مرفوض', CASE WHEN @e = 52326 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 3, N'الكمية تغيرت';
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S12 الإرجاع للجهة الطالبة', CASE WHEN @f = 3 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));

    -- S13 إعادة الإرسال تعود للمخزن
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 7;
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S13 إعادة الإرسال للمخزن', CASE WHEN @f = 1 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));

    -- S14 مسار الرفض والقبول: مخزن←مشتريات←(إرجاع للمخزن)←رفض←مشتريات←(إرجاع)←قبول←مخزن
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 2;
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 4, N'أعده للمخزن';
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S14 الإرجاع للمخزن بانتظار القبول', CASE WHEN @f = 4 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_RequestAction @C, @U, @q1, 6; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S15 الرفض بلا سبب مرفوض', CASE WHEN @e = 52326 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 6, N'لا نملك الرصيد';
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S16 الرفض يعيده للمشتريات', CASE WHEN @f = 2 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 4, N'مرة أخرى';
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 5;
    SELECT @f = DocFlow FROM dbo.Wrh_Doc WHERE DocID = @q1;
    INSERT @R VALUES (N'S17 القبول يعيده للمخزن', CASE WHEN @f = 1 THEN 1 ELSE 0 END, CONCAT(N'flow ', @f));

    -- S18 إرجاع من المخزن للجهة الطالبة ثم إلغاء المتبقي (طلب 10: صُرف 4 وأُحيل للشراء 3 ← يُلغى 3)
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 3, N'لم يعد مطلوبًا';
    EXEC dbo.Wrh_RequestAction @C, @U, @q1, 8, N'لم يعد مطلوبًا';
    SELECT @st = DocStatus FROM dbo.Wrh_Doc WHERE DocID = @q1;
    SELECT @c1 = QtyCancelled FROM dbo.Wrh_DocLine WHERE DocID = @q1;
    INSERT @R VALUES (N'S18 إلغاء المتبقي يُنهي الطلب', CASE WHEN @st = 3 AND @c1 = 3 THEN 1 ELSE 0 END, CONCAT(N'st ', @st, N' cancelled ', @c1));
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_RequestAction @C, @U, @q1, 7; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S19 لا إجراء على طلب منتهٍ', CASE WHEN @e = 52325 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S20 حذف المسودة فقط
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":2}]');
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @D, @W1, NULL, NULL, @CC, NULL, N'ط2', @L; SELECT @q2 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 1;
    EXEC dbo.Wrh_SaveDoc @C, @U, 0, 1, @D, @W1, NULL, NULL, @CC, NULL, N'ط3', @L; SELECT @q3 = MAX(DocID) FROM dbo.Wrh_Doc WHERE DocCmpID = @C AND DocType = 1;
    EXEC dbo.Wrh_DeleteDraftRequest @C, @U, @q2;
    INSERT @R VALUES (N'S20 حذف المسودة', CASE WHEN NOT EXISTS (SELECT 1 FROM dbo.Wrh_Doc WHERE DocID = @q2) THEN 1 ELSE 0 END, N'');
    EXEC dbo.Wrh_RequestAction @C, @U, @q3, 1;
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_DeleteDraftRequest @C, @U, @q3; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S21 لا حذف للطلب المرسل', CASE WHEN @e = 52324 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S22 طلب شراء من طلب عند المخزن مرفوض
    SELECT @ql = LineID FROM dbo.Wrh_DocLine WHERE DocID = @q3;
    SET @L = CONCAT(N'[{"ItemID":', @I1, N',"UnitID":', @u1, N',"Qty":1,"RefLineID":', @ql, N'}]');
    SET @e = 0; BEGIN TRY EXEC dbo.Wrh_SaveDoc @C, @U, 0, 2, @D, NULL, NULL, NULL, NULL, @q3, NULL, @L; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'S22 طلب شراء من طلب عند المخزن مرفوض', CASE WHEN @e = 52323 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- S23 القوائم: السجل والاستعلام
    SELECT @n = COUNT(*) FROM dbo.Wrh_DocEvent WHERE EvDocID = @q1 AND EvKind >= 11;
    INSERT @R VALUES (N'S23 سجل المسار يحفظ الأحداث', CASE WHEN @n >= 10 THEN 1 ELSE 0 END, CONCAT(N'events ', @n));
    DELETE #X; INSERT #X EXEC dbo.Wrh_SelectRequests @C, @W1, 1;
    SELECT @n = COUNT(*) FROM #X WHERE A = @q3 AND H = 1 AND N = 2;
    INSERT @R VALUES (N'S24 استعلام الطلبات عند المخزن', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

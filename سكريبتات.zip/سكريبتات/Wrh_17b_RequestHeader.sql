/* المرحلة 17ب: رأس طلب المواد (للشاشة). نفّذه بعد Wrh_17_RequestFlow.sql */
USE [MADARERPDataBase];
GO
CREATE OR ALTER PROCEDURE dbo.Wrh_SelectRequestHeader
    @Cmp INT, @DocID BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT d.DocID, d.DocNo, d.DocDate, d.DocWhID, w.WhName, d.DocCostCID, c.CsCName, d.DocNotes, d.DocFlow,
           CASE d.DocFlow WHEN 0 THEN N'مسودة' WHEN 1 THEN N'عند المخزن' WHEN 2 THEN N'عند المشتريات'
                          WHEN 3 THEN N'معاد للجهة الطالبة' WHEN 4 THEN N'معاد للمخزن بانتظار القبول' END AS FlowName,
           d.DocStatus, d.DocCreatedBy,
           e.EvReason AS LastReason, e.EvAt AS LastAt
    FROM dbo.Wrh_Doc AS d
    JOIN dbo.Wrh_Warehouse AS w ON w.WhID = d.DocWhID
    LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DocCostCID
    OUTER APPLY (SELECT TOP 1 ev.EvReason, ev.EvAt FROM dbo.Wrh_DocEvent AS ev
                 WHERE ev.EvDocID = d.DocID AND ev.EvKind >= 11 ORDER BY ev.EvID DESC) AS e
    WHERE d.DocCmpID = @Cmp AND d.DocID = @DocID AND d.DocType = 1;
END;
GO
PRINT N'Wrh_17b تم';

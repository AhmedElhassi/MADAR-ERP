﻿/* =====================================================================
   المرحلة 18: ربط الموردين بالمخازن (إلزامي: مخزن واحد على الأقل) — للفلترة في المستندات
   - جدول Prt_PartyWarehouse(PwPrtID, PwWhID)
   - Prt_SaveParty يأخذ @Whs (قائمة معرّفات "1,2"): للمورد فقط (دور 1). NULL = لا يُمسّ الربط. 52240 إن لم يوجد مخزن.
   - الموردون الحاليون يُربَطون مرة واحدة بكل مخازن شركتهم حتى لا ينكسر شيء؛ عدّل ربطهم من صفحة الموردين.
   - Prt_SelectPartyWarehouses(@Cmp) : لكل مورد WhIDs و WhNames (لصفحة الموردين)
   - Prt_SelectWhParties(@Cmp,@WhID) : موردو المخزن (لكمبو المورد في مستندات ذلك المخزن)
   يتطلب Wrh_11 . نفّذ الملف كاملًا.
   ===================================================================== */
USE [MADARERPDataBase];
SET NOCOUNT ON;
GO
IF OBJECT_ID(N'dbo.Prt_PartyWarehouse', N'U') IS NULL
    CREATE TABLE dbo.Prt_PartyWarehouse
    (
        PwPrtID BIGINT NOT NULL CONSTRAINT FK_Prt_PartyWarehouse_Party REFERENCES dbo.Prt_Party (PrtID),
        PwWhID  BIGINT NOT NULL CONSTRAINT FK_Prt_PartyWarehouse_Wh REFERENCES dbo.Wrh_Warehouse (WhID),
        CONSTRAINT PK_Prt_PartyWarehouse PRIMARY KEY (PwPrtID, PwWhID)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Prt_PartyWarehouse_Wh' AND object_id = OBJECT_ID(N'dbo.Prt_PartyWarehouse'))
    CREATE INDEX IX_Prt_PartyWarehouse_Wh ON dbo.Prt_PartyWarehouse (PwWhID, PwPrtID);
GO
-- ترحيل لمرة واحدة: كل مورد بلا ربط يُربط بمخازن شركته
INSERT dbo.Prt_PartyWarehouse (PwPrtID, PwWhID)
SELECT p.PrtID, w.WhID
FROM dbo.Prt_Party AS p JOIN dbo.Wrh_Warehouse AS w ON w.WhCmpID = p.PrtCmpID
WHERE p.PrtRole = 1 AND NOT EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse AS x WHERE x.PwPrtID = p.PrtID);
GO

CREATE OR ALTER PROCEDURE dbo.Prt_SaveParty
    @Cmp INT, @User BIGINT, @PrtID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @Role TINYINT, @AccID BIGINT = NULL, @Active BIT = 1, @Whs NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@PrtID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @pn INT = ISNULL((SELECT MAX(TRY_CAST(PrtCode AS INT)) FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @pn), CASE WHEN LEN(CAST(@pn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@pn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @Role IS NULL OR @Role NOT IN (1, 2, 3) THROW 52203, N'نوع الجهة غير صحيح (1 مورد، 2 جهة خدمات، 3 موظف عهدة).', 1;
    -- مخازن المورد (للموردين فقط): NULL = لا يُمسّ الربط؛ وإن مُرّرت فيجب أن يوجد مخزن واحد صحيح على الأقل
    DECLARE @W TABLE (WhID BIGINT PRIMARY KEY);
    IF @Role = 1 AND @Whs IS NOT NULL
    BEGIN
        INSERT @W SELECT DISTINCT TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) FROM STRING_SPLIT(@Whs, N',')
                  WHERE TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) IS NOT NULL;
        IF NOT EXISTS (SELECT 1 FROM @W) THROW 52240, N'مخزن واحد على الأقل مطلوب للمورد.', 1;
        IF EXISTS (SELECT 1 FROM @W AS x WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = x.WhID AND WhCmpID = @Cmp))
            THROW 52240, N'مخزن غير موجود أو لا يتبع الشركة.', 1;
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب الجهة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp AND PrtCode = @Code AND PrtID <> ISNULL(@PrtID, 0))
        THROW 52204, N'كود الجهة مستخدم من قبل.', 1;

    DECLARE @Op SMALLINT = CASE @Role WHEN 1 THEN 2 WHEN 2 THEN 17 END;   -- 2 الموردين ، 17 الدائنون المتنوعون
    DECLARE @Started BIT = 0, @Cur BIGINT, @New BIGINT;
    IF ISNULL(@PrtID, 0) <> 0
    BEGIN
        SELECT @Cur = PrtAccID FROM dbo.Prt_Party WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'الجهة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Prt_SaveParty;
    BEGIN TRY
        IF @AccID IS NULL AND @Cur IS NULL AND @Op IS NOT NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, @Op, @Name, @New OUTPUT;
            SET @AccID = @New;
        END

        IF ISNULL(@PrtID, 0) = 0
        BEGIN
            INSERT dbo.Prt_Party (PrtCmpID, PrtCode, PrtName, PrtRole, PrtAccID, PrtActive, PrtCreatedBy)
            VALUES (@Cmp, @Code, @Name, @Role, @AccID, ISNULL(@Active, 1), @User);
            SET @PrtID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE dbo.Prt_Party
               SET PrtCode = @Code, PrtName = @Name, PrtRole = @Role, PrtAccID = COALESCE(@AccID, PrtAccID), PrtActive = ISNULL(@Active, 1)
             WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;
            -- مزامنة اسم حساب النظام (الذي أنشأه النظام فقط) مع اسم الجهة
            IF @Cur IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @Cur AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @Cur AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @Cur, @User, @Cmp;
        END

        IF @Role = 1
        BEGIN
            IF @Whs IS NOT NULL
            BEGIN
                DELETE dbo.Prt_PartyWarehouse WHERE PwPrtID = @PrtID AND PwWhID NOT IN (SELECT WhID FROM @W);
                INSERT dbo.Prt_PartyWarehouse (PwPrtID, PwWhID)
                SELECT @PrtID, WhID FROM @W AS x
                WHERE NOT EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @PrtID AND PwWhID = x.WhID);
            END
            IF NOT EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @PrtID)
                THROW 52240, N'مخزن واحد على الأقل مطلوب للمورد.', 1;
        END
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Prt_SaveParty;
        THROW;
    END CATCH
    SELECT @PrtID AS PrtID;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Prt_SelectPartyWarehouses
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT p.PrtID,
           ISNULL(STUFF((SELECT N',' + CAST(l.PwWhID AS NVARCHAR(20)) FROM dbo.Prt_PartyWarehouse AS l
                         WHERE l.PwPrtID = p.PrtID ORDER BY l.PwWhID FOR XML PATH(N''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, N''), N'') AS WhIDs,
           ISNULL(STUFF((SELECT N'، ' + h.WhName FROM dbo.Prt_PartyWarehouse AS l JOIN dbo.Wrh_Warehouse AS h ON h.WhID = l.PwWhID
                         WHERE l.PwPrtID = p.PrtID ORDER BY h.WhName FOR XML PATH(N''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, N''), N'') AS WhNames
    FROM dbo.Prt_Party AS p
    WHERE p.PrtCmpID = @Cmp;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Prt_SelectWhParties
    @Cmp INT, @WhID BIGINT, @ActiveOnly BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    SELECT p.PrtID, p.PrtCode, p.PrtName
    FROM dbo.Prt_Party AS p
    WHERE p.PrtCmpID = @Cmp AND p.PrtRole = 1 AND (@ActiveOnly = 0 OR p.PrtActive = 1)
      AND EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse AS l WHERE l.PwPrtID = p.PrtID AND l.PwWhID = @WhID)
    ORDER BY p.PrtCode;
END;
GO
PRINT N'Wrh_18 تم';

/* اختبار المرحلة 18: ربط الموردين بالمخازن — داخل معاملة تُرجَع */
USE [MADARERPDataBase];
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Prt_SelectWhParties') IS NULL THROW 52900, N'نفّذ Wrh_18_PartyWarehouses.sql أولًا', 1;
DECLARE @R TABLE (Nm NVARCHAR(70), Ok BIT, Info NVARCHAR(400));
CREATE TABLE #M (A BIGINT, B NVARCHAR(MAX), C NVARCHAR(MAX));
CREATE TABLE #P (A BIGINT, B NVARCHAR(30), C NVARCHAR(200));
DECLARE @CC BIGINT = (SELECT TOP 1 CsCID FROM dbo.Acc_CostCenter ORDER BY CsCID);
DECLARE @C INT = (SELECT CsCCompany FROM dbo.Acc_CostCenter WHERE CsCID = @CC);
DECLARE @U BIGINT = (SELECT TOP 1 UsrID FROM dbo.Mng_User ORDER BY UsrID);
DECLARE @W1 BIGINT, @W2 BIGINT, @W3 BIGINT, @P1 BIGINT, @P2 BIGINT, @P3 BIGINT, @c1 NVARCHAR(30), @s NVARCHAR(100), @n INT, @e INT;
IF @C IS NULL OR @U IS NULL OR @CC IS NULL INSERT @R VALUES (N'متطلبات', 0, N'يلزم مستخدم ومركز تكلفة');
ELSE
BEGIN
    BEGIN TRAN;
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ح18 1';
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ح18 2';
    EXEC dbo.Wrh_SaveWarehouse @C, @U, 0, N'', N'مخزن ح18 3';
    SELECT @W1 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ح18 1';
    SELECT @W2 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ح18 2';
    SELECT @W3 = WhID FROM dbo.Wrh_Warehouse WHERE WhCmpID = @C AND WhName = N'مخزن ح18 3';

    -- P1 مورد بمخزنين
    SET @s = CONCAT(@W1, N',', @W2);
    EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد ح18 أ', 1, NULL, 1, @s;
    SELECT @P1 = PrtID, @c1 = PrtCode FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد ح18 أ';
    SELECT @n = COUNT(*) FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @P1 AND PwWhID IN (@W1, @W2);
    INSERT @R VALUES (N'P1 مورد بمخزنين', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- P2 بلا مخزن / فارغ / غير موجود مرفوض، ولا يُنشأ المورد
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد ح18 ب', 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P2 مورد جديد بلا مخزن مرفوض', CASE WHEN @e = 52240 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد ح18 ب', 1, NULL, 1, N''; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P3 قائمة فارغة مرفوضة', CASE WHEN @e = 52240 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد ح18 ب', 1, NULL, 1, N'999999999'; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P4 مخزن غير موجود مرفوض', CASE WHEN @e = 52240 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));
    INSERT @R VALUES (N'P5 الرفض لا يترك مورد ولا حسابًا', CASE WHEN NOT EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد ح18 ب') THEN 1 ELSE 0 END, N'');

    -- P6 تعديل بلا قائمة لا يمس الربط، وبقائمة جديدة يستبدل
    EXEC dbo.Prt_SaveParty @C, @U, @P1, @c1, N'مورد ح18 أ', 1;
    SELECT @n = COUNT(*) FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @P1;
    INSERT @R VALUES (N'P6 NULL لا يمس الربط', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    SET @s = CAST(@W3 AS NVARCHAR(20));
    EXEC dbo.Prt_SaveParty @C, @U, @P1, @c1, N'مورد ح18 أ', 1, NULL, 1, @s;
    SELECT @n = COUNT(*) FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @P1;
    INSERT @R VALUES (N'P7 الاستبدال يحذف القديم', CASE WHEN @n = 1 AND EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @P1 AND PwWhID = @W3) THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- P8 جهة خدمات (دور 2) بلا مخزن مقبولة
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'ناقل ح18', 2; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P8 غير المورد بلا مخزن مقبول', CASE WHEN @e = 0 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- P9 مورد قديم بلا ربط: التعديل بلا قائمة مرفوض
    INSERT dbo.Prt_Party (PrtCmpID, PrtCode, PrtName, PrtRole, PrtAccID, PrtActive, PrtCreatedBy)
    VALUES (@C, N'ZZ18', N'مورد قديم ح18', 1, NULL, 1, @U);
    SELECT @P3 = PrtID FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtCode = N'ZZ18';
    SET @e = 0; BEGIN TRY EXEC dbo.Prt_SaveParty @C, @U, @P3, N'ZZ18', N'مورد قديم ح18', 1; END TRY BEGIN CATCH SET @e = ERROR_NUMBER(); END CATCH
    INSERT @R VALUES (N'P9 مورد بلا ربط لا يُحفظ حتى يُربط', CASE WHEN @e = 52240 THEN 1 ELSE 0 END, CONCAT(N'got ', @e));

    -- Q1 قائمة موردي المخزن
    SET @s = CONCAT(@W1, N',', @W3);
    EXEC dbo.Prt_SaveParty @C, @U, 0, N'', N'مورد ح18 ج', 1, NULL, 1, @s;
    SELECT @P2 = PrtID FROM dbo.Prt_Party WHERE PrtCmpID = @C AND PrtName = N'مورد ح18 ج';
    DELETE #P; INSERT #P EXEC dbo.Prt_SelectWhParties @C, @W1;
    SELECT @n = COUNT(*) FROM #P WHERE A IN (@P1, @P2);
    INSERT @R VALUES (N'Q1 موردو المخزن 1 (ج فقط)', CASE WHEN @n = 1 AND EXISTS (SELECT 1 FROM #P WHERE A = @P2) THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    DELETE #P; INSERT #P EXEC dbo.Prt_SelectWhParties @C, @W3;
    SELECT @n = COUNT(*) FROM #P WHERE A IN (@P1, @P2);
    INSERT @R VALUES (N'Q2 موردو المخزن 3 (أ و ج)', CASE WHEN @n = 2 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));

    -- Q3 قائمة الربط لصفحة الموردين
    DELETE #M; INSERT #M EXEC dbo.Prt_SelectPartyWarehouses @C;
    SELECT @n = COUNT(*) FROM #M WHERE A = @P2 AND B = CONCAT(@W1, N',', @W3) AND C LIKE N'%مخزن ح18 1%' AND C LIKE N'%مخزن ح18 3%';
    INSERT @R VALUES (N'Q3 WhIDs و WhNames', CASE WHEN @n = 1 THEN 1 ELSE 0 END, CONCAT(N'got ', @n));
    IF @@TRANCOUNT > 0 ROLLBACK;
END
SELECT Nm, N'FAIL' AS Result, Info FROM @R WHERE Ok = 0;
SELECT CONCAT(SUM(CAST(Ok AS INT)), N'/', COUNT(*), N' PASS') AS Total FROM @R;

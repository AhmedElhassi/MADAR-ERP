USE [MADARERPDataBase];
GO

/* =====================================================================
   البند 1: قيد CHECK على Acc_DayDetails
   القاعدة: القيم غير سالبة، والبند إما مدين أو دائن (أحدهما > 0 والآخر = 0)
   خذ نسخة احتياطية قبل التنفيذ.
   ===================================================================== */

-- 1) فحص البيانات الحالية: يجب أن تكون النتيجة صفر صفوف
SELECT d.DayDID, d.DayDMID, d.DayDAccID, d.DayDDeb, d.DayDCrd
FROM dbo.Acc_DayDetails AS d
WHERE d.DayDDeb < 0
   OR d.DayDCrd < 0
   OR (d.DayDDeb = 0 AND d.DayDCrd = 0)
   OR (d.DayDDeb > 0 AND d.DayDCrd > 0);
GO

-- 2) إضافة القيد
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE name = N'CK_Acc_DayDetails_Amounts'
                 AND parent_object_id = OBJECT_ID(N'dbo.Acc_DayDetails'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Acc_DayDetails
               WHERE DayDDeb < 0 OR DayDCrd < 0
                  OR (DayDDeb = 0 AND DayDCrd = 0)
                  OR (DayDDeb > 0 AND DayDCrd > 0))
    BEGIN
        -- توجد صفوف مخالفة: يُفرض القيد على الصفوف الجديدة فقط حتى تُصحَّح القديمة
        ALTER TABLE dbo.Acc_DayDetails WITH NOCHECK
            ADD CONSTRAINT CK_Acc_DayDetails_Amounts
            CHECK (DayDDeb >= 0 AND DayDCrd >= 0
                   AND ((DayDDeb > 0 AND DayDCrd = 0) OR (DayDDeb = 0 AND DayDCrd > 0)));
        PRINT N'تحذير: توجد صفوف مخالفة. أُضيف القيد WITH NOCHECK. صحّح الصفوف ثم نفّذ:';
        PRINT N'ALTER TABLE dbo.Acc_DayDetails WITH CHECK CHECK CONSTRAINT CK_Acc_DayDetails_Amounts;';
    END
    ELSE
    BEGIN
        ALTER TABLE dbo.Acc_DayDetails WITH CHECK
            ADD CONSTRAINT CK_Acc_DayDetails_Amounts
            CHECK (DayDDeb >= 0 AND DayDCrd >= 0
                   AND ((DayDDeb > 0 AND DayDCrd = 0) OR (DayDDeb = 0 AND DayDCrd > 0)));
        PRINT N'تمت إضافة القيد بنجاح.';
    END
END
ELSE
    PRINT N'القيد موجود مسبقًا.';
GO

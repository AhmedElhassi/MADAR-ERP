USE [MADARERPDataBase];
GO

/* =====================================================================
   البند 3: رقم القيد (رقم/شهر) فريد لكل شركة ولكل سنة ولكل شهر
   القاعدة: (DayMCompany, YEAR, MONTH, DayMNo) فريد عندما DayMNo > 0
   المسودات (DayMNo = 0) مستثناة.
   خذ نسخة احتياطية قبل التنفيذ.
   ===================================================================== */

-- 1) فحص التكرار الحالي: يجب أن تكون النتيجة صفر صفوف
SELECT DayMCompany,
       YEAR(DayMDate)  AS Yr,
       MONTH(DayMDate) AS Mth,
       DayMNo,
       COUNT(*)        AS Cnt,
       MIN(DayMID)     AS FirstDayMID,
       MAX(DayMID)     AS LastDayMID
FROM dbo.Acc_DayMaster
WHERE DayMNo > 0
GROUP BY DayMCompany, YEAR(DayMDate), MONTH(DayMDate), DayMNo
HAVING COUNT(*) > 1
ORDER BY DayMCompany, Yr, Mth, DayMNo;
GO

-- 2) أعمدة محسوبة ومخزنة (الإجراءات الحالية تُدخل بقوائم أعمدة صريحة، فلا تتأثر)
IF COL_LENGTH(N'dbo.Acc_DayMaster', N'DayMYear') IS NULL
    ALTER TABLE dbo.Acc_DayMaster ADD DayMYear AS (YEAR(DayMDate)) PERSISTED;
GO
IF COL_LENGTH(N'dbo.Acc_DayMaster', N'DayMMonth') IS NULL
    ALTER TABLE dbo.Acc_DayMaster ADD DayMMonth AS (MONTH(DayMDate)) PERSISTED;
GO

-- 3) الفهرس الفريد المُرشَّح
--    إن وُجد تكرار في الخطوة 1 سيفشل الإنشاء: صحّح الأرقام المكررة أولًا ثم أعد التنفيذ.
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'UX_Acc_DayMaster_Company_Year_Month_No'
                 AND object_id = OBJECT_ID(N'dbo.Acc_DayMaster'))
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX UX_Acc_DayMaster_Company_Year_Month_No
        ON dbo.Acc_DayMaster (DayMCompany, DayMYear, DayMMonth, DayMNo)
        WHERE DayMNo > 0;
    PRINT N'تم إنشاء الفهرس الفريد.';
END
ELSE
    PRINT N'الفهرس موجود مسبقًا.';
GO

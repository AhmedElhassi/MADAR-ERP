USE [MADARERPDataBase];
GO

/* =====================================================================
   البند 3-ب: إعادة ترقيم القيود المكررة (رقم/شهر لكل شركة ولكل سنة)
   القاعدة: في كل مجموعة مكررة يحتفظ القيد الأقدم (أصغر DayMID) برقمه،
            وتأخذ القيود الأحدث أرقامًا جديدة: (أكبر رقم في الشهر) + 1 ثم +2 ...
   الأرقام القديمة والجديدة تُسجَّل في Acc_DayMasterRenumberLog.
   - خذ نسخة احتياطية كاملة قبل التنفيذ.
   - نفّذه والنظام خارج الاستخدام (يأخذ قفلًا على Acc_DayMaster طوال العملية).
   - هذه القيود في الحالة 7 (مؤرشفة): احصل على موافقة المحاسب أولًا.
   ===================================================================== */

IF OBJECT_ID(N'dbo.Acc_DayMasterRenumberLog') IS NULL
    CREATE TABLE dbo.Acc_DayMasterRenumberLog
    (
        LogID      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Acc_DayMasterRenumberLog PRIMARY KEY,
        DayMID     BIGINT   NOT NULL,
        DayMCompany INT     NOT NULL,
        DayMDate   DATE     NOT NULL,
        OldNo      INT      NOT NULL,
        NewNo      INT      NOT NULL,
        RunAt      DATETIME2(0) NOT NULL CONSTRAINT DF_Acc_DayMasterRenumberLog_RunAt DEFAULT SYSDATETIME(),
        RunBy      SYSNAME  NOT NULL CONSTRAINT DF_Acc_DayMasterRenumberLog_RunBy DEFAULT SUSER_SNAME()
    );
GO

SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRAN;

    -- قفل الجدول طوال العملية
    DECLARE @lock INT;
    SELECT @lock = COUNT(*) FROM dbo.Acc_DayMaster WITH (TABLOCKX, HOLDLOCK);

    IF OBJECT_ID(N'tempdb..#R') IS NOT NULL DROP TABLE #R;

    ;WITH d AS
    (
        SELECT m.DayMID, m.DayMCompany, m.DayMDate, m.DayMNo,
               YEAR(m.DayMDate) AS Yr, MONTH(m.DayMDate) AS Mth,
               ROW_NUMBER() OVER (PARTITION BY m.DayMCompany, YEAR(m.DayMDate), MONTH(m.DayMDate), m.DayMNo
                                  ORDER BY m.DayMID) AS rn
        FROM dbo.Acc_DayMaster AS m
        WHERE m.DayMNo > 0
    ),
    mx AS
    (
        SELECT DayMCompany, YEAR(DayMDate) AS Yr, MONTH(DayMDate) AS Mth, MAX(DayMNo) AS MaxNo
        FROM dbo.Acc_DayMaster
        WHERE DayMNo > 0
        GROUP BY DayMCompany, YEAR(DayMDate), MONTH(DayMDate)
    )
    SELECT d.DayMID, d.DayMCompany, d.DayMDate, d.DayMNo AS OldNo,
           mx.MaxNo + ROW_NUMBER() OVER (PARTITION BY d.DayMCompany, d.Yr, d.Mth ORDER BY d.DayMID) AS NewNo
    INTO #R
    FROM d
    JOIN mx ON mx.DayMCompany = d.DayMCompany AND mx.Yr = d.Yr AND mx.Mth = d.Mth
    WHERE d.rn > 1;

    -- معاينة ما سيتغير
    SELECT * FROM #R ORDER BY DayMCompany, DayMDate, DayMID;

    INSERT dbo.Acc_DayMasterRenumberLog (DayMID, DayMCompany, DayMDate, OldNo, NewNo)
    SELECT DayMID, DayMCompany, DayMDate, OldNo, NewNo FROM #R;

    UPDATE m
    SET    m.DayMNo = r.NewNo
    FROM   dbo.Acc_DayMaster AS m
    JOIN   #R AS r ON r.DayMID = m.DayMID;

    -- تحقق نهائي: لا تكرار بعد التعديل
    IF EXISTS (SELECT 1 FROM dbo.Acc_DayMaster
               WHERE DayMNo > 0
               GROUP BY DayMCompany, YEAR(DayMDate), MONTH(DayMDate), DayMNo
               HAVING COUNT(*) > 1)
        THROW 60001, N'ما زال هناك تكرار بعد إعادة الترقيم؛ أُلغيت العملية.', 1;

    COMMIT;
    PRINT N'تمت إعادة الترقيم. راجع Acc_DayMasterRenumberLog، ثم نفّذ fix_03_unique_voucher_no.sql لإنشاء الفهرس.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH;
GO

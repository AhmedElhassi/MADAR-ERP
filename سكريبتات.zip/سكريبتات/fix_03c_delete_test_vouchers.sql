USE [MADARERPDataBase];
GO

/* =====================================================================
   حذف القيود التجريبية المكررة (18 قيدًا) 
   - افتراضيًا معاينة فقط: لا يُحذف شيء حتى تضبط @Execute = 1
   - قبل الحذف تُنسخ الصفوف إلى جداول Bak_Del_* للرجوع إليها
   - القيد الآلي: يُحذف سطر الربط والرأس، فتعود مستندات المخازن المرتبطة
     إلى قائمة "المعلّقة" (كما يفعل Wrh_UnlinkAutoVoucher)
   - خذ نسخة احتياطية كاملة قبل التنفيذ، ونفّذ والنظام خارج الاستخدام
   ===================================================================== */
SET XACT_ABORT ON;

DECLARE @Execute BIT = 0;      -- 0 = معاينة ، 1 = تنفيذ الحذف

DECLARE @Ids TABLE (DayMID BIGINT NOT NULL PRIMARY KEY);
INSERT @Ids (DayMID) VALUES
 (13587),(13740),(11727),(11728),(13730),(13737),
 (14167),(14168),(14921),(14922),(15285),(15286),
 (15714),(15715),(16168),(16169),(16606),(16607);

-- 1) معاينة
SELECT m.DayMID, m.DayMCompany, m.DayMDate, m.DayMNo, m.DayMState,
       CASE WHEN av.AvID IS NOT NULL THEN N'آلي' ELSE N'يدوي' END AS Kind,
       (SELECT COUNT(*) FROM dbo.Acc_AutoVoucherLine l WHERE l.AvID = av.AvID) AS LinkedWarehouseDocs,
       (SELECT SUM(DayDDeb) FROM dbo.Acc_DayDetails d WHERE d.DayDMID = m.DayMID) AS TotalDeb,
       LEFT(m.DayMDescription, 50) AS Descr
FROM @Ids i
JOIN dbo.Acc_DayMaster m ON m.DayMID = i.DayMID
LEFT JOIN dbo.Acc_AutoVoucher av ON av.AvDayMID = m.DayMID
ORDER BY m.DayMCompany, m.DayMDate, m.DayMID;

IF (SELECT COUNT(*) FROM @Ids i JOIN dbo.Acc_DayMaster m ON m.DayMID = i.DayMID)
   <> (SELECT COUNT(*) FROM @Ids)
    THROW 60010, N'بعض أرقام القيود غير موجودة في Acc_DayMaster؛ راجع القائمة.', 1;

IF @Execute = 0
BEGIN
    PRINT N'معاينة فقط. لم يُحذف شيء. اضبط @Execute = 1 للتنفيذ.';
    RETURN;
END;

-- 2) تنفيذ الحذف
BEGIN TRY
    BEGIN TRAN;

    -- نسخ احتياطي للصفوف المحذوفة
    IF OBJECT_ID(N'dbo.Bak_Del_DayMaster') IS NULL
        SELECT * INTO dbo.Bak_Del_DayMaster FROM dbo.Acc_DayMaster WHERE 1 = 0;
    INSERT dbo.Bak_Del_DayMaster SELECT m.* FROM dbo.Acc_DayMaster m JOIN @Ids i ON i.DayMID = m.DayMID;

    IF OBJECT_ID(N'dbo.Bak_Del_DayDetails') IS NULL
        SELECT * INTO dbo.Bak_Del_DayDetails FROM dbo.Acc_DayDetails WHERE 1 = 0;
    INSERT dbo.Bak_Del_DayDetails SELECT d.* FROM dbo.Acc_DayDetails d JOIN @Ids i ON i.DayMID = d.DayDMID;

    IF OBJECT_ID(N'dbo.Bak_Del_DayMasterState') IS NULL
        SELECT * INTO dbo.Bak_Del_DayMasterState FROM dbo.Acc_DayMasterState WHERE 1 = 0;
    INSERT dbo.Bak_Del_DayMasterState SELECT s.* FROM dbo.Acc_DayMasterState s JOIN @Ids i ON i.DayMID = s.DayMSDayMID;

    IF OBJECT_ID(N'dbo.Bak_Del_AutoVoucher') IS NULL
        SELECT * INTO dbo.Bak_Del_AutoVoucher FROM dbo.Acc_AutoVoucher WHERE 1 = 0;
    INSERT dbo.Bak_Del_AutoVoucher SELECT v.* FROM dbo.Acc_AutoVoucher v JOIN @Ids i ON i.DayMID = v.AvDayMID;

    IF OBJECT_ID(N'dbo.Bak_Del_AutoVoucherLine') IS NULL
        SELECT * INTO dbo.Bak_Del_AutoVoucherLine FROM dbo.Acc_AutoVoucherLine WHERE 1 = 0;
    INSERT dbo.Bak_Del_AutoVoucherLine
    SELECT l.* FROM dbo.Acc_AutoVoucherLine l
    JOIN dbo.Acc_AutoVoucher v ON v.AvID = l.AvID
    JOIN @Ids i ON i.DayMID = v.AvDayMID;

    -- الحذف بترتيب المفاتيح الأجنبية
    DELETE l FROM dbo.Acc_AutoVoucherLine l
    JOIN dbo.Acc_AutoVoucher v ON v.AvID = l.AvID
    JOIN @Ids i ON i.DayMID = v.AvDayMID;

    DELETE v FROM dbo.Acc_AutoVoucher v JOIN @Ids i ON i.DayMID = v.AvDayMID;
    DELETE s FROM dbo.Acc_DayMasterState s JOIN @Ids i ON i.DayMID = s.DayMSDayMID;
    DELETE d FROM dbo.Acc_DayDetails d JOIN @Ids i ON i.DayMID = d.DayDMID;
    DELETE m FROM dbo.Acc_DayMaster m JOIN @Ids i ON i.DayMID = m.DayMID;

    IF EXISTS (SELECT 1 FROM dbo.Acc_DayMaster m JOIN @Ids i ON i.DayMID = m.DayMID)
        THROW 60011, N'بقيت قيود لم تُحذف؛ أُلغيت العملية.', 1;

    COMMIT;
    PRINT N'تم حذف القيود. النسخ في جداول Bak_Del_*. نفّذ الآن fix_03_unique_voucher_no.sql.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH;
GO

USE [MADARERPDataBase];
GO

/* =====================================================================
   البند 5 (الدفعة الأولى): المفاتيح الأجنبية الناقصة
   Wrh_Doc (7 مفاتيح) ، Acc_AutoVoucher (2) ، Acc_AutoVoucherLine.DayDID (1)

   لكل مفتاح:
     - يُعدّ عدد الصفوف اليتيمة (قيمة لا يقابلها صف في الجدول الأب)
     - بلا يتامى  : يُضاف WITH CHECK (موثوق)
     - مع يتامى   : يُضاف WITH NOCHECK (يُفرض على الجديد فقط) ويظهر العدد في النتيجة
     - الموجود مسبقًا يُتجاوز

   ملاحظات تصميم:
     - Acc_AutoVoucherLine.DayDID : ON DELETE SET NULL، لأن Acc_SaveDayVoucher يحذف
       بنود القيد ويعيد إدخالها عند تعديل المسودة، فمفتاح عادي سيمنع التعديل.
     - لم تُضف مفاتيح على Wrh_DocEvent.EvDocID و EvLineID عمدًا: الإجراءات
       (مثل Wrh_DeleteDoc) تسجّل حدثًا ثم تحذف المستند، والسجل يحمل رقم ونوع المستند.

   خذ نسخة احتياطية قبل التنفيذ، ونفّذ والنظام خارج الاستخدام.
   ===================================================================== */
SET NOCOUNT ON;

DECLARE @Defs TABLE
(
    Id        INT IDENTITY(1,1) PRIMARY KEY,
    FkName    SYSNAME NOT NULL,
    ChildTbl  SYSNAME NOT NULL,
    ChildCol  SYSNAME NOT NULL,
    ParentTbl SYSNAME NOT NULL,
    ParentCol SYSNAME NOT NULL,
    SetNull   BIT     NOT NULL
);

INSERT @Defs (FkName, ChildTbl, ChildCol, ParentTbl, ParentCol, SetNull) VALUES
 (N'FK_Wrh_Doc_Company',   N'Wrh_Doc',            N'DocCmpID',     N'Mng_Company',   N'CmpID',  0),
 (N'FK_Wrh_Doc_Warehouse', N'Wrh_Doc',            N'DocWhID',      N'Wrh_Warehouse', N'WhID',   0),
 (N'FK_Wrh_Doc_Warehouse2',N'Wrh_Doc',            N'DocWh2ID',     N'Wrh_Warehouse', N'WhID',   0),
 (N'FK_Wrh_Doc_Party',     N'Wrh_Doc',            N'DocPartyID',   N'Prt_Party',     N'PrtID',  0),
 (N'FK_Wrh_Doc_CostCenter',N'Wrh_Doc',            N'DocCostCID',   N'Acc_CostCenter',N'CsCID',  0),
 (N'FK_Wrh_Doc_RefDoc',    N'Wrh_Doc',            N'DocRefDocID',  N'Wrh_Doc',       N'DocID',  0),
 (N'FK_Wrh_Doc_CreatedBy', N'Wrh_Doc',            N'DocCreatedBy', N'Mng_User',      N'UsrID',  0),
 (N'FK_Acc_AutoVoucher_Company',   N'Acc_AutoVoucher',     N'AvCompany',   N'Mng_Company', N'CmpID',  0),
 (N'FK_Acc_AutoVoucher_CreatedBy', N'Acc_AutoVoucher',     N'AvCreatedBy', N'Mng_User',    N'UsrID',  0),
 (N'FK_Acc_AutoVoucherLine_Day',   N'Acc_AutoVoucherLine', N'DayDID',      N'Acc_DayDetails', N'DayDID', 1);

CREATE TABLE #Res (FkName SYSNAME, Orphans INT NULL, Mode NVARCHAR(40));

DECLARE @i INT = 1, @n INT = (SELECT COUNT(*) FROM @Defs);
DECLARE @fk SYSNAME, @ct SYSNAME, @cc SYSNAME, @pt SYSNAME, @pc SYSNAME, @sn BIT;
DECLARE @sql NVARCHAR(MAX), @orph INT;

WHILE @i <= @n
BEGIN
    SELECT @fk = FkName, @ct = ChildTbl, @cc = ChildCol, @pt = ParentTbl, @pc = ParentCol, @sn = SetNull
    FROM @Defs WHERE Id = @i;

    IF EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE name = @fk AND parent_object_id = OBJECT_ID(N'dbo.' + QUOTENAME(@ct)))
    BEGIN
        INSERT #Res VALUES (@fk, NULL, N'موجود مسبقًا');
    END
    ELSE
    BEGIN
        SET @sql = N'SELECT @o = COUNT(*) FROM dbo.' + QUOTENAME(@ct) + N' AS c WHERE c.' + QUOTENAME(@cc)
                 + N' IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.' + QUOTENAME(@pt) + N' AS p WHERE p.'
                 + QUOTENAME(@pc) + N' = c.' + QUOTENAME(@cc) + N')';
        EXEC sp_executesql @sql, N'@o INT OUTPUT', @o = @orph OUTPUT;

        SET @sql = N'ALTER TABLE dbo.' + QUOTENAME(@ct)
                 + CASE WHEN @orph = 0 THEN N' WITH CHECK' ELSE N' WITH NOCHECK' END
                 + N' ADD CONSTRAINT ' + QUOTENAME(@fk)
                 + N' FOREIGN KEY (' + QUOTENAME(@cc) + N') REFERENCES dbo.' + QUOTENAME(@pt)
                 + N' (' + QUOTENAME(@pc) + N')'
                 + CASE WHEN @sn = 1 THEN N' ON DELETE SET NULL' ELSE N'' END;
        EXEC sp_executesql @sql;

        INSERT #Res VALUES (@fk, @orph,
               CASE WHEN @orph = 0 THEN N'أُضيف WITH CHECK' ELSE N'أُضيف WITH NOCHECK (يوجد يتامى)' END);
    END;

    SET @i += 1;
END;

SELECT * FROM #Res ORDER BY CASE WHEN Orphans > 0 THEN 0 ELSE 1 END, FkName;
DROP TABLE #Res;
GO

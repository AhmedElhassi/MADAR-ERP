USE [MADARERPDataBase];
GO

/* =====================================================================
   البند 5 (الدفعة الثانية): مفاتيح أجنبية للحسابات والشركات والصلاحيات
   - ربط حسابات الأطراف والمخازن ومجموعات الأصناف وإعدادات المخازن بـ Acc_Account
   - ربط عمود الشركة في جداول المخازن والأطراف بـ Mng_Company
   - Mng_UserParmations: المستخدم والشركة والمنظومة وواضع الصلاحية
   - Emp_Employee.EmpCompany ، Prt_Party.PrtCreatedBy ، Wrh_Settings.WsUpdatedBy

   السلوك لكل مفتاح:
     بلا يتامى  : WITH CHECK
     مع يتامى   : WITH NOCHECK ويظهر العدد في النتيجة
     موجود مسبقًا : يُتجاوز (يمكن إعادة التشغيل)

   متروك عمدًا: Wrh_Warehouse.WhKeeper (الجدول المرجعي غير محدد في السكربت)،
   وأعمدة المنشئ في Mng_User/Mng_Company/Emp_Employee (إدارية ودائرية).

   خذ نسخة احتياطية قبل التنفيذ، ونفّذ والنظام خارج الاستخدام.
   ===================================================================== */
SET NOCOUNT ON;

DECLARE @Defs TABLE
(
    Id        INT IDENTITY(1,1) PRIMARY KEY,
    FkName    SYSNAME NOT NULL,
    ChildTbl  SYSNAME NOT NULL,
    ChildCol  SYSNAME NOT NULL,
    ParentTbl SYSNAME NOT NULL,
    ParentCol SYSNAME NOT NULL
);

INSERT @Defs (FkName, ChildTbl, ChildCol, ParentTbl, ParentCol) VALUES
 -- الحسابات
 (N'FK_Prt_Party_Account',          N'Prt_Party',     N'PrtAccID',         N'Acc_Account', N'AccID'),
 (N'FK_Wrh_Warehouse_Account',      N'Wrh_Warehouse', N'WhAccID',          N'Acc_Account', N'AccID'),
 (N'FK_Wrh_ItemGroup_Account',      N'Wrh_ItemGroup', N'GrpAccID',         N'Acc_Account', N'AccID'),
 (N'FK_Wrh_Settings_DiffAcc',       N'Wrh_Settings',  N'WsDiffAccID',      N'Acc_Account', N'AccID'),
 (N'FK_Wrh_Settings_CreditNoteAcc', N'Wrh_Settings',  N'WsCreditNoteAccID',N'Acc_Account', N'AccID'),
 (N'FK_Wrh_Settings_CountAcc',      N'Wrh_Settings',  N'WsCountAccID',     N'Acc_Account', N'AccID'),
 -- الشركات
 (N'FK_Prt_Party_Company',          N'Prt_Party',     N'PrtCmpID',         N'Mng_Company', N'CmpID'),
 (N'FK_Wrh_Warehouse_Company',      N'Wrh_Warehouse', N'WhCmpID',          N'Mng_Company', N'CmpID'),
 (N'FK_Wrh_ItemGroup_Company',      N'Wrh_ItemGroup', N'GrpCmpID',         N'Mng_Company', N'CmpID'),
 (N'FK_Wrh_Item_Company',           N'Wrh_Item',      N'ItemCmpID',        N'Mng_Company', N'CmpID'),
 (N'FK_Wrh_Unit_Company',           N'Wrh_Unit',      N'UnitCmpID',        N'Mng_Company', N'CmpID'),
 (N'FK_Wrh_Stock_Company',          N'Wrh_Stock',     N'StkCmpID',         N'Mng_Company', N'CmpID'),
 (N'FK_Emp_Employee_Company',       N'Emp_Employee',  N'EmpCompany',       N'Mng_Company', N'CmpID'),
 -- الصلاحيات
 (N'FK_Mng_UserParmations_User',    N'Mng_UserParmations', N'USPUserID',    N'Mng_User',    N'UsrID'),
 (N'FK_Mng_UserParmations_Company', N'Mng_UserParmations', N'USPCompanyID', N'Mng_Company', N'CmpID'),
 (N'FK_Mng_UserParmations_System',  N'Mng_UserParmations', N'USPSystemID',  N'Mng_System',  N'SysID'),
 (N'FK_Mng_UserParmations_By',      N'Mng_UserParmations', N'USPUser',      N'Mng_User',    N'UsrID'),
 -- المستخدم الذي أنشأ/عدّل
 (N'FK_Prt_Party_CreatedBy',        N'Prt_Party',     N'PrtCreatedBy',     N'Mng_User',    N'UsrID'),
 (N'FK_Wrh_Settings_UpdatedBy',     N'Wrh_Settings',  N'WsUpdatedBy',      N'Mng_User',    N'UsrID');

CREATE TABLE #Res (FkName SYSNAME, Orphans INT NULL, Mode NVARCHAR(40));

DECLARE @i INT = 1, @n INT = (SELECT COUNT(*) FROM @Defs);
DECLARE @fk SYSNAME, @ct SYSNAME, @cc SYSNAME, @pt SYSNAME, @pc SYSNAME;
DECLARE @sql NVARCHAR(MAX), @orph INT;

WHILE @i <= @n
BEGIN
    SELECT @fk = FkName, @ct = ChildTbl, @cc = ChildCol, @pt = ParentTbl, @pc = ParentCol
    FROM @Defs WHERE Id = @i;

    IF EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE name = @fk AND parent_object_id = OBJECT_ID(N'dbo.' + QUOTENAME(@ct)))
    BEGIN
        INSERT #Res VALUES (@fk, NULL, N'موجود مسبقًا');
    END
    ELSE
    BEGIN
        SET @sql = N'SELECT @o = COUNT(*) FROM dbo.' + QUOTENAME(@ct) + N' AS c WHERE c.' + QUOTENAME(@cc)
                 + N' IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.' + QUOTENAME(@pt) + N' AS p WHERE p.'
                 + QUOTENAME(@pc) + N' = c.' + QUOTENAME(@cc) + N')';
        EXEC sp_executesql @sql, N'@o INT OUTPUT', @o = @orph OUTPUT;

        SET @sql = N'ALTER TABLE dbo.' + QUOTENAME(@ct)
                 + CASE WHEN @orph = 0 THEN N' WITH CHECK' ELSE N' WITH NOCHECK' END
                 + N' ADD CONSTRAINT ' + QUOTENAME(@fk)
                 + N' FOREIGN KEY (' + QUOTENAME(@cc) + N') REFERENCES dbo.' + QUOTENAME(@pt)
                 + N' (' + QUOTENAME(@pc) + N')';
        EXEC sp_executesql @sql;

        INSERT #Res VALUES (@fk, @orph,
               CASE WHEN @orph = 0 THEN N'أُضيف WITH CHECK' ELSE N'أُضيف WITH NOCHECK (يوجد يتامى)' END);
    END;

    SET @i += 1;
END;

SELECT * FROM #Res ORDER BY CASE WHEN Orphans > 0 THEN 0 ELSE 1 END, FkName;
DROP TABLE #Res;
GO

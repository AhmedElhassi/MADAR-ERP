USE [MADARERPDataBase];
GO

/* =====================================================================
   حالات القيد (DayMState) من 0 إلى 7:
     0 مسودة | 1 قيد مرحَّل | 2 معاد من المراجعة | 3 مراجَع
     4 معاد من الاعتماد | 5 معتمد | 6 معاد من الأرشفة | 7 مؤرشف
   قيود CHECK على:
     Acc_DayMaster.DayMState        و   Acc_DayMasterState.DayMSState
   بلا يتامى: WITH CHECK ، مع قيم خارج النطاق: WITH NOCHECK ويُطبع التحذير
   ===================================================================== */

-- فحص مسبق: يجب أن تكون النتيجة صفر صفوف
SELECT N'Acc_DayMaster' AS Tbl, DayMState AS BadState, COUNT(*) AS Cnt
FROM dbo.Acc_DayMaster WHERE DayMState NOT BETWEEN 0 AND 7 GROUP BY DayMState
UNION ALL
SELECT N'Acc_DayMasterState', DayMSState, COUNT(*)
FROM dbo.Acc_DayMasterState WHERE DayMSState NOT BETWEEN 0 AND 7 GROUP BY DayMSState;
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE name = N'CK_Acc_DayMaster_State' AND parent_object_id = OBJECT_ID(N'dbo.Acc_DayMaster'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMState NOT BETWEEN 0 AND 7)
    BEGIN
        ALTER TABLE dbo.Acc_DayMaster WITH NOCHECK
            ADD CONSTRAINT CK_Acc_DayMaster_State CHECK (DayMState BETWEEN 0 AND 7);
        PRINT N'تحذير: Acc_DayMaster فيه حالات خارج 0-7؛ أُضيف القيد WITH NOCHECK.';
    END
    ELSE
        ALTER TABLE dbo.Acc_DayMaster WITH CHECK
            ADD CONSTRAINT CK_Acc_DayMaster_State CHECK (DayMState BETWEEN 0 AND 7);
END
ELSE PRINT N'CK_Acc_DayMaster_State موجود مسبقًا.';
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE name = N'CK_Acc_DayMasterState_State' AND parent_object_id = OBJECT_ID(N'dbo.Acc_DayMasterState'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Acc_DayMasterState WHERE DayMSState NOT BETWEEN 0 AND 7)
    BEGIN
        ALTER TABLE dbo.Acc_DayMasterState WITH NOCHECK
            ADD CONSTRAINT CK_Acc_DayMasterState_State CHECK (DayMSState BETWEEN 0 AND 7);
        PRINT N'تحذير: Acc_DayMasterState فيه حالات خارج 0-7؛ أُضيف القيد WITH NOCHECK.';
    END
    ELSE
        ALTER TABLE dbo.Acc_DayMasterState WITH CHECK
            ADD CONSTRAINT CK_Acc_DayMasterState_State CHECK (DayMSState BETWEEN 0 AND 7);
END
ELSE PRINT N'CK_Acc_DayMasterState_State موجود مسبقًا.';
GO

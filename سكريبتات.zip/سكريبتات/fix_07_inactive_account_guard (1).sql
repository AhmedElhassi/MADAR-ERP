﻿USE [MADARERPDataBase];
GO

/* =====================================================================
   حالة الحساب AccState: 0 فعّال ، 1 غير فعّال (العمود tinyint لإتاحة حالات أخرى لاحقًا).
   Acc_SaveDayVoucher: يرفض أي بند على حساب AccState <> 0 (خطأ 50115) ويذكر رمز الحساب واسمه.
   - يسري أيضًا على القيود الآلية من المخازن: ستفشل بخطأ واضح بدل الترحيل على حساب موقوف.
   - تعديل مسودة فيها حساب أُوقف لاحقًا يتطلب استبدال ذلك الحساب أولًا.
   - الإجراء مبني على نسخة fix_04 (فحص السنة المالية + سجل التاريخ)، فتنفيذه بعد fix_04.
   ===================================================================== */

/****** Object:  StoredProcedure [dbo].[Acc_SaveDayVoucher]    Script Date: 2026-11-13 11:31:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   1) حفظ القيد (مؤقت أو نهائي)
      يعيد صفًا واحدًا: DayMID, DayMNo, DayMState, VoucherNo
   ===================================================================== */
ALTER PROCEDURE [dbo].[Acc_SaveDayVoucher]
    @Cmp    INT,
    @Year   INT,
    @User   BIGINT,
    @DayMID BIGINT = 0,              -- 0 = قيد جديد
    @Date   DATE,
    @Info   NVARCHAR(MAX),
    @Post   BIT = 0,                 -- 0 = حفظ مؤقت ، 1 = حفظ نهائي
    @Lines  dbo.Acc_DayLineType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;      -- نستخدم نقطة حفظ عند وجود معاملة خارجية

    DECLARE @Cnt INT, @Deb DECIMAL(18,3), @Crd DECIMAL(18,3), @Msg NVARCHAR(400);

    SELECT @Cnt = COUNT(*),
           @Deb = ISNULL(SUM(DayDDeb), 0),
           @Crd = ISNULL(SUM(DayDCrd), 0)
    FROM @Lines;

    /* ---------- التحقق (قبل أي كتابة) ---------- */
    IF @Date IS NULL OR @Year IS NULL OR YEAR(@Date) <> @Year
        THROW 50101, N'تاريخ القيد يجب أن يقع داخل السنة المالية المحددة.', 1;

    /* [FY] السنة المالية للتاريخ الجديد يجب أن تكون مفتوحة */
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_FiscalYear
                   WHERE AccFCmpID = @Cmp AND AccFYear = YEAR(@Date) AND AccFState = 0)
        THROW 50130, N'السنة المالية للتاريخ المحدد مقفلة أو غير موجودة.', 1;

    IF NULLIF(LTRIM(RTRIM(ISNULL(@Info, N''))), N'') IS NULL
        THROW 50102, N'شرح القيد مطلوب.', 1;

    IF @Cnt = 0
        THROW 50103, N'أضف بندًا واحدًا على الأقل قبل الحفظ.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User)
        THROW 50112, N'المستخدم غير موجود.', 1;

    IF EXISTS (SELECT 1 FROM @Lines
               WHERE DayDDeb < 0 OR DayDCrd < 0
                  OR (DayDDeb = 0 AND DayDCrd = 0)
                  OR (DayDDeb > 0 AND DayDCrd > 0))
        THROW 50106, N'يوجد بند قيمته غير صحيحة: مدين أو دائن فقط، وأكبر من صفر.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE NOT EXISTS (SELECT 1 FROM dbo.Acc_Account AS a
                                 WHERE a.AccID = l.DayDAccID AND a.AccCompany = @Cmp))
        THROW 50104, N'يوجد بند على حساب غير موجود أو لا يتبع الشركة.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE EXISTS (SELECT 1 FROM dbo.Acc_Account AS c WHERE c.AccParentID = l.DayDAccID))
        THROW 50105, N'لا يجوز القيد على حساب أب، اختر حسابًا تحليليًا.', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
               WHERE NOT (   (a.AccEnd = 1 AND a.AccType IN (0, 1, 2))
                          OR (a.AccEnd = 2 AND a.AccType IN (0, 1))))
        THROW 50108, N'يوجد بند على حساب تصنيفه المالي غير صحيح (AccEnd / AccType).', 1;

    IF EXISTS (SELECT 1 FROM @Lines AS l
               WHERE l.DayDCsCID IS NOT NULL
                 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_CostCenter AS c
                                 WHERE c.CsCID = l.DayDCsCID AND c.CsCCompany = @Cmp))
        THROW 50109, N'يوجد بند على مركز تكلفة غير موجود أو لا يتبع الشركة.', 1;

    /* [ACC] لا قيد على حساب غير فعّال: AccState <> 0 (0 فعّال، 1 غير فعّال، وأي حالة مستقبلية تُمنع افتراضيًا
       كما تفعل قوائم اختيار الحسابات التي تعرض الحالة 0 فقط) */
    IF EXISTS (SELECT 1 FROM @Lines AS l
               JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
               WHERE a.AccState <> 0)
    BEGIN
        SELECT TOP (1) @Msg = CONCAT(N'لا يجوز القيد على حساب غير فعّال: ', a.AccCode, N' - ', a.AccName)
        FROM @Lines AS l
        JOIN dbo.Acc_Account AS a ON a.AccID = l.DayDAccID
        WHERE a.AccState <> 0
        ORDER BY l.SeqNo;

        THROW 50115, @Msg, 1;
    END;

    /* حسابات النظام (توجيهات حسابية): لا يجوز القيد اليدوي عليها إلا من إجراء النظام.
       علامة النظام: sp_set_session_context 'Acc.SystemOperation' = 1 */
    IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Acc.SystemOperation')), 0) <> 1
       AND EXISTS (SELECT 1
                   FROM @Lines AS l
                   JOIN dbo.Acc_PostingRule  AS r ON r.AccID = l.DayDAccID
                   JOIN dbo.Acc_PostingState AS s ON s.StateID = r.StateID
                   WHERE s.AllowManualPosting = 0)
        THROW 50114, N'يوجد بند على حساب نظام لا يقبل القيد اليدوي (مثل حسابات الموردين والزبائن). يُرحَّل عليه من العملية الخاصة به فقط.', 1;

    IF @Post = 1
    BEGIN
        IF @Cnt < 2
            THROW 50107, N'القيد النهائي يحتاج بندين على الأقل.', 1;

        IF @Deb <> @Crd
        BEGIN
            SET @Msg = CONCAT(N'لا يمكن الحفظ النهائي لقيد غير متوازن. الفرق: ',
                              CONVERT(NVARCHAR(40), @Deb - @Crd));
            THROW 50111, @Msg, 1;
        END;
    END;

    /* ---------- الكتابة ---------- */
    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0
    BEGIN
        BEGIN TRAN;
        SET @Started = 1;
    END
    ELSE
        SAVE TRANSACTION Sp_SaveDayVoucher;

    BEGIN TRY
        DECLARE @OldDate DATE, @OldState TINYINT, @OldNo INT, @No INT, @State TINYINT;

        IF @DayMID > 0
        BEGIN
            SELECT @OldDate = m.DayMDate, @OldState = m.DayMState, @OldNo = m.DayMNo
            FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
            WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

            IF @OldState IS NULL
                THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;

            IF @OldState NOT IN (0, 2)
                THROW 50121, N'لا يمكن تعديل القيد في حالته الحالية (يُعدَّل المؤقت والمُعاد من المراجعة فقط).', 1;

            /* [FY] التاريخ القديم للقيد يجب ألا يتبع سنة مقفلة */
            IF NOT EXISTS (SELECT 1 FROM dbo.Acc_FiscalYear
                           WHERE AccFCmpID = @Cmp AND AccFYear = YEAR(@OldDate) AND AccFState = 0)
                THROW 50131, N'القيد الأصلي يتبع سنة مالية مقفلة أو غير موجودة.', 1;
        END;

        /* [HIST] سجل التاريخ للقيود اليدوية فقط (لا القيود الآلية من المخازن) */
        DECLARE @LogIt BIT =
            CASE WHEN ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'Wrh.AutoGen')), 0) <> 1
                  AND NOT EXISTS (SELECT 1 FROM dbo.Acc_AutoVoucher WHERE AvDayMID = NULLIF(@DayMID, 0))
                 THEN 1 ELSE 0 END;
        DECLARE @IsNew BIT = CASE WHEN @DayMID = 0 THEN 1 ELSE 0 END;

        DECLARE @MS DATE = DATEFROMPARTS(YEAR(@Date), MONTH(@Date), 1);
        DECLARE @ME DATE = DATEADD(MONTH, 1, @MS);

        SET @No = ISNULL(@OldNo, 0);
        SET @State = CASE WHEN @Post = 1 THEN CAST(1 AS TINYINT) ELSE ISNULL(@OldState, CAST(0 AS TINYINT)) END;

        DECLARE @MonthChanged BIT =
            CASE WHEN @OldDate IS NOT NULL
                  AND DATEFROMPARTS(YEAR(@OldDate), MONTH(@OldDate), 1) <> @MS THEN 1 ELSE 0 END;

        IF @Post = 1 AND (@No = 0 OR @MonthChanged = 1)
        BEGIN
            -- رقم القيد = أكبر رقم في الشهر نفسه للشركة + 1 (القفل يمنع تكرار الرقم عند الحفظ المتزامن)
            SELECT @No = ISNULL(MAX(m.DayMNo), 0) + 1
            FROM dbo.Acc_DayMaster AS m WITH (UPDLOCK, HOLDLOCK)
            WHERE m.DayMCompany = @Cmp AND m.DayMDate >= @MS AND m.DayMDate < @ME;
        END
        ELSE IF @Post = 0 AND @No > 0 AND @MonthChanged = 1
            SET @No = 0;     -- رقم الشهر القديم لا يصلح للشهر الجديد؛ يُعاد توليده عند الترحيل

        IF @DayMID = 0
        BEGIN
            INSERT dbo.Acc_DayMaster (DayMDate, DayMDescription, DayMNo, DayMState, DayMUser, DayMCompany)
            VALUES (@Date, @Info, @No, @State, @User, @Cmp);

            SET @DayMID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            /* [HIST] تعديل (2): صورة القيد وبنوده قبل التعديل */
            IF @LogIt = 1
            BEGIN
                INSERT dbo.Acc_DayMasterHistory
                    (DayMHOpration, DayMHMID, DayMHMDate, DayMHMDescription, DayMHState, DayMHUser, DayMHNo, DayMHCompany)
                SELECT 2, m.DayMID, m.DayMDate, m.DayMDescription, m.DayMState, @User, m.DayMNo, m.DayMCompany
                FROM dbo.Acc_DayMaster AS m
                WHERE m.DayMID = @DayMID;

                INSERT dbo.Acc_DayDetailsHistory
                    (DayDHOpration, DayHDDID, DayDHMID, DayDHAccID, DayDHDeb, DayDHCrd, DayDHCsCID, DayDHNum, DayDHDescription, DayDHState, DayDHUser)
                SELECT 2, d.DayDID, d.DayDMID, d.DayDAccID, d.DayDDeb, d.DayDCrd, d.DayDCsCID, d.DayDNum, d.DayDDescription, @OldState, @User
                FROM dbo.Acc_DayDetails AS d
                WHERE d.DayDMID = @DayMID;
            END;

            UPDATE dbo.Acc_DayMaster
            SET DayMDate = @Date, DayMDescription = @Info, DayMNo = @No, DayMState = @State
            WHERE DayMID = @DayMID AND DayMCompany = @Cmp;

            DELETE dbo.Acc_DayDetails WHERE DayDMID = @DayMID;
        END;

        INSERT dbo.Acc_DayDetails (DayDMID, DayDAccID, DayDDeb, DayDCrd, DayDCsCID, DayDNum, DayDDescription)
        SELECT @DayMID, l.DayDAccID, l.DayDDeb, l.DayDCrd, l.DayDCsCID, l.DayDNum, l.DayDDescription
        FROM @Lines AS l
        ORDER BY l.SeqNo;

        /* [HIST] إنشاء (1): صورة القيد الجديد وبنوده بعد الحفظ */
        IF @LogIt = 1 AND @IsNew = 1
        BEGIN
            INSERT dbo.Acc_DayMasterHistory
                (DayMHOpration, DayMHMID, DayMHMDate, DayMHMDescription, DayMHState, DayMHUser, DayMHNo, DayMHCompany)
            SELECT 1, m.DayMID, m.DayMDate, m.DayMDescription, m.DayMState, @User, m.DayMNo, m.DayMCompany
            FROM dbo.Acc_DayMaster AS m
            WHERE m.DayMID = @DayMID;

            INSERT dbo.Acc_DayDetailsHistory
                (DayDHOpration, DayHDDID, DayDHMID, DayDHAccID, DayDHDeb, DayDHCrd, DayDHCsCID, DayDHNum, DayDHDescription, DayDHState, DayDHUser)
            SELECT 1, d.DayDID, d.DayDMID, d.DayDAccID, d.DayDDeb, d.DayDCrd, d.DayDCsCID, d.DayDNum, d.DayDDescription, @State, @User
            FROM dbo.Acc_DayDetails AS d
            WHERE d.DayDMID = @DayMID;
        END;

        -- فحص أخير من الجدول نفسه: لا يُرحَّل قيد غير متوازن مهما حدث
        IF @Post = 1
        BEGIN
            IF (SELECT SUM(DayDDeb) - SUM(DayDCrd) FROM dbo.Acc_DayDetails WHERE DayDMID = @DayMID) <> 0
                THROW 50113, N'القيد غير متوازن بعد الحفظ؛ أُلغي الترحيل.', 1;
        END;
        IF @Post = 1
        BEGIN
            INSERT INTO dbo.Acc_DayMasterState
            (
                DayMSDayMID,
                DayMSState,
                DayMSReason,
                DayMSUser
            )
            VALUES
            (
                @DayMID,
                @State,
                NULL,
                @User
            );
        END;
        IF @Started = 1 COMMIT;

        SELECT @DayMID AS DayMID,
               @No     AS DayMNo,
               @State  AS DayMState,
               CASE WHEN @No > 0
                    THEN CONCAT(@No, N'/', RIGHT(CONCAT(N'0', MONTH(@Date)), 2))
                    ELSE N'' END AS VoucherNo;
    END TRY
    BEGIN CATCH
        IF @Started = 1
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK;
        END
        ELSE IF XACT_STATE() = 1
            ROLLBACK TRANSACTION Sp_SaveDayVoucher;

        THROW;
    END CATCH;
END;

GO

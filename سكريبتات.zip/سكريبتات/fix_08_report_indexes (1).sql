USE [MADARERPDataBase];
GO

/* =====================================================================
   البند 8: فهارس التقارير على Acc_DayDetails (فهارس شاملة Covering)
   الفهارس الحالية بمفتاح واحد فقط، فكل صف مطابق يحتاج قراءة إضافية من الجدول
   لجلب المدين والدائن. تُستبدل بنفس الأسماء بفهارس تضم الأعمدة التي تقرأها
   التقارير (ميزان المراجعة، كشف الحساب، كشف مركز التكلفة).

     IX_Acc_DayDetails_DayDMID  (DayDMID)   INCLUDE (DayDAccID, DayDDeb, DayDCrd, DayDCsCID)
         ← ميزان المراجعة والقوائم المالية (وهو الفهرس الذي يوصي به تعليق Acc_Select_Trial_Balance)
     IX_Acc_DayDetails_DayDAccID (DayDAccID) INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID)
         ← كشف الحساب وتحليله
     IX_Acc_DayDetails_DayDCsCID (DayDCsCID) INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd)
         ← كشف مركز التكلفة وتحليله

   لا يمسّ البيانات. يزيد حجم الفهارس قليلًا ويزيد كلفة الكتابة قليلًا.
   يمكن إعادة التشغيل: يتجاوز الفهرس إن كان شاملًا مسبقًا.
   ===================================================================== */

-- الفهرس 1: حسب القيد
IF INDEXPROPERTY(OBJECT_ID(N'dbo.Acc_DayDetails'), N'IX_Acc_DayDetails_DayDMID', N'IndexID') IS NULL
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDMID
        ON dbo.Acc_DayDetails (DayDMID)
        INCLUDE (DayDAccID, DayDDeb, DayDCrd, DayDCsCID);
ELSE IF NOT EXISTS (SELECT 1 FROM sys.indexes i
                    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                    WHERE i.object_id = OBJECT_ID(N'dbo.Acc_DayDetails')
                      AND i.name = N'IX_Acc_DayDetails_DayDMID' AND ic.is_included_column = 1)
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDMID
        ON dbo.Acc_DayDetails (DayDMID)
        INCLUDE (DayDAccID, DayDDeb, DayDCrd, DayDCsCID)
        WITH (DROP_EXISTING = ON);
ELSE PRINT N'IX_Acc_DayDetails_DayDMID شامل مسبقًا.';
GO

-- الفهرس 2: حسب الحساب
IF INDEXPROPERTY(OBJECT_ID(N'dbo.Acc_DayDetails'), N'IX_Acc_DayDetails_DayDAccID', N'IndexID') IS NULL
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDAccID
        ON dbo.Acc_DayDetails (DayDAccID)
        INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID);
ELSE IF NOT EXISTS (SELECT 1 FROM sys.indexes i
                    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                    WHERE i.object_id = OBJECT_ID(N'dbo.Acc_DayDetails')
                      AND i.name = N'IX_Acc_DayDetails_DayDAccID' AND ic.is_included_column = 1)
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDAccID
        ON dbo.Acc_DayDetails (DayDAccID)
        INCLUDE (DayDMID, DayDDeb, DayDCrd, DayDCsCID)
        WITH (DROP_EXISTING = ON);
ELSE PRINT N'IX_Acc_DayDetails_DayDAccID شامل مسبقًا.';
GO

-- الفهرس 3: حسب مركز التكلفة
IF INDEXPROPERTY(OBJECT_ID(N'dbo.Acc_DayDetails'), N'IX_Acc_DayDetails_DayDCsCID', N'IndexID') IS NULL
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDCsCID
        ON dbo.Acc_DayDetails (DayDCsCID)
        INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd);
ELSE IF NOT EXISTS (SELECT 1 FROM sys.indexes i
                    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                    WHERE i.object_id = OBJECT_ID(N'dbo.Acc_DayDetails')
                      AND i.name = N'IX_Acc_DayDetails_DayDCsCID' AND ic.is_included_column = 1)
    CREATE NONCLUSTERED INDEX IX_Acc_DayDetails_DayDCsCID
        ON dbo.Acc_DayDetails (DayDCsCID)
        INCLUDE (DayDMID, DayDAccID, DayDDeb, DayDCrd)
        WITH (DROP_EXISTING = ON);
ELSE PRINT N'IX_Acc_DayDetails_DayDCsCID شامل مسبقًا.';
GO

-- تحقق: الفهارس الثلاثة وأعمدتها
SELECT i.name AS IndexName,
       STUFF((SELECT N', ' + c.name FROM sys.index_columns ic
              JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
              WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
              ORDER BY ic.key_ordinal FOR XML PATH(N'')), 1, 2, N'') AS KeyCols,
       STUFF((SELECT N', ' + c.name FROM sys.index_columns ic
              JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
              WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 1
              ORDER BY c.column_id FOR XML PATH(N'')), 1, 2, N'') AS IncludedCols
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID(N'dbo.Acc_DayDetails') AND i.name LIKE N'IX[_]Acc[_]DayDetails[_]%'
ORDER BY i.name;
GO

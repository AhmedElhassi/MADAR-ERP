﻿USE [MADARERPDataBase];
GO

/* =====================================================================
   Acc_DeleteAccounting: رسائل عربية واضحة عند ارتباط الحساب بجداول أخرى
   (بدل خطأ المفتاح الأجنبي التقني من SQL Server)

     50017 سجل تاريخ القيود Acc_DayDetailsHistory   ← ينتج عن fix_04
     50018 توجيه حسابي Acc_PostingRule
     50019 تصنيف التدفقات النقدية Acc_CashFlowAccounts
     50021 طرف Prt_Party        50022 مخزن Wrh_Warehouse
     50023 مجموعة أصناف Wrh_ItemGroup        50024 إعدادات المخازن Wrh_Settings

   ملاحظة: بعد fix_04 صار حساب استُخدم في قيد يدوي عُدّل أو حُذف لا يُحذف أبدًا
   (سجل التاريخ يحتفظ بمرجعه). هذا مقصود لحماية التدقيق. ولو أردت حذف مثل هذا
   الحساب فاحذف المفتاح FK_Acc_DayDetailsHistory_Account وأزل فحص 50017.
   ===================================================================== */

/****** Object:  StoredProcedure [dbo].[Acc_DeleteAccounting]    Script Date: 2026-11-13 11:31:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[Acc_DeleteAccounting]
    @original_AccID BIGINT,
    @AccUser BIGINT,
    @Cmp INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @ParentID BIGINT,
        @ParentChid SMALLINT,
        @AccCompany INT;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- التحقق من الحساب وقفل سجله
        SELECT
            @ParentID = AccParentID,
            @AccCompany = AccCompany
        FROM dbo.Acc_Account WITH (UPDLOCK, HOLDLOCK)
        WHERE AccID = @original_AccID
          AND AccCompany = @Cmp;

        IF @@ROWCOUNT = 0
            THROW 50001, N'الحساب غير موجود أو لا يتبع الشركة المحددة.', 1;

        -- منع حذف الحساب إذا كان لديه أبناء
        IF EXISTS
        (
            SELECT 1
            FROM dbo.Acc_Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccParentID = @original_AccID
        )
            THROW 50002, N'لا يمكن حذف الحساب لوجود حسابات فرعية مرتبطة به.', 1;

        -- منع حذف الحساب إذا كانت له حركات محاسبية
        IF EXISTS
        (
            SELECT 1
            FROM dbo.Acc_DayDetails WITH (UPDLOCK, HOLDLOCK)
            WHERE DayDAccID = @original_AccID
        )
            THROW 50003, N'لا يمكن حذف الحساب لوجود حركات محاسبية مرتبطة به.', 1;

        -- [FK] منع الحذف برسائل واضحة بدل خطأ المفتاح الأجنبي
        IF EXISTS (SELECT 1 FROM dbo.Acc_DayDetailsHistory WHERE DayDHAccID = @original_AccID)
            THROW 50017, N'لا يمكن حذف الحساب لوجوده في سجل تاريخ القيود (قيود عُدّلت أو حُذفت).', 1;

        IF EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @original_AccID)
            THROW 50018, N'لا يمكن حذف الحساب لارتباطه بتوجيه حسابي (قاعدة ترحيل).', 1;

        IF EXISTS (SELECT 1 FROM dbo.Acc_CashFlowAccounts WHERE AccID = @original_AccID)
            THROW 50019, N'لا يمكن حذف الحساب لارتباطه بتصنيف التدفقات النقدية.', 1;

        IF EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtAccID = @original_AccID)
            THROW 50021, N'لا يمكن حذف الحساب لارتباطه بطرف (مورد أو زبون).', 1;

        IF EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhAccID = @original_AccID)
            THROW 50022, N'لا يمكن حذف الحساب لارتباطه بمخزن.', 1;

        IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpAccID = @original_AccID)
            THROW 50023, N'لا يمكن حذف الحساب لارتباطه بمجموعة أصناف.', 1;

        IF EXISTS (SELECT 1 FROM dbo.Wrh_Settings
                   WHERE @original_AccID IN (WsDiffAccID, WsCreditNoteAccID, WsCountAccID))
            THROW 50024, N'لا يمكن حذف الحساب لارتباطه بإعدادات المخازن.', 1;

        -- التحقق من عداد أبناء الحساب الأب
        IF @ParentID IS NOT NULL
        BEGIN
            SELECT @ParentChid = AccChid
            FROM dbo.Acc_Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccID = @ParentID
              AND AccCompany = @Cmp;

            IF @@ROWCOUNT = 0
                THROW 50004, N'الحساب الأب غير موجود أو لا يتبع الشركة المحددة.', 1;

            IF @ParentChid <= 0
                THROW 50005, N'عداد الحسابات الفرعية للأب غير متسق مع بيانات الحساب.', 1;
        END;

        -- حفظ بيانات الحساب في سجل التاريخ قبل الحذف
        INSERT INTO dbo.Acc_AccountHistory
        (
            AccHOpration,
            AccHAccID,
            AccHEnd,
            AccHType,
            AccHParentID,
            AccHOrder,
            AccHLevel,
            AccHChid,
            AccHCode,
            AccHName,
            AccHState,
            AccHDateTime,
            AccHUser,
            AccHCompany
        )
        SELECT
            6,
            AccID,
            AccEnd,
            AccType,
            AccParentID,
            AccOrder,
            AccLevel,
            AccChid,
            AccCode,
            AccName,
            AccState,
            SYSUTCDATETIME(),
            @AccUser,
            AccCompany
        FROM dbo.Acc_Account
        WHERE AccID = @original_AccID;

        -- حذف الحساب
        DELETE FROM dbo.Acc_Account
        WHERE AccID = @original_AccID
          AND AccCompany = @Cmp;

        IF @@ROWCOUNT = 0
            THROW 50006, N'تعذر حذف الحساب.', 1;

        -- تحديث عداد أبناء الحساب الأب
        IF @ParentID IS NOT NULL
        BEGIN
            UPDATE dbo.Acc_Account
            SET AccChid = AccChid - 1
            WHERE AccID = @ParentID
              AND AccCompany = @Cmp;
        END;

        -- إعادة ترتيب الحسابات المتبقية تحت الأب نفسه
        -- أو الحسابات الجذرية إذا كان الحساب المحذوف جذريًا
        ;WITH OrderedAccounts AS
        (
            SELECT
                AccID,
                ROW_NUMBER() OVER
                (
                    ORDER BY AccOrder, AccID
                ) AS NewOrder
            FROM dbo.Acc_Account
            WHERE
                (
                    (@ParentID IS NULL AND AccParentID IS NULL)
                    OR
                    (AccParentID = @ParentID)
                )
                AND AccCompany = @Cmp
        )
        UPDATE A
        SET AccOrder = O.NewOrder
        FROM dbo.Acc_Account AS A
        INNER JOIN OrderedAccounts AS O
            ON O.AccID = A.AccID;

        -- إعادة تنسيق أكواد الحسابات
        EXEC dbo.Acc_UpdateAccountCode @AccCompany = @Cmp;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

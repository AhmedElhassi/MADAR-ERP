﻿USE [MADARERPDataBase];
GO

/* =====================================================================
   نقل قواعد الربط والإجراءات من أرقام العمليات القديمة إلى الجديدة
   (يتطلب تنفيذ fix_10_add_operations.sql أولًا)

   القديم -> الجديد (للقواعد الموجودة عندك والإجراءات):
     1  المخازن             -> 202        2  الموردين        -> 201
     15 مواد تشغيل          -> 203        17 الدائنون المتنوعون -> 408

   الخطوات:
     1) نقل صفوف Acc_PostingRule (داخل معاملة) مع فحص وجود الأرقام الجديدة
     2) ALTER للإجراءات الأربعة: Wrh_SaveWarehouse ، Wrh_SaveItemGroup ،
        Prt_SaveParty ، Wrh_EnsurePartyAccounts
     3) استعلام يعرض ما بقي من العمليات القديمة بلا قواعد (للحذف لاحقًا بعد اختبار التطبيق)

   - نفّذه والنظام خارج الاستخدام: بين الخطوتين 1 و2 تفشل أي عملية إنشاء حساب نظامي لحظيًا.
   - لا يحذف العمليات القديمة. احذفها بعد التأكد أن التطبيق لا يستعمل أرقامها.
   - إن كان التطبيق يحمل أرقام العمليات القديمة ثابتة في كوده، فعدّلها بالمثل.
   خذ نسخة احتياطية قبل التنفيذ.
   ===================================================================== */

-- الخطوة 1: نقل القواعد
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRAN;

    IF (SELECT COUNT(*) FROM dbo.Acc_Operation WHERE OpID IN (201, 202, 203, 408)) <> 4
        THROW 60020, N'الأرقام الجديدة غير موجودة في Acc_Operation؛ نفّذ fix_10_add_operations.sql أولًا.', 1;

    DECLARE @Map TABLE (OldOp SMALLINT PRIMARY KEY, NewOp SMALLINT NOT NULL);
    INSERT @Map (OldOp, NewOp) VALUES (1, 202), (2, 201), (15, 203), (17, 408);

    -- معاينة ما سيُنقل
    SELECT r.RuleID, r.OpID AS OldOp, m.NewOp, r.AccID, r.StateID
    FROM dbo.Acc_PostingRule AS r JOIN @Map AS m ON m.OldOp = r.OpID
    ORDER BY r.RuleID;

    UPDATE r SET r.OpID = m.NewOp
    FROM dbo.Acc_PostingRule AS r JOIN @Map AS m ON m.OldOp = r.OpID;

    PRINT CONCAT(N'نُقلت ', @@ROWCOUNT, N' قاعدة ربط.');
    COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH;
GO

-- الخطوة 2: الإجراءات
/****** Object:  StoredProcedure [dbo].[Wrh_SaveWarehouse]    Script Date: 2026-11-13 11:31:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ------------------------------------------------------------------ المخازن */
ALTER PROCEDURE [dbo].[Wrh_SaveWarehouse]
    @Cmp INT, @User BIGINT, @WhID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Keeper BIGINT = NULL, @Active BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@WhID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @wn INT = ISNULL((SELECT MAX(TRY_CAST(WhCode AS INT)) FROM dbo.Wrh_Warehouse WHERE WhCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @wn), CASE WHEN LEN(CAST(@wn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@wn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المخزن غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF @Keeper IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @Keeper)
        THROW 52200, N'أمين المخزن غير موجود.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhCmpID = @Cmp AND WhCode = @Code AND WhID <> ISNULL(@WhID, 0))
        THROW 52204, N'كود المخزن مستخدم من قبل.', 1;

    DECLARE @Started BIT = 0, @New BIGINT;
    DECLARE @CurW BIGINT;
    IF ISNULL(@WhID, 0) <> 0
    BEGIN
        SELECT @CurW = WhAccID FROM dbo.Wrh_Warehouse WHERE WhID = @WhID AND WhCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'المخزن غير موجود أو لا يتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveWarehouse;
    BEGIN TRY
        IF ISNULL(@WhID, 0) = 0
        BEGIN
            IF @AccID IS NULL
            BEGIN
                EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 202, @Name, @New OUTPUT;   -- 1 المخازن
                SET @AccID = @New;
            END
            INSERT dbo.Wrh_Warehouse (WhCmpID, WhCode, WhName, WhAccID, WhKeeper, WhActive)
            VALUES (@Cmp, @Code, @Name, @AccID, @Keeper, ISNULL(@Active, 1));
            SET @WhID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE dbo.Wrh_Warehouse
               SET WhCode = @Code, WhName = @Name, WhAccID = COALESCE(@AccID, WhAccID), WhKeeper = @Keeper, WhActive = ISNULL(@Active, 1)
             WHERE WhID = @WhID AND WhCmpID = @Cmp;
            -- مزامنة اسم حساب النظام مع اسم المخزن
            IF @CurW IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @CurW AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @CurW AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @CurW, @User, @Cmp;
        END
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveWarehouse;
        THROW;
    END CATCH
    SELECT @WhID AS WhID;
END;

GO

/****** Object:  StoredProcedure [dbo].[Wrh_SaveItemGroup]    Script Date: 2026-11-13 11:31:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[Wrh_SaveItemGroup]
    @Cmp INT, @User BIGINT, @GrpID BIGINT, @ParentID BIGINT = NULL, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @AccID BIGINT = NULL, @Active BIT = 1, @Whs NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@GrpID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @gn INT = ISNULL((SELECT MAX(TRY_CAST(GrpCode AS INT)) FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @gn), CASE WHEN LEN(CAST(@gn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@gn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب المجموعة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpCmpID = @Cmp AND GrpCode = @Code AND GrpID <> ISNULL(@GrpID, 0))
        THROW 52204, N'كود المجموعة مستخدم من قبل.', 1;

    -- الأب: للشركة نفسها، لا يحمل أصنافًا، ولا حلقة
    IF @ParentID IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID AND GrpCmpID = @Cmp)
            THROW 52207, N'المجموعة الأب غير موجودة أو لا تتبع الشركة.', 1;
        IF EXISTS (SELECT 1 FROM dbo.Wrh_Item WHERE ItemGrpID = @ParentID)
            THROW 52207, N'المجموعة الأب تحمل أصنافًا فلا تقبل مجموعات فرعية.', 1;
        IF ISNULL(@GrpID, 0) > 0
        BEGIN
            DECLARE @Cyc INT = 0;
            ;WITH D AS
            (
                SELECT GrpID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID
                UNION ALL
                SELECT g.GrpID FROM dbo.Wrh_ItemGroup AS g JOIN D ON g.GrpParentID = D.GrpID
            )
            SELECT @Cyc = COUNT(*) FROM D WHERE GrpID = @ParentID;
            IF @Cyc > 0 THROW 52207, N'لا يجوز جعل المجموعة أبًا لنفسها أو لأحد فروعها.', 1;
        END
    END

    -- مخازن المجموعة: NULL = لا يُمسّ الربط؛ وإن مُرّرت فيجب أن يوجد مخزن واحد صحيح على الأقل
    DECLARE @W TABLE (WhID BIGINT PRIMARY KEY);
    IF @Whs IS NOT NULL
    BEGIN
        INSERT @W SELECT DISTINCT TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) FROM STRING_SPLIT(@Whs, N',')
                  WHERE TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) IS NOT NULL;
        IF NOT EXISTS (SELECT 1 FROM @W) THROW 52230, N'مخزن واحد على الأقل مطلوب للمجموعة.', 1;
        IF EXISTS (SELECT 1 FROM @W AS x WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = x.WhID AND WhCmpID = @Cmp))
            THROW 52230, N'مخزن غير موجود أو لا يتبع الشركة.', 1;
    END

    DECLARE @Started BIT = 0, @New BIGINT, @Cur BIGINT, @PAcc BIGINT, @PName NVARCHAR(200), @IsNew BIT = 0;
    IF ISNULL(@GrpID, 0) <> 0
    BEGIN
        SELECT @Cur = GrpAccID FROM dbo.Wrh_ItemGroup WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'المجموعة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_SaveItemGroup;
    BEGIN TRY
        -- حساب المصروف آلي (عملية 15 مواد تشغيل) إن لم يُمرَّر ولم يكن للمجموعة حساب
        IF @ParentID IS NOT NULL
        BEGIN
            -- فرعية: تستعمل حساب الأب (يُنشأ للأب إن لم يوجد)
            SELECT @PAcc = GrpAccID, @PName = GrpName FROM dbo.Wrh_ItemGroup WHERE GrpID = @ParentID;
            IF @PAcc IS NULL
            BEGIN
                EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 203, @PName, @New OUTPUT;
                UPDATE dbo.Wrh_ItemGroup SET GrpAccID = @New WHERE GrpID = @ParentID;
                SET @PAcc = @New;
            END
            SET @AccID = @PAcc;
        END
        ELSE IF @AccID IS NULL AND @Cur IS NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, 203, @Name, @New OUTPUT;
            SET @AccID = @New;
        END
        IF ISNULL(@GrpID, 0) = 0
        BEGIN
            INSERT dbo.Wrh_ItemGroup (GrpCmpID, GrpParentID, GrpCode, GrpName, GrpAccID, GrpActive)
            VALUES (@Cmp, @ParentID, @Code, @Name, @AccID, ISNULL(@Active, 1));
            SET @GrpID = SCOPE_IDENTITY(); SET @IsNew = 1;
        END
        ELSE
        BEGIN
            UPDATE dbo.Wrh_ItemGroup
               SET GrpParentID = @ParentID, GrpCode = @Code, GrpName = @Name, GrpAccID = CASE WHEN @ParentID IS NOT NULL THEN @AccID ELSE COALESCE(@AccID, GrpAccID) END, GrpActive = ISNULL(@Active, 1)
             WHERE GrpID = @GrpID AND GrpCmpID = @Cmp;
            -- مزامنة اسم حساب النظام مع اسم المجموعة
            IF @ParentID IS NULL AND @Cur IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @Cur AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @Cur AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @Cur, @User, @Cmp;
        END
        IF @Whs IS NOT NULL
        BEGIN
            DELETE dbo.Wrh_GroupWarehouse WHERE GwGrpID = @GrpID AND GwWhID NOT IN (SELECT WhID FROM @W);
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT @GrpID, WhID FROM @W AS x
            WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @GrpID AND GwWhID = x.WhID);
        END
        -- تغيير مخازن الرئيسية يسري على فروعها (الفرع يتبع أباه)
        IF @Whs IS NOT NULL AND @ParentID IS NULL
        BEGIN
            DELETE l FROM dbo.Wrh_GroupWarehouse AS l JOIN dbo.Wrh_ItemGroup AS c ON c.GrpID = l.GwGrpID
             WHERE c.GrpParentID = @GrpID AND l.GwWhID NOT IN (SELECT WhID FROM @W);
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT c.GrpID, w.WhID FROM dbo.Wrh_ItemGroup AS c CROSS JOIN @W AS w
             WHERE c.GrpParentID = @GrpID
               AND NOT EXISTS (SELECT 1 FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = c.GrpID AND GwWhID = w.WhID);
        END
        -- فرعية جديدة بلا مخازن مُمرَّرة: تنسخ روابط الأب
        IF @Whs IS NULL AND @IsNew = 1 AND @ParentID IS NOT NULL
            INSERT dbo.Wrh_GroupWarehouse (GwGrpID, GwWhID)
            SELECT @GrpID, GwWhID FROM dbo.Wrh_GroupWarehouse WHERE GwGrpID = @ParentID;
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_SaveItemGroup;
        THROW;
    END CATCH
    SELECT @GrpID AS GrpID;
END;

GO

/****** Object:  StoredProcedure [dbo].[Prt_SaveParty]    Script Date: 2026-11-13 11:31:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[Prt_SaveParty]
    @Cmp INT, @User BIGINT, @PrtID BIGINT, @Code NVARCHAR(30), @Name NVARCHAR(200),
    @Role TINYINT, @AccID BIGINT = NULL, @Active BIT = 1, @Whs NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 THROW 52201, N'الشركة غير صحيحة.', 1;
    IF ISNULL(@User, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52200, N'المستخدم غير موجود.', 1;
    SET @Code = LTRIM(RTRIM(@Code)); SET @Name = LTRIM(RTRIM(@Name));
    IF ISNULL(@Name, N'') = N'' THROW 52202, N'الاسم مطلوب.', 1;
    IF ISNULL(@Code, N'') = N'' AND ISNULL(@PrtID, 0) <> 0 THROW 52202, N'الكود مطلوب.', 1;
    IF ISNULL(@Code, N'') = N''
    BEGIN   -- كود آلي: الرقم التالي للشركة بأربع خانات على الأقل
        DECLARE @pn INT = ISNULL((SELECT MAX(TRY_CAST(PrtCode AS INT)) FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp), 0) + 1;
        SET @Code = RIGHT(CONCAT(N'0000', @pn), CASE WHEN LEN(CAST(@pn AS NVARCHAR(10))) > 4 THEN LEN(CAST(@pn AS NVARCHAR(10))) ELSE 4 END);
    END
    IF @Role IS NULL OR @Role NOT IN (1, 2, 3) THROW 52203, N'نوع الجهة غير صحيح (1 مورد، 2 جهة خدمات، 3 موظف عهدة).', 1;
    -- مخازن المورد (للموردين فقط): NULL = لا يُمسّ الربط؛ وإن مُرّرت فيجب أن يوجد مخزن واحد صحيح على الأقل
    DECLARE @W TABLE (WhID BIGINT PRIMARY KEY);
    IF @Role = 1 AND @Whs IS NOT NULL
    BEGIN
        INSERT @W SELECT DISTINCT TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) FROM STRING_SPLIT(@Whs, N',')
                  WHERE TRY_CAST(LTRIM(RTRIM(value)) AS BIGINT) IS NOT NULL;
        IF NOT EXISTS (SELECT 1 FROM @W) THROW 52240, N'مخزن واحد على الأقل مطلوب للمورد.', 1;
        IF EXISTS (SELECT 1 FROM @W AS x WHERE NOT EXISTS (SELECT 1 FROM dbo.Wrh_Warehouse WHERE WhID = x.WhID AND WhCmpID = @Cmp))
            THROW 52240, N'مخزن غير موجود أو لا يتبع الشركة.', 1;
    END
    IF @AccID IS NOT NULL AND (NOT EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @AccID)
                               OR EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccParentID = @AccID))
        THROW 52205, N'حساب الجهة غير موجود أو ليس حسابًا ورقيًا.', 1;
    IF EXISTS (SELECT 1 FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp AND PrtCode = @Code AND PrtID <> ISNULL(@PrtID, 0))
        THROW 52204, N'كود الجهة مستخدم من قبل.', 1;

    DECLARE @Op SMALLINT = CASE @Role WHEN 1 THEN 201 WHEN 2 THEN 408 END; -- 201 الموردين ، 408 الدائنون المتنوعون
    DECLARE @Started BIT = 0, @Cur BIGINT, @New BIGINT;
    IF ISNULL(@PrtID, 0) <> 0
    BEGIN
        SELECT @Cur = PrtAccID FROM dbo.Prt_Party WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;
        IF @@ROWCOUNT = 0 THROW 52206, N'الجهة غير موجودة أو لا تتبع الشركة.', 1;
    END

    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Prt_SaveParty;
    BEGIN TRY
        IF @AccID IS NULL AND @Cur IS NULL AND @Op IS NOT NULL
        BEGIN
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, @Op, @Name, @New OUTPUT;
            SET @AccID = @New;
        END

        IF ISNULL(@PrtID, 0) = 0
        BEGIN
            INSERT dbo.Prt_Party (PrtCmpID, PrtCode, PrtName, PrtRole, PrtAccID, PrtActive, PrtCreatedBy)
            VALUES (@Cmp, @Code, @Name, @Role, @AccID, ISNULL(@Active, 1), @User);
            SET @PrtID = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE dbo.Prt_Party
               SET PrtCode = @Code, PrtName = @Name, PrtRole = @Role, PrtAccID = COALESCE(@AccID, PrtAccID), PrtActive = ISNULL(@Active, 1)
             WHERE PrtID = @PrtID AND PrtCmpID = @Cmp;
            -- مزامنة اسم حساب النظام (الذي أنشأه النظام فقط) مع اسم الجهة
            IF @Cur IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.Acc_PostingRule WHERE AccID = @Cur AND StateID = 1)
               AND EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccID = @Cur AND AccName <> @Name)
                EXEC dbo.Acc_UpdaeAccounting @Name, @Cur, @User, @Cmp;
        END

        IF @Role = 1
        BEGIN
            IF @Whs IS NOT NULL
            BEGIN
                DELETE dbo.Prt_PartyWarehouse WHERE PwPrtID = @PrtID AND PwWhID NOT IN (SELECT WhID FROM @W);
                INSERT dbo.Prt_PartyWarehouse (PwPrtID, PwWhID)
                SELECT @PrtID, WhID FROM @W AS x
                WHERE NOT EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @PrtID AND PwWhID = x.WhID);
            END
            IF NOT EXISTS (SELECT 1 FROM dbo.Prt_PartyWarehouse WHERE PwPrtID = @PrtID)
                THROW 52240, N'مخزن واحد على الأقل مطلوب للمورد.', 1;
        END
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Prt_SaveParty;
        THROW;
    END CATCH
    SELECT @PrtID AS PrtID;
END;

GO

/****** Object:  StoredProcedure [dbo].[Wrh_EnsurePartyAccounts]    Script Date: 2026-11-13 11:31:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ------------------------------------------------------------------ معالجة الأطراف بلا حساب */
ALTER PROCEDURE [dbo].[Wrh_EnsurePartyAccounts]
    @Cmp INT, @User BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF ISNULL(@Cmp, 0) <= 0 OR NOT EXISTS (SELECT 1 FROM dbo.Mng_User WHERE UsrID = @User) THROW 52807, N'الشركة أو المستخدم غير صحيح.', 1;
    DECLARE @id BIGINT, @name NVARCHAR(500), @role TINYINT, @op SMALLINT, @acc BIGINT, @n INT = 0;
    DECLARE @Started BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN; SET @Started = 1; END
    ELSE SAVE TRANSACTION Sp_Wrh_EnsurePartyAccounts;
    BEGIN TRY
        DECLARE pc CURSOR LOCAL STATIC FOR
            SELECT PrtID, PrtName, PrtRole FROM dbo.Prt_Party WHERE PrtCmpID = @Cmp AND PrtAccID IS NULL AND PrtRole IN (1, 2) ORDER BY PrtID;
        OPEN pc; FETCH NEXT FROM pc INTO @id, @name, @role;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @op = CASE @role WHEN 1 THEN 201 ELSE 408 END;
            EXEC dbo.Wrh_CreateSystemAccount @Cmp, @User, @op, @name, @acc OUTPUT;
            UPDATE dbo.Prt_Party SET PrtAccID = @acc WHERE PrtID = @id;
            SET @n += 1;
            FETCH NEXT FROM pc INTO @id, @name, @role;
        END
        CLOSE pc; DEALLOCATE pc;
        IF @Started = 1 COMMIT;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'pc') >= 0 BEGIN CLOSE pc; DEALLOCATE pc; END
        IF @Started = 1 BEGIN IF @@TRANCOUNT > 0 ROLLBACK; END
        ELSE IF XACT_STATE() = 1 ROLLBACK TRANSACTION Sp_Wrh_EnsurePartyAccounts;
        THROW;
    END CATCH
    SELECT @n AS PartiesFixed;
END;

GO

-- الخطوة 3: ما بقي من العمليات القديمة بلا قواعد (يمكن حذفه بعد اختبار التطبيق)
SELECT o.OpID, o.OpName
FROM dbo.Acc_Operation AS o
WHERE o.OpID < 100
  AND NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingRule AS r WHERE r.OpID = o.OpID)
ORDER BY o.OpID;
GO

/* للحذف لاحقًا فقط، بعد التأكد من التطبيق:
DELETE o FROM dbo.Acc_Operation AS o
WHERE o.OpID < 100 AND NOT EXISTS (SELECT 1 FROM dbo.Acc_PostingRule AS r WHERE r.OpID = o.OpID);
*/

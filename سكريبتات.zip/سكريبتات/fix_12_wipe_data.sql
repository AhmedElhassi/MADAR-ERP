﻿USE [MADARERPDataBase];
GO

/* =====================================================================
   مسح بيانات العمل والدليل التجريبي (40 جدولًا) للبدء بدليل قياسي نظيف

   يُحذف: الحسابات وقواعد الربط ومراكز التكلفة والقيود وتواريخها وحالاتها
          والقيود الآلية، ومستندات المخازن وبنودها وطبقاتها ومخزونها
          وأصنافها ومجموعاتها ومخازنها ووحداتها، والأطراف، والمراسلات.
   يُبقى : Mng_* (المستخدمون والشركات والمنظومات والقوائم والصلاحيات والإشعارات)،
          Emp_Employee، Acc_Operation، Acc_PostingState، Acc_StateMenu،
          Acc_StageMenu، Acc_AutoSource، Wrh_DocTypeDef، Acc_CompanySettings،
          Wrh_Settings (مع تفريغ حساباتها المرجعية)، Acc_FiscalYear.

   الاستخدام:
     1) خذ نسخة احتياطية كاملة من القاعدة (الحذف لا رجعة فيه).
     2) نفّذ كما هو: @Execute = 0 يعرض معاينة بعدد صفوف كل جدول ولا يحذف شيئًا.
     3) اضبط @Execute = 1 وأعد التنفيذ والنظام خارج الاستخدام.

   حمايات: يتوقف إن لم تكن القاعدة MADARERPDataBase، أو لم توجد نسخة احتياطية
   كاملة خلال 24 ساعة (يُتجاوز بـ @SkipBackupCheck = 1)، ويتراجع كله إن بقي
   صف في أي جدول مستهدف.
   ===================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Execute         BIT = 0;   -- 0 = معاينة ، 1 = تنفيذ الحذف
DECLARE @SkipBackupCheck BIT = 0;   -- 1 = تجاوز فحص النسخة الاحتياطية

IF DB_NAME() <> N'MADARERPDataBase'
    THROW 60030, N'القاعدة الحالية ليست MADARERPDataBase.', 1;

-- الجداول بترتيب الحذف (الأبناء أولًا)
CREATE TABLE #T (Seq INT IDENTITY(1,1) PRIMARY KEY, TblName SYSNAME NOT NULL);
INSERT #T (TblName) VALUES
    (N'Acc_CashFlowAccounts'),
    (N'Acc_AutoVoucherLine'),
    (N'Acc_DayDetails'),
    (N'Acc_DayDetailsHistory'),
    (N'Acc_PostingRule'),
    (N'Prt_PartyWarehouse'),
    (N'Wrh_CountLine'),
    (N'Wrh_DocLine'),
    (N'Wrh_Doc'),
    (N'Prt_Party'),
    (N'Wrh_GroupWarehouse'),
    (N'Wrh_ItemUnit'),
    (N'Wrh_Stock'),
    (N'Wrh_Item'),
    (N'Wrh_ItemGroup'),
    (N'Wrh_Warehouse'),
    (N'Acc_Account'),
    (N'Acc_AccountHistory'),
    (N'Acc_AutoVoucher'),
    (N'Acc_CostCenter'),
    (N'Acc_CostCenterHistory'),
    (N'Acc_DayMasterState'),
    (N'Acc_DayMaster'),
    (N'Acc_DayMasterHistory'),
    (N'Msg_ConversationMember'),
    (N'Msg_MessageAttachment'),
    (N'Msg_MessageReceipt'),
    (N'Msg_Message'),
    (N'Msg_Conversation'),
    (N'Wrh_CostAdjLayer'),
    (N'Wrh_CostAdj'),
    (N'Wrh_CostLine'),
    (N'Wrh_DocEvent'),
    (N'Wrh_DocSeq'),
    (N'Wrh_LayerUse'),
    (N'Wrh_Layer'),
    (N'Wrh_LayerArchive'),
    (N'Wrh_LayerUseArchive'),
    (N'Wrh_Unit'),
    (N'Wrh_YearClose');

-- معاينة: عدد صفوف كل جدول
CREATE TABLE #Cnt (Seq INT, TblName SYSNAME, Cnt BIGINT);
DECLARE @i INT = 1, @n INT = (SELECT COUNT(*) FROM #T), @t SYSNAME, @sql NVARCHAR(MAX);
WHILE @i <= @n
BEGIN
    SELECT @t = TblName FROM #T WHERE Seq = @i;
    SET @sql = N'INSERT #Cnt SELECT ' + CAST(@i AS NVARCHAR(10)) + N', N''' + @t + N''', COUNT_BIG(*) FROM dbo.' + QUOTENAME(@t);
    EXEC sp_executesql @sql;
    SET @i += 1;
END;
SELECT TblName, Cnt FROM #Cnt ORDER BY Seq;
SELECT SUM(Cnt) AS TotalRowsToDelete FROM #Cnt;

-- ما سيبقى وقد يؤثر: السنوات المالية (يجب أن تكون سنة العمل مفتوحة AccFState = 0)
SELECT AccFCmpID, AccFYear, AccFName, AccFState FROM dbo.Acc_FiscalYear ORDER BY AccFCmpID, AccFYear;

IF @Execute = 0
BEGIN
    PRINT N'معاينة فقط. لم يُحذف شيء. اضبط @Execute = 1 بعد أخذ نسخة احتياطية.';
    DROP TABLE #Cnt; DROP TABLE #T;
    RETURN;
END;

IF @SkipBackupCheck = 0
   AND NOT EXISTS (SELECT 1 FROM msdb.dbo.backupset
                   WHERE database_name = DB_NAME() AND type = 'D'
                     AND backup_finish_date > DATEADD(HOUR, -24, GETDATE()))
    THROW 60031, N'لا توجد نسخة احتياطية كاملة خلال آخر 24 ساعة. خذ نسخة أولًا (أو اضبط @SkipBackupCheck = 1 إن كنت متأكدًا).', 1;

-- التنفيذ
BEGIN TRY
    BEGIN TRAN;

    -- جداول محتفظ بها تشير إلى الحسابات المحذوفة
    UPDATE dbo.Wrh_Settings
    SET WsDiffAccID = NULL, WsCreditNoteAccID = NULL, WsCountAccID = NULL, WsClosedUpTo = NULL;

    DELETE FROM dbo.[Acc_CashFlowAccounts];
    DELETE FROM dbo.[Acc_AutoVoucherLine];
    DELETE FROM dbo.[Acc_DayDetails];
    DELETE FROM dbo.[Acc_DayDetailsHistory];
    DELETE FROM dbo.[Acc_PostingRule];
    DELETE FROM dbo.[Prt_PartyWarehouse];
    DELETE FROM dbo.[Wrh_CountLine];
    DELETE FROM dbo.[Wrh_DocLine];
    DELETE FROM dbo.[Wrh_Doc];
    DELETE FROM dbo.[Prt_Party];
    DELETE FROM dbo.[Wrh_GroupWarehouse];
    DELETE FROM dbo.[Wrh_ItemUnit];
    DELETE FROM dbo.[Wrh_Stock];
    DELETE FROM dbo.[Wrh_Item];
    DELETE FROM dbo.[Wrh_ItemGroup];
    DELETE FROM dbo.[Wrh_Warehouse];
    DELETE FROM dbo.[Acc_Account];
    DELETE FROM dbo.[Acc_AccountHistory];
    DELETE FROM dbo.[Acc_AutoVoucher];
    DELETE FROM dbo.[Acc_CostCenter];
    DELETE FROM dbo.[Acc_CostCenterHistory];
    DELETE FROM dbo.[Acc_DayMasterState];
    DELETE FROM dbo.[Acc_DayMaster];
    DELETE FROM dbo.[Acc_DayMasterHistory];
    DELETE FROM dbo.[Msg_ConversationMember];
    DELETE FROM dbo.[Msg_MessageAttachment];
    DELETE FROM dbo.[Msg_MessageReceipt];
    DELETE FROM dbo.[Msg_Message];
    DELETE FROM dbo.[Msg_Conversation];
    DELETE FROM dbo.[Wrh_CostAdjLayer];
    DELETE FROM dbo.[Wrh_CostAdj];
    DELETE FROM dbo.[Wrh_CostLine];
    DELETE FROM dbo.[Wrh_DocEvent];
    DELETE FROM dbo.[Wrh_DocSeq];
    DELETE FROM dbo.[Wrh_LayerUse];
    DELETE FROM dbo.[Wrh_Layer];
    DELETE FROM dbo.[Wrh_LayerArchive];
    DELETE FROM dbo.[Wrh_LayerUseArchive];
    DELETE FROM dbo.[Wrh_Unit];
    DELETE FROM dbo.[Wrh_YearClose];

    -- تحقق: لا صف بقي
    DELETE FROM #Cnt;
    SET @i = 1;
    WHILE @i <= @n
    BEGIN
        SELECT @t = TblName FROM #T WHERE Seq = @i;
        SET @sql = N'INSERT #Cnt SELECT ' + CAST(@i AS NVARCHAR(10)) + N', N''' + @t + N''', COUNT_BIG(*) FROM dbo.' + QUOTENAME(@t);
        EXEC sp_executesql @sql;
        SET @i += 1;
    END;
    IF EXISTS (SELECT 1 FROM #Cnt WHERE Cnt > 0)
        THROW 60032, N'بقيت صفوف في بعض الجداول المستهدفة؛ أُلغيت العملية.', 1;

    COMMIT;
    PRINT N'تم المسح.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH;

-- بعد الحذف: إعادة ضبط العدّادات التلقائية لتبدأ من 1 (للجداول التي استُعملت فقط)
DECLARE @r NVARCHAR(MAX);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT N'DBCC CHECKIDENT (N''dbo.' + o.name + N''', RESEED, '
           + CAST(CAST(ic.seed_value AS BIGINT) - CAST(ic.increment_value AS BIGINT) AS NVARCHAR(30)) + N') WITH NO_INFOMSGS'
    FROM sys.identity_columns AS ic
    JOIN sys.objects AS o ON o.object_id = ic.object_id
    JOIN #T AS x ON x.TblName = o.name
    WHERE ic.last_value IS NOT NULL;
OPEN c; FETCH NEXT FROM c INTO @r;
WHILE @@FETCH_STATUS = 0 BEGIN EXEC (@r); FETCH NEXT FROM c INTO @r; END;
CLOSE c; DEALLOCATE c;

-- حذف الجداول المساعدة التي أنشأناها أثناء العمل (إن وُجدت)
IF OBJECT_ID(N'dbo.Acc_DayMasterRenumberLog') IS NOT NULL DROP TABLE dbo.Acc_DayMasterRenumberLog;
IF OBJECT_ID(N'dbo.Bak_Del_DayMaster')        IS NOT NULL DROP TABLE dbo.Bak_Del_DayMaster;
IF OBJECT_ID(N'dbo.Bak_Del_DayDetails')       IS NOT NULL DROP TABLE dbo.Bak_Del_DayDetails;
IF OBJECT_ID(N'dbo.Bak_Del_DayMasterState')   IS NOT NULL DROP TABLE dbo.Bak_Del_DayMasterState;
IF OBJECT_ID(N'dbo.Bak_Del_AutoVoucher')      IS NOT NULL DROP TABLE dbo.Bak_Del_AutoVoucher;
IF OBJECT_ID(N'dbo.Bak_Del_AutoVoucherLine')  IS NOT NULL DROP TABLE dbo.Bak_Del_AutoVoucherLine;

DROP TABLE #Cnt; DROP TABLE #T;
PRINT N'اكتمل: مسح البيانات وإعادة ضبط العدّادات. ابدأ الآن بإنشاء الدليل القياسي وتسجيل الآباء في ربط الحسابات.';
GO

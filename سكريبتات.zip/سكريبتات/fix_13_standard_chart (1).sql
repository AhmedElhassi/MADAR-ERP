﻿USE [MADARERPDataBase];
GO

/* =====================================================================
   تحميل الدليل الحسابي القياسي (شركة مقاولات وخدمات) + تسجيل آباء العمليات
   الأكواد والمستويات يولّدها النظام نفسه (Acc_UpdateAccountCode) كما في الإدخال اليدوي:
   الجذور 1 إلى 5، وكل فرع = كود أبيه + رقم ترتيبه بعرض يتبع عدد إخوته.

   الجذور (AccEnd/AccType): الأصول 1/0 ، الخصوم 1/1 ، حقوق الملكية 1/2 ،
                            الإيرادات 2/0 ، المصروفات 2/1  (يرثها كل ابن)

   المتطلبات:
     - fix_10 و fix_11 نُفّذا (أرقام العمليات الجديدة موجودة)
     - لا حسابات للشركة (نفّذ fix_12 أولًا)، وإلا يتوقف السكربت
   قواعد الربط (Acc_PostingRule) تُسجَّل مع الدليل ما دام @RegisterRules = 1:
     الحالة 3 = أب يولّد النظام أبناءه آليًا   (الخزينة، المصارف، العهد، الموردين...)
     الحالة 2 = حساب نظام مقفل بقيد عادي        (إتلاف مخزون، الأجور، المكافئات...)
     الحالة 1 = حساب نظام لا يُمس، بلا قيد يدوي (التحويلات النقدية بالطريق)
   عدّل جدول #Chart أدناه (الأسماء ومواضع العمليات والحالات) قبل التنفيذ إن لزم.
   ===================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Cmp           INT    = 10;     -- رقم الشركة
DECLARE @User          BIGINT = (SELECT MIN(UsrID) FROM dbo.Mng_User);   -- المستخدم المنفِّذ
DECLARE @RegisterRules BIT    = 1;      -- 1 = سجّل قواعد الربط للعمليات

IF NOT EXISTS (SELECT 1 FROM dbo.Mng_Company WHERE CmpID = @Cmp)
    THROW 60040, N'الشركة غير موجودة في Mng_Company.', 1;
IF @User IS NULL
    THROW 60041, N'لا يوجد مستخدم في Mng_User.', 1;
IF EXISTS (SELECT 1 FROM dbo.Acc_Account WHERE AccCompany = @Cmp)
    THROW 60042, N'للشركة حسابات موجودة. نفّذ fix_12_wipe_data.sql أولًا (أو احذف حساباتها).', 1;

CREATE TABLE #Chart
(
    Seq INT NOT NULL PRIMARY KEY, ParentSeq INT NULL, Lvl INT NOT NULL, Name NVARCHAR(500) NOT NULL,
    OpID SMALLINT NULL, StateID TINYINT NULL, AccEnd TINYINT NULL, AccType TINYINT NULL
);
INSERT #Chart (Seq, ParentSeq, Lvl, Name, OpID, StateID, AccEnd, AccType) VALUES
    (1, NULL, 1, N'الأصول', NULL, NULL, 1, 0),
    (2, 1, 2, N'الأصول غير المتداولة', NULL, NULL, NULL, NULL),
    (3, 2, 3, N'الأصول الثابتة', 105, 3, NULL, NULL),
    (4, 2, 3, N'مجمع إهلاك الأصول الثابتة', NULL, NULL, NULL, NULL),
    (5, 2, 3, N'مشروعات تحت التنفيذ', NULL, NULL, NULL, NULL),
    (6, 1, 2, N'الأصول المتداولة', NULL, NULL, NULL, NULL),
    (7, 6, 3, N'النقدية', NULL, NULL, NULL, NULL),
    (8, 7, 4, N'الخزينة', 101, 3, NULL, NULL),
    (9, 7, 4, N'المصارف', 102, 3, NULL, NULL),
    (10, 7, 4, N'التحويلات النقدية بالطريق', 104, 1, NULL, NULL),
    (11, 6, 3, N'العهد المالية', 103, 3, NULL, NULL),
    (12, 6, 3, N'المخزون', NULL, NULL, NULL, NULL),
    (13, 12, 4, N'المخازن', 202, 3, NULL, NULL),
    (14, 12, 4, N'مواد تشغيل', 203, 3, NULL, NULL),
    (15, 6, 3, N'المدينون', NULL, NULL, NULL, NULL),
    (16, 15, 4, N'أصحاب الأعمال', 301, 3, NULL, NULL),
    (17, 15, 4, N'سلف العاملين', 405, 3, NULL, NULL),
    (18, 15, 4, N'مدينون - موظفي الشركة', 406, 3, NULL, NULL),
    (19, 15, 4, N'مدينون متنوعون', NULL, NULL, NULL, NULL),
    (20, 6, 3, N'مصروفات مدفوعة مقدمًا', NULL, NULL, NULL, NULL),
    (21, 20, 4, N'مصروف مرتبات مقدم', 402, 2, NULL, NULL),
    (22, 20, 4, N'إيجارات مدفوعة مقدمًا', NULL, NULL, NULL, NULL),
    (23, 20, 4, N'تأمينات مدفوعة مقدمًا', NULL, NULL, NULL, NULL),
    (24, 6, 3, N'دفعات مقدمة للموردين', NULL, NULL, NULL, NULL),
    (25, 6, 3, N'تأمينات لدى الغير', NULL, NULL, NULL, NULL),
    (26, NULL, 1, N'الخصوم', NULL, NULL, 1, 1),
    (27, 26, 2, N'الخصوم المتداولة', NULL, NULL, NULL, NULL),
    (28, 27, 3, N'الموردين', 201, 3, NULL, NULL),
    (29, 27, 3, N'منفذي الأعمال', 302, 3, NULL, NULL),
    (30, 27, 3, N'الدائنون المتنوعون', 408, 3, NULL, NULL),
    (31, 27, 3, N'المصروفات المستحقة', 404, 2, NULL, NULL),
    (32, 27, 3, N'خصم من الموظف لصالح الغير', 407, 2, NULL, NULL),
    (33, 27, 3, N'ضرائب ورسوم مستحقة', NULL, NULL, NULL, NULL),
    (34, 27, 3, N'دفعات مقدمة من أصحاب الأعمال', NULL, NULL, NULL, NULL),
    (35, 27, 3, N'تأمينات محتجزة من منفذي الأعمال', NULL, NULL, NULL, NULL),
    (36, 26, 2, N'الخصوم غير المتداولة', NULL, NULL, NULL, NULL),
    (37, 36, 3, N'قروض طويلة الأجل', NULL, NULL, NULL, NULL),
    (38, 36, 3, N'مخصص مكافأة نهاية الخدمة', NULL, NULL, NULL, NULL),
    (39, NULL, 1, N'حقوق الملكية', NULL, NULL, 1, 2),
    (40, 39, 2, N'رأس المال', NULL, NULL, NULL, NULL),
    (41, 39, 2, N'الاحتياطيات', NULL, NULL, NULL, NULL),
    (42, 39, 2, N'الأرباح (الخسائر) المدورة', NULL, NULL, NULL, NULL),
    (43, 39, 2, N'جاري الشركاء', NULL, NULL, NULL, NULL),
    (44, NULL, 1, N'الإيرادات', NULL, NULL, 2, 0),
    (45, 44, 2, N'إيرادات النشاط', NULL, NULL, NULL, NULL),
    (46, 45, 3, N'إيرادات مستخلصات الأعمال', NULL, NULL, NULL, NULL),
    (47, 45, 3, N'إيرادات الخدمات', NULL, NULL, NULL, NULL),
    (48, 45, 3, N'إيرادات بيع مواد', NULL, NULL, NULL, NULL),
    (49, 44, 2, N'إيرادات أخرى', NULL, NULL, NULL, NULL),
    (50, 49, 3, N'أرباح بيع أصول ثابتة', NULL, NULL, NULL, NULL),
    (51, 49, 3, N'فوائد دائنة', NULL, NULL, NULL, NULL),
    (52, 49, 3, N'إيرادات متنوعة', NULL, NULL, NULL, NULL),
    (53, NULL, 1, N'المصروفات', NULL, NULL, 2, 1),
    (54, 53, 2, N'تكلفة النشاط', NULL, NULL, NULL, NULL),
    (55, 54, 3, N'تكلفة المواد المستخدمة', NULL, NULL, NULL, NULL),
    (56, 54, 3, N'أعمال تشغيل', 303, 3, NULL, NULL),
    (57, 54, 3, N'إتلاف مخزون', 204, 2, NULL, NULL),
    (58, 54, 3, N'وقود وزيوت للآليات', NULL, NULL, NULL, NULL),
    (59, 54, 3, N'صيانة الآليات والمعدات', NULL, NULL, NULL, NULL),
    (60, 53, 2, N'مصروفات العاملين', NULL, NULL, NULL, NULL),
    (61, 60, 3, N'أجور ومرتبات', 401, 2, NULL, NULL),
    (62, 60, 3, N'مكافئات', 403, 2, NULL, NULL),
    (63, 60, 3, N'مصاريف إعاشة', 409, 2, NULL, NULL),
    (64, 60, 3, N'تأمينات اجتماعية', NULL, NULL, NULL, NULL),
    (65, 60, 3, N'مصروف مكافأة نهاية الخدمة', NULL, NULL, NULL, NULL),
    (66, 53, 2, N'المصروفات الإدارية والعمومية', NULL, NULL, NULL, NULL),
    (67, 66, 3, N'إيجارات', NULL, NULL, NULL, NULL),
    (68, 66, 3, N'كهرباء ومياه واتصالات', NULL, NULL, NULL, NULL),
    (69, 66, 3, N'صيانة عامة', NULL, NULL, NULL, NULL),
    (70, 66, 3, N'قرطاسية ومطبوعات', NULL, NULL, NULL, NULL),
    (71, 66, 3, N'سفر وانتقالات', NULL, NULL, NULL, NULL),
    (72, 66, 3, N'ضيافة', NULL, NULL, NULL, NULL),
    (73, 66, 3, N'أتعاب مهنية وقانونية', NULL, NULL, NULL, NULL),
    (74, 66, 3, N'رسوم وتراخيص', NULL, NULL, NULL, NULL),
    (75, 66, 3, N'مصروفات بنكية', NULL, NULL, NULL, NULL),
    (76, 53, 2, N'مصروف الإهلاك', NULL, NULL, NULL, NULL),
    (77, 53, 2, N'مصروفات أخرى', NULL, NULL, NULL, NULL),
    (78, 77, 3, N'غرامات', NULL, NULL, NULL, NULL),
    (79, 77, 3, N'خسائر بيع أصول ثابتة', NULL, NULL, NULL, NULL),
    (80, 77, 3, N'مصروفات متنوعة', NULL, NULL, NULL, NULL);

CREATE TABLE #Map (Seq INT NOT NULL PRIMARY KEY, AccID BIGINT NOT NULL);

BEGIN TRY
    BEGIN TRAN;

    IF @RegisterRules = 1
       AND EXISTS (SELECT 1 FROM #Chart c WHERE c.OpID IS NOT NULL
                   AND NOT EXISTS (SELECT 1 FROM dbo.Acc_Operation o WHERE o.OpID = c.OpID))
        THROW 60043, N'أرقام عمليات غير موجودة في Acc_Operation؛ نفّذ fix_10_add_operations.sql أولًا.', 1;

    -- إدخال الحسابات مستوى بمستوى (الأب قبل ابنه)
    DECLARE @L INT = 1, @MaxL INT = (SELECT MAX(Lvl) FROM #Chart);
    WHILE @L <= @MaxL
    BEGIN
        MERGE dbo.Acc_Account AS t
        USING (
            SELECT c.Seq, c.Name,
                   COALESCE(c.AccEnd,  p.AccEnd)  AS AccEnd,
                   COALESCE(c.AccType, p.AccType) AS AccType,
                   pm.AccID AS ParentID,
                   ROW_NUMBER() OVER (PARTITION BY c.ParentSeq ORDER BY c.Seq) AS Ord,
                   (SELECT COUNT(*) FROM #Chart k WHERE k.ParentSeq = c.Seq) AS Chid
            FROM #Chart AS c
            LEFT JOIN #Map AS pm ON pm.Seq = c.ParentSeq
            LEFT JOIN dbo.Acc_Account AS p ON p.AccID = pm.AccID
            WHERE c.Lvl = @L
        ) AS s ON 1 = 0
        WHEN NOT MATCHED THEN
            INSERT (AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid, AccCode, AccName,
                    AccState, AccDateTime, AccUser, AccCompany)
            VALUES (s.AccEnd, s.AccType, s.ParentID, s.Ord, @L, s.Chid, CONCAT(N'~', s.Seq), s.Name,
                    0, SYSDATETIME(), @User, @Cmp)
        OUTPUT s.Seq, inserted.AccID INTO #Map (Seq, AccID);
        SET @L += 1;
    END;

    -- رموز الجذور 1..5 بحسب الترتيب
    UPDATE a SET a.AccCode = CAST(r.n AS NVARCHAR(10))
    FROM dbo.Acc_Account AS a
    JOIN (SELECT m.AccID, ROW_NUMBER() OVER (ORDER BY m.Seq) AS n
          FROM #Map AS m JOIN #Chart AS c ON c.Seq = m.Seq WHERE c.Lvl = 1) AS r ON r.AccID = a.AccID;

    -- أكواد الفروع بإجراء النظام نفسه
    EXEC dbo.Acc_UpdateAccountCode @AccCompany = @Cmp;

    -- سجل التاريخ (عملية 1 = إنشاء)
    INSERT INTO dbo.Acc_AccountHistory
        (AccHOpration, AccHAccID, AccHEnd, AccHType, AccHParentID, AccHOrder, AccHLevel, AccHChid,
         AccHCode, AccHName, AccHState, AccHDateTime, AccHUser, AccHCompany)
    SELECT 1, AccID, AccEnd, AccType, AccParentID, AccOrder, AccLevel, AccChid,
           AccCode, AccName, AccState, AccDateTime, AccUser, AccCompany
    FROM dbo.Acc_Account
    WHERE AccCompany = @Cmp;

    -- قواعد الربط
    IF @RegisterRules = 1
        INSERT dbo.Acc_PostingRule (OpID, AccID, StateID)
        SELECT c.OpID, m.AccID, c.StateID
        FROM #Chart AS c JOIN #Map AS m ON m.Seq = c.Seq
        WHERE c.OpID IS NOT NULL;

    COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH;

-- تحقق
SELECT AccLevel, COUNT(*) AS Accounts FROM dbo.Acc_Account WHERE AccCompany = @Cmp GROUP BY AccLevel ORDER BY AccLevel;

SELECT o.OpID, o.OpName, a.AccCode, a.AccName, r.StateID
FROM dbo.Acc_PostingRule AS r
JOIN dbo.Acc_Operation AS o ON o.OpID = r.OpID
JOIN dbo.Acc_Account   AS a ON a.AccID = r.AccID
WHERE a.AccCompany = @Cmp
ORDER BY o.OpID;

EXEC dbo.Acc_CheckProtectedAccounts @Cmp = @Cmp;

DROP TABLE #Map; DROP TABLE #Chart;
GO

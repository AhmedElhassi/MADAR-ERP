USE [MADARERPDataBase]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* =====================================================================
   2) فتح قيد: نتيجتان
      الأولى: رأس القيد
      الثانية: البنود (تفصيلي أو ملخص حسب @ViewType)
   ===================================================================== */
ALTER PROCEDURE [dbo].[Acc_SelectDayEntryViewType]
    @Cmp       INT,
    @DayMID    BIGINT,
    @ViewType  TINYINT = 1 -- 0: تفصيلي, 1: ملخص
AS
BEGIN
    SET NOCOUNT ON;

    -- التحقق من وجود القيد وتبعبيته للشركة
    IF NOT EXISTS (SELECT 1 FROM dbo.Acc_DayMaster WHERE DayMID = @DayMID AND DayMCompany = @Cmp)
        THROW 50120, N'القيد غير موجود أو لا يتبع الشركة.', 1;

    -- 1. جلب رأس القيد (يظهر في كلا الشكلين)
    SELECT m.DayMID,
           m.DayMNo,
           CASE WHEN m.DayMNo > 0
                THEN CONCAT(m.DayMNo, N' / ', RIGHT(CONCAT(N'0', MONTH(m.DayMDate)), 2))
                ELSE N'' END AS VoucherNo,
           m.DayMDate,
           m.DayMDescription,
           m.DayMState,
           (SELECT ISNULL(SUM(d.DayDDeb), 0) FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS TotalDebit,
           (SELECT ISNULL(SUM(d.DayDCrd), 0) FROM dbo.Acc_DayDetails AS d WHERE d.DayDMID = m.DayMID) AS TotalCredit,
           E.EmpName
    FROM dbo.Acc_DayMaster AS m
    INNER JOIN Emp_Employee E ON E.EmpID = m.DayMUser
    WHERE m.DayMID = @DayMID AND m.DayMCompany = @Cmp;

    -- 2. جلب بنود القيد بناءً على شكل العرض المطلوب
    IF @ViewType = 0
    BEGIN
        -- **الشكل الأول: تفصيلي (عرض كل بند على حدة مع مركز التكلفة)**
        SELECT d.DayDID, 
               d.DayDAccID, 
               a.AccCode, 
               a.AccName,
               d.DayDDeb, 
               d.DayDCrd,
               d.DayDCsCID, 
               c.CsCCode, 
               c.CsCName,
               d.DayDNum, 
               d.DayDDescription
        FROM dbo.Acc_DayDetails AS d
        JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
        LEFT JOIN dbo.Acc_CostCenter AS c ON c.CsCID = d.DayDCsCID
        WHERE d.DayDMID = @DayMID
        ORDER BY d.DayDID;
    END
    ELSE
    BEGIN
        -- **الشكل الثاني: ملخص (تجميع المبالغ حسب الحساب الرئيسي الأب أو الحساب نفسه إذا لم يوجـد أب)**
        SELECT CAST(0 AS BIGINT) AS DayDID,
               ISNULL(parent.AccID, a.AccID) AS DayDAccID,
               ISNULL(parent.AccCode, a.AccCode) AS AccCode,
               ISNULL(parent.AccName, a.AccName) AS AccName,
               SUM(d.DayDDeb) AS DayDDeb,
               SUM(d.DayDCrd) AS DayDCrd,
               CAST(NULL AS BIGINT) AS DayDCsCID,
               N'' AS CsCCode,
               N'' AS CsCName,
               N'' AS DayDNum,
               N'إجمالي ملخص' AS DayDDescription
        FROM dbo.Acc_DayDetails AS d
        JOIN dbo.Acc_Account AS a ON a.AccID = d.DayDAccID
        LEFT JOIN dbo.Acc_Account AS parent ON parent.AccID = a.AccParentID
        WHERE d.DayDMID = @DayMID
        GROUP BY ISNULL(parent.AccID, a.AccID),
                 ISNULL(parent.AccCode, a.AccCode),
                 ISNULL(parent.AccName, a.AccName);
    END
END;
GO
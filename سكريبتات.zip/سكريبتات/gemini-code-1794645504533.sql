CREATE TABLE [dbo].[Emp_WorkScheduleTypes]
(
    [Emp_SchTypeID] [bigint] IDENTITY(1,1) NOT NULL,
    [Emp_SchTypeName] [nvarchar](255) NOT NULL,
    [Emp_SchTypeCmp] [int] NOT NULL,

    -- الحقول التشغيلية والزمنية للورديات
    [Emp_SchStartTime] [time](0) NOT NULL,
    [Emp_SchEndTime] [time](0) NOT NULL,
    [Emp_SchWorkingHours] [decimal](4,2) NOT NULL,
    [Emp_SchGraceMinutes] [smallint] NOT NULL 
        CONSTRAINT [DF_Emp_WorkScheduleTypes_Grace] DEFAULT ((0)),
    [Emp_SchIsNightShift] [tinyint] NOT NULL 
        CONSTRAINT [DF_Emp_WorkScheduleTypes_Night] DEFAULT ((0)),
    [Emp_SchCrossesMidnight] [tinyint] NOT NULL 
        CONSTRAINT [DF_Emp_WorkScheduleTypes_CrossMidnight] DEFAULT ((0)),

    -- الحقول القياسية
    [Emp_SchTypeState] [tinyint] NOT NULL
        CONSTRAINT [DF_Emp_WorkScheduleTypes_Emp_SchTypeState] DEFAULT ((0)),
    [Emp_SchTypeDate] [datetime2](0) NOT NULL
        CONSTRAINT [DF_Emp_WorkScheduleTypes_Emp_SchTypeDate] DEFAULT (SYSDATETIME()),
    [Emp_SchTypeUser] [bigint] NOT NULL,

    -- المفاتيح والقيود الأساسية
    CONSTRAINT [PK_Emp_WorkScheduleTypes]
        PRIMARY KEY CLUSTERED ([Emp_SchTypeID] ASC),

    CONSTRAINT [UQ_Emp_WorkScheduleTypes_Company_Name]
        UNIQUE NONCLUSTERED ([Emp_SchTypeCmp] ASC, [Emp_SchTypeName] ASC),

    CONSTRAINT [FK_Emp_WorkScheduleTypes_Company]
        FOREIGN KEY ([Emp_SchTypeCmp])
        REFERENCES [dbo].[Mng_Company] ([CmpID]),

    CONSTRAINT [FK_Emp_WorkScheduleTypes_User]
        FOREIGN KEY ([Emp_SchTypeUser])
        REFERENCES [dbo].[Mng_User] ([UsrID]),

    -- قيود التحقق الصارمة لسلامة البيانات والمنطق الزمني
    CONSTRAINT [CK_Emp_WorkScheduleTypes_WorkingHours]
        CHECK ([Emp_SchWorkingHours] > 0 AND [Emp_SchWorkingHours] <= 24),

    CONSTRAINT [CK_Emp_WorkScheduleTypes_GraceMinutes]
        CHECK ([Emp_SchGraceMinutes] >= 0),

    CONSTRAINT [CK_Emp_WorkScheduleTypes_IsNightShift]
        CHECK ([Emp_SchIsNightShift] IN (0, 1)),

    CONSTRAINT [CK_Emp_WorkScheduleTypes_CrossesMidnight]
        CHECK ([Emp_SchCrossesMidnight] IN (0, 1)),

    CONSTRAINT [CK_Emp_WorkScheduleTypes_State]
        CHECK ([Emp_SchTypeState] IN (0, 1)),

    -- قيد منطق منتصف الليل (يدعم الورديات العادية والورديات الكاملة 24 ساعة عند تساوي البداية والنهاية مع عبور منتصف الليل)
    CONSTRAINT [CK_Emp_WorkScheduleTypes_MidnightLogic]
        CHECK
        (
            (
                [Emp_SchCrossesMidnight] = 0
                AND [Emp_SchEndTime] > [Emp_SchStartTime]
            )
            OR
            (
                [Emp_SchCrossesMidnight] = 1
                AND [Emp_SchEndTime] <= [Emp_SchStartTime]
            )
        ),

    -- قيد ارتباط ساعات العمل الفعلية بالمدة الزمنية المتاحة بين البداية والنهاية
    CONSTRAINT [CK_Emp_WorkScheduleTypes_HoursWithinSpan]
        CHECK 
        (
            ([Emp_SchWorkingHours] * 60) <= 
            (
                DATEDIFF(MINUTE, [Emp_SchStartTime], [Emp_SchEndTime]) + 
                CASE WHEN [Emp_SchCrossesMidnight] = 1 THEN 1440 ELSE 0 END
            )
        )
);
GO